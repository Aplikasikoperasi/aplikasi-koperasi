import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function formatDobPassword(dateOfBirth: string): string {
  const dob = new Date(dateOfBirth);
  const day = String(dob.getDate()).padStart(2, "0");
  const month = String(dob.getMonth() + 1).padStart(2, "0");
  const year = dob.getFullYear();
  return `${day}${month}${year}`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  console.log("[saver-login] Start");

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    if (!supabaseUrl || !serviceKey) {
      throw new Error("Missing backend configuration");
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    const body = await req.json().catch(() => ({}));
    const rawSaverNumber = String(body?.saverNumber ?? body?.saver_number ?? "");
    const rawPassword = String(body?.password ?? "");

    const saverNumber = rawSaverNumber.trim().toUpperCase();
    const typedPassword = rawPassword.trim();

    if (!saverNumber || !typedPassword) {
      return new Response(
        JSON.stringify({ success: false, error: "Missing credentials" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        },
      );
    }

    // Look up saver safely using service role
    const { data: saver, error: saverError } = await supabaseAdmin
      .from("savers")
      .select(
        "id, saver_number, full_name, account_number, phone, address, email, photo_url, date_of_birth, occupation, status, created_at, balance, deposit_balance, interest_balance, tier_level, login_email, user_id",
      )
      .eq("saver_number", saverNumber)
      .eq("status", "active")
      .maybeSingle();

    if (saverError) {
      console.error("[saver-login] Saver lookup error:", saverError.message);
      throw new Error("Saver lookup failed");
    }

    if (!saver) {
      return new Response(
        JSON.stringify({ success: false, notFound: true }),
        { headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    if (!saver.date_of_birth) {
      return new Response(
        JSON.stringify({ success: false, code: "DATA_INCOMPLETE" }),
        { headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    const expectedPassword = formatDobPassword(saver.date_of_birth);
    if (typedPassword !== expectedPassword) {
      return new Response(
        JSON.stringify({ success: false, code: "INVALID_CREDENTIALS" }),
        { headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    // If saver already linked to an auth user, trust that mapping and return its email
    if (saver.user_id) {
      const { data: authUser, error: authUserError } = await supabaseAdmin.auth.admin
        .getUserById(saver.user_id);

      if (!authUserError && authUser?.user?.email) {
        const email = authUser.user.email;

        if (saver.login_email !== email) {
          await supabaseAdmin
            .from("savers")
            .update({ login_email: email })
            .eq("id", saver.id);
        }

        const duration = Date.now() - startTime;
        console.log(`[saver-login] Linked user OK in ${duration}ms`);

        return new Response(
          JSON.stringify({
            success: true,
            email,
            fullName: saver.full_name,
            saver,
          }),
          { headers: { "Content-Type": "application/json", ...corsHeaders } },
        );
      }

      // If mapping is broken, fall through to recreate.
      console.warn("[saver-login] Broken user_id mapping, recreating auth user");
    }

    // Create (or recreate) an auth user and link it to this saver
    const primaryEmail = saver.login_email ?? `${saver.saver_number.toLowerCase()}@saver.local`;

    const createUser = async (email: string) => {
      return await supabaseAdmin.auth.admin.createUser({
        email,
        password: expectedPassword,
        email_confirm: true,
        user_metadata: { full_name: saver.full_name, is_saver: true },
      });
    };

    let usedEmail = primaryEmail;
    let authUserId: string | null = null;

    const { data: created, error: createError } = await createUser(usedEmail);

    if (createError) {
      const msg = createError.message || "";
      const isAlreadyExists =
        msg.includes("already been registered") || msg.includes("already exists");

      if (!isAlreadyExists) {
        console.error("[saver-login] Create user failed:", msg);
        throw new Error("Failed to create account");
      }

      // Conflict: create a new unique email and link to it
      usedEmail = `${saver.saver_number.toLowerCase()}-${Date.now()}@saver.local`;
      console.log("[saver-login] Email conflict, using:", usedEmail);

      const { data: fallback, error: fallbackError } = await createUser(usedEmail);
      if (fallbackError) {
        console.error("[saver-login] Fallback create failed:", fallbackError.message);
        throw new Error("Failed to create account");
      }

      authUserId = fallback.user?.id ?? null;
    } else {
      authUserId = created.user?.id ?? null;
    }

    if (!authUserId) {
      throw new Error("Auth user id missing");
    }

    const updateSaver = await supabaseAdmin
      .from("savers")
      .update({ user_id: authUserId, login_email: usedEmail })
      .eq("id", saver.id);

    if (updateSaver.error) {
      console.error("[saver-login] Saver update failed:", updateSaver.error.message);
      throw new Error("Failed to link saver account");
    }

    const duration = Date.now() - startTime;
    console.log(`[saver-login] SUCCESS in ${duration}ms`);

    return new Response(
      JSON.stringify({
        success: true,
        email: usedEmail,
        fullName: saver.full_name,
        saver: { ...saver, user_id: authUserId, login_email: usedEmail },
      }),
      { headers: { "Content-Type": "application/json", ...corsHeaders } },
    );
  } catch (error) {
    const duration = Date.now() - startTime;
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error(`[saver-login] FAILED after ${duration}ms:`, message);

    return new Response(
      JSON.stringify({ success: false, error: message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } },
    );
  }
});
