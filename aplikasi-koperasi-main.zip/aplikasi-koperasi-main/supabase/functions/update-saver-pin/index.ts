import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple hash function for PIN (using Web Crypto API)
async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin + "saver_pin_salt_2024");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization") ?? "";

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: authData, error: authError } = await supabaseAuth.auth.getUser();
    const user = authData?.user;

    if (authError || !user) {
      return new Response(
        JSON.stringify({ success: false, message: "Tidak diizinkan" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { saver_id, current_pin, new_pin } = await req.json();

    if (!saver_id || !new_pin) {
      return new Response(
        JSON.stringify({ success: false, message: "Data tidak lengkap" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate new PIN format (6 digits)
    if (!/^\d{6}$/.test(new_pin)) {
      return new Response(
        JSON.stringify({ success: false, message: "PIN harus 6 digit angka" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Ensure this saver belongs to the authenticated user and fetch current PIN
    const { data: saver, error: fetchError } = await supabaseAdmin
      .from("savers")
      .select("pin_hash")
      .eq("id", saver_id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (fetchError) {
      throw fetchError;
    }

    if (!saver) {
      return new Response(
        JSON.stringify({ success: false, message: "Tidak diizinkan" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // If saver already has a PIN, verify current PIN
    if (saver.pin_hash) {
      if (!current_pin) {
        return new Response(
          JSON.stringify({ success: false, message: "PIN saat ini diperlukan" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Validate current PIN format (6 digits)
      if (!/^\d{6}$/.test(current_pin)) {
        return new Response(
          JSON.stringify({ success: false, message: "PIN saat ini harus 6 digit angka" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const currentPinHash = await hashPin(current_pin);
      if (currentPinHash !== saver.pin_hash) {
        return new Response(
          JSON.stringify({ success: false, message: "PIN saat ini salah" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Hash and save new PIN (only for this user)
    const newPinHash = await hashPin(new_pin);

    const { error: updateError } = await supabaseAdmin
      .from("savers")
      .update({ pin_hash: newPinHash })
      .eq("id", saver_id)
      .eq("user_id", user.id);

    if (updateError) {
      throw updateError;
    }

    return new Response(
      JSON.stringify({ success: true, message: "PIN berhasil diperbarui" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error updating PIN:", error);
    return new Response(
      JSON.stringify({ success: false, message: "Terjadi kesalahan server" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
