import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

/**
 * Generate OAuth access token from service account
 */
async function getServiceAccountToken(
  clientEmail: string,
  privateKey: string,
  scopes: string[]
): Promise<string> {
  const header = { alg: "RS256", typ: "JWT" };
  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: clientEmail,
    scope: scopes.join(" "),
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now,
  };

  const encodedHeader = btoa(JSON.stringify(header)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const encodedClaim = btoa(JSON.stringify(claim)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const signatureInput = `${encodedHeader}.${encodedClaim}`;

  const pemHeader = "-----BEGIN PRIVATE KEY-----";
  const pemFooter = "-----END PRIVATE KEY-----";
  const pemContents = privateKey.substring(pemHeader.length, privateKey.length - pemFooter.length).trim();
  const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));

  const key = await crypto.subtle.importKey(
    "pkcs8",
    binaryDer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(signatureInput));
  const encodedSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const jwt = `${signatureInput}.${encodedSignature}`;

  const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  if (!tokenResponse.ok) {
    throw new Error(`Token request failed: ${await tokenResponse.text()}`);
  }

  const tokenData = await tokenResponse.json();
  return tokenData.access_token;
}

/**
 * Refresh OAuth access token using refresh token
 */
async function refreshOAuthToken(
  refreshToken: string,
  clientId: string,
  clientSecret: string
): Promise<string> {
  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });

  if (!tokenResponse.ok) {
    throw new Error(`Token refresh failed: ${await tokenResponse.text()}`);
  }

  const tokens = await tokenResponse.json();
  return tokens.access_token;
}

/**
 * Delete file from Google Drive
 */
async function deleteGoogleDriveFile(fileId: string, accessToken: string): Promise<void> {
  const deleteResponse = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}`,
    {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    }
  );

  if (!deleteResponse.ok && deleteResponse.status !== 404) {
    throw new Error(`Failed to delete file: ${await deleteResponse.text()}`);
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fileIds } = await req.json();
    
    if (!fileIds || !Array.isArray(fileIds) || fileIds.length === 0) {
      throw new Error('File IDs array is required');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get settings from database
    const { data: settingsData, error: settingsError } = await supabase
      .from('google_drive_settings')
      .select('*')
      .single();

    if (settingsError) throw settingsError;
    if (!settingsData?.folder_id) {
      throw new Error('Google Drive folder ID not configured');
    }

    // Get access token based on auth mode
    let accessToken: string;
    
    if (settingsData.auth_mode === 'oauth') {
      console.log('Using OAuth authentication');
      
      // Check if token is expired
      if (settingsData.oauth_token_expiry) {
        const expiryDate = new Date(settingsData.oauth_token_expiry);
        const now = new Date();
        
        if (now >= expiryDate) {
          console.log('OAuth token expired, refreshing...');
          accessToken = await refreshOAuthToken(
            settingsData.oauth_refresh_token,
            settingsData.oauth_client_id,
            settingsData.oauth_client_secret
          );
          
          // Update token in database
          const tokenExpiry = new Date(Date.now() + 3600 * 1000).toISOString();
          await supabase
            .from('google_drive_settings')
            .update({
              oauth_access_token: accessToken,
              oauth_token_expiry: tokenExpiry,
            })
            .eq('id', settingsData.id);
        } else {
          accessToken = settingsData.oauth_access_token;
        }
      } else {
        accessToken = settingsData.oauth_access_token;
      }
    } else {
      console.log('Using Service Account authentication');
      accessToken = await getServiceAccountToken(
        settingsData.client_email,
        settingsData.private_key,
        ['https://www.googleapis.com/auth/drive.file']
      );
    }

    console.log(`Deleting ${fileIds.length} files from Google Drive...`);

    // Delete files
    const deletedFiles = [];
    const failedFiles = [];

    for (const fileId of fileIds) {
      try {
        await deleteGoogleDriveFile(fileId, accessToken);
        deletedFiles.push(fileId);
        console.log(`Deleted file: ${fileId}`);
      } catch (error) {
        console.error(`Failed to delete ${fileId}:`, error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        failedFiles.push({ fileId, error: errorMessage });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Batch delete completed: ${deletedFiles.length} files deleted, ${failedFiles.length} failed`,
        deletedFiles,
        failedFiles,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Batch delete error:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
