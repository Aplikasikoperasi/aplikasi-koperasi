import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { customerId } = await req.json().catch(() => ({ customerId: null }));

    if (!customerId) {
      return new Response(JSON.stringify({ error: "customerId is required" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    // =====================================================
    // SECURITY: Authorization Check
    // =====================================================
    // 1. Extract the user's JWT from the Authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("[customer-detail] No authorization header");
      return new Response(JSON.stringify({ error: "Unauthorized: No token provided" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const token = authHeader.replace("Bearer ", "");
    
    // 2. Create a client with the user's token to verify identity
    const userClient = createClient(supabaseUrl, anonKey, {
      auth: { persistSession: false },
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    // 3. Get the authenticated user
    const { data: { user }, error: userError } = await userClient.auth.getUser(token);
    if (userError || !user) {
      console.error("[customer-detail] Failed to verify user:", userError);
      return new Response(JSON.stringify({ error: "Unauthorized: Invalid token" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // 4. Create service role client for database operations
    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false },
    });

    // 5. Authorization: Check if user is allowed to view this customer's data
    // - Staff (owner, admin, sales, kasir) can view any customer
    // - Customers can only view their own data
    
    // Check if user is staff
    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["owner", "admin", "sales", "kasir"])
      .maybeSingle();

    const isStaff = !!roleData;

    if (!isStaff) {
      // User is not staff, check if they are the customer themselves
      const { data: customerData } = await supabase
        .from("customers")
        .select("id, user_id")
        .eq("id", customerId)
        .single();

      if (!customerData || customerData.user_id !== user.id) {
        console.warn("[customer-detail] Unauthorized access attempt:", {
          userId: user.id,
          requestedCustomerId: customerId,
          actualCustomerUserId: customerData?.user_id
        });
        
        // Log security event
        await supabase.rpc("log_system_event", {
          p_user_id: user.id,
          p_user_name: user.email || "Unknown",
          p_category: "security",
          p_action: "unauthorized_customer_detail_access",
          p_description: `Percobaan akses tidak sah ke data nasabah ${customerId}`,
          p_metadata: { requested_customer_id: customerId }
        });

        return new Response(JSON.stringify({ error: "Forbidden: You can only view your own data" }), {
          status: 403,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }
    }

    console.log("[customer-detail] Authorization passed:", {
      userId: user.id,
      isStaff,
      customerId
    });

    // =====================================================
    // DATA RETRIEVAL (only after authorization passes)
    // =====================================================

    // 2) Credit score breakdown (non-fatal if it fails)
    let creditScoreBreakdown: any = null;
    const { data: breakdownArr, error: breakdownError } = await supabase.rpc(
      "get_customer_credit_score_breakdown",
      { p_customer_id: customerId },
    );

    if (breakdownError) {
      console.error("[customer-detail] Failed to load credit score breakdown:", breakdownError);
    } else {
      creditScoreBreakdown =
        Array.isArray(breakdownArr) && breakdownArr.length > 0 ? breakdownArr[0] : null;
    }

    // 3) Achievement badge (non-fatal if it fails)
    let achievementBadge: any = null;
    const { data: badgeArr, error: badgeError } = await supabase.rpc(
      "get_customer_achievement_badge",
      { p_customer_id: customerId },
    );

    if (badgeError) {
      console.error("[customer-detail] Failed to load achievement badge:", badgeError);
    } else {
      achievementBadge =
        Array.isArray(badgeArr) && badgeArr.length > 0 ? badgeArr[0] : null;
    }


    // 4) Active applications
    const { data: apps, error: appsError } = await supabase
      .from("credit_applications")
      .select(
        "id, application_number, amount_approved, tenor_months, interest_rate, status, application_date, approved_at, disbursed_at, member:members(id, full_name, member_number)",
      )
      .eq("customer_id", customerId)
      .in("status", ["approved", "disbursed"]);

    if (appsError) throw appsError;

    const appIds = (apps ?? []).map((a: any) => a.id as string);

    // Installment progress per application
    let activeApplications: any[] = [];

    if (appIds.length > 0) {
      const { data: installments, error: instError } = await supabase
        .from("installments")
        .select("id, application_id, status")
        .in("application_id", appIds);

      if (instError) throw instError;

      const progressByApp: Record<string, {
        total: number;
        paid: number;
        unpaid: number;
        overdue: number;
        partial: number;
      }> = {};

      for (const appId of appIds) {
        progressByApp[appId] = { total: 0, paid: 0, unpaid: 0, overdue: 0, partial: 0 };
      }

      for (const inst of installments ?? []) {
        const appId = (inst as any).application_id as string;
        const status = (inst as any).status as string;
        const agg = progressByApp[appId] ?? (progressByApp[appId] = {
          total: 0,
          paid: 0,
          unpaid: 0,
          overdue: 0,
          partial: 0,
        });
        agg.total++;
        if (status === "paid") agg.paid++;
        else if (status === "unpaid") agg.unpaid++;
        else if (status === "overdue") agg.overdue++;
        else if (status === "partial") agg.partial++;
      }

      activeApplications = (apps ?? [])
        // Only keep apps that still have unpaid installments
        .filter((app: any) => {
          const prog = progressByApp[app.id];
          return prog && prog.total > 0 && prog.paid < prog.total;
        })
        .map((app: any) => ({
          ...app,
          installment_progress:
            progressByApp[app.id] ?? { total: 0, paid: 0, unpaid: 0, overdue: 0, partial: 0 },
        }));
    }

    // 5) Overdue installments & penalties
    let overdueDetails: any = null;

    if (appIds.length > 0) {
      const { data: overdueRows, error: overdueError } = await supabase
        .from("installments")
        .select(
          "id, installment_number, due_date, total_amount, paid_amount, frozen_penalty, penalty_rate_per_day, status, principal_paid, application:credit_applications(id, customer_id, application_number, amount_approved, penalty_rate_per_day)",
        )
        .eq("status", "overdue")
        .eq("principal_paid", false)
        .in("application_id", appIds);

      if (overdueError) throw overdueError;

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      let totalOverdueAmount = 0;
      let totalPenaltyAmount = 0;
      const overdueInstallments: any[] = [];

      for (const row of overdueRows ?? []) {
        const inst: any = row;
        const due = new Date(inst.due_date);
        due.setHours(0, 0, 0, 0);
        const daysOverdue = Math.max(
          0,
          Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24)),
        );

        const totalAmount = Number(inst.total_amount ?? 0);
        const paidAmount = Number(inst.paid_amount ?? 0);
        const remainingAmount = Math.max(0, totalAmount - paidAmount);

        // Use SNAPSHOT penalty rate (fallback chain: installment -> application -> default 2.0)
        const snapshotPenaltyRate = inst.penalty_rate_per_day || 
                                     inst.application?.penalty_rate_per_day || 
                                     2.0;
        
        let currentPenalty = 0;
        if (daysOverdue > 0 && remainingAmount > 0) {
          const rawPenalty = remainingAmount * (snapshotPenaltyRate / 100) * daysOverdue;
          currentPenalty = Math.ceil(rawPenalty / 1000) * 1000; // round up to nearest 1000
        }

        totalOverdueAmount += remainingAmount;
        totalPenaltyAmount += currentPenalty;

        overdueInstallments.push({
          id: inst.id,
          installment_number: inst.installment_number,
          due_date: inst.due_date,
          total_amount: totalAmount,
          paid_amount: paidAmount,
          remaining_amount: remainingAmount,
          frozen_penalty: inst.frozen_penalty,
          current_penalty: currentPenalty,
          status: inst.status,
          application_number: inst.application?.application_number,
          amount_approved: inst.application?.amount_approved,
          days_overdue: daysOverdue,
        });
      }

      if (totalOverdueAmount > 0) {
        overdueDetails = {
          totalOverdueAmount,
          totalPenaltyAmount,
          overdueInstallments,
        };
      }
    }

    const result = {
      creditScoreBreakdown,
      achievementBadge,
      activeApplications,
      overdueDetails,
    };

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error) {
    console.error("❌ [customer-detail] Error:", error);
    return new Response(JSON.stringify({ error: "Terjadi kesalahan internal" }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
});
