import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const startTime = Date.now();
  console.log('[create-customer-auth] Starting...');

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { customerId, idNumber, dateOfBirth, fullName } = await req.json();

    if (!customerId || !idNumber || !dateOfBirth) {
      throw new Error("Missing required fields: customerId, idNumber, dateOfBirth");
    }

    console.log(`[create-customer-auth] Processing customer: ${customerId}, NIK: ${idNumber}`);

    // NOTE: Validasi NIK duplikat dan blocklist sudah dilakukan di frontend (Customers.tsx)
    // Edge function ini hanya fokus pada pembuatan auth user
    // Jika sampai di sini, berarti NIK sudah divalidasi dan customer sudah tersimpan

    // ============================================================
    // STEP 3: Buat auth user
    // ============================================================
    // Format date of birth as password (DDMMYYYY)
    const dob = new Date(dateOfBirth);
    const day = String(dob.getDate()).padStart(2, '0');
    const month = String(dob.getMonth() + 1).padStart(2, '0');
    const year = dob.getFullYear();
    const password = `${day}${month}${year}`;
    
    // Email derived from unique NIK
    const email = `${idNumber}@customer.local`;

    console.log(`[create-customer-auth] Creating auth user with email: ${email}`);

    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName, is_customer: true },
    });

    let authUserId: string;

    if (createError) {
      // Edge case: email already exists (orphaned auth user from deleted customer)
      if (createError.message?.includes('already been registered') || 
          createError.message?.includes('already exists')) {
        console.log('[create-customer-auth] Email exists, using fallback approach...');
        
        // Use fallback email with timestamp to avoid conflict
        const fallbackEmail = `${idNumber}-${Date.now()}@customer.local`;
        console.log(`[create-customer-auth] Creating with fallback email: ${fallbackEmail}`);
        
        const { data: fallbackUser, error: fallbackError } = await supabaseAdmin.auth.admin.createUser({
          email: fallbackEmail,
          password,
          email_confirm: true,
          user_metadata: { full_name: fullName, is_customer: true },
        });

        if (fallbackError) {
          console.error('[create-customer-auth] Fallback creation failed:', fallbackError.message);
          throw new Error(`Gagal membuat akun: ${fallbackError.message}`);
        }

        authUserId = fallbackUser.user!.id;
        console.log(`[create-customer-auth] Created with fallback email: ${authUserId}`);
      } else {
        console.error('[create-customer-auth] Create user failed:', createError.message);
        throw new Error(`Gagal membuat akun: ${createError.message}`);
      }
    } else {
      authUserId = newUser.user!.id;
      console.log(`[create-customer-auth] New auth user created: ${authUserId}`);
    }

    console.log('[create-customer-auth] Step 3 completed: Auth user ready');

    // ============================================================
    // STEP 4 & 5: Update customer + Insert role (PARALLEL)
    // ============================================================
    console.log('[create-customer-auth] Running Step 4 & 5 in parallel...');

    const [customerResult, roleResult] = await Promise.all([
      // Step 4: Update customers dengan user_id
      supabaseAdmin
        .from('customers')
        .update({ 
          user_id: authUserId, 
          login_email: email 
        })
        .eq('id', customerId),
      
      // Step 5: Insert role 'customer'
      supabaseAdmin
        .from('user_roles')
        .upsert(
          { user_id: authUserId, role: 'customer' },
          { onConflict: 'user_id,role' }
        ),
    ]);

    if (customerResult.error) {
      console.error('[create-customer-auth] Customer update failed:', customerResult.error.message);
      throw new Error(`Gagal update customer: ${customerResult.error.message}`);
    }

    if (roleResult.error) {
      console.error('[create-customer-auth] Role assignment failed:', roleResult.error.message);
      // Non-fatal, but log warning
    }

    console.log('[create-customer-auth] Step 4 & 5 completed');

    const duration = Date.now() - startTime;
    console.log(`[create-customer-auth] SUCCESS in ${duration}ms`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        userId: authUserId,
        email: email,
        message: 'Akun nasabah berhasil dibuat',
        duration: `${duration}ms`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    const duration = Date.now() - startTime;
    const message = error instanceof Error ? error.message : 'An unknown error occurred';
    console.error(`[create-customer-auth] FAILED after ${duration}ms:`, message);
    
    return new Response(
      JSON.stringify({ error: message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  }
});
