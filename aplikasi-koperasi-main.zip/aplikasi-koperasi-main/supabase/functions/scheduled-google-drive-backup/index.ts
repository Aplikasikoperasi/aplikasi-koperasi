import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  try {
    // Check if this is a forced manual backup
    let forceBackup = false;
    try {
      const body = await req.json();
      forceBackup = body?.force === true;
    } catch {
      // No body or invalid JSON
    }

    console.log(`🔄 Starting ${forceBackup ? 'manual' : 'scheduled'} Google Drive backup...`);

    const { data: settings, error: settingsError } = await supabaseClient
      .from('google_drive_settings')
      .select('*')
      .single();

    if (settingsError || !settings) {
      console.error('❌ No Google Drive settings found:', settingsError);
      return new Response(
        JSON.stringify({ success: false, message: 'Google Drive not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (!settings.is_enabled && !forceBackup) {
      console.log('⏭️ Backup is disabled, skipping...');
      return new Response(
        JSON.stringify({ success: false, message: 'Backup is disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    const now = new Date();
    const wibOffset = 7 * 60;
    const wibTime = new Date(now.getTime() + wibOffset * 60 * 1000);
    
    if (!forceBackup) {
      const currentHourWIB = wibTime.getHours();
      const currentMinuteWIB = wibTime.getMinutes();
      const currentTimeWIB = wibTime.toTimeString().substring(0, 5);
      
      console.log(`⏰ Current time (WIB): ${currentTimeWIB}`);
      
      const isWithinBackupWindow = currentHourWIB === 0 || (currentHourWIB === 1 && currentMinuteWIB === 0);
      
      if (!isWithinBackupWindow) {
        console.log(`⏭️ Outside backup window (00:00-01:00 WIB). Current: ${currentTimeWIB}`);
        return new Response(
          JSON.stringify({ success: false, message: 'Outside backup window (00:00-01:00 WIB)' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
        );
      }
      
      if (settings.last_backup_at) {
        const lastBackup = new Date(settings.last_backup_at);
        const lastBackupWIB = new Date(lastBackup.getTime() + wibOffset * 60 * 1000);
        
        const todayDateWIB = wibTime.toISOString().substring(0, 10);
        const lastBackupDateWIB = lastBackupWIB.toISOString().substring(0, 10);
        
        if (todayDateWIB === lastBackupDateWIB) {
          console.log(`⏭️ Backup already done today: ${lastBackupDateWIB}`);
          return new Response(
            JSON.stringify({ success: false, message: 'Backup already completed today' }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
          );
        }
      }

      console.log('✅ Within backup window, starting backup...');
    } else {
      console.log('✅ Force backup requested, starting...');
    }

    // Helper function to fetch ALL data with pagination (no 1000 limit)
    async function fetchAllData(tableName: string) {
      const allData: any[] = [];
      let from = 0;
      const batchSize = 1000;
      
      while (true) {
        const { data, error } = await supabaseClient
          .from(tableName)
          .select("*")
          .range(from, from + batchSize - 1);
        
        if (error) throw error;
        if (!data || data.length === 0) break;
        
        allData.push(...data);
        if (data.length < batchSize) break;
        from += batchSize;
      }
      
      return allData;
    }

    // Fetch ALL data from ALL tables - TRUE UNLIMITED with pagination
    console.log('📊 Fetching data from all tables (with pagination to bypass 1000 limit)...');
    
    const [
      profiles,
      members,
      customers,
      creditApplications,
      installments,
      payments,
      blockedCustomers,
      bankAccounts,
      memberBalanceTransactions,
      memberBalanceWithdrawals,
      memberMonthlySummary,
      customerMessages,
      memberMessages,
      customerChangeRequests,
      restorationRequests,
      whatsappLogs,
      systemLogs,
      appSettings,
      incentiveSettings,
      whatsappSettings,
      whatsappAutoReminder,
      whatsappTemplates,
      googleDriveSettings,
      autoBackupSettings
    ] = await Promise.all([
      fetchAllData('profiles'),
      fetchAllData('members'),
      fetchAllData('customers'),
      fetchAllData('credit_applications'),
      fetchAllData('installments'),
      fetchAllData('payments'),
      fetchAllData('blocked_customers'),
      fetchAllData('bank_accounts'),
      fetchAllData('member_balance_transactions'),
      fetchAllData('member_balance_withdrawals'),
      fetchAllData('member_monthly_balance_summary'),
      fetchAllData('customer_messages'),
      fetchAllData('member_messages'),
      fetchAllData('customer_change_requests'),
      fetchAllData('customer_restoration_requests'),
      fetchAllData('whatsapp_message_logs'),
      fetchAllData('system_logs'),
      fetchAllData('app_settings'),
      fetchAllData('incentive_settings'),
      fetchAllData('whatsapp_settings'),
      fetchAllData('whatsapp_auto_reminder_settings'),
      fetchAllData('whatsapp_message_templates'),
      fetchAllData('google_drive_settings'),
      fetchAllData('auto_backup_settings'),
    ]);

    console.log('✅ Data fetched successfully');

    // Calculate data date range
    const dates: Date[] = [];
    
    customers?.forEach((c: any) => {
      if (c.created_at) dates.push(new Date(c.created_at));
    });
    
    creditApplications?.forEach((a: any) => {
      if (a.application_date) dates.push(new Date(a.application_date));
    });
    
    payments?.forEach((p: any) => {
      if (p.payment_date) dates.push(new Date(p.payment_date));
    });
    
    members?.forEach((m: any) => {
      if (m.created_at) dates.push(new Date(m.created_at));
    });

    const oldestDate = dates.length > 0 ? new Date(Math.min(...dates.map(d => d.getTime()))) : null;
    const newestDate = dates.length > 0 ? new Date(Math.max(...dates.map(d => d.getTime()))) : null;

    const backupData = {
      timestamp: now.toISOString(),
      version: '2.0',
      dataRange: {
        oldestDate: oldestDate ? oldestDate.toISOString() : null,
        newestDate: newestDate ? newestDate.toISOString() : null,
        totalDays: oldestDate && newestDate ? Math.ceil((newestDate.getTime() - oldestDate.getTime()) / (1000 * 60 * 60 * 24)) : 0
      },
      stats: {
        profiles: profiles?.length || 0,
        members: members?.length || 0,
        customers: customers?.length || 0,
        credit_applications: creditApplications?.length || 0,
        installments: installments?.length || 0,
        payments: payments?.length || 0,
        blocked_customers: blockedCustomers?.length || 0,
        bank_accounts: bankAccounts?.length || 0,
        member_balance_transactions: memberBalanceTransactions?.length || 0,
        member_balance_withdrawals: memberBalanceWithdrawals?.length || 0,
        member_monthly_summary: memberMonthlySummary?.length || 0,
        customer_messages: customerMessages?.length || 0,
        member_messages: memberMessages?.length || 0,
        customer_change_requests: customerChangeRequests?.length || 0,
        restoration_requests: restorationRequests?.length || 0,
        whatsapp_logs: whatsappLogs?.length || 0,
        system_logs: systemLogs?.length || 0,
      },
      data: {
        profiles: profiles || [],
        members: members || [],
        customers: customers || [],
        credit_applications: creditApplications || [],
        installments: installments || [],
        payments: payments || [],
        blocked_customers: blockedCustomers || [],
        bank_accounts: bankAccounts || [],
        member_balance_transactions: memberBalanceTransactions || [],
        member_balance_withdrawals: memberBalanceWithdrawals || [],
        member_monthly_balance_summary: memberMonthlySummary || [],
        customer_messages: customerMessages || [],
        member_messages: memberMessages || [],
        customer_change_requests: customerChangeRequests || [],
        customer_restoration_requests: restorationRequests || [],
        whatsapp_message_logs: whatsappLogs || [],
        system_logs: systemLogs || [],
        app_settings: appSettings || [],
        incentive_settings: incentiveSettings || [],
        whatsapp_settings: whatsappSettings || [],
        whatsapp_auto_reminder_settings: whatsappAutoReminder || [],
        whatsapp_message_templates: whatsappTemplates || [],
        google_drive_settings: googleDriveSettings || [],
        auto_backup_settings: autoBackupSettings || [],
      },
    };

    console.log('📊 Backup statistics:', backupData.stats);

    const timestamp = now.toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `backup-${timestamp}.json`;

    console.log('⬆️ Uploading to Google Drive...');
    const { data: uploadData, error: uploadError } = await supabaseClient.functions.invoke(
      'upload-to-google-drive',
      {
        body: {
          backupData,
          filename,
        },
      }
    );

    if (uploadError) {
      console.error('❌ Upload failed:', uploadError);
      throw uploadError;
    }

    console.log('✅ Backup uploaded successfully:', filename);

    // Calculate next backup - Besok jam 00:00 WIB (17:00 UTC)
    const nextBackup = new Date(now);
    nextBackup.setUTCDate(nextBackup.getUTCDate() + 1);
    nextBackup.setUTCHours(17, 0, 0, 0); // 00:00 WIB

    await supabaseClient
      .from('google_drive_settings')
      .update({
        last_backup_at: now.toISOString(),
        next_backup_at: nextBackup.toISOString(),
      })
      .eq('id', settings.id);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Comprehensive backup completed successfully',
        filename,
        stats: backupData.stats,
        next_backup: nextBackup.toISOString(),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Backup error:', error);
    
    // Send notification to admins
    try {
      const { data: adminRoles } = await supabaseClient
        .from('user_roles')
        .select('user_id')
        .in('role', ['owner', 'admin']);

      if (adminRoles && adminRoles.length > 0) {
        const adminUserIds = adminRoles.map((r: any) => r.user_id);
        
        const { data: adminMembers } = await supabaseClient
          .from('members')
          .select('id, user_id, full_name')
          .in('user_id', adminUserIds);

        if (adminMembers && adminMembers.length > 0) {
          const notifications = adminMembers.map((member: any) => ({
            member_id: member.id,
            title: '⚠️ Auto Backup Gagal',
            message: `Auto backup Google Drive gagal dijalankan pada ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB.\n\nError: ${error instanceof Error ? error.message : 'Unknown error'}\n\nSilakan periksa konfigurasi Google Drive dan coba lakukan backup manual.`,
            type: 'error',
            metadata: {
              error_type: 'auto_backup_failure',
              error_message: error instanceof Error ? error.message : 'Unknown error',
              timestamp: new Date().toISOString(),
            },
          }));

          await supabaseClient
            .from('member_messages')
            .insert(notifications);

          console.log(`📧 Sent ${notifications.length} failure notifications`);
        }
      }
    } catch (notifError) {
      console.error('❌ Failed to send notifications:', notifError);
    }
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
