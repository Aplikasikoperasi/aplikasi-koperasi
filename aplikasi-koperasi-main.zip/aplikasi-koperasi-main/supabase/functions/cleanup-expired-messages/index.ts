import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error('Missing environment variables')
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Calculate cutoff date (90 days ago)
    const cutoffDate = new Date()
    cutoffDate.setDate(cutoffDate.getDate() - 90)
    const cutoffDateString = cutoffDate.toISOString()

    console.log(`Cleaning up messages older than: ${cutoffDateString}`)

    // Delete expired member messages (both read and unread)
    const { data: deletedMemberMessages, error: memberError } = await supabase
      .from('member_messages')
      .delete()
      .lt('created_at', cutoffDateString)
      .select('id')

    if (memberError) {
      console.error('Error deleting member messages:', memberError)
      throw memberError
    }

    const memberDateCount = deletedMemberMessages?.length || 0
    console.log(`Deleted ${memberDateCount} expired member messages`)

    // Delete expired customer messages (both read and unread)
    const { data: deletedCustomerMessages, error: customerError } = await supabase
      .from('customer_messages')
      .delete()
      .lt('created_at', cutoffDateString)
      .select('id')

    if (customerError) {
      console.error('Error deleting customer messages:', customerError)
      throw customerError
    }

    const customerDateCount = deletedCustomerMessages?.length || 0
    console.log(`Deleted ${customerDateCount} expired customer messages`)

    // Cleanup messages if exceeding 30 per user (keep only 30 newest)
    console.log('Checking for users with > 30 messages...')

    let memberLimitCount = 0
    let customerLimitCount = 0

    // Get all members with more than 30 messages
    const { data: memberStats } = await supabase
      .rpc('get_member_message_counts')
      .gt('message_count', 30)
    
    if (memberStats) {
      for (const stat of memberStats) {
        // Get messages ordered by date, skip first 30 (newest), delete the rest
        const { data: oldMessages } = await supabase
          .from('member_messages')
          .select('id')
          .eq('member_id', stat.member_id)
          .order('created_at', { ascending: false })
          .range(30, 999)

        if (oldMessages && oldMessages.length > 0) {
          const idsToDelete = oldMessages.map(m => m.id)
          const { error: deleteError } = await supabase
            .from('member_messages')
            .delete()
            .in('id', idsToDelete)

          if (!deleteError) {
            memberLimitCount += oldMessages.length
            console.log(`Deleted ${oldMessages.length} excess messages for member ${stat.member_id}`)
          }
        }
      }
      console.log(`Deleted ${memberLimitCount} member messages due to 30-message limit`)
    }

    // Get all customers with more than 30 messages
    const { data: customerStats } = await supabase
      .rpc('get_customer_message_counts')
      .gt('message_count', 30)
    
    if (customerStats) {
      for (const stat of customerStats) {
        // Get messages ordered by date, skip first 30 (newest), delete the rest
        const { data: oldMessages } = await supabase
          .from('customer_messages')
          .select('id')
          .eq('customer_id', stat.customer_id)
          .order('created_at', { ascending: false })
          .range(30, 999)

        if (oldMessages && oldMessages.length > 0) {
          const idsToDelete = oldMessages.map(m => m.id)
          const { error: deleteError } = await supabase
            .from('customer_messages')
            .delete()
            .in('id', idsToDelete)

          if (!deleteError) {
            customerLimitCount += oldMessages.length
            console.log(`Deleted ${oldMessages.length} excess messages for customer ${stat.customer_id}`)
          }
        }
      }
      console.log(`Deleted ${customerLimitCount} customer messages due to 30-message limit`)
    }

    const result = {
      success: true,
      cutoff_date: cutoffDateString,
      member_messages_deleted_by_date: memberDateCount,
      customer_messages_deleted_by_date: customerDateCount,
      member_messages_deleted_by_limit: memberLimitCount,
      customer_messages_deleted_by_limit: customerLimitCount,
      total_deleted: memberDateCount + customerDateCount + memberLimitCount + customerLimitCount,
      timestamp: new Date().toISOString()
    }

    console.log('Cleanup completed:', result)

    return new Response(
      JSON.stringify(result),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )
  } catch (error) {
    console.error('Error in cleanup-expired-messages:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred'
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        success: false
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})
