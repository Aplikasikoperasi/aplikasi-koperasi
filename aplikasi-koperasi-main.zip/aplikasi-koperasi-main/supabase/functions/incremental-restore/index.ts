import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RestoreReport {
  table: string;
  totalInBackup: number;
  alreadyExists: number;
  inserted: number;
  failed: number;
  errors: Array<{ id: string; error: string }>;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // CRITICAL: Using SERVICE_ROLE_KEY to bypass ALL RLS policies
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!serviceRoleKey) {
      throw new Error('SERVICE_ROLE_KEY not configured - cannot bypass RLS');
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      serviceRoleKey,
      {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
        db: {
          schema: 'public'
        }
      }
    );

    console.log('✅ SERVICE ROLE CLIENT INITIALIZED - RLS POLICIES BYPASSED');

    const requestBody = await req.json();
    let backupData;
    
    // Check if data comes from storage or direct payload
    if (requestBody.useStorage && requestBody.storageFile) {
      console.log('📁 Reading backup from storage:', requestBody.storageFile);
      
      // Download file from storage
      const { data: fileData, error: downloadError } = await supabase.storage
        .from('backups')
        .download(requestBody.storageFile);
      
      if (downloadError) {
        throw new Error(`Failed to download from storage: ${downloadError.message}`);
      }
      
      const fileText = await fileData.text();
      backupData = JSON.parse(fileText);
      console.log('✅ Backup loaded from storage successfully');
    } else {
      // Legacy: direct payload (limited to ~6MB)
      backupData = requestBody.backupData;
      console.log('📦 Processing backup from request payload');
    }
    
    if (!backupData || !backupData.data) {
      throw new Error('Invalid backup data format');
    }

    console.log('📦 Starting incremental restore...');
    console.log('Backup timestamp:', backupData.timestamp);
    
    const reports: RestoreReport[] = [];

    console.log('\n🗑️ STEP 0: Cleaning existing data for applications in backup...');
    if (backupData.data.credit_applications && backupData.data.credit_applications.length > 0) {
      const applicationIds = backupData.data.credit_applications.map((app: any) => app.id);
      console.log(`Found ${applicationIds.length} applications in backup`);
      
      // Delete payments first (foreign key constraint)
      console.log('Deleting existing payments...');
      const { error: paymentsDeleteError } = await supabase
        .from('payments')
        .delete()
        .in('application_id', applicationIds);
      
      if (paymentsDeleteError) {
        console.error('❌ Error deleting payments:', paymentsDeleteError.message);
      } else {
        console.log(`✅ Deleted existing payments for ${applicationIds.length} applications`);
      }
      
      // Then delete installments
      console.log('Deleting existing installments...');
      const { error: installmentsDeleteError } = await supabase
        .from('installments')
        .delete()
        .in('application_id', applicationIds);
      
      if (installmentsDeleteError) {
        console.error('❌ Error deleting installments:', installmentsDeleteError.message);
      } else {
        console.log(`✅ Deleted existing installments for ${applicationIds.length} applications`);
      }
    }

    // Helper function to restore a table incrementally
    async function restoreTableIncremental(
      tableName: string,
      records: any[],
      idField: string = 'id'
    ): Promise<RestoreReport> {
      const report: RestoreReport = {
        table: tableName,
        totalInBackup: records.length,
        alreadyExists: 0,
        inserted: 0,
        failed: 0,
        errors: [],
      };

      if (!records || records.length === 0) {
        console.log(`⚠️ No records found for ${tableName}`);
        return report;
      }

      console.log(`\n📊 Processing ${tableName}: ${records.length} records`);
      console.log(`🔓 RLS BYPASSED - Using service role for ${tableName}`);

      const BATCH_SIZE = 1000; // UNLIMITED: Increased from 100 to 1000 for faster processing
      const totalBatches = Math.ceil(records.length / BATCH_SIZE);

      for (let i = 0; i < records.length; i += BATCH_SIZE) {
        const batch = records.slice(i, i + BATCH_SIZE);
        const batchNum = Math.floor(i / BATCH_SIZE) + 1;

        console.log(
          `🔓 Upserting batch ${batchNum}/${totalBatches} (${batch.length} records) - RLS BYPASSED`
        );

        const { error: batchError } = await supabase
          .from(tableName)
          .upsert(batch, { onConflict: idField });

        if (batchError) {
          console.error(
            `❌ Batch ${batchNum} upsert failed:`,
            batchError.message
          );
          report.failed += batch.length;
          report.errors.push({
            id: `batch_${batchNum}`,
            error: `${batchError.message} | Code: ${batchError.code} | Details: ${batchError.details}`,
          });
        } else {
          console.log(
            `✅ Batch ${batchNum} upserted successfully: ${batch.length} records`
          );
          report.inserted += batch.length;
        }
      }

      console.log(
        `✅ ${tableName}: ${report.inserted} processed from backup, ${report.alreadyExists} skipped, ${report.failed} failed`
      );
      return report;
    }

    // ==========================================
    // TEMPORARILY DISABLED - ONLY RESTORING INSTALLMENTS
    // ==========================================
    // To revert: Remove the comment blocks below to restore all tables
    
    // STEP 1: Restore Members (oldest first by created_at) - DISABLED
    /*
    if (backupData.data.members && backupData.data.members.length > 0) {
      const sortedMembers = [...backupData.data.members].sort((a, b) => {
        const aDate = a.created_at ? new Date(a.created_at).getTime() : 0;
        const bDate = b.created_at ? new Date(b.created_at).getTime() : 0;
        return aDate - bDate;
      });
      const memberReport = await restoreTableIncremental('members', sortedMembers);
      reports.push(memberReport);
    }
    */
    console.log('⏭️ SKIPPING: Members restoration (disabled)');
 
    // STEP 2: Restore Customers (oldest first by created_at) - DISABLED
    /*
    if (backupData.data.customers && backupData.data.customers.length > 0) {
      const sortedCustomers = [...backupData.data.customers].sort((a, b) => {
        const aDate = a.created_at ? new Date(a.created_at).getTime() : 0;
        const bDate = b.created_at ? new Date(b.created_at).getTime() : 0;
        return aDate - bDate;
      });
      const customerReport = await restoreTableIncremental('customers', sortedCustomers);
      reports.push(customerReport);
    }
    */
    console.log('⏭️ SKIPPING: Customers restoration (disabled)');
 
    // STEP 3: Restore Credit Applications (oldest first by application_date) - DISABLED
    /*
    if (backupData.data.credit_applications && backupData.data.credit_applications.length > 0) {
      const sortedApps = [...backupData.data.credit_applications].sort((a, b) => {
        const aDate = a.application_date ? new Date(a.application_date).getTime() : 0;
        const bDate = b.application_date ? new Date(b.application_date).getTime() : 0;
        return aDate - bDate;
      });
      const appReport = await restoreTableIncremental('credit_applications', sortedApps);
      reports.push(appReport);
    }
    */
    console.log('⏭️ SKIPPING: Credit Applications restoration (disabled)');
 
     // STEP 4: Restore Installments (FORCE INSERT with original IDs)
    if (backupData.data.installments && backupData.data.installments.length > 0) {
      console.log('\n💳 STEP 4: Restoring installments with ORIGINAL IDs from backup...');
      console.log(`📊 Total installments in backup: ${backupData.data.installments.length}`);
      console.log(`📊 First 3 installment IDs: ${backupData.data.installments.slice(0, 3).map((i: any) => i.id).join(', ')}`);
      console.log(`📊 Last 3 installment IDs: ${backupData.data.installments.slice(-3).map((i: any) => i.id).join(', ')}`);
      
      const sortedInstallments = [...backupData.data.installments].sort((a, b) => {
        const aDate = a.due_date ? new Date(a.due_date).getTime() : 0;
        const bDate = b.due_date ? new Date(b.due_date).getTime() : 0;
        return aDate - bDate;
      });
      
      console.log(`📊 After sorting: ${sortedInstallments.length} installments ready to insert`);
      
      // Force insert all installments (they were already deleted in STEP 0)
      const installmentReport: RestoreReport = {
        table: 'installments',
        totalInBackup: sortedInstallments.length,
        alreadyExists: 0,
        inserted: 0,
        failed: 0,
        errors: [],
      };
      
      const BATCH_SIZE = 1000; // UNLIMITED: Increased from 100 to 1000 for faster processing
      const totalBatches = Math.ceil(sortedInstallments.length / BATCH_SIZE);
      console.log(`📦 Will process ${totalBatches} batches of ${BATCH_SIZE} records each`);
      console.log(`🚀 UNLIMITED MODE: No restrictions on data volume or file size`);
      
      for (let i = 0; i < sortedInstallments.length; i += BATCH_SIZE) {
        const batch = sortedInstallments.slice(i, i + BATCH_SIZE);
        const batchNum = Math.floor(i / BATCH_SIZE) + 1;
        
        console.log(`🔓 Batch ${batchNum}/${totalBatches}: Processing ${batch.length} installments (range ${i+1} to ${i+batch.length})`);
        
        const { data: insertedData, error: batchError } = await supabase
          .from('installments')
          .insert(batch)
          .select('id');
        
        if (batchError) {
          console.error(`❌ Batch ${batchNum} FAILED:`, batchError.message);
          console.error(`❌ Error code:`, batchError.code);
          console.error(`❌ Error details:`, batchError.details);
          console.error(`❌ First 3 IDs in failed batch:`, batch.slice(0, 3).map(r => r.id));
          installmentReport.failed += batch.length;
          installmentReport.errors.push({
            id: `batch_${batchNum}`,
            error: `${batchError.message} | Code: ${batchError.code}`,
          });
        } else {
          const actualInserted = insertedData?.length || 0;
          console.log(`✅ Batch ${batchNum} SUCCESS: ${actualInserted} records inserted`);
          if (actualInserted !== batch.length) {
            console.warn(`⚠️ WARNING: Expected ${batch.length} but got ${actualInserted} inserted`);
          }
          installmentReport.inserted += actualInserted;
        }
      }
      
      reports.push(installmentReport);
      console.log(`\n📊 FINAL INSTALLMENTS SUMMARY:`);
      console.log(`   Total in backup: ${installmentReport.totalInBackup}`);
      console.log(`   Successfully inserted: ${installmentReport.inserted}`);
      console.log(`   Failed: ${installmentReport.failed}`);
      console.log(`   Errors: ${installmentReport.errors.length}`);
    }
 
    // STEP 5: Restore Payments - DISABLED
    /*
    if (backupData.data.payments && backupData.data.payments.length > 0) {
      console.log('\n💰 STEP 5: Restoring payments - BYPASSING all business logic...');
      console.log(`📊 Total payments in backup: ${backupData.data.payments.length}`);
      
      // CRITICAL: Disable ALL user triggers on payments table to bypass business logic
      console.log('🔒 Disabling ALL triggers on payments table...');
      const { error: disableError } = await supabase.rpc('disable_payments_triggers');
      if (disableError) {
        console.error('❌ Failed to disable triggers:', disableError.message);
        throw new Error(`Cannot proceed with restore: ${disableError.message}`);
      }
      console.log('✅ All triggers disabled - payments will bypass validation');
      
      try {
        const sortedPayments = [...backupData.data.payments].sort((a, b) => {
          const aDate = a.payment_date ? new Date(a.payment_date).getTime() : 0;
          const bDate = b.payment_date ? new Date(b.payment_date).getTime() : 0;
          return aDate - bDate;
        });
        
        console.log(`📊 After sorting: ${sortedPayments.length} payments ready to insert`);
        
        // Force insert all payments (they were already deleted in STEP 0)
        const paymentReport: RestoreReport = {
          table: 'payments',
          totalInBackup: sortedPayments.length,
          alreadyExists: 0,
          inserted: 0,
          failed: 0,
          errors: [],
        };
        
        const BATCH_SIZE = 1000; // UNLIMITED: Increased for maximum processing speed
        const totalBatches = Math.ceil(sortedPayments.length / BATCH_SIZE);
        console.log(`📦 Will process ${totalBatches} batches of ${BATCH_SIZE} records each`);
        console.log(`🚀 UNLIMITED MODE: No restrictions on data volume`);
        
        for (let i = 0; i < sortedPayments.length; i += BATCH_SIZE) {
          const batch = sortedPayments.slice(i, i + BATCH_SIZE);
          const batchNum = Math.floor(i / BATCH_SIZE) + 1;
          
          console.log(`🔓 Batch ${batchNum}/${totalBatches}: Processing ${batch.length} payments (range ${i+1} to ${i+batch.length})`);
          
          const { data: insertedData, error: batchError } = await supabase
            .from('payments')
            .insert(batch)
            .select('id');
          
          if (batchError) {
            console.error(`❌ Batch ${batchNum} FAILED:`, batchError.message);
            console.error(`❌ Error code:`, batchError.code);
            console.error(`❌ Error details:`, batchError.details);
            console.error(`❌ First 3 IDs in failed batch:`, batch.slice(0, 3).map(r => r.id));
            paymentReport.failed += batch.length;
            paymentReport.errors.push({
              id: `batch_${batchNum}`,
              error: `${batchError.message} | Code: ${batchError.code}`,
            });
          } else {
            const actualInserted = insertedData?.length || 0;
            console.log(`✅ Batch ${batchNum} SUCCESS: ${actualInserted} records inserted`);
            if (actualInserted !== batch.length) {
              console.warn(`⚠️ WARNING: Expected ${batch.length} but got ${actualInserted} inserted`);
            }
            paymentReport.inserted += actualInserted;
          }
        }
        
        reports.push(paymentReport);
        console.log(`\n📊 FINAL PAYMENTS SUMMARY:`);
        console.log(`   Total in backup: ${paymentReport.totalInBackup}`);
        console.log(`   Successfully inserted: ${paymentReport.inserted}`);
        console.log(`   Failed: ${paymentReport.failed}`);
        console.log(`   Errors: ${paymentReport.errors.length}`);
      } finally {
        // CRITICAL: ALWAYS re-enable triggers, even if insert failed
        console.log('🔓 Re-enabling ALL triggers on payments table...');
        const { error: enableError } = await supabase.rpc('enable_payments_triggers');
        if (enableError) {
          console.error('❌ CRITICAL: Failed to re-enable triggers:', enableError.message);
          console.error('⚠️ Manual intervention required: Run "ALTER TABLE payments ENABLE TRIGGER USER;" in database');
        } else {
          console.log('✅ All triggers re-enabled - normal operations restored');
        }
      }
    }
    */
    console.log('⏭️ SKIPPING: Payments restoration (disabled)');
 
    // Generate summary
    const summary = {
      totalInserted: reports.reduce((sum, r) => sum + r.inserted, 0),
      totalSkipped: reports.reduce((sum, r) => sum + r.alreadyExists, 0),
      totalFailed: reports.reduce((sum, r) => sum + r.failed, 0),
    };
 
    console.log('\n✅ Incremental restore completed');
    console.log(`Summary: ${summary.totalInserted} inserted, ${summary.totalSkipped} skipped, ${summary.totalFailed} failed`);

    return new Response(
      JSON.stringify({
        success: summary.totalFailed === 0,
        reports,
        summary,
        timestamp: new Date().toISOString(),
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('Error in incremental restore:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
        stack: error.stack,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
