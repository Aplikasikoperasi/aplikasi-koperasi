import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    // Get all customers without user_id and with required fields
    const { data: customers, error: fetchError } = await supabase
      .from('customers')
      .select('id, id_number, date_of_birth, full_name, status')
      .is('user_id', null)
      .eq('status', 'approved')
      .not('id_number', 'is', null)
      .not('date_of_birth', 'is', null);

    if (fetchError) {
      console.error('Error fetching customers:', fetchError);
      throw fetchError;
    }

    if (!customers || customers.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Tidak ada nasabah yang perlu dibuatkan akun',
          created: 0
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${customers.length} customers without auth accounts`);

    let successCount = 0;
    let errorCount = 0;
    const errors: any[] = [];

    // Process each customer
    for (const customer of customers) {
      try {
        // Format email from id_number (N00xxx format)
        const email = `${customer.id_number}@customer.local`;
        
        // Format password from DOB (DDMMYYYY)
        const dob = new Date(customer.date_of_birth);
        const day = String(dob.getDate()).padStart(2, '0');
        const month = String(dob.getMonth() + 1).padStart(2, '0');
        const year = dob.getFullYear();
        const password = `${day}${month}${year}`;

        console.log(`Creating auth for customer: ${customer.full_name} (${email})`);

        // Create auth user
        const { data: authData, error: authError } = await supabase.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: {
            full_name: customer.full_name,
            is_customer: true
          }
        });

        if (authError) {
          console.error(`Auth error for ${customer.full_name}:`, authError);
          
          // If user already exists, try to get their ID
          if (authError.message.includes('already registered')) {
            const { data: existingUsers } = await supabase.auth.admin.listUsers();
            const existingUser = existingUsers?.users?.find(u => u.email === email);
            
            if (existingUser) {
              // Update customer with existing user_id
              await supabase
                .from('customers')
                .update({ user_id: existingUser.id })
                .eq('id', customer.id);
              
              // Ensure profile exists
              await supabase
                .from('profiles')
                .upsert({
                  id: existingUser.id,
                  full_name: customer.full_name,
                  email
                });

              // Ensure customer role exists
              await supabase
                .from('user_roles')
                .upsert({
                  user_id: existingUser.id,
                  role: 'customer'
                }, {
                  onConflict: 'user_id,role'
                });

              successCount++;
              continue;
            }
          }
          
          errorCount++;
          errors.push({
            customer: customer.full_name,
            error: authError.message
          });
          continue;
        }

        if (!authData.user) {
          throw new Error('No user returned from auth creation');
        }

        // Update customer with user_id
        const { error: updateError } = await supabase
          .from('customers')
          .update({ 
            user_id: authData.user.id,
            login_email: email  // Store the login email for reference
          })
          .eq('id', customer.id);

        if (updateError) {
          console.error(`Error updating customer ${customer.full_name}:`, updateError);
          errorCount++;
          errors.push({
            customer: customer.full_name,
            error: updateError.message
          });
          continue;
        }

        // Create profile
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            id: authData.user.id,
            full_name: customer.full_name,
            email
          });

        if (profileError && !profileError.message.includes('duplicate')) {
          console.error(`Error creating profile for ${customer.full_name}:`, profileError);
        }

        // Assign customer role
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({
            user_id: authData.user.id,
            role: 'customer'
          });

        if (roleError && !roleError.message.includes('duplicate')) {
          console.error(`Error assigning role for ${customer.full_name}:`, roleError);
        }

        successCount++;
        console.log(`Successfully created auth for ${customer.full_name}`);

      } catch (error: any) {
        console.error(`Error processing customer ${customer.full_name}:`, error);
        errorCount++;
        errors.push({
          customer: customer.full_name,
          error: error.message
        });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Berhasil membuat ${successCount} akun login`,
        created: successCount,
        failed: errorCount,
        errors: errors.length > 0 ? errors : undefined
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in create-bulk-customer-auth:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});