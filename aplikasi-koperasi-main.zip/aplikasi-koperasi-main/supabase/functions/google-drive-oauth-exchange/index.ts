import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { code, redirectUrl, clientId, clientSecret } = await req.json();
    
    if (!code || !redirectUrl || !clientId || !clientSecret) {
      throw new Error('code, redirectUrl, clientId, and clientSecret are required');
    }

    console.log('Exchanging OAuth code for tokens...');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Exchange code for tokens
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUrl,
        grant_type: 'authorization_code',
      }),
    });

    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      throw new Error(`Token exchange failed: ${errorText}`);
    }

    const tokens = await tokenResponse.json();
    console.log('OAuth tokens obtained successfully');

    // Get user info
    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { 'Authorization': `Bearer ${tokens.access_token}` },
    });

    const userInfo = await userInfoResponse.json();
    console.log('User email:', userInfo.email);

    // Calculate token expiry
    const expiresIn = tokens.expires_in || 3600;
    const tokenExpiry = new Date(Date.now() + expiresIn * 1000).toISOString();

    // Update or create settings
    const { data: existing } = await supabase
      .from('google_drive_settings')
      .select('id')
      .maybeSingle();

    if (existing) {
      const { error } = await supabase
        .from('google_drive_settings')
        .update({
          auth_mode: 'oauth',
          oauth_access_token: tokens.access_token,
          oauth_refresh_token: tokens.refresh_token,
          oauth_token_expiry: tokenExpiry,
          oauth_user_email: userInfo.email,
          oauth_client_id: clientId,
          oauth_client_secret: clientSecret,
        })
        .eq('id', existing.id);

      if (error) throw error;
    } else {
      const { error } = await supabase
        .from('google_drive_settings')
        .insert({
          auth_mode: 'oauth',
          oauth_access_token: tokens.access_token,
          oauth_refresh_token: tokens.refresh_token,
          oauth_token_expiry: tokenExpiry,
          oauth_user_email: userInfo.email,
          oauth_client_id: clientId,
          oauth_client_secret: clientSecret,
          is_enabled: true,
        });

      if (error) throw error;
    }

    return new Response(
      JSON.stringify({
        success: true,
        email: userInfo.email,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('OAuth exchange error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
