import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

/**
 * 🔒 SECURITY FIX: Daily Recalculate and Unblock
 * 
 * Previous issues:
 * - Could be triggered by anyone at any time without password
 * - Should only be triggered by system automatically at 2 AM
 * - Risk: Problematic customers could be unblocked by unauthorized people
 * 
 * Fixed:
 * - Now requires authentication (verify_jwt = true in config.toml)
 * - Only owner can manually trigger (for emergencies)
 * - Intended to be called by cron job (which uses service role)
 * - All operations are logged to audit trail
 * - Added security header check for cron jobs
 */

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    // Check if this is a cron job request (has special header)
    const cronHeader = req.headers.get('x-supabase-cron');
    const isCronJob = cronHeader !== null;

    let userId: string | null = null;
    let userEmail: string | null = null;

    // If not a cron job, require authentication
    if (!isCronJob) {
      const authHeader = req.headers.get("authorization");
      if (!authHeader) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: "Authentication required. This function should only be called by cron job or owner." 
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 401 }
        );
      }

      // Create client with user's JWT for authentication check
      const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            authorization: authHeader,
          },
        },
      });

      // Verify user is authenticated and get their role
      const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
      
      if (authError || !user) {
        console.error("Authentication failed:", authError);
        return new Response(
          JSON.stringify({ success: false, error: "Invalid authentication" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 401 }
        );
      }

      // Check if user has owner role (ONLY OWNER can manually trigger)
      const { data: roleData, error: roleError } = await supabaseClient
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      if (roleError || !roleData || roleData.role !== "owner") {
        console.error("Authorization failed - user is not owner");
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: "Insufficient permissions. Only owner can manually trigger this function." 
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 403 }
        );
      }

      userId = user.id;
      userEmail = user.email || "Unknown";
      console.log('⚠️ Manual trigger by owner:', userEmail);
    } else {
      console.log('🤖 Triggered by cron job (automated)');
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('[daily-recalculate-and-unblock] Starting full credit score recalculation using formula: 1 + ((total - telat - menunggak) / total) * 4');

    // Get threshold from settings
    const { data: settingsData } = await supabase
      .from('app_settings')
      .select('auto_block_threshold')
      .single();
    
    const threshold = settingsData?.auto_block_threshold || 3.7;
    console.log(`[daily-recalculate-and-unblock] Using auto-block threshold: ${threshold}`);

    // Step 1: Recalculate all credit scores with new formula
    const { error: updateError } = await supabase.rpc('recalculate_all_customer_credit_scores');

    if (updateError) {
      console.error('[daily-recalculate-and-unblock] Error recalculating credit scores:', updateError);
      throw updateError;
    }

    console.log('[daily-recalculate-and-unblock] Successfully recalculated all credit scores');

    // Step 2: Auto-unblock customers with credit score > threshold
    const { data: blockedCustomers, error: fetchError } = await supabase
      .from('blocked_customers')
      .select('customer_id, customers!inner(full_name, id_number, credit_score)')
      .eq('is_auto_block', true);

    if (fetchError) {
      console.error('[daily-recalculate-and-unblock] Error fetching blocked customers:', fetchError);
      throw fetchError;
    }

    const customersToUnblock = blockedCustomers?.filter(
      bc => (bc.customers as any).credit_score > threshold
    ) || [];

    console.log(`[daily-recalculate-and-unblock] Found ${customersToUnblock.length} customers to unblock`);

    // Unblock eligible customers
    const unblockResults = [];
    for (const bc of customersToUnblock) {
      const customer = bc.customers as any;
      console.log(`[daily-recalculate-and-unblock] Unblocking ${customer.full_name} (${customer.id_number}) - Credit Score: ${customer.credit_score}`);

      const { error: deleteError } = await supabase
        .from('blocked_customers')
        .delete()
        .eq('customer_id', bc.customer_id)
        .eq('is_auto_block', true);

      if (deleteError) {
        console.error(`[daily-recalculate-and-unblock] Error unblocking ${customer.full_name}:`, deleteError);
        unblockResults.push({
          customer: customer.full_name,
          success: false,
          error: deleteError.message
        });
      } else {
        // ✅ Auto-approve pending restoration requests
        const { data: approvedRequest } = await supabase
          .from('customer_restoration_requests')
          .update({
            status: 'approved',
            reviewed_at: new Date().toISOString(),
            reviewed_by: null,
            notes: `Auto-approved: Customer dipulihkan otomatis (skor > ${threshold} via ${isCronJob ? 'cron job' : 'manual trigger'})`
          })
          .eq('customer_id', bc.customer_id)
          .eq('status', 'pending')
          .select('id')
          .single();

        // Log system event with proper attribution
        await supabase.rpc('log_system_event', {
          p_user_id: userId,
          p_user_name: isCronJob ? 'System (Cron Job)' : userEmail,
          p_category: 'blocking',
          p_action: 'auto_unblock',
          p_description: `Auto-unblock ${customer.full_name} - Credit score naik ke ${customer.credit_score} (threshold > ${threshold})`,
          p_metadata: {
            customer_id: bc.customer_id,
            customer_name: customer.full_name,
            id_number: customer.id_number,
            credit_score: customer.credit_score,
            unblock_reason: 'credit_score_improved',
            threshold: threshold,
            restoration_request_approved: !!approvedRequest,
            triggered_by: isCronJob ? 'cron_job' : 'manual',
            triggered_by_user: userEmail
          }
        });

        console.log(`[daily-recalculate-and-unblock] Restoration request auto-approved: ${!!approvedRequest}`);

        unblockResults.push({
          customer: customer.full_name,
          success: true,
          credit_score: customer.credit_score,
          restoration_request_approved: !!approvedRequest
        });
      }
    }

    // Log overall operation
    await supabase.rpc('log_system_event', {
      p_user_id: userId,
      p_user_name: isCronJob ? 'System (Cron Job)' : userEmail,
      p_category: 'security',
      p_action: 'daily_recalculate_and_unblock',
      p_description: `Recalculate semua credit score dan auto-unblock (${customersToUnblock.length} nasabah)`,
      p_metadata: {
        threshold: threshold,
        customers_unblocked: unblockResults.filter(r => r.success).length,
        triggered_by: isCronJob ? 'cron_job' : 'manual',
        triggered_by_user: userEmail,
        timestamp: new Date().toISOString()
      }
    });

    console.log('[daily-recalculate-and-unblock] Completed successfully');

    return new Response(
      JSON.stringify({
        success: true,
        message: `Credit score recalculation and auto-unblock completed. Formula: 1 + ((total - telat - menunggak) / total) * 4. Threshold: skor > ${threshold}`,
        unblocked: unblockResults.filter(r => r.success).length,
        unblock_results: unblockResults,
        triggered_by: isCronJob ? 'cron_job' : 'manual',
        triggered_by_user: isCronJob ? 'System' : userEmail,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200
      }
    );
  } catch (err) {
    console.error('[daily-recalculate-and-unblock] Fatal error:', err);
    const message = err instanceof Error ? err.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({
        success: false,
        error: message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});
