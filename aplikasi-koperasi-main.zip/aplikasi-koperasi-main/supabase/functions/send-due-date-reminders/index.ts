import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('[send-due-date-reminders] Starting due date reminders...');

    // Check if WhatsApp is enabled
    const { data: settings } = await supabase
      .from('whatsapp_settings')
      .select('is_enabled')
      .maybeSingle();

    if (!settings?.is_enabled) {
      console.log('[send-due-date-reminders] WhatsApp not enabled, skipping');
      return new Response(
        JSON.stringify({ success: true, message: 'WhatsApp not enabled', sent: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Calculate dates
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const threeDaysFromNow = new Date(today);
    threeDaysFromNow.setDate(today.getDate() + 3);

    // Get installments due today and in 3 days
    const { data: upcomingInstallments, error: installmentsError } = await supabase
      .from('installments')
      .select(`
        *,
        credit_applications!inner(
          id,
          application_number,
          customer_id,
          customers!inner(
            id,
            full_name,
            phone,
            id_number,
            credit_score
          )
        )
      `)
      .in('status', ['unpaid', 'partial'])
      .eq('principal_paid', false)
      .in('credit_applications.status', ['approved', 'disbursed'])
      .or(`due_date.eq.${today.toISOString().split('T')[0]},due_date.eq.${threeDaysFromNow.toISOString().split('T')[0]}`);

    if (installmentsError) {
      throw installmentsError;
    }

    if (!upcomingInstallments || upcomingInstallments.length === 0) {
      console.log('[send-due-date-reminders] No upcoming installments found');
      return new Response(
        JSON.stringify({ success: true, message: 'No upcoming installments', sent: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Get primary bank account info
    const { data: bankAccount } = await supabase
      .from('bank_accounts')
      .select('bank_name, account_number, account_holder')
      .eq('is_primary', true)
      .eq('is_active', true)
      .maybeSingle();

    let sentCount = 0;
    const errors: string[] = [];

    // Send reminders
    for (const installment of upcomingInstallments) {
      try {
        const customer = (installment.credit_applications as any).customers;
        const application = installment.credit_applications as any;
        
        if (!customer?.phone) {
          console.log(`[send-due-date-reminders] No phone for customer ${customer?.id}`);
          continue;
        }

        const dueDate = new Date(installment.due_date);
        const isDueToday = dueDate.toDateString() === today.toDateString();
        const remaining = installment.total_amount - installment.paid_amount;

        // Format message based on timing
        let message = '';
        
        if (isDueToday) {
          message = `📅 *JATUH TEMPO HARI INI*

Kepada Yth. ${customer.full_name}
ID: ${customer.id_number}

Angsuran Anda jatuh tempo *HARI INI*:

📋 *Detail Angsuran:*
• Angsuran ke-${installment.installment_number}
• No. Aplikasi: ${application.application_number}
• Jatuh Tempo: *${dueDate.toLocaleDateString('id-ID')}*

💰 *Detail Pembayaran:*
• Total Angsuran: Rp ${installment.total_amount.toLocaleString('id-ID')}
• Sudah Dibayar: Rp ${installment.paid_amount.toLocaleString('id-ID')}
• *Sisa Tagihan: Rp ${remaining.toLocaleString('id-ID')}*

⭐ Skor Kredit Anda: ${customer.credit_score}/5

✅ Bayar tepat waktu untuk menjaga skor kredit Anda!`;

          // Add bank account information if available
          if (bankAccount?.bank_name) {
            message += `

━━━━━━━━━━━━━━━━━
🏦 *INFORMASI PEMBAYARAN*

Transfer ke rekening:
• Bank: *${bankAccount.bank_name}*
• No. Rekening: *${bankAccount.account_number}*
• Atas Nama: *${bankAccount.account_holder}*
━━━━━━━━━━━━━━━━━`;
          }

          message += `

Hubungi kami untuk melakukan pembayaran.`;
        } else {
          message = `⏰ *PENGINGAT JATUH TEMPO*

Kepada Yth. ${customer.full_name}
ID: ${customer.id_number}

Angsuran Anda akan jatuh tempo *3 HARI LAGI*:

📋 *Detail Angsuran:*
• Angsuran ke-${installment.installment_number}
• No. Aplikasi: ${application.application_number}
• Jatuh Tempo: *${dueDate.toLocaleDateString('id-ID')}*

💰 *Detail Pembayaran:*
• Total Angsuran: Rp ${installment.total_amount.toLocaleString('id-ID')}
• Sudah Dibayar: Rp ${installment.paid_amount.toLocaleString('id-ID')}
• *Sisa Tagihan: Rp ${remaining.toLocaleString('id-ID')}*

⭐ Skor Kredit Anda: ${customer.credit_score}/5

💡 Siapkan pembayaran Anda untuk menghindari denda keterlambatan.`;

          // Add bank account information if available
          if (bankAccount?.bank_name) {
            message += `

━━━━━━━━━━━━━━━━━
🏦 *INFORMASI PEMBAYARAN*

Transfer ke rekening:
• Bank: *${bankAccount.bank_name}*
• No. Rekening: *${bankAccount.account_number}*
• Atas Nama: *${bankAccount.account_holder}*
━━━━━━━━━━━━━━━━━`;
          }

          message += `

Hubungi kami untuk informasi lebih lanjut.`;
        }

        // Send via WhatsApp
        const { error: sendError } = await supabase.functions.invoke('send-whatsapp-message', {
          body: {
            phone_number: customer.phone,
            message: message
          }
        });

        if (sendError) {
          console.error(`[send-due-date-reminders] Failed to send to ${customer.id}:`, sendError);
          errors.push(`${customer.full_name}: ${sendError.message}`);
          
          // Log failed message
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_due',
            message_content: message,
            status: 'failed',
            error_message: sendError.message
          });
        } else {
          sentCount++;
          console.log(`[send-due-date-reminders] Sent ${isDueToday ? 'due-today' : 'H-3'} reminder to ${customer.full_name}`);
          
          // Log successful message
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_due',
            message_content: message,
            status: 'sent',
            sent_at: new Date().toISOString()
          });
        }

        // Small delay to avoid rate limiting (2 seconds for safety)
        await new Promise(resolve => setTimeout(resolve, 2000));

      } catch (error) {
        console.error('[send-due-date-reminders] Error processing installment:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        errors.push(`Installment ${installment.id}: ${errorMessage}`);
      }
    }

    console.log(`[send-due-date-reminders] Completed. Sent: ${sentCount}, Errors: ${errors.length}`);

    return new Response(
      JSON.stringify({
        success: true,
        sent: sentCount,
        total: upcomingInstallments.length,
        errors: errors
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('[send-due-date-reminders] Fatal error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
