import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Listing Google Drive backups...');

    // Get Google Drive settings
    const { data: settings, error: settingsError } = await supabase
      .from('google_drive_settings')
      .select('*')
      .maybeSingle();

    if (settingsError) {
      throw new Error(`Failed to fetch settings: ${settingsError.message}`);
    }

    if (!settings || !settings.folder_id) {
      return new Response(
        JSON.stringify({ files: [], error: 'Google Drive not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check auth mode and get access token
    const authMode = settings.auth_mode || 'service_account';
    let access_token: string;

    if (authMode === 'oauth') {
      // OAuth mode
      console.log('Using OAuth authentication');
      
      if (!settings.oauth_access_token || !settings.oauth_refresh_token) {
        return new Response(
          JSON.stringify({ files: [], error: 'OAuth not authenticated' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if token expired
      const tokenExpiry = settings.oauth_token_expiry ? new Date(settings.oauth_token_expiry) : null;
      const now = new Date();

      if (!tokenExpiry || now >= tokenExpiry) {
        console.log('OAuth token expired, refreshing...');
        
        // Refresh token
        const { data: refreshData, error: refreshError } = await supabase.functions.invoke(
          'google-drive-refresh-token'
        );

        if (refreshError || !refreshData?.success) {
          return new Response(
            JSON.stringify({ files: [], error: 'Failed to refresh token' }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Reload settings to get new token
        const { data: newSettings } = await supabase
          .from('google_drive_settings')
          .select('oauth_access_token')
          .maybeSingle();

        access_token = newSettings?.oauth_access_token || '';
      } else {
        access_token = settings.oauth_access_token;
      }

    } else {
      // Service account mode
      console.log('Using service account authentication');
      
      if (!settings.client_email || !settings.private_key) {
        return new Response(
          JSON.stringify({ files: [], error: 'Service account not configured' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create JWT for Google OAuth2
      const now = Math.floor(Date.now() / 1000);
      const jwtHeader = btoa(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
      const jwtClaim = btoa(JSON.stringify({
        iss: settings.client_email,
        scope: 'https://www.googleapis.com/auth/drive.readonly',
        aud: 'https://oauth2.googleapis.com/token',
        exp: now + 3600,
        iat: now,
      }));

      const jwtData = `${jwtHeader}.${jwtClaim}`;
      
      // Extract private key properly
      let privateKeyStr = settings.private_key;
      
      if (typeof privateKeyStr === 'string' && privateKeyStr.trim().startsWith('{')) {
        try {
          const keyJson = JSON.parse(privateKeyStr);
          privateKeyStr = keyJson.private_key;
          console.log('Extracted private key from JSON object');
        } catch (e) {
          console.error('Failed to parse private_key JSON:', e);
          throw new Error('Invalid private key format - cannot parse JSON');
        }
      }
      
      if (!privateKeyStr || !privateKeyStr.includes('BEGIN PRIVATE KEY')) {
        throw new Error('Invalid private key - missing BEGIN PRIVATE KEY marker');
      }
      
      const privateKey = privateKeyStr.replace(/\\n/g, '\n');
      
      const pemHeader = '-----BEGIN PRIVATE KEY-----';
      const pemFooter = '-----END PRIVATE KEY-----';
      const pemContents = privateKey
        .replace(pemHeader, '')
        .replace(pemFooter, '')
        .replace(/\s/g, '');
      
      const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
      
      const cryptoKey = await crypto.subtle.importKey(
        'pkcs8',
        binaryDer,
        { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
        false,
        ['sign']
      );

      const encoder = new TextEncoder();
      const signature = await crypto.subtle.sign(
        'RSASSA-PKCS1-v1_5',
        cryptoKey,
        encoder.encode(jwtData)
      );

      const jwtSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');

      const jwt = `${jwtData}.${jwtSignature}`;

      // Exchange JWT for access token
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
      });

      if (!tokenResponse.ok) {
        throw new Error('Failed to get access token');
      }

      const tokenData = await tokenResponse.json();
      access_token = tokenData.access_token;
    }

    // List files in folder
    const rawFolder = settings.folder_id as string;
    const folderId = (() => {
      if (!rawFolder) return '';
      try {
        const m = rawFolder.match(/\/folders\/([a-zA-Z0-9_-]+)/);
        if (m && m[1]) return m[1];
        if (rawFolder.startsWith('http')) {
          const u = new URL(rawFolder);
          const id = u.searchParams.get('id');
          if (id) return id;
        }
      } catch (_) { /* ignore */ }
      return rawFolder.trim();
    })();

    if (!folderId || folderId.includes('http')) {
      throw new Error('Invalid Google Drive folder ID');
    }

    const listUrl = `https://www.googleapis.com/drive/v3/files?q='${folderId}'+in+parents+and+trashed=false&orderBy=createdTime desc&fields=files(id,name,createdTime,size,mimeType)&supportsAllDrives=true&includeItemsFromAllDrives=true`;
    
    const listResponse = await fetch(listUrl, {
      headers: { 'Authorization': `Bearer ${access_token}` },
    });

    if (!listResponse.ok) {
      throw new Error('Failed to list files from Google Drive');
    }

    const listData = await listResponse.json();
    
    // Filter only backup JSON files
    const backupFiles = (listData.files || [])
      .filter((file: any) => (
        (file.name.startsWith('backup-') || file.name.startsWith('scheduled-backup-')) &&
        file.name.endsWith('.json')
      ))
      .map((file: any) => ({
        id: file.id,
        name: file.name,
        created_at: file.createdTime,
        size: parseInt(file.size || '0'),
        mimeType: file.mimeType,
      }));

    console.log(`Found ${backupFiles.length} backup files`);

    return new Response(
      JSON.stringify({ files: backupFiles }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('List backups error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ files: [], error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
