import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface IncentiveRequest {
  type: 'credit_application' | 'installment_payment' | 'holiday';
  application_id?: string;
  payment_id?: string;
  installment_id?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { type, application_id, payment_id, installment_id }: IncentiveRequest = await req.json();

    console.log('Processing incentive:', { type, application_id, payment_id });

    // Fetch the correct member_id from credit application
    let member_id: string | null = null;
    
    if ((type === 'credit_application' || type === 'installment_payment' || type === 'holiday') && application_id) {
      const { data: app } = await supabaseClient
        .from('credit_applications')
        .select('member_id')
        .eq('id', application_id)
        .single();
      member_id = app?.member_id || null;
    }

    if (!member_id) {
      console.error('Member ID not found for application:', application_id);
      return new Response(
        JSON.stringify({ error: 'Member ID not found for this application' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Incentive will be given to member:', member_id);

    // CRITICAL: Check if member is sales (not admin or owner) and is active
    const { data: member, error: memberError } = await supabaseClient
      .from('members')
      .select('user_id, position, is_active')
      .eq('id', member_id)
      .single();

    if (memberError || !member) {
      console.error('Failed to fetch member:', memberError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch member information' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // CRITICAL: Skip incentive for inactive members (freeze period)
    if (!member.is_active) {
      console.log('Incentive skipped: member is inactive (freeze period)');
      return new Response(
        JSON.stringify({ message: 'Incentive skipped for inactive member' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check user role - only sales get incentives
    const { data: userRole, error: roleError } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', member.user_id)
      .single();

    if (roleError || !userRole) {
      console.error('Failed to fetch user role:', roleError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch user role' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Only sales role gets incentives
    if (userRole.role !== 'sales') {
      console.log('Incentive skipped: member is not sales role, role:', userRole.role);
      return new Response(
        JSON.stringify({ message: 'Incentive only applies to sales members' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get incentive settings
    const { data: settings, error: settingsError } = await supabaseClient
      .from('incentive_settings')
      .select('*')
      .single();

    if (settingsError) {
      console.error('Error fetching settings:', settingsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch incentive settings' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!settings || !settings.is_enabled) {
      console.log('Incentive system is disabled');
      return new Response(
        JSON.stringify({ message: 'Incentive system is disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let amount = 0;
    let description = '';

    // Determine incentive amount and description based on type
    if (type === 'holiday') {
      if (!settings.holiday_enabled) {
        console.log('Year-end bonus incentive is disabled');
        return new Response(
          JSON.stringify({ message: 'Year-end bonus incentive is disabled' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // If called with payment_id, calculate from this specific payment (auto-accumulation)
      if (payment_id) {
        const { data: payment } = await supabaseClient
          .from('payments')
          .select('amount')
          .eq('id', payment_id)
          .single();

        if (settings.holiday_type === 'percentage') {
          const percentage = Number(settings.holiday_amount || 0);
          const paymentAmount = Number(payment?.amount || 0);
          amount = (paymentAmount * percentage) / 100;
        } else {
          amount = Number(settings.holiday_amount || 0);
        }
        
        description = `Akumulasi Bonus Akhir Tahun dari pembayaran angsuran`;
      } else {
        // Manual year-end bonus calculation (for manual disbursement)
        const currentYear = new Date().getFullYear();
        const yearStart = `${currentYear}-01-01`;
        const yearEnd = `${currentYear}-12-01`;

        const { data: yearlyPayments, error: paymentsError } = await supabaseClient
          .from('payments')
          .select(`
            amount,
            application_id,
            credit_applications!inner(member_id)
          `)
          .eq('credit_applications.member_id', member_id)
          .gte('payment_date', yearStart)
          .lte('payment_date', yearEnd);

        if (paymentsError) {
          console.error('Error fetching yearly payments:', paymentsError);
          return new Response(
            JSON.stringify({ error: 'Failed to fetch yearly payments' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const totalPayments = yearlyPayments?.reduce((sum, payment) => sum + Number(payment.amount || 0), 0) || 0;

        if (settings.holiday_type === 'percentage') {
          const percentage = Number(settings.holiday_amount || 0);
          amount = (totalPayments * percentage) / 100;
        } else {
          amount = Number(settings.holiday_amount || 0);
        }
        
        description = `Insentif Bonus Akhir Tahun ${currentYear} - Total pembayaran: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalPayments)}`;
      }
    } else if (type === 'credit_application') {
      if (!settings.credit_application_enabled) {
        console.log('Credit application incentive is disabled');
        return new Response(
          JSON.stringify({ message: 'Credit application incentive is disabled' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get application details with customer info
      const { data: app } = await supabaseClient
        .from('credit_applications')
        .select('application_number, amount_approved, customers:customer_id(full_name)')
        .eq('id', application_id)
        .single();

      const approvedAmount = Number(app?.amount_approved || 0);
      const formattedApproved = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(approvedAmount);

      // Calculate amount based on type (fixed or percentage)
      if (settings.credit_application_type === 'percentage') {
        const percentage = Number(settings.credit_application_amount || 0);
        amount = (approvedAmount * percentage) / 100;
      } else {
        amount = Number(settings.credit_application_amount || 0);
      }
      
      description = `Insentif kredit ${app?.application_number || ''} (${formattedApproved})`;
    } else if (type === 'installment_payment') {
      if (!settings.installment_payment_enabled) {
        console.log('Installment payment incentive is disabled');
        return new Response(
          JSON.stringify({ message: 'Installment payment incentive is disabled' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get payment details with installment info
      const { data: payment } = await supabaseClient
        .from('payments')
        .select(`
          amount,
          installments:installment_id(
            installment_number,
            principal_paid,
            credit_applications:application_id(
              application_number
            )
          )
        `)
        .eq('id', payment_id)
        .single();

      const paymentAmount = Number(payment?.amount || 0);
      const installmentData = payment?.installments as any;
      const appData = installmentData?.credit_applications;
      const appNumber = appData?.application_number || '';
      const installmentNumber = installmentData?.installment_number || '';
      const principalPaid = installmentData?.principal_paid || false;
      const formattedPayment = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(paymentAmount);

      // Calculate amount based on type (fixed or percentage)
      if (settings.installment_payment_type === 'percentage') {
        const percentage = Number(settings.installment_payment_amount || 0);
        amount = (paymentAmount * percentage) / 100;
      } else {
        amount = Number(settings.installment_payment_amount || 0);
      }
      
      // Different description for penalty-only payment (when principal already paid)
      if (principalPaid) {
        description = `Insentif pelunasan denda angsuran ke-${installmentNumber} ${appNumber} (${formattedPayment})`;
      } else {
        description = `Insentif angsuran ke-${installmentNumber} ${appNumber} (${formattedPayment})`;
      }
    }

    if (amount <= 0) {
      console.log('Incentive amount is zero or negative');
      return new Response(
        JSON.stringify({ message: 'Incentive amount is invalid' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get payment_date to determine period_month (YYYY-MM format)
    let periodMonth: string;
    let paymentDate: Date;
    
    if (payment_id) {
      // Use payment_date from payment record
      const { data: payment } = await supabaseClient
        .from('payments')
        .select('payment_date')
        .eq('id', payment_id)
        .single();
      
      if (!payment?.payment_date) {
        console.error('Payment date not found for payment:', payment_id);
        return new Response(
          JSON.stringify({ error: 'Payment date not found' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      paymentDate = new Date(payment.payment_date);
      periodMonth = `${paymentDate.getFullYear()}-${String(paymentDate.getMonth() + 1).padStart(2, '0')}`;
    } else {
      // For credit_application type, use current date
      paymentDate = new Date();
      periodMonth = `${paymentDate.getFullYear()}-${String(paymentDate.getMonth() + 1).padStart(2, '0')}`;
    }

    // Determine balance type (year_end_bonus for holiday, regular for others)
    let balanceType = type === 'holiday' ? 'year_end_bonus' : 'regular';

    // CRITICAL: For year-end bonus (holiday type), check if payment date is after December 1st cutoff
    // Year-end bonus should only accumulate for payments from Jan 1 to Dec 1
    // Payments after Dec 1 should fall back to regular bonus if enabled
    if (type === 'holiday') {
      const paymentYear = paymentDate.getFullYear();
      const cutoffDate = new Date(`${paymentYear}-12-01T23:59:59`);
      
      if (paymentDate > cutoffDate) {
        console.log('Year-end bonus cutoff reached: payment date is after December 1st', {
          paymentDate: paymentDate.toISOString(),
          cutoffDate: cutoffDate.toISOString()
        });
        
        // FALLBACK: If regular incentive is enabled, record as regular bonus instead
        if (settings.installment_payment_enabled) {
          console.log('Falling back to regular bonus for payment after Dec 1st cutoff');
          balanceType = 'regular';
          // Update description to reflect regular bonus
          description = description.replace('Bonus Akhir Tahun', 'Insentif pembayaran');
        } else {
          // Neither year-end bonus nor regular bonus applicable
          console.log('Both year-end bonus (cutoff) and regular bonus (disabled) not applicable');
          return new Response(
            JSON.stringify({ 
              message: 'Payment after Dec 1st cutoff and regular incentive is disabled',
              payment_date: paymentDate.toISOString(),
              cutoff_date: cutoffDate.toISOString()
            }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    }

    // Check if payment_date is before incentive activation date
    // Only count payments after the system was activated
    let activationDate: Date | null = null;
    
    if (balanceType === 'regular') {
      // For regular balance, use regular_incentive_enabled_at
      if (settings.regular_incentive_enabled_at) {
        activationDate = new Date(settings.regular_incentive_enabled_at);
      }
    } else if (balanceType === 'year_end_bonus') {
      // For year-end bonus, use year_end_bonus_enabled_at
      if (settings.year_end_bonus_enabled_at) {
        activationDate = new Date(settings.year_end_bonus_enabled_at);
      }
    }

    // If activation date exists and payment is before activation, skip
    if (activationDate && paymentDate < activationDate) {
      console.log('Incentive skipped: payment date is before system activation', {
        paymentDate: paymentDate.toISOString(),
        activationDate: activationDate.toISOString()
      });
      return new Response(
        JSON.stringify({ 
          message: 'Incentive not applicable for historical payments before system activation',
          payment_date: paymentDate.toISOString(),
          activation_date: activationDate.toISOString()
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Processing incentive for period:', periodMonth, 'payment_date:', paymentDate.toISOString());

    // Create transaction record with period_month based on payment_date
    const { data: transaction, error: transactionError } = await supabaseClient
      .from('member_balance_transactions')
      .insert({
        member_id,
        amount,
        type,
        description,
        balance_type: balanceType,
        application_id: application_id || null,
        payment_id: payment_id || null,
        installment_id: installment_id || null,
        period_month: periodMonth,
      })
      .select()
      .single();

    if (transactionError) {
      console.error('Error creating transaction:', transactionError);
      return new Response(
        JSON.stringify({ error: 'Failed to create transaction' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Incentive processed successfully:', transaction);

    // Update monthly balance summary for regular balance
    if (balanceType === 'regular') {
      // Check if summary exists for this period
      const { data: existingSummary } = await supabaseClient
        .from('member_monthly_balance_summary')
        .select('*')
        .eq('member_id', member_id)
        .eq('period_month', periodMonth)
        .maybeSingle();

      if (existingSummary) {
        // Update existing summary
        await supabaseClient
          .from('member_monthly_balance_summary')
          .update({
            total_earned: Number(existingSummary.total_earned) + amount,
            available_balance: Number(existingSummary.available_balance) + amount,
            updated_at: paymentDate.toISOString()
          })
          .eq('member_id', member_id)
          .eq('period_month', periodMonth);
      } else {
        // Create new summary
        await supabaseClient
          .from('member_monthly_balance_summary')
          .insert({
            member_id: member_id,
            period_month: periodMonth,
            total_earned: amount,
            total_withdrawn: 0,
            available_balance: amount,
            is_held: false,
            hold_reason: null
          });
      }

      console.log('Monthly balance summary updated for period:', periodMonth);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Incentive processed successfully',
        transaction 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in process-incentive function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
