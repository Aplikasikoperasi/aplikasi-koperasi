import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('[run-auto-reminders] Starting auto-reminder check...');

    // Get auto-reminder settings
    const { data: settings, error: settingsError } = await supabase
      .from('whatsapp_auto_reminder_settings')
      .select('*')
      .maybeSingle();

    if (settingsError) {
      console.error('[run-auto-reminders] Settings error:', settingsError);
      throw settingsError;
    }

    if (!settings || !settings.is_enabled) {
      console.log('[run-auto-reminders] Auto-reminder is disabled');
      return new Response(
        JSON.stringify({ success: true, message: 'Auto-reminder is disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    const results: any = {
      overdue: null,
      dueDate: null,
    };

    // Send overdue reminders if enabled
    if (settings.overdue_reminder_enabled) {
      console.log('[run-auto-reminders] Invoking send-daily-overdue-reminders...');
      const { data: overdueResult, error: overdueError } = await supabase.functions.invoke(
        'send-daily-overdue-reminders',
        { body: {} }
      );

      if (overdueError) {
        console.error('[run-auto-reminders] Overdue reminders error:', overdueError);
        results.overdue = { success: false, error: overdueError.message };
      } else {
        console.log('[run-auto-reminders] Overdue reminders sent:', overdueResult);
        results.overdue = overdueResult;
      }
    }

    // Send due date reminders if enabled
    if (settings.due_date_reminder_enabled) {
      console.log('[run-auto-reminders] Invoking send-due-date-reminders...');
      const { data: dueDateResult, error: dueDateError } = await supabase.functions.invoke(
        'send-due-date-reminders',
        { body: {} }
      );

      if (dueDateError) {
        console.error('[run-auto-reminders] Due date reminders error:', dueDateError);
        results.dueDate = { success: false, error: dueDateError.message };
      } else {
        console.log('[run-auto-reminders] Due date reminders sent:', dueDateResult);
        results.dueDate = dueDateResult;
      }
    }

    // Update last_run_at
    await supabase
      .from('whatsapp_auto_reminder_settings')
      .update({ last_run_at: new Date().toISOString() })
      .eq('id', settings.id);

    console.log('[run-auto-reminders] Completed successfully');

    return new Response(
      JSON.stringify({
        success: true,
        results,
        timestamp: new Date().toISOString(),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('[run-auto-reminders] Fatal error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
