import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ResetResult {
  success: boolean;
  message: string;
  updatedCount?: number;
  error?: string;
}

/**
 * 🔒 SECURITY FIX: Reset Credit Status
 * 
 * Previous issues:
 * - Could change customer credit status without login
 * - Used "master key" that could mess up all database security rules
 * - No audit log of who changed the data
 * 
 * Fixed:
 * - Now requires authentication (verify_jwt = true in config.toml)
 * - Only owner can call this dangerous function
 * - All changes are logged to audit trail
 * - Clear security warnings and documentation
 */

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get authenticated user from JWT
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ success: false, error: "Authentication required" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 401 }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? '';
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

    if (!supabaseUrl || !supabaseAnonKey || !serviceKey) {
      console.error("Missing environment variables");
      return new Response(
        JSON.stringify({ success: false, error: "Server configuration error" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
      );
    }

    // Create client with user's JWT for authentication check
    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: {
          authorization: authHeader,
        },
      },
    });

    // Verify user is authenticated and get their role
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      console.error("Authentication failed:", authError);
      return new Response(
        JSON.stringify({ success: false, error: "Invalid authentication" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 401 }
      );
    }

    // Check if user has owner role (ONLY OWNER can reset credit status)
    const { data: roleData, error: roleError } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleError || !roleData || roleData.role !== "owner") {
      console.error("Authorization failed - user is not owner");
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: "Insufficient permissions. Only owner can reset credit status." 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 403 }
      );
    }

    console.log('⚠️ CRITICAL OPERATION: Credit status reset initiated by:', user.email);

    // Use service role for database operations
    const supabaseAdmin = createClient(supabaseUrl, serviceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    // Call the database function to reset credit status
    // This function handles:
    // 1. Temporarily disabling the constraint
    // 2. Updating credit applications without installments
    // 3. Re-enabling the constraint
    const { data, error } = await supabaseAdmin.rpc('reset_credit_status_for_restore');

    if (error) {
      console.error('Error calling reset function:', error);
      
      // Log failed attempt
      await supabaseAdmin.rpc('log_system_event', {
        p_user_id: user.id,
        p_user_name: user.email || "Unknown",
        p_category: "security",
        p_action: "reset_credit_status_failed",
        p_description: `Gagal mereset status kredit: ${error.message}`,
        p_metadata: {
          error: error.message,
          executed_by: user.email
        }
      });

      throw new Error(`Failed to reset credit status: ${error.message}`);
    }

    console.log('Reset function result:', data);

    // Check if the function succeeded
    if (!data.success) {
      throw new Error(data.message || 'Reset function returned failure');
    }

    // 🔒 CRITICAL: Log this dangerous operation to audit trail
    await supabaseAdmin.rpc('log_system_event', {
      p_user_id: user.id,
      p_user_name: user.email || "Unknown",
      p_category: "security",
      p_action: "reset_credit_status",
      p_description: `Mereset status kredit untuk restore data - ${data.updated_count} aplikasi diupdate`,
      p_metadata: {
        updated_count: data.updated_count,
        message: data.message,
        executed_by: user.email,
        timestamp: new Date().toISOString()
      }
    });

    const result: ResetResult = {
      success: true,
      message: data.message,
      updatedCount: data.updated_count
    };

    return new Response(
      JSON.stringify(result),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Error in reset-credit-status function:', error);
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    const result: ResetResult = {
      success: false,
      message: 'Failed to reset credit status',
      error: errorMessage
    };

    return new Response(
      JSON.stringify(result),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
