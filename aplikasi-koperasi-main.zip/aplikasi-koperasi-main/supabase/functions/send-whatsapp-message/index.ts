import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WhatsAppMessageRequest {
  phone_number: string;
  message: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { phone_number, message }: WhatsAppMessageRequest = await req.json();

    if (!phone_number || !message) {
      return new Response(
        JSON.stringify({ success: false, error: 'Phone number and message are required' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // Get WhatsApp settings
    const { data: settings, error: settingsError } = await supabase
      .from('whatsapp_settings')
      .select('*')
      .maybeSingle();

    if (settingsError || !settings) {
      console.error('[send-whatsapp-message] Failed to get settings:', settingsError);
      return new Response(
        JSON.stringify({ success: false, error: 'WhatsApp not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (!settings.is_enabled || !settings.api_key) {
      return new Response(
        JSON.stringify({ success: false, error: 'WhatsApp is not enabled or API key missing' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // Clean phone number (remove +, spaces, dashes)
    const cleanPhone = phone_number.replace(/[\s\-\+]/g, '');
    
    // Format for WhatsApp API (add country code if not present)
    let formattedPhone = cleanPhone;
    if (!cleanPhone.startsWith('62')) {
      formattedPhone = cleanPhone.startsWith('0') ? '62' + cleanPhone.substring(1) : '62' + cleanPhone;
    }

    console.log(`[send-whatsapp-message] Sending to: ${formattedPhone}`);

    // Send via WhatsApp Business API
    const response = await fetch(
      `https://graph.facebook.com/v17.0/${settings.phone_number_id}/messages`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${settings.api_key}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: formattedPhone,
          type: 'text',
          text: { body: message }
        })
      }
    );

    const result = await response.json();

    if (!response.ok) {
      console.error('[send-whatsapp-message] API Error:', result);
      throw new Error(result.error?.message || 'Failed to send WhatsApp message');
    }

    console.log('[send-whatsapp-message] Success:', result);

    return new Response(
      JSON.stringify({ success: true, result }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('[send-whatsapp-message] Error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
