import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface AppSettings {
  deposit_interest_rate: number;
  deposit_interest_payment_day: number;
  deposit_min_days_for_interest: number;
  deposit_tier_silver_min_balance: number;
  deposit_tier_silver_interest_rate: number;
  deposit_tier_gold_min_balance: number;
  deposit_tier_gold_interest_rate: number;
  deposit_tier_platinum_min_balance: number;
  deposit_tier_platinum_interest_rate: number;
}

interface Saver {
  id: string;
  full_name: string;
  deposit_balance: number;
  interest_balance: number;
  tier_level: string;
}

interface Deposit {
  id: string;
  saver_id: string;
  amount: number;
  deposit_date: string;
  remaining_balance: number;
  is_eligible_for_interest: boolean;
  total_interest_earned: number;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get settings
    const { data: settingsData, error: settingsError } = await supabase
      .from("app_settings")
      .select("deposit_interest_rate, deposit_interest_payment_day, deposit_min_days_for_interest, deposit_tier_silver_min_balance, deposit_tier_silver_interest_rate, deposit_tier_gold_min_balance, deposit_tier_gold_interest_rate, deposit_tier_platinum_min_balance, deposit_tier_platinum_interest_rate")
      .limit(1)
      .single();

    if (settingsError) {
      throw new Error(`Failed to fetch settings: ${settingsError.message}`);
    }

    const settings = settingsData as AppSettings;
    const minDaysForInterest = settings.deposit_min_days_for_interest || 21;

    // Get current date in WIB
    const now = new Date();
    const wibOffset = 7 * 60 * 60 * 1000;
    const nowWIB = new Date(now.getTime() + wibOffset);
    const currentMonth = `${nowWIB.getFullYear()}-${String(nowWIB.getMonth() + 1).padStart(2, '0')}`;

    // Check if interest has already been calculated for this month
    const { data: existingInterest } = await supabase
      .from("saver_interest_transactions")
      .select("id")
      .eq("period_month", currentMonth)
      .limit(1);

    if (existingInterest && existingInterest.length > 0) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: `Bunga untuk periode ${currentMonth} sudah dihitung sebelumnya` 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get all active savers with their deposits
    const { data: savers, error: saversError } = await supabase
      .from("savers")
      .select("id, full_name, deposit_balance, interest_balance, tier_level")
      .eq("status", "active");

    if (saversError) {
      throw new Error(`Failed to fetch savers: ${saversError.message}`);
    }

    const results: Array<{
      saver_id: string;
      saver_name: string;
      tier_level: string;
      principal_amount: number;
      interest_rate: number;
      interest_amount: number;
      eligible_deposits: number;
    }> = [];

    for (const saver of savers as Saver[]) {
      // Get deposits for this saver
      const { data: deposits, error: depositsError } = await supabase
        .from("saver_deposits")
        .select("*")
        .eq("saver_id", saver.id)
        .eq("transaction_type", "deposit")
        .gt("remaining_balance", 0);

      if (depositsError) {
        console.error(`Error fetching deposits for saver ${saver.id}:`, depositsError);
        continue;
      }

      // Calculate eligible deposits (those that have been held for minimum days)
      let eligiblePrincipal = 0;
      let eligibleDeposits = 0;
      const depositUpdates: Array<{ id: string; is_eligible: boolean }> = [];

      for (const deposit of deposits as Deposit[]) {
        const depositDate = new Date(deposit.deposit_date);
        const daysSinceDeposit = Math.floor((nowWIB.getTime() - depositDate.getTime()) / (1000 * 60 * 60 * 24));
        
        const isEligible = daysSinceDeposit >= minDaysForInterest;
        depositUpdates.push({ id: deposit.id, is_eligible: isEligible });

        if (isEligible) {
          eligiblePrincipal += deposit.remaining_balance;
          eligibleDeposits++;
        }
      }

      // Update deposit eligibility status
      for (const update of depositUpdates) {
        await supabase
          .from("saver_deposits")
          .update({ is_eligible_for_interest: update.is_eligible })
          .eq("id", update.id);
      }

      if (eligiblePrincipal <= 0) {
        continue;
      }

      // Determine tier level and interest rate based on total deposit balance
      let tierLevel = 'silver';
      let interestRate = settings.deposit_tier_silver_interest_rate || 0.5;

      if (saver.deposit_balance >= (settings.deposit_tier_platinum_min_balance || 10000000)) {
        tierLevel = 'platinum';
        interestRate = settings.deposit_tier_platinum_interest_rate || 1.0;
      } else if (saver.deposit_balance >= (settings.deposit_tier_gold_min_balance || 5000000)) {
        tierLevel = 'gold';
        interestRate = settings.deposit_tier_gold_interest_rate || 0.75;
      }

      // Calculate interest amount (monthly rate)
      const interestAmount = Math.floor(eligiblePrincipal * (interestRate / 100));

      if (interestAmount <= 0) {
        continue;
      }

      // Create interest transaction
      const { error: interestError } = await supabase
        .from("saver_interest_transactions")
        .insert({
          saver_id: saver.id,
          amount: interestAmount,
          interest_rate: interestRate,
          tier_level: tierLevel,
          principal_amount: eligiblePrincipal,
          period_month: currentMonth,
          payment_date: nowWIB.toISOString().split('T')[0],
        });

      if (interestError) {
        console.error(`Error creating interest transaction for saver ${saver.id}:`, interestError);
        continue;
      }

      // Update saver's interest balance and tier level
      const newInterestBalance = (saver.interest_balance || 0) + interestAmount;
      const newTotalBalance = (saver.deposit_balance || 0) + newInterestBalance;

      const { error: updateError } = await supabase
        .from("savers")
        .update({ 
          interest_balance: newInterestBalance,
          balance: newTotalBalance,
          tier_level: tierLevel,
        })
        .eq("id", saver.id);

      if (updateError) {
        console.error(`Error updating saver ${saver.id}:`, updateError);
        continue;
      }

      results.push({
        saver_id: saver.id,
        saver_name: saver.full_name,
        tier_level: tierLevel,
        principal_amount: eligiblePrincipal,
        interest_rate: interestRate,
        interest_amount: interestAmount,
        eligible_deposits: eligibleDeposits,
      });
    }

    const totalInterestPaid = results.reduce((sum, r) => sum + r.interest_amount, 0);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Berhasil menghitung bunga untuk ${results.length} nasabah`,
        period: currentMonth,
        total_interest_paid: totalInterestPaid,
        min_days_for_interest: minDaysForInterest,
        details: results,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("Error calculating interest:", error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});