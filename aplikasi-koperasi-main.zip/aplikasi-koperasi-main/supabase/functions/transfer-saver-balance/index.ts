import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { crypto } from "https://deno.land/std@0.168.0/crypto/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Generate integrity hash for transaction verification
async function generateTransactionHash(data: {
  sender_id: string;
  recipient_id: string;
  amount: number;
  timestamp: string;
  transaction_number: string;
}): Promise<string> {
  const secret = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "default-secret";
  const payload = `${data.sender_id}|${data.recipient_id}|${data.amount}|${data.timestamp}|${data.transaction_number}|${secret}`;
  
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(payload);
  const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  
  return hashHex;
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { sender_id, recipient_id, amount, pin } = await req.json();

    console.log("Transfer request:", { sender_id, recipient_id, amount });

    // Validate input
    if (!sender_id || !recipient_id || !amount || !pin) {
      return new Response(
        JSON.stringify({ error: "Data tidak lengkap" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (sender_id === recipient_id) {
      return new Response(
        JSON.stringify({ error: "Tidak dapat transfer ke rekening sendiri" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (amount <= 0) {
      return new Response(
        JSON.stringify({ error: "Jumlah transfer harus lebih dari 0" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get sender info
    const { data: sender, error: senderError } = await supabase
      .from("savers")
      .select("id, full_name, account_number, deposit_balance, pin_hash")
      .eq("id", sender_id)
      .eq("status", "active")
      .single();

    if (senderError || !sender) {
      console.error("Sender not found:", senderError);
      return new Response(
        JSON.stringify({ error: "Pengirim tidak ditemukan" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get recipient info
    const { data: recipient, error: recipientError } = await supabase
      .from("savers")
      .select("id, full_name, account_number, deposit_balance")
      .eq("id", recipient_id)
      .eq("status", "active")
      .single();

    if (recipientError || !recipient) {
      console.error("Recipient not found:", recipientError);
      return new Response(
        JSON.stringify({ error: "Penerima tidak ditemukan" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check sender balance
    const senderBalance = sender.deposit_balance || 0;
    if (senderBalance < amount) {
      return new Response(
        JSON.stringify({ error: "Saldo tidak mencukupi" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify PIN using edge function
    const { data: pinResult, error: pinError } = await supabase.functions.invoke("verify-saver-pin", {
      body: { saver_id: sender_id, pin }
    });

    if (pinError) {
      console.error("PIN verification error:", pinError);
      
      // Try to parse error for attempts info
      let errorBody: any = null;
      try {
        const ctx = (pinError as any)?.context;
        if (ctx && typeof ctx.json === "function") {
          const res = typeof ctx.clone === "function" ? ctx.clone() : ctx;
          errorBody = await res.json();
        }
      } catch {}

      if (errorBody?.attempts !== undefined) {
        if (errorBody.attempts >= 3) {
          return new Response(
            JSON.stringify({ error: "PIN salah 3x. Transaksi dibatalkan.", blocked: true }),
            { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        return new Response(
          JSON.stringify({ error: "PIN salah", attempts: errorBody.attempts }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "Gagal verifikasi PIN" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!pinResult?.valid) {
      const attempts = pinResult?.attempts || 1;
      if (attempts >= 3) {
        return new Response(
          JSON.stringify({ error: "PIN salah 3x. Transaksi dibatalkan.", blocked: true }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      return new Response(
        JSON.stringify({ error: "PIN salah", attempts }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("PIN verified successfully, processing transfer...");

    // Generate transaction number
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, "");
    const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const transactionNumber = `TRF-${dateStr}-${randomSuffix}`;

    // Start transaction - deduct from sender
    const newSenderBalance = senderBalance - amount;
    const { error: deductError } = await supabase
      .from("savers")
      .update({ 
        deposit_balance: newSenderBalance,
        updated_at: now.toISOString()
      })
      .eq("id", sender_id);

    if (deductError) {
      console.error("Failed to deduct sender balance:", deductError);
      return new Response(
        JSON.stringify({ error: "Gagal memproses transfer" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Add to recipient
    const newRecipientBalance = (recipient.deposit_balance || 0) + amount;
    const { error: addError } = await supabase
      .from("savers")
      .update({ 
        deposit_balance: newRecipientBalance,
        updated_at: now.toISOString()
      })
      .eq("id", recipient_id);

    if (addError) {
      console.error("Failed to add recipient balance:", addError);
      // Rollback sender balance
      await supabase
        .from("savers")
        .update({ deposit_balance: senderBalance })
        .eq("id", sender_id);
      
      return new Response(
        JSON.stringify({ error: "Gagal memproses transfer" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate integrity hash for this transaction
    const transactionTimestamp = now.toISOString();
    const integrityHash = await generateTransactionHash({
      sender_id,
      recipient_id,
      amount,
      timestamp: transactionTimestamp,
      transaction_number: transactionNumber
    });

    // Detailed metadata for transfer records
    const senderMetadata = JSON.stringify({
      type: "transfer_out",
      recipient_id: recipient_id,
      recipient_name: recipient.full_name,
      recipient_account: recipient.account_number,
      amount: amount,
      timestamp: transactionTimestamp,
      transaction_number: transactionNumber,
      integrity_hash: integrityHash,
      verified_by_pin: true
    });

    const recipientMetadata = JSON.stringify({
      type: "transfer_in",
      sender_id: sender_id,
      sender_name: sender.full_name,
      sender_account: sender.account_number,
      amount: amount,
      timestamp: transactionTimestamp,
      transaction_number: transactionNumber,
      integrity_hash: integrityHash,
      verified_by_pin: true
    });

    // Record sender withdrawal transaction (transfer out) with detailed info
    const { error: senderTxError } = await supabase
      .from("saver_withdrawals")
      .insert({
        saver_id: sender_id,
        amount: amount,
        payment_method: "transfer",
        payment_details: senderMetadata,
        notes: `🔄 TRANSFER ke ${recipient.full_name} | No. Rek: ${recipient.account_number} | Nominal: Rp ${amount.toLocaleString("id-ID")} | ${transactionTimestamp}`,
        transaction_number: transactionNumber,
        status: "completed",
        withdrawal_date: transactionTimestamp
      });

    if (senderTxError) {
      console.error("Failed to record sender transaction:", senderTxError);
    }

    // Record recipient deposit transaction (transfer in) with detailed info
    const { error: recipientTxError } = await supabase
      .from("saver_deposits")
      .insert({
        saver_id: recipient_id,
        amount: amount,
        remaining_balance: newRecipientBalance,
        payment_method: "transfer",
        payment_details: recipientMetadata,
        notes: `🔄 TRANSFER dari ${sender.full_name} | No. Rek: ${sender.account_number} | Nominal: Rp ${amount.toLocaleString("id-ID")} | ${transactionTimestamp}`,
        transaction_number: transactionNumber,
        transaction_type: "transfer_in",
        status: "approved",
        deposit_date: transactionTimestamp,
        approved_at: transactionTimestamp
      });

    if (recipientTxError) {
      console.error("Failed to record recipient transaction:", recipientTxError);
    }

    console.log("Transfer recorded with integrity hash:", integrityHash.substring(0, 16) + "...");

    console.log("Transfer completed successfully:", {
      transactionNumber,
      sender: sender.full_name,
      recipient: recipient.full_name,
      amount
    });

    return new Response(
      JSON.stringify({
        success: true,
        transaction_number: transactionNumber,
        message: `Transfer berhasil ke ${recipient.full_name}`
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Transfer error:", error);
    return new Response(
      JSON.stringify({ error: "Terjadi kesalahan server" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
