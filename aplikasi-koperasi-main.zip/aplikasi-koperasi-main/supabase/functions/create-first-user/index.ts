import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Check if an active owner already exists to prevent unauthorized creation
    const { data: existingOwners, error: ownerCheckErr } = await supabaseAdmin
      .from('members')
      .select('id')
      .ilike('position', 'owner')
      .not('user_id', 'is', null)
      .limit(1);

    if (ownerCheckErr) throw ownerCheckErr;
    if (existingOwners && existingOwners.length > 0) {
      return new Response(JSON.stringify({ error: 'Owner already exists in system' }), {
        status: 409,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const memberNumber = 'FTC';
    const email = `${memberNumber.toLowerCase()}@system.local`;
    const password = '04102018'; // DDMMYYYY

    // Find existing FTC user by querying profiles to avoid admin list API
    const { data: prof, error: profErr } = await supabaseAdmin
      .from('profiles')
      .select('id')
      .ilike('email', email)
      .maybeSingle();
    if (profErr) throw profErr;

    if (prof?.id) {
      // Clean related rows first
      await supabaseAdmin.from('user_roles').delete().eq('user_id', prof.id);
      await supabaseAdmin.from('members').update({ user_id: null }).eq('user_id', prof.id);
      await supabaseAdmin.from('profiles').delete().eq('id', prof.id);
      // Remove auth user if it exists (ignore not found)
      try {
        await (supabaseAdmin as any).auth.admin.deleteUser(prof.id);
      } catch (_e) {
        // ignore
      }
    }

    // Ensure only one FTC member row remains
    await supabaseAdmin.from('members').delete().eq('member_number', memberNumber);

    // Create auth user properly via Admin API
    const { data: created, error: createErr } = await (supabaseAdmin as any).auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: 'FTC' },
      app_metadata: { provider: 'email', providers: ['email'] },
    });
    if (createErr) throw createErr;
    const userId = created.user.id;

    // Upsert profile
    const { error: profileErr } = await supabaseAdmin
      .from('profiles')
      .upsert({ id: userId, full_name: 'FTC', email })
      .eq('id', userId);
    if (profileErr) throw profileErr;

    // Insert member
    const { error: memberErr } = await supabaseAdmin
      .from('members')
      .insert({
        user_id: userId,
        member_number: memberNumber,
        full_name: 'FTC',
        position: 'Owner',
        date_of_birth: '2018-10-04',
      });
    if (memberErr) throw memberErr;

    // Assign owner role (idempotent)
    const { error: roleErr } = await supabaseAdmin
      .from('user_roles')
      .insert({ user_id: userId, role: 'owner' })
      .select()
      .single();
    if (roleErr && !`${roleErr.message}`.includes('duplicate')) throw roleErr;

    return new Response(
      JSON.stringify({ success: true, username: memberNumber, password }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : 'An unknown error occurred';
    return new Response(
      JSON.stringify({ error: message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  }
});
