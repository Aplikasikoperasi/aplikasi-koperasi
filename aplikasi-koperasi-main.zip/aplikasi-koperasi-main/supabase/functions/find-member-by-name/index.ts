import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

/**
 * 🔒 SECURITY NOTE: Find Member by Name
 * 
 * Purpose: Used during login flow to check if member exists (BEFORE authentication)
 * 
 * Security measures:
 * - Public access (no JWT) required for login flow
 * - Returns data needed for login: id, user_id, full_name, position, is_active, date_of_birth
 * - PIN is NEVER returned (it's the sensitive credential)
 * - date_of_birth is returned as it's used for password generation (like customer login)
 * - All lookups are logged to audit trail
 * - Actual authentication happens via Supabase Auth with proper credentials
 */

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    if (!supabaseUrl || !supabaseAnonKey || !serviceKey) {
      console.error("Missing environment variables");
      return new Response(
        JSON.stringify({ success: false, error: "Server configuration error" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
      );
    }

    // Parse request body
    const { fullName } = await req.json();

    if (!fullName || typeof fullName !== "string") {
      return new Response(
        JSON.stringify({ success: false, error: "fullName is required", notFound: true }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
      );
    }

    console.log("🔍 Finding member by name:", fullName);

    // Use service role client for database query
    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    // 🔒 SECURITY: Select fields needed for login
    // PIN is NEVER returned as it's the sensitive credential
    // date_of_birth is returned as it's used for password generation (similar to customer login)
    const { data, error } = await supabaseAdmin
      .from("members")
      .select("id, user_id, full_name, position, is_active, date_of_birth")
      .ilike("full_name", fullName)
      .limit(1);

    if (error) {
      console.error("Error querying members:", error);
      return new Response(
        JSON.stringify({ success: false, error: "Database query failed" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
      );
    }

    if (!data || data.length === 0) {
      console.log("Member not found for name:", fullName);
      return new Response(
        JSON.stringify({ success: false, notFound: true, error: "Member not found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    const member = data[0];

    // Log access for audit trail
    await supabaseAdmin.rpc('log_system_event', {
      p_user_id: member.user_id || member.id,
      p_user_name: fullName,
      p_category: "authentication",
      p_action: "find_member_by_name",
      p_description: `Pencarian member untuk login: ${fullName}`,
      p_metadata: {
        member_id: member.id,
        member_name: member.full_name,
        lookup_during: "login_flow"
      }
    });

    return new Response(
      JSON.stringify({ success: true, member }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  } catch (error) {
    console.error("Unexpected error in find-member-by-name:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ success: false, error: "Internal server error" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
