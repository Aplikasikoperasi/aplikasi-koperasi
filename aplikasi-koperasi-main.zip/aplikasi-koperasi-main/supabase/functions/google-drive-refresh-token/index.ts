import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

/**
 * Refresh OAuth access token using refresh token
 */
async function refreshOAuthToken(
  refreshToken: string,
  clientId: string,
  clientSecret: string
): Promise<{ accessToken: string; expiresIn: number }> {
  console.log('Refreshing OAuth access token...');
  
  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });

  if (!tokenResponse.ok) {
    const errorText = await tokenResponse.text();
    throw new Error(`Token refresh failed: ${errorText}`);
  }

  const tokens = await tokenResponse.json();
  console.log('Access token refreshed successfully');

  return {
    accessToken: tokens.access_token,
    expiresIn: tokens.expires_in || 3600,
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Check if this is auto-refresh (from cron) or manual
    let isAutoRefresh = false;
    try {
      const body = await req.json();
      isAutoRefresh = body?.auto_refresh === true;
    } catch {
      // No body or invalid JSON
    }

    console.log(`🔄 Token refresh initiated (${isAutoRefresh ? 'auto' : 'manual'})...`);

    // Get current settings from database
    const { data: settingsData, error: settingsError } = await supabase
      .from('google_drive_settings')
      .select('oauth_refresh_token, oauth_client_id, oauth_client_secret, is_enabled, auth_mode')
      .single();

    if (settingsError) throw settingsError;
    
    // Skip if Google Drive is disabled or not using OAuth
    if (!settingsData?.is_enabled || settingsData?.auth_mode !== 'oauth') {
      console.log('⏭️ Skipping refresh: Google Drive disabled or not using OAuth');
      return new Response(
        JSON.stringify({
          success: false,
          message: 'Google Drive backup is disabled or not using OAuth',
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }
    
    if (!settingsData?.oauth_refresh_token) {
      throw new Error('No refresh token found');
    }
    if (!settingsData?.oauth_client_id || !settingsData?.oauth_client_secret) {
      throw new Error('OAuth credentials not configured');
    }

    // Refresh the token
    const { accessToken, expiresIn } = await refreshOAuthToken(
      settingsData.oauth_refresh_token,
      settingsData.oauth_client_id,
      settingsData.oauth_client_secret
    );
    
    const tokenExpiry = new Date(Date.now() + expiresIn * 1000).toISOString();

    // Update settings with new token
    const { error: updateError } = await supabase
      .from('google_drive_settings')
      .update({
        oauth_access_token: accessToken,
        oauth_token_expiry: tokenExpiry,
      })
      .eq('oauth_refresh_token', settingsData.oauth_refresh_token);

    if (updateError) {
      throw new Error(`Failed to update token: ${updateError.message}`);
    }

    console.log(`✅ Token refreshed successfully, expires at: ${tokenExpiry}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Token refreshed successfully',
        expiresAt: tokenExpiry,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Token refresh error:', error);
    
    // Send notification to admins if this is a critical failure
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    const isCritical = errorMessage.includes('No refresh token') || 
                       errorMessage.includes('OAuth credentials not configured') ||
                       errorMessage.includes('invalid_grant');
    
    if (isCritical) {
      try {
        const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
        const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
        const supabase = createClient(supabaseUrl, supabaseKey);
        
        const { data: adminRoles } = await supabase
          .from('user_roles')
          .select('user_id')
          .in('role', ['owner', 'admin']);

        if (adminRoles && adminRoles.length > 0) {
          const adminUserIds = adminRoles.map((r: any) => r.user_id);
          
          const { data: adminMembers } = await supabase
            .from('members')
            .select('id, full_name')
            .in('user_id', adminUserIds);

          if (adminMembers && adminMembers.length > 0) {
            const notifications = adminMembers.map((member: any) => ({
              member_id: member.id,
              title: '🔐 Google Drive OAuth Gagal',
              message: `Token OAuth Google Drive gagal di-refresh dan memerlukan autentikasi ulang.\n\nError: ${errorMessage}\n\n⚠️ Auto backup Google Drive akan berhenti sampai Anda login ulang dengan Google.\n\nSilakan buka Settings → Google Drive → Re-auth Google untuk memperbaiki masalah ini.`,
              type: 'error',
              metadata: {
                error_type: 'oauth_refresh_failure',
                error_message: errorMessage,
                requires_reauth: true,
                timestamp: new Date().toISOString(),
              },
            }));

            await supabase
              .from('member_messages')
              .insert(notifications);

            console.log(`📧 Sent ${notifications.length} critical OAuth failure notifications`);
          }
        }
      } catch (notifError) {
        console.error('❌ Failed to send notifications:', notifError);
      }
    }
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        critical: isCritical,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
