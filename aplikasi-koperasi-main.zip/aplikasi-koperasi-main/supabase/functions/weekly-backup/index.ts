import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Background backup function
async function performBackup(supabase: any, userId?: string) {
  try {
    console.log('🔄 Starting comprehensive backup process...');

    // Check if auto backup is enabled
    const { data: settings } = await supabase
      .from('auto_backup_settings')
      .select('enabled')
      .maybeSingle();

    if (!settings?.enabled) {
      console.log('⏭️ Auto backup is disabled, skipping...');
      return;
    }

    // Helper function to fetch ALL data with pagination (no 1000 limit)
    async function fetchAllData(tableName: string) {
      const allData: any[] = [];
      let from = 0;
      const batchSize = 1000;
      
      while (true) {
        const { data, error } = await supabase
          .from(tableName)
          .select("*")
          .range(from, from + batchSize - 1);
        
        if (error) throw error;
        if (!data || data.length === 0) break;
        
        allData.push(...data);
        if (data.length < batchSize) break;
        from += batchSize;
      }
      
      return allData;
    }

    // Fetch ALL data from ALL important tables - TRUE UNLIMITED with pagination
    console.log('📊 Fetching data from all tables (with pagination to bypass 1000 limit)...');
    
    const [
      profiles,
      members,
      customers,
      creditApplications,
      installments,
      payments,
      blockedCustomers,
      bankAccounts,
      memberBalanceTransactions,
      memberBalanceWithdrawals,
      memberMonthlySummary,
      customerMessages,
      memberMessages,
      customerChangeRequests,
      restorationRequests,
      whatsappLogs,
      systemLogs,
      appSettings,
      incentiveSettings,
      whatsappSettings,
      whatsappAutoReminder,
      whatsappTemplates,
      googleDriveSettings,
      autoBackupSettings
    ] = await Promise.all([
      fetchAllData("profiles"),
      fetchAllData("members"),
      fetchAllData("customers"),
      fetchAllData("credit_applications"),
      fetchAllData("installments"),
      fetchAllData("payments"),
      fetchAllData("blocked_customers"),
      fetchAllData("bank_accounts"),
      fetchAllData("member_balance_transactions"),
      fetchAllData("member_balance_withdrawals"),
      fetchAllData("member_monthly_balance_summary"),
      fetchAllData("customer_messages"),
      fetchAllData("member_messages"),
      fetchAllData("customer_change_requests"),
      fetchAllData("customer_restoration_requests"),
      fetchAllData("whatsapp_message_logs"),
      fetchAllData("system_logs"),
      fetchAllData("app_settings"),
      fetchAllData("incentive_settings"),
      fetchAllData("whatsapp_settings"),
      fetchAllData("whatsapp_auto_reminder_settings"),
      fetchAllData("whatsapp_message_templates"),
      fetchAllData("google_drive_settings"),
      fetchAllData("auto_backup_settings"),
    ]);

    console.log('✅ Data fetched successfully');

    // Calculate data date range
    const dates: Date[] = [];
    
    customers?.forEach((c: any) => {
      if (c.created_at) dates.push(new Date(c.created_at));
    });
    
    creditApplications?.forEach((a: any) => {
      if (a.application_date) dates.push(new Date(a.application_date));
    });
    
    payments?.forEach((p: any) => {
      if (p.payment_date) dates.push(new Date(p.payment_date));
    });
    
    members?.forEach((m: any) => {
      if (m.created_at) dates.push(new Date(m.created_at));
    });

    const oldestDate = dates.length > 0 ? new Date(Math.min(...dates.map(d => d.getTime()))) : null;
    const newestDate = dates.length > 0 ? new Date(Math.max(...dates.map(d => d.getTime()))) : null;

    const stats = {
      profiles: profiles?.length || 0,
      members: members?.length || 0,
      customers: customers?.length || 0,
      credit_applications: creditApplications?.length || 0,
      installments: installments?.length || 0,
      payments: payments?.length || 0,
      blocked_customers: blockedCustomers?.length || 0,
      bank_accounts: bankAccounts?.length || 0,
      member_balance_transactions: memberBalanceTransactions?.length || 0,
      member_balance_withdrawals: memberBalanceWithdrawals?.length || 0,
      member_monthly_summary: memberMonthlySummary?.length || 0,
      customer_messages: customerMessages?.length || 0,
      member_messages: memberMessages?.length || 0,
      customer_change_requests: customerChangeRequests?.length || 0,
      restoration_requests: restorationRequests?.length || 0,
      whatsapp_logs: whatsappLogs?.length || 0,
      system_logs: systemLogs?.length || 0,
    };

    console.log('📊 Backup statistics:', stats);

    // Create folder name with timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const folderName = `backup-${timestamp}`;

    // Helper function to chunk large arrays and upload them
    async function uploadWithChunking(tableName: string, data: any[], chunkSize = 500) {
      const chunks = [];
      for (let i = 0; i < data.length; i += chunkSize) {
        chunks.push(data.slice(i, i + chunkSize));
      }
      
      const uploadPromises = chunks.map((chunk, index) => {
        const fileName = chunks.length > 1 
          ? `${tableName}_part${index + 1}.json`
          : `${tableName}.json`;
        
        return supabase.storage
          .from('backups')
          .upload(`${folderName}/${fileName}`, JSON.stringify(chunk, null, 2), { 
            contentType: 'application/json' 
          });
      });
      
      return { promises: uploadPromises, parts: chunks.length };
    }

    // Prepare file list for manifest
    const fileList: string[] = [];
    
    // Track total parts for large tables
    const tableChunks: Record<string, number> = {};

    console.log('⬆️ Uploading backup files to Supabase Storage...');

    // Upload small tables directly
    const smallTableUploads = [
      supabase.storage.from('backups').upload(`${folderName}/profiles.json`, JSON.stringify(profiles || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/members.json`, JSON.stringify(members || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/customers.json`, JSON.stringify(customers || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/credit_applications.json`, JSON.stringify(creditApplications || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/blocked_customers.json`, JSON.stringify(blockedCustomers || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/bank_accounts.json`, JSON.stringify(bankAccounts || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/member_balance_transactions.json`, JSON.stringify(memberBalanceTransactions || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/member_balance_withdrawals.json`, JSON.stringify(memberBalanceWithdrawals || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/member_monthly_balance_summary.json`, JSON.stringify(memberMonthlySummary || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/customer_messages.json`, JSON.stringify(customerMessages || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/member_messages.json`, JSON.stringify(memberMessages || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/customer_change_requests.json`, JSON.stringify(customerChangeRequests || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/customer_restoration_requests.json`, JSON.stringify(restorationRequests || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/whatsapp_message_logs.json`, JSON.stringify(whatsappLogs || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/system_logs.json`, JSON.stringify(systemLogs || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/app_settings.json`, JSON.stringify(appSettings || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/incentive_settings.json`, JSON.stringify(incentiveSettings || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/whatsapp_settings.json`, JSON.stringify(whatsappSettings || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/whatsapp_auto_reminder_settings.json`, JSON.stringify(whatsappAutoReminder || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/whatsapp_message_templates.json`, JSON.stringify(whatsappTemplates || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/google_drive_settings.json`, JSON.stringify(googleDriveSettings || [], null, 2), { contentType: 'application/json' }),
      supabase.storage.from('backups').upload(`${folderName}/auto_backup_settings.json`, JSON.stringify(autoBackupSettings || [], null, 2), { contentType: 'application/json' }),
    ];

    fileList.push('profiles.json', 'members.json', 'customers.json', 'credit_applications.json', 
      'blocked_customers.json', 'bank_accounts.json', 'member_balance_transactions.json',
      'member_balance_withdrawals.json', 'member_monthly_balance_summary.json',
      'customer_messages.json', 'member_messages.json', 'customer_change_requests.json',
      'customer_restoration_requests.json', 'whatsapp_message_logs.json', 'system_logs.json',
      'app_settings.json', 'incentive_settings.json', 'whatsapp_settings.json',
      'whatsapp_auto_reminder_settings.json', 'whatsapp_message_templates.json',
      'google_drive_settings.json', 'auto_backup_settings.json');

    // Upload large tables with chunking (installments and payments)
    const installmentsResult = await uploadWithChunking('installments', installments || []);
    const paymentsResult = await uploadWithChunking('payments', payments || []);
    
    tableChunks['installments'] = installmentsResult.parts;
    tableChunks['payments'] = paymentsResult.parts;
    
    // Add chunked files to file list
    for (let i = 1; i <= installmentsResult.parts; i++) {
      fileList.push(installmentsResult.parts > 1 ? `installments_part${i}.json` : 'installments.json');
    }
    for (let i = 1; i <= paymentsResult.parts; i++) {
      fileList.push(paymentsResult.parts > 1 ? `payments_part${i}.json` : 'payments.json');
    }

    // Combine all uploads
    const allUploads = [
      ...smallTableUploads,
      ...installmentsResult.promises,
      ...paymentsResult.promises
    ];

    // Create manifest
    const manifest = {
      timestamp: new Date().toISOString(),
      version: '3.0',
      type: 'multi-file',
      dataRange: {
        oldestDate: oldestDate ? oldestDate.toISOString() : null,
        newestDate: newestDate ? newestDate.toISOString() : null,
        totalDays: oldestDate && newestDate ? Math.ceil((newestDate.getTime() - oldestDate.getTime()) / (1000 * 60 * 60 * 24)) : 0
      },
      stats,
      tableChunks,
      files: fileList
    };

    // Upload manifest first
    await supabase.storage
      .from('backups')
      .upload(`${folderName}/_manifest.json`, JSON.stringify(manifest, null, 2), { 
        contentType: 'application/json' 
      });

    // Execute all uploads
    const results = await Promise.all(allUploads);
    const failures = results.filter(r => r.error);
    
    if (failures.length > 0) {
      console.error('❌ Some files failed to upload:', failures);
      throw new Error(`Failed to upload ${failures.length} files`);
    }

    console.log('✅ All backup files uploaded successfully to:', folderName);

    // Auto-delete backup folders older than 7 days
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    console.log('🗑️ Checking for backups older than:', sevenDaysAgo.toISOString());

    const { data: allFolders, error: listError } = await supabase.storage
      .from('backups')
      .list('', { limit: 1000 });

    if (!listError && allFolders) {
      const oldFolders = allFolders.filter((item: any) => {
        // Only process folders (backup-* directories)
        if (!item.name.startsWith('backup-')) return false;
        const fileDate = new Date(item.created_at);
        return fileDate < sevenDaysAgo;
      });

      console.log(`Found ${oldFolders.length} old backup folders to delete`);

      for (const folder of oldFolders) {
        try {
          // List all files in the folder
          const { data: folderFiles } = await supabase.storage
            .from('backups')
            .list(folder.name);
          
          if (folderFiles && folderFiles.length > 0) {
            const filesToDelete = folderFiles.map((f: any) => `${folder.name}/${f.name}`);
            await supabase.storage.from('backups').remove(filesToDelete);
            console.log(`🗑️ Deleted folder: ${folder.name} (${filesToDelete.length} files)`);
          }
        } catch (err) {
          console.error(`❌ Error deleting folder ${folder.name}:`, err);
        }
      }
    }

    // Update backup settings - Next backup: besok jam 00:00 WIB (17:00 UTC)
    const nextBackupDate = new Date();
    nextBackupDate.setUTCDate(nextBackupDate.getUTCDate() + 1);
    nextBackupDate.setUTCHours(17, 0, 0, 0); // 00:00 WIB
    
    await supabase
      .from('auto_backup_settings')
      .update({
        last_backup_at: new Date().toISOString(),
        next_backup_at: nextBackupDate.toISOString()
      })
      .eq('enabled', true);

    console.log('✅ Backup settings updated');

    // Check if Google Drive backup is enabled
    const { data: gdSettings } = await supabase
      .from('google_drive_settings')
      .select('is_enabled')
      .maybeSingle();

    let gdUploadResult = null;
    if (gdSettings?.is_enabled) {
      console.log('☁️ Google Drive backup is enabled, uploading...');
      try {
        // Pass folder name for Google Drive backup
        const { data: gdResponse, error: gdError } = await supabase.functions.invoke(
          'upload-to-google-drive',
          {
            body: { folderName }
          }
        );

        if (gdError) {
          console.error('❌ Google Drive upload failed:', gdError);
        } else {
          gdUploadResult = gdResponse;
          console.log('✅ Google Drive upload successful');
        }
      } catch (gdErr) {
        console.error('❌ Google Drive upload exception:', gdErr);
      }
    }

    console.log('✅ Backup completed successfully!');

    // Send success notification to user if userId provided
    if (userId) {
      const { data: member } = await supabase
        .from('members')
        .select('id')
        .eq('user_id', userId)
        .maybeSingle();

      if (member) {
        await supabase
          .from('member_messages')
          .insert({
            member_id: member.id,
            title: '✅ Backup Berhasil',
            message: `Backup data berhasil dibuat pada ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB.\n\n📊 Total Records:\n• Anggota: ${stats.members}\n• Nasabah: ${stats.customers}\n• Pengajuan Kredit: ${stats.credit_applications}\n• Angsuran: ${stats.installments}\n• Pembayaran: ${stats.payments}\n\nFolder: ${folderName}`,
            type: 'success',
            metadata: {
              backup_folder: folderName,
              stats: stats,
              timestamp: new Date().toISOString(),
            }
          });
      }
    }

    return {
      success: true,
      folder: folderName,
      stats: stats,
      googleDrive: gdUploadResult ? { uploaded: true } : { uploaded: false }
    };

  } catch (error) {
    console.error('❌ Backup error:', error);
    
    // Send error notification to user if userId provided
    if (userId) {
      const { data: member } = await supabase
        .from('members')
        .select('id')
        .eq('user_id', userId)
        .maybeSingle();

      if (member) {
        await supabase
          .from('member_messages')
          .insert({
            member_id: member.id,
            title: '⚠️ Backup Gagal',
            message: `Backup data gagal pada ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB.\n\nError: ${error instanceof Error ? error.message : 'Unknown error'}\n\nSilakan coba lagi atau hubungi administrator.`,
            type: 'error',
            metadata: {
              error_type: 'backup_failure',
              error_message: error instanceof Error ? error.message : 'Unknown error',
              timestamp: new Date().toISOString(),
            }
          });
      }
    }
    
    throw error;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user info for notification
    const authHeader = req.headers.get('Authorization');
    let userId: string | undefined;
    
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: { user } } = await supabase.auth.getUser(token);
      userId = user?.id;
    }

    // Start backup in background (don't await)
    performBackup(supabase, userId).catch(err => 
      console.error('Background backup failed:', err)
    );

    // Return immediate response
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Backup process started in background. You will receive a notification when complete.',
        status: 'processing'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error starting backup:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
