import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { typedPassword, expectedDOB } = await req.json();

    if (!typedPassword || !expectedDOB) {
      return new Response(
        JSON.stringify({ valid: false, error: 'Missing required parameters' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // Password must be exactly 12 characters (DDMMYYYYHHMM)
    if (typedPassword.length !== 12) {
      return new Response(
        JSON.stringify({ valid: false, error: 'Invalid password format' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Extract parts from typed password
    const typedDOB = typedPassword.substring(0, 8);
    const typedHour = typedPassword.substring(8, 10);
    const typedMinute = typedPassword.substring(10, 12);

    // Validate DOB matches
    if (typedDOB !== expectedDOB) {
      return new Response(
        JSON.stringify({ valid: false, error: 'Invalid credentials' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Validate time format
    const hour = parseInt(typedHour, 10);
    const minute = parseInt(typedMinute, 10);
    if (isNaN(hour) || isNaN(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      return new Response(
        JSON.stringify({ valid: false, error: 'Invalid time format' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Use server time in WIB (UTC+7) for validation
    const now = new Date();
    const wibOffset = 7 * 60; // WIB is UTC+7
    const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
    const wibTotalMinutes = (utcMinutes + wibOffset) % 1440;
    
    const typedTotalMinutes = hour * 60 + minute;
    let minuteDiff = Math.abs(wibTotalMinutes - typedTotalMinutes);
    
    // Handle day boundary crossings
    if (minuteDiff > 720) {
      minuteDiff = 1440 - minuteDiff;
    }

    // Increased tolerance to ±5 minutes to handle clock drift and network latency
    if (minuteDiff > 5) {
      return new Response(
        JSON.stringify({ valid: false, error: 'Invalid time' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // All validations passed
    return new Response(
      JSON.stringify({ valid: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );
  } catch (error) {
    console.error('Error in validate-time-password:', error);
    return new Response(
      JSON.stringify({ valid: false, error: 'Internal server error' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
