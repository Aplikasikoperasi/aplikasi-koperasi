import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('[multi-stage-reminders] Starting multi-stage reminder job...');

    // Check if WhatsApp is enabled
    const { data: whatsappSettings } = await supabase
      .from('whatsapp_settings')
      .select('is_enabled')
      .single();

    if (!whatsappSettings?.is_enabled) {
      console.log('[multi-stage-reminders] WhatsApp is disabled, skipping reminders');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'WhatsApp is disabled',
          sent: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const threeDaysFromNow = new Date(today);
    threeDaysFromNow.setDate(today.getDate() + 3);
    
    const oneDayAgo = new Date(today);
    oneDayAgo.setDate(today.getDate() - 1);

    // Get penalty rate
    const { data: appSettings } = await supabase
      .from('app_settings')
      .select('penalty_rate_per_day')
      .single();
    
    const penaltyRate = appSettings?.penalty_rate_per_day || 2;

    // Get bank account info for payment details
    const { data: bankAccount } = await supabase
      .from('bank_accounts')
      .select('bank_name, account_number, account_holder')
      .eq('is_primary', true)
      .eq('is_active', true)
      .single();

    let sentCount = 0;
    const errors: any[] = [];

    // ============ STAGE 1: H-3 Reminders (3 days before due) ============
    console.log('[multi-stage-reminders] Processing H-3 reminders...');
    const { data: upcomingInstallments } = await supabase
      .from('installments')
      .select(`
        id,
        installment_number,
        due_date,
        total_amount,
        paid_amount,
        credit_applications!inner(
          application_number,
          customers!inner(
            id,
            full_name,
            phone
          )
        )
      `)
      .eq('principal_paid', false)
      .eq('due_date', threeDaysFromNow.toISOString().split('T')[0]);

    if (upcomingInstallments && upcomingInstallments.length > 0) {
      console.log(`[multi-stage-reminders] Found ${upcomingInstallments.length} installments due in 3 days`);
      
      for (const installment of upcomingInstallments) {
        const customer = (installment as any).credit_applications.customers;
        const application = (installment as any).credit_applications;
        
        if (!customer?.phone) continue;

        const remainingAmount = installment.total_amount - installment.paid_amount;
        
        let message = `*🔔 PENGINGAT ANGSURAN (H-3)*\n\n`;
        message += `Kepada Yth. Bapak/Ibu *${customer.full_name}*,\n\n`;
        message += `Kami ingin mengingatkan bahwa angsuran Anda akan jatuh tempo dalam *3 hari*:\n\n`;
        message += `📋 *Detail Angsuran:*\n`;
        message += `• No. Aplikasi: ${application.application_number}\n`;
        message += `• Angsuran ke: ${installment.installment_number}\n`;
        message += `• Tanggal Jatuh Tempo: ${new Date(installment.due_date).toLocaleDateString('id-ID')}\n`;
        message += `• Jumlah yang Harus Dibayar: Rp ${remainingAmount.toLocaleString('id-ID')}\n\n`;

        if (bankAccount) {
          message += `💳 *Informasi Pembayaran:*\n`;
          message += `• Bank: ${bankAccount.bank_name}\n`;
          message += `• No. Rekening: ${bankAccount.account_number}\n`;
          message += `• Atas Nama: ${bankAccount.account_holder}\n\n`;
        }

        message += `⚠️ Harap lakukan pembayaran sebelum tanggal jatuh tempo untuk menghindari denda keterlambatan.\n\n`;
        message += `Terima kasih atas perhatian dan kerjasamanya.`;

        try {
          const { error: sendError } = await supabase.functions.invoke('send-whatsapp-message', {
            body: {
              to: customer.phone,
              message: message,
            },
          });

          if (sendError) throw sendError;

          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_h3',
            message_content: message,
            status: 'sent',
            sent_at: new Date().toISOString(),
          });

          sentCount++;
          console.log(`[multi-stage-reminders] H-3 reminder sent to ${customer.full_name}`);
          
          await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (error: any) {
          console.error(`[multi-stage-reminders] H-3 error for ${customer.full_name}:`, error);
          errors.push({ stage: 'H-3', customer: customer.full_name, error: error.message });
          
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_h3',
            message_content: message,
            status: 'failed',
            error_message: error.message,
          });
        }
      }
    }

    // ============ STAGE 2: H-0 Reminders (Due today) ============
    console.log('[multi-stage-reminders] Processing H-0 reminders...');
    const { data: todayInstallments } = await supabase
      .from('installments')
      .select(`
        id,
        installment_number,
        due_date,
        total_amount,
        paid_amount,
        credit_applications!inner(
          application_number,
          customers!inner(
            id,
            full_name,
            phone
          )
        )
      `)
      .eq('principal_paid', false)
      .eq('due_date', today.toISOString().split('T')[0]);

    if (todayInstallments && todayInstallments.length > 0) {
      console.log(`[multi-stage-reminders] Found ${todayInstallments.length} installments due today`);
      
      for (const installment of todayInstallments) {
        const customer = (installment as any).credit_applications.customers;
        const application = (installment as any).credit_applications;
        
        if (!customer?.phone) continue;

        const remainingAmount = installment.total_amount - installment.paid_amount;
        
        let message = `*🚨 JATUH TEMPO HARI INI*\n\n`;
        message += `Kepada Yth. Bapak/Ibu *${customer.full_name}*,\n\n`;
        message += `Angsuran Anda *JATUH TEMPO HARI INI*. Mohon segera lakukan pembayaran:\n\n`;
        message += `📋 *Detail Angsuran:*\n`;
        message += `• No. Aplikasi: ${application.application_number}\n`;
        message += `• Angsuran ke: ${installment.installment_number}\n`;
        message += `• Tanggal Jatuh Tempo: *HARI INI* (${new Date(installment.due_date).toLocaleDateString('id-ID')})\n`;
        message += `• Jumlah yang Harus Dibayar: Rp ${remainingAmount.toLocaleString('id-ID')}\n\n`;

        if (bankAccount) {
          message += `💳 *Informasi Pembayaran:*\n`;
          message += `• Bank: ${bankAccount.bank_name}\n`;
          message += `• No. Rekening: ${bankAccount.account_number}\n`;
          message += `• Atas Nama: ${bankAccount.account_holder}\n\n`;
        }

        message += `⚠️ *PENTING:* Pembayaran setelah hari ini akan dikenakan denda ${penaltyRate}% per hari.\n\n`;
        message += `Terima kasih atas perhatian dan kerjasamanya.`;

        try {
          const { error: sendError } = await supabase.functions.invoke('send-whatsapp-message', {
            body: {
              to: customer.phone,
              message: message,
            },
          });

          if (sendError) throw sendError;

          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_due_today',
            message_content: message,
            status: 'sent',
            sent_at: new Date().toISOString(),
          });

          sentCount++;
          console.log(`[multi-stage-reminders] H-0 reminder sent to ${customer.full_name}`);
          
          await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (error: any) {
          console.error(`[multi-stage-reminders] H-0 error for ${customer.full_name}:`, error);
          errors.push({ stage: 'H-0', customer: customer.full_name, error: error.message });
          
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_due_today',
            message_content: message,
            status: 'failed',
            error_message: error.message,
          });
        }
      }
    }

    // ============ STAGE 3: H+1 Warnings (1 day overdue) ============
    console.log('[multi-stage-reminders] Processing H+1 warnings...');
    const { data: overdueInstallments } = await supabase
      .from('installments')
      .select(`
        id,
        installment_number,
        due_date,
        total_amount,
        paid_amount,
        credit_applications!inner(
          application_number,
          customers!inner(
            id,
            full_name,
            phone
          )
        )
      `)
      .eq('principal_paid', false)
      .eq('due_date', oneDayAgo.toISOString().split('T')[0]);

    if (overdueInstallments && overdueInstallments.length > 0) {
      console.log(`[multi-stage-reminders] Found ${overdueInstallments.length} installments 1 day overdue`);
      
      for (const installment of overdueInstallments) {
        const customer = (installment as any).credit_applications.customers;
        const application = (installment as any).credit_applications;
        
        if (!customer?.phone) continue;

        const remainingAmount = installment.total_amount - installment.paid_amount;
        const daysOverdue = 1;
        const penalty = Math.ceil((remainingAmount * (penaltyRate / 100) * daysOverdue) / 1000) * 1000;
        const totalDue = remainingAmount + penalty;
        
        let message = `*⛔ PERINGATAN KETERLAMBATAN PEMBAYARAN*\n\n`;
        message += `Kepada Yth. Bapak/Ibu *${customer.full_name}*,\n\n`;
        message += `Angsuran Anda telah *MELEWATI JATUH TEMPO 1 HARI* dan terkena denda keterlambatan:\n\n`;
        message += `📋 *Detail Angsuran:*\n`;
        message += `• No. Aplikasi: ${application.application_number}\n`;
        message += `• Angsuran ke: ${installment.installment_number}\n`;
        message += `• Tanggal Jatuh Tempo: ${new Date(installment.due_date).toLocaleDateString('id-ID')}\n`;
        message += `• Terlambat: ${daysOverdue} hari\n\n`;
        message += `💰 *Rincian Pembayaran:*\n`;
        message += `• Sisa Angsuran: Rp ${remainingAmount.toLocaleString('id-ID')}\n`;
        message += `• Denda (${penaltyRate}%/hari): Rp ${penalty.toLocaleString('id-ID')}\n`;
        message += `• *TOTAL YANG HARUS DIBAYAR: Rp ${totalDue.toLocaleString('id-ID')}*\n\n`;

        if (bankAccount) {
          message += `💳 *Informasi Pembayaran:*\n`;
          message += `• Bank: ${bankAccount.bank_name}\n`;
          message += `• No. Rekening: ${bankAccount.account_number}\n`;
          message += `• Atas Nama: ${bankAccount.account_holder}\n\n`;
        }

        message += `⚠️ *SEGERA LAKUKAN PEMBAYARAN* untuk menghindari denda bertambah dan dampak pada skor kredit Anda.\n\n`;
        message += `Hubungi kami jika ada kendala pembayaran.\n\n`;
        message += `Terima kasih atas perhatian dan kerjasamanya.`;

        try {
          const { error: sendError } = await supabase.functions.invoke('send-whatsapp-message', {
            body: {
              to: customer.phone,
              message: message,
            },
          });

          if (sendError) throw sendError;

          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'warning_overdue_1day',
            message_content: message,
            status: 'sent',
            sent_at: new Date().toISOString(),
          });

          sentCount++;
          console.log(`[multi-stage-reminders] H+1 warning sent to ${customer.full_name}`);
          
          await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (error: any) {
          console.error(`[multi-stage-reminders] H+1 error for ${customer.full_name}:`, error);
          errors.push({ stage: 'H+1', customer: customer.full_name, error: error.message });
          
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'warning_overdue_1day',
            message_content: message,
            status: 'failed',
            error_message: error.message,
          });
        }
      }
    }

    console.log(`[multi-stage-reminders] Job completed. Sent: ${sentCount}, Errors: ${errors.length}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Multi-stage reminders sent successfully',
        sent: sentCount,
        errors: errors.length > 0 ? errors : undefined,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error: any) {
    console.error('[multi-stage-reminders] Fatal error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});