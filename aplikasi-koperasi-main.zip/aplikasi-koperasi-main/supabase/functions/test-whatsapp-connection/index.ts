import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      api_provider, 
      api_url, 
      phone_number, 
      phone_number_id,
      business_account_id,
      api_key 
    } = await req.json();

    console.log('Testing WhatsApp API connection:', { 
      api_provider, 
      api_url, 
      phone_number,
      has_api_key: !!api_key 
    });

    // Validate API key
    if (!api_key) {
      console.error('API Key not provided');
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'WhatsApp API Key tidak ditemukan' 
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Validate required fields
    if (!api_url || !phone_number) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'API URL dan Phone Number wajib diisi' 
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    let testResult = { success: false, message: '' };

    // Test connection based on provider
    if (api_provider === 'whatsapp_business') {
      // Meta WhatsApp Business API
      if (!phone_number_id) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            message: 'Phone Number ID diperlukan untuk Meta WhatsApp Business API' 
          }),
          {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      // Test by getting phone number details
      const testUrl = `${api_url}/${phone_number_id}`;
      console.log('Testing Meta API:', testUrl);

      const response = await fetch(testUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${api_key}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Meta API test successful:', data);
        testResult = { 
          success: true, 
          message: `Terhubung ke WhatsApp Business API. Verified Name: ${data.verified_name || 'N/A'}` 
        };
      } else {
        const errorText = await response.text();
        console.error('Meta API test failed:', response.status, errorText);
        testResult = { 
          success: false, 
          message: `Gagal terhubung: ${response.status} - ${errorText}` 
        };
      }
    } else if (api_provider === 'wappin') {
      // Wappin.id API test
      console.log('Testing Wappin API:', api_url);
      
      const response = await fetch(`${api_url}/api/v1/profile`, {
        method: 'GET',
        headers: {
          'Authorization': api_key,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Wappin API test successful:', data);
        testResult = { 
          success: true, 
          message: `Terhubung ke Wappin.id. Status: ${data.status || 'Active'}` 
        };
      } else {
        const errorText = await response.text();
        console.error('Wappin API test failed:', response.status, errorText);
        testResult = { 
          success: false, 
          message: `Gagal terhubung: ${response.status} - ${errorText}` 
        };
      }
    } else if (api_provider === 'fonnte') {
      // Fonnte API test
      console.log('Testing Fonnte API:', api_url);
      
      const response = await fetch(`${api_url}/device`, {
        method: 'GET',
        headers: {
          'Authorization': api_key,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Fonnte API test successful:', data);
        testResult = { 
          success: true, 
          message: `Terhubung ke Fonnte. Device: ${data.device || 'Connected'}` 
        };
      } else {
        const errorText = await response.text();
        console.error('Fonnte API test failed:', response.status, errorText);
        testResult = { 
          success: false, 
          message: `Gagal terhubung: ${response.status} - ${errorText}` 
        };
      }
    } else {
      // Custom API - just test if URL is reachable
      console.log('Testing Custom API:', api_url);
      
      try {
        const response = await fetch(api_url, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${api_key}`,
            'Content-Type': 'application/json',
          },
        });

        if (response.ok || response.status === 401 || response.status === 403) {
          // Even if unauthorized, at least the endpoint is reachable
          testResult = { 
            success: true, 
            message: `Endpoint dapat dijangkau (Status: ${response.status}). Pastikan API key valid.` 
          };
        } else {
          testResult = { 
            success: false, 
            message: `Endpoint tidak dapat dijangkau: ${response.status}` 
          };
        }
      } catch (error: any) {
        console.error('Custom API test error:', error);
        testResult = { 
          success: false, 
          message: `Error: ${error.message}` 
        };
      }
    }

    return new Response(
      JSON.stringify(testResult),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('Error in test-whatsapp-connection:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        message: error.message || 'Terjadi kesalahan saat menguji koneksi' 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
