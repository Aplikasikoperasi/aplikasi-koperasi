import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? '';

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);
    const supabaseAuth = createClient(supabaseUrl, anonKey);

    const { fullName, dateOfBirth, phone, nik, address, photoUrl, supercode } = await req.json();

    if (!fullName || !dateOfBirth) {
      return new Response(JSON.stringify({ error: 'fullName and dateOfBirth are required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!supercode || supercode.length < 6) {
      return new Response(JSON.stringify({ error: 'Supercode is required and must be at least 6 characters' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Check if there's an ACTIVE owner (member with linked auth)
    const { data: activeOwners, error: activeErr } = await supabaseAdmin
      .from('members')
      .select('id')
      .ilike('position', 'owner')
      .not('user_id', 'is', null)
      .limit(1);

    if (activeErr) throw activeErr;
    if (activeOwners && activeOwners.length > 0) {
      return new Response(JSON.stringify({ error: 'Owner already exists (active)' }), {
        status: 409,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Build email and password
    const email = `${String(fullName).toLowerCase().replace(/\s+/g, '')}@system.local`;
    const dob = new Date(dateOfBirth);
    const day = String(dob.getDate()).padStart(2, '0');
    const month = String(dob.getMonth() + 1).padStart(2, '0');
    const year = dob.getFullYear();
    const password = `${day}${month}${year}`;

    // Check if user exists (edge case when roles table had none but auth has one)
    let userId: string | null = null;
    try {
      const { data, error: signUpErr } = await supabaseAuth.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName } },
      });
      if (signUpErr) throw signUpErr;
      userId = data.user?.id ?? null;
      if (!userId) throw new Error('Failed to get user id after signUp');
    } catch (e) {
      console.error('signUp failed, attempting signIn fallback', e);
      const { data: login, error: loginErr } = await supabaseAuth.auth.signInWithPassword({ email, password });
      if (loginErr) {
        console.error('signIn fallback failed', loginErr);
        throw e;
      }
      userId = login.user?.id ?? null;
      if (!userId) throw e;
    }

    // Compute next member number for owner (S01, S02, etc.)
    const { data: allMembers } = await supabaseAdmin
      .from('members')
      .select('member_number')
      .ilike('position', 'owner');
    
    let maxNum = 0;
    for (const m of allMembers || []) {
      const numStr = m.member_number || '';
      // Extract numeric part after 'S' prefix
      const n = parseInt(numStr.replace(/^S/, '') || '0', 10);
      if (!isNaN(n) && n > maxNum) maxNum = n;
    }
    const nextNumber = 'S' + String(maxNum + 1).padStart(2, '0');

    // Insert member and link user_id
    const { data: member, error: memberErr } = await supabaseAdmin
      .from('members')
      .insert({
        member_number: nextNumber,
        full_name: fullName,
        position: 'owner',
        phone: phone ?? null,
        nik: nik ?? null,
        address: address ?? null,
        date_of_birth: `${year}-${month}-${day}`,
        user_id: userId,
        photo_url: photoUrl ?? null,
      })
      .select()
      .single();
    if (memberErr) throw memberErr;

    // Upsert profile
    const { error: profileErr } = await supabaseAdmin
      .from('profiles')
      .upsert({ id: userId, full_name: fullName, email }, { onConflict: 'id' });
    if (profileErr) {
      console.error('Profile upsert error:', profileErr);
      throw profileErr;
    }

    // Delete existing roles for this user first (cleanup)
    await supabaseAdmin
      .from('user_roles')
      .delete()
      .eq('user_id', userId);

    // Insert owner role
    const { error: roleErr } = await supabaseAdmin
      .from('user_roles')
      .insert({ user_id: userId, role: 'owner' });
    if (roleErr) {
      console.error('Role insert error:', roleErr);
      throw roleErr;
    }

    // Save supercode to app_settings
    const { error: settingsErr } = await supabaseAdmin
      .from('app_settings')
      .upsert({
        user_id: userId,
        super_code: supercode,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'user_id'
      });
    
    if (settingsErr) {
      console.error('Error saving supercode:', settingsErr);
      throw settingsErr;
    }

    console.log('✅ Owner account created successfully with supercode and photo');

    return new Response(
      JSON.stringify({ success: true, userId, email, message: 'Owner account created successfully' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error create-first-owner:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});