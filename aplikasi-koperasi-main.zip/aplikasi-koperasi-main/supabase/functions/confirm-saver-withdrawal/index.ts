import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { withdrawal_id, pin, action } = await req.json();

    if (!withdrawal_id) {
      return new Response(
        JSON.stringify({ error: "withdrawal_id is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!action || !["confirm", "cancel"].includes(action)) {
      return new Response(
        JSON.stringify({ error: "action must be 'confirm' or 'cancel'" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get the pending withdrawal
    const { data: withdrawal, error: fetchError } = await supabase
      .from("saver_pending_withdrawals")
      .select("*, savers!inner(id, full_name, balance, pin_hash)")
      .eq("id", withdrawal_id)
      .eq("status", "pending")
      .single();

    if (fetchError || !withdrawal) {
      console.error("Fetch error:", fetchError);
      return new Response(
        JSON.stringify({ error: "Pending withdrawal not found or already processed" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const MAX_PIN_ATTEMPTS = 3;
    const currentAttempts = withdrawal.failed_pin_attempts || 0;

    // Check if expired
    const expiresAt = new Date(withdrawal.expires_at);
    const now = new Date();
    if (now > expiresAt) {
      // Auto-expire
      await supabase
        .from("saver_pending_withdrawals")
        .update({ status: "expired", updated_at: now.toISOString() })
        .eq("id", withdrawal_id);

      return new Response(
        JSON.stringify({ error: "Withdrawal request has expired" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Handle cancel action
    if (action === "cancel") {
      const { error: cancelError } = await supabase
        .from("saver_pending_withdrawals")
        .update({
          status: "cancelled",
          cancelled_at: now.toISOString(),
          cancel_reason: "Dibatalkan oleh debitur",
          updated_at: now.toISOString(),
        })
        .eq("id", withdrawal_id);

      if (cancelError) {
        console.error("Cancel error:", cancelError);
        return new Response(
          JSON.stringify({ error: "Failed to cancel withdrawal" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`Withdrawal ${withdrawal_id} cancelled by saver`);
      return new Response(
        JSON.stringify({ success: true, message: "Penarikan berhasil dibatalkan" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Handle confirm action - requires PIN verification
    if (!pin) {
      return new Response(
        JSON.stringify({ error: "PIN is required for confirmation" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get saver's PIN hash
    const storedPinHash = withdrawal.savers?.pin_hash;
    if (!storedPinHash) {
      return new Response(
        JSON.stringify({ error: "PIN not set for this saver. Please set your PIN first." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify PIN (must match the hashing used by update-saver-pin / verify-saver-pin)
    const PIN_SALT = "saver_pin_salt_2024";

    const encoder = new TextEncoder();

    // Current scheme (salted SHA-256)
    const saltedData = encoder.encode(String(pin) + PIN_SALT);
    const saltedHashBuffer = await crypto.subtle.digest("SHA-256", saltedData);
    const saltedHashArray = Array.from(new Uint8Array(saltedHashBuffer));
    const saltedPinHash = saltedHashArray.map((b) => b.toString(16).padStart(2, "0")).join("");

    // Backward-compat (older scheme: unsalted SHA-256) - kept to avoid breaking legacy PINs
    const legacyData = encoder.encode(String(pin));
    const legacyHashBuffer = await crypto.subtle.digest("SHA-256", legacyData);
    const legacyHashArray = Array.from(new Uint8Array(legacyHashBuffer));
    const legacyPinHash = legacyHashArray.map((b) => b.toString(16).padStart(2, "0")).join("");

    // Compare with stored hash
    const isPinValid = saltedPinHash === storedPinHash || legacyPinHash === storedPinHash;

    if (!isPinValid) {
      const newAttempts = currentAttempts + 1;
      console.log(`PIN verification failed for withdrawal: ${withdrawal_id}. Attempt ${newAttempts}/${MAX_PIN_ATTEMPTS}`);
      
      // Check if max attempts reached
      if (newAttempts >= MAX_PIN_ATTEMPTS) {
        // Auto-cancel the withdrawal due to too many failed attempts
        await supabase
          .from("saver_pending_withdrawals")
          .update({
            status: "cancelled",
            cancelled_at: now.toISOString(),
            cancel_reason: `Dibatalkan otomatis: ${MAX_PIN_ATTEMPTS}x percobaan PIN gagal`,
            failed_pin_attempts: newAttempts,
            updated_at: now.toISOString(),
          })
          .eq("id", withdrawal_id);
        
        console.log(`Withdrawal ${withdrawal_id} auto-cancelled due to ${MAX_PIN_ATTEMPTS} failed PIN attempts`);
        
        return new Response(
          JSON.stringify({
            success: false,
            error: `PIN salah ${MAX_PIN_ATTEMPTS}x. Transaksi penarikan dibatalkan untuk keamanan.`,
            cancelled: true,
            attempts: newAttempts,
            max_attempts: MAX_PIN_ATTEMPTS,
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Update failed attempts count
      await supabase
        .from("saver_pending_withdrawals")
        .update({
          failed_pin_attempts: newAttempts,
          updated_at: now.toISOString(),
        })
        .eq("id", withdrawal_id);

      const remainingAttempts = MAX_PIN_ATTEMPTS - newAttempts;
      return new Response(
        JSON.stringify({
          success: false,
          error: `PIN salah. Sisa ${remainingAttempts} percobaan sebelum transaksi dibatalkan.`,
          attempts: newAttempts,
          max_attempts: MAX_PIN_ATTEMPTS,
          remaining: remainingAttempts,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("PIN verified successfully for withdrawal:", withdrawal_id);

    // Check if saver has sufficient balance
    const saverBalance = withdrawal.savers?.balance || 0;
    if (saverBalance < withdrawal.amount) {
      return new Response(
        JSON.stringify({ error: "Saldo tidak mencukupi" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Start transaction: update pending withdrawal and create actual withdrawal
    const saverId = withdrawal.saver_id;
    const amount = withdrawal.amount;

    // 1. Update pending withdrawal status
    const { error: updatePendingError } = await supabase
      .from("saver_pending_withdrawals")
      .update({
        status: "confirmed",
        confirmed_at: now.toISOString(),
        updated_at: now.toISOString(),
      })
      .eq("id", withdrawal_id);

    if (updatePendingError) {
      console.error("Update pending error:", updatePendingError);
      return new Response(
        JSON.stringify({ error: "Failed to confirm withdrawal" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Insert into saver_withdrawals with status "pending" (requires admin/owner verification)
    const { error: insertWithdrawalError } = await supabase
      .from("saver_withdrawals")
      .insert({
        saver_id: saverId,
        amount: amount,
        withdrawal_date: now.toISOString().split("T")[0],
        notes: withdrawal.notes,
        status: "pending", // Changed from "completed" - requires verification by admin/owner
        processed_by: null, // Will be set when admin/owner verifies
        payment_method: withdrawal.payment_method,
        payment_details: withdrawal.payment_details,
      });

    if (insertWithdrawalError) {
      console.error("Insert withdrawal error:", insertWithdrawalError);
      // Rollback pending status
      await supabase
        .from("saver_pending_withdrawals")
        .update({ status: "pending", updated_at: now.toISOString() })
        .eq("id", withdrawal_id);

      return new Response(
        JSON.stringify({ error: "Failed to process withdrawal" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Withdrawal ${withdrawal_id} confirmed by PIN. Awaiting admin/owner verification. Amount: ${amount}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Penarikan berhasil dikonfirmasi. Menunggu verifikasi admin.",
        amount: amount,
        awaiting_verification: true
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: unknown) {
    console.error("Error in confirm-saver-withdrawal:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
