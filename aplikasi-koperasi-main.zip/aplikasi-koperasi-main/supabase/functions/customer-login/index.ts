import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function formatDobPassword(dateOfBirth: string): string {
  const dob = new Date(dateOfBirth);
  const day = String(dob.getDate()).padStart(2, "0");
  const month = String(dob.getMonth() + 1).padStart(2, "0");
  const year = dob.getFullYear();
  return `${day}${month}${year}`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  console.log("[customer-login] Start");

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    if (!supabaseUrl || !serviceKey) {
      throw new Error("Missing backend configuration");
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    const body = await req.json().catch(() => ({}));
    const rawIdNumber = String(body?.idNumber ?? "");
    const rawPassword = String(body?.password ?? "");

    const idNumber = rawIdNumber.trim().toUpperCase();
    const typedPassword = rawPassword.trim();

    if (!idNumber || !typedPassword) {
      return new Response(
        JSON.stringify({ success: false, error: "Missing credentials" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        },
      );
    }

    // Look up customer safely using service role
    const { data: customer, error: customerError } = await supabaseAdmin
      .from("customers")
      .select("id, full_name, id_number, date_of_birth, login_email, user_id, status")
      .eq("id_number", idNumber)
      .maybeSingle();

    if (customerError) {
      console.error("[customer-login] Customer lookup error:", customerError.message);
      throw new Error("Customer lookup failed");
    }

    if (!customer) {
      return new Response(
        JSON.stringify({ success: false, notFound: true }),
        { headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    if (!customer.date_of_birth) {
      return new Response(
        JSON.stringify({ success: false, code: "DATA_INCOMPLETE" }),
        { headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    const expectedPassword = formatDobPassword(customer.date_of_birth);
    if (typedPassword !== expectedPassword) {
      return new Response(
        JSON.stringify({ success: false, code: "INVALID_CREDENTIALS" }),
        { headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    // If customer already linked to an auth user, trust that mapping and return its email
    if (customer.user_id) {
      const { data: authUser, error: authUserError } = await supabaseAdmin.auth.admin
        .getUserById(customer.user_id);

      if (!authUserError && authUser?.user?.email) {
        const email = authUser.user.email;

        if (customer.login_email !== email) {
          await supabaseAdmin
            .from("customers")
            .update({ login_email: email })
            .eq("id", customer.id);
        }

        const duration = Date.now() - startTime;
        console.log(`[customer-login] Linked user OK in ${duration}ms`);

        return new Response(
          JSON.stringify({ success: true, email, fullName: customer.full_name }),
          { headers: { "Content-Type": "application/json", ...corsHeaders } },
        );
      }

      // If mapping is broken, clear it and fall through to recreate
      console.warn("[customer-login] Broken user_id mapping, clearing and recreating");
      await supabaseAdmin
        .from("customers")
        .update({ user_id: null, login_email: null })
        .eq("id", customer.id);
    }

    // Create (or recreate) an auth user and link it to this customer
    // Use the SAME format as create-customer-auth: {NIK}@customer.local (uppercase to match id_number)
    const primaryEmail = `${customer.id_number}@customer.local`;
    
    const createUser = async (email: string) => {
      return await supabaseAdmin.auth.admin.createUser({
        email,
        password: expectedPassword,
        email_confirm: true,
        user_metadata: { full_name: customer.full_name, is_customer: true },
      });
    };

    let usedEmail = primaryEmail;
    let authUserId: string | null = null;

    // First try with primary email (same as create-customer-auth)
    let { data: created, error: createError } = await createUser(usedEmail);

    if (createError) {
      const msg = createError.message || "";
      const isAlreadyExists =
        msg.includes("already been registered") || msg.includes("already exists");
      const isDbError = msg.includes("Database error");

      // If email already exists, try to sign in with it
      if (isAlreadyExists) {
        // The auth user exists - try to get it by email and use it
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = existingUsers?.users?.find(u => u.email === usedEmail);
        
        if (existingUser) {
          authUserId = existingUser.id;
          console.log("[customer-login] Using existing auth user:", authUserId);
        } else {
          // Use fallback with timestamp
          usedEmail = `${customer.id_number}-${Date.now()}@customer.local`;
          console.log("[customer-login] Email exists but not found, using unique:", usedEmail);

          const { data: fallback, error: fallbackError } = await createUser(usedEmail);
          if (fallbackError) {
            console.error("[customer-login] Fallback create failed:", fallbackError.message);
            throw new Error("Failed to create account");
          }
          authUserId = fallback.user?.id ?? null;
        }
      } else if (isDbError) {
        // Database error (corrupt user) - use timestamp-based unique email
        usedEmail = `${customer.id_number}-${Date.now()}@customer.local`;
        console.log("[customer-login] DB error, using unique email:", usedEmail);

        const { data: fallback, error: fallbackError } = await createUser(usedEmail);
        if (fallbackError) {
          console.error("[customer-login] Fallback create failed:", fallbackError.message);
          throw new Error("Failed to create account");
        }
        authUserId = fallback.user?.id ?? null;
      } else {
        console.error("[customer-login] Create user failed:", msg);
        throw new Error("Failed to create account");
      }
    } else {
      authUserId = created.user?.id ?? null;
    }

    if (!authUserId) {
      throw new Error("Auth user id missing");
    }

    const [updateCustomer, upsertRole] = await Promise.all([
      supabaseAdmin
        .from("customers")
        .update({ user_id: authUserId, login_email: usedEmail })
        .eq("id", customer.id),
      supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: authUserId, role: "customer" }, { onConflict: "user_id,role" }),
    ]);

    if (updateCustomer.error) {
      console.error("[customer-login] Customer update failed:", updateCustomer.error.message);
      throw new Error("Failed to link customer account");
    }

    if (upsertRole.error) {
      console.warn("[customer-login] Role upsert failed:", upsertRole.error.message);
    }

    const duration = Date.now() - startTime;
    console.log(`[customer-login] SUCCESS in ${duration}ms`);

    return new Response(
      JSON.stringify({
        success: true,
        email: usedEmail,
        fullName: customer.full_name,
      }),
      { headers: { "Content-Type": "application/json", ...corsHeaders } },
    );
  } catch (error) {
    const duration = Date.now() - startTime;
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error(`[customer-login] FAILED after ${duration}ms:`, message);

    return new Response(
      JSON.stringify({ success: false, error: message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } },
    );
  }
});
