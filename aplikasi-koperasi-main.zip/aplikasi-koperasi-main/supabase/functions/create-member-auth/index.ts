import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Hash kasir PIN using same algorithm as database function
async function hashKasirPin(pin: string): Promise<string> {
  const salt = 'K4S1R_P1N_S4LT_2024';
  const combined = pin + salt;
  const encoder = new TextEncoder();
  const data = encoder.encode(combined);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { memberId, fullName, dateOfBirth, position, pin } = await req.json();

    if (!memberId || !fullName || !dateOfBirth) {
      throw new Error("Missing required fields");
    }

    // Clean and normalize full name - trim and collapse multiple spaces
    const cleanFullName = fullName.trim().replace(/\s+/g, ' ');

    // Create email from cleaned member name
    const email = `${cleanFullName.toLowerCase().replace(/\s+/g, '')}@system.local`;
    
    // Format date of birth as password (DDMMYYYY)
    const dob = new Date(dateOfBirth);
    const day = String(dob.getDate()).padStart(2, '0');
    const month = String(dob.getMonth() + 1).padStart(2, '0');
    const year = dob.getFullYear();
    const password = `${day}${month}${year}`;

    let authUserId;

    // Try to create user, handle duplicate gracefully
    const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName }
    });

    if (authError) {
      // If user already exists, try to find them via admin API and update password
      if (authError.message?.includes('already been registered') || authError.message?.includes('User already registered')) {
        console.log('User already registered, attempting to find existing auth user by email:', email);

        const { data: usersData, error: listError } = await supabaseAdmin.auth.admin.listUsers({
          page: 1,
          perPage: 1000,
        });

        if (listError) {
          console.error('Error listing users to resolve existing user:', listError);
          throw new Error(`Database error checking email: ${listError.message}`);
        }

        const existingUser = usersData?.users?.find((u: any) => u.email?.toLowerCase() === email.toLowerCase());

        if (!existingUser) {
          console.error('Existing auth user not found for email despite duplicate error:', email);
          throw new Error(`User email already registered but auth user not found: ${email}`);
        }

        authUserId = existingUser.id;

        // Update the existing user's password to match date of birth
        const { error: updatePasswordError } = await supabaseAdmin.auth.admin.updateUserById(
          authUserId,
          { password }
        );

        if (updatePasswordError) {
          console.error('Error updating password for existing user:', updatePasswordError);
          throw updatePasswordError;
        }

        console.log(`Updated password for existing user: ${email}`);

        // Ensure profile exists / is updated for this auth user
        const { error: upsertProfileError } = await supabaseAdmin
          .from('profiles')
          .upsert({
            id: authUserId,
            full_name: cleanFullName,
            email,
          });

        if (upsertProfileError) {
          console.error('Error upserting profile for existing user:', upsertProfileError);
          throw new Error(`Database error upserting profile for existing user: ${upsertProfileError.message}`);
        }
      } else {
        console.error('Error creating auth user:', authError);
        throw authError;
      }
    } else {
      authUserId = authUser.user.id;
    }

    // Update member with user_id and PIN hash (if Kasir)
    const updateData: any = { user_id: authUserId };
    if (position?.toLowerCase() === 'kasir' && pin) {
      // Hash the PIN before storing for security
      const hashedPin = await hashKasirPin(pin);
      updateData.pin = hashedPin;
      console.log('Kasir PIN hashed and stored securely');
    }
    
    const { error: updateError } = await supabaseAdmin
      .from('members')
      .update(updateData)
      .eq('id', memberId);

    if (updateError) throw updateError;

    // Update member with cleaned name
    const { error: memberUpdateError } = await supabaseAdmin
      .from('members')
      .update({ full_name: cleanFullName })
      .eq('id', memberId);

    if (memberUpdateError) {
      console.warn('Failed to update member name:', memberUpdateError);
    }

    // Upsert profile
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .upsert({ 
        id: authUserId, 
        full_name: cleanFullName, 
        email 
      });

    if (profileError) throw profileError;

    // Determine role based on position
    let role = 'sales';
    const posLower = position?.toLowerCase() || '';
    if (posLower === 'owner') role = 'owner';
    else if (posLower === 'admin') role = 'admin';
    else if (posLower === 'kasir') role = 'kasir';
    
    console.log(`Assigning role: ${role} for position: ${position}`);

    // SECURITY CHECK: Verify this user is NOT already a customer
    // Customers should NEVER have their role overwritten by member auth creation
    const { data: existingCustomer } = await supabaseAdmin
      .from('customers')
      .select('id, id_number, full_name')
      .eq('user_id', authUserId)
      .maybeSingle();
    
    if (existingCustomer) {
      console.error(`SECURITY BLOCK: User ${authUserId} is already a customer (${existingCustomer.id_number}). Cannot assign member role.`);
      throw new Error(`User sudah terdaftar sebagai nasabah (${existingCustomer.id_number}). Tidak dapat membuat akun anggota.`);
    }

    // Use upsert to handle existing roles gracefully
    // This automatically handles the one_role_per_user constraint
    const { error: roleError } = await supabaseAdmin
      .from('user_roles')
      .upsert({ 
        user_id: authUserId, 
        role 
      }, {
        onConflict: 'user_id',
        ignoreDuplicates: false
      });

    if (roleError) {
      console.error('Failed to assign member role:', roleError);
      throw roleError;
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        userId: authUserId,
        email,
        password, // return DOB-based password (DDMMYYYY)
        message: 'Akun berhasil dibuat' 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : 'An unknown error occurred';
    console.error('Error creating member auth:', message);
    return new Response(
      JSON.stringify({ error: message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  }
});
