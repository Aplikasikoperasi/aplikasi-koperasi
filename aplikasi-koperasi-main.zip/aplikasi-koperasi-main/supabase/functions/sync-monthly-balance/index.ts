import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('[sync-monthly-balance] Starting sync...');

    // Get incentive settings to check activation date for regular incentives
    const { data: settings } = await supabase
      .from('incentive_settings')
      .select('regular_incentive_enabled_at, year_end_bonus_enabled_at')
      .single();

    // Use regular_incentive_enabled_at for regular balance syncing
    const activationDate = settings?.regular_incentive_enabled_at 
      ? new Date(settings.regular_incentive_enabled_at) 
      : null;

    console.log('[sync-monthly-balance] Regular incentive activation date:', activationDate?.toISOString() || 'Not set');

    // Get all transactions grouped by member and period
    // Only include transactions with period_month >= activation date
    const { data: transactions, error: transError } = await supabase
      .from('member_balance_transactions')
      .select('member_id, period_month, amount, type, balance_type')
      .order('period_month', { ascending: true });

    if (transError) {
      console.error('[sync-monthly-balance] Error fetching transactions:', transError);
      throw transError;
    }

    // Group by member_id and period_month
    const grouped = new Map<string, Map<string, { earned: number; withdrawn: number }>>();

    for (const trans of transactions || []) {
      if (!trans.period_month) continue;
      
      // Skip transactions with period_month before activation date
      if (activationDate) {
        const transPeriodDate = new Date(trans.period_month + '-01');
        if (transPeriodDate < activationDate) {
          console.log('[sync-monthly-balance] Skipping historical transaction before activation:', {
            period_month: trans.period_month,
            activation_date: activationDate.toISOString()
          });
          continue;
        }
      }
      
      const memberKey = trans.member_id;
      if (!grouped.has(memberKey)) {
        grouped.set(memberKey, new Map());
      }
      
      const periodMap = grouped.get(memberKey)!;
      if (!periodMap.has(trans.period_month)) {
        periodMap.set(trans.period_month, { earned: 0, withdrawn: 0 });
      }
      
      const periodData = periodMap.get(trans.period_month)!;
      
      // Only regular balance type counts for monthly summary
      if (trans.balance_type === 'regular') {
        if (trans.type === 'withdrawal') {
          periodData.withdrawn += Math.abs(Number(trans.amount));
        } else {
          periodData.earned += Number(trans.amount);
        }
      }
    }

    // Upsert monthly summaries
    const summaries = [];
    for (const [memberId, periodMap] of grouped.entries()) {
      for (const [periodMonth, data] of periodMap.entries()) {
        const availableBalance = data.earned - data.withdrawn;
        
        // Check if there are overdue installments in this period
        const { data: hasOverdue } = await supabase
          .rpc('check_member_overdue_in_period', {
            p_member_id: memberId,
            p_period_month: periodMonth
          });

        summaries.push({
          member_id: memberId,
          period_month: periodMonth,
          total_earned: data.earned,
          total_withdrawn: data.withdrawn,
          available_balance: availableBalance,
          is_held: hasOverdue || false,
          hold_reason: hasOverdue ? `Ada angsuran menunggak di periode ${periodMonth}` : null,
          updated_at: new Date().toISOString()
        });
      }
    }

    if (summaries.length > 0) {
      const { error: upsertError } = await supabase
        .from('member_monthly_balance_summary')
        .upsert(summaries, {
          onConflict: 'member_id,period_month',
          ignoreDuplicates: false
        });

      if (upsertError) {
        console.error('[sync-monthly-balance] Error upserting summaries:', upsertError);
        throw upsertError;
      }
    }

    console.log(`[sync-monthly-balance] Synced ${summaries.length} monthly summaries`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Synced ${summaries.length} monthly summaries`,
        summaries_count: summaries.length
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200
      }
    );
  } catch (err) {
    console.error('[sync-monthly-balance] Fatal error:', err);
    const message = err instanceof Error ? err.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({
        success: false,
        error: message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});
