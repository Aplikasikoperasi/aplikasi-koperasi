import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting Google Drive upload...');

    // Get payload from request body (supports direct backupData or filename-only)
    const body = await req.json().catch(() => ({} as any));
    const { filename, backupData } = body as { filename?: string; backupData?: unknown };

    if (!filename) {
      throw new Error('Missing filename');
    }

    let finalBackupData: any;

    if (backupData) {
      console.log('Using backupData from request body (no storage download)');
      finalBackupData = backupData;
    } else {
      console.log(`Downloading backup file from Supabase Storage: ${filename}`);
      
      // Download backup from Supabase Storage (legacy mode)
      const { data: fileData, error: downloadError } = await supabase.storage
        .from('backups')
        .download(filename);
  
      if (downloadError || !fileData) {
        console.error('Storage download error:', downloadError);
        throw new Error(
          `Failed to download backup from storage: ${
            (downloadError as any)?.message || JSON.stringify(downloadError) || 'File not found or bucket does not exist'
          }`
        );
      }
      
      if (!fileData || fileData.size === 0) {
        throw new Error(`Downloaded file is empty: ${filename}`);
      }
  
      // Convert blob to JSON
      finalBackupData = JSON.parse(await fileData.text());
      console.log('Backup file downloaded and parsed successfully');
    }

    // Get Google Drive settings
    const { data: settings, error: settingsError } = await supabase
      .from('google_drive_settings')
      .select('*')
      .maybeSingle();

    if (settingsError) {
      throw new Error(`Failed to fetch settings: ${settingsError.message}`);
    }

    if (!settings || !settings.is_enabled) {
      return new Response(
        JSON.stringify({ message: 'Google Drive backup is disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check auth mode and get access token
    const authMode = settings.auth_mode || 'service_account';
    let access_token: string;

    if (authMode === 'oauth') {
      // OAuth mode
      console.log('Using OAuth authentication');
      
      if (!settings.oauth_access_token || !settings.oauth_refresh_token) {
        throw new Error('OAuth tokens not available. Please re-authenticate.');
      }

      if (!settings.folder_id) {
        throw new Error('Folder ID is required');
      }

      // Check if token expired
      const tokenExpiry = settings.oauth_token_expiry ? new Date(settings.oauth_token_expiry) : null;
      const now = new Date();

      if (!tokenExpiry || now >= tokenExpiry) {
        console.log('OAuth token expired, refreshing...');
        
        // Refresh token
        const { data: refreshData, error: refreshError } = await supabase.functions.invoke(
          'google-drive-refresh-token'
        );

        if (refreshError || !refreshData?.success) {
          throw new Error('Failed to refresh OAuth token. Please re-authenticate.');
        }

        // Reload settings to get new token
        const { data: newSettings } = await supabase
          .from('google_drive_settings')
          .select('oauth_access_token')
          .maybeSingle();

        access_token = newSettings?.oauth_access_token || '';
      } else {
        access_token = settings.oauth_access_token;
      }

    } else {
      // Service account mode
      console.log('Using service account authentication');
      
      if (!settings.client_email || !settings.private_key || !settings.folder_id) {
        throw new Error('Service account credentials are incomplete');
      }

      // Create JWT for Google OAuth2
      const now = Math.floor(Date.now() / 1000);
      const jwtHeader = btoa(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
      const jwtClaim = btoa(JSON.stringify({
        iss: settings.client_email,
        scope: 'https://www.googleapis.com/auth/drive.file',
        aud: 'https://oauth2.googleapis.com/token',
        exp: now + 3600,
        iat: now,
      }));

      const jwtData = `${jwtHeader}.${jwtClaim}`;
      
      // Extract private key properly
      let privateKeyStr = settings.private_key;
      
      if (typeof privateKeyStr === 'string' && privateKeyStr.trim().startsWith('{')) {
        try {
          const keyJson = JSON.parse(privateKeyStr);
          privateKeyStr = keyJson.private_key;
          console.log('Extracted private key from JSON object');
        } catch (e) {
          console.error('Failed to parse private_key JSON:', e);
          throw new Error('Invalid private key format - cannot parse JSON');
        }
      }
      
      if (!privateKeyStr || !privateKeyStr.includes('BEGIN PRIVATE KEY')) {
        throw new Error('Invalid private key - missing BEGIN PRIVATE KEY marker');
      }
      
      const privateKey = privateKeyStr.replace(/\\n/g, '\n');
      
      // Import the private key
      const pemHeader = '-----BEGIN PRIVATE KEY-----';
      const pemFooter = '-----END PRIVATE KEY-----';
      const pemContents = privateKey
        .replace(pemHeader, '')
        .replace(pemFooter, '')
        .replace(/\s/g, '');
      
      const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
      
      const cryptoKey = await crypto.subtle.importKey(
        'pkcs8',
        binaryDer,
        {
          name: 'RSASSA-PKCS1-v1_5',
          hash: 'SHA-256',
        },
        false,
        ['sign']
      );

      // Sign the JWT
      const encoder = new TextEncoder();
      const signature = await crypto.subtle.sign(
        'RSASSA-PKCS1-v1_5',
        cryptoKey,
        encoder.encode(jwtData)
      );

      const jwtSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');

      const jwt = `${jwtData}.${jwtSignature}`;

      // Exchange JWT for access token
      console.log('Exchanging JWT for access token...');
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
      });

      if (!tokenResponse.ok) {
        const errorText = await tokenResponse.text();
        throw new Error(`Failed to get access token: ${errorText}`);
      }

      const tokenData = await tokenResponse.json();
      access_token = tokenData.access_token;
      console.log('Access token obtained successfully');
    }

    // Upload file to Google Drive
    console.log('Uploading file to Google Drive...');
    const boundary = '-------314159265358979323846';

    // Normalize Google Drive folder ID
    const rawFolder = settings.folder_id as string;
    const folderId = (() => {
      if (!rawFolder) return '';
      try {
        const m = rawFolder.match(/\/folders\/([a-zA-Z0-9_-]+)/);
        if (m && m[1]) return m[1];
        if (rawFolder.startsWith('http')) {
          const u = new URL(rawFolder);
          const id = u.searchParams.get('id');
          if (id) return id;
        }
      } catch (_) { /* ignore */ }
      return rawFolder.trim();
    })();

    if (!folderId || folderId.includes('http')) {
      throw new Error('Invalid Google Drive folder ID');
    }

    const metadata = {
      name: filename,
      parents: [folderId],
      mimeType: 'application/json',
    };

    const multipartBody = [
      `--${boundary}`,
      'Content-Type: application/json; charset=UTF-8',
      '',
      JSON.stringify(metadata),
      `--${boundary}`,
      'Content-Type: application/json',
      '',
      JSON.stringify(finalBackupData, null, 2),
      `--${boundary}--`,
    ].join('\r\n');

    const uploadResponse = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body: multipartBody,
      }
    );

    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text();
      throw new Error(`Failed to upload to Google Drive: ${errorText}`);
    }

    const uploadResult = await uploadResponse.json();
    console.log('File uploaded successfully:', uploadResult.id);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Backup uploaded to Google Drive successfully',
        fileId: uploadResult.id,
        filename,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Google Drive upload error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
