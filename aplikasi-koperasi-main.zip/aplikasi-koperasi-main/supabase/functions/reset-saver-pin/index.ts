import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization") ?? "";

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Verify that the requester is authenticated
    const { data: authData, error: authError } = await supabaseAuth.auth.getUser();
    const user = authData?.user;

    if (authError || !user) {
      console.log("Auth error or no user:", authError);
      return new Response(
        JSON.stringify({ success: false, message: "Tidak diizinkan - tidak terautentikasi" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if the user is admin or owner
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .maybeSingle();

    if (roleError) {
      console.error("Role check error:", roleError);
      throw roleError;
    }

    const userRole = roleData?.role;
    const isAdminOrOwner = userRole === "admin" || userRole === "owner";

    if (!isAdminOrOwner) {
      console.log("User role:", userRole, "- not authorized");
      return new Response(
        JSON.stringify({ success: false, message: "Tidak diizinkan - hanya admin/owner yang bisa reset PIN" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { saver_id } = await req.json();

    if (!saver_id) {
      return new Response(
        JSON.stringify({ success: false, message: "ID debitur tidak ditemukan" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get saver info for logging
    const { data: saver, error: saverError } = await supabaseAdmin
      .from("savers")
      .select("full_name, saver_number, pin_hash")
      .eq("id", saver_id)
      .maybeSingle();

    if (saverError) {
      throw saverError;
    }

    if (!saver) {
      return new Response(
        JSON.stringify({ success: false, message: "Debitur tidak ditemukan" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!saver.pin_hash) {
      return new Response(
        JSON.stringify({ success: false, message: "Debitur belum memiliki PIN" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Reset PIN by setting pin_hash to null
    const { error: updateError } = await supabaseAdmin
      .from("savers")
      .update({ pin_hash: null })
      .eq("id", saver_id);

    if (updateError) {
      throw updateError;
    }

    // Get admin/owner name for logging
    const { data: memberData } = await supabaseAdmin
      .from("members")
      .select("full_name")
      .eq("user_id", user.id)
      .maybeSingle();

    const adminName = memberData?.full_name || user.email || "Unknown";

    // Log the action
    await supabaseAdmin.from("system_logs").insert({
      action: "reset_saver_pin",
      category: "security",
      description: `PIN debitur ${saver.full_name} (${saver.saver_number}) direset oleh ${adminName}`,
      user_id: user.id,
      user_name: adminName,
      metadata: {
        saver_id,
        saver_name: saver.full_name,
        saver_number: saver.saver_number,
        reset_by: adminName,
      },
    });

    console.log(`PIN reset successful for saver ${saver.full_name} by ${adminName}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `PIN debitur ${saver.full_name} berhasil direset` 
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error resetting PIN:", error);
    return new Response(
      JSON.stringify({ success: false, message: "Terjadi kesalahan server" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
