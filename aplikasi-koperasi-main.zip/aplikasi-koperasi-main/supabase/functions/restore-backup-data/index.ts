import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RestoreReport {
  step: string;
  status: 'success' | 'error' | 'in_progress';
  message: string;
  details?: any;
}

interface RestoreSummary {
  [tableName: string]: { inserted: number; updated: number; failed: number; skipped: number };
}

// Background restore function
async function performRestore(
  progressId: string,
  backupData: any,
  supabaseUrl: string,
  supabaseServiceKey: string
) {
  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  
  const reports: RestoreReport[] = [];
  const summary: RestoreSummary = {};

  try {
    console.log('🚀 Starting COMPREHENSIVE RESTORE process...');
    console.log('📊 Backup version:', backupData.version || '1.0');
    console.log('📊 Backup stats:', backupData.stats || 'No stats available');

    // Define restore order (respecting foreign keys)
    const restoreOrder = [
      'profiles',
      'members',
      'customers',
      'credit_applications',
      'installments',
      'payments',
      'blocked_customers',
      'bank_accounts',
      'member_balance_transactions',
      'member_balance_withdrawals',
      'member_monthly_balance_summary',
      'customer_messages',
      'member_messages',
      'customer_change_requests',
      'customer_restoration_requests',
      'whatsapp_message_logs',
      'system_logs',
    ];

    // Initialize summary for each table
    restoreOrder.forEach(table => {
      summary[table] = { inserted: 0, updated: 0, failed: 0, skipped: 0 };
    });

    // Update progress
    await supabase
      .from('restore_progress')
      .update({
        status: 'Memulai proses restore komprehensif',
        last_updated: new Date().toISOString(),
      })
      .eq('id', progressId);

    // CLEANING STEP: Delete old installments & payments before restore
    console.log('\n🧹 CLEANING STEP: Removing old installments & payments...');
    const applicationsInBackup = backupData.data.credit_applications || [];
    if (applicationsInBackup.length > 0) {
      const appIds = applicationsInBackup.map((a: any) => a.id);
      
      // Delete old payments first (foreign key constraint)
      const { error: deletePaymentsError, count: deletedPaymentsCount } = await supabase
        .from('payments')
        .delete()
        .in('application_id', appIds);
      
      if (deletePaymentsError) {
        console.error('⚠️ Failed to delete old payments:', deletePaymentsError);
      } else {
        console.log(`✅ Deleted ${deletedPaymentsCount || 0} old payment records`);
      }
      
      // Delete old installments
      const { error: deleteInstallmentsError, count: deletedInstallmentsCount } = await supabase
        .from('installments')
        .delete()
        .in('application_id', appIds);
      
      if (deleteInstallmentsError) {
        console.error('⚠️ Failed to delete old installments:', deleteInstallmentsError);
      } else {
        console.log(`✅ Deleted ${deletedInstallmentsCount || 0} old installment records`);
      }
      
      await supabase
        .from('restore_progress')
        .update({
          status: `Cleaning completed: ${deletedInstallmentsCount || 0} installments, ${deletedPaymentsCount || 0} payments removed`,
          last_updated: new Date().toISOString(),
        })
        .eq('id', progressId);
    }

    // Restore each table in order
    for (const tableName of restoreOrder) {
      const tableData = backupData.data[tableName] || [];
      
      if (tableData.length === 0) {
        console.log(`⏭️ Skipping ${tableName} (no data)`);
        continue;
      }

      console.log(`\n📋 Restoring ${tableName} (${tableData.length} records)...`);
      
      reports.push({
        step: `Restore ${tableName}`,
        status: 'in_progress',
        message: `Memulihkan data ${tableName}...`,
      });

      await supabase
        .from('restore_progress')
        .update({
          status: `Memulihkan ${tableName}`,
          last_updated: new Date().toISOString(),
        })
        .eq('id', progressId);

      // Restore with UPSERT to handle conflicts
      const BATCH_SIZE = 100;
      
      for (let i = 0; i < tableData.length; i += BATCH_SIZE) {
        const batch = tableData.slice(i, i + BATCH_SIZE);
        
        // Try batch upsert
        const { data: upsertData, error: batchError } = await supabase
          .from(tableName)
          .upsert(batch, { 
            onConflict: 'id',
            ignoreDuplicates: false 
          })
          .select('id');
        
        if (batchError) {
          console.warn(`⚠️ Batch upsert failed for ${tableName}, trying individual records...`);
          
          // Fallback: individual upserts
          for (const record of batch) {
            try {
              const { error: singleError } = await supabase
                .from(tableName)
                .upsert(record, { 
                  onConflict: 'id',
                  ignoreDuplicates: false 
                });
              
              if (singleError) {
                // If upsert fails, try to determine if it's update or insert
                const { data: existing } = await supabase
                  .from(tableName)
                  .select('id')
                  .eq('id', record.id)
                  .single();
                
                if (existing) {
                  const { error: updateError } = await supabase
                    .from(tableName)
                    .update(record)
                    .eq('id', record.id);
                  
                  if (updateError) {
                    summary[tableName].failed++;
                    console.error(`❌ Failed to update ${tableName} record ${record.id}:`, updateError.message);
                  } else {
                    summary[tableName].updated++;
                  }
                } else {
                  const { error: insertError } = await supabase
                    .from(tableName)
                    .insert(record);
                  
                  if (insertError) {
                    summary[tableName].failed++;
                    console.error(`❌ Failed to insert ${tableName} record ${record.id}:`, insertError.message);
                  } else {
                    summary[tableName].inserted++;
                  }
                }
              } else {
                // Upsert succeeded - count as insert
                summary[tableName].inserted++;
              }
            } catch (err) {
              summary[tableName].failed++;
              console.error(`❌ Exception for ${tableName} record:`, err);
            }
          }
        } else {
          // Batch upsert succeeded
          summary[tableName].inserted += batch.length;
        }
        
        // Log progress
        if (i > 0 && i % 500 === 0) {
          console.log(`Progress: ${Math.min(i + BATCH_SIZE, tableData.length)}/${tableData.length} ${tableName}`);
        }
      }

      console.log(`✅ ${tableName}: ${summary[tableName].inserted} inserted/updated, ${summary[tableName].failed} failed`);
      
      reports.push({
        step: `Restore ${tableName}`,
        status: summary[tableName].failed > 0 ? 'error' : 'success',
        message: `Inserted/Updated: ${summary[tableName].inserted}, Failed: ${summary[tableName].failed}`,
      });
    }

    // Special handling for credit applications - force status to disbursed
    console.log('\n🔄 Post-processing: Setting credit applications to disbursed...');
    const applications = backupData.data.credit_applications || [];
    if (applications.length > 0) {
      const appIds = applications.map((a: any) => a.id);
      const { error: statusError } = await supabase
        .from('credit_applications')
        .update({ status: 'disbursed' })
        .in('id', appIds);
      
      if (statusError) {
        console.error('⚠️ Failed to update application statuses:', statusError);
      } else {
        console.log(`✅ Updated ${appIds.length} applications to disbursed status`);
      }
    }

    // Calculate totals
    const totalInserted = Object.values(summary).reduce((sum, s) => sum + s.inserted, 0);
    const totalUpdated = Object.values(summary).reduce((sum, s) => sum + s.updated, 0);
    const totalFailed = Object.values(summary).reduce((sum, s) => sum + s.failed, 0);
    
    const hasErrors = totalFailed > 0;

    const finalMessage = hasErrors
      ? `⚠️ Restore completed with ${totalFailed} errors`
      : '✅ Restore completed successfully - ALL data restored!';

    console.log('\n' + '='.repeat(80));
    console.log(finalMessage);
    console.log('='.repeat(80));
    console.log('📊 SUMMARY:');
    console.log(`Total Records: ${totalInserted + totalUpdated + totalFailed}`);
    console.log(`Inserted/Updated: ${totalInserted + totalUpdated}`);
    console.log(`Failed: ${totalFailed}`);
    console.log('\nDetails by table:');
    Object.entries(summary).forEach(([table, stats]) => {
      if (stats.inserted + stats.updated + stats.failed > 0) {
        console.log(`  ${table}: ${stats.inserted + stats.updated} OK, ${stats.failed} failed`);
      }
    });
    console.log('='.repeat(80));

    // Update final progress
    await supabase
      .from('restore_progress')
      .update({
        status: hasErrors ? 'completed_with_errors' : 'completed',
        completed_at: new Date().toISOString(),
        last_updated: new Date().toISOString(),
        error_log: { reports, summary, totals: { inserted: totalInserted, updated: totalUpdated, failed: totalFailed } },
      })
      .eq('id', progressId);

    // Send notification to owners and admins
    try {
      console.log('\n📬 Sending restore completion notifications to owners and admins...');
      
      // Get all owners and admins
      const { data: ownerAdminUsers, error: usersError } = await supabase
        .from('user_roles')
        .select('user_id')
        .in('role', ['owner', 'admin']);
      
      if (usersError) {
        console.error('⚠️ Failed to fetch owner/admin users:', usersError);
      } else if (ownerAdminUsers && ownerAdminUsers.length > 0) {
        // Get member IDs for these users
        const userIds = ownerAdminUsers.map(u => u.user_id);
        const { data: members, error: membersError } = await supabase
          .from('members')
          .select('id, full_name')
          .in('user_id', userIds);
        
        if (membersError) {
          console.error('⚠️ Failed to fetch member details:', membersError);
        } else if (members && members.length > 0) {
          // Build detailed message
          let messageDetails = `<div style="font-family: Arial, sans-serif;">`;
          messageDetails += `<h3 style="color: ${hasErrors ? '#f59e0b' : '#10b981'};">${hasErrors ? '⚠️' : '✅'} Proses Restore Selesai</h3>`;
          messageDetails += `<p><strong>Status:</strong> ${hasErrors ? 'Selesai dengan error' : 'Berhasil sempurna'}</p>`;
          messageDetails += `<hr style="border: 1px solid #e5e7eb; margin: 15px 0;">`;
          
          // Summary stats
          messageDetails += `<h4>📊 Ringkasan Total:</h4>`;
          messageDetails += `<table style="width: 100%; border-collapse: collapse; margin: 10px 0;">`;
          messageDetails += `<tr style="background: #f3f4f6;">`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb;"><strong>✓ Inserted:</strong></td>`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb; color: #10b981;">${totalInserted}</td>`;
          messageDetails += `</tr>`;
          messageDetails += `<tr>`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb;"><strong>↻ Updated:</strong></td>`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb; color: #3b82f6;">${totalUpdated}</td>`;
          messageDetails += `</tr>`;
          messageDetails += `<tr style="background: #f3f4f6;">`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb;"><strong>✗ Failed:</strong></td>`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb; color: #ef4444;">${totalFailed}</td>`;
          messageDetails += `</tr>`;
          messageDetails += `<tr>`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb;"><strong>Total Records:</strong></td>`;
          messageDetails += `<td style="padding: 8px; border: 1px solid #e5e7eb; font-weight: bold;">${totalInserted + totalUpdated + totalFailed}</td>`;
          messageDetails += `</tr>`;
          messageDetails += `</table>`;
          
          // Detailed breakdown per table
          messageDetails += `<hr style="border: 1px solid #e5e7eb; margin: 15px 0;">`;
          messageDetails += `<h4>📋 Detail Per Tabel:</h4>`;
          messageDetails += `<table style="width: 100%; border-collapse: collapse; font-size: 12px;">`;
          messageDetails += `<tr style="background: #1f2937; color: white;">`;
          messageDetails += `<th style="padding: 6px; border: 1px solid #374151; text-align: left;">Tabel</th>`;
          messageDetails += `<th style="padding: 6px; border: 1px solid #374151; text-align: center;">Inserted</th>`;
          messageDetails += `<th style="padding: 6px; border: 1px solid #374151; text-align: center;">Updated</th>`;
          messageDetails += `<th style="padding: 6px; border: 1px solid #374151; text-align: center;">Failed</th>`;
          messageDetails += `<th style="padding: 6px; border: 1px solid #374151; text-align: center;">Total</th>`;
          messageDetails += `</tr>`;
          
          let rowCount = 0;
          Object.entries(summary)
            .filter(([_, stats]) => stats.inserted + stats.updated + stats.failed > 0)
            .forEach(([table, stats]) => {
              const bgColor = rowCount % 2 === 0 ? '#f9fafb' : 'white';
              messageDetails += `<tr style="background: ${bgColor};">`;
              messageDetails += `<td style="padding: 6px; border: 1px solid #e5e7eb;">${table}</td>`;
              messageDetails += `<td style="padding: 6px; border: 1px solid #e5e7eb; text-align: center; color: #10b981;">${stats.inserted}</td>`;
              messageDetails += `<td style="padding: 6px; border: 1px solid #e5e7eb; text-align: center; color: #3b82f6;">${stats.updated}</td>`;
              messageDetails += `<td style="padding: 6px; border: 1px solid #e5e7eb; text-align: center; color: ${stats.failed > 0 ? '#ef4444' : '#6b7280'};">${stats.failed}</td>`;
              messageDetails += `<td style="padding: 6px; border: 1px solid #e5e7eb; text-align: center; font-weight: bold;">${stats.inserted + stats.updated + stats.failed}</td>`;
              messageDetails += `</tr>`;
              rowCount++;
            });
          
          messageDetails += `</table>`;
          
          // Footer
          messageDetails += `<hr style="border: 1px solid #e5e7eb; margin: 15px 0;">`;
          messageDetails += `<p style="font-size: 11px; color: #6b7280;">Restore ID: ${progressId}</p>`;
          messageDetails += `<p style="font-size: 11px; color: #6b7280;">Waktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB</p>`;
          messageDetails += `</div>`;
          
          // Send notification to each owner/admin
          const notifications = members.map(member => ({
            member_id: member.id,
            title: hasErrors ? '⚠️ Restore Selesai dengan Error' : '✅ Restore Data Berhasil',
            message: messageDetails,
            type: hasErrors ? 'warning' : 'success',
            metadata: {
              restore_id: progressId,
              total_inserted: totalInserted,
              total_updated: totalUpdated,
              total_failed: totalFailed,
              has_errors: hasErrors,
              completed_at: new Date().toISOString(),
            }
          }));
          
          const { error: notifError } = await supabase
            .from('member_messages')
            .insert(notifications);
          
          if (notifError) {
            console.error('⚠️ Failed to send notifications:', notifError);
          } else {
            console.log(`✅ Sent restore completion notifications to ${members.length} owner(s)/admin(s)`);
          }
        }
      }
    } catch (notifError) {
      console.error('⚠️ Non-critical error sending notifications:', notifError);
      // Don't fail the restore if notification fails
    }

    return {
      success: !hasErrors,
      message: finalMessage,
      reports,
      summary,
      totals: {
        inserted: totalInserted,
        updated: totalUpdated,
        failed: totalFailed,
      }
    };

  } catch (error) {
    console.error('❌ CRITICAL ERROR in restore function:', error);
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    await supabase
      .from('restore_progress')
      .update({
        status: 'failed',
        completed_at: new Date().toISOString(),
        last_updated: new Date().toISOString(),
        error_log: { error: errorMessage, reports, summary },
      })
      .eq('id', progressId);

    throw error;
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('📦 Parsing backup data...');
    const requestBody = await req.json();
    
    const backupData = requestBody.backupData || requestBody;
    
    if (!backupData || !backupData.data) {
      console.error('Invalid backup structure');
      throw new Error('Invalid backup data structure. Expected: { data: { ... } }');
    }

    console.log('✅ Backup data validated');
    console.log('Backup timestamp:', backupData.timestamp);
    console.log('Backup version:', backupData.version || '1.0');

    // Create progress record
    const progressId = crypto.randomUUID();
    const { error: progressError } = await supabase
      .from('restore_progress')
      .insert({
        id: progressId,
        backup_timestamp: backupData.timestamp || new Date().toISOString(),
        total_customers: backupData.data.customers?.length || 0,
        total_applications: backupData.data.credit_applications?.length || 0,
        completed_customers: 0,
        completed_applications: 0,
        status: 'starting',
        started_at: new Date().toISOString(),
        last_updated: new Date().toISOString(),
      });

    if (progressError) {
      console.error('Failed to create progress record:', progressError);
      throw new Error('Failed to initialize restore progress tracking');
    }

    console.log(`✅ Progress tracking started with ID: ${progressId}`);

    // Start background restore
    performRestore(progressId, backupData, supabaseUrl, supabaseServiceKey)
      .catch(err => console.error('Background restore error:', err));

    return new Response(
      JSON.stringify({
        success: true,
        progressId,
        message: 'Comprehensive restore process started in background. Monitor progress using the progress ID.',
        version: backupData.version || '1.0',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('❌ CRITICAL ERROR in restore function:', error);
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return new Response(
      JSON.stringify({
        success: false,
        message: 'Restore failed to start',
        error: errorMessage,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
