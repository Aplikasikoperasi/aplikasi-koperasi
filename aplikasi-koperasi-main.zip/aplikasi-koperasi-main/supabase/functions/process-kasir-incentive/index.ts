import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface KasirIncentiveRequest {
  type: 'kasir_payment' | 'kasir_holiday';
  payment_id?: string;
  kasir_member_id?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { type, payment_id, kasir_member_id }: KasirIncentiveRequest = await req.json();

    console.log('Processing kasir incentive:', { type, payment_id, kasir_member_id });

    // Get kasir member_id from payment's created_by
    let member_id: string | null = kasir_member_id || null;
    
    if (type === 'kasir_payment' && payment_id) {
      const { data: payment } = await supabaseClient
        .from('payments')
        .select('created_by')
        .eq('id', payment_id)
        .single();
      
      if (payment?.created_by) {
        // Get member_id from user_id
        const { data: member } = await supabaseClient
          .from('members')
          .select('id')
          .eq('user_id', payment.created_by)
          .single();
        
        member_id = member?.id || null;
      }
    }

    if (!member_id) {
      console.error('Kasir member ID not found');
      return new Response(
        JSON.stringify({ error: 'Kasir member ID not found' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Kasir incentive will be given to member:', member_id);

    // Check if member is kasir and is active
    const { data: member, error: memberError } = await supabaseClient
      .from('members')
      .select('user_id, position, is_active')
      .eq('id', member_id)
      .single();

    if (memberError || !member) {
      console.error('Failed to fetch member:', memberError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch member information' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Skip incentive for inactive members
    if (!member.is_active) {
      console.log('Kasir incentive skipped: member is inactive');
      return new Response(
        JSON.stringify({ message: 'Kasir incentive skipped for inactive member' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check user role - only kasir get this incentive
    const { data: userRole, error: roleError } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', member.user_id)
      .single();

    if (roleError || !userRole) {
      console.error('Failed to fetch user role:', roleError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch user role' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Only kasir role gets this incentive
    if (userRole.role !== 'kasir') {
      console.log('Kasir incentive skipped: member is not kasir role, role:', userRole.role);
      return new Response(
        JSON.stringify({ message: 'Kasir incentive only applies to kasir members' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get incentive settings
    const { data: settings, error: settingsError } = await supabaseClient
      .from('incentive_settings')
      .select('*')
      .single();

    if (settingsError) {
      console.error('Error fetching settings:', settingsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch incentive settings' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!settings || !settings.kasir_enabled) {
      console.log('Kasir incentive system is disabled');
      return new Response(
        JSON.stringify({ message: 'Kasir incentive system is disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let amount = 0;
    let description = '';
    let balanceType = 'regular';

    if (type === 'kasir_payment') {
      if (!settings.kasir_payment_enabled) {
        console.log('Kasir payment incentive is disabled');
        return new Response(
          JSON.stringify({ message: 'Kasir payment incentive is disabled' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get payment amount
      const { data: payment } = await supabaseClient
        .from('payments')
        .select(`
          amount,
          installments:installment_id(
            installment_number,
            credit_applications:application_id(
              application_number
            )
          )
        `)
        .eq('id', payment_id)
        .single();

      const paymentAmount = Number(payment?.amount || 0);
      const installmentData = payment?.installments as any;
      const appData = installmentData?.credit_applications;
      const appNumber = appData?.application_number || '';
      const installmentNumber = installmentData?.installment_number || '';
      const formattedPayment = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(paymentAmount);

      // Calculate amount based on type (fixed or percentage)
      if (settings.kasir_payment_type === 'percentage') {
        const percentage = Number(settings.kasir_payment_amount || 0);
        amount = (paymentAmount * percentage) / 100;
      } else {
        amount = Number(settings.kasir_payment_amount || 0);
      }

      description = `Insentif kasir input pembayaran angsuran ke-${installmentNumber} ${appNumber} (${formattedPayment})`;
      balanceType = 'regular';

    } else if (type === 'kasir_holiday') {
      if (!settings.kasir_holiday_enabled) {
        console.log('Kasir holiday incentive is disabled');
        return new Response(
          JSON.stringify({ message: 'Kasir holiday incentive is disabled' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Calculate year-end bonus from total payments inputted by this kasir
      const currentYear = new Date().getFullYear();
      const yearStart = `${currentYear}-01-01`;
      const yearEnd = `${currentYear}-12-01`;

      // Get total payments created by this kasir
      const { data: yearlyPayments, error: paymentsError } = await supabaseClient
        .from('payments')
        .select('amount')
        .eq('created_by', member.user_id)
        .gte('payment_date', yearStart)
        .lte('payment_date', yearEnd);

      if (paymentsError) {
        console.error('Error fetching yearly payments for kasir:', paymentsError);
        return new Response(
          JSON.stringify({ error: 'Failed to fetch yearly payments' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const totalPayments = yearlyPayments?.reduce((sum, payment) => sum + Number(payment.amount || 0), 0) || 0;

      if (settings.kasir_holiday_type === 'percentage') {
        const percentage = Number(settings.kasir_holiday_amount || 0);
        amount = (totalPayments * percentage) / 100;
      } else {
        amount = Number(settings.kasir_holiday_amount || 0);
      }

      description = `Bonus Akhir Tahun Kasir ${currentYear} - Total pembayaran diinput: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalPayments)}`;
      balanceType = 'year_end_bonus';
    }

    if (amount <= 0) {
      console.log('Kasir incentive amount is zero or negative');
      return new Response(
        JSON.stringify({ message: 'Kasir incentive amount is invalid' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get payment_date to determine period_month
    let periodMonth: string;
    let paymentDate: Date;

    if (payment_id) {
      const { data: payment } = await supabaseClient
        .from('payments')
        .select('payment_date')
        .eq('id', payment_id)
        .single();

      if (!payment?.payment_date) {
        console.error('Payment date not found for payment:', payment_id);
        return new Response(
          JSON.stringify({ error: 'Payment date not found' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      paymentDate = new Date(payment.payment_date);
      periodMonth = `${paymentDate.getFullYear()}-${String(paymentDate.getMonth() + 1).padStart(2, '0')}`;
    } else {
      paymentDate = new Date();
      periodMonth = `${paymentDate.getFullYear()}-${String(paymentDate.getMonth() + 1).padStart(2, '0')}`;
    }

    // CRITICAL: For kasir year-end bonus (kasir_holiday type), check if payment date is after December 1st cutoff
    // Year-end bonus should only accumulate for payments from Jan 1 to Dec 1
    // Payments after Dec 1 should fall back to regular bonus if enabled
    if (type === 'kasir_holiday' || balanceType === 'year_end_bonus') {
      const paymentYear = paymentDate.getFullYear();
      const cutoffDate = new Date(`${paymentYear}-12-01T23:59:59`);
      
      if (paymentDate > cutoffDate) {
        console.log('Kasir year-end bonus cutoff reached: payment date is after December 1st', {
          paymentDate: paymentDate.toISOString(),
          cutoffDate: cutoffDate.toISOString()
        });
        
        // FALLBACK: If kasir regular payment incentive is enabled, record as regular bonus instead
        if (settings.kasir_payment_enabled) {
          console.log('Falling back to kasir regular bonus for payment after Dec 1st cutoff');
          balanceType = 'regular';
          // Update description to reflect regular bonus
          description = description.replace('Bonus Akhir Tahun', 'Insentif kasir');
        } else {
          // Neither year-end bonus nor regular bonus applicable
          console.log('Both kasir year-end bonus (cutoff) and regular bonus (disabled) not applicable');
          return new Response(
            JSON.stringify({ 
              message: 'Kasir payment after Dec 1st cutoff and regular incentive is disabled',
              payment_date: paymentDate.toISOString(),
              cutoff_date: cutoffDate.toISOString()
            }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    }

    console.log('Processing kasir incentive for period:', periodMonth);

    // Create transaction record
    const { data: transaction, error: transactionError } = await supabaseClient
      .from('member_balance_transactions')
      .insert({
        member_id,
        amount,
        type: type,
        description,
        balance_type: balanceType,
        payment_id: payment_id || null,
        period_month: periodMonth,
      })
      .select()
      .single();

    if (transactionError) {
      console.error('Error creating kasir transaction:', transactionError);
      return new Response(
        JSON.stringify({ error: 'Failed to create transaction' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Kasir incentive processed successfully:', transaction);

    // Update monthly balance summary for regular balance
    if (balanceType === 'regular') {
      const { data: existingSummary } = await supabaseClient
        .from('member_monthly_balance_summary')
        .select('*')
        .eq('member_id', member_id)
        .eq('period_month', periodMonth)
        .maybeSingle();

      if (existingSummary) {
        await supabaseClient
          .from('member_monthly_balance_summary')
          .update({
            total_earned: Number(existingSummary.total_earned) + amount,
            available_balance: Number(existingSummary.available_balance) + amount,
            updated_at: paymentDate.toISOString()
          })
          .eq('member_id', member_id)
          .eq('period_month', periodMonth);
      } else {
        await supabaseClient
          .from('member_monthly_balance_summary')
          .insert({
            member_id: member_id,
            period_month: periodMonth,
            total_earned: amount,
            total_withdrawn: 0,
            available_balance: amount,
            is_held: false,
            hold_reason: null
          });
      }

      console.log('Kasir monthly balance summary updated for period:', periodMonth);
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Kasir incentive processed successfully',
        transaction
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in process-kasir-incentive function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
