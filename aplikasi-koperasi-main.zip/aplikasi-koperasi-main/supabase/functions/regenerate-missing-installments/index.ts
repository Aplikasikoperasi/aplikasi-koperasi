import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface InstallmentSchedule {
  installment_number: number;
  due_date: string;
  principal_amount: number;
  interest_amount: number;
  total_amount: number;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('🔄 Starting regeneration of missing installments...');

    // Get all disbursed applications
    const { data: applications, error: appError } = await supabaseAdmin
      .from('credit_applications')
      .select('*')
      .eq('status', 'disbursed')
      .order('disbursed_at', { ascending: true });

    if (appError) throw appError;
    if (!applications || applications.length === 0) {
      return new Response(
        JSON.stringify({ success: true, message: 'No disbursed applications found', regenerated: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`📋 Found ${applications.length} disbursed applications`);

    let totalRegenerated = 0;
    let totalSkipped = 0;
    const errors: any[] = [];

    // Process each application
    for (const app of applications) {
      try {
        // Check how many installments currently exist for this application
        const { data: existingInstallments, error: checkError } = await supabaseAdmin
          .from('installments')
          .select('installment_number')
          .eq('application_id', app.id)
          .order('installment_number', { ascending: true });

        if (checkError) throw checkError;

        const existingNumbers = new Set(existingInstallments?.map(i => i.installment_number) || []);
        const missingNumbers: number[] = [];

        // Find missing installment numbers (should be 1 to tenor_months)
        for (let i = 1; i <= app.tenor_months; i++) {
          if (!existingNumbers.has(i)) {
            missingNumbers.push(i);
          }
        }

        if (missingNumbers.length === 0) {
          console.log(`✅ Application ${app.application_number}: All ${app.tenor_months} installments exist`);
          totalSkipped++;
          continue;
        }

        console.log(`🔧 Application ${app.application_number}: Regenerating ${missingNumbers.length} missing installments (${missingNumbers.join(', ')})`);

        // Calculate installment schedule for missing installments
        const amountApproved = app.amount_approved || 0;
        const interestRate = app.interest_rate || 0;
        const tenorMonths = app.tenor_months || 1;
        
        // Calculate amounts per installment
        const totalInterest = (amountApproved * interestRate * tenorMonths) / 100;
        const principalPerInstallment = amountApproved / tenorMonths;
        const interestPerInstallment = totalInterest / tenorMonths;
        const totalPerInstallment = principalPerInstallment + interestPerInstallment;

        // Get disbursement date for calculating due dates
        const disbursedDate = new Date(app.disbursed_at || app.approved_at || app.created_at);
        
        // Generate missing installments
        const missingInstallments = missingNumbers.map(num => {
          // Calculate due date (1st of each month after disbursement)
          const dueDate = new Date(disbursedDate);
          dueDate.setMonth(dueDate.getMonth() + num);
          dueDate.setDate(1); // Set to 1st of the month

          return {
            application_id: app.id,
            installment_number: num,
            due_date: dueDate.toISOString().split('T')[0],
            principal_amount: Math.round(principalPerInstallment),
            interest_amount: Math.round(interestPerInstallment),
            total_amount: Math.round(totalPerInstallment),
            paid_amount: 0,
            status: 'unpaid',
            created_at: new Date().toISOString(),
            frozen_penalty: 0,
            principal_paid: false,
            frozen_days_overdue: 0,
          };
        });

        // Insert missing installments
        const { error: insertError } = await supabaseAdmin
          .from('installments')
          .insert(missingInstallments);

        if (insertError) {
          console.error(`❌ Error inserting installments for ${app.application_number}:`, insertError);
          errors.push({
            application_number: app.application_number,
            application_id: app.id,
            error: insertError.message,
            missing_numbers: missingNumbers
          });
        } else {
          console.log(`✅ Regenerated ${missingNumbers.length} installments for ${app.application_number}`);
          totalRegenerated += missingNumbers.length;
        }
      } catch (error) {
        console.error(`❌ Error processing application ${app.application_number}:`, error);
        errors.push({
          application_number: app.application_number,
          application_id: app.id,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    const summary = {
      success: true,
      total_applications: applications.length,
      applications_with_complete_installments: totalSkipped,
      applications_processed: applications.length - totalSkipped,
      total_installments_regenerated: totalRegenerated,
      errors: errors.length > 0 ? errors : undefined,
    };

    console.log('📊 Regeneration Summary:', summary);

    return new Response(
      JSON.stringify(summary),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Fatal error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
