import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Create Supabase client with service role for admin operations
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Parse request body first to check operation type
    const { superCodeInput, operation } = await req.json();

    // For owner_login operation, skip authentication (user hasn't logged in yet)
    const isLoginOperation = operation === 'owner_login';
    
    let user = null;
    
    // Only authenticate for non-login operations
    if (!isLoginOperation) {
      // Get user from auth header
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return new Response(
          JSON.stringify({ valid: false, error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const token = authHeader.replace('Bearer ', '');
      const { data: { user: authUser }, error: userError } = await supabaseAdmin.auth.getUser(token);

      if (userError || !authUser) {
        console.error('User authentication error:', userError);
        return new Response(
          JSON.stringify({ valid: false, error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      user = authUser;

      // Check if user has owner or admin role
      const { data: hasOwnerRole } = await supabaseAdmin.rpc('has_role', {
        _user_id: user.id,
        _role: 'owner'
      });

      const { data: hasAdminRole } = await supabaseAdmin.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin'
      });

      if (!hasOwnerRole && !hasAdminRole) {
        // Log unauthorized attempt
        await supabaseAdmin.rpc('log_system_event', {
          p_user_id: user.id,
          p_user_name: user.email || 'Unknown',
          p_category: 'security',
          p_action: 'supercode_unauthorized_attempt',
          p_description: 'Percobaan akses SuperCode oleh user tanpa wewenang',
          p_metadata: { user_email: user.email }
        });

        return new Response(
          JSON.stringify({ valid: false, error: 'Akses ditolak: Hanya owner atau admin yang dapat menggunakan SuperCode' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    if (!superCodeInput) {
      return new Response(
        JSON.stringify({ valid: false, error: 'SuperCode tidak boleh kosong' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch super_code from app_settings
    const { data: settings, error: settingsError } = await supabaseAdmin
      .from('app_settings')
      .select('super_code')
      .single();

    if (settingsError || !settings?.super_code) {
      console.error('Settings error:', settingsError);
      
      // Log failed attempt only if user is authenticated
      if (user) {
        await supabaseAdmin.rpc('log_system_event', {
          p_user_id: user.id,
          p_user_name: user.email || 'Unknown',
          p_category: 'security',
          p_action: 'supercode_config_missing',
          p_description: 'SuperCode belum dikonfigurasi di pengaturan sistem',
          p_metadata: { operation: operation || 'unknown' }
        });
      }

      return new Response(
        JSON.stringify({ valid: false, error: 'SuperCode belum dikonfigurasi di pengaturan sistem' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get current server time in WIB (UTC+7)
    const now = new Date();
    const wibTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
    const hours = wibTime.getHours().toString().padStart(2, '0');
    const minutes = wibTime.getMinutes().toString().padStart(2, '0');
    const currentTime = hours + minutes;

    // Build expected SuperCode: base_code + HHMM
    const expectedSuperCode = settings.super_code + currentTime;

    // Validate SuperCode
    const isValid = superCodeInput === expectedSuperCode;

    // Log the verification attempt (only if user is authenticated)
    if (user) {
      await supabaseAdmin.rpc('log_system_event', {
        p_user_id: user.id,
        p_user_name: user.email || 'Unknown',
        p_category: 'security',
        p_action: isValid ? 'supercode_verified' : 'supercode_failed',
        p_description: isValid 
          ? `SuperCode berhasil diverifikasi untuk operasi: ${operation || 'unknown'}`
          : `Percobaan SuperCode gagal untuk operasi: ${operation || 'unknown'}`,
        p_metadata: {
          operation: operation || 'unknown',
          wib_time: wibTime.toISOString(),
          success: isValid
        }
      });
    } else {
      // For login operations, log without user_id
      console.log(`SuperCode verification for ${operation}: ${isValid ? 'SUCCESS' : 'FAILED'}`);
    }

    if (!isValid) {
      return new Response(
        JSON.stringify({ 
          valid: false, 
          error: "SuperCode salah" 
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ valid: true }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Unexpected error in verify-supercode:', error);
    return new Response(
      JSON.stringify({ 
        valid: false, 
        error: 'Terjadi kesalahan saat memverifikasi SuperCode' 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
