import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WithdrawalRequest {
  withdrawal_id: string;
  action: 'approve' | 'reject';
  rejection_reason?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { withdrawal_id, action, rejection_reason }: WithdrawalRequest = await req.json();

    console.log('[process-balance-withdrawal] Processing:', { withdrawal_id, action });

    // Get withdrawal request
    const { data: withdrawal, error: withdrawalError } = await supabase
      .from('member_balance_withdrawals')
      .select('*')
      .eq('id', withdrawal_id)
      .single();

    if (withdrawalError || !withdrawal) {
      throw new Error('Withdrawal request not found');
    }

    if (withdrawal.status !== 'pending') {
      throw new Error('Withdrawal request already processed');
    }

    if (action === 'reject') {
      // Reject withdrawal
      await supabase
        .from('member_balance_withdrawals')
        .update({
          status: 'rejected',
          rejection_reason: rejection_reason || 'Ditolak oleh owner',
          reviewed_at: new Date().toISOString()
        })
        .eq('id', withdrawal_id);

      return new Response(
        JSON.stringify({
          success: true,
          message: 'Withdrawal rejected successfully'
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200
        }
      );
    }

    // Approve withdrawal - validate based on type
    if (withdrawal.withdrawal_type === 'regular') {
      // CRITICAL: Validate regular withdrawal against available balance
      const { data: availablePeriods, error: periodsError } = await supabase
        .from('member_monthly_balance_summary')
        .select('*')
        .eq('member_id', withdrawal.member_id)
        .eq('is_held', false)
        .gt('available_balance', 0)
        .order('period_month', { ascending: true });

      if (periodsError) {
        throw periodsError;
      }

      // Calculate total available (excluding current month)
      const now = new Date();
      const currentPeriod = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      
      const totalAvailable = (availablePeriods || [])
        .filter(p => p.period_month !== currentPeriod)
        .reduce((sum, p) => sum + Number(p.available_balance), 0);

      console.log('[process-balance-withdrawal] Regular validation:', {
        requested: withdrawal.amount,
        available: totalAvailable,
        currentPeriod
      });

      // CRITICAL: Strict validation - cannot exceed available balance
      if (Number(withdrawal.amount) > totalAvailable) {
        throw new Error(`Insufficient available balance. Requested: ${withdrawal.amount}, Available: ${totalAvailable}`);
      }

      if (totalAvailable <= 0) {
        throw new Error('No available balance to withdraw');
      }

      // Process deduction from periods (oldest first)
      let remainingAmount = Number(withdrawal.amount);

      for (const period of availablePeriods || []) {
        if (remainingAmount <= 0) break;

        // Skip current month period
        if (period.period_month === currentPeriod) {
          continue;
        }

        const deductAmount = Math.min(remainingAmount, Number(period.available_balance));
        const newAvailable = Number(period.available_balance) - deductAmount;
        const newWithdrawn = Number(period.total_withdrawn) + deductAmount;

        // Update period summary
        await supabase
          .from('member_monthly_balance_summary')
          .update({
            total_withdrawn: newWithdrawn,
            available_balance: newAvailable,
            updated_at: now.toISOString()
          })
          .eq('member_id', withdrawal.member_id)
          .eq('period_month', period.period_month);

        // Create withdrawal transaction record
        await supabase
          .from('member_balance_transactions')
          .insert({
            member_id: withdrawal.member_id,
            amount: -deductAmount,
            type: 'withdrawal',
            description: `Penarikan saldo dari periode ${period.period_month}`,
            balance_type: 'regular',
            period_month: period.period_month,
            created_at: now.toISOString()
          });

        remainingAmount -= deductAmount;

        console.log('[process-balance-withdrawal] Deducted from period:', {
          period: period.period_month,
          deducted: deductAmount,
          remaining: remainingAmount
        });
      }

      if (remainingAmount > 0) {
        throw new Error('Unable to process full withdrawal amount - insufficient balance after period deduction');
      }

    } else if (withdrawal.withdrawal_type === 'year_end_bonus') {
      // IMPORTANT: Don't use get_member_balance_detailed for validation during approval
      // because that RPC already subtracts pending withdrawals, causing circular validation failure
      // Instead, calculate raw THR balance from transactions
      const { data: thrTransactions, error: thrError } = await supabase
        .from('member_balance_transactions')
        .select('amount')
        .eq('member_id', withdrawal.member_id)
        .eq('balance_type', 'year_end_bonus');

      if (thrError) {
        throw thrError;
      }

      const rawThrBalance = (thrTransactions || []).reduce((sum, t) => sum + Number(t.amount), 0);

      // Get other pending THR withdrawals (excluding current one being approved)
      const { data: otherPendingWithdrawals, error: pendingError } = await supabase
        .from('member_balance_withdrawals')
        .select('amount')
        .eq('member_id', withdrawal.member_id)
        .in('withdrawal_type', ['thr', 'year_end_bonus'])
        .eq('status', 'pending')
        .neq('id', withdrawal_id);

      if (pendingError) {
        throw pendingError;
      }

      const otherPendingAmount = (otherPendingWithdrawals || []).reduce((sum, w) => sum + Number(w.amount), 0);
      const actualBonusBalance = rawThrBalance - otherPendingAmount;

      console.log('[process-balance-withdrawal] Year-end bonus validation:', {
        requested: withdrawal.amount,
        rawThrBalance,
        otherPendingAmount,
        actualAvailable: actualBonusBalance
      });

      // Validate: requested amount should not exceed available (excluding this withdrawal from pending)
      if (Number(withdrawal.amount) > actualBonusBalance) {
        throw new Error(`Insufficient year-end bonus balance. Requested: ${withdrawal.amount}, Available: ${actualBonusBalance}`);
      }

      if (actualBonusBalance <= 0) {
        throw new Error('No year-end bonus balance to withdraw');
      }

      // Process THR withdrawal
      const now = new Date();
      const currentYear = now.getFullYear();
      
      // Create THR withdrawal transaction
      await supabase
        .from('member_balance_transactions')
        .insert({
          member_id: withdrawal.member_id,
          amount: -Number(withdrawal.amount),
          type: 'withdrawal',
          description: `Penarikan Bonus Akhir Tahun ${currentYear}`,
          balance_type: 'year_end_bonus',
          period_month: `${currentYear}-12`,
          created_at: now.toISOString()
        });

      console.log('[process-balance-withdrawal] THR withdrawal processed:', {
        amount: withdrawal.amount,
        year: currentYear
      });
    } else {
      throw new Error('Invalid withdrawal type');
    }

    // Mark withdrawal as approved
    const now = new Date();
    await supabase
      .from('member_balance_withdrawals')
      .update({
        status: 'approved',
        reviewed_at: now.toISOString()
      })
      .eq('id', withdrawal_id);

    console.log('[process-balance-withdrawal] Withdrawal approved successfully');

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Withdrawal approved and processed successfully'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200
      }
    );

  } catch (err) {
    console.error('[process-balance-withdrawal] Error:', err);
    const message = err instanceof Error ? err.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({
        success: false,
        error: message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});
