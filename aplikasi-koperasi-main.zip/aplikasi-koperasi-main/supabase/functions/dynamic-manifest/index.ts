import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Default values
const DEFAULT_NAME = 'Aplikasi Koperasi'
const DEFAULT_SHORT_NAME = 'Koperasi'
const DEFAULT_DESCRIPTION = 'Aplikasi manajemen koperasi simpan pinjam'
const DEFAULT_THEME_COLOR = '#2563EB'

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  // Get the origin from the request (for absolute URLs in manifest)
  const requestOrigin = req.headers.get('origin') || req.headers.get('referer')?.replace(/\/$/, '') || ''
  // Extract just the origin (protocol + host) from referer if needed
  let targetOrigin = ''
  if (requestOrigin) {
    try {
      const url = new URL(requestOrigin)
      targetOrigin = url.origin
    } catch {
      targetOrigin = requestOrigin
    }
  }

  console.log('📱 [Dynamic Manifest] Request received')

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseKey)

    type BusinessProfileRow = {
      business_name: string | null
      business_description: string | null
      logo_url: string | null
      updated_at?: string | null
    }

    // Prefer: owner's profile (by role). Fallback: latest profile with business info.
    let profileData: BusinessProfileRow | null = null

    const { data: owners, error: ownersError } = await supabase
      .from('user_roles')
      .select('user_id')
      .eq('role', 'owner')

    if (ownersError) {
      console.error('❌ [Dynamic Manifest] Error fetching owners:', ownersError)
    }

    const ownerIds = (owners ?? []).map((o: any) => o.user_id).filter(Boolean)

    if (ownerIds.length > 0) {
      const { data: ownerProfile, error: ownerProfileError } = await supabase
        .from('profiles')
        .select('business_name, business_description, logo_url, updated_at')
        .in('id', ownerIds)
        .or('business_name.not.is.null,logo_url.not.is.null')
        .order('updated_at', { ascending: false, nullsFirst: false })
        .limit(1)
        .maybeSingle()

      if (ownerProfileError) {
        console.error('❌ [Dynamic Manifest] Error fetching owner profile:', ownerProfileError)
      }

      if (ownerProfile) profileData = ownerProfile as BusinessProfileRow
    }

    if (!profileData) {
      const { data: latestProfile, error: latestProfileError } = await supabase
        .from('profiles')
        .select('business_name, business_description, logo_url, updated_at')
        .or('business_name.not.is.null,logo_url.not.is.null')
        .order('updated_at', { ascending: false, nullsFirst: false })
        .limit(1)
        .maybeSingle()

      if (latestProfileError) {
        console.error('❌ [Dynamic Manifest] Error fetching latest profile:', latestProfileError)
      }

      if (latestProfile) profileData = latestProfile as BusinessProfileRow
    }

    // Use business data if available, otherwise use defaults
    const businessName = profileData?.business_name?.trim() || DEFAULT_NAME
    const businessDescription = profileData?.business_description?.trim() || DEFAULT_DESCRIPTION
    const logoUrl = profileData?.logo_url?.trim() || null

    console.log('📱 [Dynamic Manifest] Using:', {
      name: businessName,
      hasLogo: !!logoUrl,
      logoUrl: logoUrl ? logoUrl.substring(0, 50) + '...' : 'default'
    })

    // Generate short_name (max 12 chars for PWA)
    const shortName = businessName.length > 12 
      ? businessName.substring(0, 12).trim() 
      : businessName

    // Determine icon URLs - use logo if available, otherwise default PWA icons
    const icons = logoUrl ? [
      {
        src: logoUrl,
        sizes: '192x192',
        type: 'image/png',
        purpose: 'any'
      },
      {
        src: logoUrl,
        sizes: '512x512',
        type: 'image/png',
        purpose: 'any'
      },
      {
        src: logoUrl,
        sizes: '512x512',
        type: 'image/png',
        purpose: 'maskable'
      }
    ] : [
      {
        src: '/pwa-192x192.png',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'any maskable'
      },
      {
        src: '/pwa-512x512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'any maskable'
      }
    ]

    // Use absolute URLs for start_url and scope when we know the target origin
    // This is CRITICAL for cross-origin manifest serving
    const startUrl = targetOrigin ? `${targetOrigin}/` : '/'
    const scope = targetOrigin ? `${targetOrigin}/` : '/'

    const manifest = {
      name: businessName,
      short_name: shortName,
      description: businessDescription,
      theme_color: DEFAULT_THEME_COLOR,
      background_color: '#ffffff',
      display: 'standalone',
      orientation: 'portrait',
      scope,
      start_url: startUrl,
      categories: ['finance', 'business'],
      icons
    }

    console.log('✅ [Dynamic Manifest] Generated:', { 
      name: businessName, 
      startUrl, 
      scope,
      targetOrigin: targetOrigin || 'unknown'
    })

    return new Response(JSON.stringify(manifest), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/manifest+json',
        'Cache-Control': 'public, max-age=300' // Cache for 5 minutes
      }
    })
  } catch (error) {
    console.error('❌ [Dynamic Manifest] Error:', error)
    
    // Return default manifest on error
    const fallbackManifest = {
      name: DEFAULT_NAME,
      short_name: DEFAULT_SHORT_NAME,
      description: DEFAULT_DESCRIPTION,
      theme_color: DEFAULT_THEME_COLOR,
      background_color: '#ffffff',
      display: 'standalone',
      orientation: 'portrait',
      scope: '/',
      start_url: '/',
      categories: ['finance', 'business'],
      icons: [
        {
          src: '/pwa-192x192.png',
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any maskable'
        },
        {
          src: '/pwa-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any maskable'
        }
      ]
    }

    return new Response(JSON.stringify(fallbackManifest), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/manifest+json',
        'Cache-Control': 'public, max-age=60' // Shorter cache on error
      }
    })
  }
})