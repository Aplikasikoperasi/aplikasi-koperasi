import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('[send-daily-overdue-reminders] Starting daily overdue reminders...');

    // Check if WhatsApp is enabled
    const { data: settings } = await supabase
      .from('whatsapp_settings')
      .select('is_enabled')
      .maybeSingle();

    if (!settings?.is_enabled) {
      console.log('[send-daily-overdue-reminders] WhatsApp not enabled, skipping');
      return new Response(
        JSON.stringify({ success: true, message: 'WhatsApp not enabled', sent: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Get overdue installments WITH snapshot penalty rate
    const { data: overdueInstallments, error: installmentsError } = await supabase
      .from('installments')
      .select(`
        *,
        credit_applications!inner(
          id,
          application_number,
          customer_id,
          penalty_rate_per_day,
          customers!inner(
            id,
            full_name,
            phone,
            id_number
          )
        )
      `)
      .eq('status', 'overdue')
      .eq('principal_paid', false)
      .eq('credit_applications.status', 'approved');

    if (installmentsError) {
      throw installmentsError;
    }

    if (!overdueInstallments || overdueInstallments.length === 0) {
      console.log('[send-daily-overdue-reminders] No overdue installments found');
      return new Response(
        JSON.stringify({ success: true, message: 'No overdue installments', sent: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Note: We no longer use global penalty rate - each installment has its snapshot

    // Get primary bank account info
    const { data: bankAccount } = await supabase
      .from('bank_accounts')
      .select('bank_name, account_number, account_holder')
      .eq('is_primary', true)
      .eq('is_active', true)
      .maybeSingle();

    let sentCount = 0;
    const errors: string[] = [];

    // Send reminders
    for (const installment of overdueInstallments) {
      try {
        const customer = (installment.credit_applications as any).customers;
        const application = installment.credit_applications as any;
        
        if (!customer?.phone) {
          console.log(`[send-daily-overdue-reminders] No phone for customer ${customer?.id}`);
          continue;
        }

        // Calculate days overdue and penalty using SNAPSHOT rate
        const dueDate = new Date(installment.due_date);
        const today = new Date();
        const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
        
        // Use SNAPSHOT penalty rate (fallback chain: installment -> application -> default 2.0)
        const snapshotPenaltyRate = installment.penalty_rate_per_day || 
                                     application.penalty_rate_per_day || 
                                     2.0;
        
        const penalty = Math.ceil((installment.total_amount * (snapshotPenaltyRate / 100) * daysOverdue) / 1000) * 1000;
        const totalDue = (installment.total_amount - installment.paid_amount) + penalty;
        
        console.log(`[Installment ${installment.id}] Using snapshot penalty rate: ${snapshotPenaltyRate}%`);

        // Format message
        let message = `🚨 *PENGINGAT TUNGGAKAN*

Kepada Yth. ${customer.full_name}
ID: ${customer.id_number}

Anda memiliki tunggakan angsuran yang perlu segera dilunasi:

📋 *Detail Angsuran:*
• Angsuran ke-${installment.installment_number}
• No. Aplikasi: ${application.application_number}
• Jatuh Tempo: ${new Date(installment.due_date).toLocaleDateString('id-ID')}
• Terlambat: *${daysOverdue} hari*

💰 *Detail Tagihan:*
• Angsuran: Rp ${installment.total_amount.toLocaleString('id-ID')}
• Denda (${snapshotPenaltyRate}%/hari): Rp ${penalty.toLocaleString('id-ID')}
• *Total Tagihan: Rp ${totalDue.toLocaleString('id-ID')}*

⚠️ Mohon segera melakukan pembayaran untuk menghindari denda yang terus bertambah.`;

        // Add bank account information if available
        if (bankAccount?.bank_name) {
          message += `

━━━━━━━━━━━━━━━━━
🏦 *INFORMASI PEMBAYARAN*

Transfer ke rekening:
• Bank: *${bankAccount.bank_name}*
• No. Rekening: *${bankAccount.account_number}*
• Atas Nama: *${bankAccount.account_holder}*
━━━━━━━━━━━━━━━━━`;
        }

        message += `

Hubungi kami untuk informasi lebih lanjut.`;

        // Send via WhatsApp
        const { error: sendError } = await supabase.functions.invoke('send-whatsapp-message', {
          body: {
            phone_number: customer.phone,
            message: message
          }
        });

        if (sendError) {
          console.error(`[send-daily-overdue-reminders] Failed to send to ${customer.id}:`, sendError);
          errors.push(`${customer.full_name}: ${sendError.message}`);
          
          // Log failed message
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_overdue',
            message_content: message,
            status: 'failed',
            error_message: sendError.message
          });
        } else {
          sentCount++;
          console.log(`[send-daily-overdue-reminders] Sent to ${customer.full_name}`);
          
          // Log successful message
          await supabase.from('whatsapp_message_logs').insert({
            recipient_phone: customer.phone,
            recipient_name: customer.full_name,
            recipient_type: 'customer',
            recipient_id: customer.id,
            message_type: 'reminder_overdue',
            message_content: message,
            status: 'sent',
            sent_at: new Date().toISOString()
          });
        }

        // Small delay to avoid rate limiting (2 seconds for safety)
        await new Promise(resolve => setTimeout(resolve, 2000));

      } catch (error) {
        console.error('[send-daily-overdue-reminders] Error processing installment:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        errors.push(`Installment ${installment.id}: ${errorMessage}`);
      }
    }

    console.log(`[send-daily-overdue-reminders] Completed. Sent: ${sentCount}, Errors: ${errors.length}`);

    return new Response(
      JSON.stringify({
        success: true,
        sent: sentCount,
        total: overdueInstallments.length,
        errors: errors
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('[send-daily-overdue-reminders] Fatal error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
