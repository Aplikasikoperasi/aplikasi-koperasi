import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('Starting payment reminders job...');

    // Get today's date at midnight
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Calculate 3 days from now
    const threeDaysFromNow = new Date(today);
    threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);
    const threeDaysDate = threeDaysFromNow.toISOString().split('T')[0];

    // Get app settings for penalty rate
    const { data: appSettings } = await supabase.rpc('get_public_app_settings');
    const penaltyRate = (appSettings as any)?.penalty_rate_per_day || 2.0;

    let remindersCount = 0;
    let warningsCount = 0;

    // ============================================================
    // 1. SEND REMINDERS: Installments due in 3 days (unpaid only)
    // ============================================================
    const { data: upcomingInstallments, error: upcomingError } = await supabase
      .from('installments')
      .select(`
        id,
        installment_number,
        due_date,
        total_amount,
        credit_applications!inner (
          id,
          application_number,
          customer_id,
          customers!inner (
            id,
            full_name,
            id_number,
            date_of_birth
          )
        )
      `)
      .eq('status', 'unpaid')
      .eq('due_date', threeDaysDate);

    if (upcomingError) {
      console.error('Error fetching upcoming installments:', upcomingError);
    } else if (upcomingInstallments && upcomingInstallments.length > 0) {
      console.log(`Found ${upcomingInstallments.length} upcoming installments`);

      for (const inst of upcomingInstallments) {
        const customer = (inst.credit_applications as any).customers;
        const app = inst.credit_applications as any;

        // Check if reminder was already sent today
        const { data: existingMessage } = await supabase
          .from('customer_messages')
          .select('id')
          .eq('customer_id', customer.id)
          .eq('type', 'reminder')
          .gte('created_at', today.toISOString())
          .like('message', `%${inst.installment_number}%`)
          .maybeSingle();

        if (existingMessage) {
          console.log(`Reminder already sent for customer ${customer.id_number}, installment ${inst.installment_number}`);
          continue;
        }

        const formatRupiah = (amount: number) => {
          return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
          }).format(amount);
        };

        const formatDate = (dateStr: string) => {
          const date = new Date(dateStr);
          return new Intl.DateTimeFormat('id-ID', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
          }).format(date);
        };

        let message = `🔔 *PENGINGAT ANGSURAN*\n\n`;
        message += `Kepada Yth,\nBapak/Ibu *${customer.full_name}*\n\n`;
        message += `📅 Angsuran ke-${inst.installment_number}\n`;
        message += `Jatuh Tempo: ${formatDate(inst.due_date)}\n\n`;
        message += `💰 *Jumlah Angsuran:*\n`;
        message += `${formatRupiah(inst.total_amount)}\n\n`;
        message += `📋 No. Aplikasi: ${app.application_number}\n`;
        message += `\n⏰ Mohon segera melakukan pembayaran untuk menghindari denda keterlambatan.\n\n`;
        
        // Add login info
        if (customer.id && customer.date_of_birth) {
          const dob = new Date(customer.date_of_birth);
          const day = String(dob.getDate()).padStart(2, '0');
          const month = String(dob.getMonth() + 1).padStart(2, '0');
          const year = dob.getFullYear();
          const password = `${day}${month}${year}`;
          
          message += `━━━━━━━━━━━━━━━━━\n`;
          message += `🔐 *INFO AKUN LOGIN NASABAH*\n\n`;
          message += `Akses dashboard Anda untuk memantau kredit:\n`;
          message += `• No. ID User: *${customer.id}*\n`;
          message += `• Password: *${password}*\n`;
          message += `• Link: https://www.mitradana.id/\n\n`;
          message += `_Login dengan No. ID User Anda untuk melihat riwayat kredit & angsuran_\n`;
          message += `━━━━━━━━━━━━━━━━━\n\n`;
        }
        
        message += `_Terima kasih atas kepercayaan Anda._`;

        const { error: insertError } = await supabase
          .from('customer_messages')
          .insert({
            customer_id: customer.id,
            title: 'Pengingat Pembayaran',
            message,
            type: 'reminder',
            is_read: false,
            metadata: {
              installment_id: inst.id,
              due_date: inst.due_date,
              amount: inst.total_amount
            }
          });

        if (insertError) {
          console.error(`Error sending reminder to ${customer.id_number}:`, insertError);
        } else {
          remindersCount++;
          console.log(`Sent reminder to ${customer.id_number} for installment ${inst.installment_number}`);
        }
      }
    }

    // ============================================================
    // 2. SEND WARNINGS: Overdue installments with penalties
    // ============================================================
    const todayDate = today.toISOString().split('T')[0];
    
    const { data: overdueInstallments, error: overdueError } = await supabase
      .from('installments')
      .select(`
        id,
        installment_number,
        due_date,
        total_amount,
        paid_amount,
        frozen_penalty,
        principal_paid,
        credit_applications!inner (
          id,
          application_number,
          customer_id,
          customers!inner (
            id,
            full_name,
            id_number,
            date_of_birth
          )
        )
      `)
      .in('status', ['overdue', 'partial'])
      .lt('due_date', todayDate);

    if (overdueError) {
      console.error('Error fetching overdue installments:', overdueError);
    } else if (overdueInstallments && overdueInstallments.length > 0) {
      console.log(`Found ${overdueInstallments.length} overdue installments`);

      for (const inst of overdueInstallments) {
        const customer = (inst.credit_applications as any).customers;
        const app = inst.credit_applications as any;

        // Calculate days overdue and penalty
        const dueDate = new Date(inst.due_date);
        dueDate.setHours(0, 0, 0, 0);
        const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

        let currentPenalty = 0;
        if (inst.principal_paid) {
          // Use frozen penalty if principal already paid
          currentPenalty = inst.frozen_penalty || 0;
        } else {
          // Calculate real-time penalty
          if (daysOverdue > 0) {
            currentPenalty = Math.ceil((daysOverdue * (inst.total_amount * (penaltyRate / 100))) / 1000) * 1000;
          }
        }

        if (currentPenalty === 0) continue; // No penalty, skip

        // Check if warning was already sent today
        const { data: existingWarning } = await supabase
          .from('customer_messages')
          .select('id')
          .eq('customer_id', customer.id)
          .eq('type', 'reminder')
          .gte('created_at', today.toISOString())
          .like('message', `%telat%`)
          .like('message', `%${inst.installment_number}%`)
          .maybeSingle();

        if (existingWarning) {
          console.log(`Warning already sent for customer ${customer.id_number}, overdue installment ${inst.installment_number}`);
          continue;
        }

        const formatRupiah = (amount: number) => {
          return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
          }).format(amount);
        };

        const formatDate = (dateStr: string) => {
          const date = new Date(dateStr);
          return new Intl.DateTimeFormat('id-ID', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
          }).format(date);
        };

        const remaining = inst.total_amount - inst.paid_amount;
        const totalDue = remaining + currentPenalty;

        let message = `⚠️ *PERINGATAN TUNGGAKAN*\n\n`;
        message += `Kepada Yth,\nBapak/Ibu *${customer.full_name}*\n\n`;
        message += `Angsuran ke-${inst.installment_number} untuk aplikasi ${app.application_number} telah melewati jatuh tempo ${daysOverdue} hari sejak ${formatDate(inst.due_date)}.\n\n`;
        message += `💰 *Detail Pembayaran:*\n`;
        message += `• Sisa Angsuran: ${formatRupiah(remaining)}\n`;
        message += `• Denda Keterlambatan: ${formatRupiah(currentPenalty)} (${penaltyRate}% per hari)\n`;
        message += `• *Total yang Harus Dibayar: ${formatRupiah(totalDue)}*\n\n`;
        message += `⏰ Segera lakukan pembayaran untuk menghindari penambahan denda.\n\n`;
        
        // Add login info
        if (customer.id && customer.date_of_birth) {
          const dob = new Date(customer.date_of_birth);
          const day = String(dob.getDate()).padStart(2, '0');
          const month = String(dob.getMonth() + 1).padStart(2, '0');
          const year = dob.getFullYear();
          const password = `${day}${month}${year}`;
          
          message += `━━━━━━━━━━━━━━━━━\n`;
          message += `🔐 *INFO AKUN LOGIN NASABAH*\n\n`;
          message += `Akses dashboard Anda untuk memantau kredit:\n`;
          message += `• No. ID User: *${customer.id}*\n`;
          message += `• Password: *${password}*\n`;
          message += `• Link: https://www.mitradana.id/\n\n`;
          message += `_Login dengan No. ID User Anda untuk melihat riwayat kredit & angsuran_\n`;
          message += `━━━━━━━━━━━━━━━━━\n\n`;
        }
        
        message += `_Terima kasih atas perhatian Anda._`;

        const { error: insertError } = await supabase
          .from('customer_messages')
          .insert({
            customer_id: customer.id,
            title: 'Peringatan Keterlambatan Pembayaran',
            message,
            type: 'reminder',
            is_read: false,
            metadata: {
              installment_id: inst.id,
              due_date: inst.due_date,
              days_overdue: daysOverdue,
              remaining_amount: remaining,
              penalty_amount: currentPenalty,
              total_due: totalDue
            }
          });

        if (insertError) {
          console.error(`Error sending warning to ${customer.id_number}:`, insertError);
        } else {
          warningsCount++;
          console.log(`Sent overdue warning to ${customer.id_number} for installment ${inst.installment_number} (${daysOverdue} days late)`);
        }
      }
    }

    const summary = {
      success: true,
      timestamp: new Date().toISOString(),
      reminders_sent: remindersCount,
      warnings_sent: warningsCount,
      total_notifications: remindersCount + warningsCount
    };

    console.log('Payment reminders job completed:', summary);

    return new Response(
      JSON.stringify(summary),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error: any) {
    console.error('Error in send-payment-reminders:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
