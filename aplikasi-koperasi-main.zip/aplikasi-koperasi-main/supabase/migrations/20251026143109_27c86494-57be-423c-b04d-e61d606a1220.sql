-- Update validation trigger for installments to only prevent future dates
CREATE OR REPLACE FUNCTION public.validate_installment_paid_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate paid_at if it's being set or updated
  IF NEW.paid_at IS NOT NULL THEN
    -- Check if paid_at is not in the future
    IF NEW.paid_at::date > CURRENT_DATE THEN
      RAISE EXCEPTION 'Tanggal pembayaran tidak boleh lebih dari tanggal sistem saat ini. Tanggal pembayaran hanya dapat diisi sesuai tanggal sistem atau tanggal sebelumnya.';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Update validation trigger for payments to only prevent future dates
CREATE OR REPLACE FUNCTION public.validate_payment_date()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate payment_date
  IF NEW.payment_date IS NOT NULL THEN
    -- Check if payment_date is not in the future
    IF NEW.payment_date > CURRENT_DATE THEN
      RAISE EXCEPTION 'Tanggal pembayaran tidak boleh lebih dari tanggal sistem saat ini. Tanggal pembayaran hanya dapat diisi sesuai tanggal sistem atau tanggal sebelumnya.';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;