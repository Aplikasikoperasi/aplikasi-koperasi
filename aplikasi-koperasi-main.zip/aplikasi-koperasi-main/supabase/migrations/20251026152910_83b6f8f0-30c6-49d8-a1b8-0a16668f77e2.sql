-- Enable owner/admin to delete payments (to allow fixing duplicate entries)
CREATE POLICY "Owner and admin can delete payments"
ON public.payments
FOR DELETE
USING (
  has_role_text(auth.uid(), 'owner'::text) OR has_role_text(auth.uid(), 'admin'::text)
);
