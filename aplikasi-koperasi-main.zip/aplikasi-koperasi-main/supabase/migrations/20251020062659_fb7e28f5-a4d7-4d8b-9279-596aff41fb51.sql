-- Function to automatically create customer auth account
CREATE OR REPLACE FUNCTION public.auto_create_customer_auth()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_password TEXT;
  v_auth_user_id UUID;
  v_day TEXT;
  v_month TEXT;
  v_year TEXT;
BEGIN
  -- Only proceed if user_id is NULL and we have required fields
  IF NEW.user_id IS NULL AND NEW.id_number IS NOT NULL AND NEW.date_of_birth IS NOT NULL THEN
    
    -- Create email from id_number
    v_email := NEW.id_number || '@customer.local';
    
    -- Format date of birth as password (DDMMYYYY)
    v_day := LPAD(EXTRACT(DAY FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_month := LPAD(EXTRACT(MONTH FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_year := EXTRACT(YEAR FROM NEW.date_of_birth)::TEXT;
    v_password := v_day || v_month || v_year;
    
    -- Try to create auth user
    BEGIN
      -- Create user in auth.users
      INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token
      ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        gen_random_uuid(),
        'authenticated',
        'authenticated',
        v_email,
        crypt(v_password, gen_salt('bf')),
        NOW(),
        jsonb_build_object('full_name', NEW.full_name, 'is_customer', true),
        NOW(),
        NOW(),
        '',
        ''
      )
      RETURNING id INTO v_auth_user_id;
      
      -- Update customer with user_id
      NEW.user_id := v_auth_user_id;
      
      -- Create profile
      INSERT INTO public.profiles (id, full_name, email)
      VALUES (v_auth_user_id, NEW.full_name, v_email)
      ON CONFLICT (id) DO UPDATE
      SET full_name = EXCLUDED.full_name,
          email = EXCLUDED.email;
      
      -- Assign customer role
      INSERT INTO public.user_roles (user_id, role)
      VALUES (v_auth_user_id, 'customer')
      ON CONFLICT (user_id, role) DO NOTHING;
      
    EXCEPTION WHEN OTHERS THEN
      -- If user already exists, try to find them
      SELECT id INTO v_auth_user_id
      FROM auth.users
      WHERE email = v_email
      LIMIT 1;
      
      IF v_auth_user_id IS NOT NULL THEN
        -- Update customer with existing user_id
        NEW.user_id := v_auth_user_id;
        
        -- Update password
        UPDATE auth.users
        SET encrypted_password = crypt(v_password, gen_salt('bf')),
            updated_at = NOW()
        WHERE id = v_auth_user_id;
        
        -- Ensure profile exists
        INSERT INTO public.profiles (id, full_name, email)
        VALUES (v_auth_user_id, NEW.full_name, v_email)
        ON CONFLICT (id) DO UPDATE
        SET full_name = EXCLUDED.full_name,
            email = EXCLUDED.email;
        
        -- Ensure customer role exists
        INSERT INTO public.user_roles (user_id, role)
        VALUES (v_auth_user_id, 'customer')
        ON CONFLICT (user_id, role) DO NOTHING;
      END IF;
    END;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new customers
DROP TRIGGER IF EXISTS trigger_auto_create_customer_auth ON public.customers;
CREATE TRIGGER trigger_auto_create_customer_auth
  BEFORE INSERT OR UPDATE ON public.customers
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_create_customer_auth();

-- Create auth accounts for all existing customers without user_id
DO $$
DECLARE
  customer_record RECORD;
  v_email TEXT;
  v_password TEXT;
  v_auth_user_id UUID;
  v_day TEXT;
  v_month TEXT;
  v_year TEXT;
BEGIN
  FOR customer_record IN 
    SELECT id, id_number, full_name, date_of_birth
    FROM public.customers
    WHERE user_id IS NULL 
      AND id_number IS NOT NULL 
      AND date_of_birth IS NOT NULL
  LOOP
    -- Create email and password
    v_email := customer_record.id_number || '@customer.local';
    v_day := LPAD(EXTRACT(DAY FROM customer_record.date_of_birth)::TEXT, 2, '0');
    v_month := LPAD(EXTRACT(MONTH FROM customer_record.date_of_birth)::TEXT, 2, '0');
    v_year := EXTRACT(YEAR FROM customer_record.date_of_birth)::TEXT;
    v_password := v_day || v_month || v_year;
    
    BEGIN
      -- Try to create auth user
      INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token
      ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        gen_random_uuid(),
        'authenticated',
        'authenticated',
        v_email,
        crypt(v_password, gen_salt('bf')),
        NOW(),
        jsonb_build_object('full_name', customer_record.full_name, 'is_customer', true),
        NOW(),
        NOW(),
        '',
        ''
      )
      RETURNING id INTO v_auth_user_id;
      
      -- Update customer
      UPDATE public.customers
      SET user_id = v_auth_user_id
      WHERE id = customer_record.id;
      
      -- Create profile
      INSERT INTO public.profiles (id, full_name, email)
      VALUES (v_auth_user_id, customer_record.full_name, v_email)
      ON CONFLICT (id) DO UPDATE
      SET full_name = EXCLUDED.full_name,
          email = EXCLUDED.email;
      
      -- Assign role
      INSERT INTO public.user_roles (user_id, role)
      VALUES (v_auth_user_id, 'customer')
      ON CONFLICT (user_id, role) DO NOTHING;
      
    EXCEPTION WHEN OTHERS THEN
      -- If user exists, link them
      SELECT id INTO v_auth_user_id
      FROM auth.users
      WHERE email = v_email
      LIMIT 1;
      
      IF v_auth_user_id IS NOT NULL THEN
        UPDATE public.customers
        SET user_id = v_auth_user_id
        WHERE id = customer_record.id;
        
        UPDATE auth.users
        SET encrypted_password = crypt(v_password, gen_salt('bf')),
            updated_at = NOW()
        WHERE id = v_auth_user_id;
        
        INSERT INTO public.profiles (id, full_name, email)
        VALUES (v_auth_user_id, customer_record.full_name, v_email)
        ON CONFLICT (id) DO UPDATE
        SET full_name = EXCLUDED.full_name,
            email = EXCLUDED.email;
        
        INSERT INTO public.user_roles (user_id, role)
        VALUES (v_auth_user_id, 'customer')
        ON CONFLICT (user_id, role) DO NOTHING;
      END IF;
    END;
  END LOOP;
END $$;