-- Drop ALL triggers on customers table that might depend on credit_score
DROP TRIGGER IF EXISTS trigger_auto_block_low_credit_score ON customers;
DROP TRIGGER IF EXISTS trigger_auto_unblock_on_credit_score ON customers;
DROP TRIGGER IF EXISTS trg_auto_unblock_on_credit_score ON customers;
DROP TRIGGER IF EXISTS trg_auto_block_low_credit_score ON customers;

-- Alter credit_score column to accept decimal (numeric with 1 decimal place)
ALTER TABLE customers ALTER COLUMN credit_score TYPE numeric(3,1) USING credit_score::numeric(3,1);

-- Drop and recreate calculate_credit_score function with decimal return type
DROP FUNCTION IF EXISTS public.calculate_credit_score(uuid);

CREATE OR REPLACE FUNCTION public.calculate_credit_score(p_customer_id uuid)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_total_installments integer;
  v_on_time_installments integer;
  v_credit_score numeric;
BEGIN
  -- Count ONLY installments from ACTIVE approved/disbursed applications
  SELECT COUNT(i.id) INTO v_total_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
    AND ca.status IN ('approved','disbursed');

  -- Return default score if no installments
  IF v_total_installments = 0 THEN
    RETURN 5.0;
  END IF;

  -- Count on-time installments:
  -- - Paid on time (no frozen penalty)
  -- - OR still unpaid but not overdue yet
  SELECT COUNT(i.id) INTO v_on_time_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
    AND ca.status IN ('approved','disbursed')
    AND (
      -- Paid on time (no penalty frozen)
      (i.status = 'paid' AND COALESCE(i.frozen_penalty, 0) = 0)
      OR
      -- Unpaid but not overdue yet (status = unpaid, not overdue)
      (i.status = 'unpaid')
    );

  -- Calculate score as percentage * 5 (gives decimal result)
  v_credit_score := (v_on_time_installments::numeric / v_total_installments::numeric) * 5.0;
  
  -- Round to 1 decimal place and clamp between 0 and 5
  v_credit_score := ROUND(v_credit_score, 1);
  v_credit_score := GREATEST(0.0, LEAST(5.0, v_credit_score));
  
  RETURN v_credit_score;
END;
$function$;

-- Recreate trigger for credit score updates on installments
DROP TRIGGER IF EXISTS trigger_update_credit_score ON installments;
CREATE TRIGGER trigger_update_credit_score
AFTER INSERT OR UPDATE OF status, paid_at, frozen_penalty ON installments
FOR EACH ROW
EXECUTE FUNCTION trigger_update_credit_score_on_payment();

-- Recreate auto-block trigger (updated for decimal scores)
CREATE TRIGGER trigger_auto_block_low_credit_score
AFTER UPDATE OF credit_score ON customers
FOR EACH ROW
EXECUTE FUNCTION auto_block_low_credit_score();

-- Recreate auto-unblock trigger (updated for decimal scores)
CREATE TRIGGER trigger_auto_unblock_on_credit_score
AFTER UPDATE OF credit_score ON customers
FOR EACH ROW
EXECUTE FUNCTION auto_unblock_on_credit_score();