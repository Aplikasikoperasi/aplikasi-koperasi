-- Update RLS policy to allow sales staff to insert members
DROP POLICY IF EXISTS "Owner and Admin can insert members" ON public.members;

CREATE POLICY "All staff can insert members"
ON public.members
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'owner'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'sales'::app_role)
);