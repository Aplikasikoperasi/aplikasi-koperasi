-- Update get_interest_rate function to use highest tenor rate for undefined tenors in custom mode
CREATE OR REPLACE FUNCTION public.get_interest_rate(p_tenor_months integer)
RETURNS numeric
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_settings RECORD;
  v_custom_rate JSONB;
  v_max_tenor INTEGER;
  v_max_tenor_rate NUMERIC;
BEGIN
  SELECT * INTO v_settings FROM app_settings LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN 4.0;
  END IF;
  
  CASE v_settings.interest_type
    WHEN 'flat' THEN
      RETURN v_settings.flat_interest_rate;
    
    WHEN 'tiered' THEN
      IF p_tenor_months = 1 THEN RETURN 10.0;
      ELSIF p_tenor_months = 2 THEN RETURN 7.0;
      ELSIF p_tenor_months = 3 THEN RETURN 6.0;
      ELSIF p_tenor_months IN (4, 5) THEN RETURN 5.0;
      ELSE RETURN 4.0;
      END IF;
    
    WHEN 'custom' THEN
      -- First, check for exact match
      FOR v_custom_rate IN SELECT * FROM jsonb_array_elements(v_settings.custom_rates)
      LOOP
        IF (v_custom_rate->>'tenor')::INTEGER = p_tenor_months THEN
          RETURN (v_custom_rate->>'rate')::NUMERIC;
        END IF;
      END LOOP;
      
      -- If no exact match, find the highest tenor and use its rate
      v_max_tenor := 0;
      v_max_tenor_rate := 4.0;
      
      FOR v_custom_rate IN SELECT * FROM jsonb_array_elements(v_settings.custom_rates)
      LOOP
        IF (v_custom_rate->>'tenor')::INTEGER > v_max_tenor THEN
          v_max_tenor := (v_custom_rate->>'tenor')::INTEGER;
          v_max_tenor_rate := (v_custom_rate->>'rate')::NUMERIC;
        END IF;
      END LOOP;
      
      RETURN v_max_tenor_rate;
    
    ELSE RETURN 4.0;
  END CASE;
END;
$function$