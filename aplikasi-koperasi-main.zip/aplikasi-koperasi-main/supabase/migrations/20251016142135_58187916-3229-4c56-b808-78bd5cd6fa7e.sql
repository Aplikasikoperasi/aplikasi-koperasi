-- Update generate_installments function with clearer logic for legacy data
CREATE OR REPLACE FUNCTION public.generate_installments()
RETURNS TRIGGER AS $$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  v_base_date DATE;
  v_installment_status TEXT;
  i INTEGER;
BEGIN
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;

    -- Determine base date for installment calculation
    -- Logic: If disbursed, use disbursed_at
    --        If application_date is before today, use application_date (legacy data)
    --        Otherwise use approved_at (new data)
    IF NEW.disbursed_at IS NOT NULL THEN
      v_base_date := NEW.disbursed_at::DATE;
    ELSIF NEW.application_date IS NOT NULL AND NEW.application_date < CURRENT_DATE THEN
      -- Legacy/old data: use application_date if it's before today
      v_base_date := NEW.application_date;
    ELSIF NEW.approved_at IS NOT NULL THEN
      -- New data: use approval date
      v_base_date := NEW.approved_at::DATE;
    ELSE
      -- Fallback to application date
      v_base_date := NEW.application_date;
    END IF;

    v_monthly_interest_rate := get_interest_rate(NEW.tenor_months) / 100;
    v_principal_portion := NEW.amount_approved / NEW.tenor_months;
    v_interest_portion := NEW.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;

    FOR i IN 1..NEW.tenor_months LOOP
      v_due_date := (v_base_date + (i || ' months')::INTERVAL)::DATE;
      
      -- Set status based on due date
      IF v_due_date < CURRENT_DATE THEN
        v_installment_status := 'overdue';
      ELSE
        v_installment_status := 'unpaid';
      END IF;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, 
        total_amount, paid_amount, frozen_penalty, principal_paid, status
      ) VALUES (
        NEW.id, i, v_due_date, v_principal_portion, v_interest_portion, 
        v_monthly_payment, 0, 0, false, v_installment_status
      );
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';