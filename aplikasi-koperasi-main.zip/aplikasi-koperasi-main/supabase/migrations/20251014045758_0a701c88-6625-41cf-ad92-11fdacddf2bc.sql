-- Fix incorrect unique constraint to allow multi-role per user
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'user_roles_user_id_unique'
  ) THEN
    ALTER TABLE public.user_roles DROP CONSTRAINT user_roles_user_id_unique;
  END IF;
END $$;

-- Ensure proper uniqueness on (user_id, role)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'user_roles_user_role_unique'
  ) THEN
    ALTER TABLE public.user_roles
    ADD CONSTRAINT user_roles_user_role_unique UNIQUE (user_id, role);
  END IF;
END $$;

-- Ensure intended owner(s) have the owner role
-- Add owner role for known owner account(s) if missing
INSERT INTO public.user_roles (user_id, role)
SELECT au.id, 'owner'::app_role
FROM auth.users au
WHERE au.email IN ('tonyaza34@gmail.com')
  AND NOT EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = au.id AND ur.role = 'owner'::app_role
  );

-- Optional: keep both roles if present; the frontend prefers 'owner' first
-- No further changes.