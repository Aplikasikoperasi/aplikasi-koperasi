
-- Create validation trigger to prevent invalid paid_at dates
CREATE OR REPLACE FUNCTION public.validate_installment_paid_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate paid_at if it's being set or updated
  IF NEW.paid_at IS NOT NULL THEN
    -- Check if year is reasonable (between 2020 and current year + 10)
    IF EXTRACT(YEAR FROM NEW.paid_at) < 2020 OR 
       EXTRACT(YEAR FROM NEW.paid_at) > EXTRACT(YEAR FROM CURRENT_DATE) + 10 THEN
      RAISE EXCEPTION 'Tanggal pembayaran tidak valid. Tahun harus antara 2020 dan % (paid_at: %)', 
        EXTRACT(YEAR FROM CURRENT_DATE) + 10, 
        NEW.paid_at;
    END IF;
    
    -- Check if paid_at is not too far in the future (max 1 year ahead)
    IF NEW.paid_at::date > CURRENT_DATE + INTERVAL '1 year' THEN
      RAISE EXCEPTION 'Tanggal pembayaran tidak boleh lebih dari 1 tahun ke depan (paid_at: %)', NEW.paid_at;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Drop trigger if exists and recreate
DROP TRIGGER IF EXISTS validate_paid_at_before_save ON public.installments;

CREATE TRIGGER validate_paid_at_before_save
  BEFORE INSERT OR UPDATE ON public.installments
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_installment_paid_at();

-- Also validate payment_date in payments table
CREATE OR REPLACE FUNCTION public.validate_payment_date()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate payment_date
  IF NEW.payment_date IS NOT NULL THEN
    -- Check if year is reasonable (between 2020 and current year + 10)
    IF EXTRACT(YEAR FROM NEW.payment_date) < 2020 OR 
       EXTRACT(YEAR FROM NEW.payment_date) > EXTRACT(YEAR FROM CURRENT_DATE) + 10 THEN
      RAISE EXCEPTION 'Tanggal pembayaran tidak valid. Tahun harus antara 2020 dan % (payment_date: %)', 
        EXTRACT(YEAR FROM CURRENT_DATE) + 10, 
        NEW.payment_date;
    END IF;
    
    -- Check if payment_date is not too far in the future (max 1 year ahead)
    IF NEW.payment_date > CURRENT_DATE + INTERVAL '1 year' THEN
      RAISE EXCEPTION 'Tanggal pembayaran tidak boleh lebih dari 1 tahun ke depan (payment_date: %)', NEW.payment_date;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Drop trigger if exists and recreate
DROP TRIGGER IF EXISTS validate_payment_date_before_save ON public.payments;

CREATE TRIGGER validate_payment_date_before_save
  BEFORE INSERT OR UPDATE ON public.payments
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_payment_date();
