-- Attach trigger to automatically create customer auth accounts
-- This trigger will automatically create login accounts when customers are inserted or approved

CREATE TRIGGER auto_create_customer_auth_trigger
  BEFORE INSERT OR UPDATE ON public.customers
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_create_customer_auth();