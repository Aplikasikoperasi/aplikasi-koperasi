-- Function to calculate credit score based on payment history
CREATE OR REPLACE FUNCTION public.calculate_credit_score(p_customer_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_installments integer;
  v_late_installments integer;
  v_on_time_percentage numeric;
  v_credit_score integer;
BEGIN
  -- Count total installments for this customer (only from approved/disbursed applications)
  SELECT COUNT(i.id) INTO v_total_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
  AND ca.status IN ('approved', 'disbursed');
  
  -- If no installments yet, return default 5 stars
  IF v_total_installments = 0 THEN
    RETURN 5;
  END IF;
  
  -- Count late installments (paid after due date or currently overdue)
  SELECT COUNT(i.id) INTO v_late_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
  AND ca.status IN ('approved', 'disbursed')
  AND (
    -- Currently overdue
    (i.status = 'overdue')
    OR
    -- Was paid but late (paid_at > due_date)
    (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date)
  );
  
  -- Calculate on-time percentage
  v_on_time_percentage := (v_total_installments - v_late_installments)::numeric / v_total_installments::numeric;
  
  -- Convert to 5-star scale
  v_credit_score := ROUND(v_on_time_percentage * 5);
  
  -- Ensure score is between 0 and 5
  v_credit_score := GREATEST(0, LEAST(5, v_credit_score));
  
  RETURN v_credit_score;
END;
$$;

-- Function to update customer credit score
CREATE OR REPLACE FUNCTION public.update_customer_credit_score(p_customer_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_score integer;
BEGIN
  -- Calculate new credit score
  v_new_score := calculate_credit_score(p_customer_id);
  
  -- Update customer record
  UPDATE customers
  SET credit_score = v_new_score
  WHERE id = p_customer_id;
END;
$$;

-- Trigger function to update credit score after payment
CREATE OR REPLACE FUNCTION public.trigger_update_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
BEGIN
  -- Get customer_id from the application
  SELECT customer_id INTO v_customer_id
  FROM credit_applications
  WHERE id = NEW.application_id;
  
  -- Update credit score
  PERFORM update_customer_credit_score(v_customer_id);
  
  RETURN NEW;
END;
$$;

-- Create trigger on installments table for when status changes or payment is made
DROP TRIGGER IF EXISTS update_credit_score_on_installment_change ON installments;
CREATE TRIGGER update_credit_score_on_installment_change
AFTER INSERT OR UPDATE OF status, paid_at, paid_amount
ON installments
FOR EACH ROW
EXECUTE FUNCTION trigger_update_credit_score();

-- Create trigger on payments table to update when payment is recorded
CREATE OR REPLACE FUNCTION public.trigger_update_credit_score_on_payment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
BEGIN
  -- Get customer_id from the application
  SELECT customer_id INTO v_customer_id
  FROM credit_applications
  WHERE id = NEW.application_id;
  
  -- Update credit score
  PERFORM update_customer_credit_score(v_customer_id);
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS update_credit_score_on_payment ON payments;
CREATE TRIGGER update_credit_score_on_payment
AFTER INSERT OR UPDATE
ON payments
FOR EACH ROW
EXECUTE FUNCTION trigger_update_credit_score_on_payment();

-- Update credit scores for all existing customers with installment history
DO $$
DECLARE
  customer_record RECORD;
BEGIN
  FOR customer_record IN 
    SELECT DISTINCT ca.customer_id
    FROM credit_applications ca
    WHERE ca.status IN ('approved', 'disbursed')
  LOOP
    PERFORM update_customer_credit_score(customer_record.customer_id);
  END LOOP;
END $$;