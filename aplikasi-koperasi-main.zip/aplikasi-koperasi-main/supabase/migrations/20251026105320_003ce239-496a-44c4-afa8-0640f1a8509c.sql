-- Drop existing trigger first
DROP TRIGGER IF EXISTS trigger_apply_first_installment_on_approval ON credit_applications;

-- Recreate improved trigger function that handles both first installment and admin fee
CREATE OR REPLACE FUNCTION public.apply_first_installment_on_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_first_type text;
  v_first_installment record;
  v_payment_amount numeric;
  v_payment_date date;
  v_admin_fee numeric;
  v_user_id uuid := auth.uid();
BEGIN
  -- Only run when status becomes approved/disbursed
  IF TG_OP = 'UPDATE' AND NEW.status IN ('approved','disbursed') AND (OLD.status IS DISTINCT FROM NEW.status) THEN
    -- Read config
    SELECT first_installment_type INTO v_first_type FROM app_settings LIMIT 1;
    v_first_type := COALESCE(v_first_type, 'next_month');

    -- Determine payment date: use application_date for old data, approved_at date for new data
    IF NEW.application_date IS NOT NULL AND NEW.application_date < CURRENT_DATE THEN
      v_payment_date := NEW.application_date;
    ELSIF NEW.approved_at IS NOT NULL THEN
      v_payment_date := NEW.approved_at::date;
    ELSE
      v_payment_date := CURRENT_DATE;
    END IF;

    -- AUTO PAYMENT 1: First Installment (if paid_upfront)
    IF v_first_type = 'paid_upfront' THEN
      -- Ensure installments exist (should be created by other trigger)
      SELECT * INTO v_first_installment
      FROM installments 
      WHERE application_id = NEW.id AND installment_number = 1
      LIMIT 1;

      IF FOUND AND v_first_installment.status <> 'paid' THEN
        v_payment_amount := v_first_installment.total_amount;

        -- Insert payment record for first installment
        INSERT INTO payments (
          application_id,
          installment_id,
          amount,
          payment_date,
          payment_method,
          reference_number,
          notes,
          created_by
        ) VALUES (
          NEW.id,
          v_first_installment.id,
          v_payment_amount,
          v_payment_date,
          'Potong Pencairan',
          'AUTO-INST1-' || (extract(epoch from now())*1000)::bigint,
          'Pembayaran angsuran pertama otomatis saat pencairan',
          COALESCE(NEW.approved_by, v_user_id)
        );

        -- Mark installment as paid
        UPDATE installments
        SET paid_amount = v_payment_amount,
            principal_paid = true,
            status = 'paid',
            paid_at = now()
        WHERE id = v_first_installment.id;
      END IF;
    END IF;

    -- AUTO PAYMENT 2: Admin Fee (if enabled and amount > 0)
    v_admin_fee := COALESCE(NEW.admin_fee_amount, 0);
    
    IF v_admin_fee > 0 THEN
      -- Create a payment record for admin fee (not linked to installment)
      INSERT INTO payments (
        application_id,
        installment_id,
        amount,
        payment_date,
        payment_method,
        reference_number,
        notes,
        created_by
      ) VALUES (
        NEW.id,
        NULL, -- No installment_id for admin fee
        v_admin_fee,
        v_payment_date,
        'Potong Pencairan',
        'AUTO-ADMINFEE-' || (extract(epoch from now())*1000)::bigint,
        'Biaya administrasi otomatis dipotong saat pencairan',
        COALESCE(NEW.approved_by, v_user_id)
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Recreate trigger
CREATE TRIGGER trigger_apply_first_installment_on_approval
AFTER UPDATE ON credit_applications
FOR EACH ROW
EXECUTE FUNCTION apply_first_installment_on_approval();