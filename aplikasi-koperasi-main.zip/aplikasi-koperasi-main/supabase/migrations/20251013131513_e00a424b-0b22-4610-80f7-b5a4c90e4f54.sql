-- Create storage bucket for customer photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('customer-photos', 'customer-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Add photo_url column to customers table
ALTER TABLE public.customers 
ADD COLUMN IF NOT EXISTS photo_url text;

-- Create RLS policies for customer photos bucket
CREATE POLICY "Anyone can view customer photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'customer-photos');

CREATE POLICY "Authenticated users can upload customer photos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'customer-photos' AND
  (has_role(auth.uid(), 'owner'::app_role) OR 
   has_role(auth.uid(), 'admin'::app_role) OR 
   has_role(auth.uid(), 'sales'::app_role))
);

CREATE POLICY "Authenticated users can update customer photos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'customer-photos' AND
  (has_role(auth.uid(), 'owner'::app_role) OR 
   has_role(auth.uid(), 'admin'::app_role) OR 
   has_role(auth.uid(), 'sales'::app_role))
);

CREATE POLICY "Authenticated users can delete customer photos"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'customer-photos' AND
  (has_role(auth.uid(), 'owner'::app_role) OR 
   has_role(auth.uid(), 'admin'::app_role) OR 
   has_role(auth.uid(), 'sales'::app_role))
);