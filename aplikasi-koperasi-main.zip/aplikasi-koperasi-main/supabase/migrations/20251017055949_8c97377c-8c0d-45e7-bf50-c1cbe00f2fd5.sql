-- Update generate_installments function to read first_installment_type from app_settings
CREATE OR REPLACE FUNCTION public.generate_installments()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  v_base_date DATE;
  v_installment_status TEXT;
  v_first_installment_type TEXT;
  i INTEGER;
BEGIN
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;

    -- Get first_installment_type from app_settings
    SELECT first_installment_type INTO v_first_installment_type
    FROM app_settings
    LIMIT 1;
    
    -- Default to 'next_month' if not set
    v_first_installment_type := COALESCE(v_first_installment_type, 'next_month');

    -- Determine base date for installments
    IF NEW.application_date IS NOT NULL AND NEW.application_date < CURRENT_DATE THEN
      v_base_date := NEW.application_date;
    ELSIF NEW.approved_at IS NOT NULL THEN
      v_base_date := NEW.approved_at::DATE;
    ELSE
      v_base_date := NEW.application_date;
    END IF;

    v_monthly_interest_rate := get_interest_rate(NEW.tenor_months) / 100;
    v_principal_portion := NEW.amount_approved / NEW.tenor_months;
    v_interest_portion := NEW.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;

    -- Adjust starting installment based on first_installment_type
    FOR i IN 0..(NEW.tenor_months - 1) LOOP
      IF v_first_installment_type = 'paid_upfront' THEN
        -- Start from base_date for first installment (will be paid immediately)
        -- Then subsequent installments are +1 month, +2 months, etc.
        v_due_date := (v_base_date + (i || ' months')::INTERVAL)::DATE;
      ELSE
        -- Default behavior: first installment is next month (+1 month from base_date)
        v_due_date := (v_base_date + ((i + 1) || ' months')::INTERVAL)::DATE;
      END IF;
      
      -- Set status based on due date
      IF v_due_date < CURRENT_DATE THEN
        v_installment_status := 'overdue';
      ELSE
        v_installment_status := 'unpaid';
      END IF;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, 
        total_amount, paid_amount, frozen_penalty, principal_paid, status
      ) VALUES (
        NEW.id, i + 1, v_due_date, v_principal_portion, v_interest_portion, 
        v_monthly_payment, 0, 0, false, v_installment_status
      );
    END LOOP;
  END IF;
  RETURN NEW;
END;
$function$;