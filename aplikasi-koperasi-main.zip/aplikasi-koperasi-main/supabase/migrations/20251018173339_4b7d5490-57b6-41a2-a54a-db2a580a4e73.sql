-- Add UPDATE policy for blocked_customers table
-- This allows owner and admin to update blocked customer records
CREATE POLICY "Owner and admin can update blocked customers"
ON public.blocked_customers
FOR UPDATE
USING (has_role(auth.uid(), 'owner') OR has_role(auth.uid(), 'admin'))
WITH CHECK (has_role(auth.uid(), 'owner') OR has_role(auth.uid(), 'admin'));