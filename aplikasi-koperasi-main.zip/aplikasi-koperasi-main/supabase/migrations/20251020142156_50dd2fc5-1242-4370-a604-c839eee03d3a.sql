-- Add indexes for better query performance on frequently searched/filtered columns

-- Customers table indexes
CREATE INDEX IF NOT EXISTS idx_customers_full_name ON public.customers(full_name);
CREATE INDEX IF NOT EXISTS idx_customers_id_number ON public.customers(id_number);
CREATE INDEX IF NOT EXISTS idx_customers_status ON public.customers(status);
CREATE INDEX IF NOT EXISTS idx_customers_created_by ON public.customers(created_by);

-- Credit applications indexes
CREATE INDEX IF NOT EXISTS idx_applications_number ON public.credit_applications(application_number);
CREATE INDEX IF NOT EXISTS idx_applications_status ON public.credit_applications(status);
CREATE INDEX IF NOT EXISTS idx_applications_customer_id ON public.credit_applications(customer_id);
CREATE INDEX IF NOT EXISTS idx_applications_member_id ON public.credit_applications(member_id);
CREATE INDEX IF NOT EXISTS idx_applications_created_at ON public.credit_applications(created_at DESC);

-- Installments indexes
CREATE INDEX IF NOT EXISTS idx_installments_due_date ON public.installments(due_date);
CREATE INDEX IF NOT EXISTS idx_installments_status ON public.installments(status);
CREATE INDEX IF NOT EXISTS idx_installments_application_id ON public.installments(application_id);
CREATE INDEX IF NOT EXISTS idx_installments_principal_paid ON public.installments(principal_paid);

-- Payments indexes
CREATE INDEX IF NOT EXISTS idx_payments_date ON public.payments(payment_date DESC);
CREATE INDEX IF NOT EXISTS idx_payments_application_id ON public.payments(application_id);
CREATE INDEX IF NOT EXISTS idx_payments_installment_id ON public.payments(installment_id);