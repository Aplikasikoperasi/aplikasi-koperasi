-- Fix bug di fungsi apply_payment_to_installment
-- Bug: sistem menandai angsuran lunas meskipun pembayaran kurang dari total_amount

CREATE OR REPLACE FUNCTION public.apply_payment_to_installment(
  p_installment_id uuid,
  p_amount numeric,
  p_payment_date date,
  p_payment_method text,
  p_reference text,
  p_notes text DEFAULT NULL::text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_inst RECORD;
  v_penalty_rate numeric := 2.0;
  v_today date := CURRENT_DATE;
  v_is_historical boolean;
  v_days_overdue integer := 0;
  v_penalty_due numeric := 0;
  v_base_remaining numeric := 0;
  v_need numeric := 0;
  v_paying numeric := 0;
  v_pay_to_principal numeric := 0;
  v_pay_to_penalty numeric := 0;
  v_new_paid_amount numeric := 0;
  v_principal_paid boolean := false;
  v_frozen_penalty numeric := 0;
  v_frozen_days integer := 0;
  v_status text := 'partial';
  v_payment_id uuid;
  v_user_id uuid := auth.uid();
BEGIN
  -- Lock the installment row to avoid race conditions
  SELECT * INTO v_inst
  FROM installments
  WHERE id = p_installment_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Installment not found';
  END IF;

  -- CRITICAL VALIDATION: Cegah pembayaran jika sudah lunas
  IF v_inst.status = 'paid' AND v_inst.paid_amount >= v_inst.total_amount AND COALESCE(v_inst.frozen_penalty, 0) = 0 THEN
    RAISE EXCEPTION 'Angsuran ini sudah lunas. Tidak dapat menerima pembayaran tambahan.';
  END IF;

  -- Load penalty rate from settings
  SELECT penalty_rate_per_day INTO v_penalty_rate
  FROM app_settings
  ORDER BY updated_at DESC NULLS LAST, created_at DESC
  LIMIT 1;
  v_penalty_rate := COALESCE(v_penalty_rate, 2.0);

  v_is_historical := p_payment_date < v_today;

  -- Compute overdue & penalty
  IF v_is_historical THEN
    v_penalty_due := 0;
    v_frozen_days := 0;
  ELSE
    IF v_inst.principal_paid THEN
      v_penalty_due := COALESCE(v_inst.frozen_penalty, 0);
      v_frozen_days := COALESCE(v_inst.frozen_days_overdue, 0);
    ELSE
      v_days_overdue := GREATEST(0, p_payment_date - v_inst.due_date);
      IF v_days_overdue > 0 THEN
        v_penalty_due := CEIL((v_inst.total_amount * (v_penalty_rate/100) * v_days_overdue) / 1000) * 1000;
        v_frozen_days := v_days_overdue;
      ELSE
        v_penalty_due := 0;
        v_frozen_days := 0;
      END IF;
    END IF;
  END IF;

  -- Calculate remaining amount needed
  v_base_remaining := GREATEST(0, v_inst.total_amount - v_inst.paid_amount);
  v_need := v_base_remaining + v_penalty_due;
  
  IF v_need <= 0 THEN
    -- Already fully paid including penalty
    RETURN jsonb_build_object(
      'allocated_principal', 0,
      'allocated_penalty', 0,
      'remaining_need', 0,
      'payment_id', NULL,
      'status', v_inst.status
    );
  END IF;

  -- CRITICAL: Pembayaran tidak boleh melebihi kebutuhan
  v_paying := LEAST(p_amount, v_need);
  
  -- Alokasi pembayaran: prioritas principal dulu, baru penalty
  v_pay_to_principal := LEAST(v_paying, v_base_remaining);
  v_pay_to_penalty := v_paying - v_pay_to_principal;

  -- Insert payment record
  INSERT INTO payments (
    installment_id,
    application_id,
    amount,
    payment_date,
    payment_method,
    reference_number,
    notes,
    created_by
  ) VALUES (
    v_inst.id,
    v_inst.application_id,
    v_paying,
    p_payment_date,
    p_payment_method,
    NULLIF(p_reference, ''),
    p_notes,
    v_user_id
  ) RETURNING id INTO v_payment_id;

  -- Update installment dengan VALIDASI KETAT
  v_new_paid_amount := v_inst.paid_amount + v_pay_to_principal;
  
  -- CRITICAL: Principal dianggap lunas HANYA jika paid_amount >= total_amount
  v_principal_paid := v_new_paid_amount >= v_inst.total_amount;

  -- Calculate frozen penalty
  IF v_inst.principal_paid THEN
    -- Jika sudah principal_paid sebelumnya, kurangi frozen penalty
    v_frozen_penalty := GREATEST(0, COALESCE(v_inst.frozen_penalty, 0) - v_pay_to_penalty);
    v_frozen_days := CASE WHEN v_frozen_penalty > 0 THEN COALESCE(v_inst.frozen_days_overdue, 0) ELSE 0 END;
  ELSE
    -- Principal belum lunas
    IF v_principal_paid THEN
      -- Baru saja lunas principal, freeze remaining penalty
      IF (v_penalty_due - v_pay_to_penalty) <= 0 THEN
        v_frozen_penalty := 0;
        v_frozen_days := 0;
      ELSE
        v_frozen_penalty := v_penalty_due - v_pay_to_penalty;
        v_frozen_days := v_frozen_days;
      END IF;
    ELSE
      -- Belum lunas principal, keep frozen penalty
      v_frozen_penalty := COALESCE(v_inst.frozen_penalty, 0);
      v_frozen_days := COALESCE(v_inst.frozen_days_overdue, 0);
    END IF;
  END IF;

  -- CRITICAL STATUS DETERMINATION: Status 'paid' HANYA jika principal lunas DAN tidak ada penalty
  IF v_principal_paid AND v_frozen_penalty = 0 THEN
    v_status := 'paid';
  ELSIF v_new_paid_amount > 0 AND v_new_paid_amount < v_inst.total_amount THEN
    v_status := 'partial';
  ELSE
    -- Keep current status if unpaid or overdue
    v_status := CASE 
      WHEN v_inst.status IN ('unpaid', 'overdue') THEN v_inst.status
      ELSE 'partial'
    END;
  END IF;

  -- CRITICAL UPDATE dengan validasi final
  UPDATE installments
  SET 
    paid_amount = v_new_paid_amount,
    principal_paid = v_principal_paid,
    frozen_penalty = v_frozen_penalty,
    frozen_days_overdue = v_frozen_days,
    status = v_status,
    paid_at = CASE 
      WHEN v_status = 'paid' THEN p_payment_date::timestamp 
      ELSE paid_at 
    END
  WHERE id = v_inst.id;

  -- Log untuk audit trail
  RAISE NOTICE 'Payment applied - Installment: %, Paid: %, Status: %, Principal Paid: %', 
    v_inst.id, v_paying, v_status, v_principal_paid;

  RETURN jsonb_build_object(
    'payment_id', v_payment_id,
    'allocated_principal', v_pay_to_principal,
    'allocated_penalty', v_pay_to_penalty,
    'remaining_need', GREATEST(0, v_need - v_paying),
    'new_status', v_status,
    'new_paid_amount', v_new_paid_amount,
    'principal_paid', v_principal_paid,
    'frozen_penalty', v_frozen_penalty
  );
END;
$function$;

-- Tambahkan validasi di trigger untuk mencegah update manual yang salah
CREATE OR REPLACE FUNCTION public.validate_installment_status_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Validasi: Status 'paid' HANYA jika paid_amount >= total_amount DAN frozen_penalty = 0
  IF NEW.status = 'paid' THEN
    IF NEW.paid_amount < NEW.total_amount THEN
      RAISE EXCEPTION 'Status tidak dapat diset ke "paid" karena paid_amount (%) kurang dari total_amount (%). Kekurangan: %',
        NEW.paid_amount, NEW.total_amount, (NEW.total_amount - NEW.paid_amount);
    END IF;
    
    IF COALESCE(NEW.frozen_penalty, 0) > 0 THEN
      RAISE EXCEPTION 'Status tidak dapat diset ke "paid" karena masih ada frozen_penalty sebesar %',
        NEW.frozen_penalty;
    END IF;
  END IF;
  
  -- Validasi: paid_amount tidak boleh melebihi total_amount
  IF NEW.paid_amount > NEW.total_amount THEN
    RAISE EXCEPTION 'paid_amount (%) tidak boleh melebihi total_amount (%)',
      NEW.paid_amount, NEW.total_amount;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Apply trigger untuk validasi setiap update installment
DROP TRIGGER IF EXISTS trigger_validate_installment_status ON public.installments;
CREATE TRIGGER trigger_validate_installment_status
  BEFORE UPDATE ON public.installments
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_installment_status_update();

COMMENT ON FUNCTION public.apply_payment_to_installment IS 
'FIXED: Fungsi pembayaran angsuran dengan validasi ketat. Status paid HANYA jika paid_amount >= total_amount DAN frozen_penalty = 0';

COMMENT ON TRIGGER trigger_validate_installment_status ON public.installments IS 
'Validasi untuk mencegah status paid jika pembayaran belum mencapai total_amount atau masih ada penalty';