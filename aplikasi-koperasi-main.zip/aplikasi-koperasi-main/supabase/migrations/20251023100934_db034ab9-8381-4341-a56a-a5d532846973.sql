-- Fix paid_amount untuk installments yang masih punya selisih denda
-- Setelah delete payments denda, paid_amount harus = sum dari payments yang tersisa

-- VIKTOR: paid_amount seharusnya = 915,000 (sum payments yang tersisa)
UPDATE installments 
SET paid_amount = 915000
WHERE id = '0dbbe34a-cfa7-494c-9c7b-5b668a6ccc9c';

-- TARA NADILAH: paid_amount seharusnya = 570,000 (540,000 + 30,000)
UPDATE installments 
SET paid_amount = 570000
WHERE id = '76fd7b45-67a0-4a20-971b-8fa6373a473e';

-- DEPITASARI: paid_amount seharusnya = 617,000
UPDATE installments 
SET paid_amount = 617000
WHERE id = '2142e41b-e4a8-4be2-90e4-c7cf1fe54876';