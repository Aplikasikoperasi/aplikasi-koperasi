-- Ensure triggers are clean before recreating
DROP TRIGGER IF EXISTS trigger_adjust_customer_registration ON public.credit_applications;
DROP TRIGGER IF EXISTS trigger_adjust_customer_registration_on_update ON public.credit_applications;

-- Function: adjust all customers based on earliest application_date (fallback to created_at)
CREATE OR REPLACE FUNCTION public.adjust_customer_registration_date()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update using a set-based approach for performance
  UPDATE public.customers c
  SET created_at = sub.earliest_ts
  FROM (
    SELECT ca.customer_id,
           MIN(COALESCE(ca.application_date::timestamptz, ca.created_at)) AS earliest_ts
    FROM public.credit_applications ca
    GROUP BY ca.customer_id
  ) sub
  WHERE sub.customer_id = c.id
    AND sub.earliest_ts < c.created_at;
END;
$$;

-- Trigger function: adjust on insert/update of application (uses application_date primarily)
CREATE OR REPLACE FUNCTION public.auto_adjust_customer_registration_on_application()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_ts timestamptz;
BEGIN
  v_ts := COALESCE(NEW.application_date::timestamptz, NEW.created_at);

  UPDATE public.customers c
  SET created_at = v_ts
  WHERE c.id = NEW.customer_id
    AND c.created_at > v_ts;

  RETURN NEW;
END;
$$;

-- Recreate triggers for insert and for updates to application_date
CREATE TRIGGER trigger_adjust_customer_registration
  AFTER INSERT ON public.credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_adjust_customer_registration_on_application();

CREATE TRIGGER trigger_adjust_customer_registration_on_update
  AFTER UPDATE OF application_date ON public.credit_applications
  FOR EACH ROW
  WHEN (NEW.application_date IS DISTINCT FROM OLD.application_date)
  EXECUTE FUNCTION public.auto_adjust_customer_registration_on_application();

-- Run full backfill now
SELECT public.adjust_customer_registration_date();