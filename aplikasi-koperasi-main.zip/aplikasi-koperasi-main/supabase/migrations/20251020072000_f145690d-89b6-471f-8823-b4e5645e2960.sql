-- Add indexes for frequently queried columns to improve performance

-- Index for customers search by id_number and full_name
CREATE INDEX IF NOT EXISTS idx_customers_id_number ON customers(id_number);
CREATE INDEX IF NOT EXISTS idx_customers_full_name ON customers(full_name);
CREATE INDEX IF NOT EXISTS idx_customers_status ON customers(status);
CREATE INDEX IF NOT EXISTS idx_customers_created_by ON customers(created_by);

-- Index for credit applications filtering
CREATE INDEX IF NOT EXISTS idx_credit_applications_status ON credit_applications(status);
CREATE INDEX IF NOT EXISTS idx_credit_applications_customer_id ON credit_applications(customer_id);
CREATE INDEX IF NOT EXISTS idx_credit_applications_member_id ON credit_applications(member_id);
CREATE INDEX IF NOT EXISTS idx_credit_applications_application_date ON credit_applications(application_date);

-- Index for installments filtering and sorting
CREATE INDEX IF NOT EXISTS idx_installments_status ON installments(status);
CREATE INDEX IF NOT EXISTS idx_installments_due_date ON installments(due_date);
CREATE INDEX IF NOT EXISTS idx_installments_application_id ON installments(application_id);
CREATE INDEX IF NOT EXISTS idx_installments_principal_paid ON installments(principal_paid);

-- Index for payments
CREATE INDEX IF NOT EXISTS idx_payments_payment_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_application_id ON payments(application_id);
CREATE INDEX IF NOT EXISTS idx_payments_installment_id ON payments(installment_id);

-- Index for blocked customers
CREATE INDEX IF NOT EXISTS idx_blocked_customers_customer_id ON blocked_customers(customer_id);

-- Index for members filtering
CREATE INDEX IF NOT EXISTS idx_members_user_id ON members(user_id);
CREATE INDEX IF NOT EXISTS idx_members_is_active ON members(is_active);
CREATE INDEX IF NOT EXISTS idx_members_position ON members(position);

-- Index for user_roles
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role);

-- Index for customer_messages
CREATE INDEX IF NOT EXISTS idx_customer_messages_customer_id ON customer_messages(customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_messages_is_read ON customer_messages(is_read);
CREATE INDEX IF NOT EXISTS idx_customer_messages_created_at ON customer_messages(created_at);

-- Composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_installments_status_due_date ON installments(status, due_date);
CREATE INDEX IF NOT EXISTS idx_credit_applications_status_customer ON credit_applications(status, customer_id);

-- Analyze tables to update statistics for query planner
ANALYZE customers;
ANALYZE credit_applications;
ANALYZE installments;
ANALYZE payments;
ANALYZE members;
