-- Add status column to customers table for verification
ALTER TABLE public.customers 
ADD COLUMN IF NOT EXISTS status text DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected'));

-- Add approved_by and approved_at columns
ALTER TABLE public.customers 
ADD COLUMN IF NOT EXISTS approved_by uuid REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS approved_at timestamp with time zone;

-- Add index for status queries
CREATE INDEX IF NOT EXISTS idx_customers_status ON public.customers(status);

-- Update existing customers to approved status
UPDATE public.customers SET status = 'approved' WHERE status IS NULL;