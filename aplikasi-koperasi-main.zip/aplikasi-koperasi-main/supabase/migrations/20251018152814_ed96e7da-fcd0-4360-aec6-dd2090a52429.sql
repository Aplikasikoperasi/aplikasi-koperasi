-- Create history table to track all block events (persists across restores)
create table if not exists public.block_history (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete cascade,
  customer_nik text,
  reason text,
  blocked_by uuid,
  blocked_at timestamptz not null default now()
);

-- Enable RLS (history is non-sensitive; allow authenticated users to view)
alter table public.block_history enable row level security;

do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='block_history' and policyname='Authenticated users can view block history'
  ) then
    create policy "Authenticated users can view block history"
    on public.block_history for select
    to authenticated
    using (true);
  end if;
end $$;

-- Update block_customer function to record history and use it for permanent block logic
create or replace function public.block_customer(p_customer_id uuid, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_restoration_status text;
  v_user_id uuid := auth.uid();
  v_final_reason text;
  v_prev_block_count integer := 0;
  v_total_block_count integer := 0;
  v_customer_nik text;
begin
  if v_user_id is null then
    return jsonb_build_object('success', false, 'message', 'Unauthorized');
  end if;

  -- Role check
  if not (
    public.has_role(v_user_id, 'owner') or 
    public.has_role(v_user_id, 'admin') or 
    public.has_role(v_user_id, 'sales')
  ) then
    return jsonb_build_object('success', false, 'message', 'Akses ditolak');
  end if;

  -- Get customer info & NIK
  select restoration_status, nik into v_restoration_status, v_customer_nik
  from public.customers
  where id = p_customer_id;

  if v_restoration_status = 'permanently_blocked' then
    return jsonb_build_object('success', false, 'message', 'Nasabah berstatus blokir permanen');
  end if;

  -- Count previous block events from history (persists across restores)
  select count(*) into v_prev_block_count
  from public.block_history
  where customer_id = p_customer_id
     or (v_customer_nik is not null and customer_nik = v_customer_nik);

  -- Record new block event
  insert into public.block_history (customer_id, customer_nik, reason, blocked_by)
  values (p_customer_id, v_customer_nik, coalesce(p_reason, 'Diblokir oleh staf'), v_user_id);

  v_total_block_count := v_prev_block_count + 1;

  -- Set reason and permanent block if this is 2nd (or more) time
  v_final_reason := coalesce(p_reason, 'Diblokir oleh staf');
  if v_total_block_count >= 2 then
    v_final_reason := 'BLOKIR PERMANEN - Nasabah telah diblokir sebanyak ' || v_total_block_count::text || ' kali. ' || v_final_reason;

    update public.customers
    set restoration_status = 'permanently_blocked',
        credit_score = 0
    where id = p_customer_id;
  end if;

  -- Upsert into blocked_customers (current block state)
  insert into public.blocked_customers (
    customer_id, blocked_reason, blocked_by, consecutive_missed_months
  ) values (
    p_customer_id, v_final_reason, v_user_id, 0
  )
  on conflict (customer_id) do update
  set blocked_reason = excluded.blocked_reason,
      blocked_by = excluded.blocked_by,
      blocked_at = now(),
      consecutive_missed_months = 0;

  return jsonb_build_object('success', true, 'message', case when v_total_block_count >= 2 then 'Nasabah diblokir permanen' else 'Nasabah diblokir' end);
end; $$;