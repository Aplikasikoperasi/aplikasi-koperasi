-- Create enum for log categories
CREATE TYPE public.log_category AS ENUM (
  'member_management',
  'customer_management', 
  'credit_application',
  'payment',
  'blocking',
  'security',
  'system_error'
);

-- Create system_logs table
CREATE TABLE public.system_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  user_name TEXT,
  category public.log_category NOT NULL,
  action TEXT NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.system_logs ENABLE ROW LEVEL SECURITY;

-- Only owner and admin can view logs
CREATE POLICY "Owner and admin can view logs"
ON public.system_logs
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'owner'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role)
);

-- All authenticated users can insert logs
CREATE POLICY "Authenticated users can insert logs"
ON public.system_logs
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Create index for faster queries
CREATE INDEX idx_system_logs_created_at ON public.system_logs(created_at DESC);
CREATE INDEX idx_system_logs_category ON public.system_logs(category);
CREATE INDEX idx_system_logs_user_id ON public.system_logs(user_id);

-- Function to delete logs older than 30 days
CREATE OR REPLACE FUNCTION public.cleanup_old_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.system_logs
  WHERE created_at < (now() - INTERVAL '30 days');
END;
$$;

-- Function to log system events
CREATE OR REPLACE FUNCTION public.log_system_event(
  p_user_id UUID,
  p_user_name TEXT,
  p_category log_category,
  p_action TEXT,
  p_description TEXT,
  p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_log_id UUID;
BEGIN
  INSERT INTO public.system_logs (
    user_id,
    user_name,
    category,
    action,
    description,
    metadata
  ) VALUES (
    p_user_id,
    p_user_name,
    p_category,
    p_action,
    p_description,
    p_metadata
  ) RETURNING id INTO v_log_id;
  
  -- Auto cleanup old logs
  PERFORM cleanup_old_logs();
  
  RETURN v_log_id;
END;
$$;