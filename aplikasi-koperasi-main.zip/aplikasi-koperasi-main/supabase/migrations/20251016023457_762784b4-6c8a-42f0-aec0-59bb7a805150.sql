-- Patch: include application_date as fallback for due date base
CREATE OR REPLACE FUNCTION public.generate_installments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_remaining_principal NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  i INTEGER;
BEGIN
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;

    v_monthly_interest_rate := NEW.interest_rate / 100;  
    v_principal_portion := NEW.amount_approved / NEW.tenor_months;
    v_interest_portion := NEW.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;

    v_remaining_principal := NEW.amount_approved;

    FOR i IN 1..NEW.tenor_months LOOP
      v_due_date := (COALESCE(NEW.disbursed_at, NEW.approved_at, NEW.application_date)::DATE + (i || ' months')::INTERVAL)::DATE;
      IF i = NEW.tenor_months THEN
        v_principal_portion := v_remaining_principal;
        v_monthly_payment := v_principal_portion + v_interest_portion;
      END IF;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, total_amount, paid_amount, status
      ) VALUES (
        NEW.id, i, v_due_date, v_principal_portion, v_interest_portion, v_monthly_payment, 0, 'unpaid'
      );

      v_remaining_principal := v_remaining_principal - v_principal_portion;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

-- Recalculate existing installments again using application_date fallback
DO $$
DECLARE
  app RECORD;
  v_monthly_interest_rate NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_monthly_payment NUMERIC;
  v_remaining_principal NUMERIC;
  v_due_date DATE;
  i INTEGER;
BEGIN
  FOR app IN 
    SELECT * FROM credit_applications 
    WHERE status IN ('approved','disbursed')
  LOOP
    DELETE FROM installments WHERE application_id = app.id;

    v_monthly_interest_rate := app.interest_rate / 100;
    v_principal_portion := app.amount_approved / app.tenor_months;
    v_interest_portion := app.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;
    v_remaining_principal := app.amount_approved;

    FOR i IN 1..app.tenor_months LOOP
      v_due_date := (COALESCE(app.disbursed_at, app.approved_at, app.application_date)::DATE + (i || ' months')::INTERVAL)::DATE;
      IF i = app.tenor_months THEN
        v_principal_portion := v_remaining_principal;
        v_monthly_payment := v_principal_portion + v_interest_portion;
      END IF;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, total_amount, paid_amount, status
      ) VALUES (
        app.id, i, v_due_date, v_principal_portion, v_interest_portion, v_monthly_payment, 0, 'unpaid'
      );

      v_remaining_principal := v_remaining_principal - v_principal_portion;
    END LOOP;
  END LOOP;
END $$;
