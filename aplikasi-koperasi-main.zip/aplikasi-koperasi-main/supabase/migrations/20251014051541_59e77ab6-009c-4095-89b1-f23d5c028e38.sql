-- Global data reset to simulate fresh install (keep auth/storage intact)
BEGIN;

-- Truncate all application data tables
TRUNCATE TABLE
  public.blocked_customers,
  public.payments,
  public.installments,
  public.credit_applications,
  public.customers,
  public.app_settings,
  public.financial_reports,
  public.members,
  public.profiles,
  public.user_roles
RESTART IDENTITY CASCADE;

COMMIT;