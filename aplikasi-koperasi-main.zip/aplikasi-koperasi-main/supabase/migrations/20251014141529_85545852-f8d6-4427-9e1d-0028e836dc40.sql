-- Add application_date column to credit_applications table
ALTER TABLE public.credit_applications
ADD COLUMN application_date DATE;

-- Set default value for existing records to their created_at date
UPDATE public.credit_applications
SET application_date = created_at::DATE
WHERE application_date IS NULL;