-- Add nik column to customers table
ALTER TABLE public.customers 
ADD COLUMN IF NOT EXISTS nik text;