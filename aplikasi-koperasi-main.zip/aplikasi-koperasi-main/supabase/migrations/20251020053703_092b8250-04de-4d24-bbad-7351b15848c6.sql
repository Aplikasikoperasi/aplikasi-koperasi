-- Create trigger to automatically handle first installment payment on approval
CREATE TRIGGER trigger_apply_first_installment
  AFTER INSERT OR UPDATE ON public.credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.apply_first_installment_on_approval();

-- Fix existing application that missed the automatic first payment (APP-1760937650660)
DO $$
DECLARE
  v_application_id uuid;
  v_first_installment_id uuid;
  v_payment_amount numeric;
  v_payment_date date;
  v_approved_by uuid;
  v_app_date date;
BEGIN
  -- Get the application details
  SELECT id, approved_by, application_date 
  INTO v_application_id, v_approved_by, v_app_date
  FROM credit_applications 
  WHERE application_number = 'APP-1760937650660';

  IF v_application_id IS NOT NULL THEN
    -- Get first installment
    SELECT id, total_amount 
    INTO v_first_installment_id, v_payment_amount
    FROM installments 
    WHERE application_id = v_application_id 
      AND installment_number = 1
      AND status = 'unpaid';

    IF v_first_installment_id IS NOT NULL THEN
      -- Determine payment date
      IF v_app_date IS NOT NULL AND v_app_date < CURRENT_DATE THEN
        v_payment_date := v_app_date;
      ELSE
        v_payment_date := CURRENT_DATE;
      END IF;

      -- Insert payment record
      INSERT INTO payments (
        application_id,
        installment_id,
        amount,
        payment_date,
        payment_method,
        reference_number,
        notes,
        created_by
      ) VALUES (
        v_application_id,
        v_first_installment_id,
        v_payment_amount,
        v_payment_date,
        'Potong Pencairan',
        'AUTO-' || (extract(epoch from now())*1000)::bigint,
        'Pembayaran angsuran pertama otomatis saat pencairan (diperbaiki)',
        v_approved_by
      );

      -- Mark installment as paid
      UPDATE installments
      SET paid_amount = v_payment_amount,
          principal_paid = true,
          status = 'paid',
          paid_at = now()
      WHERE id = v_first_installment_id;

      RAISE NOTICE 'Fixed first payment for application APP-1760937650660';
    END IF;
  END IF;
END $$;