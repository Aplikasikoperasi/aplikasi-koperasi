-- Function to auto-approve customers created by owner/admin
CREATE OR REPLACE FUNCTION public.auto_approve_customer_by_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_is_owner_or_admin boolean;
BEGIN
  -- Check if creator is owner or admin
  IF NEW.created_by IS NOT NULL THEN
    v_is_owner_or_admin := (
      has_role_text(NEW.created_by, 'owner'::text) OR 
      has_role_text(NEW.created_by, 'admin'::text)
    );
    
    -- Auto-approve if created by owner/admin
    IF v_is_owner_or_admin THEN
      NEW.status := 'approved';
      NEW.approved_by := NEW.created_by;
      NEW.approved_at := NOW();
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Function to auto-approve credit applications created by owner/admin
CREATE OR REPLACE FUNCTION public.auto_approve_application_by_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_is_owner_or_admin boolean;
  v_creator_id uuid;
BEGIN
  -- Get creator from member_id (person responsible for the application)
  IF NEW.member_id IS NOT NULL THEN
    SELECT user_id INTO v_creator_id
    FROM members
    WHERE id = NEW.member_id;
    
    IF v_creator_id IS NOT NULL THEN
      v_is_owner_or_admin := (
        has_role_text(v_creator_id, 'owner'::text) OR 
        has_role_text(v_creator_id, 'admin'::text)
      );
      
      -- Auto-approve if created by owner/admin
      IF v_is_owner_or_admin THEN
        NEW.status := 'approved';
        NEW.approved_by := v_creator_id;
        NEW.approved_at := NOW();
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for customers (only on INSERT)
DROP TRIGGER IF EXISTS trigger_auto_approve_customer ON customers;
CREATE TRIGGER trigger_auto_approve_customer
  BEFORE INSERT ON customers
  FOR EACH ROW
  EXECUTE FUNCTION auto_approve_customer_by_role();

-- Create trigger for credit applications (only on INSERT)
DROP TRIGGER IF EXISTS trigger_auto_approve_application ON credit_applications;
CREATE TRIGGER trigger_auto_approve_application
  BEFORE INSERT ON credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION auto_approve_application_by_role();