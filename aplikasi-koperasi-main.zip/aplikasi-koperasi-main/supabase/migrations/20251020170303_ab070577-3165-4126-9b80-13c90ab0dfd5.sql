-- Function to adjust customer created_at based on their earliest credit application
CREATE OR REPLACE FUNCTION public.adjust_customer_registration_date()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update customer created_at to match their earliest application if application is earlier
  UPDATE public.customers c
  SET created_at = (
    SELECT MIN(ca.created_at)
    FROM public.credit_applications ca
    WHERE ca.customer_id = c.id
  )
  WHERE EXISTS (
    SELECT 1
    FROM public.credit_applications ca
    WHERE ca.customer_id = c.id
    AND ca.created_at < c.created_at
  );
END;
$$;

-- Run the function once to fix existing data
SELECT public.adjust_customer_registration_date();

-- Trigger function to auto-adjust customer registration date when new application is created
CREATE OR REPLACE FUNCTION public.auto_adjust_customer_registration_on_application()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- If this application's created_at is earlier than customer's registration date, adjust it
  UPDATE public.customers
  SET created_at = NEW.created_at
  WHERE id = NEW.customer_id
  AND created_at > NEW.created_at;
  
  RETURN NEW;
END;
$$;

-- Create trigger that runs after each new credit application insert
CREATE TRIGGER trigger_adjust_customer_registration
  AFTER INSERT ON public.credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_adjust_customer_registration_on_application();