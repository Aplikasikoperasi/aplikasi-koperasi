-- Ensure correct trigger order and handle INSERT + UPDATE
-- 1) Drop old triggers if exist
DROP TRIGGER IF EXISTS trigger_apply_first_installment_on_approval ON credit_applications;
DROP TRIGGER IF EXISTS trigger_01_generate_installments ON credit_applications;
DROP TRIGGER IF EXISTS trigger_02_apply_first_installment_on_approval ON credit_applications;

-- 2) Attach generate_installments to both INSERT and UPDATE with explicit order prefix
CREATE TRIGGER trigger_01_generate_installments
AFTER INSERT OR UPDATE ON credit_applications
FOR EACH ROW
EXECUTE FUNCTION public.generate_installments();

-- 3) Update function to support INSERT and compute admin fee if missing, and tie admin fee payment to first installment
CREATE OR REPLACE FUNCTION public.apply_first_installment_on_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_first_type text;
  v_first_installment record;
  v_payment_amount numeric;
  v_payment_date date;
  v_admin_fee numeric := 0;
  v_settings record;
  v_user_id uuid := auth.uid();
BEGIN
  -- Run for both INSERT and UPDATE when status is approved/disbursed
  IF NEW.status IN ('approved','disbursed') THEN
    -- Read config
    SELECT first_installment_type, admin_fee_enabled, admin_fee_amount INTO v_settings FROM app_settings LIMIT 1;

    -- Determine payment date
    IF NEW.approved_at IS NOT NULL THEN
      v_payment_date := NEW.approved_at::date;
    ELSIF NEW.application_date IS NOT NULL AND NEW.application_date < CURRENT_DATE THEN
      v_payment_date := NEW.application_date;
    ELSE
      v_payment_date := CURRENT_DATE;
    END IF;

    -- Compute admin fee if not set on the row
    IF COALESCE(NEW.admin_fee_amount, 0) = 0 AND COALESCE(v_settings.admin_fee_enabled, false) = true AND COALESCE(v_settings.admin_fee_amount, 0) > 0 THEN
      v_admin_fee := ROUND(COALESCE(NEW.amount_approved, NEW.amount_requested) * (v_settings.admin_fee_amount / 100.0));
      -- Persist admin fee on application (AFTER triggers need explicit update)
      UPDATE credit_applications
      SET admin_fee_amount = v_admin_fee
      WHERE id = NEW.id AND COALESCE(admin_fee_amount,0) = 0;
    ELSE
      v_admin_fee := COALESCE(NEW.admin_fee_amount, 0);
    END IF;

    -- First Installment auto payment if paid_upfront
    IF COALESCE(v_settings.first_installment_type, 'next_month') = 'paid_upfront' THEN
      -- Ensure first installment exists (created by trigger_01_generate_installments)
      SELECT * INTO v_first_installment
      FROM installments
      WHERE application_id = NEW.id AND installment_number = 1
      LIMIT 1;

      IF FOUND AND v_first_installment.status <> 'paid' THEN
        v_payment_amount := v_first_installment.total_amount;

        -- Insert payment for first installment
        INSERT INTO payments (
          application_id, installment_id, amount, payment_date, payment_method, reference_number, notes, created_by
        ) VALUES (
          NEW.id, v_first_installment.id, v_payment_amount, v_payment_date,
          'Potong Pencairan', 'AUTO-INST1-' || (extract(epoch from now())*1000)::bigint,
          'Pembayaran angsuran pertama otomatis saat persetujuan', COALESCE(NEW.approved_by, v_user_id)
        );

        -- Mark installment as paid
        UPDATE installments
        SET paid_amount = v_payment_amount,
            principal_paid = true,
            status = 'paid',
            paid_at = now()
        WHERE id = v_first_installment.id;

        -- If admin fee > 0, record as a separate payment tied to the first installment
        IF v_admin_fee > 0 THEN
          INSERT INTO payments (
            application_id, installment_id, amount, payment_date, payment_method, reference_number, notes, created_by
          ) VALUES (
            NEW.id, v_first_installment.id, v_admin_fee, v_payment_date,
            'Potong Pencairan', 'AUTO-ADMINFEE-' || (extract(epoch from now())*1000)::bigint,
            'Biaya administrasi otomatis dipotong saat persetujuan', COALESCE(NEW.approved_by, v_user_id)
          );
        END IF;
      ELSE
        -- Even if first installment already paid (or not found), still record admin fee if > 0 and not yet recorded
        IF v_admin_fee > 0 AND FOUND THEN
          -- Check if admin fee payment already exists (by reference prefix)
          IF NOT EXISTS (
            SELECT 1 FROM payments WHERE application_id = NEW.id AND installment_id = v_first_installment.id AND reference_number LIKE 'AUTO-ADMINFEE-%'
          ) THEN
            INSERT INTO payments (
              application_id, installment_id, amount, payment_date, payment_method, reference_number, notes, created_by
            ) VALUES (
              NEW.id, v_first_installment.id, v_admin_fee, v_payment_date,
              'Potong Pencairan', 'AUTO-ADMINFEE-' || (extract(epoch from now())*1000)::bigint,
              'Biaya administrasi otomatis dipotong saat persetujuan', COALESCE(NEW.approved_by, v_user_id)
            );
          END IF;
        END IF;
      END IF;
    ELSE
      -- If first installment is not paid upfront but admin fee applies, we still record admin fee to first installment slot
      IF v_admin_fee > 0 THEN
        -- Find first installment to anchor the payment record
        SELECT * INTO v_first_installment
        FROM installments
        WHERE application_id = NEW.id
        ORDER BY installment_number
        LIMIT 1;

        IF FOUND THEN
          IF NOT EXISTS (
            SELECT 1 FROM payments WHERE application_id = NEW.id AND installment_id = v_first_installment.id AND reference_number LIKE 'AUTO-ADMINFEE-%'
          ) THEN
            INSERT INTO payments (
              application_id, installment_id, amount, payment_date, payment_method, reference_number, notes, created_by
            ) VALUES (
              NEW.id, v_first_installment.id, v_admin_fee, v_payment_date,
              'Potong Pencairan', 'AUTO-ADMINFEE-' || (extract(epoch from now())*1000)::bigint,
              'Biaya administrasi otomatis dipotong saat persetujuan', COALESCE(NEW.approved_by, v_user_id)
            );
          END IF;
        END IF;
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;

-- 4) Attach AFTER triggers for both INSERT and UPDATE with order suffix
CREATE TRIGGER trigger_02_apply_first_installment_on_approval
AFTER INSERT OR UPDATE ON credit_applications
FOR EACH ROW
EXECUTE FUNCTION public.apply_first_installment_on_approval();