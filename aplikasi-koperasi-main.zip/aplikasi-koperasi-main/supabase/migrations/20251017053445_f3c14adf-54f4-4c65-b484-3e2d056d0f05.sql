-- Create log_category enum if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'log_category') THEN
    CREATE TYPE log_category AS ENUM (
      'member_management',
      'customer_management',
      'credit_application',
      'payment',
      'blocking',
      'security',
      'system_error'
    );
  END IF;
END $$;

-- Create system_logs table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.system_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  user_name TEXT,
  category log_category NOT NULL,
  action TEXT NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Create index if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_system_logs_created_at') THEN
    CREATE INDEX idx_system_logs_created_at ON public.system_logs(created_at DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_system_logs_category') THEN
    CREATE INDEX idx_system_logs_category ON public.system_logs(category);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_system_logs_user_id') THEN
    CREATE INDEX idx_system_logs_user_id ON public.system_logs(user_id);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE public.system_logs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and recreate
DROP POLICY IF EXISTS "Owner and admin can view logs" ON public.system_logs;
DROP POLICY IF EXISTS "Authenticated users can insert logs" ON public.system_logs;

CREATE POLICY "Owner and admin can view logs"
  ON public.system_logs
  FOR SELECT
  USING (
    has_role(auth.uid(), 'owner'::app_role) OR 
    has_role(auth.uid(), 'admin'::app_role)
  );

CREATE POLICY "Authenticated users can insert logs"
  ON public.system_logs
  FOR INSERT
  WITH CHECK (true);

-- Create cleanup function
CREATE OR REPLACE FUNCTION public.cleanup_old_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.system_logs
  WHERE created_at < (now() - INTERVAL '30 days');
END;
$$;

-- Create log_system_event function
CREATE OR REPLACE FUNCTION public.log_system_event(
  p_user_id UUID,
  p_user_name TEXT,
  p_category log_category,
  p_action TEXT,
  p_description TEXT,
  p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_log_id UUID;
BEGIN
  INSERT INTO public.system_logs (
    user_id,
    user_name,
    category,
    action,
    description,
    metadata
  ) VALUES (
    p_user_id,
    p_user_name,
    p_category,
    p_action,
    p_description,
    p_metadata
  ) RETURNING id INTO v_log_id;
  
  -- Auto cleanup old logs (every 100 inserts to avoid performance issues)
  IF random() < 0.01 THEN
    PERFORM cleanup_old_logs();
  END IF;
  
  RETURN v_log_id;
END;
$$;