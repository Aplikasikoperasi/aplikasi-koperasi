-- Fix search_path for restore_blocked_customer function
CREATE OR REPLACE FUNCTION public.restore_blocked_customer(p_customer_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_restoration_status TEXT;
BEGIN
  -- Get customer's restoration status
  SELECT restoration_status INTO v_restoration_status
  FROM customers
  WHERE id = p_customer_id;
  
  -- Check if permanently blocked
  IF v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Nasabah dengan status blokir permanen tidak dapat dipulihkan'
    );
  END IF;
  
  -- Delete from blocked_customers
  DELETE FROM blocked_customers WHERE customer_id = p_customer_id;
  
  -- Update customer: reset credit score to 5 and update restoration status
  UPDATE customers
  SET 
    credit_score = 5,
    restoration_status = CASE 
      WHEN restoration_status = 'never_restored' THEN 'restored_once'
      ELSE restoration_status
    END
  WHERE id = p_customer_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'message', 'Nasabah berhasil dipulihkan dengan skor kredit 5'
  );
END;
$$;

-- Fix search_path for handle_reblock_restored_customer function
CREATE OR REPLACE FUNCTION public.handle_reblock_restored_customer()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_restoration_status TEXT;
BEGIN
  -- Get customer's restoration status
  SELECT restoration_status INTO v_restoration_status
  FROM customers
  WHERE id = NEW.customer_id;
  
  -- If customer was restored once, make it permanent block
  IF v_restoration_status = 'restored_once' THEN
    UPDATE customers
    SET 
      restoration_status = 'permanently_blocked',
      credit_score = 0
    WHERE id = NEW.customer_id;
    
    -- Update block reason
    NEW.blocked_reason := 'BLOKIR PERMANEN - Nasabah diblokir kembali setelah pemulihan sebelumnya. ' || NEW.blocked_reason;
  END IF;
  
  RETURN NEW;
END;
$$;