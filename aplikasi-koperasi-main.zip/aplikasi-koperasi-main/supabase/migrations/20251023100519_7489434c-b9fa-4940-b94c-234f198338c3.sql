-- Cleanup data historis denda
-- Hapus pembayaran yang murni denda (tidak ada pembayaran pokok)

-- 1. ARLIDA SITUMORANG - Hapus payment denda 444.000
DELETE FROM payments WHERE id = '53c4ab37-e8ba-462a-b0a5-fd1819dca193';
UPDATE installments 
SET paid_amount = paid_amount - 444000 
WHERE id = '69b02396-caf2-4df2-8b97-cd2af5691795';

-- 2. VIKTOR HASOLOAN TAMBUNAN - Hapus payment denda 568.000
DELETE FROM payments WHERE id = 'ea35a703-ee39-4ffb-968d-51cc1cfaf495';
UPDATE installments 
SET paid_amount = paid_amount - 568000 
WHERE id = '0dbbe34a-cfa7-494c-9c7b-5b668a6ccc9c';

-- 3. M. RESTY - Hapus payment denda 420.000
DELETE FROM payments WHERE id = '94631321-3f3c-479f-82d2-b3f7f9188fb5';
UPDATE installments 
SET paid_amount = paid_amount - 420000 
WHERE id = '50f6948d-e1e5-4c42-be5a-5dd8f4cebea4';

-- 4. TARA NADILAH - Update payment, kurangi denda dari amount
UPDATE payments 
SET amount = 30000,
    notes = 'Input data kredit lama (tidak ada denda) - Disesuaikan dari Rp 384.000'
WHERE id = '2ff562b8-aab0-4e6c-b2df-3110b2cc309a';
UPDATE installments 
SET paid_amount = paid_amount - 354000 
WHERE id = '76fd7b45-67a0-4a20-971b-8fa6373a473e';

-- 5. DEPITASARI NOPIANTI - Hapus payment denda 272.000
DELETE FROM payments WHERE id = 'cb7b071b-6ea9-43d0-b757-6e0c33d46c2a';
UPDATE installments 
SET paid_amount = paid_amount - 272000 
WHERE id = '2142e41b-e4a8-4be2-90e4-c7cf1fe54876';