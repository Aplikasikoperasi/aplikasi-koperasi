-- Update trigger to create customer even if NIK is duplicate (different members)
CREATE OR REPLACE FUNCTION public.create_customer_for_sales_member()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  -- Only create customer if member is active and NOT an owner
  IF NEW.is_active = true AND NEW.position != 'Owner' THEN
    -- Check if customer doesn't already exist for THIS SPECIFIC member
    IF NOT EXISTS (
      SELECT 1
      FROM public.customers
      WHERE created_by = NEW.id
    ) THEN
      -- Get highest customer id_number
      SELECT COALESCE(
        MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
        0
      ) INTO max_num
      FROM public.customers
      WHERE id_number ~ '^N[0-9]+$';
      
      next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
      
      -- Insert customer record with member's data
      INSERT INTO public.customers (
        id_number,
        full_name,
        nik,
        date_of_birth,
        phone,
        address,
        occupation,
        photo_url,
        created_by
      ) VALUES (
        next_id_number,
        NEW.full_name,
        NEW.nik,
        NEW.date_of_birth,
        NEW.phone,
        NEW.address,
        NEW.occupation,
        NEW.photo_url,
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Update handle status change function similarly
CREATE OR REPLACE FUNCTION public.handle_member_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  -- If member is deactivated, remove them from customers table (except owner)
  IF NEW.is_active = false AND OLD.is_active = true AND NEW.position != 'Owner' THEN
    DELETE FROM public.customers
    WHERE created_by = NEW.id;
  END IF;
  
  -- If member is reactivated, recreate customer record (except owner)
  IF NEW.is_active = true AND OLD.is_active = false AND NEW.position != 'Owner' THEN
    -- Check if customer doesn't already exist for THIS SPECIFIC member
    IF NOT EXISTS (
      SELECT 1
      FROM public.customers
      WHERE created_by = NEW.id
    ) THEN
      -- Get highest customer id_number
      SELECT COALESCE(
        MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
        0
      ) INTO max_num
      FROM public.customers
      WHERE id_number ~ '^N[0-9]+$';
      
      next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
      
      -- Insert customer record
      INSERT INTO public.customers (
        id_number,
        full_name,
        nik,
        date_of_birth,
        phone,
        address,
        occupation,
        photo_url,
        created_by
      ) VALUES (
        next_id_number,
        NEW.full_name,
        NEW.nik,
        NEW.date_of_birth,
        NEW.phone,
        NEW.address,
        NEW.occupation,
        NEW.photo_url,
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Populate customers for all remaining active members without customer records
DO $$
DECLARE
  member_record RECORD;
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  FOR member_record IN 
    SELECT m.* 
    FROM members m
    LEFT JOIN customers c ON c.created_by = m.id
    WHERE m.position != 'Owner' 
      AND (m.is_active IS NULL OR m.is_active = true)
      AND c.id IS NULL
  LOOP
    -- Get highest customer id_number
    SELECT COALESCE(
      MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
      0
    ) INTO max_num
    FROM public.customers
    WHERE id_number ~ '^N[0-9]+$';
    
    next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
    
    -- Insert customer record
    INSERT INTO public.customers (
      id_number,
      full_name,
      nik,
      date_of_birth,
      phone,
      address,
      occupation,
      photo_url,
      created_by
    ) VALUES (
      next_id_number,
      member_record.full_name,
      member_record.nik,
      member_record.date_of_birth,
      member_record.phone,
      member_record.address,
      member_record.occupation,
      member_record.photo_url,
      member_record.id
    );
    
    RAISE NOTICE 'Created customer for member: %', member_record.full_name;
  END LOOP;
END $$;