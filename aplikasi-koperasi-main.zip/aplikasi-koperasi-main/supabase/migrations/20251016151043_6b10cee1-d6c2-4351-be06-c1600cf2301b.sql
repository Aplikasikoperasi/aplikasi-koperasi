-- Update generate_installments function dengan logika baru
-- Jika application_date < tanggal sistem (data lama) -> gunakan application_date
-- Jika application_date >= tanggal sistem (data baru) -> gunakan approved_at
CREATE OR REPLACE FUNCTION public.generate_installments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  v_base_date DATE;
  v_installment_status TEXT;
  i INTEGER;
BEGIN
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;

    -- Logika baru untuk menentukan tanggal base angsuran:
    -- Jika application_date sebelum hari ini (data lama), gunakan application_date
    -- Jika application_date hari ini atau setelahnya (data baru), gunakan approved_at
    IF NEW.application_date IS NOT NULL AND NEW.application_date < CURRENT_DATE THEN
      -- Data lama: gunakan tanggal pengajuan sebagai base
      v_base_date := NEW.application_date;
    ELSIF NEW.approved_at IS NOT NULL THEN
      -- Data baru: gunakan tanggal persetujuan sebagai base
      v_base_date := NEW.approved_at::DATE;
    ELSE
      -- Fallback ke tanggal pengajuan
      v_base_date := NEW.application_date;
    END IF;

    v_monthly_interest_rate := get_interest_rate(NEW.tenor_months) / 100;
    v_principal_portion := NEW.amount_approved / NEW.tenor_months;
    v_interest_portion := NEW.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;

    FOR i IN 1..NEW.tenor_months LOOP
      v_due_date := (v_base_date + (i || ' months')::INTERVAL)::DATE;
      
      -- Set status berdasarkan due date
      IF v_due_date < CURRENT_DATE THEN
        v_installment_status := 'overdue';
      ELSE
        v_installment_status := 'unpaid';
      END IF;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, 
        total_amount, paid_amount, frozen_penalty, principal_paid, status
      ) VALUES (
        NEW.id, i, v_due_date, v_principal_portion, v_interest_portion, 
        v_monthly_payment, 0, 0, false, v_installment_status
      );
    END LOOP;
  END IF;
  RETURN NEW;
END;
$function$;