-- Add photo_url column to members table
ALTER TABLE public.members ADD COLUMN photo_url text;