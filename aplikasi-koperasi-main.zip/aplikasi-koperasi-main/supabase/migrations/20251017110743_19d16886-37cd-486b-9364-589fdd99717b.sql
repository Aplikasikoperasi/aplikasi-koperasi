-- Update generate_installments function to properly handle disbursement date and first installment timing
CREATE OR REPLACE FUNCTION public.generate_installments()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  v_disbursement_date DATE;
  v_installment_status TEXT;
  v_first_installment_type TEXT;
  i INTEGER;
BEGIN
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;

    -- Get first_installment_type from app_settings
    SELECT first_installment_type INTO v_first_installment_type
    FROM app_settings
    LIMIT 1;
    
    -- Default to 'next_month' if not set
    v_first_installment_type := COALESCE(v_first_installment_type, 'next_month');

    -- Determine disbursement date
    -- For old credit data (application_date < today), use application_date as disbursement
    -- For new credit data, use approved_at as disbursement
    IF NEW.application_date IS NOT NULL AND NEW.application_date < CURRENT_DATE THEN
      v_disbursement_date := NEW.application_date;
    ELSIF NEW.approved_at IS NOT NULL THEN
      v_disbursement_date := NEW.approved_at::DATE;
    ELSE
      v_disbursement_date := COALESCE(NEW.application_date, CURRENT_DATE);
    END IF;

    v_monthly_interest_rate := get_interest_rate(NEW.tenor_months) / 100;
    v_principal_portion := NEW.amount_approved / NEW.tenor_months;
    v_interest_portion := NEW.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;

    -- Generate installments based on first_installment_type
    FOR i IN 0..(NEW.tenor_months - 1) LOOP
      IF v_first_installment_type = 'paid_upfront' THEN
        -- paid_upfront: first installment due on disbursement date (paid immediately)
        -- subsequent installments are +1 month, +2 months, etc from disbursement
        v_due_date := (v_disbursement_date + (i || ' months')::INTERVAL)::DATE;
      ELSE
        -- next_month: first installment due next month from disbursement
        -- subsequent installments follow monthly
        v_due_date := (v_disbursement_date + ((i + 1) || ' months')::INTERVAL)::DATE;
      END IF;
      
      -- Set status based on due date
      IF v_due_date < CURRENT_DATE THEN
        v_installment_status := 'overdue';
      ELSE
        v_installment_status := 'unpaid';
      END IF;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, 
        total_amount, paid_amount, frozen_penalty, principal_paid, status
      ) VALUES (
        NEW.id, i + 1, v_due_date, v_principal_portion, v_interest_portion, 
        v_monthly_payment, 0, 0, false, v_installment_status
      );
    END LOOP;
  END IF;
  RETURN NEW;
END;
$function$;