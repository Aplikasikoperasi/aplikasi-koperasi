-- Function to populate customers from existing active members (non-owner)
DO $$
DECLARE
  member_record RECORD;
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  FOR member_record IN 
    SELECT m.* 
    FROM members m
    LEFT JOIN customers c ON c.created_by = m.id OR (c.nik IS NOT NULL AND c.nik = m.nik)
    WHERE m.position != 'Owner' 
      AND (m.is_active IS NULL OR m.is_active = true)
      AND c.id IS NULL
  LOOP
    -- Get highest customer id_number
    SELECT COALESCE(
      MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
      0
    ) INTO max_num
    FROM public.customers
    WHERE id_number ~ '^N[0-9]+$';
    
    next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
    
    -- Insert customer record
    INSERT INTO public.customers (
      id_number,
      full_name,
      nik,
      date_of_birth,
      phone,
      address,
      occupation,
      photo_url,
      created_by
    ) VALUES (
      next_id_number,
      member_record.full_name,
      member_record.nik,
      member_record.date_of_birth,
      member_record.phone,
      member_record.address,
      member_record.occupation,
      member_record.photo_url,
      member_record.id
    );
    
    RAISE NOTICE 'Created customer for member: %', member_record.full_name;
  END LOOP;
END $$;