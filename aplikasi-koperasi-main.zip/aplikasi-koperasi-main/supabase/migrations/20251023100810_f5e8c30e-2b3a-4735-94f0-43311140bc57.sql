-- Perbaiki paid_amount yang menjadi negatif karena cleanup tadi
-- Kembalikan dengan menambahkan denda yang dikurangi

-- 1. ARLIDA SITUMORANG - Kembalikan 444.000
UPDATE installments 
SET paid_amount = paid_amount + 444000 
WHERE id = '69b02396-caf2-4df2-8b97-cd2af5691795';

-- 2. VIKTOR HASOLOAN TAMBUNAN - Kembalikan 568.000
UPDATE installments 
SET paid_amount = paid_amount + 568000 
WHERE id = '0dbbe34a-cfa7-494c-9c7b-5b668a6ccc9c';

-- 3. M. RESTY - Kembalikan 420.000
UPDATE installments 
SET paid_amount = paid_amount + 420000 
WHERE id = '50f6948d-e1e5-4c42-be5a-5dd8f4cebea4';

-- 4. TARA NADILAH - Kembalikan 354.000
UPDATE installments 
SET paid_amount = paid_amount + 354000 
WHERE id = '76fd7b45-67a0-4a20-971b-8fa6373a473e';

-- 5. DEPITASARI NOPIANTI - Kembalikan 272.000
UPDATE installments 
SET paid_amount = paid_amount + 272000 
WHERE id = '2142e41b-e4a8-4be2-90e4-c7cf1fe54876';