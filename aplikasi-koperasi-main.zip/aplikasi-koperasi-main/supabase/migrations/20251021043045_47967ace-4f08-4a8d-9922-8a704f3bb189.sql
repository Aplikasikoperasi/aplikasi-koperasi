-- Step 1: Identify and keep only the FIRST (oldest) application for each customer with duplicate pending/active applications
-- Delete duplicates, keeping the one with earliest created_at

WITH duplicates AS (
  SELECT 
    id,
    customer_id,
    created_at,
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY created_at ASC) as rn
  FROM public.credit_applications
  WHERE status IN ('pending', 'approved', 'disbursed')
)
DELETE FROM public.credit_applications
WHERE id IN (
  SELECT id FROM duplicates WHERE rn > 1
);

-- Step 2: Add unique constraint to prevent future duplicates
-- This prevents race conditions where multiple applications are submitted simultaneously
CREATE UNIQUE INDEX unique_active_application_per_customer 
ON public.credit_applications (customer_id)
WHERE status IN ('pending', 'approved', 'disbursed');