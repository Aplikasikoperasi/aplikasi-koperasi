-- Add missing system settings columns to app_settings
ALTER TABLE public.app_settings
  ADD COLUMN IF NOT EXISTS interest_type text DEFAULT 'flat',
  ADD COLUMN IF NOT EXISTS flat_interest_rate numeric DEFAULT 4.0,
  ADD COLUMN IF NOT EXISTS max_tenor_months integer DEFAULT 24,
  ADD COLUMN IF NOT EXISTS penalty_rate_per_day numeric DEFAULT 2.0,
  ADD COLUMN IF NOT EXISTS custom_rates jsonb DEFAULT '[]'::jsonb;

-- Backfill existing rows to ensure no NULLs
UPDATE public.app_settings
SET 
  interest_type = COALESCE(interest_type, 'flat'),
  flat_interest_rate = COALESCE(flat_interest_rate, 4.0),
  max_tenor_months = COALESCE(max_tenor_months, 24),
  penalty_rate_per_day = COALESCE(penalty_rate_per_day, 2.0),
  custom_rates = COALESCE(custom_rates, '[]'::jsonb);
