-- Attach trigger for auto-applying first installment payment on approval
DROP TRIGGER IF EXISTS trigger_apply_first_installment ON public.credit_applications;

CREATE TRIGGER trigger_apply_first_installment
  AFTER UPDATE ON public.credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.apply_first_installment_on_approval();

-- Add column to track admin fee in credit applications
ALTER TABLE public.credit_applications 
ADD COLUMN IF NOT EXISTS admin_fee_amount numeric DEFAULT 0;