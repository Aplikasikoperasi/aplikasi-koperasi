-- Require verification for all new customers by default
ALTER TABLE public.customers
  ALTER COLUMN status SET DEFAULT 'pending';