-- Create function to automatically block customers with low credit score
CREATE OR REPLACE FUNCTION public.auto_block_low_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_total_installments integer;
  v_late_installments integer;
  v_overdue_installments integer;
  v_on_time_percentage numeric;
  v_block_reason text;
BEGIN
  -- Only check if credit score dropped below 4
  IF NEW.credit_score < 4 AND (OLD.credit_score IS NULL OR OLD.credit_score >= 4) THEN
    
    -- Check if customer is not already blocked
    IF NOT EXISTS (
      SELECT 1 FROM public.blocked_customers WHERE customer_id = NEW.id
    ) THEN
      
      -- Get customer's payment performance data
      SELECT 
        COUNT(i.id),
        COUNT(CASE WHEN i.status = 'overdue' OR (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date) THEN 1 END),
        COUNT(CASE WHEN i.status = 'overdue' THEN 1 END)
      INTO 
        v_total_installments,
        v_late_installments,
        v_overdue_installments
      FROM installments i
      JOIN credit_applications ca ON ca.id = i.application_id
      WHERE ca.customer_id = NEW.id
      AND ca.status IN ('approved', 'disbursed');
      
      -- Calculate on-time percentage
      IF v_total_installments > 0 THEN
        v_on_time_percentage := ((v_total_installments - v_late_installments)::numeric / v_total_installments::numeric) * 100;
      ELSE
        v_on_time_percentage := 0;
      END IF;
      
      -- Build detailed block reason
      v_block_reason := format(
        'Diblokir otomatis oleh sistem karena skor kredit turun menjadi %s bintang (minimum 4 bintang). ' ||
        'Data kinerja: Total %s angsuran, %s pembayaran terlambat (%s%% ketepatan waktu), %s angsuran masih menunggak.',
        NEW.credit_score,
        v_total_installments,
        v_late_installments,
        ROUND(v_on_time_percentage, 1),
        v_overdue_installments
      );
      
      -- Insert into blocked_customers
      INSERT INTO public.blocked_customers (
        customer_id,
        blocked_reason,
        blocked_by,
        consecutive_missed_months
      ) VALUES (
        NEW.id,
        v_block_reason,
        NULL, -- NULL indicates system-initiated block
        0 -- Not due to consecutive missed months, but low credit score
      );
      
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to auto-block customers with low credit score
DROP TRIGGER IF EXISTS trigger_auto_block_low_credit_score ON public.customers;
CREATE TRIGGER trigger_auto_block_low_credit_score
  AFTER UPDATE OF credit_score ON public.customers
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_block_low_credit_score();