-- Recreate app_role enum and user_roles table properly
DO $$ 
BEGIN
  -- Create enum if not exists
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
    CREATE TYPE public.app_role AS ENUM ('owner', 'admin', 'sales', 'customer');
  END IF;
END $$;

-- Recreate user_roles table with correct structure
DROP TABLE IF EXISTS public.user_roles CASCADE;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT extensions.uuid_generate_v4(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL DEFAULT 'sales'::app_role,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Owners can manage all roles"
ON public.user_roles
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "Users can view all roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (true);

-- Create indexes
CREATE INDEX idx_user_roles_user_id ON public.user_roles(user_id);
CREATE INDEX idx_user_roles_role ON public.user_roles(role);

-- Recreate has_role function
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Recreate all dependent functions
CREATE OR REPLACE FUNCTION public.create_customer_on_sales_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  member_record RECORD;
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  IF NEW.role = 'sales'::app_role THEN
    SELECT * INTO member_record
    FROM public.members
    WHERE user_id = NEW.user_id
    LIMIT 1;
    
    IF FOUND AND (member_record.position IS NULL OR (LOWER(member_record.position) NOT LIKE '%owner%' AND member_record.position != 'Owner')) THEN
      IF NOT EXISTS (
        SELECT 1
        FROM public.customers
        WHERE created_by = member_record.id OR (nik IS NOT NULL AND nik = member_record.nik)
      ) THEN
        SELECT COALESCE(
          MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
          0
        ) INTO max_num
        FROM public.customers
        WHERE id_number ~ '^N[0-9]+$';
        
        next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
        
        INSERT INTO public.customers (
          id_number, full_name, nik, date_of_birth, phone, address, occupation, photo_url, created_by
        ) VALUES (
          next_id_number, member_record.full_name, member_record.nik, member_record.date_of_birth,
          member_record.phone, member_record.address, member_record.occupation, member_record.photo_url, member_record.id
        );
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.auto_sync_member_auth()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public, extensions'
AS $function$
DECLARE
  v_email TEXT;
  v_password TEXT;
  v_day TEXT;
  v_month TEXT;
  v_year TEXT;
  v_auth_user_id UUID;
  v_role TEXT := 'sales';
BEGIN
  IF NEW.position IS NOT NULL THEN
    IF LOWER(NEW.position) = 'owner' THEN v_role := 'owner';
    ELSIF LOWER(NEW.position) = 'admin' THEN v_role := 'admin';
    ELSE v_role := 'sales'; END IF;
  END IF;
  IF NEW.full_name IS NOT NULL THEN
    v_email := LOWER(REGEXP_REPLACE(NEW.full_name, '\s+', '', 'g')) || '@system.local';
  END IF;
  IF NEW.date_of_birth IS NOT NULL THEN
    v_day := LPAD(EXTRACT(DAY FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_month := LPAD(EXTRACT(MONTH FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_year := EXTRACT(YEAR FROM NEW.date_of_birth)::TEXT;
    v_password := v_day || v_month || v_year;
  END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.user_id IS NULL AND v_email IS NOT NULL AND NEW.date_of_birth IS NOT NULL THEN
      BEGIN
        INSERT INTO auth.users (
          instance_id,id,aud,role,email,encrypted_password,email_confirmed_at,raw_user_meta_data,created_at,updated_at,confirmation_token,recovery_token
        ) VALUES (
          '00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated','authenticated', v_email,
          extensions.crypt(v_password, extensions.gen_salt('bf')), NOW(), jsonb_build_object('full_name', NEW.full_name, 'is_member', true), NOW(), NOW(), '', ''
        ) RETURNING id INTO v_auth_user_id;
        NEW.user_id := v_auth_user_id;
        INSERT INTO public.profiles (id, full_name, email) VALUES (v_auth_user_id, NEW.full_name, v_email)
        ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name, email = EXCLUDED.email;
        INSERT INTO public.user_roles (user_id, role) VALUES (v_auth_user_id, v_role::app_role) ON CONFLICT (user_id, role) DO NOTHING;
      EXCEPTION WHEN OTHERS THEN
        SELECT id INTO v_auth_user_id FROM auth.users WHERE email = v_email LIMIT 1;
        IF v_auth_user_id IS NOT NULL THEN
          NEW.user_id := v_auth_user_id;
          UPDATE auth.users SET encrypted_password = extensions.crypt(v_password, extensions.gen_salt('bf')), updated_at = NOW() WHERE id = v_auth_user_id;
          INSERT INTO public.profiles (id, full_name, email) VALUES (v_auth_user_id, NEW.full_name, v_email)
          ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name, email = EXCLUDED.email;
          INSERT INTO public.user_roles (user_id, role) VALUES (v_auth_user_id, v_role::app_role) ON CONFLICT (user_id, role) DO NOTHING;
        END IF;
      END;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.user_id IS NOT NULL AND NEW.date_of_birth IS DISTINCT FROM OLD.date_of_birth AND NEW.date_of_birth IS NOT NULL THEN
      UPDATE auth.users SET encrypted_password = extensions.crypt(v_password, extensions.gen_salt('bf')), updated_at = NOW() WHERE id = NEW.user_id;
    END IF;
    IF NEW.user_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.user_id, v_role::app_role) ON CONFLICT (user_id, role) DO NOTHING;
    END IF;
    IF NEW.user_id IS NOT NULL AND v_email IS NOT NULL THEN
      INSERT INTO public.profiles (id, full_name, email) VALUES (NEW.user_id, NEW.full_name, v_email)
      ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name, email = EXCLUDED.email;
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

-- Recreate trigger for members
DROP TRIGGER IF EXISTS auto_sync_member_auth_trigger ON public.members;
CREATE TRIGGER auto_sync_member_auth_trigger
BEFORE INSERT OR UPDATE ON public.members
FOR EACH ROW
EXECUTE FUNCTION public.auto_sync_member_auth();

-- Recreate trigger for user_roles
DROP TRIGGER IF EXISTS create_customer_on_sales_role_trigger ON public.user_roles;
CREATE TRIGGER create_customer_on_sales_role_trigger
AFTER INSERT ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.create_customer_on_sales_role();