-- Add new columns to members table
ALTER TABLE public.members 
ADD COLUMN IF NOT EXISTS member_number TEXT UNIQUE,
ADD COLUMN IF NOT EXISTS date_of_birth DATE;

-- Drop the default temporarily
ALTER TABLE public.user_roles ALTER COLUMN role DROP DEFAULT;

-- Drop has_role function with CASCADE
DROP FUNCTION IF EXISTS public.has_role(uuid, app_role) CASCADE;

-- Update the app_role enum
ALTER TYPE public.app_role RENAME TO app_role_old;
CREATE TYPE public.app_role AS ENUM ('owner', 'admin', 'sales');

-- Update user_roles table to use new enum
ALTER TABLE public.user_roles 
ALTER COLUMN role TYPE public.app_role USING 
  CASE 
    WHEN role::text = 'admin' THEN 'owner'::public.app_role
    ELSE 'sales'::public.app_role
  END;

-- Set new default
ALTER TABLE public.user_roles ALTER COLUMN role SET DEFAULT 'sales'::public.app_role;

-- Drop old type
DROP TYPE public.app_role_old;

-- Recreate has_role function
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Recreate handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'),
    NEW.email
  );
  
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'sales');
  
  RETURN NEW;
END;
$$;

-- Drop all existing policies
DROP POLICY IF EXISTS "Users can view all roles" ON public.user_roles;
DROP POLICY IF EXISTS "Authenticated users can view members" ON public.members;
DROP POLICY IF EXISTS "Authenticated users can view customers" ON public.customers;
DROP POLICY IF EXISTS "Authenticated users can view applications" ON public.credit_applications;
DROP POLICY IF EXISTS "Authenticated users can view payments" ON public.payments;
DROP POLICY IF EXISTS "Authenticated users can view reports" ON public.financial_reports;
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;

-- Recreate all RLS policies

-- user_roles
CREATE POLICY "Owners can manage all roles" ON public.user_roles
FOR ALL USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Users can view all roles" ON public.user_roles
FOR SELECT USING (true);

-- members
CREATE POLICY "Owner and Admin can insert members" ON public.members
FOR INSERT WITH CHECK (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin')
);

CREATE POLICY "Owner and Admin can update members" ON public.members
FOR UPDATE USING (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin')
);

CREATE POLICY "Owners can delete members" ON public.members
FOR DELETE USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Authenticated users can view members" ON public.members
FOR SELECT USING (true);

-- customers
CREATE POLICY "All staff can insert customers" ON public.customers
FOR INSERT WITH CHECK (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'sales')
);

CREATE POLICY "All staff can update customers" ON public.customers
FOR UPDATE USING (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'sales')
);

CREATE POLICY "Owners can delete customers" ON public.customers
FOR DELETE USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Authenticated users can view customers" ON public.customers
FOR SELECT USING (true);

-- credit_applications
CREATE POLICY "All staff can insert applications" ON public.credit_applications
FOR INSERT WITH CHECK (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'sales')
);

CREATE POLICY "All staff can update applications" ON public.credit_applications
FOR UPDATE USING (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'sales')
);

CREATE POLICY "Owners can delete applications" ON public.credit_applications
FOR DELETE USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Authenticated users can view applications" ON public.credit_applications
FOR SELECT USING (true);

-- installments
CREATE POLICY "All staff can manage installments" ON public.installments
FOR ALL USING (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'sales')
);

-- payments
CREATE POLICY "All staff can insert payments" ON public.payments
FOR INSERT WITH CHECK (
  public.has_role(auth.uid(), 'owner') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'sales')
);

CREATE POLICY "Authenticated users can view payments" ON public.payments
FOR SELECT USING (true);

-- financial_reports (owner only)
CREATE POLICY "Owner can manage financial reports" ON public.financial_reports
FOR ALL USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Authenticated users can view reports" ON public.financial_reports
FOR SELECT USING (true);

-- app_settings (owner only)
CREATE POLICY "Only owner can view settings" ON public.app_settings
FOR SELECT USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Only owner can update settings" ON public.app_settings
FOR UPDATE USING (public.has_role(auth.uid(), 'owner'));

CREATE POLICY "Only owner can insert settings" ON public.app_settings
FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'owner'));

-- profiles
CREATE POLICY "Users can view all profiles" ON public.profiles
FOR SELECT USING (true);

CREATE POLICY "Owner can update profiles" ON public.profiles
FOR UPDATE USING (public.has_role(auth.uid(), 'owner'));