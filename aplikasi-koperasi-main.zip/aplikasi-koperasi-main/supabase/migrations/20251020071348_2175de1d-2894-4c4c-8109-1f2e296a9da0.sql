-- Enable required extensions for cron jobs
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA cron TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cron TO postgres;

-- Schedule the payment reminders function to run daily at 8:00 AM
-- This will send reminders for installments due in 3 days and warnings for overdue installments
SELECT cron.schedule(
  'send-payment-reminders-daily',
  '0 8 * * *', -- Every day at 8:00 AM
  $$
  SELECT
    net.http_post(
        url:='https://rufeqqwcnyzvmelzezgl.supabase.co/functions/v1/send-payment-reminders',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ1ZmVxcXdjbnl6dm1lbHplemdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyNTkwMjUsImV4cCI6MjA3NTgzNTAyNX0.n40rZ-a6aRnVPtsnKcxuKN5oHigrhclfFrC1V9KiZgs"}'::jsonb,
        body:=concat('{"time": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);

-- View scheduled jobs (comment out for production)
-- SELECT * FROM cron.job;

-- To manually test the function immediately:
-- SELECT net.http_post(
--   url:='https://rufeqqwcnyzvmelzezgl.supabase.co/functions/v1/send-payment-reminders',
--   headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ1ZmVxcXdjbnl6dm1lbHplemdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyNTkwMjUsImV4cCI6MjA3NTgzNTAyNX0.n40rZ-a6aRnVPtsnKcxuKN5oHigrhclfFrC1V9KiZgs"}'::jsonb,
--   body:='{"time": "now"}'::jsonb
-- );