-- Update get_public_app_settings to include super_code
CREATE OR REPLACE FUNCTION public.get_public_app_settings()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT to_jsonb(s)
  FROM (
    SELECT 
      first_installment_type,
      admin_fee_enabled,
      admin_fee_amount,
      max_tenor_months,
      interest_type,
      flat_interest_rate,
      penalty_rate_per_day,
      custom_rates,
      super_code
    FROM app_settings
    LIMIT 1
  ) s
$$;