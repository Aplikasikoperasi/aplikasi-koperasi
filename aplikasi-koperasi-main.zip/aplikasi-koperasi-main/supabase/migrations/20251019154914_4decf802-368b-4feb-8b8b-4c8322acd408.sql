-- Create function to validate customer status before credit application
CREATE OR REPLACE FUNCTION public.validate_customer_for_credit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_customer_status TEXT;
  v_customer_name TEXT;
BEGIN
  -- Get customer status
  SELECT status, full_name INTO v_customer_status, v_customer_name
  FROM public.customers
  WHERE id = NEW.customer_id;
  
  -- Check if customer is approved
  IF v_customer_status IS NULL THEN
    RAISE EXCEPTION 'Nasabah tidak ditemukan dalam sistem';
  END IF;
  
  IF v_customer_status != 'approved' THEN
    RAISE EXCEPTION 'Hanya nasabah yang sudah diverifikasi (status: approved) yang dapat mengajukan kredit. Nasabah "%" masih berstatus "%".', v_customer_name, v_customer_status;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to validate customer status on credit application insert
DROP TRIGGER IF EXISTS trigger_validate_customer_status ON public.credit_applications;
CREATE TRIGGER trigger_validate_customer_status
  BEFORE INSERT ON public.credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_customer_for_credit();

-- Also validate on update (if customer_id is changed)
DROP TRIGGER IF EXISTS trigger_validate_customer_status_update ON public.credit_applications;
CREATE TRIGGER trigger_validate_customer_status_update
  BEFORE UPDATE OF customer_id ON public.credit_applications
  FOR EACH ROW
  WHEN (OLD.customer_id IS DISTINCT FROM NEW.customer_id)
  EXECUTE FUNCTION public.validate_customer_for_credit();