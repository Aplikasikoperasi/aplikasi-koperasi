-- Ensure re-block trigger handles both INSERT and UPDATE (for upserts)
CREATE OR REPLACE FUNCTION public.handle_reblock_restored_customer()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_restoration_status TEXT;
BEGIN
  -- Get customer's restoration status
  SELECT restoration_status INTO v_restoration_status
  FROM customers
  WHERE id = NEW.customer_id;
  
  -- If customer was restored once, make it permanent block
  IF v_restoration_status = 'restored_once' THEN
    UPDATE customers
    SET 
      restoration_status = 'permanently_blocked',
      credit_score = 0
    WHERE id = NEW.customer_id;
    
    -- Prefix block reason
    IF NEW.blocked_reason IS NULL OR NEW.blocked_reason = '' THEN
      NEW.blocked_reason := 'BLOKIR PERMANEN - Diblokir kembali setelah pemulihan sebelumnya.';
    ELSE
      NEW.blocked_reason := 'BLOKIR PERMANEN - Nasabah diblokir kembali setelah pemulihan sebelumnya. ' || NEW.blocked_reason;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate trigger to fire on INSERT or UPDATE
DROP TRIGGER IF EXISTS trigger_reblock_restored_customer ON public.blocked_customers;
CREATE TRIGGER trigger_reblock_restored_customer
BEFORE INSERT OR UPDATE ON public.blocked_customers
FOR EACH ROW
EXECUTE FUNCTION public.handle_reblock_restored_customer();