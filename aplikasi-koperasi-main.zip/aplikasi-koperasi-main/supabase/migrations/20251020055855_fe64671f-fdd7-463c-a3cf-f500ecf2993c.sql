-- Add customer role to app_role enum (will skip if already exists)
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'customer';

-- Add user_id column to customers table
ALTER TABLE public.customers 
ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

-- Create index for user_id
CREATE INDEX IF NOT EXISTS idx_customers_user_id ON public.customers(user_id);

-- Create customer_messages table for inbox
CREATE TABLE IF NOT EXISTS public.customer_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  metadata JSONB DEFAULT '{}'::jsonb
);

-- Enable RLS on customer_messages
ALTER TABLE public.customer_messages ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Customers can view their own messages" ON public.customer_messages;
DROP POLICY IF EXISTS "Customers can update their own messages" ON public.customer_messages;
DROP POLICY IF EXISTS "Staff can insert customer messages" ON public.customer_messages;

-- Customer can only view their own messages
CREATE POLICY "Customers can view their own messages"
ON public.customer_messages
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.customers c
    WHERE c.id = customer_messages.customer_id
    AND c.user_id = auth.uid()
  )
);

-- Customer can mark their own messages as read
CREATE POLICY "Customers can update their own messages"
ON public.customer_messages
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.customers c
    WHERE c.id = customer_messages.customer_id
    AND c.user_id = auth.uid()
  )
);

-- Staff can insert messages for customers
CREATE POLICY "Staff can insert customer messages"
ON public.customer_messages
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'owner') OR 
  has_role(auth.uid(), 'admin') OR 
  has_role(auth.uid(), 'sales')
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_customer_messages_customer_id ON public.customer_messages(customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_messages_created_at ON public.customer_messages(created_at DESC);