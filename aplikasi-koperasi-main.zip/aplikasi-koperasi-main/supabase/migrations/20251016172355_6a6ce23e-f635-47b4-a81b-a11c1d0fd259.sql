-- Add is_active column to members table
ALTER TABLE public.members
ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT true;

-- Update existing trigger to only create customer for active non-owner members
CREATE OR REPLACE FUNCTION public.create_customer_for_sales_member()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  -- Only create customer if member is active and NOT an owner
  IF NEW.is_active = true AND NEW.position != 'Owner' THEN
    -- Check if customer doesn't already exist for this member
    IF NOT EXISTS (
      SELECT 1
      FROM public.customers
      WHERE created_by = NEW.id OR (nik IS NOT NULL AND nik = NEW.nik)
    ) THEN
      -- Get highest customer id_number
      SELECT COALESCE(
        MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
        0
      ) INTO max_num
      FROM public.customers
      WHERE id_number ~ '^N[0-9]+$';
      
      next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
      
      -- Insert customer record with member's data
      INSERT INTO public.customers (
        id_number,
        full_name,
        nik,
        date_of_birth,
        phone,
        address,
        occupation,
        photo_url,
        created_by
      ) VALUES (
        next_id_number,
        NEW.full_name,
        NEW.nik,
        NEW.date_of_birth,
        NEW.phone,
        NEW.address,
        NEW.occupation,
        NEW.photo_url,
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create function to handle member deactivation
CREATE OR REPLACE FUNCTION public.handle_member_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- If member is deactivated, remove them from customers table (except owner)
  IF NEW.is_active = false AND OLD.is_active = true AND NEW.position != 'Owner' THEN
    DELETE FROM public.customers
    WHERE created_by = NEW.id;
  END IF;
  
  -- If member is reactivated, recreate customer record (except owner)
  IF NEW.is_active = true AND OLD.is_active = false AND NEW.position != 'Owner' THEN
    DECLARE
      next_id_number TEXT;
      max_num INTEGER;
    BEGIN
      -- Check if customer doesn't already exist
      IF NOT EXISTS (
        SELECT 1
        FROM public.customers
        WHERE created_by = NEW.id OR (nik IS NOT NULL AND nik = NEW.nik)
      ) THEN
        -- Get highest customer id_number
        SELECT COALESCE(
          MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
          0
        ) INTO max_num
        FROM public.customers
        WHERE id_number ~ '^N[0-9]+$';
        
        next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
        
        -- Insert customer record
        INSERT INTO public.customers (
          id_number,
          full_name,
          nik,
          date_of_birth,
          phone,
          address,
          occupation,
          photo_url,
          created_by
        ) VALUES (
          next_id_number,
          NEW.full_name,
          NEW.nik,
          NEW.date_of_birth,
          NEW.phone,
          NEW.address,
          NEW.occupation,
          NEW.photo_url,
          NEW.id
        );
      END IF;
    END;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger for member status changes
DROP TRIGGER IF EXISTS on_member_status_change ON public.members;
CREATE TRIGGER on_member_status_change
  AFTER UPDATE OF is_active ON public.members
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_member_status_change();