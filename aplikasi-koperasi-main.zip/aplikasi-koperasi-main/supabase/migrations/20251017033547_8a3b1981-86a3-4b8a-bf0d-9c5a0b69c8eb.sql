-- Create secure RPC to block customer with conflict handling and role check
CREATE OR REPLACE FUNCTION public.block_customer(p_customer_id uuid, p_reason text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_restoration_status text;
  v_user_id uuid := auth.uid();
BEGIN
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
  END IF;

  -- Role check aligns with RLS for inserts
  IF NOT (
    public.has_role(v_user_id, 'owner') OR 
    public.has_role(v_user_id, 'admin') OR 
    public.has_role(v_user_id, 'sales')
  ) THEN
    RETURN jsonb_build_object('success', false, 'message', 'Akses ditolak');
  END IF;

  SELECT restoration_status INTO v_restoration_status
  FROM customers
  WHERE id = p_customer_id;

  IF v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Nasabah berstatus blokir permanen');
  END IF;

  -- Upsert to avoid duplicate key and trigger permanent block on second time
  INSERT INTO public.blocked_customers (
    customer_id,
    blocked_reason,
    blocked_by,
    consecutive_missed_months
  ) VALUES (
    p_customer_id,
    COALESCE(p_reason, 'Diblokir oleh staf'),
    v_user_id,
    0
  )
  ON CONFLICT (customer_id) DO UPDATE
  SET 
    blocked_reason = EXCLUDED.blocked_reason,
    blocked_by = EXCLUDED.blocked_by,
    blocked_at = now(),
    consecutive_missed_months = EXCLUDED.consecutive_missed_months;

  RETURN jsonb_build_object('success', true, 'message', 'Nasabah berhasil diblokir');
END;
$$;