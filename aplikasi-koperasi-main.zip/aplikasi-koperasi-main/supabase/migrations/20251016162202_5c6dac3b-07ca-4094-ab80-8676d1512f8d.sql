-- Add first installment and admin fee settings to app_settings table
ALTER TABLE app_settings 
ADD COLUMN IF NOT EXISTS first_installment_type text DEFAULT 'next_month' CHECK (first_installment_type IN ('paid_upfront', 'next_month')),
ADD COLUMN IF NOT EXISTS admin_fee_enabled boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS admin_fee_amount numeric DEFAULT 0;