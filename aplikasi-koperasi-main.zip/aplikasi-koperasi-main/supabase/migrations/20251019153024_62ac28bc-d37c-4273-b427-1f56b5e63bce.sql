-- Drop the existing trigger and function with CASCADE
DROP TRIGGER IF EXISTS trigger_auto_block_low_credit_score ON customers;
DROP FUNCTION IF EXISTS auto_block_low_credit_score() CASCADE;

-- Create improved auto-block function that blocks ANY customer with score < 3.5
CREATE OR REPLACE FUNCTION public.auto_block_low_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_total_installments integer;
  v_late_installments integer;
  v_overdue_installments integer;
  v_on_time_percentage numeric;
  v_block_reason text;
BEGIN
  -- Only check if credit score dropped below 3.5
  IF NEW.credit_score < 3.5 AND (OLD.credit_score IS NULL OR OLD.credit_score >= 3.5) THEN
    -- Skip if already blocked
    IF NOT EXISTS (SELECT 1 FROM public.blocked_customers WHERE customer_id = NEW.id) THEN
      -- Get installment statistics
      SELECT 
        COUNT(i.id),
        COUNT(CASE 
          WHEN i.status = 'overdue' OR 
               (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date AND COALESCE(i.frozen_penalty,0) > 0)
          THEN 1 END),
        COUNT(CASE WHEN i.status = 'overdue' THEN 1 END)
      INTO v_total_installments, v_late_installments, v_overdue_installments
      FROM installments i
      JOIN credit_applications ca ON ca.id = i.application_id
      WHERE ca.customer_id = NEW.id
        AND ca.status IN ('approved','disbursed');

      -- Calculate on-time percentage
      IF v_total_installments > 0 THEN
        v_on_time_percentage := ((v_total_installments - v_late_installments)::numeric / v_total_installments::numeric) * 100;
        
        v_block_reason := format(
          'Diblokir otomatis: skor %s bintang. Total %s angsuran, %s telat (%s%% tepat waktu), %s menunggak.',
          NEW.credit_score,
          v_total_installments,
          v_late_installments,
          ROUND(v_on_time_percentage,1),
          v_overdue_installments
        );
      ELSE
        -- No installment history, but still block due to low score
        v_block_reason := format(
          'Diblokir otomatis: skor kredit %s bintang (di bawah minimum 3.5 bintang).',
          NEW.credit_score
        );
      END IF;

      -- Insert into blocked_customers
      INSERT INTO public.blocked_customers (customer_id, blocked_reason, blocked_by, consecutive_missed_months)
      VALUES (NEW.id, v_block_reason, NULL, 0)
      ON CONFLICT (customer_id) DO UPDATE
        SET blocked_reason = EXCLUDED.blocked_reason,
            blocked_at = now(),
            consecutive_missed_months = EXCLUDED.consecutive_missed_months;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

-- Recreate the trigger
CREATE TRIGGER trigger_auto_block_low_credit_score
AFTER UPDATE OF credit_score ON customers
FOR EACH ROW
EXECUTE FUNCTION auto_block_low_credit_score();

-- Block existing customers with credit_score < 3.5 who are not already blocked
INSERT INTO public.blocked_customers (customer_id, blocked_reason, blocked_by, consecutive_missed_months)
SELECT 
  c.id,
  format('Diblokir otomatis: skor kredit %s bintang (di bawah minimum 3.5 bintang).', c.credit_score),
  NULL,
  0
FROM customers c
WHERE c.credit_score < 3.5
  AND c.restoration_status != 'permanently_blocked'
  AND NOT EXISTS (SELECT 1 FROM blocked_customers bc WHERE bc.customer_id = c.id)
ON CONFLICT (customer_id) DO NOTHING;