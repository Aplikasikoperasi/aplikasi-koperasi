-- Add blocked_by column to track who blocked the customer
ALTER TABLE public.blocked_customers 
ADD COLUMN blocked_by uuid REFERENCES auth.users(id);