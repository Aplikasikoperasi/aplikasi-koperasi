
-- PERBAIKAN MASSAL: Koreksi semua data pembayaran yang tidak akurat
-- Bug: paid_amount tidak sesuai dengan total pembayaran aktual

-- Step 1: Update paid_amount sesuai dengan pembayaran aktual dari tabel payments
UPDATE installments i
SET 
  paid_amount = COALESCE((
    SELECT SUM(p.amount)
    FROM payments p
    WHERE p.installment_id = i.id
  ), 0),
  -- Update status berdasarkan pembayaran aktual
  status = CASE
    WHEN COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.installment_id = i.id), 0) >= i.total_amount 
         AND COALESCE(i.frozen_penalty, 0) = 0 
    THEN 'paid'
    WHEN COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.installment_id = i.id), 0) > 0 
         AND COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.installment_id = i.id), 0) < i.total_amount 
    THEN 'partial'
    WHEN i.due_date < CURRENT_DATE AND COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.installment_id = i.id), 0) = 0
    THEN 'overdue'
    ELSE 'unpaid'
  END,
  -- Update principal_paid berdasarkan pembayaran aktual
  principal_paid = CASE
    WHEN COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.installment_id = i.id), 0) >= i.total_amount 
    THEN true
    ELSE false
  END,
  -- Reset paid_at jika ternyata belum lunas
  paid_at = CASE
    WHEN COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.installment_id = i.id), 0) >= i.total_amount 
         AND COALESCE(i.frozen_penalty, 0) = 0 
    THEN i.paid_at
    ELSE NULL
  END
WHERE 
  -- Hanya update yang paid_amount tidak match dengan pembayaran aktual
  i.paid_amount != COALESCE((
    SELECT SUM(p.amount)
    FROM payments p
    WHERE p.installment_id = i.id
  ), 0);

-- Log hasil koreksi untuk audit
DO $$
DECLARE
  v_corrected_count integer;
BEGIN
  SELECT COUNT(*) INTO v_corrected_count
  FROM installments i
  WHERE i.paid_amount != COALESCE((
    SELECT SUM(p.amount)
    FROM payments p
    WHERE p.installment_id = i.id
  ), 0);
  
  RAISE NOTICE 'Jumlah angsuran yang dikoreksi: %', v_corrected_count;
END $$;

-- Buat view untuk monitoring data pembayaran ke depan
CREATE OR REPLACE VIEW installment_payment_verification AS
SELECT 
  i.id as installment_id,
  ca.application_number,
  c.id_number as customer_id,
  c.full_name,
  i.installment_number,
  i.total_amount,
  i.paid_amount as recorded_paid_amount,
  COALESCE(SUM(p.amount), 0) as actual_payments_total,
  i.paid_amount - COALESCE(SUM(p.amount), 0) as discrepancy,
  i.status,
  i.principal_paid,
  CASE 
    WHEN i.paid_amount != COALESCE(SUM(p.amount), 0) THEN 'MISMATCH'
    WHEN i.status = 'paid' AND i.paid_amount < i.total_amount THEN 'INVALID_STATUS'
    WHEN i.status = 'paid' AND COALESCE(i.frozen_penalty, 0) > 0 THEN 'HAS_PENALTY'
    ELSE 'OK'
  END as verification_status
FROM installments i
JOIN credit_applications ca ON ca.id = i.application_id
JOIN customers c ON c.id = ca.customer_id
LEFT JOIN payments p ON p.installment_id = i.id
GROUP BY i.id, ca.application_number, c.id_number, c.full_name, i.installment_number, 
         i.total_amount, i.paid_amount, i.status, i.principal_paid, i.frozen_penalty
ORDER BY ABS(i.paid_amount - COALESCE(SUM(p.amount), 0)) DESC;

COMMENT ON VIEW installment_payment_verification IS 
'View untuk monitoring dan verifikasi konsistensi data pembayaran. Status verification_status menunjukkan masalah jika ada.';