-- Delete duplicate rows, keeping only the first one based on created_at
DELETE FROM public.user_roles
WHERE id IN (
  SELECT id
  FROM (
    SELECT id,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY created_at ASC) as rn
    FROM public.user_roles
  ) t
  WHERE t.rn > 1
);

-- Add unique constraint to prevent duplicates in the future
ALTER TABLE public.user_roles
DROP CONSTRAINT IF EXISTS user_roles_user_id_key;

ALTER TABLE public.user_roles
ADD CONSTRAINT user_roles_user_id_unique UNIQUE (user_id);