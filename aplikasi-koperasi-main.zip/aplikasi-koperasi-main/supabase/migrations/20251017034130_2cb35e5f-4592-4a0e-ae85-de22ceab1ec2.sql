-- Fix the block_customer function to avoid any ID conflicts
CREATE OR REPLACE FUNCTION public.block_customer(p_customer_id uuid, p_reason text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_restoration_status text;
  v_user_id uuid := auth.uid();
  v_final_reason text;
  v_blocked_record_id uuid;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
  END IF;

  -- Role check
  IF NOT (
    public.has_role(v_user_id, 'owner') OR 
    public.has_role(v_user_id, 'admin') OR 
    public.has_role(v_user_id, 'sales')
  ) THEN
    RETURN jsonb_build_object('success', false, 'message', 'Akses ditolak');
  END IF;

  -- Get customer info
  SELECT restoration_status INTO v_restoration_status
  FROM customers
  WHERE id = p_customer_id;

  IF v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Nasabah berstatus blokir permanen');
  END IF;

  -- Check if customer is already blocked and get the blocked record ID
  SELECT id INTO v_blocked_record_id
  FROM blocked_customers 
  WHERE customer_id = p_customer_id;

  -- Set reason based on restoration status
  v_final_reason := COALESCE(p_reason, 'Diblokir oleh staf');
  
  -- If customer was restored once and being blocked again, make it permanent
  IF v_restoration_status = 'restored_once' THEN
    v_final_reason := 'BLOKIR PERMANEN - Nasabah diblokir kembali setelah pemulihan sebelumnya. ' || v_final_reason;
    
    -- Update customer to permanently blocked
    UPDATE customers
    SET 
      restoration_status = 'permanently_blocked',
      credit_score = 0
    WHERE id = p_customer_id;
  END IF;

  -- Insert or update blocked customer record
  IF v_blocked_record_id IS NOT NULL THEN
    -- Update existing record
    UPDATE blocked_customers
    SET 
      blocked_reason = v_final_reason,
      blocked_by = v_user_id,
      blocked_at = now(),
      consecutive_missed_months = 0
    WHERE id = v_blocked_record_id;
  ELSE
    -- Insert new record
    INSERT INTO public.blocked_customers (
      customer_id,
      blocked_reason,
      blocked_by,
      consecutive_missed_months
    ) VALUES (
      p_customer_id,
      v_final_reason,
      v_user_id,
      0
    );
  END IF;

  RETURN jsonb_build_object('success', true, 'message', 'Nasabah berhasil diblokir');
END;
$$;