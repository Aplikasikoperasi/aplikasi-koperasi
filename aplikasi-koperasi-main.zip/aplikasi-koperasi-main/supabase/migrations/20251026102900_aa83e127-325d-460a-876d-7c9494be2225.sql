-- Drop existing triggers
DROP TRIGGER IF EXISTS trigger_auto_approve_customer ON customers;
DROP TRIGGER IF EXISTS trigger_auto_approve_application ON credit_applications;

-- Recreate function to auto-approve customers using current user
CREATE OR REPLACE FUNCTION public.auto_approve_customer_by_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_current_user_id uuid;
  v_is_owner_or_admin boolean;
BEGIN
  -- Get current authenticated user
  v_current_user_id := auth.uid();
  
  -- Check if current user is owner or admin
  IF v_current_user_id IS NOT NULL THEN
    v_is_owner_or_admin := (
      has_role_text(v_current_user_id, 'owner'::text) OR 
      has_role_text(v_current_user_id, 'admin'::text)
    );
    
    -- Auto-approve if created by owner/admin
    IF v_is_owner_or_admin THEN
      NEW.status := 'approved';
      NEW.approved_by := v_current_user_id;
      NEW.approved_at := NOW();
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate function to auto-approve applications using current user
CREATE OR REPLACE FUNCTION public.auto_approve_application_by_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_current_user_id uuid;
  v_is_owner_or_admin boolean;
BEGIN
  -- Get current authenticated user
  v_current_user_id := auth.uid();
  
  -- Check if current user is owner or admin
  IF v_current_user_id IS NOT NULL THEN
    v_is_owner_or_admin := (
      has_role_text(v_current_user_id, 'owner'::text) OR 
      has_role_text(v_current_user_id, 'admin'::text)
    );
    
    -- Auto-approve if created by owner/admin
    IF v_is_owner_or_admin THEN
      NEW.status := 'approved';
      NEW.approved_by := v_current_user_id;
      NEW.approved_at := NOW();
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate triggers
CREATE TRIGGER trigger_auto_approve_customer
  BEFORE INSERT ON customers
  FOR EACH ROW
  EXECUTE FUNCTION auto_approve_customer_by_role();

CREATE TRIGGER trigger_auto_approve_application
  BEFORE INSERT ON credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION auto_approve_application_by_role();