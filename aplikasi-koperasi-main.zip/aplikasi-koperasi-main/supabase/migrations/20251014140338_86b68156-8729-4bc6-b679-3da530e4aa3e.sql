-- Function to generate installments when credit application is approved
CREATE OR REPLACE FUNCTION generate_installments()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_remaining_principal NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  i INTEGER;
BEGIN
  -- Only generate if status changed to approved or disbursed and installments don't exist
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    
    -- Check if installments already exist
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;
    
    -- Calculate monthly interest rate (annual rate / 12)
    v_monthly_interest_rate := NEW.interest_rate / 100 / 12;
    
    -- Calculate monthly payment using annuity formula
    -- PMT = P * [r(1+r)^n] / [(1+r)^n - 1]
    v_monthly_payment := NEW.amount_approved * 
                        (v_monthly_interest_rate * POWER(1 + v_monthly_interest_rate, NEW.tenor_months)) /
                        (POWER(1 + v_monthly_interest_rate, NEW.tenor_months) - 1);
    
    v_remaining_principal := NEW.amount_approved;
    
    -- Generate installments
    FOR i IN 1..NEW.tenor_months LOOP
      -- Calculate due date (first installment is 1 month from approval)
      v_due_date := (COALESCE(NEW.disbursed_at, NEW.approved_at)::DATE + (i || ' months')::INTERVAL)::DATE;
      
      -- Calculate interest portion (remaining principal * monthly rate)
      v_interest_portion := v_remaining_principal * v_monthly_interest_rate;
      
      -- Calculate principal portion
      v_principal_portion := v_monthly_payment - v_interest_portion;
      
      -- For last installment, adjust to ensure principal is fully paid
      IF i = NEW.tenor_months THEN
        v_principal_portion := v_remaining_principal;
        v_monthly_payment := v_principal_portion + v_interest_portion;
      END IF;
      
      -- Insert installment
      INSERT INTO installments (
        application_id,
        installment_number,
        due_date,
        principal_amount,
        interest_amount,
        total_amount,
        paid_amount,
        status
      ) VALUES (
        NEW.id,
        i,
        v_due_date,
        v_principal_portion,
        v_interest_portion,
        v_monthly_payment,
        0,
        'unpaid'
      );
      
      -- Update remaining principal
      v_remaining_principal := v_remaining_principal - v_principal_portion;
    END LOOP;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for auto-generating installments
DROP TRIGGER IF EXISTS trigger_generate_installments ON credit_applications;
CREATE TRIGGER trigger_generate_installments
  AFTER INSERT OR UPDATE ON credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION generate_installments();

-- Function to calculate penalty (2% per day for overdue installments)
CREATE OR REPLACE FUNCTION calculate_installment_penalty(
  p_installment_id UUID
)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_due_date DATE;
  v_total_amount NUMERIC;
  v_paid_amount NUMERIC;
  v_days_overdue INTEGER;
  v_penalty NUMERIC;
BEGIN
  -- Get installment details
  SELECT due_date, total_amount, paid_amount
  INTO v_due_date, v_total_amount, v_paid_amount
  FROM installments
  WHERE id = p_installment_id;
  
  -- Calculate days overdue
  v_days_overdue := GREATEST(0, CURRENT_DATE - v_due_date);
  
  -- Calculate penalty: 2% per day on unpaid amount
  IF v_days_overdue > 0 AND (v_total_amount - v_paid_amount) > 0 THEN
    v_penalty := (v_total_amount - v_paid_amount) * 0.02 * v_days_overdue;
  ELSE
    v_penalty := 0;
  END IF;
  
  RETURN v_penalty;
END;
$$;