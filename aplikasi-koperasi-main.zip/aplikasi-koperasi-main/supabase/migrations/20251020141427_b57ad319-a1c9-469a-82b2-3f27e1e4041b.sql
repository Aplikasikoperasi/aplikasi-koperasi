-- Ensure updated_at is automatically maintained on profiles updates
DO $$ BEGIN
  -- Safe drop if exists to avoid duplicate trigger errors
  IF EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_profiles_updated_at'
  ) THEN
    DROP TRIGGER update_profiles_updated_at ON public.profiles;
  END IF;
END $$;

CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Improve realtime payloads for profiles table
ALTER TABLE public.profiles REPLICA IDENTITY FULL;