-- Fix security warning: set search_path on auto_unblock function
CREATE OR REPLACE FUNCTION public.auto_unblock_on_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.credit_score >= 4 THEN
    IF EXISTS (SELECT 1 FROM customers c WHERE c.id = NEW.id AND c.restoration_status = 'permanently_blocked') THEN
      RETURN NEW;
    END IF;
    DELETE FROM blocked_customers WHERE customer_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$function$;