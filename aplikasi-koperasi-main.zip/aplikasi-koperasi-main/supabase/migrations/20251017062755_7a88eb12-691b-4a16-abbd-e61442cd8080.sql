-- Add frozen_days_overdue column to installments table
ALTER TABLE public.installments 
ADD COLUMN IF NOT EXISTS frozen_days_overdue INTEGER DEFAULT 0;

COMMENT ON COLUMN public.installments.frozen_days_overdue IS 'Number of overdue days frozen when payment is made';
