-- Perbaiki logika blokir permanen: hitung berdasarkan history, bukan restoration_status

-- 1. Drop function lama
DROP FUNCTION IF EXISTS public.block_customer(uuid, text);

-- 2. Buat function baru dengan logika yang diperbaiki
CREATE OR REPLACE FUNCTION public.block_customer(p_customer_id uuid, p_reason text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_restoration_status text;
  v_user_id uuid := auth.uid();
  v_final_reason text;
  v_block_count integer;
  v_customer_nik text;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
  END IF;

  -- Role check
  IF NOT (
    public.has_role(v_user_id, 'owner') OR 
    public.has_role(v_user_id, 'admin') OR 
    public.has_role(v_user_id, 'sales')
  ) THEN
    RETURN jsonb_build_object('success', false, 'message', 'Akses ditolak');
  END IF;

  -- Get customer info dan NIK
  SELECT restoration_status, nik INTO v_restoration_status, v_customer_nik
  FROM customers
  WHERE id = p_customer_id;

  IF v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Nasabah berstatus blokir permanen');
  END IF;

  -- Hitung berapa kali customer ini pernah masuk blocked_customers (termasuk yang sudah dipulihkan)
  -- Cari berdasarkan customer_id atau NIK (untuk handle kasus customer dihapus dan dibuat ulang)
  SELECT COUNT(DISTINCT bc.id) INTO v_block_count
  FROM blocked_customers bc
  LEFT JOIN customers c ON bc.customer_id = c.id
  WHERE bc.customer_id = p_customer_id 
     OR (v_customer_nik IS NOT NULL AND c.nik = v_customer_nik);

  -- Set reason based on block count
  v_final_reason := COALESCE(p_reason, 'Diblokir oleh staf');
  
  -- Jika ini adalah blokir ke-3 atau lebih, jadikan permanen
  IF v_block_count >= 2 THEN
    v_final_reason := 'BLOKIR PERMANEN - Nasabah telah diblokir sebanyak ' || (v_block_count + 1)::text || ' kali. ' || v_final_reason;
    
    -- Update customer to permanently blocked
    UPDATE customers
    SET 
      restoration_status = 'permanently_blocked',
      credit_score = 0
    WHERE id = p_customer_id;
  END IF;

  -- Upsert to avoid duplicate key errors
  INSERT INTO public.blocked_customers (
    customer_id,
    blocked_reason,
    blocked_by,
    consecutive_missed_months
  ) VALUES (
    p_customer_id,
    v_final_reason,
    v_user_id,
    0
  )
  ON CONFLICT (customer_id) DO UPDATE
  SET 
    blocked_reason = EXCLUDED.blocked_reason,
    blocked_by = EXCLUDED.blocked_by,
    blocked_at = now(),
    consecutive_missed_months = 0;

  RETURN jsonb_build_object('success', true, 'message', 'Nasabah berhasil diblokir');
END;
$$;

-- 3. Drop function lama can_apply_for_credit
DROP FUNCTION IF EXISTS public.can_apply_for_credit(text);

-- 4. Update function can_apply_for_credit untuk cek NIK yang permanently blocked
CREATE OR REPLACE FUNCTION public.can_apply_for_credit(check_nik text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_customer_id uuid;
  v_has_active_credit boolean;
  v_has_unpaid_installments boolean;
  v_credit_score integer;
  v_restoration_status text;
  v_is_currently_blocked boolean;
BEGIN
  -- Cek apakah NIK ini pernah diblokir permanen (cek di customers yang masih ada)
  SELECT id, credit_score, restoration_status INTO v_customer_id, v_credit_score, v_restoration_status
  FROM public.customers
  WHERE nik = check_nik
  LIMIT 1;
  
  -- Jika customer ditemukan dan statusnya permanently_blocked
  IF v_customer_id IS NOT NULL AND v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'permanently_blocked',
      'message', 'NIK ini telah diblokir permanen dan tidak dapat mengajukan kredit',
      'credit_score', 0
    );
  END IF;
  
  -- Cek apakah NIK ini sedang dalam daftar blokir
  SELECT EXISTS (
    SELECT 1
    FROM public.blocked_customers bc
    JOIN public.customers c ON bc.customer_id = c.id
    WHERE c.nik = check_nik
  ) INTO v_is_currently_blocked;
  
  IF v_is_currently_blocked THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'currently_blocked',
      'message', 'Nasabah sedang dalam status diblokir',
      'credit_score', COALESCE(v_credit_score, 0)
    );
  END IF;
  
  -- If customer not found, they can apply (new customer will get default 5 stars)
  IF v_customer_id IS NULL THEN
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'new_customer',
      'credit_score', 5
    );
  END IF;
  
  -- Check if customer has active credit (approved or disbursed)
  SELECT EXISTS (
    SELECT 1
    FROM public.credit_applications ca
    WHERE ca.customer_id = v_customer_id
    AND ca.status IN ('approved', 'disbursed')
    AND EXISTS (
      SELECT 1
      FROM public.installments i
      WHERE i.application_id = ca.id
      AND i.status != 'paid'
    )
  ) INTO v_has_active_credit;
  
  -- Check if customer has any unpaid installments or penalties
  SELECT EXISTS (
    SELECT 1
    FROM public.installments i
    JOIN public.credit_applications ca ON ca.id = i.application_id
    WHERE ca.customer_id = v_customer_id
    AND (i.status = 'overdue' OR (i.total_amount - i.paid_amount) > 0)
  ) INTO v_has_unpaid_installments;
  
  -- Customer can apply if:
  -- 1. No active credit
  -- 2. No unpaid installments
  -- 3. Credit score >= 3
  IF v_has_active_credit THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'active_credit_exists',
      'message', 'Nasabah masih memiliki kredit aktif yang belum lunas',
      'credit_score', v_credit_score
    );
  ELSIF v_has_unpaid_installments THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'unpaid_installments',
      'message', 'Nasabah memiliki angsuran atau denda yang belum dilunasi',
      'credit_score', v_credit_score
    );
  ELSIF v_credit_score < 3 THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'low_credit_score',
      'message', 'Skor kredit nasabah terlalu rendah (minimum 3 bintang)',
      'credit_score', v_credit_score
    );
  ELSE
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'eligible',
      'credit_score', v_credit_score
    );
  END IF;
END;
$$;