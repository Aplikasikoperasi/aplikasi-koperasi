-- Create function to check if NIK is blocked
CREATE OR REPLACE FUNCTION public.is_nik_blocked(check_nik TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.blocked_customers bc
    JOIN public.customers c ON bc.customer_id = c.id
    WHERE c.nik = check_nik
  )
$$;