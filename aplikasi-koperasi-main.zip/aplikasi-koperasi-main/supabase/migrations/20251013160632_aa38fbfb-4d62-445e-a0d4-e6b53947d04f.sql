-- Create blocked_customers table
CREATE TABLE public.blocked_customers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  blocked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  blocked_reason TEXT NOT NULL DEFAULT 'Menunggak pembayaran selama 3 bulan berturut-turut',
  consecutive_missed_months INTEGER NOT NULL DEFAULT 3,
  application_id UUID REFERENCES public.credit_applications(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(customer_id)
);

-- Enable RLS
ALTER TABLE public.blocked_customers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for blocked_customers
CREATE POLICY "Authenticated users can view blocked customers"
ON public.blocked_customers
FOR SELECT
USING (true);

CREATE POLICY "All staff can insert blocked customers"
ON public.blocked_customers
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'owner'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'sales'::app_role)
);

CREATE POLICY "Only owner can delete blocked customers"
ON public.blocked_customers
FOR DELETE
USING (has_role(auth.uid(), 'owner'::app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_blocked_customers_updated_at
BEFORE UPDATE ON public.blocked_customers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for faster lookups
CREATE INDEX idx_blocked_customers_customer_id ON public.blocked_customers(customer_id);
CREATE INDEX idx_blocked_customers_blocked_at ON public.blocked_customers(blocked_at);