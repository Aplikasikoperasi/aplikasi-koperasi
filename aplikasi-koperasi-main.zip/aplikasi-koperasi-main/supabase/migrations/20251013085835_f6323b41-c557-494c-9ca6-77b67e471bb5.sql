-- Create the first superuser account (FTC)
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Check if owner already exists
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'owner') THEN
    -- Create auth user (profile will be auto-created by trigger)
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'FTC@system.local',
      crypt('04102018', gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"FTC"}',
      now(),
      now(),
      '',
      ''
    )
    RETURNING id INTO v_user_id;

    -- Create member record
    INSERT INTO public.members (
      user_id,
      member_number,
      full_name,
      position,
      date_of_birth
    ) VALUES (
      v_user_id,
      'FTC',
      'FTC',
      'Owner',
      '2018-10-04'
    );

    -- Assign owner role
    INSERT INTO public.user_roles (
      user_id,
      role
    ) VALUES (
      v_user_id,
      'owner'
    );
  END IF;
END $$;