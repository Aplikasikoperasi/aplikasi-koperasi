-- Enable realtime on blocked_customers and customers
ALTER TABLE public.blocked_customers REPLICA IDENTITY FULL;
ALTER TABLE public.customers REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.blocked_customers;
ALTER PUBLICATION supabase_realtime ADD TABLE public.customers;