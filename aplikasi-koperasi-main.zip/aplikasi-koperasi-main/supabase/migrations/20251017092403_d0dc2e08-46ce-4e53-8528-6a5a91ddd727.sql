
-- Delete customers that were created by owner members
-- First check if they have any credit applications or blocked records
DO $$
DECLARE
  owner_member_id uuid;
  customer_record RECORD;
BEGIN
  -- Get owner member ID
  SELECT id INTO owner_member_id FROM members WHERE position = 'Owner' OR position ILIKE '%owner%' LIMIT 1;
  
  IF owner_member_id IS NOT NULL THEN
    -- Loop through customers created by owner
    FOR customer_record IN 
      SELECT id FROM customers WHERE created_by = owner_member_id
    LOOP
      -- Delete related blocked_customers records first (if any)
      DELETE FROM blocked_customers WHERE customer_id = customer_record.id;
      
      -- Delete related installments (via cascade from applications)
      -- Delete related payments (via cascade from applications)
      -- Delete credit applications
      DELETE FROM credit_applications WHERE customer_id = customer_record.id;
      
      -- Finally delete the customer
      DELETE FROM customers WHERE id = customer_record.id;
    END LOOP;
  END IF;
END $$;

-- Update the trigger function to be more explicit about preventing owner from becoming customer
CREATE OR REPLACE FUNCTION public.create_customer_for_sales_member()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  -- Only create customer if member is active and NOT an owner (case insensitive)
  IF NEW.is_active = true AND (NEW.position IS NULL OR (LOWER(NEW.position) NOT LIKE '%owner%' AND NEW.position != 'Owner')) THEN
    -- Check if customer doesn't already exist for THIS SPECIFIC member
    IF NOT EXISTS (
      SELECT 1
      FROM public.customers
      WHERE created_by = NEW.id
    ) THEN
      -- Get highest customer id_number
      SELECT COALESCE(
        MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
        0
      ) INTO max_num
      FROM public.customers
      WHERE id_number ~ '^N[0-9]+$';
      
      next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
      
      -- Insert customer record with member's data
      INSERT INTO public.customers (
        id_number,
        full_name,
        nik,
        date_of_birth,
        phone,
        address,
        occupation,
        photo_url,
        created_by
      ) VALUES (
        next_id_number,
        NEW.full_name,
        NEW.nik,
        NEW.date_of_birth,
        NEW.phone,
        NEW.address,
        NEW.occupation,
        NEW.photo_url,
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Update handle_member_status_change to also exclude owner
CREATE OR REPLACE FUNCTION public.handle_member_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  -- If member is deactivated, remove them from customers table (except owner)
  IF NEW.is_active = false AND OLD.is_active = true AND (LOWER(NEW.position) NOT LIKE '%owner%' AND NEW.position != 'Owner') THEN
    DELETE FROM public.customers
    WHERE created_by = NEW.id;
  END IF;
  
  -- If member is reactivated, recreate customer record (except owner - case insensitive)
  IF NEW.is_active = true AND OLD.is_active = false AND (LOWER(NEW.position) NOT LIKE '%owner%' AND NEW.position != 'Owner') THEN
    -- Check if customer doesn't already exist for THIS SPECIFIC member
    IF NOT EXISTS (
      SELECT 1
      FROM public.customers
      WHERE created_by = NEW.id
    ) THEN
      -- Get highest customer id_number
      SELECT COALESCE(
        MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
        0
      ) INTO max_num
      FROM public.customers
      WHERE id_number ~ '^N[0-9]+$';
      
      next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
      
      -- Insert customer record
      INSERT INTO public.customers (
        id_number,
        full_name,
        nik,
        date_of_birth,
        phone,
        address,
        occupation,
        photo_url,
        created_by
      ) VALUES (
        next_id_number,
        NEW.full_name,
        NEW.nik,
        NEW.date_of_birth,
        NEW.phone,
        NEW.address,
        NEW.occupation,
        NEW.photo_url,
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Update create_customer_on_sales_role to also check member position
CREATE OR REPLACE FUNCTION public.create_customer_on_sales_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  member_record RECORD;
  next_id_number TEXT;
  max_num INTEGER;
BEGIN
  -- Only proceed if the new role is 'sales'
  IF NEW.role = 'sales'::app_role THEN
    -- Get member record for this user
    SELECT * INTO member_record
    FROM public.members
    WHERE user_id = NEW.user_id
    LIMIT 1;
    
    -- If member exists and is NOT an owner, create customer record
    IF FOUND AND (member_record.position IS NULL OR (LOWER(member_record.position) NOT LIKE '%owner%' AND member_record.position != 'Owner')) THEN
      -- Check if customer doesn't already exist
      IF NOT EXISTS (
        SELECT 1
        FROM public.customers
        WHERE created_by = member_record.id OR (nik IS NOT NULL AND nik = member_record.nik)
      ) THEN
        -- Get highest customer id_number
        SELECT COALESCE(
          MAX(CAST(REPLACE(id_number, 'N', '') AS INTEGER)),
          0
        ) INTO max_num
        FROM public.customers
        WHERE id_number ~ '^N[0-9]+$';
        
        next_id_number := 'N' || LPAD((max_num + 1)::TEXT, 5, '0');
        
        -- Insert customer record
        INSERT INTO public.customers (
          id_number,
          full_name,
          nik,
          date_of_birth,
          phone,
          address,
          occupation,
          photo_url,
          created_by
        ) VALUES (
          next_id_number,
          member_record.full_name,
          member_record.nik,
          member_record.date_of_birth,
          member_record.phone,
          member_record.address,
          member_record.occupation,
          member_record.photo_url,
          member_record.id
        );
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;
