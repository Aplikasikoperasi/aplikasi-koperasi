-- Update auto_block_low_credit_score to trigger at credit_score < 3.5 (instead of < 4)
CREATE OR REPLACE FUNCTION public.auto_block_low_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_total_installments integer;
  v_late_installments integer;
  v_overdue_installments integer;
  v_on_time_percentage numeric;
  v_block_reason text;
  v_has_real_overdue boolean;
BEGIN
  -- Only check if credit score dropped below 3.5
  IF NEW.credit_score < 3.5 AND (OLD.credit_score IS NULL OR OLD.credit_score >= 3.5) THEN
    -- Skip if already blocked
    IF NOT EXISTS (SELECT 1 FROM public.blocked_customers WHERE customer_id = NEW.id) THEN
      -- Only consider REAL overdue (with penalty > 0)
      SELECT EXISTS (
        SELECT 1
        FROM installments i
        JOIN credit_applications ca ON ca.id = i.application_id
        WHERE ca.customer_id = NEW.id
          AND ca.status IN ('approved','disbursed')
          AND i.status = 'overdue'
          AND COALESCE(i.frozen_penalty,0) > 0
      ) INTO v_has_real_overdue;

      IF v_has_real_overdue THEN
        SELECT 
          COUNT(i.id),
          COUNT(CASE 
            WHEN i.status = 'overdue' OR 
                 (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date AND COALESCE(i.frozen_penalty,0) > 0)
            THEN 1 END),
          COUNT(CASE WHEN i.status = 'overdue' THEN 1 END)
        INTO v_total_installments, v_late_installments, v_overdue_installments
        FROM installments i
        JOIN credit_applications ca ON ca.id = i.application_id
        WHERE ca.customer_id = NEW.id
          AND ca.status IN ('approved','disbursed');

        IF v_total_installments > 0 THEN
          v_on_time_percentage := ((v_total_installments - v_late_installments)::numeric / v_total_installments::numeric) * 100;
        ELSE
          v_on_time_percentage := 0;
        END IF;

        v_block_reason := format(
          'Diblokir otomatis: skor %s bintang. Total %s angsuran, %s telat (%s%% tepat waktu), %s menunggak (real).',
          NEW.credit_score,
          v_total_installments,
          v_late_installments,
          ROUND(v_on_time_percentage,1),
          v_overdue_installments
        );

        INSERT INTO public.blocked_customers (customer_id, blocked_reason, blocked_by, consecutive_missed_months)
        VALUES (NEW.id, v_block_reason, NULL, 0)
        ON CONFLICT (customer_id) DO UPDATE
          SET blocked_reason = EXCLUDED.blocked_reason,
              blocked_at = now(),
              consecutive_missed_months = EXCLUDED.consecutive_missed_months;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

-- Update can_apply_for_credit to require minimum 3.5 credit score (instead of 3)
CREATE OR REPLACE FUNCTION public.can_apply_for_credit(check_nik text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
  v_customer_id uuid;
  v_has_active_credit boolean;
  v_has_unpaid_installments boolean;
  v_credit_score numeric;
  v_restoration_status text;
  v_is_currently_blocked boolean;
BEGIN
  -- Cek apakah NIK ini pernah diblokir permanen (cek di customers yang masih ada)
  SELECT id, credit_score, restoration_status INTO v_customer_id, v_credit_score, v_restoration_status
  FROM public.customers
  WHERE nik = check_nik
  LIMIT 1;
  
  -- Jika customer ditemukan dan statusnya permanently_blocked
  IF v_customer_id IS NOT NULL AND v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'permanently_blocked',
      'message', 'NIK ini telah diblokir permanen dan tidak dapat mengajukan kredit',
      'credit_score', 0
    );
  END IF;
  
  -- Cek apakah NIK ini sedang dalam daftar blokir
  SELECT EXISTS (
    SELECT 1
    FROM public.blocked_customers bc
    JOIN public.customers c ON bc.customer_id = c.id
    WHERE c.nik = check_nik
  ) INTO v_is_currently_blocked;
  
  IF v_is_currently_blocked THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'currently_blocked',
      'message', 'Nasabah sedang dalam status diblokir',
      'credit_score', COALESCE(v_credit_score, 0)
    );
  END IF;
  
  -- If customer not found, they can apply (new customer will get default 5 stars)
  IF v_customer_id IS NULL THEN
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'new_customer',
      'credit_score', 5
    );
  END IF;
  
  -- Check if customer has active credit (approved or disbursed)
  SELECT EXISTS (
    SELECT 1
    FROM public.credit_applications ca
    WHERE ca.customer_id = v_customer_id
    AND ca.status IN ('approved', 'disbursed')
    AND EXISTS (
      SELECT 1
      FROM public.installments i
      WHERE i.application_id = ca.id
      AND i.status != 'paid'
      AND i.principal_paid = false
    )
  ) INTO v_has_active_credit;
  
  -- Check if customer has any unpaid principal
  SELECT EXISTS (
    SELECT 1
    FROM public.installments i
    JOIN public.credit_applications ca ON ca.id = i.application_id
    WHERE ca.customer_id = v_customer_id
    AND i.principal_paid = false
    AND (i.status = 'unpaid' OR i.status = 'overdue' OR i.status = 'partial')
  ) INTO v_has_unpaid_installments;
  
  -- Customer can apply if:
  -- 1. No active credit with unpaid principal
  -- 2. No unpaid principal installments
  -- 3. Credit score >= 3.5 (CHANGED from 3)
  IF v_has_active_credit THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'active_credit_exists',
      'message', 'Nasabah masih memiliki kredit aktif yang pokoknya belum lunas',
      'credit_score', v_credit_score
    );
  ELSIF v_has_unpaid_installments THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'unpaid_installments',
      'message', 'Nasabah memiliki angsuran pokok yang belum dilunasi',
      'credit_score', v_credit_score
    );
  ELSIF v_credit_score < 3.5 THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'low_credit_score',
      'message', 'Skor kredit nasabah terlalu rendah (minimum 3.5 bintang)',
      'credit_score', v_credit_score
    );
  ELSE
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'eligible',
      'credit_score', v_credit_score
    );
  END IF;
END;
$function$;