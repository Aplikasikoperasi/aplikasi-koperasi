-- Update paid_amount untuk installments dengan pembayaran ganda
-- Sesuaikan paid_amount dengan sum dari payments yang ada

-- ARLIDA SITUMORANG: sum payments = 1,480,000
UPDATE installments 
SET paid_amount = 1480000
WHERE id = '69b02396-caf2-4df2-8b97-cd2af5691795';

-- M. RESTY: sum payments = 1,400,000
UPDATE installments 
SET paid_amount = 1400000
WHERE id = '50f6948d-e1e5-4c42-be5a-5dd8f4cebea4';