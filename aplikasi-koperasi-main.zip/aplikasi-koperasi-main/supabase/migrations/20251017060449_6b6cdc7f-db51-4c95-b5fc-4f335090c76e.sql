-- Ensure trigger for generate_installments is properly set up
DROP TRIGGER IF EXISTS trg_generate_installments ON public.credit_applications;

CREATE TRIGGER trg_generate_installments
AFTER UPDATE OF status ON public.credit_applications
FOR EACH ROW
WHEN (NEW.status IN ('approved', 'disbursed') AND (OLD.status IS DISTINCT FROM NEW.status))
EXECUTE FUNCTION public.generate_installments();