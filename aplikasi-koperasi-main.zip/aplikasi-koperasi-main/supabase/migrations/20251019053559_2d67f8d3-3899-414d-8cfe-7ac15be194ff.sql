-- 1) Update auto-block logic to ignore historical data (no penalty)
CREATE OR REPLACE FUNCTION public.auto_block_low_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_total_installments integer;
  v_late_installments integer;
  v_overdue_installments integer;
  v_on_time_percentage numeric;
  v_block_reason text;
  v_has_real_overdue boolean;
BEGIN
  -- Only check if credit score dropped below 4
  IF NEW.credit_score < 4 AND (OLD.credit_score IS NULL OR OLD.credit_score >= 4) THEN
    -- Skip if already blocked
    IF NOT EXISTS (SELECT 1 FROM public.blocked_customers WHERE customer_id = NEW.id) THEN
      -- Only consider REAL overdue (with penalty > 0)
      SELECT EXISTS (
        SELECT 1
        FROM installments i
        JOIN credit_applications ca ON ca.id = i.application_id
        WHERE ca.customer_id = NEW.id
          AND ca.status IN ('approved','disbursed')
          AND i.status = 'overdue'
          AND COALESCE(i.frozen_penalty,0) > 0
      ) INTO v_has_real_overdue;

      IF v_has_real_overdue THEN
        SELECT 
          COUNT(i.id),
          COUNT(CASE 
            WHEN i.status = 'overdue' OR 
                 (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date AND COALESCE(i.frozen_penalty,0) > 0)
            THEN 1 END),
          COUNT(CASE WHEN i.status = 'overdue' THEN 1 END)
        INTO v_total_installments, v_late_installments, v_overdue_installments
        FROM installments i
        JOIN credit_applications ca ON ca.id = i.application_id
        WHERE ca.customer_id = NEW.id
          AND ca.status IN ('approved','disbursed');

        IF v_total_installments > 0 THEN
          v_on_time_percentage := ((v_total_installments - v_late_installments)::numeric / v_total_installments::numeric) * 100;
        ELSE
          v_on_time_percentage := 0;
        END IF;

        v_block_reason := format(
          'Diblokir otomatis: skor %s bintang. Total %s angsuran, %s telat (%s%% tepat waktu), %s menunggak (real).',
          NEW.credit_score,
          v_total_installments,
          v_late_installments,
          ROUND(v_on_time_percentage,1),
          v_overdue_installments
        );

        INSERT INTO public.blocked_customers (customer_id, blocked_reason, blocked_by, consecutive_missed_months)
        VALUES (NEW.id, v_block_reason, NULL, 0)
        ON CONFLICT (customer_id) DO UPDATE
          SET blocked_reason = EXCLUDED.blocked_reason,
              blocked_at = now(),
              consecutive_missed_months = EXCLUDED.consecutive_missed_months;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

-- 2) Recalculate credit score ignoring historical (no-penalty) late payments
CREATE OR REPLACE FUNCTION public.calculate_credit_score(p_customer_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_total_installments integer;
  v_late_installments integer;
  v_on_time_percentage numeric;
  v_credit_score integer;
BEGIN
  SELECT COUNT(i.id) INTO v_total_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
    AND ca.status IN ('approved','disbursed');

  IF v_total_installments = 0 THEN
    RETURN 5;
  END IF;

  SELECT COUNT(i.id) INTO v_late_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
    AND ca.status IN ('approved','disbursed')
    AND (
      (i.status = 'overdue' AND COALESCE(i.frozen_penalty,0) > 0) OR
      (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date AND COALESCE(i.frozen_penalty,0) > 0)
    );

  v_on_time_percentage := (v_total_installments - v_late_installments)::numeric / v_total_installments::numeric;
  v_credit_score := ROUND(v_on_time_percentage * 5);
  v_credit_score := GREATEST(0, LEAST(5, v_credit_score));
  RETURN v_credit_score;
END;
$function$;

-- 3) Auto-unblock when credit score recovers (and not permanently blocked)
CREATE OR REPLACE FUNCTION public.auto_unblock_on_credit_score()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.credit_score >= 4 THEN
    -- Do not auto-unblock permanently blocked customers
    IF EXISTS (SELECT 1 FROM customers c WHERE c.id = NEW.id AND c.restoration_status = 'permanently_blocked') THEN
      RETURN NEW;
    END IF;
    DELETE FROM blocked_customers WHERE customer_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$function$;

-- 4) Ensure triggers exist and point to latest functions
DROP TRIGGER IF EXISTS trigger_auto_block_low_credit_score ON customers;
CREATE TRIGGER trigger_auto_block_low_credit_score
AFTER UPDATE OF credit_score ON customers
FOR EACH ROW EXECUTE FUNCTION public.auto_block_low_credit_score();

DROP TRIGGER IF EXISTS trg_installments_update_credit_score ON installments;
CREATE TRIGGER trg_installments_update_credit_score
AFTER INSERT OR UPDATE ON installments
FOR EACH ROW EXECUTE FUNCTION public.trigger_update_credit_score();

DROP TRIGGER IF EXISTS trg_payments_update_credit_score ON payments;
CREATE TRIGGER trg_payments_update_credit_score
AFTER INSERT OR UPDATE ON payments
FOR EACH ROW EXECUTE FUNCTION public.trigger_update_credit_score_on_payment();

DROP TRIGGER IF EXISTS trg_auto_unblock_on_credit_score ON customers;
CREATE TRIGGER trg_auto_unblock_on_credit_score
AFTER UPDATE OF credit_score ON customers
FOR EACH ROW EXECUTE FUNCTION public.auto_unblock_on_credit_score();

-- 5) One-time cleanup: unblocking customers that only have historical/no-penalty issues
DELETE FROM blocked_customers bc
USING customers c
WHERE bc.customer_id = c.id
  AND c.restoration_status <> 'permanently_blocked'
  AND NOT EXISTS (
    SELECT 1
    FROM installments i
    JOIN credit_applications ca ON ca.id = i.application_id
    WHERE ca.customer_id = c.id
      AND ca.status IN ('approved','disbursed')
      AND (
        (i.status = 'overdue' AND COALESCE(i.frozen_penalty,0) > 0) OR
        (i.status = 'paid' AND i.paid_at IS NOT NULL AND i.paid_at::date > i.due_date AND COALESCE(i.frozen_penalty,0) > 0)
      )
  );

-- 6) For customer N00011 (historical), mark installments as paid if no penalty
UPDATE installments i
SET paid_amount = i.total_amount,
    principal_paid = TRUE,
    status = 'paid',
    paid_at = COALESCE(i.paid_at, i.due_date)
FROM credit_applications ca
JOIN customers c ON c.id = ca.customer_id
WHERE i.application_id = ca.id
  AND c.id_number = 'N00011'
  AND ca.status IN ('approved','disbursed')
  AND i.status <> 'paid'
  AND COALESCE(i.frozen_penalty,0) = 0;

-- Recalculate credit score for N00011
DO $$
DECLARE
  v_customer_id uuid;
BEGIN
  SELECT id INTO v_customer_id FROM customers WHERE id_number = 'N00011' LIMIT 1;
  IF v_customer_id IS NOT NULL THEN
    PERFORM public.update_customer_credit_score(v_customer_id);
  END IF;
END $$;