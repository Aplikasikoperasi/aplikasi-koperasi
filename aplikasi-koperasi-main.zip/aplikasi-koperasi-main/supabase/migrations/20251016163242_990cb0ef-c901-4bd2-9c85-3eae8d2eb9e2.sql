-- Add super_code column to app_settings for owner verification
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS super_code TEXT;