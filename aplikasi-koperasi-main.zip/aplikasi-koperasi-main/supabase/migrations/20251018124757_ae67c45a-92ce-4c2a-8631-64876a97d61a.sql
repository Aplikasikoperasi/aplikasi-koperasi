-- Remove unused proxy credential columns from app_settings table
-- These columns stored sensitive credentials in plain text and are not used by the application

ALTER TABLE public.app_settings 
DROP COLUMN IF EXISTS proxy_enabled,
DROP COLUMN IF EXISTS proxy_username,
DROP COLUMN IF EXISTS proxy_password,
DROP COLUMN IF EXISTS proxy_host,
DROP COLUMN IF EXISTS proxy_port;

-- Add comment explaining the removal
COMMENT ON TABLE public.app_settings IS 'System settings for the credit application. Proxy credentials removed for security compliance.';