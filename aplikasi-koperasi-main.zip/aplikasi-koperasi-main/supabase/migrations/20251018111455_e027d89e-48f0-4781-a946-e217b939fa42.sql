-- Enable pg_cron extension for scheduled jobs
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;

-- Enable pg_net extension for HTTP requests
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Create storage bucket for backups
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'backups',
  'backups',
  false,
  10485760, -- 10MB limit
  ARRAY['application/json', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']
)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for backups bucket
CREATE POLICY "Owner and admin can view backup files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'backups' AND 
  (has_role(auth.uid(), 'owner') OR has_role(auth.uid(), 'admin'))
);

CREATE POLICY "Only system can upload backups"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'backups' AND 
  (has_role(auth.uid(), 'owner') OR has_role(auth.uid(), 'admin'))
);

CREATE POLICY "Owner can delete backup files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'backups' AND 
  has_role(auth.uid(), 'owner')
);

-- Create table to track auto backup settings
CREATE TABLE IF NOT EXISTS public.auto_backup_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enabled boolean NOT NULL DEFAULT false,
  last_backup_at timestamp with time zone,
  next_backup_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.auto_backup_settings ENABLE ROW LEVEL SECURITY;

-- RLS policies for auto_backup_settings
CREATE POLICY "Owner and admin can view backup settings"
ON public.auto_backup_settings FOR SELECT
USING (has_role(auth.uid(), 'owner') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Owner can manage backup settings"
ON public.auto_backup_settings FOR ALL
USING (has_role(auth.uid(), 'owner'));

-- Insert default settings
INSERT INTO public.auto_backup_settings (enabled)
VALUES (false)
ON CONFLICT DO NOTHING;

-- Schedule weekly backup every Sunday at midnight (using cron syntax)
SELECT cron.schedule(
  'weekly-database-backup',
  '0 0 * * 0', -- Every Sunday at 00:00
  $$
  SELECT
    net.http_post(
      url := 'https://rufeqqwcnyzvmelzezgl.supabase.co/functions/v1/weekly-backup',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ1ZmVxcXdjbnl6dm1lbHplemdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyNTkwMjUsImV4cCI6MjA3NTgzNTAyNX0.n40rZ-a6aRnVPtsnKcxuKN5oHigrhclfFrC1V9KiZgs'
      ),
      body := jsonb_build_object('scheduled', true)
    ) as request_id;
  $$
);