-- Update calculate_credit_score to only count installments from ACTIVE credit (with unpaid installments)
CREATE OR REPLACE FUNCTION public.calculate_credit_score(p_customer_id uuid)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_total_installments integer;
  v_on_time_installments integer;
  v_credit_score numeric;
BEGIN
  -- Count ONLY installments from applications that STILL HAVE unpaid installments (active credit)
  -- Exclude applications where ALL installments are paid (completed credit)
  SELECT COUNT(i.id) INTO v_total_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
    AND ca.status IN ('approved','disbursed')
    -- Only include applications that have at least one unpaid installment
    AND EXISTS (
      SELECT 1 FROM installments i2
      WHERE i2.application_id = ca.id
      AND i2.principal_paid = false
    );

  -- Return default score if no active installments
  IF v_total_installments = 0 THEN
    RETURN 5.0;
  END IF;

  -- Count on-time installments from active credit only
  SELECT COUNT(i.id) INTO v_on_time_installments
  FROM installments i
  JOIN credit_applications ca ON ca.id = i.application_id
  WHERE ca.customer_id = p_customer_id
    AND ca.status IN ('approved','disbursed')
    -- Only from applications with unpaid installments
    AND EXISTS (
      SELECT 1 FROM installments i2
      WHERE i2.application_id = ca.id
      AND i2.principal_paid = false
    )
    AND (
      -- Paid on time (no penalty frozen)
      (i.status = 'paid' AND COALESCE(i.frozen_penalty, 0) = 0)
      OR
      -- Unpaid but not overdue yet
      (i.status = 'unpaid')
    );

  -- Calculate score as percentage * 5 (gives decimal result)
  v_credit_score := (v_on_time_installments::numeric / v_total_installments::numeric) * 5.0;
  
  -- Round to 1 decimal place and clamp between 0 and 5
  v_credit_score := ROUND(v_credit_score, 1);
  v_credit_score := GREATEST(0.0, LEAST(5.0, v_credit_score));
  
  RETURN v_credit_score;
END;
$function$;