-- Recreate RPC with created_by capture and robust locking
CREATE OR REPLACE FUNCTION public.apply_payment_to_installment(
  p_installment_id uuid,
  p_amount numeric,
  p_payment_date date,
  p_payment_method text,
  p_reference text,
  p_notes text DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_inst RECORD;
  v_penalty_rate numeric := 2.0;
  v_today date := CURRENT_DATE;
  v_is_historical boolean;
  v_days_overdue integer := 0;
  v_penalty_due numeric := 0;
  v_base_remaining numeric := 0;
  v_need numeric := 0;
  v_paying numeric := 0;
  v_pay_to_principal numeric := 0;
  v_pay_to_penalty numeric := 0;
  v_new_paid_amount numeric := 0;
  v_principal_paid boolean := false;
  v_frozen_penalty numeric := 0;
  v_frozen_days integer := 0;
  v_status text := 'partial';
  v_payment_id uuid;
  v_user_id uuid := auth.uid();
BEGIN
  -- Lock the installment row to avoid race conditions
  SELECT * INTO v_inst
  FROM installments
  WHERE id = p_installment_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Installment not found';
  END IF;

  -- Load settings (penalty)
  SELECT penalty_rate_per_day INTO v_penalty_rate
  FROM app_settings
  ORDER BY updated_at DESC NULLS LAST, created_at DESC
  LIMIT 1;
  v_penalty_rate := COALESCE(v_penalty_rate, 2.0);

  v_is_historical := p_payment_date < v_today;

  -- Compute overdue & penalty
  IF v_is_historical THEN
    v_penalty_due := 0;
    v_frozen_days := 0;
  ELSE
    IF v_inst.principal_paid THEN
      v_penalty_due := COALESCE(v_inst.frozen_penalty,0);
      v_frozen_days := COALESCE(v_inst.frozen_days_overdue,0);
    ELSE
      v_days_overdue := GREATEST(0, p_payment_date - v_inst.due_date);
      IF v_days_overdue > 0 THEN
        v_penalty_due := CEIL( (v_inst.total_amount * (v_penalty_rate/100) * v_days_overdue) / 1000) * 1000;
        v_frozen_days := v_days_overdue;
      ELSE
        v_penalty_due := 0;
        v_frozen_days := 0;
      END IF;
    END IF;
  END IF;

  v_base_remaining := GREATEST(0, v_inst.total_amount - v_inst.paid_amount);
  v_need := v_base_remaining + v_penalty_due;
  IF v_need <= 0 THEN
    -- Already fully paid including penalty
    RETURN jsonb_build_object(
      'allocated_principal', 0,
      'allocated_penalty', 0,
      'remaining_need', 0,
      'payment_id', NULL,
      'status', v_inst.status
    );
  END IF;

  v_paying := LEAST(p_amount, v_need);
  v_pay_to_principal := LEAST(v_paying, v_base_remaining);
  v_pay_to_penalty := v_paying - v_pay_to_principal;

  -- Insert payment record (idempotency minimal via same ref)
  INSERT INTO payments (
    installment_id,
    application_id,
    amount,
    payment_date,
    payment_method,
    reference_number,
    notes,
    created_by
  ) VALUES (
    v_inst.id,
    v_inst.application_id,
    v_paying,
    p_payment_date,
    p_payment_method,
    NULLIF(p_reference, ''),
    p_notes,
    v_user_id
  ) RETURNING id INTO v_payment_id;

  -- Update installment safely based on locked row
  v_new_paid_amount := v_inst.paid_amount + v_pay_to_principal;
  v_principal_paid := v_inst.principal_paid OR v_new_paid_amount >= v_inst.total_amount;

  IF v_inst.principal_paid THEN
    -- Only reducing frozen penalty
    v_frozen_penalty := GREATEST(0, COALESCE(v_inst.frozen_penalty,0) - v_pay_to_penalty);
    v_frozen_days := CASE WHEN v_frozen_penalty > 0 THEN COALESCE(v_inst.frozen_days_overdue,0) ELSE 0 END;
  ELSE
    -- Principal not yet fully paid
    IF v_principal_paid THEN
      IF (v_penalty_due - v_pay_to_penalty) <= 0 THEN
        v_frozen_penalty := 0;
        v_frozen_days := 0;
      ELSE
        v_frozen_penalty := v_penalty_due - v_pay_to_penalty;
        v_frozen_days := v_frozen_days; -- keep computed overdue days
      END IF;
    ELSE
      -- Keep previous frozen penalty as we don't freeze during partial principal payments
      v_frozen_penalty := COALESCE(v_inst.frozen_penalty,0);
      v_frozen_days := COALESCE(v_inst.frozen_days_overdue,0);
    END IF;
  END IF;

  IF v_principal_paid AND v_frozen_penalty = 0 THEN
    v_status := 'paid';
  ELSE
    v_status := 'partial';
  END IF;

  UPDATE installments
  SET paid_amount = v_new_paid_amount,
      principal_paid = v_principal_paid,
      frozen_penalty = v_frozen_penalty,
      frozen_days_overdue = v_frozen_days,
      status = v_status,
      paid_at = CASE WHEN v_status = 'paid' THEN p_payment_date::timestamp ELSE paid_at END
  WHERE id = v_inst.id;

  RETURN jsonb_build_object(
    'payment_id', v_payment_id,
    'allocated_principal', v_pay_to_principal,
    'allocated_penalty', v_pay_to_penalty,
    'remaining_need', GREATEST(0, v_need - v_paying),
    'new_status', v_status
  );
END;
$$;

-- Delete duplicate full-amount payments within 5 minutes window keeping the earliest
DELETE FROM payments p
USING installments i
WHERE i.id = p.installment_id
  AND p.amount = i.total_amount
  AND EXISTS (
    SELECT 1
    FROM payments p_first
    WHERE p_first.installment_id = p.installment_id
      AND p_first.amount = i.total_amount
      AND p_first.created_at = (
        SELECT MIN(p3.created_at)
        FROM payments p3
        WHERE p3.installment_id = p.installment_id
          AND p3.amount = i.total_amount
      )
      AND p.created_at > p_first.created_at
      AND p.created_at - p_first.created_at <= interval '5 minutes'
  );

-- Normalize installments where paid_amount exceeded total_amount due to duplicates
UPDATE installments i
SET paid_amount = LEAST(i.paid_amount, i.total_amount),
    principal_paid = CASE WHEN i.paid_amount >= i.total_amount THEN TRUE ELSE i.principal_paid END,
    status = CASE WHEN i.paid_amount >= i.total_amount AND COALESCE(i.frozen_penalty,0)=0 THEN 'paid' ELSE i.status END
WHERE i.paid_amount > i.total_amount;