-- 1. Create function to prevent duplicate payments for the same installment
CREATE OR REPLACE FUNCTION public.prevent_duplicate_payment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_installment_status TEXT;
  v_existing_payment_count INTEGER;
BEGIN
  -- Check if installment is already fully paid
  SELECT status INTO v_installment_status
  FROM installments
  WHERE id = NEW.installment_id;
  
  IF v_installment_status = 'paid' THEN
    RAISE EXCEPTION 'Angsuran ini sudah lunas dan tidak dapat dibayar lagi. Silakan refresh halaman untuk melihat status terkini.';
  END IF;
  
  -- Check for duplicate payment attempts (same installment, similar amount, recent timestamp)
  SELECT COUNT(*) INTO v_existing_payment_count
  FROM payments
  WHERE installment_id = NEW.installment_id
    AND amount = NEW.amount
    AND payment_date = NEW.payment_date
    AND created_at > (NOW() - INTERVAL '5 seconds'); -- Prevent rapid duplicate submissions
  
  IF v_existing_payment_count > 0 THEN
    RAISE EXCEPTION 'Pembayaran duplikat terdeteksi untuk angsuran ini. Mohon tunggu beberapa saat dan refresh halaman.';
  END IF;
  
  RETURN NEW;
END;
$$;

-- 2. Create trigger to run before payment insert
DROP TRIGGER IF EXISTS trigger_prevent_duplicate_payment ON payments;
CREATE TRIGGER trigger_prevent_duplicate_payment
  BEFORE INSERT ON payments
  FOR EACH ROW
  EXECUTE FUNCTION prevent_duplicate_payment();

-- 3. Clean up existing duplicate payments (keep the most recent one for each installment)
WITH duplicates AS (
  SELECT 
    id,
    installment_id,
    ROW_NUMBER() OVER (
      PARTITION BY installment_id 
      ORDER BY created_at DESC, payment_date DESC
    ) as rn
  FROM payments
)
DELETE FROM payments
WHERE id IN (
  SELECT id FROM duplicates WHERE rn > 1
);

-- 4. Log the cleanup
DO $$
DECLARE
  v_deleted_count INTEGER;
BEGIN
  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
  RAISE NOTICE 'Cleaned up % duplicate payment records', v_deleted_count;
END $$;
