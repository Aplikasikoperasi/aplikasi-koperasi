-- Add nik column to members table
ALTER TABLE public.members 
ADD COLUMN nik text;