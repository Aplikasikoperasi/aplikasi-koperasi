-- Add occupation column to members table
ALTER TABLE public.members 
ADD COLUMN occupation text;