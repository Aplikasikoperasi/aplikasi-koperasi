-- Restore/ensure roles in user_roles based on members.position
-- Map positions to roles and upsert
INSERT INTO public.user_roles (user_id, role)
SELECT DISTINCT m.user_id, 'owner'::app_role
FROM public.members m
WHERE m.user_id IS NOT NULL AND (LOWER(m.position) = 'owner' OR m.position = 'Owner')
ON CONFLICT (user_id, role) DO NOTHING;

INSERT INTO public.user_roles (user_id, role)
SELECT DISTINCT m.user_id, 'admin'::app_role
FROM public.members m
WHERE m.user_id IS NOT NULL AND (LOWER(m.position) = 'admin' OR m.position = 'Admin')
ON CONFLICT (user_id, role) DO NOTHING;

INSERT INTO public.user_roles (user_id, role)
SELECT DISTINCT m.user_id, 'sales'::app_role
FROM public.members m
WHERE m.user_id IS NOT NULL AND (
  m.position IS NULL OR (
    LOWER(m.position) NOT IN ('owner','admin') AND m.position NOT IN ('Owner','Admin')
  )
)
ON CONFLICT (user_id, role) DO NOTHING;