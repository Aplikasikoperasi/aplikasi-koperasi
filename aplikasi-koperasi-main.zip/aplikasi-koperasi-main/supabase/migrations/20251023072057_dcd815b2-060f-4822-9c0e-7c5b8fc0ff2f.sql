-- Mark credit applications as completed when all installments are paid
-- 1) Helper function
CREATE OR REPLACE FUNCTION public.mark_application_completed_if_paid(p_application_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total integer;
  v_paid integer;
BEGIN
  SELECT COUNT(*) INTO v_total FROM public.installments WHERE application_id = p_application_id;
  IF v_total = 0 THEN
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_paid FROM public.installments WHERE application_id = p_application_id AND status = 'paid';
  IF v_paid = v_total THEN
    UPDATE public.credit_applications
    SET status = 'completed', updated_at = now()
    WHERE id = p_application_id
      AND status IN ('approved','disbursed');
  END IF;
END;
$$;

-- 2) Trigger function
CREATE OR REPLACE FUNCTION public.installments_after_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.mark_application_completed_if_paid(NEW.application_id);
  RETURN NEW;
END;
$$;

-- 3) Trigger on installments insert/update
DROP TRIGGER IF EXISTS trg_installments_after_change ON public.installments;
CREATE TRIGGER trg_installments_after_change
AFTER INSERT OR UPDATE ON public.installments
FOR EACH ROW
EXECUTE FUNCTION public.installments_after_change();

-- 4) Backfill existing data
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT id FROM public.credit_applications WHERE status IN ('approved','disbursed') LOOP
    PERFORM public.mark_application_completed_if_paid(r.id);
  END LOOP;
END $$;