-- Public settings accessor for non-owner roles
CREATE OR REPLACE FUNCTION public.get_public_app_settings()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT to_jsonb(s)
  FROM (
    SELECT 
      first_installment_type,
      admin_fee_enabled,
      admin_fee_amount,
      max_tenor_months,
      interest_type,
      flat_interest_rate,
      penalty_rate_per_day,
      custom_rates
    FROM app_settings
    LIMIT 1
  ) s
$$;

-- Auto-apply first installment payment on approval when configured
CREATE OR REPLACE FUNCTION public.apply_first_installment_on_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_first_type text;
  v_first_installment record;
  v_payment_amount numeric;
BEGIN
  -- Only run when status becomes approved/disbursed
  IF TG_OP = 'UPDATE' AND NEW.status IN ('approved','disbursed') AND (OLD.status IS DISTINCT FROM NEW.status) THEN
    -- Read config
    SELECT first_installment_type INTO v_first_type FROM app_settings LIMIT 1;
    v_first_type := COALESCE(v_first_type, 'next_month');

    IF v_first_type = 'paid_upfront' THEN
      -- Ensure installments exist (should be created by other trigger)
      SELECT * INTO v_first_installment
      FROM installments 
      WHERE application_id = NEW.id AND installment_number = 1
      LIMIT 1;

      IF FOUND AND v_first_installment.status <> 'paid' THEN
        v_payment_amount := v_first_installment.total_amount;

        -- Insert payment record
        INSERT INTO payments (
          application_id,
          installment_id,
          amount,
          payment_date,
          payment_method,
          reference_number,
          notes,
          created_by
        ) VALUES (
          NEW.id,
          v_first_installment.id,
          v_payment_amount,
          CURRENT_DATE,
          'Potong Pencairan',
          'AUTO-' || (extract(epoch from now())*1000)::bigint,
          'Pembayaran angsuran pertama otomatis saat pencairan',
          NEW.approved_by
        );

        -- Mark installment as paid
        UPDATE installments
        SET paid_amount = v_payment_amount,
            principal_paid = true,
            status = 'paid',
            paid_at = now()
        WHERE id = v_first_installment.id;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

-- Bind trigger to credit_applications updates
DROP TRIGGER IF EXISTS trg_apply_first_installment ON public.credit_applications;
CREATE TRIGGER trg_apply_first_installment
AFTER UPDATE OF status ON public.credit_applications
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status AND NEW.status IN ('approved','disbursed'))
EXECUTE FUNCTION public.apply_first_installment_on_approval();