-- Add super_code column to app_settings table
ALTER TABLE public.app_settings
ADD COLUMN super_code TEXT;

-- Update get_public_app_settings function to include super_code
CREATE OR REPLACE FUNCTION public.get_public_app_settings()
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT to_jsonb(s)
  FROM (
    SELECT 
      first_installment_type,
      admin_fee_enabled,
      admin_fee_amount,
      max_tenor_months,
      interest_type,
      flat_interest_rate,
      penalty_rate_per_day,
      custom_rates,
      super_code
    FROM app_settings
    ORDER BY updated_at DESC NULLS LAST, created_at DESC
    LIMIT 1
  ) s
$function$;