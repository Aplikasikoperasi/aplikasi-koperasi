-- Run the adjustment function again to ensure all existing data is synchronized
SELECT public.adjust_customer_registration_date();