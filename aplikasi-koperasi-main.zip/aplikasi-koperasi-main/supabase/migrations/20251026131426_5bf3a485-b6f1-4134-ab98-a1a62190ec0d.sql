-- Step 1: Update existing applications that have NULL application_date
-- Use approved_at if available, otherwise use created_at
UPDATE credit_applications
SET application_date = COALESCE(approved_at::date, created_at::date)
WHERE application_date IS NULL;

-- Step 2: Make application_date NOT NULL with default value
ALTER TABLE credit_applications 
ALTER COLUMN application_date SET NOT NULL;

ALTER TABLE credit_applications 
ALTER COLUMN application_date SET DEFAULT CURRENT_DATE;

-- Step 3: Create validation trigger to ensure application_date is always set
CREATE OR REPLACE FUNCTION validate_application_date_before_save()
RETURNS TRIGGER AS $$
BEGIN
  -- If application_date is NULL, auto-set based on priority:
  -- 1. approved_at (if exists)
  -- 2. created_at (always exists)
  IF NEW.application_date IS NULL THEN
    NEW.application_date := COALESCE(NEW.approved_at::date, NEW.created_at::date, CURRENT_DATE);
  END IF;
  
  -- Extra validation: if status is approved/disbursed/completed, must have application_date
  IF NEW.status IN ('approved', 'disbursed', 'completed') AND NEW.application_date IS NULL THEN
    RAISE EXCEPTION 'application_date cannot be NULL for status %', NEW.status;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger that runs before INSERT or UPDATE
CREATE TRIGGER ensure_application_date_not_null
  BEFORE INSERT OR UPDATE ON credit_applications
  FOR EACH ROW
  EXECUTE FUNCTION validate_application_date_before_save();