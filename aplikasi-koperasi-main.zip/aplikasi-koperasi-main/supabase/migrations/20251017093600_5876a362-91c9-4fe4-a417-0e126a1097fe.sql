-- Update RLS policy to allow both owner and admin to view app_settings
DROP POLICY IF EXISTS "Only owner can view settings" ON app_settings;

CREATE POLICY "Owner and admin can view settings"
ON app_settings
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'owner') OR 
  has_role(auth.uid(), 'admin')
);
