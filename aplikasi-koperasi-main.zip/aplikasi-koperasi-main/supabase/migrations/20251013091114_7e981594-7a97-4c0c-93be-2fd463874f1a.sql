-- Create FTC superuser account permanently
DO $$
DECLARE
  v_user_id uuid := gen_random_uuid();
  v_hashed_password text;
BEGIN
  -- Check if FTC user already exists
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'FTC@system.local'
  ) THEN
    -- Create the auth user with proper password hash
    INSERT INTO auth.users (
      id,
      instance_id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      confirmation_sent_at,
      recovery_sent_at,
      email_change_sent_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      created_at,
      updated_at
    ) VALUES (
      v_user_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated',
      'authenticated',
      'FTC@system.local',
      crypt('04102018', gen_salt('bf')),
      now(),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"FTC"}',
      false,
      now(),
      now()
    );

    -- Create identity record
    INSERT INTO auth.identities (
      id,
      user_id,
      identity_data,
      provider,
      last_sign_in_at,
      created_at,
      updated_at
    ) VALUES (
      gen_random_uuid(),
      v_user_id,
      jsonb_build_object('sub', v_user_id::text, 'email', 'FTC@system.local'),
      'email',
      now(),
      now(),
      now()
    );

    -- Create profile
    INSERT INTO public.profiles (
      id,
      full_name,
      email
    ) VALUES (
      v_user_id,
      'FTC',
      'FTC@system.local'
    );

    -- Create member record
    INSERT INTO public.members (
      user_id,
      member_number,
      full_name,
      position,
      date_of_birth
    ) VALUES (
      v_user_id,
      'FTC',
      'FTC',
      'Owner',
      '2018-10-04'
    );

    -- Assign owner role
    INSERT INTO public.user_roles (
      user_id,
      role
    ) VALUES (
      v_user_id,
      'owner'
    );

    RAISE NOTICE 'FTC superuser account created successfully';
  ELSE
    RAISE NOTICE 'FTC user already exists';
  END IF;
END $$;