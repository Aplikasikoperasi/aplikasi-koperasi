-- Ensure real-time application of owner settings for first installment and installment generation
-- 1) Generate installments when application status becomes approved/disbursed
DO $$ BEGIN
IF NOT EXISTS (
  SELECT 1 FROM pg_trigger WHERE tgname = 'a_generate_installments_on_status'
) THEN
  CREATE TRIGGER a_generate_installments_on_status
  AFTER UPDATE OF status ON public.credit_applications
  FOR EACH ROW
  WHEN (NEW.status IN ('approved','disbursed'))
  EXECUTE FUNCTION public.generate_installments();
END IF;
END $$;

-- 2) Apply first installment upfront on approval/disbursement if configured in app_settings
DO $$ BEGIN
IF NOT EXISTS (
  SELECT 1 FROM pg_trigger WHERE tgname = 'b_apply_first_installment_on_approval'
) THEN
  CREATE TRIGGER b_apply_first_installment_on_approval
  AFTER UPDATE OF status ON public.credit_applications
  FOR EACH ROW
  WHEN (NEW.status IN ('approved','disbursed'))
  EXECUTE FUNCTION public.apply_first_installment_on_approval();
END IF;
END $$;