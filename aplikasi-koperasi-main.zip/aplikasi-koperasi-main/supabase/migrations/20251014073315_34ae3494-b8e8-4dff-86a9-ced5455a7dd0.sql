-- Function to automatically create customer record for sales members
CREATE OR REPLACE FUNCTION public.create_customer_for_sales_member()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_has_sales_role BOOLEAN;
BEGIN
  -- Check if the member's user has sales role
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = NEW.user_id AND role = 'sales'::app_role
  ) INTO user_has_sales_role;
  
  -- If user has sales role, create customer record
  IF user_has_sales_role THEN
    -- Check if customer doesn't already exist for this member
    IF NOT EXISTS (
      SELECT 1
      FROM public.customers
      WHERE created_by = NEW.id OR (nik IS NOT NULL AND nik = NEW.nik)
    ) THEN
      -- Get next customer ID number
      DECLARE
        next_id_number TEXT;
        customer_count INTEGER;
      BEGIN
        SELECT COUNT(*) INTO customer_count FROM public.customers;
        next_id_number := LPAD((customer_count + 1)::TEXT, 4, '0');
        
        -- Insert customer record with member's data
        INSERT INTO public.customers (
          id_number,
          full_name,
          nik,
          date_of_birth,
          phone,
          address,
          occupation,
          photo_url,
          created_by
        ) VALUES (
          next_id_number,
          NEW.full_name,
          NEW.nik,
          NEW.date_of_birth,
          NEW.phone,
          NEW.address,
          NEW.occupation,
          NEW.photo_url,
          NEW.id  -- The member who is also a customer
        );
      END;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger on members table to auto-create customer for sales
CREATE TRIGGER auto_create_customer_for_sales
AFTER INSERT OR UPDATE ON public.members
FOR EACH ROW
EXECUTE FUNCTION public.create_customer_for_sales_member();

-- Function to create customer when sales role is assigned to existing member
CREATE OR REPLACE FUNCTION public.create_customer_on_sales_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  member_record RECORD;
BEGIN
  -- Only proceed if the new role is 'sales'
  IF NEW.role = 'sales'::app_role THEN
    -- Get member record for this user
    SELECT * INTO member_record
    FROM public.members
    WHERE user_id = NEW.user_id
    LIMIT 1;
    
    -- If member exists, create customer record
    IF FOUND THEN
      -- Check if customer doesn't already exist
      IF NOT EXISTS (
        SELECT 1
        FROM public.customers
        WHERE created_by = member_record.id OR (nik IS NOT NULL AND nik = member_record.nik)
      ) THEN
        DECLARE
          next_id_number TEXT;
          customer_count INTEGER;
        BEGIN
          SELECT COUNT(*) INTO customer_count FROM public.customers;
          next_id_number := LPAD((customer_count + 1)::TEXT, 4, '0');
          
          -- Insert customer record
          INSERT INTO public.customers (
            id_number,
            full_name,
            nik,
            date_of_birth,
            phone,
            address,
            occupation,
            photo_url,
            created_by
          ) VALUES (
            next_id_number,
            member_record.full_name,
            member_record.nik,
            member_record.date_of_birth,
            member_record.phone,
            member_record.address,
            member_record.occupation,
            member_record.photo_url,
            member_record.id
          );
        END;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger on user_roles table to auto-create customer when sales role is assigned
CREATE TRIGGER auto_create_customer_on_sales_role
AFTER INSERT ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.create_customer_on_sales_role();