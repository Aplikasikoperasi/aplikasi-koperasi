-- Add UPDATE policy for payments table to allow staff (owner, admin, sales) to edit payments
CREATE POLICY "All staff can update payments" 
ON public.payments 
FOR UPDATE 
TO public
USING (
  has_role_text(auth.uid(), 'owner'::text) OR 
  has_role_text(auth.uid(), 'admin'::text) OR 
  has_role_text(auth.uid(), 'sales'::text)
);