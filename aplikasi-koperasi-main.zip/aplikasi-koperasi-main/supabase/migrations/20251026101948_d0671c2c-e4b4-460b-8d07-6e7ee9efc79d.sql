-- Drop existing delete policy for credit_applications
DROP POLICY IF EXISTS "Owners can delete applications" ON credit_applications;

-- Create new delete policy that allows both owner and admin
CREATE POLICY "Owner and admin can delete applications"
ON credit_applications
FOR DELETE
USING (
  has_role_text(auth.uid(), 'owner'::text) OR 
  has_role_text(auth.uid(), 'admin'::text)
);