-- Drop existing delete policy for members
DROP POLICY IF EXISTS "Owners can delete members" ON public.members;

-- Create new policy allowing both owner and admin to delete
CREATE POLICY "Owner and Admin can delete members"
ON public.members
FOR DELETE
USING (
  has_role(auth.uid(), 'owner'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role)
);