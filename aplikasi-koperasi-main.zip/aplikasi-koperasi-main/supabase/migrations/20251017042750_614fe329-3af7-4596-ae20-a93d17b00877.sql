-- Fix duplicate key on re-blocking by using UPSERT in block_customer
CREATE OR REPLACE FUNCTION public.block_customer(p_customer_id uuid, p_reason text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_restoration_status text;
  v_user_id uuid := auth.uid();
  v_final_reason text;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
  END IF;

  -- Role check
  IF NOT (
    public.has_role(v_user_id, 'owner') OR 
    public.has_role(v_user_id, 'admin') OR 
    public.has_role(v_user_id, 'sales')
  ) THEN
    RETURN jsonb_build_object('success', false, 'message', 'Akses ditolak');
  END IF;

  -- Get customer info
  SELECT restoration_status INTO v_restoration_status
  FROM customers
  WHERE id = p_customer_id;

  IF v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Nasabah berstatus blokir permanen');
  END IF;

  -- Set reason based on restoration status
  v_final_reason := COALESCE(p_reason, 'Diblokir oleh staf');
  
  -- If customer was restored once and being blocked again, make it permanent
  IF v_restoration_status = 'restored_once' THEN
    v_final_reason := 'BLOKIR PERMANEN - Nasabah diblokir kembali setelah pemulihan sebelumnya. ' || v_final_reason;
    
    -- Update customer to permanently blocked
    UPDATE customers
    SET 
      restoration_status = 'permanently_blocked',
      credit_score = 0
    WHERE id = p_customer_id;
  END IF;

  -- Upsert to avoid duplicate key errors on concurrent/block-again actions
  INSERT INTO public.blocked_customers (
    customer_id,
    blocked_reason,
    blocked_by,
    consecutive_missed_months
  ) VALUES (
    p_customer_id,
    v_final_reason,
    v_user_id,
    0
  )
  ON CONFLICT (customer_id) DO UPDATE
  SET 
    blocked_reason = EXCLUDED.blocked_reason,
    blocked_by = EXCLUDED.blocked_by,
    blocked_at = now(),
    consecutive_missed_months = 0;

  RETURN jsonb_build_object('success', true, 'message', 'Nasabah berhasil diblokir');
END;
$function$;