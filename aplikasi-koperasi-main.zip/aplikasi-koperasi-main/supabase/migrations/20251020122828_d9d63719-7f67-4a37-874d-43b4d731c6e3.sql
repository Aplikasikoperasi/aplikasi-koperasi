-- Update can_apply_for_credit to also block when there's an existing pending application for the same customer
CREATE OR REPLACE FUNCTION public.can_apply_for_credit(check_nik text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
  v_customer_id uuid;
  v_has_active_credit boolean;
  v_has_unpaid_installments boolean;
  v_has_pending boolean;
  v_credit_score numeric;
  v_restoration_status text;
  v_is_currently_blocked boolean;
BEGIN
  -- Cek apakah NIK ini pernah diblokir permanen (cek di customers yang masih ada)
  SELECT id, credit_score, restoration_status INTO v_customer_id, v_credit_score, v_restoration_status
  FROM public.customers
  WHERE nik = check_nik
  LIMIT 1;
  
  -- Jika customer ditemukan dan statusnya permanently_blocked
  IF v_customer_id IS NOT NULL AND v_restoration_status = 'permanently_blocked' THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'permanently_blocked',
      'message', 'NIK ini telah diblokir permanen dan tidak dapat mengajukan kredit',
      'credit_score', 0
    );
  END IF;
  
  -- Cek apakah NIK ini sedang dalam daftar blokir
  SELECT EXISTS (
    SELECT 1
    FROM public.blocked_customers bc
    JOIN public.customers c ON bc.customer_id = c.id
    WHERE c.nik = check_nik
  ) INTO v_is_currently_blocked;
  
  IF v_is_currently_blocked THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'currently_blocked',
      'message', 'Nasabah sedang dalam status diblokir',
      'credit_score', COALESCE(v_credit_score, 0)
    );
  END IF;
  
  -- If customer not found, they can apply (new customer will get default 5 stars)
  IF v_customer_id IS NULL THEN
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'new_customer',
      'credit_score', 5
    );
  END IF;

  -- New check: block if there is any PENDING application for this customer
  SELECT EXISTS (
    SELECT 1
    FROM public.credit_applications ca
    WHERE ca.customer_id = v_customer_id
      AND ca.status = 'pending'
  ) INTO v_has_pending;

  IF v_has_pending THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'pending_application_exists',
      'message', 'Masih ada pengajuan kredit yang belum diproses untuk nasabah ini'
    );
  END IF;
  
  -- Check if customer has active credit (approved or disbursed) with unpaid installments
  SELECT EXISTS (
    SELECT 1
    FROM public.credit_applications ca
    WHERE ca.customer_id = v_customer_id
    AND ca.status IN ('approved', 'disbursed')
    -- Only include applications that have at least one unpaid installment
    AND EXISTS (
      SELECT 1 FROM public.installments i
      WHERE i.application_id = ca.id
      AND i.status != 'paid'
      AND i.principal_paid = false
    )
  ) INTO v_has_active_credit;
  
  -- Check if customer has any unpaid principal
  SELECT EXISTS (
    SELECT 1
    FROM public.installments i
    JOIN public.credit_applications ca ON ca.id = i.application_id
    WHERE ca.customer_id = v_customer_id
    AND i.principal_paid = false
    AND (i.status = 'unpaid' OR i.status = 'overdue' OR i.status = 'partial')
  ) INTO v_has_unpaid_installments;
  
  -- Customer can apply if:
  -- 1. No active credit with unpaid principal
  -- 2. No unpaid principal installments
  -- 3. Credit score >= 3.5 (CHANGED from 3)
  IF v_has_active_credit THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'active_credit_exists',
      'message', 'Nasabah masih memiliki kredit aktif yang pokoknya belum lunas',
      'credit_score', v_credit_score
    );
  ELSIF v_has_unpaid_installments THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'unpaid_installments',
      'message', 'Nasabah memiliki angsuran pokok yang belum dilunasi',
      'credit_score', v_credit_score
    );
  ELSIF v_credit_score < 3.5 THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'low_credit_score',
      'message', 'Skor kredit nasabah terlalu rendah (minimum 3.5 bintang)',
      'credit_score', v_credit_score
    );
  ELSE
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'eligible',
      'credit_score', v_credit_score
    );
  END IF;
END;
$function$