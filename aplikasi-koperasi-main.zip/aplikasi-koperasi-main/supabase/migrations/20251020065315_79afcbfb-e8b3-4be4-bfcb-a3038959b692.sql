-- Add login_email column to map username(ID)->internal auth email
ALTER TABLE public.customers
  ADD COLUMN IF NOT EXISTS login_email text;

-- Backfill existing rows with default mapping if empty
UPDATE public.customers
SET login_email = id_number || '@customer.local'
WHERE login_email IS NULL;