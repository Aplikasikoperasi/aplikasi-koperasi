-- Ensure credit score is updated whenever installments change
-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS trigger_update_credit_score_on_installment_change ON installments;
DROP TRIGGER IF EXISTS trigger_recalculate_credit_score_on_payment ON payments;

-- Create comprehensive trigger function for installment changes
CREATE OR REPLACE FUNCTION public.trigger_update_credit_score_on_installment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_customer_id uuid;
  v_new_score numeric;
BEGIN
  -- Get customer_id from the application
  SELECT customer_id INTO v_customer_id
  FROM credit_applications
  WHERE id = COALESCE(NEW.application_id, OLD.application_id);
  
  IF v_customer_id IS NOT NULL THEN
    -- Calculate new credit score
    v_new_score := calculate_credit_score(v_customer_id);
    
    -- Update customer record
    UPDATE customers
    SET credit_score = v_new_score
    WHERE id = v_customer_id;
    
    -- Log the update
    RAISE NOTICE 'Credit score updated for customer %: %', v_customer_id, v_new_score;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create trigger on installments for INSERT, UPDATE, DELETE
CREATE TRIGGER trigger_update_credit_score_on_installment_change
AFTER INSERT OR UPDATE OR DELETE ON installments
FOR EACH ROW
EXECUTE FUNCTION trigger_update_credit_score_on_installment();

-- Also update when payments are made
CREATE TRIGGER trigger_recalculate_credit_score_on_payment
AFTER INSERT OR UPDATE ON payments
FOR EACH ROW
EXECUTE FUNCTION trigger_update_credit_score_on_installment();

-- Add comment for documentation
COMMENT ON TRIGGER trigger_update_credit_score_on_installment_change ON installments IS 
'Automatically recalculates customer credit score whenever installment data changes (insert, update, or delete)';

COMMENT ON TRIGGER trigger_recalculate_credit_score_on_payment ON payments IS 
'Automatically recalculates customer credit score whenever a payment is recorded';

-- Force recalculate all customer credit scores now
DO $$
DECLARE
  customer_record RECORD;
  v_new_score numeric;
BEGIN
  FOR customer_record IN 
    SELECT DISTINCT id FROM customers WHERE status = 'approved'
  LOOP
    v_new_score := calculate_credit_score(customer_record.id);
    UPDATE customers SET credit_score = v_new_score WHERE id = customer_record.id;
    RAISE NOTICE 'Recalculated credit score for customer %: %', customer_record.id, v_new_score;
  END LOOP;
END $$;