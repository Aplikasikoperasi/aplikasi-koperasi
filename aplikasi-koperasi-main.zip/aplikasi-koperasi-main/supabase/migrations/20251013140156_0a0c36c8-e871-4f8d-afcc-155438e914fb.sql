-- Add address column to members table
ALTER TABLE public.members
ADD COLUMN address TEXT;