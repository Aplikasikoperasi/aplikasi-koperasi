-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Only owner can view settings" ON public.app_settings;
DROP POLICY IF EXISTS "Only owner can insert settings" ON public.app_settings;
DROP POLICY IF EXISTS "Only owner can update settings" ON public.app_settings;

-- Add system settings table for interest and penalty configuration
CREATE TABLE IF NOT EXISTS public.app_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  interest_type TEXT NOT NULL DEFAULT 'flat' CHECK (interest_type IN ('flat', 'tiered', 'custom')),
  flat_interest_rate NUMERIC DEFAULT 4.0,
  max_tenor_months INTEGER DEFAULT 24,
  penalty_rate_per_day NUMERIC DEFAULT 2.0,
  custom_rates JSONB DEFAULT '[]'::jsonb,
  proxy_enabled BOOLEAN DEFAULT false,
  proxy_host TEXT,
  proxy_port INTEGER,
  proxy_username TEXT,
  proxy_password TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only owner can view settings" ON public.app_settings
  FOR SELECT USING (has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "Only owner can insert settings" ON public.app_settings
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "Only owner can update settings" ON public.app_settings
  FOR UPDATE USING (has_role(auth.uid(), 'owner'::app_role));

-- Add columns to installments for tracking frozen penalties
ALTER TABLE public.installments 
ADD COLUMN IF NOT EXISTS frozen_penalty NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS principal_paid BOOLEAN DEFAULT false;

-- Function to get interest rate based on settings
CREATE OR REPLACE FUNCTION public.get_interest_rate(p_tenor_months INTEGER)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_settings RECORD;
  v_custom_rate JSONB;
BEGIN
  SELECT * INTO v_settings FROM app_settings LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN 4.0;
  END IF;
  
  CASE v_settings.interest_type
    WHEN 'flat' THEN
      RETURN v_settings.flat_interest_rate;
    
    WHEN 'tiered' THEN
      IF p_tenor_months = 1 THEN RETURN 10.0;
      ELSIF p_tenor_months = 2 THEN RETURN 7.0;
      ELSIF p_tenor_months = 3 THEN RETURN 6.0;
      ELSIF p_tenor_months IN (4, 5) THEN RETURN 5.0;
      ELSE RETURN 4.0;
      END IF;
    
    WHEN 'custom' THEN
      FOR v_custom_rate IN SELECT * FROM jsonb_array_elements(v_settings.custom_rates)
      LOOP
        IF (v_custom_rate->>'tenor')::INTEGER = p_tenor_months THEN
          RETURN (v_custom_rate->>'rate')::NUMERIC;
        END IF;
      END LOOP;
      RETURN 4.0;
    
    ELSE RETURN 4.0;
  END CASE;
END;
$$;

-- Update generate_installments to use dynamic interest rate
CREATE OR REPLACE FUNCTION public.generate_installments()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_monthly_payment NUMERIC;
  v_principal_portion NUMERIC;
  v_interest_portion NUMERIC;
  v_monthly_interest_rate NUMERIC;
  v_due_date DATE;
  i INTEGER;
BEGIN
  IF (NEW.status IN ('approved', 'disbursed')) AND 
     (OLD.status IS NULL OR OLD.status NOT IN ('approved', 'disbursed')) THEN
    IF EXISTS (SELECT 1 FROM installments WHERE application_id = NEW.id) THEN
      RETURN NEW;
    END IF;

    v_monthly_interest_rate := get_interest_rate(NEW.tenor_months) / 100;
    v_principal_portion := NEW.amount_approved / NEW.tenor_months;
    v_interest_portion := NEW.amount_approved * v_monthly_interest_rate;
    v_monthly_payment := v_principal_portion + v_interest_portion;

    FOR i IN 1..NEW.tenor_months LOOP
      v_due_date := (COALESCE(NEW.disbursed_at, NEW.approved_at, NEW.application_date)::DATE + (i || ' months')::INTERVAL)::DATE;

      INSERT INTO installments (
        application_id, installment_number, due_date, principal_amount, interest_amount, 
        total_amount, paid_amount, frozen_penalty, principal_paid, status
      ) VALUES (
        NEW.id, i, v_due_date, v_principal_portion, v_interest_portion, 
        v_monthly_payment, 0, 0, false, 'unpaid'
      );
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

-- Function to calculate current penalty
CREATE OR REPLACE FUNCTION public.calculate_current_penalty(p_installment_id UUID)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_installment RECORD;
  v_days_overdue INTEGER;
  v_penalty_rate NUMERIC;
BEGIN
  SELECT i.*, COALESCE(s.penalty_rate_per_day, 2.0) as penalty_rate
  INTO v_installment
  FROM installments i
  LEFT JOIN app_settings s ON true
  WHERE i.id = p_installment_id
  LIMIT 1;
  
  IF NOT FOUND OR v_installment.principal_paid THEN
    RETURN 0;
  END IF;
  
  v_days_overdue := GREATEST(0, CURRENT_DATE - v_installment.due_date);
  
  IF v_days_overdue > 0 THEN
    RETURN v_installment.total_amount * (v_installment.penalty_rate / 100) * v_days_overdue;
  END IF;
  
  RETURN 0;
END;
$$;