-- Ensure created_by column exists and is uuid
ALTER TABLE public.customers
  ADD COLUMN IF NOT EXISTS created_by uuid;

-- Drop any conflicting/legacy constraints
ALTER TABLE public.customers DROP CONSTRAINT IF EXISTS customers_created_by_fkey;
ALTER TABLE public.customers DROP CONSTRAINT IF EXISTS custumers_created_by_fkey;

-- Recreate proper foreign key to members(id)
ALTER TABLE public.customers
  ADD CONSTRAINT customers_created_by_members_id_fkey
  FOREIGN KEY (created_by) REFERENCES public.members(id)
  ON DELETE SET NULL;

-- Helpful index for lookups
CREATE INDEX IF NOT EXISTS idx_customers_created_by ON public.customers(created_by);