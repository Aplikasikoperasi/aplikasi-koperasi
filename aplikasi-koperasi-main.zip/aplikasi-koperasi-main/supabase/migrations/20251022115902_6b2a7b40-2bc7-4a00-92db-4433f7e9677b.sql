-- Recreate RLS policies that reference app_role to fix broken type OIDs

-- app_settings
DROP POLICY IF EXISTS "Only owner can insert settings" ON public.app_settings;
DROP POLICY IF EXISTS "Only owner can update settings" ON public.app_settings;
DROP POLICY IF EXISTS "Owner and admin can view settings" ON public.app_settings;
CREATE POLICY "Only owner can insert settings"
ON public.app_settings
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role));
CREATE POLICY "Only owner can update settings"
ON public.app_settings
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role));
CREATE POLICY "Owner and admin can view settings"
ON public.app_settings
FOR SELECT
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));

-- auto_backup_settings
DROP POLICY IF EXISTS "Owner and admin can view backup settings" ON public.auto_backup_settings;
DROP POLICY IF EXISTS "Owner can manage backup settings" ON public.auto_backup_settings;
CREATE POLICY "Owner and admin can view backup settings"
ON public.auto_backup_settings
FOR SELECT
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Owner can manage backup settings"
ON public.auto_backup_settings
FOR ALL
USING (has_role(auth.uid(), 'owner'::app_role));

-- blocked_customers
DROP POLICY IF EXISTS "Owner and admin can update blocked customers" ON public.blocked_customers;
DROP POLICY IF EXISTS "All staff can insert blocked customers" ON public.blocked_customers;
DROP POLICY IF EXISTS "Only owner can delete blocked customers" ON public.blocked_customers;
CREATE POLICY "Owner and admin can update blocked customers"
ON public.blocked_customers
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "All staff can insert blocked customers"
ON public.blocked_customers
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "Only owner can delete blocked customers"
ON public.blocked_customers
FOR DELETE
USING (has_role(auth.uid(), 'owner'::app_role));

-- credit_applications
DROP POLICY IF EXISTS "All staff can insert applications" ON public.credit_applications;
DROP POLICY IF EXISTS "All staff can update applications" ON public.credit_applications;
DROP POLICY IF EXISTS "Owners can delete applications" ON public.credit_applications;
CREATE POLICY "All staff can insert applications"
ON public.credit_applications
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "All staff can update applications"
ON public.credit_applications
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "Owners can delete applications"
ON public.credit_applications
FOR DELETE
USING (has_role(auth.uid(), 'owner'::app_role));

-- customer_change_requests
DROP POLICY IF EXISTS "All staff can insert change requests" ON public.customer_change_requests;
DROP POLICY IF EXISTS "Owner and admin can update change requests" ON public.customer_change_requests;
CREATE POLICY "All staff can insert change requests"
ON public.customer_change_requests
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "Owner and admin can update change requests"
ON public.customer_change_requests
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));

-- customer_messages
DROP POLICY IF EXISTS "Staff can insert customer messages" ON public.customer_messages;
CREATE POLICY "Staff can insert customer messages"
ON public.customer_messages
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));

-- customers
DROP POLICY IF EXISTS "All staff can insert customers" ON public.customers;
DROP POLICY IF EXISTS "All staff can update customers" ON public.customers;
DROP POLICY IF EXISTS "Owners can delete customers" ON public.customers;
CREATE POLICY "All staff can insert customers"
ON public.customers
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "All staff can update customers"
ON public.customers
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "Owners can delete customers"
ON public.customers
FOR DELETE
USING (has_role(auth.uid(), 'owner'::app_role));

-- financial_reports
DROP POLICY IF EXISTS "Owner can manage financial reports" ON public.financial_reports;
CREATE POLICY "Owner can manage financial reports"
ON public.financial_reports
FOR ALL
USING (has_role(auth.uid(), 'owner'::app_role));

-- installments
DROP POLICY IF EXISTS "All staff can manage installments" ON public.installments;
CREATE POLICY "All staff can manage installments"
ON public.installments
FOR ALL
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));

-- members
DROP POLICY IF EXISTS "Owner and Admin can update members" ON public.members;
DROP POLICY IF EXISTS "All staff can insert members" ON public.members;
DROP POLICY IF EXISTS "Owner and Admin can delete members" ON public.members;
CREATE POLICY "Owner and Admin can update members"
ON public.members
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "All staff can insert members"
ON public.members
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));
CREATE POLICY "Owner and Admin can delete members"
ON public.members
FOR DELETE
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));

-- payments
DROP POLICY IF EXISTS "All staff can insert payments" ON public.payments;
CREATE POLICY "All staff can insert payments"
ON public.payments
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'sales'::app_role));

-- profiles
DROP POLICY IF EXISTS "Owner can update profiles" ON public.profiles;
CREATE POLICY "Owner can update profiles"
ON public.profiles
FOR UPDATE
USING (has_role(auth.uid(), 'owner'::app_role));

-- system_logs
DROP POLICY IF EXISTS "Owner and admin can view logs" ON public.system_logs;
CREATE POLICY "Owner and admin can view logs"
ON public.system_logs
FOR SELECT
USING (has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role));