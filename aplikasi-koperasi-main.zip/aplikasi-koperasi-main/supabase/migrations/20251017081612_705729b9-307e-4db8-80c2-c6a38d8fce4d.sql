-- Remove super_code column and update RPC to exclude it
BEGIN;

-- 1) Update RPC: remove super_code from the returned JSON
CREATE OR REPLACE FUNCTION public.get_public_app_settings()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT to_jsonb(s)
  FROM (
    SELECT 
      first_installment_type,
      admin_fee_enabled,
      admin_fee_amount,
      max_tenor_months,
      interest_type,
      flat_interest_rate,
      penalty_rate_per_day,
      custom_rates
    FROM app_settings
    ORDER BY updated_at DESC NULLS LAST, created_at DESC
    LIMIT 1
  ) s
$function$;

-- 2) Drop the column from app_settings
ALTER TABLE public.app_settings
  DROP COLUMN IF EXISTS super_code;

COMMIT;