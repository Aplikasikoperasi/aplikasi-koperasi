-- Permanent auth rules for customers & members
-- 1) Ensure customer auth is auto-created on insert (uses existing function)
DROP TRIGGER IF EXISTS trg_auto_create_customer_auth ON public.customers;
CREATE TRIGGER trg_auto_create_customer_auth
BEFORE INSERT ON public.customers
FOR EACH ROW
EXECUTE FUNCTION public.auto_create_customer_auth();

-- 2) Auto-update customer password when date_of_birth changes
CREATE OR REPLACE FUNCTION public.update_customer_password_on_dob_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_day TEXT;
  v_month TEXT;
  v_year TEXT;
  v_password TEXT;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.date_of_birth IS DISTINCT FROM OLD.date_of_birth THEN
    IF NEW.date_of_birth IS NULL THEN
      RETURN NEW;
    END IF;

    v_day := LPAD(EXTRACT(DAY FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_month := LPAD(EXTRACT(MONTH FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_year := EXTRACT(YEAR FROM NEW.date_of_birth)::TEXT;
    v_password := v_day || v_month || v_year;

    IF NEW.user_id IS NOT NULL THEN
      UPDATE auth.users
      SET encrypted_password = crypt(v_password, gen_salt('bf')),
          updated_at = NOW()
      WHERE id = NEW.user_id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_update_customer_password_on_dob_change ON public.customers;
CREATE TRIGGER trg_update_customer_password_on_dob_change
BEFORE UPDATE OF date_of_birth ON public.customers
FOR EACH ROW
EXECUTE FUNCTION public.update_customer_password_on_dob_change();

-- 3) Auto-create & sync member auth on insert/update
CREATE OR REPLACE FUNCTION public.auto_sync_member_auth()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_email TEXT;
  v_password TEXT;
  v_day TEXT;
  v_month TEXT;
  v_year TEXT;
  v_auth_user_id UUID;
  v_role app_role := 'sales';
BEGIN
  -- Determine role from position
  IF NEW.position IS NOT NULL THEN
    IF LOWER(NEW.position) = 'owner' THEN
      v_role := 'owner'::app_role;
    ELSIF LOWER(NEW.position) = 'admin' THEN
      v_role := 'admin'::app_role;
    ELSE
      v_role := 'sales'::app_role;
    END IF;
  END IF;

  -- Email from full_name
  IF NEW.full_name IS NOT NULL THEN
    v_email := LOWER(REGEXP_REPLACE(NEW.full_name, '\\s+', '', 'g')) || '@system.local';
  END IF;

  -- Password from DOB
  IF NEW.date_of_birth IS NOT NULL THEN
    v_day := LPAD(EXTRACT(DAY FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_month := LPAD(EXTRACT(MONTH FROM NEW.date_of_birth)::TEXT, 2, '0');
    v_year := EXTRACT(YEAR FROM NEW.date_of_birth)::TEXT;
    v_password := v_day || v_month || v_year;
  END IF;

  IF TG_OP = 'INSERT' THEN
    IF NEW.user_id IS NULL AND v_email IS NOT NULL AND NEW.date_of_birth IS NOT NULL THEN
      BEGIN
        INSERT INTO auth.users (
          instance_id,
          id,
          aud,
          role,
          email,
          encrypted_password,
          email_confirmed_at,
          raw_user_meta_data,
          created_at,
          updated_at,
          confirmation_token,
          recovery_token
        ) VALUES (
          '00000000-0000-0000-0000-000000000000',
          gen_random_uuid(),
          'authenticated',
          'authenticated',
          v_email,
          crypt(v_password, gen_salt('bf')),
          NOW(),
          jsonb_build_object('full_name', NEW.full_name, 'is_member', true),
          NOW(),
          NOW(),
          '',
          ''
        )
        RETURNING id INTO v_auth_user_id;

        NEW.user_id := v_auth_user_id;

        -- Ensure profile
        INSERT INTO public.profiles (id, full_name, email)
        VALUES (v_auth_user_id, NEW.full_name, v_email)
        ON CONFLICT (id) DO UPDATE
          SET full_name = EXCLUDED.full_name,
              email = EXCLUDED.email;

        -- Ensure role
        INSERT INTO public.user_roles (user_id, role)
        VALUES (v_auth_user_id, v_role)
        ON CONFLICT (user_id, role) DO NOTHING;

      EXCEPTION WHEN OTHERS THEN
        SELECT id INTO v_auth_user_id FROM auth.users WHERE email = v_email LIMIT 1;

        IF v_auth_user_id IS NOT NULL THEN
          NEW.user_id := v_auth_user_id;

          UPDATE auth.users
          SET encrypted_password = crypt(v_password, gen_salt('bf')),
              updated_at = NOW()
          WHERE id = v_auth_user_id;

          INSERT INTO public.profiles (id, full_name, email)
          VALUES (v_auth_user_id, NEW.full_name, v_email)
          ON CONFLICT (id) DO UPDATE
            SET full_name = EXCLUDED.full_name,
                email = EXCLUDED.email;

          INSERT INTO public.user_roles (user_id, role)
          VALUES (v_auth_user_id, v_role)
          ON CONFLICT (user_id, role) DO NOTHING;
        END IF;
      END;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.user_id IS NOT NULL AND NEW.date_of_birth IS DISTINCT FROM OLD.date_of_birth AND NEW.date_of_birth IS NOT NULL THEN
      UPDATE auth.users
      SET encrypted_password = crypt(v_password, gen_salt('bf')),
          updated_at = NOW()
      WHERE id = NEW.user_id;
    END IF;

    -- Ensure role exists (position may have changed)
    IF NEW.user_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role)
      VALUES (NEW.user_id, v_role)
      ON CONFLICT (user_id, role) DO NOTHING;
    END IF;

    -- Keep profile in sync
    IF NEW.user_id IS NOT NULL AND v_email IS NOT NULL THEN
      INSERT INTO public.profiles (id, full_name, email)
      VALUES (NEW.user_id, NEW.full_name, v_email)
      ON CONFLICT (id) DO UPDATE
        SET full_name = EXCLUDED.full_name,
            email = EXCLUDED.email;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_auto_sync_member_auth ON public.members;
CREATE TRIGGER trg_auto_sync_member_auth
BEFORE INSERT OR UPDATE ON public.members
FOR EACH ROW
EXECUTE FUNCTION public.auto_sync_member_auth();