-- Create function to check if customer can apply for new credit
CREATE OR REPLACE FUNCTION public.can_apply_for_credit(check_nik text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
  v_has_active_credit boolean;
  v_has_unpaid_installments boolean;
  v_credit_score integer;
BEGIN
  -- Get customer by NIK
  SELECT id, credit_score INTO v_customer_id, v_credit_score
  FROM public.customers
  WHERE nik = check_nik
  LIMIT 1;
  
  -- If customer not found, they can apply (new customer will get default 5 stars)
  IF v_customer_id IS NULL THEN
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'new_customer',
      'credit_score', 5
    );
  END IF;
  
  -- Check if customer has active credit (approved or disbursed)
  SELECT EXISTS (
    SELECT 1
    FROM public.credit_applications ca
    WHERE ca.customer_id = v_customer_id
    AND ca.status IN ('approved', 'disbursed')
    AND EXISTS (
      SELECT 1
      FROM public.installments i
      WHERE i.application_id = ca.id
      AND i.status != 'paid'
    )
  ) INTO v_has_active_credit;
  
  -- Check if customer has any unpaid installments or penalties
  SELECT EXISTS (
    SELECT 1
    FROM public.installments i
    JOIN public.credit_applications ca ON ca.id = i.application_id
    WHERE ca.customer_id = v_customer_id
    AND (i.status = 'overdue' OR (i.total_amount - i.paid_amount) > 0)
  ) INTO v_has_unpaid_installments;
  
  -- Customer can apply if:
  -- 1. No active credit
  -- 2. No unpaid installments
  -- 3. Credit score >= 3
  IF v_has_active_credit THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'active_credit_exists',
      'message', 'Nasabah masih memiliki kredit aktif yang belum lunas',
      'credit_score', v_credit_score
    );
  ELSIF v_has_unpaid_installments THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'unpaid_installments',
      'message', 'Nasabah memiliki angsuran atau denda yang belum dilunasi',
      'credit_score', v_credit_score
    );
  ELSIF v_credit_score < 3 THEN
    RETURN jsonb_build_object(
      'can_apply', false,
      'reason', 'low_credit_score',
      'message', 'Skor kredit nasabah terlalu rendah (minimum 3 bintang)',
      'credit_score', v_credit_score
    );
  ELSE
    RETURN jsonb_build_object(
      'can_apply', true,
      'reason', 'eligible',
      'credit_score', v_credit_score
    );
  END IF;
END;
$$;