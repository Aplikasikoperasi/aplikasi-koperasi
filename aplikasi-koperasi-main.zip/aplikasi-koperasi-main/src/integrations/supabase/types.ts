export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          admin_fee_amount: number | null
          admin_fee_enabled: boolean | null
          admin_fee_minimum: number | null
          auto_block_threshold: number | null
          auto_blocking_enabled: boolean | null
          badge_discount_enabled: boolean | null
          bank_account_holder: string | null
          bank_account_number: string | null
          bank_name: string | null
          created_at: string
          custom_rates: Json | null
          deposit_interest_payment_day: number | null
          deposit_interest_rate: number | null
          deposit_min_days_for_interest: number | null
          deposit_tier_gold_interest_rate: number | null
          deposit_tier_gold_min_balance: number | null
          deposit_tier_platinum_interest_rate: number | null
          deposit_tier_platinum_min_balance: number | null
          deposit_tier_silver_interest_rate: number | null
          deposit_tier_silver_min_balance: number | null
          diamond_discount: number | null
          first_installment_type: string | null
          flat_interest_rate: number | null
          gold_discount: number | null
          id: string
          interest_type: string | null
          maintenance_message: string | null
          maintenance_mode_enabled: boolean | null
          maintenance_title: string | null
          max_tenor_months: number | null
          penalty_rate_per_day: number | null
          platinum_discount: number | null
          super_code: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_fee_amount?: number | null
          admin_fee_enabled?: boolean | null
          admin_fee_minimum?: number | null
          auto_block_threshold?: number | null
          auto_blocking_enabled?: boolean | null
          badge_discount_enabled?: boolean | null
          bank_account_holder?: string | null
          bank_account_number?: string | null
          bank_name?: string | null
          created_at?: string
          custom_rates?: Json | null
          deposit_interest_payment_day?: number | null
          deposit_interest_rate?: number | null
          deposit_min_days_for_interest?: number | null
          deposit_tier_gold_interest_rate?: number | null
          deposit_tier_gold_min_balance?: number | null
          deposit_tier_platinum_interest_rate?: number | null
          deposit_tier_platinum_min_balance?: number | null
          deposit_tier_silver_interest_rate?: number | null
          deposit_tier_silver_min_balance?: number | null
          diamond_discount?: number | null
          first_installment_type?: string | null
          flat_interest_rate?: number | null
          gold_discount?: number | null
          id?: string
          interest_type?: string | null
          maintenance_message?: string | null
          maintenance_mode_enabled?: boolean | null
          maintenance_title?: string | null
          max_tenor_months?: number | null
          penalty_rate_per_day?: number | null
          platinum_discount?: number | null
          super_code?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_fee_amount?: number | null
          admin_fee_enabled?: boolean | null
          admin_fee_minimum?: number | null
          auto_block_threshold?: number | null
          auto_blocking_enabled?: boolean | null
          badge_discount_enabled?: boolean | null
          bank_account_holder?: string | null
          bank_account_number?: string | null
          bank_name?: string | null
          created_at?: string
          custom_rates?: Json | null
          deposit_interest_payment_day?: number | null
          deposit_interest_rate?: number | null
          deposit_min_days_for_interest?: number | null
          deposit_tier_gold_interest_rate?: number | null
          deposit_tier_gold_min_balance?: number | null
          deposit_tier_platinum_interest_rate?: number | null
          deposit_tier_platinum_min_balance?: number | null
          deposit_tier_silver_interest_rate?: number | null
          deposit_tier_silver_min_balance?: number | null
          diamond_discount?: number | null
          first_installment_type?: string | null
          flat_interest_rate?: number | null
          gold_discount?: number | null
          id?: string
          interest_type?: string | null
          maintenance_message?: string | null
          maintenance_mode_enabled?: boolean | null
          maintenance_title?: string | null
          max_tenor_months?: number | null
          penalty_rate_per_day?: number | null
          platinum_discount?: number | null
          super_code?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      auto_backup_settings: {
        Row: {
          created_at: string
          enabled: boolean
          id: string
          last_backup_at: string | null
          next_backup_at: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: string
          last_backup_at?: string | null
          next_backup_at?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: string
          last_backup_at?: string | null
          next_backup_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      bank_accounts: {
        Row: {
          account_holder: string
          account_number: string
          bank_name: string
          created_at: string | null
          id: string
          is_active: boolean | null
          is_primary: boolean | null
          updated_at: string | null
        }
        Insert: {
          account_holder: string
          account_number: string
          bank_name: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          is_primary?: boolean | null
          updated_at?: string | null
        }
        Update: {
          account_holder?: string
          account_number?: string
          bank_name?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          is_primary?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      banners: {
        Row: {
          created_at: string
          display_order: number
          id: string
          image_url: string
          is_active: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          id?: string
          image_url: string
          is_active?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          image_url?: string
          is_active?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      block_history: {
        Row: {
          blocked_at: string
          blocked_by: string | null
          customer_id: string
          customer_nik: string | null
          id: string
          reason: string | null
        }
        Insert: {
          blocked_at?: string
          blocked_by?: string | null
          customer_id: string
          customer_nik?: string | null
          id?: string
          reason?: string | null
        }
        Update: {
          blocked_at?: string
          blocked_by?: string | null
          customer_id?: string
          customer_nik?: string | null
          id?: string
          reason?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "block_history_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      blocked_customers: {
        Row: {
          application_id: string | null
          blocked_at: string
          blocked_by: string | null
          blocked_reason: string
          consecutive_missed_months: number
          created_at: string
          customer_id: string
          id: string
          is_auto_block: boolean
          updated_at: string
        }
        Insert: {
          application_id?: string | null
          blocked_at?: string
          blocked_by?: string | null
          blocked_reason?: string
          consecutive_missed_months?: number
          created_at?: string
          customer_id: string
          id?: string
          is_auto_block?: boolean
          updated_at?: string
        }
        Update: {
          application_id?: string | null
          blocked_at?: string
          blocked_by?: string | null
          blocked_reason?: string
          consecutive_missed_months?: number
          created_at?: string
          customer_id?: string
          id?: string
          is_auto_block?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "blocked_customers_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "credit_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blocked_customers_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: true
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_applications: {
        Row: {
          admin_fee_amount: number | null
          amount_approved: number | null
          amount_requested: number
          application_date: string
          application_number: string
          approved_at: string | null
          approved_by: string | null
          collateral_description: string | null
          created_at: string
          custom_rates_snapshot: Json | null
          customer_id: string
          disbursed_at: string | null
          discount_applied: number | null
          discount_badge_level: string | null
          first_installment_type: string | null
          flat_interest_rate_snapshot: number | null
          id: string
          interest_rate: number
          interest_type_snapshot: string | null
          member_id: string | null
          original_interest_rate: number | null
          penalty_rate_per_day: number | null
          purpose: string
          status: string
          tenor_months: number
          updated_at: string
        }
        Insert: {
          admin_fee_amount?: number | null
          amount_approved?: number | null
          amount_requested: number
          application_date?: string
          application_number: string
          approved_at?: string | null
          approved_by?: string | null
          collateral_description?: string | null
          created_at?: string
          custom_rates_snapshot?: Json | null
          customer_id: string
          disbursed_at?: string | null
          discount_applied?: number | null
          discount_badge_level?: string | null
          first_installment_type?: string | null
          flat_interest_rate_snapshot?: number | null
          id?: string
          interest_rate: number
          interest_type_snapshot?: string | null
          member_id?: string | null
          original_interest_rate?: number | null
          penalty_rate_per_day?: number | null
          purpose: string
          status?: string
          tenor_months: number
          updated_at?: string
        }
        Update: {
          admin_fee_amount?: number | null
          amount_approved?: number | null
          amount_requested?: number
          application_date?: string
          application_number?: string
          approved_at?: string | null
          approved_by?: string | null
          collateral_description?: string | null
          created_at?: string
          custom_rates_snapshot?: Json | null
          customer_id?: string
          disbursed_at?: string | null
          discount_applied?: number | null
          discount_badge_level?: string | null
          first_installment_type?: string | null
          flat_interest_rate_snapshot?: number | null
          id?: string
          interest_rate?: number
          interest_type_snapshot?: string | null
          member_id?: string | null
          original_interest_rate?: number | null
          penalty_rate_per_day?: number | null
          purpose?: string
          status?: string
          tenor_months?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_applications_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_applications_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_change_requests: {
        Row: {
          created_at: string
          customer_id: string
          id: string
          new_data: Json
          notes: string | null
          old_data: Json
          requested_by: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          id?: string
          new_data: Json
          notes?: string | null
          old_data: Json
          requested_by: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          id?: string
          new_data?: Json
          notes?: string | null
          old_data?: Json
          requested_by?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_change_requests_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_messages: {
        Row: {
          created_at: string
          customer_id: string
          id: string
          is_read: boolean
          message: string
          metadata: Json | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          id?: string
          is_read?: boolean
          message: string
          metadata?: Json | null
          title: string
          type?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          id?: string
          is_read?: boolean
          message?: string
          metadata?: Json | null
          title?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_messages_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_restoration_requests: {
        Row: {
          created_at: string
          customer_id: string
          id: string
          notes: string | null
          rejection_reason: string | null
          requested_at: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          id?: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          id?: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_restoration_requests_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "customer_restoration_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          address: string
          approved_at: string | null
          approved_by: string | null
          baseline_credit_score: number | null
          created_at: string
          created_by: string | null
          credit_score: number | null
          date_of_birth: string | null
          email: string | null
          full_name: string
          id: string
          id_number: string
          login_email: string | null
          monitored_ontime_streak: number | null
          monitored_since: string | null
          monthly_income: number | null
          nik: string | null
          no_kk: string | null
          occupation: string | null
          phone: string
          photo_url: string | null
          restoration_status: string | null
          status: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address: string
          approved_at?: string | null
          approved_by?: string | null
          baseline_credit_score?: number | null
          created_at?: string
          created_by?: string | null
          credit_score?: number | null
          date_of_birth?: string | null
          email?: string | null
          full_name: string
          id?: string
          id_number: string
          login_email?: string | null
          monitored_ontime_streak?: number | null
          monitored_since?: string | null
          monthly_income?: number | null
          nik?: string | null
          no_kk?: string | null
          occupation?: string | null
          phone: string
          photo_url?: string | null
          restoration_status?: string | null
          status?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address?: string
          approved_at?: string | null
          approved_by?: string | null
          baseline_credit_score?: number | null
          created_at?: string
          created_by?: string | null
          credit_score?: number | null
          date_of_birth?: string | null
          email?: string | null
          full_name?: string
          id?: string
          id_number?: string
          login_email?: string | null
          monitored_ontime_streak?: number | null
          monitored_since?: string | null
          monthly_income?: number | null
          nik?: string | null
          no_kk?: string | null
          occupation?: string | null
          phone?: string
          photo_url?: string | null
          restoration_status?: string | null
          status?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customers_created_by_members_id_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      deposit_accounts: {
        Row: {
          account_holder: string
          account_number: string
          bank_name: string
          created_at: string | null
          id: string
          is_active: boolean | null
          is_primary: boolean | null
          updated_at: string | null
        }
        Insert: {
          account_holder: string
          account_number: string
          bank_name: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          is_primary?: boolean | null
          updated_at?: string | null
        }
        Update: {
          account_holder?: string
          account_number?: string
          bank_name?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          is_primary?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      expenses: {
        Row: {
          amount: number
          category: string | null
          created_at: string
          created_by: string | null
          created_by_name: string
          description: string
          expense_date: string
          id: string
          pic_id: string | null
          pic_name: string
          status: string
          updated_at: string
          verified_at: string | null
          verified_by: string | null
          verified_by_name: string | null
        }
        Insert: {
          amount: number
          category?: string | null
          created_at?: string
          created_by?: string | null
          created_by_name: string
          description: string
          expense_date: string
          id?: string
          pic_id?: string | null
          pic_name: string
          status?: string
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
          verified_by_name?: string | null
        }
        Update: {
          amount?: number
          category?: string | null
          created_at?: string
          created_by?: string | null
          created_by_name?: string
          description?: string
          expense_date?: string
          id?: string
          pic_id?: string | null
          pic_name?: string
          status?: string
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
          verified_by_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "expenses_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expenses_pic_id_fkey"
            columns: ["pic_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expenses_verified_by_fkey"
            columns: ["verified_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      financial_reports: {
        Row: {
          approved_applications: number
          generated_at: string
          generated_by: string | null
          id: string
          npl_amount: number
          npl_count: number
          period_end: string
          period_start: string
          period_type: string
          total_applications: number
          total_collected: number
          total_disbursed: number
          total_outstanding: number
        }
        Insert: {
          approved_applications?: number
          generated_at?: string
          generated_by?: string | null
          id?: string
          npl_amount?: number
          npl_count?: number
          period_end: string
          period_start: string
          period_type: string
          total_applications?: number
          total_collected?: number
          total_disbursed?: number
          total_outstanding?: number
        }
        Update: {
          approved_applications?: number
          generated_at?: string
          generated_by?: string | null
          id?: string
          npl_amount?: number
          npl_count?: number
          period_end?: string
          period_start?: string
          period_type?: string
          total_applications?: number
          total_collected?: number
          total_disbursed?: number
          total_outstanding?: number
        }
        Relationships: []
      }
      google_drive_cleanup_history: {
        Row: {
          cleanup_type: string
          created_at: string
          cutoff_date: string
          deleted_files: Json | null
          executed_by: string | null
          failed_files: Json | null
          files_deleted: number
          files_failed: number
          id: string
          retention_days: number
          total_files_checked: number
        }
        Insert: {
          cleanup_type: string
          created_at?: string
          cutoff_date: string
          deleted_files?: Json | null
          executed_by?: string | null
          failed_files?: Json | null
          files_deleted?: number
          files_failed?: number
          id?: string
          retention_days: number
          total_files_checked?: number
        }
        Update: {
          cleanup_type?: string
          created_at?: string
          cutoff_date?: string
          deleted_files?: Json | null
          executed_by?: string | null
          failed_files?: Json | null
          files_deleted?: number
          files_failed?: number
          id?: string
          retention_days?: number
          total_files_checked?: number
        }
        Relationships: []
      }
      google_drive_settings: {
        Row: {
          auth_mode: string | null
          backup_date: number | null
          backup_day: number | null
          backup_schedule: string | null
          backup_time: string | null
          client_email: string | null
          created_at: string | null
          folder_id: string | null
          id: string
          is_enabled: boolean | null
          last_backup_at: string | null
          next_backup_at: string | null
          oauth_access_token: string | null
          oauth_client_id: string | null
          oauth_client_secret: string | null
          oauth_refresh_token: string | null
          oauth_token_expiry: string | null
          oauth_user_email: string | null
          private_key: string | null
          retention_days: number | null
          updated_at: string | null
        }
        Insert: {
          auth_mode?: string | null
          backup_date?: number | null
          backup_day?: number | null
          backup_schedule?: string | null
          backup_time?: string | null
          client_email?: string | null
          created_at?: string | null
          folder_id?: string | null
          id?: string
          is_enabled?: boolean | null
          last_backup_at?: string | null
          next_backup_at?: string | null
          oauth_access_token?: string | null
          oauth_client_id?: string | null
          oauth_client_secret?: string | null
          oauth_refresh_token?: string | null
          oauth_token_expiry?: string | null
          oauth_user_email?: string | null
          private_key?: string | null
          retention_days?: number | null
          updated_at?: string | null
        }
        Update: {
          auth_mode?: string | null
          backup_date?: number | null
          backup_day?: number | null
          backup_schedule?: string | null
          backup_time?: string | null
          client_email?: string | null
          created_at?: string | null
          folder_id?: string | null
          id?: string
          is_enabled?: boolean | null
          last_backup_at?: string | null
          next_backup_at?: string | null
          oauth_access_token?: string | null
          oauth_client_id?: string | null
          oauth_client_secret?: string | null
          oauth_refresh_token?: string | null
          oauth_token_expiry?: string | null
          oauth_user_email?: string | null
          private_key?: string | null
          retention_days?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      incentive_settings: {
        Row: {
          created_at: string
          credit_application_amount: number | null
          credit_application_enabled: boolean
          credit_application_type: string | null
          holiday_amount: number | null
          holiday_enabled: boolean
          holiday_type: string | null
          id: string
          installment_payment_amount: number | null
          installment_payment_enabled: boolean
          installment_payment_type: string | null
          is_enabled: boolean
          kasir_enabled: boolean | null
          kasir_holiday_amount: number | null
          kasir_holiday_enabled: boolean | null
          kasir_holiday_type: string | null
          kasir_payment_amount: number | null
          kasir_payment_enabled: boolean | null
          kasir_payment_type: string | null
          kasir_year_end_bonus_withdrawal_date: number | null
          regular_incentive_enabled_at: string | null
          updated_at: string
          year_end_bonus_enabled_at: string | null
          year_end_bonus_withdrawal_date: number | null
        }
        Insert: {
          created_at?: string
          credit_application_amount?: number | null
          credit_application_enabled?: boolean
          credit_application_type?: string | null
          holiday_amount?: number | null
          holiday_enabled?: boolean
          holiday_type?: string | null
          id?: string
          installment_payment_amount?: number | null
          installment_payment_enabled?: boolean
          installment_payment_type?: string | null
          is_enabled?: boolean
          kasir_enabled?: boolean | null
          kasir_holiday_amount?: number | null
          kasir_holiday_enabled?: boolean | null
          kasir_holiday_type?: string | null
          kasir_payment_amount?: number | null
          kasir_payment_enabled?: boolean | null
          kasir_payment_type?: string | null
          kasir_year_end_bonus_withdrawal_date?: number | null
          regular_incentive_enabled_at?: string | null
          updated_at?: string
          year_end_bonus_enabled_at?: string | null
          year_end_bonus_withdrawal_date?: number | null
        }
        Update: {
          created_at?: string
          credit_application_amount?: number | null
          credit_application_enabled?: boolean
          credit_application_type?: string | null
          holiday_amount?: number | null
          holiday_enabled?: boolean
          holiday_type?: string | null
          id?: string
          installment_payment_amount?: number | null
          installment_payment_enabled?: boolean
          installment_payment_type?: string | null
          is_enabled?: boolean
          kasir_enabled?: boolean | null
          kasir_holiday_amount?: number | null
          kasir_holiday_enabled?: boolean | null
          kasir_holiday_type?: string | null
          kasir_payment_amount?: number | null
          kasir_payment_enabled?: boolean | null
          kasir_payment_type?: string | null
          kasir_year_end_bonus_withdrawal_date?: number | null
          regular_incentive_enabled_at?: string | null
          updated_at?: string
          year_end_bonus_enabled_at?: string | null
          year_end_bonus_withdrawal_date?: number | null
        }
        Relationships: []
      }
      installments: {
        Row: {
          application_id: string
          created_at: string
          due_date: string
          frozen_days_overdue: number | null
          frozen_penalty: number | null
          id: string
          installment_number: number
          interest_amount: number
          is_silenced: boolean
          paid_amount: number
          paid_at: string | null
          penalty_rate_per_day: number | null
          principal_amount: number
          principal_paid: boolean | null
          status: string
          total_amount: number
        }
        Insert: {
          application_id: string
          created_at?: string
          due_date: string
          frozen_days_overdue?: number | null
          frozen_penalty?: number | null
          id?: string
          installment_number: number
          interest_amount: number
          is_silenced?: boolean
          paid_amount?: number
          paid_at?: string | null
          penalty_rate_per_day?: number | null
          principal_amount: number
          principal_paid?: boolean | null
          status?: string
          total_amount: number
        }
        Update: {
          application_id?: string
          created_at?: string
          due_date?: string
          frozen_days_overdue?: number | null
          frozen_penalty?: number | null
          id?: string
          installment_number?: number
          interest_amount?: number
          is_silenced?: boolean
          paid_amount?: number
          paid_at?: string | null
          penalty_rate_per_day?: number | null
          principal_amount?: number
          principal_paid?: boolean | null
          status?: string
          total_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: "installments_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "credit_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      member_balance_transactions: {
        Row: {
          amount: number
          application_id: string | null
          balance_type: string | null
          created_at: string
          description: string
          id: string
          installment_id: string | null
          member_id: string
          payment_id: string | null
          period_month: string | null
          type: string
        }
        Insert: {
          amount: number
          application_id?: string | null
          balance_type?: string | null
          created_at?: string
          description: string
          id?: string
          installment_id?: string | null
          member_id: string
          payment_id?: string | null
          period_month?: string | null
          type: string
        }
        Update: {
          amount?: number
          application_id?: string | null
          balance_type?: string | null
          created_at?: string
          description?: string
          id?: string
          installment_id?: string | null
          member_id?: string
          payment_id?: string | null
          period_month?: string | null
          type?: string
        }
        Relationships: []
      }
      member_balance_withdrawals: {
        Row: {
          amount: number
          bank_account_info: string | null
          bonus_year: number | null
          id: string
          member_id: string
          notes: string | null
          rejection_reason: string | null
          requested_at: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          withdrawal_method: string | null
          withdrawal_type: string | null
        }
        Insert: {
          amount: number
          bank_account_info?: string | null
          bonus_year?: number | null
          id?: string
          member_id: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          withdrawal_method?: string | null
          withdrawal_type?: string | null
        }
        Update: {
          amount?: number
          bank_account_info?: string | null
          bonus_year?: number | null
          id?: string
          member_id?: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          withdrawal_method?: string | null
          withdrawal_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "member_balance_withdrawals_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      member_messages: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          member_id: string
          message: string
          metadata: Json | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          member_id: string
          message: string
          metadata?: Json | null
          title: string
          type?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          member_id?: string
          message?: string
          metadata?: Json | null
          title?: string
          type?: string
        }
        Relationships: []
      }
      member_monthly_balance_summary: {
        Row: {
          available_balance: number
          created_at: string
          hold_reason: string | null
          id: string
          is_held: boolean
          member_id: string
          period_month: string
          total_earned: number
          total_withdrawn: number
          updated_at: string
        }
        Insert: {
          available_balance?: number
          created_at?: string
          hold_reason?: string | null
          id?: string
          is_held?: boolean
          member_id: string
          period_month: string
          total_earned?: number
          total_withdrawn?: number
          updated_at?: string
        }
        Update: {
          available_balance?: number
          created_at?: string
          hold_reason?: string | null
          id?: string
          is_held?: boolean
          member_id?: string
          period_month?: string
          total_earned?: number
          total_withdrawn?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "member_monthly_balance_summary_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      members: {
        Row: {
          address: string | null
          approved_applications: number
          created_at: string
          date_of_birth: string | null
          deactivated_at: string | null
          full_name: string
          id: string
          is_active: boolean
          member_number: string | null
          nik: string | null
          occupation: string | null
          phone: string | null
          photo_url: string | null
          pin: string | null
          position: string
          total_amount_disbursed: number
          total_applications: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address?: string | null
          approved_applications?: number
          created_at?: string
          date_of_birth?: string | null
          deactivated_at?: string | null
          full_name: string
          id?: string
          is_active?: boolean
          member_number?: string | null
          nik?: string | null
          occupation?: string | null
          phone?: string | null
          photo_url?: string | null
          pin?: string | null
          position: string
          total_amount_disbursed?: number
          total_applications?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address?: string | null
          approved_applications?: number
          created_at?: string
          date_of_birth?: string | null
          deactivated_at?: string | null
          full_name?: string
          id?: string
          is_active?: boolean
          member_number?: string | null
          nik?: string | null
          occupation?: string | null
          phone?: string | null
          photo_url?: string | null
          pin?: string | null
          position?: string
          total_amount_disbursed?: number
          total_applications?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          application_id: string
          created_at: string
          created_by: string | null
          id: string
          installment_id: string
          notes: string | null
          payment_date: string
          payment_method: string
          reference_number: string | null
        }
        Insert: {
          amount: number
          application_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          installment_id: string
          notes?: string | null
          payment_date: string
          payment_method: string
          reference_number?: string | null
        }
        Update: {
          amount?: number
          application_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          installment_id?: string
          notes?: string | null
          payment_date?: string
          payment_method?: string
          reference_number?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payments_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "credit_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_installment_id_fkey"
            columns: ["installment_id"]
            isOneToOne: false
            referencedRelation: "installment_payment_verification"
            referencedColumns: ["installment_id"]
          },
          {
            foreignKeyName: "payments_installment_id_fkey"
            columns: ["installment_id"]
            isOneToOne: false
            referencedRelation: "installments"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          business_address: string | null
          business_description: string | null
          business_email: string | null
          business_name: string | null
          business_phone: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          logo_url: string | null
          phone: string | null
          updated_at: string
        }
        Insert: {
          business_address?: string | null
          business_description?: string | null
          business_email?: string | null
          business_name?: string | null
          business_phone?: string | null
          created_at?: string
          email: string
          full_name: string
          id: string
          logo_url?: string | null
          phone?: string | null
          updated_at?: string
        }
        Update: {
          business_address?: string | null
          business_description?: string | null
          business_email?: string | null
          business_name?: string | null
          business_phone?: string | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          logo_url?: string | null
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      reconciliation_logs: {
        Row: {
          changes: Json
          created_at: string
          executed_at: string
          executed_by: string | null
          id: string
          mode: string
          total_examined: number
          total_updated: number
        }
        Insert: {
          changes?: Json
          created_at?: string
          executed_at?: string
          executed_by?: string | null
          id?: string
          mode: string
          total_examined?: number
          total_updated?: number
        }
        Update: {
          changes?: Json
          created_at?: string
          executed_at?: string
          executed_by?: string | null
          id?: string
          mode?: string
          total_examined?: number
          total_updated?: number
        }
        Relationships: []
      }
      restore_progress: {
        Row: {
          backup_timestamp: string
          completed_applications: number
          completed_at: string | null
          completed_customers: number
          current_application_id: string | null
          current_customer_id: string | null
          current_customer_name: string | null
          error_log: Json | null
          id: string
          last_updated: string
          started_at: string
          status: string
          total_applications: number
          total_customers: number
        }
        Insert: {
          backup_timestamp: string
          completed_applications?: number
          completed_at?: string | null
          completed_customers?: number
          current_application_id?: string | null
          current_customer_id?: string | null
          current_customer_name?: string | null
          error_log?: Json | null
          id?: string
          last_updated?: string
          started_at?: string
          status?: string
          total_applications?: number
          total_customers?: number
        }
        Update: {
          backup_timestamp?: string
          completed_applications?: number
          completed_at?: string | null
          completed_customers?: number
          current_application_id?: string | null
          current_customer_id?: string | null
          current_customer_name?: string | null
          error_log?: Json | null
          id?: string
          last_updated?: string
          started_at?: string
          status?: string
          total_applications?: number
          total_customers?: number
        }
        Relationships: []
      }
      saver_deposits: {
        Row: {
          amount: number
          approved_at: string | null
          approved_by: string | null
          created_at: string
          created_by: string | null
          deposit_date: string
          id: string
          is_eligible_for_interest: boolean
          notes: string | null
          payment_details: string | null
          payment_method: string | null
          rejection_reason: string | null
          remaining_balance: number
          saver_id: string
          status: string | null
          total_interest_earned: number
          transaction_number: string | null
          transaction_type: string
          updated_at: string
        }
        Insert: {
          amount: number
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string | null
          deposit_date?: string
          id?: string
          is_eligible_for_interest?: boolean
          notes?: string | null
          payment_details?: string | null
          payment_method?: string | null
          rejection_reason?: string | null
          remaining_balance: number
          saver_id: string
          status?: string | null
          total_interest_earned?: number
          transaction_number?: string | null
          transaction_type?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string | null
          deposit_date?: string
          id?: string
          is_eligible_for_interest?: boolean
          notes?: string | null
          payment_details?: string | null
          payment_method?: string | null
          rejection_reason?: string | null
          remaining_balance?: number
          saver_id?: string
          status?: string | null
          total_interest_earned?: number
          transaction_number?: string | null
          transaction_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "saver_deposits_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saver_deposits_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saver_deposits_saver_id_fkey"
            columns: ["saver_id"]
            isOneToOne: false
            referencedRelation: "savers"
            referencedColumns: ["id"]
          },
        ]
      }
      saver_interest_transactions: {
        Row: {
          amount: number
          created_at: string
          deposit_id: string | null
          id: string
          interest_rate: number
          payment_date: string
          period_month: string
          principal_amount: number
          saver_id: string
          tier_level: string
        }
        Insert: {
          amount: number
          created_at?: string
          deposit_id?: string | null
          id?: string
          interest_rate: number
          payment_date?: string
          period_month: string
          principal_amount: number
          saver_id: string
          tier_level?: string
        }
        Update: {
          amount?: number
          created_at?: string
          deposit_id?: string | null
          id?: string
          interest_rate?: number
          payment_date?: string
          period_month?: string
          principal_amount?: number
          saver_id?: string
          tier_level?: string
        }
        Relationships: [
          {
            foreignKeyName: "saver_interest_transactions_deposit_id_fkey"
            columns: ["deposit_id"]
            isOneToOne: false
            referencedRelation: "saver_deposits"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saver_interest_transactions_saver_id_fkey"
            columns: ["saver_id"]
            isOneToOne: false
            referencedRelation: "savers"
            referencedColumns: ["id"]
          },
        ]
      }
      saver_pending_withdrawals: {
        Row: {
          amount: number
          cancel_reason: string | null
          cancelled_at: string | null
          confirmed_at: string | null
          created_at: string
          expires_at: string
          failed_pin_attempts: number | null
          id: string
          notes: string | null
          payment_details: string | null
          payment_method: string | null
          requested_at: string
          requested_by: string | null
          saver_id: string
          status: string
          transaction_number: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          cancel_reason?: string | null
          cancelled_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          expires_at?: string
          failed_pin_attempts?: number | null
          id?: string
          notes?: string | null
          payment_details?: string | null
          payment_method?: string | null
          requested_at?: string
          requested_by?: string | null
          saver_id: string
          status?: string
          transaction_number?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          cancel_reason?: string | null
          cancelled_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          expires_at?: string
          failed_pin_attempts?: number | null
          id?: string
          notes?: string | null
          payment_details?: string | null
          payment_method?: string | null
          requested_at?: string
          requested_by?: string | null
          saver_id?: string
          status?: string
          transaction_number?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "saver_pending_withdrawals_requested_by_fkey"
            columns: ["requested_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saver_pending_withdrawals_saver_id_fkey"
            columns: ["saver_id"]
            isOneToOne: false
            referencedRelation: "savers"
            referencedColumns: ["id"]
          },
        ]
      }
      saver_withdrawals: {
        Row: {
          amount: number
          created_at: string
          id: string
          notes: string | null
          payment_details: string | null
          payment_method: string | null
          processed_by: string | null
          saver_id: string
          status: string
          transaction_number: string | null
          withdrawal_date: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          notes?: string | null
          payment_details?: string | null
          payment_method?: string | null
          processed_by?: string | null
          saver_id: string
          status?: string
          transaction_number?: string | null
          withdrawal_date?: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          notes?: string | null
          payment_details?: string | null
          payment_method?: string | null
          processed_by?: string | null
          saver_id?: string
          status?: string
          transaction_number?: string | null
          withdrawal_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "saver_withdrawals_processed_by_fkey"
            columns: ["processed_by"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saver_withdrawals_saver_id_fkey"
            columns: ["saver_id"]
            isOneToOne: false
            referencedRelation: "savers"
            referencedColumns: ["id"]
          },
        ]
      }
      savers: {
        Row: {
          account_number: string
          address: string
          balance: number | null
          created_at: string
          created_by: string | null
          date_of_birth: string | null
          deposit_balance: number | null
          email: string | null
          full_name: string
          id: string
          id_number: string
          interest_balance: number | null
          login_email: string | null
          mother_maiden_name: string | null
          occupation: string | null
          phone: string
          photo_url: string | null
          pin_hash: string | null
          recommended_by_member_id: string | null
          saver_number: string
          status: string
          tier_level: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          account_number: string
          address: string
          balance?: number | null
          created_at?: string
          created_by?: string | null
          date_of_birth?: string | null
          deposit_balance?: number | null
          email?: string | null
          full_name: string
          id?: string
          id_number: string
          interest_balance?: number | null
          login_email?: string | null
          mother_maiden_name?: string | null
          occupation?: string | null
          phone: string
          photo_url?: string | null
          pin_hash?: string | null
          recommended_by_member_id?: string | null
          saver_number: string
          status?: string
          tier_level?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          account_number?: string
          address?: string
          balance?: number | null
          created_at?: string
          created_by?: string | null
          date_of_birth?: string | null
          deposit_balance?: number | null
          email?: string | null
          full_name?: string
          id?: string
          id_number?: string
          interest_balance?: number | null
          login_email?: string | null
          mother_maiden_name?: string | null
          occupation?: string | null
          phone?: string
          photo_url?: string | null
          pin_hash?: string | null
          recommended_by_member_id?: string | null
          saver_number?: string
          status?: string
          tier_level?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "savers_recommended_by_member_id_fkey"
            columns: ["recommended_by_member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      system_logs: {
        Row: {
          action: string
          category: Database["public"]["Enums"]["log_category"]
          created_at: string
          description: string
          id: string
          metadata: Json | null
          user_id: string | null
          user_name: string | null
        }
        Insert: {
          action: string
          category: Database["public"]["Enums"]["log_category"]
          created_at?: string
          description: string
          id?: string
          metadata?: Json | null
          user_id?: string | null
          user_name?: string | null
        }
        Update: {
          action?: string
          category?: Database["public"]["Enums"]["log_category"]
          created_at?: string
          description?: string
          id?: string
          metadata?: Json | null
          user_id?: string | null
          user_name?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      whatsapp_auto_reminder_settings: {
        Row: {
          created_at: string
          due_date_reminder_enabled: boolean
          id: string
          is_enabled: boolean
          last_run_at: string | null
          next_run_at: string | null
          overdue_reminder_enabled: boolean
          reminder_time: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          due_date_reminder_enabled?: boolean
          id?: string
          is_enabled?: boolean
          last_run_at?: string | null
          next_run_at?: string | null
          overdue_reminder_enabled?: boolean
          reminder_time?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          due_date_reminder_enabled?: boolean
          id?: string
          is_enabled?: boolean
          last_run_at?: string | null
          next_run_at?: string | null
          overdue_reminder_enabled?: boolean
          reminder_time?: string
          updated_at?: string
        }
        Relationships: []
      }
      whatsapp_message_logs: {
        Row: {
          created_at: string
          created_by: string | null
          error_message: string | null
          id: string
          message_content: string
          message_type: string
          recipient_id: string | null
          recipient_name: string | null
          recipient_phone: string
          recipient_type: string
          sent_at: string | null
          status: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          error_message?: string | null
          id?: string
          message_content: string
          message_type: string
          recipient_id?: string | null
          recipient_name?: string | null
          recipient_phone: string
          recipient_type: string
          sent_at?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          error_message?: string | null
          id?: string
          message_content?: string
          message_type?: string
          recipient_id?: string | null
          recipient_name?: string | null
          recipient_phone?: string
          recipient_type?: string
          sent_at?: string | null
          status?: string
        }
        Relationships: []
      }
      whatsapp_message_templates: {
        Row: {
          category: string
          content: string
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          name: string
          title: string
          updated_at: string
          variables: Json | null
        }
        Insert: {
          category: string
          content: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name: string
          title: string
          updated_at?: string
          variables?: Json | null
        }
        Update: {
          category?: string
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name?: string
          title?: string
          updated_at?: string
          variables?: Json | null
        }
        Relationships: []
      }
      whatsapp_settings: {
        Row: {
          api_key: string | null
          api_provider: string
          api_url: string | null
          broadcast_delay_seconds: number | null
          business_account_id: string | null
          created_at: string
          id: string
          is_enabled: boolean
          last_tested_at: string | null
          phone_number: string | null
          phone_number_id: string | null
          test_message: string | null
          test_status: string | null
          updated_at: string
          webhook_verify_token: string | null
        }
        Insert: {
          api_key?: string | null
          api_provider?: string
          api_url?: string | null
          broadcast_delay_seconds?: number | null
          business_account_id?: string | null
          created_at?: string
          id?: string
          is_enabled?: boolean
          last_tested_at?: string | null
          phone_number?: string | null
          phone_number_id?: string | null
          test_message?: string | null
          test_status?: string | null
          updated_at?: string
          webhook_verify_token?: string | null
        }
        Update: {
          api_key?: string | null
          api_provider?: string
          api_url?: string | null
          broadcast_delay_seconds?: number | null
          business_account_id?: string | null
          created_at?: string
          id?: string
          is_enabled?: boolean
          last_tested_at?: string | null
          phone_number?: string | null
          phone_number_id?: string | null
          test_message?: string | null
          test_status?: string | null
          updated_at?: string
          webhook_verify_token?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      installment_payment_verification: {
        Row: {
          actual_payments_total: number | null
          application_number: string | null
          customer_id: string | null
          discrepancy: number | null
          full_name: string | null
          installment_id: string | null
          installment_number: number | null
          principal_paid: boolean | null
          recorded_paid_amount: number | null
          status: string | null
          total_amount: number | null
          verification_status: string | null
        }
        Relationships: [
          {
            foreignKeyName: "credit_applications_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      adjust_customer_registration_date: { Args: never; Returns: undefined }
      apply_payment_to_installment: {
        Args: {
          p_amount: number
          p_installment_id: string
          p_notes?: string
          p_payment_date: string
          p_payment_method: string
          p_reference: string
        }
        Returns: Json
      }
      audit_customer_badges: {
        Args: never
        Returns: {
          badge_from_func: string
          consecutive_on_time: number
          customer_id: string
          expected_badge: string
          full_name: string
          mismatch: boolean
          on_time_paid: number
          on_time_percentage: number
          overdue_count: number
          paid_late_count: number
          penalty_count: number
          total_paid: number
        }[]
      }
      auto_expire_pending_withdrawals: { Args: never; Returns: undefined }
      auto_update_overdue_installments: { Args: never; Returns: undefined }
      backfill_missing_incentive_transactions: {
        Args: never
        Returns: {
          member_name: string
          payments_processed: number
          regular_amount: number
          year_end_bonus_amount: number
        }[]
      }
      block_all_low_credit_customers: { Args: never; Returns: Json }
      block_customer: {
        Args: { p_customer_id: string; p_reason: string }
        Returns: Json
      }
      calculate_credit_score: {
        Args: { p_customer_id: string }
        Returns: number
      }
      calculate_current_penalty: {
        Args: { p_installment_id: string }
        Returns: number
      }
      calculate_installment_penalty: {
        Args: { p_installment_id: string }
        Returns: number
      }
      can_apply_for_credit: { Args: { check_nik: string }; Returns: Json }
      can_family_apply_credit: {
        Args: { p_customer_id: string }
        Returns: Json
      }
      can_request_restoration: {
        Args: { p_customer_id: string }
        Returns: boolean
      }
      check_family_active_credit: {
        Args: { p_exclude_customer_id?: string; p_no_kk: string }
        Returns: {
          amount_approved: number
          application_number: string
          customer_id: string
          customer_name: string
          remaining_amount: number
          status: string
        }[]
      }
      check_member_overdue_in_period: {
        Args: { p_member_id: string; p_period_month: string }
        Returns: boolean
      }
      check_owner_exists: { Args: never; Returns: boolean }
      cleanup_old_customer_messages: { Args: never; Returns: undefined }
      cleanup_old_logs: { Args: never; Returns: undefined }
      cleanup_old_member_messages: { Args: never; Returns: undefined }
      cleanup_old_messages: { Args: never; Returns: undefined }
      disable_payments_triggers: { Args: never; Returns: undefined }
      enable_payments_triggers: { Args: never; Returns: undefined }
      forfeit_inactive_member_balances: {
        Args: never
        Returns: {
          forfeited_regular: number
          forfeited_thr: number
          forfeited_total: number
          member_id: string
          member_name: string
        }[]
      }
      generate_saver_account_number: { Args: never; Returns: string }
      generate_saver_number: { Args: never; Returns: string }
      get_customer_achievement_badge: {
        Args: { p_customer_id: string }
        Returns: {
          badge_description: string
          badge_level: string
          badge_name: string
          consecutive_on_time_payments: number
          customer_id: string
          on_time_percentage: number
          total_on_time_payments: number
          total_payments: number
        }[]
      }
      get_customer_credit_score_breakdown: {
        Args: { p_customer_id: string }
        Returns: {
          due_today: number
          on_time_no_penalty: number
          overdue_no_payment: number
          paid_with_penalty: number
          partial_1_24: number
          partial_25_49: number
          partial_50_74: number
          partial_75_plus: number
          running_penalty: number
          total_installments: number
          upcoming_installments: number
        }[]
      }
      get_customer_detail_data: {
        Args: { p_customer_id: string }
        Returns: Json
      }
      get_customer_message_counts: {
        Args: never
        Returns: {
          customer_id: string
          message_count: number
        }[]
      }
      get_customers_achievement_badges: {
        Args: { p_customer_ids: string[] }
        Returns: {
          badge_description: string
          badge_level: string
          badge_name: string
          consecutive_on_time_payments: number
          customer_id: string
          on_time_percentage: number
          total_on_time_payments: number
          total_payments: number
        }[]
      }
      get_financial_dashboard_summary: {
        Args: { p_month_end?: string; p_month_start?: string }
        Returns: Json
      }
      get_interest_rate: {
        Args: {
          p_custom_rates?: Json
          p_flat_rate?: number
          p_interest_type?: string
          p_tenor_months: number
        }
        Returns: number
      }
      get_member_available_balance: {
        Args: { p_member_id: string }
        Returns: number
      }
      get_member_balance: { Args: { p_member_id: string }; Returns: number }
      get_member_balance_detailed: {
        Args: { p_member_id: string }
        Returns: {
          regular_balance: number
          thr_balance: number
          total_balance: number
        }[]
      }
      get_member_message_counts: {
        Args: never
        Returns: {
          member_id: string
          message_count: number
        }[]
      }
      get_member_payments_aggregate: {
        Args: { p_end_date: string; p_start_date: string }
        Returns: {
          member_id: string
          payment_count: number
          total_amount: number
        }[]
      }
      get_member_performance: {
        Args: { p_month: number; p_year: number }
        Returns: {
          applications_count: number
          member_id: string
          member_name: string
          total_collected: number
          total_disbursed: number
        }[]
      }
      get_payments_total_by_member: {
        Args: { p_end: string; p_start: string }
        Returns: {
          member_id: string
          payments_count: number
          total_amount: number
        }[]
      }
      get_public_app_settings: { Args: never; Returns: Json }
      get_reports_financial_stats: { Args: never; Returns: Json }
      get_verified_member_id: { Args: { p_user_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role_text: {
        Args: { _role: string; _user_id: string }
        Returns: boolean
      }
      has_unpaid_penalties: {
        Args: { p_customer_id: string }
        Returns: boolean
      }
      hash_kasir_pin: { Args: { pin: string }; Returns: string }
      is_active_staff: { Args: { p_user_id: string }; Returns: boolean }
      is_nik_blocked: { Args: { check_nik: string }; Returns: boolean }
      log_system_event: {
        Args: {
          p_action: string
          p_category: Database["public"]["Enums"]["log_category"]
          p_description: string
          p_metadata?: Json
          p_user_id: string
          p_user_name: string
        }
        Returns: string
      }
      mark_application_completed_if_paid: {
        Args: { p_application_id: string }
        Returns: undefined
      }
      recalculate_all_application_statuses: {
        Args: never
        Returns: {
          application_id: string
          application_number: string
          new_status: string
          old_status: string
          paid_installments: number
          total_installments: number
        }[]
      }
      recalculate_all_customer_credit_scores: {
        Args: never
        Returns: {
          customer_id: string
          difference: number
          full_name: string
          id_number: string
          new_score: number
          old_score: number
        }[]
      }
      recalculate_all_member_statistics: { Args: never; Returns: undefined }
      recalculate_application_status: {
        Args: { p_application_id: string }
        Returns: undefined
      }
      recalculate_saver_balances: {
        Args: { p_saver_id: string }
        Returns: undefined
      }
      reset_credit_status_for_restore: { Args: never; Returns: Json }
      restore_application_if_not_exists: {
        Args: { p_application_data: Json; p_application_id: string }
        Returns: Json
      }
      restore_blocked_customer: {
        Args: { p_customer_id: string }
        Returns: Json
      }
      restore_customer_if_not_exists: {
        Args: { p_customer_data: Json; p_customer_id: string }
        Returns: Json
      }
      restore_installment_if_not_exists: {
        Args: { p_installment_data: Json; p_installment_id: string }
        Returns: Json
      }
      restore_member_if_not_exists: {
        Args: { p_member_data: Json; p_member_id: string }
        Returns: Json
      }
      restore_payment_if_not_exists: {
        Args: { p_payment_data: Json; p_payment_id: string }
        Returns: Json
      }
      update_customer_credit_score: {
        Args: { p_customer_id: string }
        Returns: undefined
      }
      update_member_statistics: {
        Args: { p_member_id: string }
        Returns: undefined
      }
      update_monthly_balance_holds: { Args: never; Returns: undefined }
      verify_kasir_pin: {
        Args: { p_member_id: string; p_pin_input: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "owner" | "admin" | "sales" | "customer" | "kasir" | "saver"
      log_category:
        | "member_management"
        | "customer_management"
        | "credit_application"
        | "payment"
        | "blocking"
        | "security"
        | "system_error"
        | "data_deletion"
        | "sensitive_update"
        | "authentication"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "admin", "sales", "customer", "kasir", "saver"],
      log_category: [
        "member_management",
        "customer_management",
        "credit_application",
        "payment",
        "blocking",
        "security",
        "system_error",
        "data_deletion",
        "sensitive_update",
        "authentication",
      ],
    },
  },
} as const
