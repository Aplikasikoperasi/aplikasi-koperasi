import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import { DeviceAwareWrapper } from "./components/DeviceAwareWrapper";
import { PWAUpdatePrompt } from "./components/PWAUpdatePrompt";
import { DynamicPWAMetadata } from "./components/DynamicPWAMetadata";
import { InstallPromptBanner } from "./components/InstallPromptBanner";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { AppLayout } from "./components/layout/AppLayout";
import { UserRoleProvider } from "./contexts/UserRoleContext";
import { SuperCodeProvider } from "./contexts/SuperCodeContext";
import { SaverAuthProvider } from "./contexts/SaverAuthContext";
import { SkeletonCard } from "./components/ui/skeleton-card";

// Lazy load pages untuk reduce initial bundle size
const Index = lazy(() => import("./pages/Index"));
const Auth = lazy(() => import("./pages/Auth"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const CashierDashboard = lazy(() => import("./pages/CashierDashboard"));
const Settings = lazy(() => import("./pages/Settings"));
const Members = lazy(() => import("./pages/Members"));
const Customers = lazy(() => import("./pages/Customers"));
const PendingCustomers = lazy(() => import("./pages/PendingCustomers"));
const MembersAndCustomers = lazy(() => import("./pages/MembersAndCustomers"));
const BlockedCustomers = lazy(() => import("./pages/BlockedCustomers"));
const Verifications = lazy(() => import("./pages/Verifications"));
const Applications = lazy(() => import("./pages/Applications"));
const Installments = lazy(() => import("./pages/Installments"));
const Payments = lazy(() => import("./pages/Payments"));
const InstallmentsAndPayments = lazy(() => import("./pages/InstallmentsAndPayments"));
const Reports = lazy(() => import("./pages/Reports"));
const ReportsDetailedRedirect = lazy(() => import("./pages/ReportsDetailedRedirect"));
const WhatsApp = lazy(() => import("./pages/WhatsApp"));
const NotFound = lazy(() => import("./pages/NotFound"));
const SalesPerformance = lazy(() => import("./pages/SalesPerformance"));
const CustomerDashboard = lazy(() => import("./pages/CustomerDashboard"));
const CustomerInbox = lazy(() => import("./pages/CustomerInbox"));
const BroadcastMessages = lazy(() => import("./pages/BroadcastMessages"));
const Inbox = lazy(() => import("./pages/Inbox"));
const MemberBalance = lazy(() => import("./pages/MemberBalance"));
const OAuthCallback = lazy(() => import("./pages/OAuthCallback"));
const TestKasirSystem = lazy(() => import("./pages/TestKasirSystem"));
const RoyalCustomers = lazy(() => import("./pages/RoyalCustomers"));
const NPLCustomers = lazy(() => import("./pages/NPLCustomers"));
const SalesCustomers = lazy(() => import("./pages/SalesCustomers"));
const SalesApplications = lazy(() => import("./pages/SalesApplications"));
const SalesNPL = lazy(() => import("./pages/SalesNPL"));
const CreditSimulation = lazy(() => import("./pages/CreditSimulation"));
const Expenses = lazy(() => import("./pages/Expenses"));
const SaverDashboard = lazy(() => import("./pages/SaverDashboard"));
const SaverProfile = lazy(() => import("./pages/SaverProfile"));

// Loading fallback component
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center p-4">
    <div className="w-full max-w-4xl space-y-4">
      <SkeletonCard />
    </div>
  </div>
);

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <UserRoleProvider>
      <SuperCodeProvider>
        <SaverAuthProvider>
          <DeviceAwareWrapper>
            <TooltipProvider>
              <DynamicPWAMetadata />
              <PWAUpdatePrompt />
              <InstallPromptBanner />
              <Toaster />
              <Sonner />
              <BrowserRouter>
              <Suspense fallback={<PageLoader />}>
                <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/simulasi-kredit" element={<CreditSimulation />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/test-kasir" element={<TestKasirSystem />} />
              <Route path="/oauth/callback" element={<OAuthCallback />} />
              <Route path="/saver-dashboard" element={<SaverDashboard />} />
              <Route path="/saver-profile" element={<SaverProfile />} />
              <Route
                path="/customer-dashboard" 
                element={
                  <ProtectedRoute allowedRoles={["customer"]}>
                    <CustomerDashboard />
                  </ProtectedRoute>
                } 
              />
              <Route
                path="/customer-inbox" 
                element={
                  <ProtectedRoute allowedRoles={["customer"]}>
                    <CustomerInbox />
                  </ProtectedRoute>
                } 
              />
              <Route 
                element={
                  <ProtectedRoute allowedRoles={["owner", "admin", "sales", "kasir"]}>
                    <AppLayout />
                  </ProtectedRoute>
                }
              >
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/cashier-dashboard" element={<CashierDashboard />} />
                <Route path="/royal-customers" element={<RoyalCustomers />} />
                <Route path="/npl-customers" element={<NPLCustomers />} />
                <Route path="/sales-customers" element={<SalesCustomers />} />
                <Route path="/sales-applications" element={<SalesApplications />} />
                <Route path="/sales-npl" element={<SalesNPL />} />
                <Route path="/members-customers" element={<MembersAndCustomers />} />
                <Route path="/members" element={<Members />} />
                <Route path="/customers" element={<Customers />} />
                <Route path="/verifications" element={<Verifications />} />
                <Route path="/pending-customers" element={<PendingCustomers />} />
                <Route path="/blocked-customers" element={<BlockedCustomers />} />
                <Route path="/applications" element={<Applications />} />
                <Route path="/installments-payments" element={<InstallmentsAndPayments />} />
                <Route path="/installments" element={<Installments />} />
                <Route path="/payments" element={<Payments />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/reports/detailed" element={<ReportsDetailedRedirect />} />
                <Route path="/sales-performance" element={<SalesPerformance />} />
                <Route path="/whatsapp" element={<WhatsApp />} />
                <Route path="/broadcast-messages" element={<BroadcastMessages />} />
                <Route path="/inbox" element={<Inbox />} />
                <Route path="/member-balance" element={<MemberBalance />} />
                <Route path="/expenses" element={<Expenses />} />
                <Route path="/settings" element={<Settings />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
              </Suspense>
            </BrowserRouter>
          </TooltipProvider>
        </DeviceAwareWrapper>
        </SaverAuthProvider>
      </SuperCodeProvider>
    </UserRoleProvider>
  </QueryClientProvider>
);

export default App;
