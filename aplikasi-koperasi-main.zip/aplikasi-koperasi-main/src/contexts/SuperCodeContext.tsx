import { createContext, useContext, useState, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SuperCodeContextType {
  requireSuperCode: (operation: string) => Promise<boolean>;
}

const SuperCodeContext = createContext<SuperCodeContextType | undefined>(undefined);

export const useSuperCode = () => {
  const context = useContext(SuperCodeContext);
  if (!context) {
    throw new Error("useSuperCode must be used within SuperCodeProvider");
  }
  return context;
};

interface SuperCodeProviderProps {
  children: ReactNode;
}

export const SuperCodeProvider = ({ children }: SuperCodeProviderProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [superCodeInput, setSuperCodeInput] = useState("");
  const [currentOperation, setCurrentOperation] = useState("");
  const [resolvePromise, setResolvePromise] = useState<((value: boolean) => void) | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const { toast } = useToast();

  const verifySuperCode = async (): Promise<boolean> => {
    try {
      const { data: result, error } = await supabase.functions.invoke('verify-supercode', {
        body: {
          superCodeInput: superCodeInput,
          operation: currentOperation
        }
      });

      if (error) {
        const errorMsg = "Gagal memverifikasi SuperCode. Silakan coba lagi.";
        setErrorMessage(errorMsg);
        toast({
          title: "❌ Error",
          description: errorMsg,
          variant: "destructive"
        });
        return false;
      }

      if (!result?.valid) {
        const errorMsg = result?.error || "SuperCode tidak valid";
        setErrorMessage(errorMsg);
        toast({
          title: "❌ SuperCode Salah",
          description: errorMsg,
          variant: "destructive"
        });
        return false;
      }

      return true;
    } catch (error: any) {
      const errorMsg = error.message || "Gagal memverifikasi SuperCode";
      setErrorMessage(errorMsg);
      toast({
        title: "❌ Error",
        description: errorMsg,
        variant: "destructive"
      });
      return false;
    }
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    setErrorMessage(""); // Clear previous errors
    
    const isValid = await verifySuperCode();
    
    setIsVerifying(false);
    
    // Only close dialog if verification is successful
    if (isValid) {
      toast({
        title: "✅ Verifikasi Berhasil",
        description: "SuperCode valid",
      });
      
      // Close dialog after short delay so user sees success message
      setTimeout(() => {
        setDialogOpen(false);
        setSuperCodeInput("");
        setErrorMessage("");
        
        if (resolvePromise) {
          resolvePromise(true);
        }
      }, 500);
    }
    // If invalid, keep dialog open so user can try again
    // Error message is already shown by verifySuperCode
  };

  const handleCancel = () => {
    setDialogOpen(false);
    setSuperCodeInput("");
    setErrorMessage("");
    if (resolvePromise) {
      resolvePromise(false);
    }
  };

  const requireSuperCode = (operation: string): Promise<boolean> => {
    return new Promise((resolve) => {
      setCurrentOperation(operation);
      setResolvePromise(() => resolve);
      setErrorMessage("");
      setSuperCodeInput("");
      setDialogOpen(true);
    });
  };

  return (
    <SuperCodeContext.Provider value={{ requireSuperCode }}>
      {children}
      
      <Dialog open={dialogOpen} onOpenChange={(open) => !open && handleCancel()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Verifikasi SuperCode</DialogTitle>
            <DialogDescription>
              Masukkan SuperCode untuk melanjutkan: {currentOperation}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {errorMessage && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive px-4 py-3 rounded-md">
                <p className="text-sm font-medium">❌ {errorMessage}</p>
              </div>
            )}
            <Input
              type="password"
              placeholder="Masukkan SuperCode"
              value={superCodeInput}
              onChange={(e) => {
                setSuperCodeInput(e.target.value);
                setErrorMessage(""); // Clear error when user types
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !isVerifying) {
                  handleVerify();
                }
              }}
              disabled={isVerifying}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              onClick={handleCancel}
              disabled={isVerifying}
            >
              Batal
            </Button>
            <Button 
              onClick={handleVerify}
              disabled={isVerifying}
            >
              {isVerifying ? "Memverifikasi..." : "Verifikasi"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </SuperCodeContext.Provider>
  );
};
