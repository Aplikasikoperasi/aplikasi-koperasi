import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export type UserRole = "owner" | "admin" | "sales" | "customer" | "kasir" | "saver" | null;

interface UserRoleContextType {
  role: UserRole;
  loading: boolean;
  isOwner: boolean;
  isAdmin: boolean;
  isSales: boolean;
  isCustomer: boolean;
  isKasir: boolean;
  refreshRole: () => Promise<void>;
}

const UserRoleContext = createContext<UserRoleContextType | undefined>(undefined);

export function UserRoleProvider({ children }: { children: ReactNode }) {
  // Use toast function directly instead of useToast hook to avoid circular dependency
  const [role, setRole] = useState<UserRole>(null);
  const [loading, setLoading] = useState(true);
  const [isOwner, setIsOwner] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSales, setIsSales] = useState(false);
  const [isCustomer, setIsCustomer] = useState(false);
  const [isKasir, setIsKasir] = useState(false);

  const loadRole = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // SECURITY: Check account TYPE first to determine correct role
        // Customer accounts should ALWAYS have role = 'customer' regardless of user_roles table
        const { data: customerData } = await supabase
          .from("customers")
          .select("id")
          .eq("user_id", user.id)
          .maybeSingle();
        
        if (customerData) {
          // This is a CUSTOMER account - force customer role
          console.log("[UserRoleContext] User is a customer, forcing customer role");
          setRole('customer');
          setIsOwner(false);
          setIsAdmin(false);
          setIsSales(false);
          setIsCustomer(true);
          setIsKasir(false);
          setLoading(false);
          return;
        }

        // Check if member is active (for non-customer roles)
        const { data: memberData } = await supabase
          .from("members")
          .select("is_active, deactivated_at")
          .eq("user_id", user.id)
          .maybeSingle();

        // If member exists and is not active, block access
        if (memberData && !memberData.is_active) {
          console.warn("Member account is inactive. Access denied.");
          
          // Calculate days inactive and remaining time
          let daysInactive = 0;
          let daysRemaining = 90;
          if (memberData.deactivated_at) {
            const deactivatedDate = new Date(memberData.deactivated_at);
            const now = new Date();
            daysInactive = Math.floor((now.getTime() - deactivatedDate.getTime()) / (1000 * 60 * 60 * 24));
            daysRemaining = Math.max(0, 90 - daysInactive);
          }
          
          // Show detailed warning about account status and balance freeze
          toast({
            title: "⛔ Akses Ditolak - Akun Tidak Aktif",
            description: daysRemaining > 0 
              ? `Akun Anda telah dinonaktifkan ${daysInactive} hari yang lalu.\n\n📊 INFORMASI SALDO:\n• Saldo Anda dibekukan selama masa tenggang 90 hari\n• Sisa waktu: ${daysRemaining} hari\n• Setelah ${daysRemaining} hari, saldo akan hangus otomatis dan tidak dapat dikembalikan\n\n✅ CARA MENGAKTIFKAN KEMBALI:\nHubungi Owner atau Admin untuk memulihkan akses dan menyelamatkan saldo Anda sebelum hangus.`
              : `Akun Anda telah tidak aktif lebih dari 90 hari.\n\n❌ STATUS SALDO:\n• Saldo Anda telah hangus secara otomatis\n• Saldo yang hangus tidak dapat dikembalikan\n\n📞 KONTAK:\nHubungi Owner atau Admin untuk informasi lebih lanjut tentang reaktivasi akun.`,
            variant: "destructive",
            duration: 15000, // 15 seconds untuk membaca pesan panjang
          });
          
          // Sign out the user automatically
          await supabase.auth.signOut();
          setRole(null);
          setIsOwner(false);
          setIsAdmin(false);
          setIsSales(false);
          setIsCustomer(false);
          setIsKasir(false);
          return;
        }

        // Check roles via RPC for authoritative result (for members only)
        const [ownerRes, adminRes, salesRes, kasirRes] = await Promise.all([
          supabase.rpc('has_role', { _user_id: user.id, _role: 'owner' }),
          supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' }),
          supabase.rpc('has_role', { _user_id: user.id, _role: 'sales' }),
          supabase.rpc('has_role', { _user_id: user.id, _role: 'kasir' }),
        ]);

        const ownerStatus = ownerRes.data === true;
        const adminStatus = adminRes.data === true;
        const salesStatus = salesRes.data === true;
        const kasirStatus = kasirRes.data === true;

        setIsOwner(ownerStatus);
        setIsAdmin(adminStatus);
        setIsSales(salesStatus);
        setIsCustomer(false); // Already confirmed not a customer above
        setIsKasir(kasirStatus);

        if (ownerStatus) {
          setRole('owner');
        } else if (adminStatus) {
          setRole('admin');
        } else if (salesStatus) {
          setRole('sales');
        } else if (kasirStatus) {
          setRole('kasir');
        } else {
          // Fallback to table query
          const { data: roleData } = await supabase
            .from("user_roles")
            .select("role")
            .eq("user_id", user.id)
            .order('created_at', { ascending: false })
            .limit(1);
          
          const userRole = roleData && roleData.length > 0 ? roleData[0].role : null;
          setRole(userRole);
        }
      } else {
        // User not logged in, reset all states
        setRole(null);
        setIsOwner(false);
        setIsAdmin(false);
        setIsSales(false);
        setIsCustomer(false);
        setIsKasir(false);
      }
    } catch (error) {
      console.error("Error loading user role:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRole();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        loadRole();
      } else if (event === 'SIGNED_OUT') {
        setRole(null);
        setIsOwner(false);
        setIsAdmin(false);
        setIsSales(false);
        setIsCustomer(false);
        setIsKasir(false);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <UserRoleContext.Provider
      value={{
        role,
        loading,
        isOwner,
        isAdmin,
        isSales,
        isCustomer,
        isKasir,
        refreshRole: loadRole,
      }}
    >
      {children}
    </UserRoleContext.Provider>
  );
}

export function useUserRole() {
  const context = useContext(UserRoleContext);
  if (context === undefined) {
    throw new Error("useUserRole must be used within a UserRoleProvider");
  }
  return context;
}
