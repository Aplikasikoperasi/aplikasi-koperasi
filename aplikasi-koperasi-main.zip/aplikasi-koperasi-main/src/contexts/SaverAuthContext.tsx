import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SaverData {
  id: string;
  saver_number: string;
  full_name: string;
  account_number: string;
  phone: string;
  address: string;
  email: string | null;
  photo_url: string | null;
  date_of_birth: string | null;
  occupation: string | null;
  status: string;
  created_at: string;
  balance: number | null;
  deposit_balance: number | null;
  interest_balance: number | null;
  tier_level: string | null;
}

interface SaverAuthContextType {
  saver: SaverData | null;
  isAuthenticated: boolean;
  login: (saver: SaverData) => void;
  logout: () => Promise<void>;
}

const SaverAuthContext = createContext<SaverAuthContextType | undefined>(undefined);

const SAVER_STORAGE_KEY = "saver_auth_data";

export function SaverAuthProvider({ children }: { children: ReactNode }) {
  const [saver, setSaver] = useState<SaverData | null>(null);

  useEffect(() => {
    // Check for existing session on mount
    const storedData = localStorage.getItem(SAVER_STORAGE_KEY);
    if (storedData) {
      try {
        const parsed = JSON.parse(storedData);
        setSaver(parsed);
      } catch {
        localStorage.removeItem(SAVER_STORAGE_KEY);
      }
    }
  }, []);

  const login = (saverData: SaverData) => {
    setSaver(saverData);
    localStorage.setItem(SAVER_STORAGE_KEY, JSON.stringify(saverData));
  };

  const logout = async () => {
    setSaver(null);
    
    // CRITICAL: Sign out from Supabase first to clear the auth session
    await supabase.auth.signOut();
    
    // CRITICAL: Clear ALL localStorage to prevent role confusion and cache issues
    localStorage.clear();
    
    // CRITICAL: Clear ALL sessionStorage
    sessionStorage.clear();
  };

  return (
    <SaverAuthContext.Provider
      value={{
        saver,
        isAuthenticated: !!saver,
        login,
        logout,
      }}
    >
      {children}
    </SaverAuthContext.Provider>
  );
}

export function useSaverAuth() {
  const context = useContext(SaverAuthContext);
  if (context === undefined) {
    throw new Error("useSaverAuth must be used within a SaverAuthProvider");
  }
  return context;
}
