import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface Saver {
  id: string;
  saver_number: string;
  account_number: string;
  full_name: string;
  id_number: string;
  phone: string;
  address: string;
  date_of_birth: string | null;
  email: string | null;
  photo_url: string | null;
  user_id: string | null;
  login_email: string | null;
  status: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  balance: number | null;
  deposit_balance: number | null;
  interest_balance: number | null;
  occupation: string | null;
  tier_level: string | null;
}

export type { Saver };

interface UseSaversParams {
  search?: string;
  page?: number;
  pageSize?: number;
}

export function useSaversQuery({
  search = "",
  page = 1,
  pageSize = 10,
}: UseSaversParams = {}) {
  return useQuery({
    queryKey: ["savers", search, page, pageSize],
    queryFn: async () => {
      let query = supabase
        .from("savers")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false });

      if (search) {
        query = query.or(
          `full_name.ilike.%${search}%,saver_number.ilike.%${search}%,account_number.ilike.%${search}%,id_number.ilike.%${search}%,phone.ilike.%${search}%`
        );
      }

      // Apply pagination
      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        savers: data as Saver[],
        totalCount: count || 0,
      };
    },
  });
}

export function useSaversCount() {
  return useQuery({
    queryKey: ["savers-count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("savers")
        .select("id", { count: "exact", head: true });

      if (error) throw error;
      return count || 0;
    },
  });
}

export function useInvalidateSavers() {
  const queryClient = useQueryClient();
  return () => {
    queryClient.invalidateQueries({ queryKey: ["savers"] });
    queryClient.invalidateQueries({ queryKey: ["savers-count"] });
  };
}
