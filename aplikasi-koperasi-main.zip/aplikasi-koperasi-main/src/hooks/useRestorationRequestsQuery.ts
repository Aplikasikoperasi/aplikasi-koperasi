import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useRestorationRequestsQuery = () => {
  return useQuery({
    queryKey: ["restoration-requests"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customer_restoration_requests")
        .select(`
          *,
          customers!inner(
            id,
            full_name,
            phone,
            credit_score,
            photo_url
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Filter: hanya tampilkan request untuk nasabah yang MASIH diblokir
      const requestsData = data || [];
      if (requestsData.length === 0) return [];

      const customerIds = requestsData.map(r => r.customer_id);
      const { data: blockedIds } = await supabase
        .from("blocked_customers")
        .select("customer_id")
        .in("customer_id", customerIds);

      const blockedSet = new Set((blockedIds || []).map(b => b.customer_id));
      
      // Hanya return request untuk nasabah yang masih diblokir
      return requestsData.filter(r => blockedSet.has(r.customer_id));
    },
  });
};

export const useCustomerRestorationStatusQuery = (customerId: string) => {
  return useQuery({
    queryKey: ["restoration-status", customerId],
    queryFn: async () => {
      // Check if customer is blocked
      const { data: blockData } = await supabase
        .from("blocked_customers")
        .select("*, customers!inner(credit_score)")
        .eq("customer_id", customerId)
        .single();

      if (!blockData) {
        return { isBlocked: false, canRequest: false };
      }

      // Check if can request restoration
      const { data: canRequestData, error } = await supabase
        .rpc("can_request_restoration", { p_customer_id: customerId });

      if (error) throw error;

      // Get last rejection
      const { data: lastRejection } = await supabase
        .from("customer_restoration_requests")
        .select("reviewed_at, rejection_reason")
        .eq("customer_id", customerId)
        .eq("status", "rejected")
        .order("reviewed_at", { ascending: false })
        .limit(1)
        .single();

      // Get pending request
      const { data: pendingRequest } = await supabase
        .from("customer_restoration_requests")
        .select("*")
        .eq("customer_id", customerId)
        .eq("status", "pending")
        .single();

      return {
        isBlocked: true,
        blockData,
        canRequest: canRequestData as boolean,
        lastRejection,
        pendingRequest,
      };
    },
    enabled: !!customerId,
  });
};

export const useInvalidateRestorationRequests = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["restoration-requests"] });
    queryClient.invalidateQueries({ queryKey: ["restoration-status"] });
  };
};
