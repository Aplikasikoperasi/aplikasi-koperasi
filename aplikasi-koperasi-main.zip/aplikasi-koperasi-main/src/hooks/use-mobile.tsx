import * as React from "react";

const MOBILE_BREAKPOINT = 768; // match Tailwind md breakpoint

export function useIsMobile() {
  const getInitial = () => {
    if (typeof window === "undefined") return false;
    return window.innerWidth <= MOBILE_BREAKPOINT;
  };

  const [isMobile, setIsMobile] = React.useState<boolean>(getInitial());

  React.useEffect(() => {
    const computeIsMobile = () => {
      setIsMobile(window.innerWidth <= MOBILE_BREAKPOINT);
    };

    window.addEventListener("resize", computeIsMobile);
    window.addEventListener("orientationchange", computeIsMobile);
    return () => {
      window.removeEventListener("resize", computeIsMobile);
      window.removeEventListener("orientationchange", computeIsMobile);
    };
  }, []);

  return isMobile;
}
