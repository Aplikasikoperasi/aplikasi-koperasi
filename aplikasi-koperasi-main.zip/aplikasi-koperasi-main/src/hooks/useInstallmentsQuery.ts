import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { getDateStringInWIB } from "@/lib/utils";

interface UseInstallmentsParams {
  searchQuery?: string;
  selectedMember?: string;
  page?: number;
  itemsPerPage?: number;
}

export const useInstallmentsQuery = ({
  searchQuery = "",
  selectedMember = "all",
  page = 1,
  itemsPerPage = 20,
}: UseInstallmentsParams = {}) => {
  return useQuery({
    queryKey: ["installments", searchQuery, selectedMember, page],
    queryFn: async () => {
      const from = (page - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      const threeDaysFromNowStr = getDateStringInWIB(3);

      // Get current user info
      const { data: { user } } = await supabase.auth.getUser();
      let currentMemberId = null;
      let isSalesUser = false;
      let relatedCustomerIds: string[] = [];

      if (user) {
        const { data: roleData } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .maybeSingle();

        isSalesUser = roleData?.role === "sales";

        if (isSalesUser) {
          const { data: memberData } = await supabase
            .from("members")
            .select("id")
            .eq("user_id", user.id)
            .maybeSingle();

          currentMemberId = memberData?.id;

          const { data: customersData } = await supabase
            .from("customers")
            .select("id")
            .eq("created_by", currentMemberId);

          relatedCustomerIds = customersData?.map((c) => c.id) || [];
        }
      }

      // Get allowed application IDs for sales users
      let allowedAppIds: string[] | null = null;

      if (isSalesUser && currentMemberId) {
        let appQuery = supabase.from("credit_applications").select("id");
        if (relatedCustomerIds.length > 0) {
          appQuery = appQuery.or(
            `member_id.eq.${currentMemberId},customer_id.in.(${relatedCustomerIds.join(",")})`
          );
        } else {
          appQuery = appQuery.eq("member_id", currentMemberId);
        }
        const { data: allowedApps } = await appQuery;
        allowedAppIds = allowedApps?.map((app) => app.id) || [];

        if (allowedAppIds.length === 0) {
          return { installments: [], totalCount: 0, uniqueMembers: [] };
        }
      }

      // Build query
      let query = supabase
        .from("installments")
        .select(
          `
          *,
          credit_applications!inner(
            id,
            application_number,
            amount_approved,
            amount_requested,
            tenor_months,
            interest_rate,
            penalty_rate_per_day,
            application_date,
            collateral_description,
            customers!inner(id, full_name, phone, id_number, photo_url, nik, date_of_birth, address),
            members(id, full_name, position, nik, date_of_birth, address, photo_url, phone)
          )
        `,
          { count: "exact" }
        ) as any;

      // Default view: only unpaid (exclude paid)
      query = query.neq("status", "paid");

      // Hide silenced installments UNLESS searching
      // When searching, show silenced installments so users can find them
      if (!searchQuery.trim()) {
        query = query.eq("is_silenced", false);
      }

      // Apply date filter (H-3 to overdue) ONLY when NOT searching
      if (!searchQuery.trim()) {
        query = query.lte("due_date", threeDaysFromNowStr);
      }

      // Apply sales filter
      if (allowedAppIds) {
        query = query.in("application_id", allowedAppIds);
      }

      // Apply member filter
      if (selectedMember !== "all") {
        query = query.eq("credit_applications.member_id", selectedMember);
      }

      // Client-side search for nested fields (avoid PostgREST nested OR issues)
      let finalData: any[] = [];
      let finalCount = 0;

      if (searchQuery.trim()) {
        // SERVER-SIDE SEARCH to avoid global cap and ensure consistent pagination
        const qRaw = searchQuery.trim();
        const q = qRaw; // keep case for better ilike matching

        // Find matching customers and applications first
        const [customersRes, appsRes] = await Promise.all([
          supabase
            .from("customers")
            .select("id")
            .or(
              `full_name.ilike.%${q}%,phone.ilike.%${q}%,id_number.ilike.%${q}%`
            ),
          supabase
            .from("credit_applications")
            .select("id")
            .ilike("application_number", `%${q}%`),
        ]);

        const customerIds = (customersRes.data || []).map((c: any) => c.id);
        const appIds = (appsRes.data || []).map((a: any) => a.id);

        // If no matches at all, short-circuit
        if (customerIds.length === 0 && appIds.length === 0) {
          return { installments: [], totalCount: 0, uniqueMembers: [] };
        }

        // Build filtered query using server-side conditions
        let searchQueryBuilder = query;
        if (appIds.length > 0 && customerIds.length > 0) {
          const appList = appIds.join(",");
          const custList = customerIds.join(",");
          // OR across base column and related column
          searchQueryBuilder = searchQueryBuilder.or(
            `application_id.in.(${appList}),credit_applications.customer_id.in.(${custList})`
          );
        } else if (appIds.length > 0) {
          searchQueryBuilder = searchQueryBuilder.in("application_id", appIds);
        } else {
          searchQueryBuilder = searchQueryBuilder.in(
            "credit_applications.customer_id",
            customerIds
          );
        }

        // Custom sorting: unpaid first, then partial, ordered by due_date
        const { data: allData, error: errS, count: countS } = await searchQueryBuilder
          .order("due_date", { ascending: true });
        
        if (errS) throw errS;
        
        // Sort: unpaid (paid_amount = 0) first, then partial (paid_amount > 0)
        const sortedData = (allData || []).sort((a, b) => {
          const aIsUnpaid = a.paid_amount === 0;
          const bIsUnpaid = b.paid_amount === 0;
          
          // Priority 1: Unpaid installments first
          if (aIsUnpaid && !bIsUnpaid) return -1;
          if (!aIsUnpaid && bIsUnpaid) return 1;
          
          // Priority 2: Within same payment status, order by due_date
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        });
        
        // Apply pagination after sorting
        const dataS = sortedData.slice(from, to + 1);
        if (errS) throw errS;

        finalData = dataS || [];
        finalCount = countS || 0;
        console.debug("[InstallmentsQuery] search mode (server)", {
          q,
          appIds: appIds.length,
          customerIds: customerIds.length,
          returned: finalData.length,
          totalCount: finalCount,
        });
      } else {
        // Default view: hanya tampilkan angsuran yang principal belum lunas
        // Angsuran dengan principal_paid = true (meski ada denda) tidak ditampilkan
        const { data: allDefaultData, error, count } = await query
          .or("principal_paid.is.null,principal_paid.eq.false")
          .order("due_date", { ascending: true });
        
        if (error) {
          console.error("[InstallmentsQuery] default mode error", error);
          throw error;
        }
        
        // Sort: unpaid (paid_amount = 0) first, then partial (paid_amount > 0)
        const sortedDefaultData = (allDefaultData || []).sort((a, b) => {
          const aIsUnpaid = a.paid_amount === 0;
          const bIsUnpaid = b.paid_amount === 0;
          
          // Priority 1: Unpaid installments first
          if (aIsUnpaid && !bIsUnpaid) return -1;
          if (!aIsUnpaid && bIsUnpaid) return 1;
          
          // Priority 2: Within same payment status, order by due_date
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        });
        
        // Apply pagination after sorting
        const data = sortedDefaultData.slice(from, to + 1);

        finalData = data || [];
        finalCount = count || 0;

        console.debug("[InstallmentsQuery] default mode", {
          from,
          to,
          returned: finalData.length,
          totalCount: finalCount,
          dateFilter: threeDaysFromNowStr,
          principalFilter: "principal_paid = false or null (exclude paid principal with penalty)"
        });
      }

      // Get unique members for filter - only members with active credits
      // Active credit means they have installments that are not fully paid
      const { data: activeMembersData } = await supabase
        .from("credit_applications")
        .select(`
          member_id,
          members!inner(id, full_name)
        `)
        .not("status", "eq", "rejected")
        .not("status", "eq", "completed");

      // Extract unique members
      const uniqueMembersMap = new Map();
      if (activeMembersData) {
        activeMembersData.forEach((app: any) => {
          if (app.members && app.member_id) {
            uniqueMembersMap.set(app.member_id, {
              id: app.members.id,
              full_name: app.members.full_name
            });
          }
        });
      }

      const uniqueMembers = Array.from(uniqueMembersMap.values()).sort((a, b) => 
        a.full_name.localeCompare(b.full_name)
      );

      return {
        installments: finalData,
        totalCount: finalCount,
        uniqueMembers,
      };
    },
  });
};

export const usePenaltyRate = () => {
  return useQuery({
    queryKey: ["penalty-rate"],
    queryFn: async () => {
      const { data } = await supabase.rpc("get_public_app_settings");
      return (data as any)?.penalty_rate_per_day || 2.0;
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });
};

export const useInvalidateInstallments = () => {
  const queryClient = useQueryClient();

  return () => {
    queryClient.invalidateQueries({ queryKey: ["installments"] });
    queryClient.invalidateQueries({ queryKey: ["penalty-rate"] });
  };
};
