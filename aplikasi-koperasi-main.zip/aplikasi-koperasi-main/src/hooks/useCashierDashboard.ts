import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { startOfDay, startOfWeek, startOfMonth, startOfYear, format, subDays } from "date-fns";

export const useCashierDashboard = () => {
  return useQuery({
    queryKey: ["cashier-dashboard"],
    queryFn: async () => {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Get member info
      const { data: member } = await supabase
        .from("members")
        .select("id, full_name, position")
        .eq("user_id", user.id)
        .single();

      if (!member) throw new Error("Member not found");

      const memberId = member.id;
      const today = startOfDay(new Date());
      const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
      const monthStart = startOfMonth(new Date());

      // Get all payments created by this cashier (created_by stores auth.uid, not member_id)
      const { data: allPayments } = await supabase
        .from("payments")
        .select(`
          *,
          installments!inner(
            *,
            credit_applications!inner(
              application_number,
              customers!inner(
                full_name,
                phone
              )
            )
          )
        `)
        .eq("created_by", user.id)
        .order("payment_date", { ascending: false });

      // Calculate statistics
      const todayPayments = allPayments?.filter(p => 
        new Date(p.payment_date) >= today
      ) || [];
      
      const weekPayments = allPayments?.filter(p => 
        new Date(p.payment_date) >= weekStart
      ) || [];
      
      const monthPayments = allPayments?.filter(p => 
        new Date(p.payment_date) >= monthStart
      ) || [];

      const todayTotal = todayPayments.reduce((sum, p) => sum + Number(p.amount), 0);
      const weekTotal = weekPayments.reduce((sum, p) => sum + Number(p.amount), 0);
      const monthTotal = monthPayments.reduce((sum, p) => sum + Number(p.amount), 0);

      // Get recent transactions from last 7 days
      const sevenDaysAgo = subDays(new Date(), 7);
      const recentTransactions = (allPayments || [])
        .filter(payment => new Date(payment.payment_date) >= sevenDaysAgo)
        .map(payment => ({
          id: payment.id,
          date: payment.payment_date,
          amount: Number(payment.amount),
          method: payment.payment_method,
          reference: payment.reference_number,
          customer: payment.installments?.credit_applications?.customers?.full_name || "N/A",
          application: payment.installments?.credit_applications?.application_number || "N/A",
          installmentNumber: payment.installments?.installment_number || 0,
        }));

      // Group by payment method
      const methodStats = (allPayments || []).reduce((acc, p) => {
        const method = p.payment_method;
        if (!acc[method]) {
          acc[method] = { count: 0, total: 0 };
        }
        acc[method].count++;
        acc[method].total += Number(p.amount);
        return acc;
      }, {} as Record<string, { count: number; total: number }>);

      // Chart data for last 7 days
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = subDays(new Date(), 6 - i);
        return format(date, "yyyy-MM-dd");
      });

      const last7DaysData = last7Days.map(date => {
        const dayPayments = (allPayments || []).filter(p => 
          format(new Date(p.payment_date), "yyyy-MM-dd") === date
        );
        const total = dayPayments.reduce((sum, p) => sum + Number(p.amount), 0);
        return {
          date: format(new Date(date), "dd/MM"),
          fullDate: date,
          total,
          count: dayPayments.length,
        };
      });

      // Chart data for last 30 days
      const last30Days = Array.from({ length: 30 }, (_, i) => {
        const date = subDays(new Date(), 29 - i);
        return format(date, "yyyy-MM-dd");
      });

      const last30DaysData = last30Days.map(date => {
        const dayPayments = (allPayments || []).filter(p => 
          format(new Date(p.payment_date), "yyyy-MM-dd") === date
        );
        const total = dayPayments.reduce((sum, p) => sum + Number(p.amount), 0);
        return {
          date: format(new Date(date), "dd/MM"),
          fullDate: date,
          total,
          count: dayPayments.length,
        };
      });

      // Chart data for year to date (monthly)
      const yearStart = startOfYear(new Date());
      const currentMonth = new Date().getMonth();
      const monthsInYear = Array.from({ length: currentMonth + 1 }, (_, i) => {
        const date = new Date(yearStart);
        date.setMonth(i);
        return format(date, "yyyy-MM");
      });

      const yearToDateData = monthsInYear.map(month => {
        const monthPayments = (allPayments || []).filter(p => 
          format(new Date(p.payment_date), "yyyy-MM") === month
        );
        const total = monthPayments.reduce((sum, p) => sum + Number(p.amount), 0);
        return {
          date: format(new Date(month), "MMM yyyy"),
          fullDate: month,
          total,
          count: monthPayments.length,
        };
      });

      return {
        member,
        stats: {
          today: {
            count: todayPayments.length,
            total: todayTotal,
          },
          week: {
            count: weekPayments.length,
            total: weekTotal,
          },
          month: {
            count: monthPayments.length,
            total: monthTotal,
          },
          allTime: {
            count: allPayments?.length || 0,
            total: allPayments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0,
          },
        },
        recentTransactions,
        methodStats,
        chartData: {
          last7Days: last7DaysData,
          last30Days: last30DaysData,
          yearToDate: yearToDateData,
        },
      };
    },
    staleTime: 1000 * 60 * 2, // 2 minutes
  });
};
