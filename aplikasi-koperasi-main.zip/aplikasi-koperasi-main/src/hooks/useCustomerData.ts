import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

// Cache untuk menyimpan customer ID agar tidak perlu query berulang
let cachedCustomerId: string | null = null;
let cachedUserId: string | null = null;

export const useCustomerData = () => {
  const [customerId, setCustomerId] = useState<string | null>(cachedCustomerId);
  const [loading, setLoading] = useState(!cachedCustomerId);

  useEffect(() => {
    const loadCustomerId = async () => {
      // Jika sudah ada cache, gunakan cache
      if (cachedCustomerId) {
        setCustomerId(cachedCustomerId);
        setLoading(false);
        return;
      }

      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          setLoading(false);
          return;
        }

        // Jika user ID sama dengan yang di-cache, gunakan cached customer ID
        if (cachedUserId === user.id && cachedCustomerId) {
          setCustomerId(cachedCustomerId);
          setLoading(false);
          return;
        }

        // Query customer ID
        const { data: customer, error } = await supabase
          .from('customers')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) throw error;

        if (customer) {
          // Simpan ke cache
          cachedCustomerId = customer.id;
          cachedUserId = user.id;
          setCustomerId(customer.id);
        }
      } catch (error) {
        console.error('Error loading customer ID:', error);
      } finally {
        setLoading(false);
      }
    };

    loadCustomerId();
  }, []);

  return { customerId, loading };
};

// Function untuk clear cache (dipanggil saat logout)
export const clearCustomerCache = () => {
  cachedCustomerId = null;
  cachedUserId = null;
};
