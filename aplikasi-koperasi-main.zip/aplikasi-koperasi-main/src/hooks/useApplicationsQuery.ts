import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseApplicationsParams {
  searchQuery?: string;
  memberFilter?: string;
  page?: number;
  itemsPerPage?: number;
}

export const useApplicationsQuery = ({ searchQuery = "", memberFilter = "all", page = 1, itemsPerPage = 20 }: UseApplicationsParams = {}) => {
  return useQuery({
    queryKey: ["applications", searchQuery, memberFilter, page],
    queryFn: async () => {
      const from = (page - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      // Get current user for role filtering
      const { data: { user } } = await supabase.auth.getUser();
      let currentMemberId = null;
      let isSalesUser = false;
      let relatedCustomerIds: string[] = [];

      if (user) {
        const { data: roleData } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .maybeSingle();

        isSalesUser = roleData?.role === "sales";

        if (isSalesUser) {
          const { data: memberData } = await supabase
            .from("members")
            .select("id")
            .eq("user_id", user.id)
            .maybeSingle();

          currentMemberId = memberData?.id;

          const { data: customersData } = await supabase
            .from("customers")
            .select("id")
            .eq("created_by", currentMemberId);

          relatedCustomerIds = customersData?.map((c) => c.id) || [];
        }
      }

      // Build query with filters
      let query = supabase
        .from("credit_applications")
        .select(`
          *,
          customers!inner(id, full_name, id_number, phone, photo_url, credit_score, nik, date_of_birth, address, restoration_status),
          members!inner(id, full_name, position, nik, date_of_birth, address, photo_url, phone)
        `, { count: "exact" });

      // Apply sales filter
      if (isSalesUser && currentMemberId) {
        if (relatedCustomerIds.length > 0) {
          query = query.or(
            `member_id.eq.${currentMemberId},customer_id.in.(${relatedCustomerIds.join(",")})`
          );
        } else {
          query = query.eq("member_id", currentMemberId);
        }
      }

      // Apply search filter - for nested relationships, use foreignTable option
      if (searchQuery.trim()) {
        query = query.or(
          `full_name.ilike.%${searchQuery}%,phone.ilike.%${searchQuery}%`,
          { foreignTable: 'customers' }
        );
      }

      // Apply member filter
      if (memberFilter && memberFilter !== "all") {
        query = query.eq("member_id", memberFilter);
      }

      // Apply pagination and sorting
      const { data, error, count } = await query
        .order("application_date", { ascending: false })
        .range(from, to);

      if (error) throw error;

      return {
        applications: data || [],
        totalCount: count || 0,
      };
    },
  });
};

export const useApplicationStats = () => {
  return useQuery({
    queryKey: ["application-stats"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      let currentMemberId = null;
      let isSalesUser = false;

      if (user) {
        const { data: roleData } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .maybeSingle();

        isSalesUser = roleData?.role === "sales";

        if (isSalesUser) {
          const { data: memberData } = await supabase
            .from("members")
            .select("id")
            .eq("user_id", user.id)
            .maybeSingle();

          currentMemberId = memberData?.id;
        }
      }

      let query = supabase.from("credit_applications").select("status, amount_approved");

      if (isSalesUser && currentMemberId) {
        query = query.eq("member_id", currentMemberId);
      }

      const { data, error } = await query;

      if (error) throw error;

      const stats = {
        pending: { count: 0, amount: 0 },
        unpaid: { count: 0, amount: 0 },
        paid: { count: 0, amount: 0 },
        rejected: { count: 0, amount: 0 },
        disbursed: { count: 0, amount: 0 },
        not_disbursed: { count: 0, amount: 0 },
      };

      data?.forEach((app: any) => {
        const amount = app.amount_approved || 0;
        const status = app.status;

        if (status === "pending") {
          stats.pending.count++;
          stats.pending.amount += amount;
        } else if (status === "approved") {
          stats.unpaid.count++;
          stats.unpaid.amount += amount;
        } else if (status === "rejected") {
          stats.rejected.count++;
          stats.rejected.amount += amount;
        } else if (status === "disbursed") {
          stats.disbursed.count++;
          stats.disbursed.amount += amount;
        } else if (status === "paid") {
          stats.paid.count++;
          stats.paid.amount += amount;
        }

        if (app.is_disbursed) {
          stats.disbursed.count++;
          stats.disbursed.amount += amount;
        } else {
          stats.not_disbursed.count++;
          stats.not_disbursed.amount += amount;
        }
      });

      return stats;
    },
  });
};

export const useInvalidateApplications = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["applications"] });
    queryClient.invalidateQueries({ queryKey: ["application-stats"] });
  };
};
