import { useCallback, useRef } from "react";

export function useSuccessFeedback() {
  const audioContextRef = useRef<AudioContext | null>(null);

  const playSuccessSound = useCallback(() => {
    try {
      // Create or reuse AudioContext
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioContextRef.current;
      
      // Resume if suspended (required for some browsers)
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const now = ctx.currentTime;

      // Create a pleasant "success" chime with two notes
      const createNote = (frequency: number, startTime: number, duration: number) => {
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(frequency, startTime);
        
        // Envelope: quick attack, smooth decay
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.3, startTime + 0.02);
        gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + duration);
      };

      // Play two ascending notes for a pleasant "ding-ding" success sound
      createNote(880, now, 0.15);        // A5
      createNote(1318.5, now + 0.1, 0.2); // E6
      
    } catch (error) {
      console.warn('Could not play success sound:', error);
    }
  }, []);

  const triggerHaptic = useCallback(() => {
    try {
      // Check if vibration API is available
      if ('vibrate' in navigator) {
        // Short vibration pattern: quick double pulse
        navigator.vibrate([50, 30, 50]);
      }
    } catch (error) {
      console.warn('Could not trigger haptic feedback:', error);
    }
  }, []);

  const triggerSuccessFeedback = useCallback(() => {
    playSuccessSound();
    triggerHaptic();
  }, [playSuccessSound, triggerHaptic]);

  return {
    playSuccessSound,
    triggerHaptic,
    triggerSuccessFeedback,
  };
}
