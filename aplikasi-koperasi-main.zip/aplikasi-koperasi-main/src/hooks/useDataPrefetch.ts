import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "./useUserRole";

export const useDataPrefetch = () => {
  const queryClient = useQueryClient();
  const { role, isOwner, isAdmin, isSales } = useUserRole();
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!role) return;

    const prefetchData = async () => {
      console.log('🔄 Starting background data prefetch...');

      try {
        // 1. Members & Customers (all roles)
        await Promise.all([
          queryClient.prefetchQuery({
            queryKey: ["members"],
            queryFn: async () => {
              const { data } = await supabase
                .from("members")
                .select("*")
                .order("created_at", { ascending: false });
              return data || [];
            },
            staleTime: 1000 * 60 * 5,
          }),
          queryClient.prefetchQuery({
            queryKey: ["customers"],
            queryFn: async () => {
              const { data: customers } = await supabase
                .from("customers")
                .select(`
                  *,
                  members:created_by(id, full_name, member_number)
                `)
                .order("created_at", { ascending: false });

              if (!customers) return [];

              // Fetch blocked customers
              const { data: blockedCustomers } = await supabase
                .from("blocked_customers")
                .select("customer_id");

              const blockedIds = new Set(blockedCustomers?.map(b => b.customer_id) || []);

              return customers.filter(c => !blockedIds.has(c.id));
            },
            staleTime: 1000 * 60 * 5,
          }),
        ]);
        console.log('✅ Prefetched: Members & Customers');

        // 2. Installments & Payments (all roles) - moved up in priority
        await Promise.all([
          queryClient.prefetchQuery({
            queryKey: ["installments"],
            queryFn: async () => {
              const { data } = await supabase
                .from("installments")
                .select(`
                  *,
                  credit_applications(
                    application_number,
                    customers(id, full_name, phone),
                    members(id, full_name)
                  )
                `)
                .order("due_date", { ascending: true });
              return data || [];
            },
            staleTime: 1000 * 60 * 5,
          }),
          queryClient.prefetchQuery({
            queryKey: ["payments"],
            queryFn: async () => {
              const { data } = await supabase
                .from("payments")
                .select(`
                  *,
                  credit_applications(
                    application_number,
                    customers(id, full_name),
                    members(id, full_name)
                  ),
                  installments(installment_number, due_date)
                `)
                .order("payment_date", { ascending: false });
              return data || [];
            },
            staleTime: 1000 * 60 * 5,
          }),
        ]);
        console.log('✅ Prefetched: Installments & Payments');

        // 3. Verifications (owner/admin only)
        if (isOwner || isAdmin) {
          await Promise.all([
            queryClient.prefetchQuery({
              queryKey: ["pending-customers"],
              queryFn: async () => {
                const { data } = await supabase
                  .from("customers")
                  .select(`
                    *,
                    members:created_by(full_name, member_number)
                  `)
                  .eq("status", "pending")
                  .order("created_at", { ascending: false });
                return data || [];
              },
              staleTime: 1000 * 60 * 5,
            }),
            queryClient.prefetchQuery({
              queryKey: ["pending-applications"],
              queryFn: async () => {
                const { data } = await supabase
                  .from("credit_applications")
                  .select(`
                    *,
                    customers(id, full_name, phone, id_number),
                    members(id, full_name, member_number)
                  `)
                  .eq("status", "pending")
                  .order("application_date", { ascending: false });
                return data || [];
              },
              staleTime: 1000 * 60 * 5,
            }),
            queryClient.prefetchQuery({
              queryKey: ["restoration-requests"],
              queryFn: async () => {
                const { data } = await supabase
                  .from("customer_restoration_requests")
                  .select(`
                    *,
                    customers(id, full_name, phone, nik),
                    members:reviewed_by(full_name)
                  `)
                  .order("requested_at", { ascending: false });
                return data || [];
              },
              staleTime: 1000 * 60 * 5,
            }),
            queryClient.prefetchQuery({
              queryKey: ["change-requests"],
              queryFn: async () => {
                const { data } = await supabase
                  .from("customer_change_requests")
                  .select(`
                    *,
                    customers(id, full_name, phone)
                  `)
                  .order("created_at", { ascending: false });
                return data || [];
              },
              staleTime: 1000 * 60 * 5,
            }),
            queryClient.prefetchQuery({
              queryKey: ["withdrawal-requests"],
              queryFn: async () => {
                const { data } = await supabase
                  .from("member_balance_withdrawals")
                  .select(`
                    *,
                    members(id, full_name, member_number)
                  `)
                  .order("requested_at", { ascending: false });
                return data || [];
              },
              staleTime: 1000 * 60 * 5,
            }),
          ]);
        console.log('✅ Prefetched: Verifications');
        }

        // 4. Blocked Customers (owner/admin only)
        if (isOwner || isAdmin) {
          await queryClient.prefetchQuery({
            queryKey: ["blocked-customers"],
            queryFn: async () => {
              const { data } = await supabase
                .from("blocked_customers")
                .select(`
                  *,
                  customers(
                    id,
                    full_name,
                    phone,
                    id_number,
                    nik,
                    address
                  ),
                  credit_applications(
                    id,
                    application_number,
                    amount_approved
                  )
                `)
                .order("blocked_at", { ascending: false });
              return data || [];
            },
            staleTime: 1000 * 60 * 5,
          });
        console.log('✅ Prefetched: Blocked Customers');
        }

        // 5. Reports (all roles)
        await queryClient.prefetchQuery({
          queryKey: ["reports-financial"],
          queryFn: async () => {
            const { data, error } = await supabase.rpc("get_reports_financial_stats");
            if (error) throw error;
            return data;
          },
          staleTime: 1000 * 60 * 5,
        });
        console.log('✅ Prefetched: Reports');

        // 6. Member Balance (sales only)
        if (isSales) {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            const { data: member } = await supabase
              .from("members")
              .select("id")
              .eq("user_id", user.id)
              .single();

            if (member) {
              await queryClient.prefetchQuery({
                queryKey: ["member-balance", member.id],
                queryFn: async () => {
                  const { data, error } = await supabase.rpc("get_member_balance_detailed", {
                    p_member_id: member.id,
                  });
                  if (error) throw error;
                  return data?.[0] || { regular_balance: 0, thr_balance: 0, total_balance: 0 };
                },
                staleTime: 1000 * 60 * 5,
              });
              console.log('✅ Prefetched: Member Balance');
            }
          }
        }

        console.log('✅ All data prefetch completed!');
      } catch (error) {
        console.error('❌ Prefetch error:', error);
      }
    };

    // Start prefetch after a short delay to not block initial page load
    const timer = setTimeout(() => {
      prefetchData();
    }, 2000);

    // Setup auto-refresh every 5 minutes
    refreshIntervalRef.current = setInterval(() => {
      console.log('🔄 Auto-refreshing cached data...');
      
      // Invalidate all queries to trigger background refetch
      const queryKeys = [
        ["members"],
        ["customers"],
        ["installments"],
        ["payments"],
        ["reports-financial"]
      ];

      // Add role-specific queries
      if (isOwner || isAdmin) {
        queryKeys.push(
          ["pending-customers"],
          ["pending-applications"],
          ["restoration-requests"],
          ["change-requests"],
          ["withdrawal-requests"],
          ["blocked-customers"]
        );
      }

      // Invalidate all queries to trigger background refetch
      queryKeys.forEach(key => {
        queryClient.invalidateQueries({ queryKey: key });
      });

      console.log('✅ Auto-refresh triggered for all cached data');
    }, 5 * 60 * 1000); // 5 minutes

    return () => {
      clearTimeout(timer);
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, [role, isOwner, isAdmin, isSales, queryClient]);
};
