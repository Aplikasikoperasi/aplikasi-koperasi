import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseChangeRequestsParams {
  memberId?: string | null;
}

export const useChangeRequestsQuery = ({ memberId }: UseChangeRequestsParams = {}) => {
  return useQuery({
    queryKey: ["change-requests", memberId],
    queryFn: async () => {
      let query = supabase
        .from("customer_change_requests")
        .select(`
          *,
          customers!inner(
            id,
            id_number,
            full_name,
            phone,
            photo_url
          )
        `)
        .eq("status", "pending")
        .order("created_at", { ascending: false });

      // Filter by member for sales users
      if (memberId) {
        const { data: customerIds } = await supabase
          .from("customers")
          .select("id")
          .eq("created_by", memberId);

        if (customerIds && customerIds.length > 0) {
          query = query.in("customer_id", customerIds.map(c => c.id));
        } else {
          return [];
        }
      }

      const { data, error } = await query;

      if (error) throw error;

      // Batch fetch requester info
      const requesterIds = [...new Set((data || []).map((r: any) => r.requested_by).filter(Boolean))];
      const requestersMap = new Map();

      if (requesterIds.length > 0) {
        const { data: membersData } = await supabase
          .from("members")
          .select("id, full_name, position")
          .in("user_id", requesterIds);

        membersData?.forEach((m: any) => requestersMap.set(m.user_id, m));
      }

      const requestsWithRequester = (data || []).map((request: any) => ({
        ...request,
        requester: request.requested_by ? requestersMap.get(request.requested_by) : null,
      }));

      return requestsWithRequester;
    },
  });
};

export const useInvalidateChangeRequests = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["change-requests"] });
  };
};
