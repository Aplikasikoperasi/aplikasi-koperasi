import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const usePendingCustomersQuery = () => {
  return useQuery({
    queryKey: ["pending-customers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customers")
        .select("*")
        .eq("status", "pending")
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Batch fetch creator info
      const creatorIds = [...new Set((data || []).map(c => c.created_by).filter(Boolean))];
      const creatorsMap = new Map();

      if (creatorIds.length > 0) {
        const { data: membersData } = await supabase
          .from("members")
          .select("id, full_name, position")
          .in("id", creatorIds);

        membersData?.forEach(m => creatorsMap.set(m.id, m));
      }

      const customersWithCreator = (data || []).map(customer => ({
        ...customer,
        creator: customer.created_by ? creatorsMap.get(customer.created_by) : null,
      }));

      return customersWithCreator;
    },
  });
};

export const useInvalidatePendingCustomers = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["pending-customers"] });
  };
};
