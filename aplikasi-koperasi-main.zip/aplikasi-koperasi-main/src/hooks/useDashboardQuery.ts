import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useDashboardQuery = () => {
  return useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_financial_dashboard_summary");

      if (error) throw error;

      return data || {
        overall_disbursed_amount: 0,
        overall_total_payments: 0,
        ongoing_installments_principal: 0,
        ongoing_installments_interest: 0,
        total_installments_principal: 0,
        total_installments_interest: 0,
        overall_net_cash_flow: 0,
        monthly_disbursed_amount: 0,
        monthly_paid_installments_principal: 0,
        monthly_paid_installments_interest: 0,
        monthly_unpaid_installments_principal: 0,
        monthly_unpaid_installments_interest: 0,
        monthly_overdue_principal: 0,
        monthly_overdue_interest: 0,
        monthly_overdue_penalty: 0,
        monthly_interest_income: 0,
        monthly_net_cash_flow: 0,
        paid_penalties: 0,
        unpaid_penalties: 0,
        total_admin_fees: 0,
        overdue_count: 0,
      };
    },
    staleTime: 1000 * 60 * 2, // 2 minutes
  });
};
