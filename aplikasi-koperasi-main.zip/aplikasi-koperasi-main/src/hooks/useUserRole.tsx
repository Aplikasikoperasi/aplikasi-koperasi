// This hook is now deprecated - use the context provider instead
// Re-export from context for backward compatibility
import { useUserRole as useUserRoleContext, type UserRole } from "@/contexts/UserRoleContext";

export type { UserRole };
export const useUserRole = useUserRoleContext;
