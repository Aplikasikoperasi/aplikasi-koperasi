import { useState, useEffect } from 'react';

type ViewMode = 'card' | 'table';

// Version key to force reset when default changes
const PREFERENCE_VERSION = 'v2';

export function useViewPreference(pageKey: string) {
  const storageKey = `view-preference-${pageKey}`;
  const versionKey = `view-preference-version`;
  
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    // Check if we need to reset due to version change
    const savedVersion = localStorage.getItem(versionKey);
    if (savedVersion !== PREFERENCE_VERSION) {
      // Clear old preferences and set new version
      localStorage.removeItem(storageKey);
      localStorage.setItem(versionKey, PREFERENCE_VERSION);
      return 'card'; // New default
    }
    
    const saved = localStorage.getItem(storageKey);
    return (saved as ViewMode) || 'card';
  });

  useEffect(() => {
    localStorage.setItem(storageKey, viewMode);
  }, [viewMode, storageKey]);

  const toggleView = () => {
    setViewMode(prev => prev === 'table' ? 'card' : 'table');
  };

  return { viewMode, setViewMode, toggleView };
}
