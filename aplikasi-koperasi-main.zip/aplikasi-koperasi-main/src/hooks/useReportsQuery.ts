import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseReportsParams {
  selectedMonth: string;
  selectedYear: string;
}

export const useReportsQuery = ({ selectedMonth, selectedYear }: UseReportsParams) => {
  return useQuery({
    queryKey: ["reports", selectedMonth, selectedYear],
    queryFn: async () => {
      // Use RPC to get aggregated member performance data from database
      // This avoids fetchAllRows and performs aggregation directly in the database
      const { data: memberPerformanceData, error: perfError } = await supabase.rpc(
        "get_member_performance",
        {
          p_month: parseInt(selectedMonth),
          p_year: parseInt(selectedYear),
        }
      );

      if (perfError) throw perfError;

      // Transform the RPC result to match expected format
      const memberPerformance = (memberPerformanceData || []).map((row: any) => ({
        member_id: row.member_id,
        member_name: row.member_name,
        applications: Number(row.applications_count || 0),
        disbursed: Number(row.total_disbursed || 0),
        collected: Number(row.total_collected || 0),
      }));

      // Calculate basic stats from aggregated data
      const total_disbursed = memberPerformance.reduce((sum: number, m: any) => sum + m.disbursed, 0);
      const total_collected = memberPerformance.reduce((sum: number, m: any) => sum + m.collected, 0);

      const stats = {
        total_disbursed,
        total_collected,
        total_principal_paid: 0,
        total_interest_paid: 0,
        total_penalty_paid: 0,
        total_admin_fee: 0,
        total_outstanding_principal: 0,
        total_outstanding_interest: 0,
        total_outstanding_penalty: 0,
      };

      return {
        stats,
        memberPerformance,
      };
    },
    staleTime: 1000 * 60 * 5, // 5 minutes - cache for 5 minutes
  });
};
