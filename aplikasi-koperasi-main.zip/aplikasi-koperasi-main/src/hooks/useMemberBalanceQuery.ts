import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";

export const useMemberBalanceQuery = () => {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["member-balance"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not found");

      // Get member ID
      const { data: member, error: memberError } = await supabase
        .from("members")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();

      if (memberError) throw memberError;
      if (!member) throw new Error("Member not found");

      // Get balance details
      const { data: balanceData, error: balanceError } = await supabase.rpc(
        "get_member_balance_detailed",
        { p_member_id: member.id }
      );

      if (balanceError) throw balanceError;

      // Handle both array and single object responses
      const balanceObj = Array.isArray(balanceData) 
        ? balanceData[0] 
        : balanceData;
      
      const balance = balanceObj || {
        regular_balance: 0,
        thr_balance: 0,
        total_balance: 0,
      };

      // Get available balance (not held)
      const { data: availableData, error: availableError } = await supabase.rpc(
        "get_member_available_balance",
        { p_member_id: member.id }
      );

      if (availableError) throw availableError;

      // Get monthly balances
      const { data: monthlyData, error: monthlyError } = await supabase
        .from("member_monthly_balance_summary")
        .select("*")
        .eq("member_id", member.id)
        .order("period_month", { ascending: false })
        .limit(12);

      if (monthlyError) throw monthlyError;

      // Get transactions
      const { data: transactionsData, error: transactionsError } = await supabase
        .from("member_balance_transactions")
        .select("*")
        .eq("member_id", member.id)
        .order("created_at", { ascending: false })
        .limit(50);

      if (transactionsError) throw transactionsError;

      // Get withdrawal requests
      const { data: withdrawalsData, error: withdrawalsError } = await supabase
        .from("member_balance_withdrawals")
        .select("*")
        .eq("member_id", member.id)
        .order("requested_at", { ascending: false });

      if (withdrawalsError) throw withdrawalsError;

      // Get incentive settings
      const { data: incentiveSettings, error: incentiveError } = await supabase
        .from("incentive_settings")
        .select("*")
        .maybeSingle();

      if (incentiveError) throw incentiveError;

      return {
        memberId: member.id,
        regularBalance: balance.regular_balance || 0,
        thrBalance: balance.thr_balance || 0,
        totalBalance: balance.total_balance || 0,
        availableBalance: availableData || 0,
        monthlyBalances: monthlyData || [],
        transactions: transactionsData || [],
        withdrawals: withdrawalsData || [],
        incentiveSettings: incentiveSettings || null,
      };
    },
    staleTime: 1000 * 30, // 30 seconds - balance data should be relatively fresh
  });

  // Setup realtime subscription for withdrawals
  useEffect(() => {
    const memberId = query.data?.memberId;
    if (!memberId) return;

    const channel = supabase
      .channel('member-balance-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'member_balance_withdrawals',
          filter: `member_id=eq.${memberId}`
        },
        () => {
          // Invalidate query to refetch data
          queryClient.invalidateQueries({ queryKey: ["member-balance"] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'member_balance_transactions',
          filter: `member_id=eq.${memberId}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ["member-balance"] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.data?.memberId, queryClient]);

  return query;
};

export const useInvalidateMemberBalance = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["member-balance"] });
  };
};
