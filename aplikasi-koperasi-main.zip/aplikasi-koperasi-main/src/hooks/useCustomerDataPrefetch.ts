import { useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

// Cache duration: 5 minutes
const CACHE_DURATION = 5 * 60 * 1000;

export interface PrefetchedCustomerData {
  penaltyRate: number;
  creditScoreBreakdown: {
    total_installments: number;
    on_time_no_penalty: number;
    paid_with_penalty: number;
    overdue_no_payment: number;
    partial_1_24: number;
    partial_25_49: number;
    partial_50_74: number;
    partial_75_plus: number;
    upcoming_installments: number;
    due_today: number;
  } | null;
  achievementBadge: {
    customer_id: string;
    badge_level: string;
    badge_name: string;
    badge_description: string;
    total_payments: number;
    total_on_time_payments: number;
    consecutive_on_time_payments: number;
    on_time_percentage: number;
  } | null;
  activeApplications: Array<{
    id: string;
    application_number: string;
    amount_approved: number;
    tenor_months: number;
    interest_rate: number;
    status: string;
    application_date: string;
    approved_at: string | null;
    disbursed_at: string | null;
    member: {
      id: string;
      full_name: string;
      member_number: string | null;
    } | null;
    installment_progress: {
      total: number;
      paid: number;
      unpaid: number;
      overdue: number;
      partial: number;
    };
  }>;
  overdueDetails: {
    totalOverdueAmount: number;
    totalPenaltyAmount: number;
    overdueInstallments: Array<{
      id: string;
      installment_number: number;
      due_date: string;
      total_amount: number;
      paid_amount: number;
      remaining_amount: number;
      frozen_penalty: number | null;
      current_penalty: number;
      status: string;
      application_number: string;
      amount_approved: number;
      days_overdue: number;
    }>;
  } | null;
}

interface CacheEntry {
  data: PrefetchedCustomerData;
  timestamp: number;
}

export function useCustomerDataPrefetch() {
  const prefetchCache = useRef<Map<string, CacheEntry>>(new Map());
  const prefetchingRef = useRef<Set<string>>(new Set());

  const prefetchCustomerData = useCallback(async (customerId: string): Promise<void> => {
    // Check if already prefetching
    if (prefetchingRef.current.has(customerId)) {
      return;
    }

    // Check cache
    const cached = prefetchCache.current.get(customerId);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      return;
    }

    prefetchingRef.current.add(customerId);

    try {
      const { data, error } = await supabase.functions.invoke("customer-detail", {
        body: { customerId },
      });

      if (error) throw error;

      if (data) {
        prefetchCache.current.set(customerId, {
          data: data as unknown as PrefetchedCustomerData,
          timestamp: Date.now(),
        });
      }
    } catch (error) {
      console.error("Error prefetching customer data:", error);
    } finally {
      prefetchingRef.current.delete(customerId);
    }
  }, []);

  const getCachedData = useCallback((customerId: string): PrefetchedCustomerData | null => {
    const cached = prefetchCache.current.get(customerId);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      return cached.data;
    }
    return null;
  }, []);

  const clearCache = useCallback((customerId?: string) => {
    if (customerId) {
      prefetchCache.current.delete(customerId);
    } else {
      prefetchCache.current.clear();
    }
  }, []);

  return {
    prefetchCustomerData,
    getCachedData,
    clearCache,
  };
}
