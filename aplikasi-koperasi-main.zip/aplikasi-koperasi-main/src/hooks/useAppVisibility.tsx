import { useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';

interface UseAppVisibilityOptions {
  onBecomeVisible?: () => void;
  onBecomeHidden?: () => void;
  refreshOnVisible?: boolean;
}

// Store session timestamp in localStorage to persist across app restarts
const SESSION_TIMESTAMP_KEY = 'app_last_active_timestamp';
const SESSION_MAX_BACKGROUND_TIME = 15 * 60 * 1000; // 15 minutes - session stays valid in background

function getLastActiveTimestamp(): number {
  try {
    const stored = localStorage.getItem(SESSION_TIMESTAMP_KEY);
    return stored ? parseInt(stored, 10) : Date.now();
  } catch {
    return Date.now();
  }
}

function setLastActiveTimestamp(timestamp: number): void {
  try {
    localStorage.setItem(SESSION_TIMESTAMP_KEY, timestamp.toString());
  } catch {
    // localStorage might not be available
  }
}

export function useAppVisibility(options: UseAppVisibilityOptions = {}) {
  const { onBecomeVisible, onBecomeHidden, refreshOnVisible = true } = options;
  const queryClient = useQueryClient();
  const lastActiveRef = useRef<number>(getLastActiveTimestamp());
  const isProcessingRef = useRef(false);

  // Simple session check - non-blocking
  const checkSession = useCallback(async (): Promise<boolean> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      return !!session;
    } catch {
      return false;
    }
  }, []);

  // Lightweight refresh - just invalidate queries, don't block
  const refreshData = useCallback(() => {
    if (!refreshOnVisible) return;
    
    // Use requestIdleCallback if available, otherwise setTimeout
    const scheduleRefresh = () => {
      try {
        queryClient.invalidateQueries();
        console.log('[AppVisibility] Data refresh scheduled');
      } catch (err) {
        console.warn('[AppVisibility] Data refresh warning:', err);
      }
    };

    if ('requestIdleCallback' in window) {
      (window as any).requestIdleCallback(scheduleRefresh, { timeout: 2000 });
    } else {
      setTimeout(scheduleRefresh, 100);
    }
  }, [queryClient, refreshOnVisible]);

  const handleVisibilityChange = useCallback(() => {
    const isVisible = document.visibilityState === 'visible';
    const now = Date.now();
    const idleTime = now - lastActiveRef.current;

    if (isVisible) {
      console.log(`[AppVisibility] App became visible after ${Math.round(idleTime / 1000)}s`);

      // Prevent multiple simultaneous processing
      if (isProcessingRef.current) {
        console.log('[AppVisibility] Already processing, skipping...');
        return;
      }

      // Check if we've been in background too long (> 15 minutes)
      if (idleTime > SESSION_MAX_BACKGROUND_TIME) {
        console.log('[AppVisibility] Session expired due to long background time');
        // Don't block - just redirect
        window.location.href = '/auth';
        return;
      }

      // For shorter background times (> 2 minutes), do a lightweight refresh
      const STALE_THRESHOLD = 2 * 60 * 1000; // 2 minutes (increased from 30s)

      if (idleTime > STALE_THRESHOLD) {
        isProcessingRef.current = true;
        
        // Use setTimeout to not block the visibility event
        setTimeout(async () => {
          try {
            const hasSession = await checkSession();
            
            if (hasSession) {
              refreshData();
            } else {
              // Session lost - redirect to auth
              console.log('[AppVisibility] Session lost, redirecting...');
              window.location.href = '/auth';
            }
          } catch (err) {
            console.warn('[AppVisibility] Resume check failed:', err);
          } finally {
            isProcessingRef.current = false;
          }
        }, 100);
      }

      // Update last active
      lastActiveRef.current = now;
      setLastActiveTimestamp(now);

      onBecomeVisible?.();
    } else {
      // App going to background - save timestamp
      lastActiveRef.current = now;
      setLastActiveTimestamp(now);
      onBecomeHidden?.();
    }
  }, [onBecomeVisible, onBecomeHidden, checkSession, refreshData]);

  const handleOnline = useCallback(() => {
    console.log('[AppVisibility] Network came online');
    // Just refresh data, don't do heavy reconnection
    refreshData();
  }, [refreshData]);

  // Handle page show event (important for mobile back-forward cache)
  const handlePageShow = useCallback(
    (event: PageTransitionEvent) => {
      if (!event.persisted) return;

      console.log('[AppVisibility] Page restored from bfcache');

      const now = Date.now();
      const idleTime = now - getLastActiveTimestamp();

      // If restored from bfcache after more than 15 minutes, force re-auth
      if (idleTime > SESSION_MAX_BACKGROUND_TIME) {
        console.log('[AppVisibility] bfcache restore after long idle, redirecting to auth...');
        window.location.href = '/auth';
        return;
      }

      // Otherwise just refresh data without blocking
      lastActiveRef.current = now;
      setLastActiveTimestamp(now);
      
      setTimeout(() => {
        refreshData();
      }, 100);
    },
    [refreshData]
  );

  useEffect(() => {
    // Initialize last active from localStorage
    lastActiveRef.current = getLastActiveTimestamp();
    
    // Listen for visibility changes (tab switching, minimizing)
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Listen for network status changes
    window.addEventListener('online', handleOnline);
    
    // Listen for page show (important for mobile back-forward cache / bfcache)
    window.addEventListener('pageshow', handlePageShow);
    
    // Update last active on any user interaction
    const updateLastActive = () => {
      const now = Date.now();
      lastActiveRef.current = now;
      setLastActiveTimestamp(now);
    };
    
    const events = ['mousedown', 'keydown', 'touchstart', 'scroll'];
    events.forEach(event => {
      window.addEventListener(event, updateLastActive, { passive: true });
    });

    // Periodically update timestamp while app is active (every 60 seconds)
    const intervalId = setInterval(() => {
      if (document.visibilityState === 'visible') {
        setLastActiveTimestamp(Date.now());
      }
    }, 60 * 1000);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('pageshow', handlePageShow);
      events.forEach(event => {
        window.removeEventListener(event, updateLastActive);
      });
      clearInterval(intervalId);
    };
  }, [handleVisibilityChange, handleOnline, handlePageShow]);

  return {
    refreshData,
    checkSession,
  };
}
