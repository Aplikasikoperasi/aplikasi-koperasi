import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useAutoBackup = () => {
  useEffect(() => {
    const checkAndRunBackup = async () => {
      try {
        // Only check if user is authenticated
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Get Google Drive settings
        const { data: settings } = await supabase
          .from('google_drive_settings')
          .select('*')
          .single();

        if (!settings || !settings.is_enabled) {
          return;
        }

        // Check if backup is needed based on schedule
        const now = new Date();
        const lastBackup = settings.last_backup_at ? new Date(settings.last_backup_at) : null;
        
        if (!lastBackup) {
          // No backup history, run first backup
          await runBackup();
          return;
        }

        const shouldBackup = (() => {
          // Convert to WIB (UTC+7)
          const wibOffset = 7 * 60;
          const wibTime = new Date(now.getTime() + wibOffset * 60 * 1000);
          const currentHourWIB = wibTime.getHours();
          const currentMinuteWIB = wibTime.getMinutes();
          
          // Check if current time is between 12:00 - 13:00 WIB
          const isWithinBackupWindow = currentHourWIB === 12 || (currentHourWIB === 13 && currentMinuteWIB === 0);
          
          if (!isWithinBackupWindow) {
            return false;
          }
          
          // Check if backup already done today
          const lastBackupWIB = new Date(lastBackup.getTime() + wibOffset * 60 * 1000);
          const todayDateWIB = wibTime.toISOString().substring(0, 10); // YYYY-MM-DD
          const lastBackupDateWIB = lastBackupWIB.toISOString().substring(0, 10); // YYYY-MM-DD
          
          // Backup needed if not done today and within backup window
          return todayDateWIB !== lastBackupDateWIB;
        })();

        if (shouldBackup) {
          console.log('🔄 Running scheduled backup...');
          await runBackup();
        }
      } catch (error) {
        console.error('❌ Auto backup check error:', error);
      }
    };

    const runBackup = async () => {
      try {
        const { error } = await supabase.functions.invoke('scheduled-google-drive-backup');
        
        if (error) {
          console.error('❌ Backup failed:', error);
        } else {
          console.log('✅ Backup completed successfully');
        }
      } catch (error) {
        console.error('❌ Backup error:', error);
      }
    };

    // Check on mount and every 5 minutes
    checkAndRunBackup();
    const interval = setInterval(checkAndRunBackup, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);
};
