import { useEffect, useRef } from "react";
import { useSidebar } from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/use-mobile";

interface SwipeSidebarOptions {
  threshold?: number;
  edgeWidth?: number;
}

export function useSwipeSidebar(options: SwipeSidebarOptions = {}) {
  const {
    threshold = 50,
    edgeWidth = 80,
  } = options;

  const isMobile = useIsMobile();
  const { open, setOpen } = useSidebar();
  const touchStartX = useRef<number>(0);
  const touchStartY = useRef<number>(0);
  const touchEndX = useRef<number>(0);
  const touchEndY = useRef<number>(0);

  useEffect(() => {
    if (!isMobile) return;

    const handleTouchStart = (e: TouchEvent) => {
      touchStartX.current = e.touches[0].clientX;
      touchStartY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: TouchEvent) => {
      touchEndX.current = e.touches[0].clientX;
      touchEndY.current = e.touches[0].clientY;
    };

    const handleTouchEnd = () => {
      const deltaX = touchEndX.current - touchStartX.current;
      const deltaY = Math.abs(touchEndY.current - touchStartY.current);

      // Only trigger if horizontal swipe is dominant
      if (deltaY < threshold * 1.2) {
        // Swipe right (open sidebar) - must start from left edge
        if (deltaX > threshold && touchStartX.current < edgeWidth && !open) {
          setOpen(true);
        }
        // Swipe left (close sidebar) - only when sidebar is open
        else if (deltaX < -threshold && open) {
          setOpen(false);
        }
      }

      // Reset values
      touchStartX.current = 0;
      touchStartY.current = 0;
      touchEndX.current = 0;
      touchEndY.current = 0;
    };

    document.addEventListener("touchstart", handleTouchStart, { passive: true });
    document.addEventListener("touchmove", handleTouchMove, { passive: true });
    document.addEventListener("touchend", handleTouchEnd, { passive: true });

    return () => {
      document.removeEventListener("touchstart", handleTouchStart);
      document.removeEventListener("touchmove", handleTouchMove);
      document.removeEventListener("touchend", handleTouchEnd);
    };
  }, [isMobile, threshold, edgeWidth, open, setOpen]);
}
