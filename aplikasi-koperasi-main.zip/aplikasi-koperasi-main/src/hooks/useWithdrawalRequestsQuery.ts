import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseWithdrawalRequestsParams {
  memberId?: string | null;
  status?: string;
}

export const useWithdrawalRequestsQuery = ({ memberId, status = "pending" }: UseWithdrawalRequestsParams = {}) => {
  return useQuery({
    queryKey: ["withdrawal-requests", memberId, status],
    queryFn: async () => {
      let query = supabase
        .from("member_balance_withdrawals")
        .select(`
          *,
          members!inner(
            id,
            full_name,
            member_number,
            phone,
            photo_url
          )
        `)
        .eq("status", status)
        .order("requested_at", { ascending: false });

      // Filter by member for sales users
      if (memberId) {
        query = query.eq("member_id", memberId);
      }

      const { data, error } = await query;

      if (error) throw error;

      return data || [];
    },
  });
};

export const useInvalidateWithdrawalRequests = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["withdrawal-requests"] });
  };
};
