import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const BADGE_TTL_MS = 10 * 60 * 1000; // 10 minutes
const badgeCache = new Map<string, { badge: any | null; expiresAt: number }>();

interface UseCustomersParams {
  searchQuery?: string;
  page?: number;
  itemsPerPage?: number;
  isSalesUser?: boolean;
  currentMemberId?: string | null;
}

export const useCustomersQuery = ({ searchQuery = "", page = 1, itemsPerPage = 20, isSalesUser, currentMemberId }: UseCustomersParams = {}) => {
  return useQuery({
    queryKey: ["customers", searchQuery, page],
    staleTime: 1000 * 60 * 2, // Cache for 2 minutes to avoid refetching badges constantly
    queryFn: async () => {
      const from = (page - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      // Determine role and member context efficiently
      let effectiveIsSalesUser = typeof isSalesUser === "boolean" ? isSalesUser : false;
      let effectiveMemberId: string | null = currentMemberId ?? null;

      if (isSalesUser === undefined) {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: roleData } = await supabase
            .from("user_roles")
            .select("role")
            .eq("user_id", user.id)
            .maybeSingle();

          effectiveIsSalesUser = roleData?.role === "sales";

          if (effectiveIsSalesUser && !effectiveMemberId) {
            const { data: memberData } = await supabase
              .from("members")
              .select("id")
              .eq("user_id", user.id)
              .maybeSingle();

            effectiveMemberId = memberData?.id || null;
          }
        }
      }

      // Build base query with joins to avoid extra round trips
      // LEFT JOIN with blocked_customers and filter out any customers that have a blocked record
      const selectColumns = `
        id, full_name, phone, nik, id_number, date_of_birth, created_at, created_by, status, photo_url, user_id, restoration_status, credit_score, login_email, email, address, occupation, monthly_income,
        member:created_by (id, full_name, position, nik, is_active),
        credit_applications!customer_id(application_date, amount_approved, status)
      `;

      let query = supabase
        .from("customers")
        .select(selectColumns, { count: "exact" })
        .eq("status", "approved");

      // Apply sales filter
      if (isSalesUser && currentMemberId) {
        const { data: relatedApps } = await supabase
          .from("credit_applications")
          .select("customer_id")
          .eq("member_id", currentMemberId);
        
        const relatedIds = relatedApps?.map(a => a.customer_id) || [];
        if (relatedIds.length > 0) {
          query = query.or(`created_by.eq.${currentMemberId},id.in.(${relatedIds.join(',')})`);
        } else {
          query = query.eq("created_by", currentMemberId);
        }
      }

      if (searchQuery.trim()) {
        query = query.or(
          `full_name.ilike.%${searchQuery}%,phone.ilike.%${searchQuery}%,nik.ilike.%${searchQuery}%,id_number.ilike.%${searchQuery}%`
        );
      }

      // OPTIMIZED: Apply pagination at database level for better performance
      // Sort by created_at descending to show newest first
      const { data, error, count } = await query
        .order("created_at", { ascending: false })
        .range(from, to);

      if (error) throw error;

      const customersRaw = data || [];
      const customerIds = customersRaw.map((customer: any) => customer.id);

      // Explicitly load blocked status for customers on the current page
      let blockedCustomerIds = new Set<string>();
      if (customerIds.length > 0) {
        const { data: blockedRows, error: blockedError } = await supabase
          .from("blocked_customers")
          .select("customer_id")
          .in("customer_id", customerIds);

        if (blockedError) {
          console.error("Failed to load blocked customers for list", blockedError);
        } else {
          blockedCustomerIds = new Set(
            (blockedRows || []).map((row: any) => row.customer_id)
          );
        }
      }

      // Attach member data to customers and ensure blocked customers are never shown
      const customersWithMembers = customersRaw
        .filter((customer: any) => !blockedCustomerIds.has(customer.id))
        .map((customer: any) => {
          const member = (customer as any).member || null;
          const isMemberCustomer = !!(
            member &&
            member.position !== "Owner" &&
            member.is_active !== false
          );
          const hasIncompleteData = !customer.id_number || !customer.date_of_birth;

          // Calculate effective registration date (earlier of created_at or first credit application)
          const creditApps = Array.isArray(customer.credit_applications) 
            ? customer.credit_applications 
            : [];
          
          const earliestCreditDate = creditApps.length > 0
            ? creditApps.reduce((earliest: string, app: any) => {
                if (!app?.application_date) return earliest;
                return !earliest || app.application_date < earliest 
                  ? app.application_date 
                  : earliest;
              }, '')
            : null;

          // Calculate total loan amount - separate active and completed
          const totalActiveLoanAmount = creditApps.reduce((total: number, app: any) => {
            // Active loans are those with status 'approved' or 'disbursed' (not 'completed' or 'rejected')
            if (app?.amount_approved && app.status && app.status !== 'completed' && app.status !== 'rejected' && app.status !== 'pending') {
              return total + app.amount_approved;
            }
            return total;
          }, 0);

          const totalCompletedLoanAmount = creditApps.reduce((total: number, app: any) => {
            // Completed loans have status 'completed'
            if (app?.amount_approved && app.status === 'completed') {
              return total + app.amount_approved;
            }
            return total;
          }, 0);

          // Use earlier date between registration and first credit
          let effectiveRegistrationDate = customer.created_at;
          if (earliestCreditDate && earliestCreditDate < customer.created_at) {
            effectiveRegistrationDate = earliestCreditDate;
          }

          return {
            ...customer,
            member,
            isMemberCustomer,
            hasIncompleteData,
            effective_registration_date: effectiveRegistrationDate,
            total_active_loan_amount: totalActiveLoanAmount,
            total_completed_loan_amount: totalCompletedLoanAmount,
          };
        });

      const now = Date.now();

      // Fetch badges only for current page (already paginated at DB level)

      const badgesMap = new Map<string, any>();
      const missingIds: string[] = [];

      for (const c of customersWithMembers) {
        const cached = badgeCache.get(c.id);
        // IMPORTANT: jangan cache hasil NULL secara permanen supaya bisa muncul badge baru
        if (cached && cached.expiresAt > now && cached.badge) {
          badgesMap.set(c.id, cached.badge);
        } else {
          missingIds.push(c.id);
        }
      }

      if (missingIds.length > 0) {
        const { data: bulk, error: badgeError } = await supabase.rpc('get_customers_achievement_badges', {
          p_customer_ids: missingIds
        });

        if (badgeError) {
          console.error("Failed to load achievement badges", {
            missingIds,
            error: badgeError.message,
          });
        }

        (bulk || []).forEach((row: any) => {
          const badge = row && row.badge_level ? row : null;
          // Hanya cache kalau memang ada badge; kalau tidak, biarkan supaya bisa dihitung ulang nanti
          if (badge) {
            badgeCache.set(row.customer_id, { badge, expiresAt: now + BADGE_TTL_MS });
            badgesMap.set(row.customer_id, badge);
          } else {
            badgeCache.delete(row.customer_id);
          }
        });
      }

      const customersWithBadges = customersWithMembers.map(customer => ({
        ...customer,
        achievementBadge: badgesMap.get(customer.id) || null
      }));

      return {
        customers: customersWithBadges,
        totalCount: count || 0,
      };
    },
  });
};

export const useCustomersWithoutAuthQuery = () => {
  return useQuery({
    queryKey: ["customers-without-auth"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("customers")
        .select("*", { count: "exact", head: true })
        .eq("status", "approved")
        .is("user_id", null)
        .not("id_number", "is", null)
        .not("date_of_birth", "is", null);

      if (error) throw error;
      return count || 0;
    },
  });
};

export const useInvalidateCustomers = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["customers"] });
    queryClient.invalidateQueries({ queryKey: ["customers-without-auth"] });
  };
};
