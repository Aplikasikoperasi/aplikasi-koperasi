import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseBlockedCustomersParams {
  searchQuery?: string;
  page?: number;
  itemsPerPage?: number;
}

export const useBlockedCustomersQuery = ({ searchQuery = "", page = 1, itemsPerPage = 20 }: UseBlockedCustomersParams = {}) => {
  return useQuery({
    queryKey: ["blocked-customers", searchQuery, page],
    staleTime: 0,
    gcTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    refetchInterval: 10000, // Auto-refetch every 10 seconds to ensure credit scores are up to date
    queryFn: async () => {
      console.log('🔄 Fetching blocked customers data...');
      const from = (page - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      let query = supabase
        .from("blocked_customers")
        .select(`
          *,
          customers(
            id,
            id_number,
            full_name,
            nik,
            phone,
            address,
            photo_url,
            date_of_birth,
            credit_score,
            restoration_status
          )
        `, { count: "exact" });

      if (searchQuery.trim()) {
        query = query.or(
          `full_name.ilike.%${searchQuery}%,phone.ilike.%${searchQuery}%,nik.ilike.%${searchQuery}%`,
          { foreignTable: 'customers' }
        );
      }

      const { data, error, count } = await query
        .order("blocked_at", { ascending: false })
        .range(from, to);

      if (error) throw error;

      console.log(`✅ Fetched ${data?.length || 0} blocked customers with fresh credit scores`);

      // Fetch blocker names in parallel
      const blockerIds = [...new Set((data || []).map((b: any) => b.blocked_by).filter(Boolean))];
      
      let blockersMap = new Map();
      if (blockerIds.length > 0) {
        const { data: membersData } = await supabase
          .from("members")
          .select("id, full_name")
          .in("id", blockerIds);

        membersData?.forEach((m: any) => blockersMap.set(m.id, m));
      }

      const blockedCustomersWithBlocker = (data || []).map((blocked: any) => ({
        ...blocked,
        blocker: blocked.blocked_by ? blockersMap.get(blocked.blocked_by) : null,
      }));

      return {
        blockedCustomers: blockedCustomersWithBlocker,
        totalCount: count || 0,
      };
    },
  });
};

export const useInvalidateBlockedCustomers = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["blocked-customers"] });
  };
};
