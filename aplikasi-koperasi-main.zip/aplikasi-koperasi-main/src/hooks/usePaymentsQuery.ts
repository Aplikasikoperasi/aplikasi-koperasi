import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UsePaymentsParams {
  searchQuery?: string;
  selectedMonth?: string;
  selectedYear?: string;
  page?: number;
  itemsPerPage?: number;
}

export const usePaymentsQuery = ({
  searchQuery = "",
  selectedMonth = "",
  selectedYear = "",
  page = 1,
  itemsPerPage = 20,
}: UsePaymentsParams = {}) => {
  return useQuery({
    queryKey: ["payments", searchQuery, selectedMonth, selectedYear, page],
    queryFn: async () => {
      const from = (page - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      // Get current user info
      const { data: { user } } = await supabase.auth.getUser();
      let currentMemberId = null;
      let isSalesUser = false;

      if (user) {
        const { data: roleData } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .maybeSingle();

        isSalesUser = roleData?.role === "sales";

        if (isSalesUser) {
          const { data: memberData } = await supabase
            .from("members")
            .select("id")
            .eq("user_id", user.id)
            .maybeSingle();

          currentMemberId = memberData?.id;
        }
      }

      // Build query
      let query = supabase
        .from("payments")
        .select(
          `
          *,
          installments!inner(
            id,
            installment_number,
            due_date,
            principal_amount,
            interest_amount,
            frozen_penalty,
            total_amount,
            paid_amount,
            credit_applications!inner(
              id,
              member_id,
              application_number,
              application_date,
              tenor_months,
              customers!inner(id, full_name, phone, photo_url, id_number)
            )
          )
        `,
          { count: "exact" }
        );

      // Apply sales filter - filter by member_id in credit_applications
      if (isSalesUser && currentMemberId) {
        query = query.eq("installments.credit_applications.member_id", currentMemberId);
      }

      // Apply month filter
      if (selectedMonth && selectedMonth !== "all") {
        const monthNum = parseInt(selectedMonth);
        const year = selectedYear && selectedYear !== "all" ? selectedYear : new Date().getFullYear().toString();
        query = query.gte("payment_date", `${year}-${monthNum.toString().padStart(2, "0")}-01`)
          .lt("payment_date", `${year}-${(monthNum + 1).toString().padStart(2, "0")}-01`);
      }

      // Apply year filter
      if (selectedYear && selectedYear !== "all" && (!selectedMonth || selectedMonth === "all")) {
        query = query.gte("payment_date", `${selectedYear}-01-01`)
          .lt("payment_date", `${parseInt(selectedYear) + 1}-01-01`);
      }

      // Apply search filter - search in customer ID, name, and phone
      // Note: We need to fetch all data first then filter client-side for nested OR conditions
      let allData: any[] = [];
      let finalCount = 0;
      
      if (searchQuery.trim()) {
        // Get all payments without pagination first for search
        const searchFrom = 0;
        const searchTo = 999; // Get more records for search
        
        let searchQuery2 = supabase
          .from("payments")
          .select(
            `
            *,
            installments!inner(
              id,
              installment_number,
              due_date,
              principal_amount,
              interest_amount,
              frozen_penalty,
              total_amount,
              paid_amount,
              credit_applications!inner(
                id,
                member_id,
                application_number,
                application_date,
                tenor_months,
                customers!inner(id, full_name, phone, photo_url, id_number)
              )
            )
          `,
            { count: "exact" }
          );

        // Apply sales filter
        if (isSalesUser && currentMemberId) {
          searchQuery2 = searchQuery2.eq("installments.credit_applications.member_id", currentMemberId);
        }

        // Apply month filter
        if (selectedMonth && selectedMonth !== "all") {
          const monthNum = parseInt(selectedMonth);
          const year = selectedYear && selectedYear !== "all" ? selectedYear : new Date().getFullYear().toString();
          searchQuery2 = searchQuery2.gte("payment_date", `${year}-${monthNum.toString().padStart(2, "0")}-01`)
            .lt("payment_date", `${year}-${(monthNum + 1).toString().padStart(2, "0")}-01`);
        }

        // Apply year filter
        if (selectedYear && selectedYear !== "all" && (!selectedMonth || selectedMonth === "all")) {
          searchQuery2 = searchQuery2.gte("payment_date", `${selectedYear}-01-01`)
            .lt("payment_date", `${parseInt(selectedYear) + 1}-01-01`);
        }

        const { data: searchData, error: searchError } = await searchQuery2
          .order("payment_date", { ascending: false })
          .range(searchFrom, searchTo);

        if (searchError) throw searchError;

        // Filter client-side
        const searchLower = searchQuery.toLowerCase().trim();
        const filtered = searchData?.filter((payment: any) => {
          const customer = payment.installments?.credit_applications?.customers;
          if (!customer) return false;
          
          const nameMatch = customer.full_name?.toLowerCase().includes(searchLower);
          const phoneMatch = customer.phone?.toLowerCase().includes(searchLower);
          const idMatch = customer.id_number?.toLowerCase().includes(searchLower);
          
          return nameMatch || phoneMatch || idMatch;
        }) || [];

        // Apply pagination to filtered results
        allData = filtered.slice(from, to + 1);
        finalCount = filtered.length;
      } else {
        // If no search, apply pagination normally
        const { data: fetchedData, error, count: fetchedCount } = await query
          .order("payment_date", { ascending: false })
          .range(from, to);

        if (error) throw error;
        
        allData = fetchedData || [];
        finalCount = fetchedCount || 0;
      }

      // Hydrate member names for:
      // 1. Payment creator (created_by) - who recorded the payment
      // 2. Application member (member_id) - who handles the credit application
      const creatorUserIds = [...new Set(
        allData?.map((p: any) => p.created_by).filter(Boolean)
      )];
      
      const applicationMemberIds = [...new Set(
        allData?.map((p: any) => p.installments?.credit_applications?.member_id).filter(Boolean)
      )];
      
      // Fetch members by user_id for payment creators
      const { data: creatorMembersData } = await supabase
        .from("members")
        .select("user_id, full_name, member_number, position")
        .in("user_id", creatorUserIds);

      const creatorMap = new Map(creatorMembersData?.map((m) => [m.user_id, m]) || []);
      
      // Fetch members by id for application handlers
      const { data: applicationMembersData } = await supabase
        .from("members")
        .select("id, full_name, position")
        .in("id", applicationMemberIds);

      const applicationMemberMap = new Map(applicationMembersData?.map((m) => [m.id, { full_name: m.full_name, position: m.position }]) || []);

      const paymentsWithMembers = allData?.map((payment: any) => {
        const responsibleMember = applicationMemberMap.get(payment.installments?.credit_applications?.member_id);
        return {
          ...payment,
          creator_member: creatorMap.get(payment.created_by) || null,
          responsible_member: responsibleMember || null,
          member_name: responsibleMember?.full_name || "Unknown",
        };
      });

      return {
        payments: paymentsWithMembers || [],
        totalCount: finalCount || 0,
      };
    },
  });
};

export const useInvalidatePayments = () => {
  const queryClient = useQueryClient();

  return () => {
    queryClient.invalidateQueries({ queryKey: ["payments"] });
  };
};
