import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface BusinessInfo {
  businessName: string;
  businessDescription: string;
  businessPhone: string;
  businessEmail: string;
  logoUrl: string | null;
  loading: boolean;
}

export function useBusinessInfo(): BusinessInfo {
  const [businessName, setBusinessName] = useState<string>("Sistem Kredit");
  const [businessDescription, setBusinessDescription] = useState<string>("Solusi lengkap untuk manajemen kredit");
  const [businessPhone, setBusinessPhone] = useState<string>("");
  const [businessEmail, setBusinessEmail] = useState<string>("");
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [ownerId, setOwnerId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);

  // Load owner id (if any). If none, we'll fallback to most recently updated profile with business info
  useEffect(() => {
    let isMounted = true;

    const loadOwner = async () => {
      // Fetch all owners, then choose the owner whose profile was updated most recently
      const { data: owners } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "owner");

      if (owners && owners.length > 0) {
        const ownerIds = owners.map((o: any) => o.user_id);
        const { data: latestOwner } = await supabase
          .from("profiles")
          .select("id, updated_at")
          .in("id", ownerIds)
          .order("updated_at", { ascending: false, nullsFirst: false })
          .limit(1)
          .maybeSingle();

        if (isMounted) {
          setOwnerId(latestOwner?.id || ownerIds[0] || null);
        }
      } else if (isMounted) {
        setOwnerId(null);
      }
    };

    loadOwner();

    return () => { isMounted = false; };
  }, []);

  // Load business info and subscribe to realtime changes
  useEffect(() => {
    let isMounted = true;

    const loadProfile = async () => {
      // Preferred: owner's profile
      if (ownerId) {
        const { data: ownerProfile } = await supabase
          .from("profiles")
          .select("business_name, business_description, business_phone, business_email, logo_url, updated_at")
          .eq("id", ownerId)
          .maybeSingle();

        if (isMounted && ownerProfile) {
          setBusinessName(ownerProfile.business_name || "Sistem Kredit");
          setBusinessDescription(ownerProfile.business_description || "Solusi lengkap untuk manajemen kredit");
          setBusinessPhone(ownerProfile.business_phone || "");
          setBusinessEmail(ownerProfile.business_email || "");
          setLogoUrl(ownerProfile.logo_url || null);
          setLastUpdated(ownerProfile.updated_at);
          setLoading(false);
          return;
        }
      }

      // Fallback: latest profile with business info (handles when owner role missing)
      const { data: latest } = await supabase
        .from("profiles")
        .select("business_name, business_description, business_phone, business_email, logo_url, updated_at")
        .not("business_name", "is", null)
        .order("updated_at", { ascending: false, nullsFirst: false })
        .limit(1)
        .maybeSingle();

      if (isMounted && latest) {
        setBusinessName(latest.business_name || "Sistem Kredit");
        setBusinessDescription(latest.business_description || "Solusi lengkap untuk manajemen kredit");
        setBusinessPhone(latest.business_phone || "");
        setBusinessEmail(latest.business_email || "");
        setLogoUrl(latest.logo_url || null);
        setLastUpdated(latest.updated_at);
      }
      if (isMounted) setLoading(false);
    };

    loadProfile();

    // Realtime subscription: listen to any change in profiles and adopt newest value
    const channel = supabase
      .channel("business-profile-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "profiles" },
        (payload: any) => {
          const row = payload.new || payload.old;
          if (!row) return;

          // Only react to changes for owner or the most recently updated profile
          const isOwnerRow = ownerId ? row.id === ownerId : true;

          if (isOwnerRow) {
            setBusinessName(row.business_name || "Sistem Kredit");
            setBusinessDescription(row.business_description || "Solusi lengkap untuk manajemen kredit");
            setBusinessPhone(row.business_phone || "");
            setBusinessEmail(row.business_email || "");
            setLogoUrl(row.logo_url || null);
            setLastUpdated(row.updated_at || new Date().toISOString());
            return;
          }

          // If not owner and we don't know owner, prefer the most recent
          if (!ownerId) {
            const updated = row.updated_at || new Date().toISOString();
            if (!lastUpdated || updated > lastUpdated) {
              setBusinessName(row.business_name || "Sistem Kredit");
              setBusinessDescription(row.business_description || "Solusi lengkap untuk manajemen kredit");
              setBusinessPhone(row.business_phone || "");
              setBusinessEmail(row.business_email || "");
              setLogoUrl(row.logo_url || null);
              setLastUpdated(updated);
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      isMounted = false;
    };
  }, [ownerId, lastUpdated]);

  return { businessName, businessDescription, businessPhone, businessEmail, logoUrl, loading };
}
