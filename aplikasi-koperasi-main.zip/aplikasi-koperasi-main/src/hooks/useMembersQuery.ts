import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseMembersParams {
  searchQuery?: string;
  page?: number;
  itemsPerPage?: number;
}

export const useMembersQuery = ({ searchQuery = "", page = 1, itemsPerPage = 20 }: UseMembersParams = {}) => {
  return useQuery({
    queryKey: ["members", searchQuery, page],
    queryFn: async () => {
      const from = (page - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      // Get members with their earliest credit application date
      let query = supabase
        .from("members")
        .select(`
          *,
          credit_applications!member_id(application_date)
        `, { count: "exact" });

      if (searchQuery.trim()) {
        query = query.or(
          `full_name.ilike.%${searchQuery}%,phone.ilike.%${searchQuery}%,member_number.ilike.%${searchQuery}%`
        );
      }

      const { data: membersData, error: membersError, count } = await query;

      if (membersError) throw membersError;

      // Get the earliest credit application date in the entire system (for owner's join date)
      const { data: earliestCreditData } = await supabase
        .from("credit_applications")
        .select("application_date")
        .order("application_date", { ascending: true })
        .limit(1);

      const systemEarliestCreditDate = earliestCreditData?.[0]?.application_date || null;

      // Get all user roles
      const { data: rolesData, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role");

      if (rolesError) throw rolesError;

      // Create a map of user_id to role
      const roleMap = new Map(rolesData?.map(r => [r.user_id, r.role]) || []);

      // Attach roles and calculate effective join date for members
      const membersWithRoles = (membersData || []).map(member => {
        const memberRole = roleMap.get(member.user_id) || 'sales';
        
        // Special handling for Owner: use earliest credit date in the system
        if (member.position?.toLowerCase() === 'owner' && systemEarliestCreditDate) {
          return {
            ...member,
            role: memberRole,
            effective_join_date: systemEarliestCreditDate
          };
        }
        
        // For non-owner members: compare their registration date with their own earliest credit
        // Safely get credit applications array (will be [] if none exist)
        const creditApps = Array.isArray(member.credit_applications) 
          ? member.credit_applications 
          : [];
        
        // Find earliest credit application date only if there are applications
        const earliestCreditDate = creditApps.length > 0
          ? creditApps.reduce((earliest: string, app: any) => {
              // Skip if app or application_date is invalid
              if (!app?.application_date) return earliest;
              return !earliest || app.application_date < earliest 
                ? app.application_date 
                : earliest;
            }, '')
          : null;

        // Calculate effective join date (earlier of registration or first credit)
        // Default to created_at, only change if we have a valid earlier credit date
        let effectiveJoinDate = member.created_at;
        if (earliestCreditDate && earliestCreditDate < member.created_at) {
          effectiveJoinDate = earliestCreditDate;
        }

        return {
          ...member,
          role: memberRole,
          effective_join_date: effectiveJoinDate // Will always be set to created_at minimum
        };
      });

      // Sort by position priority (owner > admin > kasir > sales), then by member_number for stable ordering
      const positionOrder: Record<string, number> = {
        owner: 1,
        admin: 2,
        kasir: 3,
        sales: 4,
      };

      const sortedData = membersWithRoles.sort((a: any, b: any) => {
        // First priority: active status (active members first)
        if (a.is_active !== b.is_active) {
          return a.is_active ? -1 : 1;
        }
        
        // Second priority: position hierarchy (use position field, not user_roles)
        const posA = positionOrder[a.position?.toLowerCase()] || 999;
        const posB = positionOrder[b.position?.toLowerCase()] || 999;
        
        if (posA !== posB) {
          return posA - posB;
        }
        
        // Third priority: stable sort by member_number
        const numA = a.member_number || 'Z999';
        const numB = b.member_number || 'Z999';
        return numA.localeCompare(numB);
      });

      // Apply pagination after sorting
      const paginatedData = sortedData.slice(from, to + 1);

      return {
        members: paginatedData,
        totalCount: count || 0,
      };
    },
  });
};

export const useInvalidateMembers = () => {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.invalidateQueries({ queryKey: ["members"] });
  };
};
