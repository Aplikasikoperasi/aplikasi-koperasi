import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';

interface IdleTimeoutConfig {
  role: 'owner' | 'admin' | 'sales' | 'customer' | 'kasir' | null;
  onWarning?: () => void;
  onLogout?: () => void;
}

// Role-based timeout in milliseconds - BALANCED FOR USABILITY & SECURITY
const TIMEOUTS = {
  customer: 10 * 60 * 1000,   // 10 minutes (increased from 5 for better UX)
  sales: 20 * 60 * 1000,      // 20 minutes (increased for field work)
  admin: 20 * 60 * 1000,      // 20 minutes
  owner: 30 * 60 * 1000,      // 30 minutes (unchanged)
  kasir: 10 * 60 * 1000,      // 10 minutes (increased from 3 - was too aggressive)
};

// Warning time: 60 seconds for all roles
const WARNING_TIME_DEFAULT = 60 * 1000; // 1 minute
const WARNING_TIME_KASIR = 60 * 1000;   // 1 minute (was 30 seconds)

export function useIdleTimeout({ role, onWarning, onLogout }: IdleTimeoutConfig) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showWarning, setShowWarning] = useState(false);
  const [remainingTime, setRemainingTime] = useState(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const warningTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const countdownRef = useRef<NodeJS.Timeout | null>(null);

  const getTimeout = () => {
    if (!role) return TIMEOUTS.customer;
    return TIMEOUTS[role] || TIMEOUTS.customer;
  };

  const getWarningTime = () => {
    return role === 'kasir' ? WARNING_TIME_KASIR : WARNING_TIME_DEFAULT;
  };

  const clearAllTimers = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (warningTimeoutRef.current) clearTimeout(warningTimeoutRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
  };

  const handleLogout = async () => {
    clearAllTimers();
    setShowWarning(false);
    
    // CRITICAL SECURITY: Clear React Query cache first to prevent data leaks
    queryClient.clear();
    
    // Clear all session data
    localStorage.clear();
    sessionStorage.clear();
    
    await supabase.auth.signOut();
    
    toast({
      title: "Sesi Berakhir",
      description: "Anda telah keluar karena tidak ada aktivitas.",
      variant: "destructive",
    });
    
    if (onLogout) onLogout();
    
    // CRITICAL: Hard redirect to auth page to ensure all cache is cleared
    window.location.href = '/auth';
  };

  const startCountdown = () => {
    const warningTime = getWarningTime();
    setRemainingTime(warningTime / 1000);
    countdownRef.current = setInterval(() => {
      setRemainingTime((prev) => {
        if (prev <= 1) {
          if (countdownRef.current) clearInterval(countdownRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const showWarningDialog = () => {
    setShowWarning(true);
    startCountdown();
    if (onWarning) onWarning();
    
    // REMOVED: Toast notification - countdown only shown in dialog
  };

  const resetTimer = () => {
    clearAllTimers();
    setShowWarning(false);
    
    const timeout = getTimeout();
    const warningTime = getWarningTime();
    
    // Set warning timer
    warningTimeoutRef.current = setTimeout(() => {
      showWarningDialog();
    }, timeout - warningTime);
    
    // Set logout timer
    timeoutRef.current = setTimeout(() => {
      handleLogout();
    }, timeout);
  };

  const extendSession = () => {
    setShowWarning(false);
    resetTimer();
    // REMOVED: Toast notification - silent session extension
  };

  useEffect(() => {
    if (!role) return;

    const events = ['mousedown', 'keydown', 'scroll', 'touchstart', 'mousemove'];
    
    const handleActivity = () => {
      resetTimer();
    };

    // Start initial timer
    resetTimer();

    // Add event listeners for user activity
    events.forEach(event => {
      window.addEventListener(event, handleActivity);
    });

    return () => {
      clearAllTimers();
      events.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [role]);

  return {
    showWarning,
    remainingTime,
    extendSession,
    handleLogout,
  };
}
