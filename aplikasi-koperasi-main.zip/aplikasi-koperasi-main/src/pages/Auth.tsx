import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Building2, Eye, EyeOff, Upload, X, AlertTriangle, Clock } from "lucide-react";
import { useSaverAuth } from "@/contexts/SaverAuthContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DatePicker } from "@/components/ui/date-picker";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { compressImage } from "@/lib/imageCompression";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { useQueryClient } from "@tanstack/react-query";
import { 
  isLoginBlocked, 
  recordFailedAttempt, 
  resetLoginAttempts, 
  getLoginAttemptsRemaining,
  getLockoutEndTime 
} from "@/lib/loginRateLimiter";
const Auth = () => {
  const { login: saverLogin } = useSaverAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [supercodeDialogOpen, setSupercodeDialogOpen] = useState(false);
  const [supercodeInput, setSupercodeInput] = useState("");
  const [pendingOwnerData, setPendingOwnerData] = useState<{
    email: string;
    authPassword: string;
    fullName: string;
    memberData: any;
  } | null>(null);
  const [pinDialogOpen, setPinDialogOpen] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [pendingKasirData, setPendingKasirData] = useState<{
    email: string;
    authPassword: string;
    fullName: string;
    memberData: any;
  } | null>(null);
  const [showOwnerDialog, setShowOwnerDialog] = useState(false);
  const [ownerExists, setOwnerExists] = useState(false);
  const [checkingOwner, setCheckingOwner] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [dateOfBirth, setDateOfBirth] = useState<Date | undefined>();
  const [formData, setFormData] = useState({
    full_name: "",
    phone: "",
    nik: "",
    address: "",
    supercode: ""
  });
  
  // Login rate limiting states
  const [isBlocked, setIsBlocked] = useState(false);
  const [blockRemainingMinutes, setBlockRemainingMinutes] = useState(0);
  const [attemptsRemaining, setAttemptsRemaining] = useState(3);
  
  const navigate = useNavigate();
  const {
    toast
  } = useToast();
  const {
    businessName,
    logoUrl,
    loading: businessLoading
  } = useBusinessInfo();
  const queryClient = useQueryClient();

  // Check login block status on mount and periodically
  useEffect(() => {
    const checkBlockStatus = () => {
      const blockStatus = isLoginBlocked();
      setIsBlocked(blockStatus.blocked);
      setBlockRemainingMinutes(blockStatus.remainingMinutes);
      setAttemptsRemaining(getLoginAttemptsRemaining());
    };
    
    checkBlockStatus();
    
    // Check every 30 seconds to update countdown
    const interval = setInterval(checkBlockStatus, 30000);
    
    return () => clearInterval(interval);
  }, []);

  // Client-side time-based password validation (faster than edge function call)
  const validateTimePassword = (typedPassword: string, expectedDOB: string): {
    valid: boolean;
    error?: string;
  } => {
    // Password must be exactly 12 characters (DDMMYYYYHHMM)
    if (typedPassword.length !== 12) {
      return {
        valid: false,
        error: 'Invalid password format'
      };
    }

    // Extract parts from typed password
    const typedDOB = typedPassword.substring(0, 8);
    const typedHour = typedPassword.substring(8, 10);
    const typedMinute = typedPassword.substring(10, 12);

    // Validate DOB matches
    if (typedDOB !== expectedDOB) {
      return {
        valid: false,
        error: 'Invalid credentials'
      };
    }

    // Validate time format
    const hour = parseInt(typedHour, 10);
    const minute = parseInt(typedMinute, 10);
    if (isNaN(hour) || isNaN(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      return {
        valid: false,
        error: 'Invalid time format'
      };
    }

    // Use local time in WIB (UTC+7) for validation
    const now = new Date();
    const wibOffset = 7 * 60; // WIB is UTC+7
    const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
    const wibTotalMinutes = (utcMinutes + wibOffset) % 1440;
    const typedTotalMinutes = hour * 60 + minute;
    let minuteDiff = Math.abs(wibTotalMinutes - typedTotalMinutes);

    // Handle day boundary crossings
    if (minuteDiff > 720) {
      minuteDiff = 1440 - minuteDiff;
    }

    // Tolerance ±5 minutes
    if (minuteDiff > 5) {
      return {
        valid: false,
        error: 'Invalid time'
      };
    }
    return {
      valid: true
    };
  };
  useEffect(() => {
    let isMounted = true;
    
    const initAuth = async () => {
      // Check if user is already authenticated
      const {
        data: {
          session
        }
      } = await supabase.auth.getSession();
      
      if (!isMounted) return;
      
      if (session) {
        // CRITICAL: Redirect based on ACCOUNT TYPE first, then role
        // This prevents customers from accessing staff dashboards even if role is wrong
        try {
          const {
            data: user
          } = await supabase.auth.getUser();
          
          if (!isMounted) return;
          
          if (user?.user) {
            // SECURITY: Check if this is a CUSTOMER account FIRST (highest priority)
            // Customers should ALWAYS go to customer dashboard regardless of role
            const {
              data: customerData
            } = await supabase.from("customers").select("id").eq("user_id", user.user.id).maybeSingle();
            
            if (!isMounted) return;
            
            if (customerData) {
              // This is a customer - always redirect to customer dashboard
              console.log("[Auth] User is a customer, redirecting to customer-dashboard");
              navigate("/customer-dashboard", {
                replace: true
              });
              return;
            }

            // SECURITY: Only check member/staff roles if user is NOT a customer
            const {
              data: memberData
            } = await supabase.from("members").select("id, position").eq("user_id", user.user.id).maybeSingle();
            
            if (!isMounted) return;
            
            if (memberData) {
              // This is a member/staff - check role for proper redirect
              const {
                data: roleData
              } = await supabase.from("user_roles").select("role").eq("user_id", user.user.id).maybeSingle();
              
              if (!isMounted) return;
              
              if (roleData?.role === "kasir") {
                navigate("/cashier-dashboard", { replace: true });
                return;
              } else if (roleData?.role === "sales") {
                navigate("/sales-performance", { replace: true });
                return;
              } else if (roleData?.role === "owner" || roleData?.role === "admin") {
                navigate("/dashboard", { replace: true });
                return;
              }
              
              // Fallback based on position field for members without roles
              const posLower = memberData.position?.toLowerCase() || '';
              if (posLower === 'kasir') {
                navigate("/cashier-dashboard", { replace: true });
                return;
              } else if (posLower === 'sales') {
                navigate("/sales-performance", { replace: true });
                return;
              }
              
              // Default member redirect
              navigate("/dashboard", { replace: true });
              return;
            }
            
            // User exists in auth but not in customers or members - suspicious
            console.warn("[Auth] User not found in customers or members table");
          }
        } catch (error) {
          console.error("Error checking role on init:", error);
        }

        // Fallback to dashboard if checks fail
        navigate("/dashboard", {
          replace: true
        });
        return;
      }

      // Only check owner existence if not authenticated
      checkOwnerExists();
    };
    
    initAuth();
    
    return () => {
      isMounted = false;
    };
  }, [navigate]);
  const checkOwnerExists = async () => {
    try {
      setCheckingOwner(true);
      
      // Use security definer function to check owner existence
      // This works even without authentication (for login page)
      const { data: hasOwner, error } = await supabase.rpc("check_owner_exists");
      
      console.log("Owner check:", { hasOwner, error });
      
      if (error) {
        console.error("Error checking owner:", error);
        // Default to ownerExists = true for security (hide button if error)
        setOwnerExists(true);
      } else {
        setOwnerExists(hasOwner === true);
      }
    } catch (error) {
      console.error("Error checking owner:", error);
      // Default ke ownerExists = true untuk keamanan (sembunyikan tombol jika error)
      setOwnerExists(true);
    } finally {
      setCheckingOwner(false);
    }
  };
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if login is blocked due to too many failed attempts
    const blockStatus = isLoginBlocked();
    if (blockStatus.blocked) {
      setIsBlocked(true);
      setBlockRemainingMinutes(blockStatus.remainingMinutes);
      toast({
        title: "Akses Login Dibekukan",
        description: `Terlalu banyak percobaan gagal. Silakan tunggu ${blockStatus.remainingMinutes} menit.`,
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    try {
      // CRITICAL SECURITY: Clear React Query cache before login
      queryClient.clear();
      // Clear any cached data before login (except device_id and login_attempts for rate limiting)
      const deviceId = localStorage.getItem('device_id');
      const loginAttempts = localStorage.getItem('login_attempts');
      localStorage.clear();
      sessionStorage.clear();
      // Restore rate limiting data
      if (deviceId) localStorage.setItem('device_id', deviceId);
      if (loginAttempts) localStorage.setItem('login_attempts', loginAttempts);

      // Normalize username: trim and collapse multiple spaces to single space
      const normalizedUsername = username.trim().replace(/\s+/g, ' ');

      // SAVER/DEBITUR LOGIN
      // Format yang didukung: D + angka, akan dinormalisasi menjadi D + 5 digit (contoh: D00001)
      const saverMatch = normalizedUsername.trim().toUpperCase().match(/^D(\d+)$/);
      const normalizedSaverId = saverMatch
        ? `D${saverMatch[1].slice(-5).padStart(5, "0")}`
        : null;

      if (normalizedSaverId) {
        const typedPassword = password.trim();

        // Login via backend function (bypass RLS sebelum user punya sesi)
        const { data: loginData, error: loginError } = await supabase.functions.invoke(
          "saver-login",
          {
            body: {
              saverNumber: normalizedSaverId,
              password: typedPassword,
            },
          }
        );

        if (loginError) {
          console.error("Saver login function error:", loginError);
          throw new Error("Terjadi kesalahan saat login. Silakan coba lagi.");
        }

        if (!loginData?.success || !loginData?.email || !loginData?.saver) {
          const isNotFound = !!loginData?.notFound;
          const code = String(loginData?.code ?? "");

          toast({
            title: "Login Gagal",
            description: isNotFound
              ? `ID Debitur tidak ditemukan atau tidak aktif. Gunakan format D00xxx (contoh: ${normalizedSaverId}).`
              : code === "DATA_INCOMPLETE"
                ? "Akun belum memiliki tanggal lahir. Hubungi admin."
                : "Username atau password tidak valid",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: loginData.email,
          password: typedPassword,
        });

        if (signInError) {
          console.error("Saver sign in error:", signInError);
          toast({
            title: "Login Gagal",
            description: "Username atau password tidak valid",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        const saver = loginData.saver;

        // Simpan data saver untuk UI (context)
        saverLogin({
          id: saver.id,
          saver_number: saver.saver_number,
          full_name: saver.full_name,
          account_number: saver.account_number,
          phone: saver.phone,
          address: saver.address,
          email: saver.email,
          photo_url: saver.photo_url,
          date_of_birth: saver.date_of_birth,
          occupation: saver.occupation,
          status: saver.status,
          created_at: saver.created_at,
          balance: saver.balance,
          deposit_balance: saver.deposit_balance,
          interest_balance: saver.interest_balance,
          tier_level: saver.tier_level,
        });

        // Reset login attempts on successful login
        resetLoginAttempts();
        setAttemptsRemaining(3);
        setIsBlocked(false);

        toast({
          title: "Login Berhasil",
          description: `Selamat datang, ${saver.full_name}!`,
        });

        navigate("/saver-dashboard", { replace: true });
        return;
      }

      // CUSTOMER LOGIN
      // Format yang didukung: N + angka, akan dinormalisasi menjadi N + 5 digit (contoh: N00195)
      const customerMatch = normalizedUsername.trim().toUpperCase().match(/^N(\d+)$/);
      const normalizedCustomerId = customerMatch
        ? `N${customerMatch[1].slice(-5).padStart(5, '0')}`
        : null;

      // Customer login via backend function — aman & tidak butuh akses tabel customers sebelum login
      if (normalizedCustomerId) {
        const typedPassword = password.trim();

        const { data: loginData, error: loginError } = await supabase.functions.invoke(
          "customer-login",
          {
            body: {
              idNumber: normalizedCustomerId,
              password: typedPassword,
            },
          }
        );

        if (loginError) {
          console.error("Customer login function error:", loginError);
          throw new Error("Terjadi kesalahan saat login. Silakan coba lagi.");
        }

        if (!loginData?.success || !loginData?.email) {
          const isNotFound = !!loginData?.notFound;
          toast({
            title: "Login Gagal",
            description: isNotFound
              ? `ID nasabah tidak ditemukan. Gunakan format N00xxx (contoh: ${normalizedCustomerId}).`
              : "Username atau password tidak valid",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: loginData.email,
          password: typedPassword,
        });

        if (signInError) {
          console.error("Customer sign in error:", signInError);
          toast({
            title: "Login Gagal",
            description: "Username atau password tidak valid",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        // Reset login attempts on successful login
        resetLoginAttempts();
        setAttemptsRemaining(3);
        setIsBlocked(false);

        toast({
          title: "Login Berhasil",
          description: `Selamat datang, ${loginData.fullName ?? normalizedCustomerId}!`,
        });

        navigate("/customer-dashboard", { replace: true });
        return;
      }


      // If not customer, check if this is a member (staff)
      const {
        data: memberResponse,
        error: memberError
      } = await supabase.functions.invoke("find-member-by-name", {
        body: {
          fullName: normalizedUsername
        }
      });
      if (memberError) {
        console.error("Error finding member via function:", memberError);
        throw new Error("Terjadi kesalahan saat mencari username");
      }
      const memberPayload: any = memberResponse;
      if (!memberPayload?.success && memberPayload?.notFound) {
        throw new Error("Login Gagal. Silahkan masukkan username atau sandi yang benar dan coba kembali.");
      }
      if (!memberPayload?.success || !memberPayload?.member) {
        console.error("Member lookup failed:", memberPayload);
        throw new Error(memberPayload?.error || "Terjadi kesalahan saat mencari username");
      }
      const memberData = memberPayload.member;

      // Check if user is admin, owner, or kasir (check both user_roles table AND position field)
      const {
        data: roleData
      } = await supabase.from("user_roles").select("role").eq("user_id", memberData.user_id).in("role", ["admin", "owner", "kasir"]).maybeSingle();
      const positionLower = memberData.position?.toLowerCase() || '';
      const isOwner = positionLower === 'owner' || roleData?.role === 'owner';
      const isAdmin = positionLower === 'admin' || roleData?.role === 'admin';
      const isAdminOrOwner = isAdmin || isOwner || !!roleData;
      const isKasir = positionLower === 'kasir' || roleData?.role === 'kasir';

      // Member's date of birth
      const memberDOB = memberData.date_of_birth ? new Date(memberData.date_of_birth) : null;
      const dobDay = memberDOB ? String(memberDOB.getDate()).padStart(2, '0') : '';
      const dobMonth = memberDOB ? String(memberDOB.getMonth() + 1).padStart(2, '0') : '';
      const dobYear = memberDOB ? memberDOB.getFullYear() : '' as any;
      const expectedPassword = memberDOB ? `${dobDay}${dobMonth}${dobYear}` : null;

      // Construct email from cleaned full_name (trim and remove all spaces)
      const cleanedName = memberData.full_name.trim().replace(/\s+/g, '').toLowerCase();
      const email = `${cleanedName}@system.local`;
      const typedPassword = password.trim();
      let authPassword = typedPassword;

      // Enforce strict credential rules
      if (!memberDOB) {
        throw new Error("Tanggal lahir belum diisi pada data anggota. Mohon lengkapi tanggal lahir untuk dapat login.");
      }

      // OWNER: uses time-based password (DDMMYYYYHHMM) + Supercode
      if (isOwner) {
        const validationResult = validateTimePassword(typedPassword, expectedPassword as string);
        if (!validationResult.valid) {
          throw new Error(validationResult.error || "Password tidak valid");
        }

        // Use DOB password for auth (since that's what's stored in auth)
        authPassword = expectedPassword as string;

        // Store pending login data
        setPendingOwnerData({
          email,
          authPassword,
          fullName: memberData.full_name,
          memberData
        });

        // Show Supercode dialog
        setSupercodeDialogOpen(true);
        setLoading(false);
        return; // Stop here, wait for Supercode input
      }

      // ADMIN: uses time-based password (DDMMYYYYHHMM) but NO Supercode
      if (isAdmin) {
        const validationResult = validateTimePassword(typedPassword, expectedPassword as string);
        if (!validationResult.valid) {
          throw new Error(validationResult.error || "Password tidak valid");
        }

        // Use DOB password for auth (since that's what's stored in auth)
        authPassword = expectedPassword as string;
      }

      // KASIR & SALES: use DOB only (DDMMYYYY)
      if (!isAdmin && !isOwner) {
        if (typedPassword !== expectedPassword) {
          throw new Error("Username atau password tidak valid");
        }
        authPassword = expectedPassword as string;
      }

      // KASIR: requires additional PIN verification
      if (isKasir) {
        // Store pending login data
        setPendingKasirData({
          email,
          authPassword,
          fullName: memberData.full_name,
          memberData
        });

        // Show PIN dialog
        setPinDialogOpen(true);
        setLoading(false);
        return; // Stop here, wait for PIN input
      }

      // Attempt sign-in with the chosen password first
      let {
        error: signInError
      } = await supabase.auth.signInWithPassword({
        email,
        password: authPassword
      });

      // Auto-heal path for invalid credentials: (re)create auth user and retry with DOB password
      if (signInError && isAdminOrOwner && /invalid login credentials/i.test(signInError.message)) {
        try {
          if (!memberDOB) {
            throw new Error("Tanggal lahir belum diisi pada data anggota. Mohon lengkapi tanggal lahir untuk dapat login.");
          }
          console.warn('Invalid credentials, attempting to (re)create member auth...');
          const {
            error: ensureErr
          } = await supabase.functions.invoke('create-member-auth', {
            body: {
              memberId: memberData.id,
              fullName: memberData.full_name,
              dateOfBirth: memberData.date_of_birth,
              position: memberData.position
            }
          });
          if (ensureErr) {
            console.error('ensure auth error:', ensureErr);
          }

          // Wait a moment for auth system to update
          await new Promise(resolve => setTimeout(resolve, 1000));

          // Retry sign-in with DOB password as the canonical one
          const retry = await supabase.auth.signInWithPassword({
            email,
            password: expectedPassword as string
          });
          signInError = retry.error ?? null;
        } catch (fErr: any) {
          console.error('Auto-heal failed:', fErr);
          if (!signInError) {
            signInError = fErr;
          }
        }
      }
      if (signInError) {
        console.error("Sign in error:", signInError);
        throw new Error(typeof signInError.message === 'string' ? signInError.message : 'Gagal masuk.');
      }

      // CRITICAL: Check if member is active before allowing login
      if (!memberData.is_active) {
        console.warn("Login blocked: Member is inactive");
        await supabase.auth.signOut();
        throw new Error("⚠️ Akun Anda telah dinonaktifkan. Silakan hubungi administrator untuk informasi lebih lanjut.");
      }

      // Redirect based on role - CRITICAL: Each role to their specific page
      let redirectPath = "/dashboard"; // Default for owner/admin

      if (isKasir) {
        redirectPath = "/cashier-dashboard";
      } else if (!isAdmin && !isOwner) {
        // Sales role
        redirectPath = "/sales-performance";
      }
      // Reset login attempts on successful login
      resetLoginAttempts();
      setAttemptsRemaining(3);
      setIsBlocked(false);
      
      toast({
        title: "Login Berhasil",
        description: `Selamat datang, ${memberData.full_name}!`
      });

      // CRITICAL: Use replace to prevent back navigation and clear any cached routes
      navigate(redirectPath, {
        replace: true
      });
    } catch (error: any) {
      console.error("Login error:", error);
      
      // Record failed login attempt
      const attemptResult = recordFailedAttempt();
      setAttemptsRemaining(attemptResult.attemptsRemaining);
      
      if (attemptResult.blocked) {
        setIsBlocked(true);
        setBlockRemainingMinutes(attemptResult.lockoutMinutes);
        toast({
          title: "Akses Login Dibekukan",
          description: `Terlalu banyak percobaan gagal. Akses login dibekukan selama ${attemptResult.lockoutMinutes} menit.`,
          variant: "destructive"
        });
      } else {
        toast({
          title: "Login Gagal",
          description: `${error?.message || "Username atau password tidak valid"}. Sisa percobaan: ${attemptResult.attemptsRemaining}`,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
  };
  const resetOwnerForm = () => {
    setFormData({
      full_name: "",
      phone: "",
      nik: "",
      address: "",
      supercode: ""
    });
    setDateOfBirth(undefined);
    setPhotoFile(null);
    setPhotoPreview(null);
  };
  const handleCreateOwner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dateOfBirth) {
      toast({
        title: "Tanggal lahir diperlukan",
        description: "Silakan pilih tanggal lahir untuk membuat akun login",
        variant: "destructive"
      });
      return;
    }
    if (!formData.supercode || formData.supercode.length < 6) {
      toast({
        title: "Supercode diperlukan",
        description: "Supercode minimal 6 karakter untuk keamanan aplikasi",
        variant: "destructive"
      });
      return;
    }
    setUploading(true);
    try {
      const formattedDOB = format(dateOfBirth, "yyyy-MM-dd");

      // Upload photo first if exists
      let photoUrl = "";
      if (photoFile) {
        const fileName = `owner-${Date.now()}.jpg`;
        const compressedFile = await compressImage(photoFile);
        const {
          error: uploadError
        } = await supabase.storage.from("member-photos").upload(fileName, compressedFile);
        if (uploadError) {
          console.error("Upload error:", uploadError);
          toast({
            title: "Gagal upload foto",
            description: uploadError.message,
            variant: "destructive"
          });
          setUploading(false);
          return;
        }
        const {
          data: {
            publicUrl
          }
        } = supabase.storage.from("member-photos").getPublicUrl(fileName);
        photoUrl = publicUrl;
      }
      const {
        error
      } = await supabase.functions.invoke('create-first-owner', {
        body: {
          fullName: formData.full_name,
          dateOfBirth: formattedDOB,
          phone: formData.phone,
          nik: formData.nik,
          address: formData.address,
          photoUrl: photoUrl || null,
          supercode: formData.supercode
        }
      });
      if (error) throw error;
      const day = String(dateOfBirth.getDate()).padStart(2, '0');
      const month = String(dateOfBirth.getMonth() + 1).padStart(2, '0');
      const year = dateOfBirth.getFullYear();
      const expectedPassword = `${day}${month}${year}`;
      toast({
        title: "Akun Owner Berhasil Dibuat",
        description: `Silakan login dengan username: ${formData.full_name}`
      });
      setShowOwnerDialog(false);
      setUsername(formData.full_name);
      setPassword(expectedPassword);
      setOwnerExists(true);
      resetOwnerForm();
    } catch (error: any) {
      toast({
        title: "Gagal membuat akun owner",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };
  return <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10">
      <Card className="w-full max-w-md relative">
        <Button variant="ghost" size="icon" className="absolute right-4 top-4 h-8 w-8 rounded-full hover:bg-accent z-10" onClick={() => navigate("/")} type="button">
          <X className="h-4 w-4" />
        </Button>
        <CardHeader className="text-center">
          <div className="flex flex-col items-center gap-4 mb-4">
            {logoUrl ? <div className="w-20 h-20 rounded-lg overflow-hidden animate-logo-container">
                <img key={logoUrl} src={logoUrl} alt="Logo" className="w-full h-full object-cover animate-logo" />
              </div> : <div className="mx-auto w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                <Building2 className="w-6 h-6 text-primary-foreground" />
              </div>}
            <h2 className="font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent font-mono text-3xl">
              {businessLoading ? "Memuat..." : businessName || "Sistem Kredit"}
            </h2>
          </div>
          
          <CardDescription>
            Silakan masuk dengan username dan password Anda
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Lockout Warning Banner */}
          {isBlocked && (
            <div className="mb-4 p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
              <div className="flex items-center gap-3 text-destructive">
                <AlertTriangle className="h-5 w-5 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Akses Login Dibekukan</p>
                  <p className="text-sm flex items-center gap-1 mt-1">
                    <Clock className="h-3 w-3" />
                    Silakan tunggu {blockRemainingMinutes} menit sebelum mencoba lagi
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {/* Attempts Warning */}
          {!isBlocked && attemptsRemaining < 3 && attemptsRemaining > 0 && (
            <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
              <div className="flex items-center gap-2 text-yellow-600 dark:text-yellow-500">
                <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                <p className="text-sm">
                  Sisa percobaan login: <span className="font-bold">{attemptsRemaining}</span>
                </p>
              </div>
            </div>
          )}
          
          <form onSubmit={handleAuth} className="space-y-4">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input 
                id="username" 
                type="text" 
                value={username} 
                onChange={e => setUsername(e.target.value.toUpperCase())} 
                placeholder="Masukkan username" 
                required 
                disabled={isBlocked}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input 
                  id="password" 
                  type={showPassword ? "text" : "password"} 
                  value={password} 
                  onChange={e => setPassword(e.target.value)} 
                  placeholder="Masukkan password" 
                  required 
                  disabled={isBlocked}
                />
                <button 
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  disabled={isBlocked}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={loading || isBlocked}>
              {isBlocked ? `Dibekukan (${blockRemainingMinutes} menit)` : loading ? "Memproses..." : "Masuk"}
            </Button>
          </form>
          
          {!checkingOwner && !ownerExists && <div className="mt-4 pt-4 border-t">
              <Button type="button" variant="outline" className="w-full" onClick={() => setShowOwnerDialog(true)}>
                Buat Akun Owner Pertama
              </Button>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Klik tombol ini jika belum ada akun owner
              </p>
            </div>}
        </CardContent>
      </Card>

      <Dialog open={showOwnerDialog} onOpenChange={o => {
      setShowOwnerDialog(o);
      if (!o) resetOwnerForm();
    }}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Buat Akun Owner Pertama</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateOwner} className="space-y-4">
            <div>
              <Label>Foto</Label>
              <div className="flex flex-col items-center gap-4 mt-2">
                {photoPreview ? <div className="relative">
                    <Avatar className="w-32 h-32">
                      <AvatarImage src={photoPreview} alt="Owner photo" />
                      <AvatarFallback>Photo</AvatarFallback>
                    </Avatar>
                    <Button type="button" variant="destructive" size="icon" className="absolute -top-2 -right-2 h-6 w-6 rounded-full" onClick={removePhoto}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div> : <div className="w-32 h-32 border-2 border-dashed rounded-full flex items-center justify-center">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>}
                <div className="relative">
                  <Input type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" id="photo-upload" />
                  <Label htmlFor="photo-upload" className="cursor-pointer">
                    <Button type="button" variant="outline" asChild>
                      <span>
                        <Upload className="h-4 w-4 mr-2" />
                        Unggah Foto
                      </span>
                    </Button>
                  </Label>
                </div>
              </div>
            </div>
            <div>
              <Label htmlFor="full_name">Nama Lengkap</Label>
              <Input id="full_name" value={formData.full_name} onChange={e => setFormData({
              ...formData,
              full_name: e.target.value
            })} required />
            </div>
            <div>
              <Label>Tanggal Lahir *</Label>
              <DatePicker value={dateOfBirth} onChange={setDateOfBirth} placeholder="dd/MM/yyyy" disabled={date => date > new Date() || date < new Date("1900-01-01")} />
              <p className="text-sm text-muted-foreground mt-1">
                Tanggal lahir akan digunakan untuk membuat password unik
              </p>
            </div>
            <div>
              <Label htmlFor="nik">NIK</Label>
              <Input id="nik" value={formData.nik} onChange={e => setFormData({
              ...formData,
              nik: e.target.value
            })} placeholder="Nomor Induk Kependudukan" />
            </div>
            <div>
              <Label htmlFor="phone">Nomor Telepon</Label>
              <Input id="phone" type="tel" value={formData.phone} onChange={e => setFormData({
              ...formData,
              phone: e.target.value
            })} placeholder="Masukkan nomor telepon" required />
            </div>
            <div>
              <Label htmlFor="address">Alamat</Label>
              <Input id="address" value={formData.address} onChange={e => setFormData({
              ...formData,
              address: e.target.value
            })} placeholder="Masukkan alamat" />
            </div>
            <div>
              <Label htmlFor="supercode">Supercode * (minimal 6 karakter)</Label>
              <Input id="supercode" type="password" value={formData.supercode} onChange={e => setFormData({
              ...formData,
              supercode: e.target.value
            })} placeholder="Buat supercode untuk keamanan" minLength={6} required />
              <p className="text-sm text-muted-foreground mt-1">
                Supercode akan digunakan untuk verifikasi operasi sensitif di aplikasi
              </p>
            </div>
            <Button type="submit" className="w-full" disabled={uploading}>
              {uploading ? "Menyimpan..." : "Buat Akun Owner"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Supercode Verification Dialog - Only shown for Owner login */}
      <Dialog open={supercodeDialogOpen} onOpenChange={open => {
      if (!open) {
        setSupercodeDialogOpen(false);
        setSupercodeInput("");
        setPendingOwnerData(null);
        setLoading(false);
      }
    }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Verifikasi Supercode Owner</DialogTitle>
          </DialogHeader>
          <form onSubmit={async e => {
          e.preventDefault();
          setLoading(true);
          try {
            if (!pendingOwnerData) {
              throw new Error("Data login tidak ditemukan");
            }

            // Verify supercode via edge function
            const {
              data: supercodeData,
              error: supercodeError
            } = await supabase.functions.invoke('verify-supercode', {
              body: {
                superCodeInput: supercodeInput.trim(),
                operation: 'owner_login'
              }
            });
            if (supercodeError || !supercodeData?.valid) {
              throw new Error("Supercode tidak valid");
            }

            // Supercode valid, proceed with sign in
            let {
              error: signInError
            } = await supabase.auth.signInWithPassword({
              email: pendingOwnerData.email,
              password: pendingOwnerData.authPassword
            });

            // Auto-heal path if needed
            if (signInError && /invalid login credentials/i.test(signInError.message)) {
              try {
                console.warn('Invalid credentials, attempting to (re)create member auth...');
                const {
                  error: ensureErr
                } = await supabase.functions.invoke('create-member-auth', {
                  body: {
                    memberId: pendingOwnerData.memberData.id,
                    fullName: pendingOwnerData.memberData.full_name,
                    dateOfBirth: pendingOwnerData.memberData.date_of_birth,
                    position: pendingOwnerData.memberData.position
                  }
                });
                if (ensureErr) {
                  console.error('ensure auth error:', ensureErr);
                }
                await new Promise(resolve => setTimeout(resolve, 1000));
                const retry = await supabase.auth.signInWithPassword({
                  email: pendingOwnerData.email,
                  password: pendingOwnerData.authPassword
                });
                signInError = retry.error ?? null;
              } catch (fErr: any) {
                console.error('Auto-heal failed:', fErr);
                if (!signInError) {
                  signInError = fErr;
                }
              }
            }
            if (signInError) {
              console.error("Sign in error:", signInError);
              throw new Error(typeof signInError.message === 'string' ? signInError.message : 'Gagal masuk.');
            }

            // CRITICAL: Check if member is active before allowing login
            if (!pendingOwnerData.memberData.is_active) {
              console.warn("Login blocked: Owner is inactive");
              await supabase.auth.signOut();
              // Clean up
              setSupercodeDialogOpen(false);
              setSupercodeInput("");
              setPendingOwnerData(null);
              throw new Error("⚠️ Akun Anda telah dinonaktifkan. Silakan hubungi administrator untuk informasi lebih lanjut.");
            }
            // Reset login attempts on successful login
            resetLoginAttempts();
            setAttemptsRemaining(3);
            setIsBlocked(false);
            
            toast({
              title: "Login Berhasil",
              description: `Selamat datang, ${pendingOwnerData.fullName}!`
            });

            // Clean up
            setSupercodeDialogOpen(false);
            setSupercodeInput("");
            setPendingOwnerData(null);

            // CRITICAL: Use replace to prevent back navigation
            navigate("/dashboard", {
              replace: true
            });
          } catch (error: any) {
            console.error("Supercode verification error:", error);
            toast({
              title: "Verifikasi Gagal",
              description: error?.message || "Supercode tidak valid",
              variant: "destructive"
            });
          } finally {
            setLoading(false);
          }
        }} className="space-y-4">
            <div>
              <Label htmlFor="supercode-verify">Masukkan Supercode</Label>
              <Input id="supercode-verify" type="password" value={supercodeInput} onChange={e => setSupercodeInput(e.target.value)} placeholder="Supercode Owner" required autoFocus />
              <p className="text-sm text-muted-foreground mt-2">
                Username dan password telah diverifikasi. Masukkan Supercode untuk melanjutkan akses ke aplikasi.
              </p>
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => {
              setSupercodeDialogOpen(false);
              setSupercodeInput("");
              setPendingOwnerData(null);
              setLoading(false);
            }} disabled={loading}>
                Batal
              </Button>
              <Button type="submit" className="flex-1" disabled={loading}>
                {loading ? "Memverifikasi..." : "Verifikasi"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Kasir PIN Verification Dialog */}
      <Dialog open={pinDialogOpen} onOpenChange={open => {
      if (!open) {
        setPinDialogOpen(false);
        setPinInput("");
        setPendingKasirData(null);
        setLoading(false);
      }
    }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Verifikasi PIN Kasir</DialogTitle>
          </DialogHeader>
          <form onSubmit={async e => {
          e.preventDefault();
          setLoading(true);
          try {
            if (!pendingKasirData) {
              throw new Error("Data login tidak ditemukan");
            }

            // Verify PIN via RPC function
            const {
              data: pinValid,
              error: pinError
            } = await supabase.rpc('verify_kasir_pin', {
              p_member_id: pendingKasirData.memberData.id,
              p_pin_input: pinInput.trim()
            });
            if (pinError || !pinValid) {
              throw new Error("PIN tidak valid");
            }

            // PIN valid, proceed with sign in
            let {
              error: signInError
            } = await supabase.auth.signInWithPassword({
              email: pendingKasirData.email,
              password: pendingKasirData.authPassword
            });

            // Auto-heal path if needed
            if (signInError && /invalid login credentials/i.test(signInError.message)) {
              try {
                console.warn('Invalid credentials, attempting to (re)create kasir auth...');
                const {
                  error: ensureErr
                } = await supabase.functions.invoke('create-member-auth', {
                  body: {
                    memberId: pendingKasirData.memberData.id,
                    fullName: pendingKasirData.memberData.full_name,
                    dateOfBirth: pendingKasirData.memberData.date_of_birth,
                    position: pendingKasirData.memberData.position,
                    pin: pendingKasirData.memberData.pin
                  }
                });
                if (ensureErr) {
                  console.error('ensure auth error:', ensureErr);
                }
                await new Promise(resolve => setTimeout(resolve, 1000));
                const retry = await supabase.auth.signInWithPassword({
                  email: pendingKasirData.email,
                  password: pendingKasirData.authPassword
                });
                signInError = retry.error ?? null;
              } catch (fErr: any) {
                console.error('Auto-heal failed:', fErr);
                if (!signInError) {
                  signInError = fErr;
                }
              }
            }
            if (signInError) {
              console.error("Sign in error:", signInError);
              throw new Error(typeof signInError.message === 'string' ? signInError.message : 'Gagal masuk.');
            }

            // CRITICAL: Check if member is active before allowing login
            if (!pendingKasirData.memberData.is_active) {
              console.warn("Login blocked: Kasir is inactive");
              await supabase.auth.signOut();
              // Clean up
              setPinDialogOpen(false);
              setPinInput("");
              setPendingKasirData(null);
              throw new Error("⚠️ Akun Anda telah dinonaktifkan. Silakan hubungi administrator untuk informasi lebih lanjut.");
            }
            // Reset login attempts on successful login
            resetLoginAttempts();
            setAttemptsRemaining(3);
            setIsBlocked(false);
            
            toast({
              title: "Login Berhasil",
              description: `Selamat datang, ${pendingKasirData.fullName}!`
            });

            // Clean up
            setPinDialogOpen(false);
            setPinInput("");
            setPendingKasirData(null);

            // CRITICAL: Use replace to prevent back navigation
            navigate("/cashier-dashboard", {
              replace: true
            });
          } catch (error: any) {
            console.error("PIN verification error:", error);
            toast({
              title: "Verifikasi Gagal",
              description: error?.message || "PIN tidak valid",
              variant: "destructive"
            });
          } finally {
            setLoading(false);
          }
        }} className="space-y-4">
            <div>
              <Label htmlFor="pin-verify">Masukkan PIN Kasir</Label>
              <Input id="pin-verify" type="password" value={pinInput} onChange={e => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 6))} placeholder="6 digit PIN" maxLength={6} required autoFocus />
              <p className="text-sm text-muted-foreground mt-2">
                Username dan password telah diverifikasi. Masukkan PIN Kasir untuk melanjutkan.
              </p>
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => {
              setPinDialogOpen(false);
              setPinInput("");
              setPendingKasirData(null);
              setLoading(false);
            }} disabled={loading}>
                Batal
              </Button>
              <Button type="submit" className="flex-1" disabled={loading || pinInput.length !== 6}>
                {loading ? "Memverifikasi..." : "Verifikasi"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>;
};
export default Auth;