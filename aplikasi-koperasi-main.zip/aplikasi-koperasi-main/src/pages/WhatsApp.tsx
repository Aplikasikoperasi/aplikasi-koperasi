import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, AlertTriangle, Clock, CheckCircle, Send, Check } from "lucide-react";
import { formatRupiah, formatDate, getTodayDateStringInWIB, getDateStringInWIB } from "@/lib/utils";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { generateInstallmentReminderMessage, generatePaymentReceiptMessage, generateWhatsAppLink, generateDisbursementNotification, openWhatsAppChat } from "@/lib/whatsappHelper";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
export default function WhatsApp() {
  const [overdueInstallments, setOverdueInstallments] = useState<any[]>([]);
  const [upcomingInstallments, setUpcomingInstallments] = useState<any[]>([]);
  const [recentPayments, setRecentPayments] = useState<any[]>([]);
  const [recentDisbursements, setRecentDisbursements] = useState<any[]>([]);
  const [penaltyRate, setPenaltyRate] = useState(2.0);
  const [sentMessages, setSentMessages] = useState<Set<string>>(new Set());

  // Pagination states
  const [overduePage, setOverduePage] = useState(1);
  const [upcomingPage, setUpcomingPage] = useState(1);
  const [paymentsPage, setPaymentsPage] = useState(1);
  const [disbursementsPage, setDisbursementsPage] = useState(1);
  const itemsPerPage = 20;

  // Search states
  const [overdueSearch, setOverdueSearch] = useState("");
  const [upcomingSearch, setUpcomingSearch] = useState("");
  const [paymentsSearch, setPaymentsSearch] = useState("");
  const [disbursementsSearch, setDisbursementsSearch] = useState("");
  const [bankInfo, setBankInfo] = useState<{
    bankName: string;
    bankAccountNumber: string;
    bankAccountHolder: string;
  } | null>(null);
  const {
    toast
  } = useToast();
  useEffect(() => {
    loadSettings();
    loadOverdueInstallments();
    loadUpcomingInstallments();
    loadRecentPayments();
    loadRecentDisbursements();
    loadBankInfo();
  }, []);
  const loadSettings = async () => {
    const {
      data
    } = await supabase.rpc('get_public_app_settings');
    if (data) {
      setPenaltyRate((data as any)?.penalty_rate_per_day || 2.0);
    }
  };
  const loadBankInfo = async () => {
    try {
      const {
        data: bankDataRaw
      } = await supabase.from("bank_accounts" as any).select("bank_name, account_number, account_holder").eq("is_primary", true).eq("is_active", true).maybeSingle();
      const bankData = bankDataRaw as any;
      if (bankData && bankData.bank_name) {
        setBankInfo({
          bankName: bankData.bank_name,
          bankAccountNumber: bankData.account_number,
          bankAccountHolder: bankData.account_holder
        });
      }
    } catch (error) {
      console.error("Error loading bank info:", error);
    }
  };
  const loadOverdueInstallments = async () => {
    const today = getTodayDateStringInWIB();

    // Get current user's member_id for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let currentMemberId = null;
    let isSalesUser = false;
    if (user) {
      const {
        data: roleData
      } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
      isSalesUser = roleData?.role === 'sales';
      if (isSalesUser) {
        const {
          data: memberData
        } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
        currentMemberId = memberData?.id;
      }
    }

    // For sales: get customer IDs they registered
    let relatedCustomerIds: string[] = [];
    if (isSalesUser && currentMemberId) {
      const {
        data: customersData
      } = await supabase.from("customers").select("id").eq("created_by", currentMemberId);
      relatedCustomerIds = customersData?.map(c => c.id) || [];
    }
    let query = supabase.from('installments').select(`
        *,
        credit_applications!application_id!inner(
          application_number,
          customer_id,
          member_id,
          customers!inner(id, full_name, phone, photo_url, id_number, date_of_birth, credit_score),
          members!inner(full_name)
        )
      `).lt('due_date', today).in('status', ['unpaid', 'partial', 'overdue']).order('due_date', {
      ascending: true
    });
    const {
      data,
      error
    } = await query;
    if (error) {
      console.error('Error loading overdue installments:', error);
      return;
    }

    // Filter for sales users client-side
    let filteredData = data || [];
    if (isSalesUser && currentMemberId) {
      // Filter: show if application created by sales OR customer registered by sales
      filteredData = filteredData.filter(inst => {
        const app: any = (inst as any).credit_applications;
        const appData = Array.isArray(app) ? app[0] : app;
        return appData?.member_id === currentMemberId || appData?.customer_id && relatedCustomerIds.includes(appData.customer_id);
      });
    }
    
    // Normalize to ensure nested relations are objects, not arrays
    const normalizedData = filteredData.map(inst => {
      const app: any = (inst as any).credit_applications;
      const appObj: any = Array.isArray(app) ? app[0] : app;
      const normalizedApp: any = { ...appObj };
      if (Array.isArray(appObj?.customers)) {
        normalizedApp.customers = appObj.customers[0];
      }
      if (Array.isArray(appObj?.members)) {
        normalizedApp.members = appObj.members[0];
      }
      return { ...inst, credit_applications: normalizedApp };
    });
    
    setOverdueInstallments(normalizedData);
  };
  const loadUpcomingInstallments = async () => {
    const todayStr = getDateStringInWIB(0);
    const threeDaysLaterStr = getDateStringInWIB(3);

    // Get current user's member_id for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let currentMemberId = null;
    let isSalesUser = false;
    if (user) {
      const {
        data: roleData
      } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
      isSalesUser = roleData?.role === 'sales';
      if (isSalesUser) {
        const {
          data: memberData
        } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
        currentMemberId = memberData?.id;
      }
    }

    // For sales: get customer IDs they registered
    let relatedCustomerIds: string[] = [];
    if (isSalesUser && currentMemberId) {
      const {
        data: customersData
      } = await supabase.from("customers").select("id").eq("created_by", currentMemberId);
      relatedCustomerIds = customersData?.map(c => c.id) || [];
    }
    let query = supabase.from('installments').select(`
        *,
        credit_applications!application_id!inner(
          application_number,
          customer_id,
          member_id,
          customers!inner(id, full_name, phone, photo_url, id_number, date_of_birth, credit_score),
          members!inner(full_name)
        )
      `).gte('due_date', todayStr).lte('due_date', threeDaysLaterStr).eq('status', 'unpaid').order('due_date', {
      ascending: true
    });
    const {
      data,
      error
    } = await query;
    if (error) {
      console.error('Error loading upcoming installments:', error);
      return;
    }

    // Filter for sales users client-side
    let filteredData = data || [];
    if (isSalesUser && currentMemberId) {
      // Filter: show if application created by sales OR customer registered by sales
      filteredData = filteredData.filter(inst => {
        const app: any = (inst as any).credit_applications;
        const appData = Array.isArray(app) ? app[0] : app;
        return appData?.member_id === currentMemberId || appData?.customer_id && relatedCustomerIds.includes(appData.customer_id);
      });
    }
    
    // Normalize credit_applications to always be an object, not an array
    const normalizedData = filteredData.map(inst => {
      const app: any = (inst as any).credit_applications;
      if (Array.isArray(app)) {
        return { ...inst, credit_applications: app[0] };
      }
      return inst;
    });
    
    setUpcomingInstallments(normalizedData);
  };
  const loadRecentPayments = async () => {
    const sevenDaysAgoStr = getDateStringInWIB(-7);

    // Get current user's member_id for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let currentMemberId = null;
    let isSalesUser = false;
    if (user) {
      const {
        data: roleData
      } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
      isSalesUser = roleData?.role === 'sales';
      if (isSalesUser) {
        const {
          data: memberData
        } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
        currentMemberId = memberData?.id;
      }
    }

    // For sales: get customer IDs they registered
    let relatedCustomerIds: string[] = [];
    if (isSalesUser && currentMemberId) {
      const {
        data: customersData
      } = await supabase.from("customers").select("id").eq("created_by", currentMemberId);
      relatedCustomerIds = customersData?.map(c => c.id) || [];
    }
    let query = supabase.from('payments').select(`
        *,
        installments!installment_id!inner(
          installment_number, 
          frozen_penalty, 
          total_amount, 
          paid_amount
        ),
        credit_applications!application_id!inner(
          application_number,
          member_id,
          customer_id,
          customers!inner(id, full_name, phone, id_number, date_of_birth, credit_score)
        )
      `).gte('payment_date', sevenDaysAgoStr).order('payment_date', {
      ascending: false
    }).limit(10);
    const {
      data,
      error
    } = await query;
    if (error) {
      console.error('Error loading recent payments:', error);
      return;
    }

    // Filter for sales users client-side
    let filteredData = data || [];
    if (isSalesUser && currentMemberId) {
      // Filter: show if application created by sales OR customer registered by sales
      filteredData = filteredData.filter(payment => payment.credit_applications?.member_id === currentMemberId || payment.credit_applications?.customer_id && relatedCustomerIds.includes(payment.credit_applications.customer_id));
    }
    
    // Normalize nested relationships to always be objects, not arrays
    const normalizedData = filteredData.map(payment => {
      const normalized: any = { ...payment };
      if (Array.isArray(payment.credit_applications)) {
        normalized.credit_applications = payment.credit_applications[0];
      }
      if (Array.isArray(payment.installments)) {
        normalized.installments = payment.installments[0];
      }
      return normalized;
    });
    
    setRecentPayments(normalizedData);
  };
  const loadRecentDisbursements = async () => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    // Get current user's member_id for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let currentMemberId = null;
    let isSalesUser = false;
    if (user) {
      const {
        data: roleData
      } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
      isSalesUser = roleData?.role === 'sales';
      if (isSalesUser) {
        const {
          data: memberData
        } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
        currentMemberId = memberData?.id;
      }
    }

    // For sales: get customer IDs they registered
    let relatedCustomerIds: string[] = [];
    if (isSalesUser && currentMemberId) {
      const {
        data: customersData
      } = await supabase.from("customers").select("id").eq("created_by", currentMemberId);
      relatedCustomerIds = customersData?.map(c => c.id) || [];
    }
    let query = supabase.from('credit_applications').select(`
        *,
        customers!inner(id, full_name, phone, id_number, date_of_birth, credit_score),
        installments!inner(due_date, total_amount)
      `).eq('status', 'approved').gte('approved_at', sevenDaysAgo.toISOString()).order('approved_at', {
      ascending: false
    }).limit(10);
    const {
      data,
      error
    } = await query;
    if (error) {
      console.error('Error loading recent disbursements:', error);
      return;
    }

    // Filter for sales users client-side
    let filteredData = data || [];
    if (isSalesUser && currentMemberId) {
      // Filter: show if application created by sales OR customer registered by sales
      filteredData = filteredData.filter(app => app.member_id === currentMemberId || app.customer_id && relatedCustomerIds.includes(app.customer_id));
    }
    
    // Normalize nested relationships to always be objects, not arrays
    const normalizedData = filteredData.map(app => {
      const normalized: any = { ...app };
      if (Array.isArray(app.customers)) {
        normalized.customers = app.customers[0];
      }
      if (Array.isArray(app.installments)) {
        normalized.installments = app.installments[0];
      }
      return normalized;
    });
    
    setRecentDisbursements(normalizedData);
  };
  const calculatePenalty = (installment: any): number => {
    const dueDate = new Date(installment.due_date);
    const today = new Date();
    const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
    if (daysOverdue <= 0) return 0;
    const totalAmount = Number(installment.total_amount);
    const penaltyAmount = totalAmount * (penaltyRate / 100) * daysOverdue;
    return penaltyAmount;
  };
  const getDaysOverdue = (dueDate: string): number => {
    const due = new Date(dueDate);
    const today = new Date();
    return Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
  };
  const getUnsentCount = (items: any[], idPrefix: string): number => {
    return items.filter(item => !sentMessages.has(`${idPrefix}-${item.id}`)).length;
  };
  const sortBySentStatus = (items: any[], idPrefix: string) => {
    return [...items].sort((a, b) => {
      const aIsSent = sentMessages.has(`${idPrefix}-${a.id}`);
      const bIsSent = sentMessages.has(`${idPrefix}-${b.id}`);
      if (aIsSent && !bIsSent) return 1;
      if (!aIsSent && bIsSent) return -1;
      return 0;
    });
  };
  // Remove local openWhatsAppChat - using imported one from whatsappHelper.ts
  const paginateData = (data: any[], page: number) => {
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return data.slice(startIndex, endIndex);
  };
  const getTotalPages = (dataLength: number) => {
    return Math.ceil(dataLength / itemsPerPage);
  };
  const filterOverdueData = (data: any[]) => {
    if (!overdueSearch.trim()) return data;
    const search = overdueSearch.toLowerCase();
    return data.filter(item => item.credit_applications.customers.full_name.toLowerCase().includes(search) || item.credit_applications.application_number.toLowerCase().includes(search) || item.credit_applications.members.full_name.toLowerCase().includes(search));
  };
  const filterUpcomingData = (data: any[]) => {
    if (!upcomingSearch.trim()) return data;
    const search = upcomingSearch.toLowerCase();
    return data.filter(item => item.credit_applications.customers.full_name.toLowerCase().includes(search) || item.credit_applications.application_number.toLowerCase().includes(search) || item.credit_applications.members.full_name.toLowerCase().includes(search));
  };
  const filterPaymentsData = (data: any[]) => {
    if (!paymentsSearch.trim()) return data;
    const search = paymentsSearch.toLowerCase();
    return data.filter(item => item.credit_applications.customers.full_name.toLowerCase().includes(search) || item.credit_applications.application_number.toLowerCase().includes(search) || item.payment_method.toLowerCase().includes(search));
  };
  const filterDisbursementsData = (data: any[]) => {
    if (!disbursementsSearch.trim()) return data;
    const search = disbursementsSearch.toLowerCase();
    return data.filter(item => item.customers.full_name.toLowerCase().includes(search) || item.application_number.toLowerCase().includes(search));
  };
  const handleSendReminder = (installment: any) => {
    console.info('[WA] handleSendReminder clicked:', installment?.id);
    const app = installment?.credit_applications;
    const customer = app?.customers;
    const member = app?.members;

    const customerPhone = customer?.phone as string | undefined;
    console.info('[WA] customerPhone:', customerPhone);
    if (!customerPhone) {
      toast({
        title: "Error",
        description: "Nomor telepon nasabah tidak tersedia",
        variant: "destructive"
      });
      return;
    }

    try {
      // Validasi nomor WhatsApp terlebih dahulu agar tidak silent-fail
      const testLink = generateWhatsAppLink(customerPhone, "test", 'api');
      console.info('[WA] testLink:', testLink);
      if (testLink === '#') {
        toast({
          title: "Nomor tidak valid",
          description: "Nomor WhatsApp tidak valid. Gunakan format internasional (mis. 628xx).",
          variant: "destructive"
        });
        return;
      }

      const daysOverdue = getDaysOverdue(installment.due_date);
      const penalty = daysOverdue > 0 ? calculatePenalty(installment) : 0;

      const message = generateInstallmentReminderMessage({
        customerName: customer?.full_name || "Nasabah",
        customerPhone,
        installmentNumber: Number(installment.installment_number) || 0,
        dueDate: installment.due_date,
        totalAmount: Number(installment.total_amount) || 0,
        daysOverdue: daysOverdue > 0 ? daysOverdue : undefined,
        penalty: penalty > 0 ? penalty : undefined,
        memberName: member?.full_name || "Petugas",
        applicationNumber: app?.application_number || "",
        creditScore: typeof customer?.credit_score === 'number' ? Number(customer.credit_score) : undefined,
        customerIdNumber: customer?.id_number || undefined,
        dateOfBirth: customer?.date_of_birth || undefined,
        bankName: bankInfo?.bankName,
        bankAccountNumber: bankInfo?.bankAccountNumber,
        bankAccountHolder: bankInfo?.bankAccountHolder
      });

      console.info('[WA] opening chat with message length:', message.length);
      openWhatsAppChat(customerPhone, message);
      setSentMessages(prev => new Set(prev).add(`installment-${installment.id}`));
      toast({
        title: "WhatsApp Dibuka",
        description: "Pesan reminder telah disiapkan. Klik Send untuk mengirim."
      });
    } catch (e) {
      console.error("Gagal membuat/membuka pesan WhatsApp untuk tunggakan:", e);
      toast({
        title: "Gagal mengirim",
        description: "Terjadi kesalahan saat menyiapkan pesan. Coba lagi.",
        variant: "destructive"
      });
    }
  };
  const handleSendReceipt = (payment: any) => {
    const customerPhone = payment.credit_applications?.customers?.phone;
    if (!customerPhone) {
      toast({
        title: "Error",
        description: "Nomor telepon nasabah tidak tersedia",
        variant: "destructive"
      });
      return;
    }
    const message = generatePaymentReceiptMessage({
      customerName: payment.credit_applications.customers.full_name,
      paymentDate: payment.payment_date,
      amount: Number(payment.amount),
      installmentNumber: payment.installments.installment_number,
      paymentMethod: payment.payment_method,
      referenceNumber: payment.reference_number,
      applicationNumber: payment.credit_applications.application_number,
      creditScore: payment.credit_applications.customers.credit_score,
      customerIdNumber: payment.credit_applications.customers.id_number,
      dateOfBirth: payment.credit_applications.customers.date_of_birth,
      remainingPenalty: Number(payment.installments?.frozen_penalty || 0),
      totalAmount: Number(payment.installments?.total_amount || 0),
      paidAmount: Number(payment.installments?.paid_amount || 0),
      bankName: bankInfo?.bankName,
      bankAccountNumber: bankInfo?.bankAccountNumber,
      bankAccountHolder: bankInfo?.bankAccountHolder
    });
    openWhatsAppChat(customerPhone, message);
    setSentMessages(prev => new Set(prev).add(`payment-${payment.id}`));
    toast({
      title: "WhatsApp Dibuka",
      description: "Bukti pembayaran telah disiapkan."
    });
  };
  const handleSendDisbursementNotif = (application: any) => {
    const customerPhone = application.customers?.phone;
    if (!customerPhone) {
      toast({
        title: "Error",
        description: "Nomor telepon nasabah tidak tersedia",
        variant: "destructive"
      });
      return;
    }
    const firstInstallment = application.installments?.[0];
    if (!firstInstallment) return;
    const message = generateDisbursementNotification({
      customerName: application.customers.full_name,
      amountApproved: Number(application.amount_approved),
      tenor: application.tenor_months,
      interestRate: Number(application.interest_rate),
      monthlyInstallment: Number(firstInstallment.total_amount),
      firstInstallmentDate: firstInstallment.due_date,
      applicationNumber: application.application_number,
      creditScore: application.customers.credit_score,
      customerIdNumber: application.customers.id_number,
      dateOfBirth: application.customers.date_of_birth
    });
    openWhatsAppChat(customerPhone, message);
    setSentMessages(prev => new Set(prev).add(`disbursement-${application.id}`));
    toast({
      title: "WhatsApp Dibuka",
      description: "Notifikasi pencairan telah disiapkan."
    });
  };
  return <div className="w-full p-mobile">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 mb-3">
        <div className="flex items-center gap-2 sm:gap-3">
          <MessageCircle className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div>
            <h1 className="text-2xl font-semibold">WhatsApp Notifications</h1>
            
          </div>
        </div>
      </div>

      <Tabs defaultValue="overdue" className="space-y-3 sm:space-y-4">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto gap-1">
          <TabsTrigger value="overdue" className="flex items-center gap-1 sm:gap-2 min-h-[44px] text-mobile-sm py-2 px-2 sm:px-3">
            <AlertTriangle className="h-4 w-4 flex-shrink-0" />
            <span className="hidden sm:inline">Tunggakan</span>
            <span className="sm:hidden">Tunggak</span>
            <span>({getUnsentCount(overdueInstallments, 'installment')})</span>
          </TabsTrigger>
          <TabsTrigger value="upcoming" className="flex items-center gap-1 sm:gap-2 min-h-[44px] text-mobile-sm py-2 px-2 sm:px-3">
            <Clock className="h-4 w-4 flex-shrink-0" />
            <span className="hidden sm:inline">Jatuh Tempo</span>
            <span className="sm:hidden">J.Tempo</span>
            <span>({getUnsentCount(upcomingInstallments, 'installment')})</span>
          </TabsTrigger>
          <TabsTrigger value="receipts" className="flex items-center gap-1 sm:gap-2 min-h-[44px] text-mobile-sm py-2 px-2 sm:px-3">
            <CheckCircle className="h-4 w-4 flex-shrink-0" />
            <span className="hidden sm:inline">Bukti Bayar</span>
            <span className="sm:hidden">Bukti</span>
            <span>({getUnsentCount(recentPayments, 'payment')})</span>
          </TabsTrigger>
          <TabsTrigger value="disbursements" className="flex items-center gap-1 sm:gap-2 min-h-[44px] text-mobile-sm py-2 px-2 sm:px-3">
            <Send className="h-4 w-4 flex-shrink-0" />
            <span className="hidden sm:inline">Pencairan</span>
            <span className="sm:hidden">Cair</span>
            <span>({getUnsentCount(recentDisbursements, 'disbursement')})</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overdue">
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-mobile-lg">
                <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />
                Angsuran Tertunggak
              </CardTitle>
              <CardDescription className="text-mobile-sm">
                Kirim pengingat kepada nasabah yang angsurannya tertunggak
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <Input placeholder="Cari nasabah, nomor aplikasi, atau petugas..." value={overdueSearch} onChange={e => {
              setOverdueSearch(e.target.value);
              setOverduePage(1);
            }} className="w-full sm:max-w-sm" />
              {/* Desktop Table View */}
              <div className="hidden lg:block w-full">
                <ScrollArea className="h-[calc(100vh-420px)] rounded-md border">
                  <div className="overflow-x-auto w-full">
                    <Table className="w-full">
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead>Nasabah</TableHead>
                        <TableHead>No. Aplikasi</TableHead>
                        <TableHead>Angsuran</TableHead>
                        <TableHead>Jatuh Tempo</TableHead>
                        <TableHead>Jumlah</TableHead>
                        <TableHead>Denda</TableHead>
                        <TableHead>Penanggung Jawab</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {overdueInstallments.length === 0 ? <TableRow>
                          <TableCell colSpan={8} className="text-center text-muted-foreground">
                            Tidak ada angsuran tertunggak
                          </TableCell>
                        </TableRow> : filterOverdueData(overdueInstallments).length === 0 ? <TableRow>
                          <TableCell colSpan={8} className="text-center text-muted-foreground">
                            Tidak ada hasil pencarian
                          </TableCell>
                        </TableRow> : paginateData(sortBySentStatus(filterOverdueData(overdueInstallments), 'installment'), overduePage).map(installment => {
                        const daysOverdue = getDaysOverdue(installment.due_date);
                        const penalty = calculatePenalty(installment);
                        return <TableRow key={installment.id}>
                              <TableCell className="font-medium">
                                {installment.credit_applications.customers.full_name}
                              </TableCell>
                              <TableCell className="font-bold">{installment.credit_applications.application_number}</TableCell>
                              <TableCell>
                                <Badge variant="outline">Ke-{installment.installment_number}</Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  {formatDate(installment.due_date)}
                                  <Badge variant="destructive" className="text-xs">
                                    +{daysOverdue} hari
                                  </Badge>
                                </div>
                              </TableCell>
                              <TableCell>{formatRupiah(Number(installment.total_amount))}</TableCell>
                              <TableCell className="text-destructive font-medium">
                                {formatRupiah(penalty)}
                              </TableCell>
                              <TableCell>{installment.credit_applications.members.full_name}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Button size="sm" onClick={() => handleSendReminder(installment)} className="flex items-center gap-2">
                                    <Send className="h-4 w-4" />
                                    Kirim Pesan
                                  </Button>
                                  {sentMessages.has(`installment-${installment.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                      <Check className="h-3 w-3" />
                                      Terkirim
                                    </Badge>}
                                </div>
                              </TableCell>
                            </TableRow>;
                      })}
                    </TableBody>
                  </Table>
                    </div>
                </ScrollArea>
              </div>

              {/* Mobile & Tablet Card View */}
              <div className="lg:hidden w-full max-w-full overflow-hidden">
                <ScrollArea className="h-[500px] w-full">
                  <div className="space-y-2 w-full max-w-full px-1">
                    {overdueInstallments.length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada angsuran tertunggak</p> : filterOverdueData(overdueInstallments).length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada hasil pencarian</p> : paginateData(sortBySentStatus(filterOverdueData(overdueInstallments), 'installment'), overduePage).map(installment => {
                    const daysOverdue = getDaysOverdue(installment.due_date);
                    const penalty = calculatePenalty(installment);
                    return <Card key={installment.id} className="p-2.5 w-full max-w-full overflow-hidden">
                            <div className="space-y-1.5 w-full max-w-full">
                              <div className="flex items-start justify-between gap-2 w-full max-w-full overflow-hidden">
                                <div className="flex-1 min-w-0 overflow-hidden">
                                  <p className="font-semibold text-mobile-base truncate">
                                    {installment.credit_applications.customers.full_name}
                                  </p>
                                  <p className="text-mobile-sm text-muted-foreground truncate">
                                    {installment.credit_applications.application_number}
                                  </p>
                                </div>
                                <Badge variant="outline" className="flex-shrink-0 text-xs">
                                  Ke-{installment.installment_number}
                                </Badge>
                              </div>
                              
                              <div className="grid grid-cols-1 xs:grid-cols-2 gap-1.5 text-mobile-sm w-full">
                                <div className="min-w-0 overflow-hidden">
                                  <span className="text-muted-foreground text-xs">Jatuh Tempo:</span>
                                  <p className="font-medium text-xs truncate">{formatDate(installment.due_date)}</p>
                                  <Badge variant="destructive" className="text-xs mt-0.5">
                                    +{daysOverdue} hari
                                  </Badge>
                                </div>
                                <div className="min-w-0 overflow-hidden">
                                  <span className="text-muted-foreground text-xs">Jumlah:</span>
                                  <p className="font-medium text-xs break-words">{formatRupiah(Number(installment.total_amount))}</p>
                                  <p className="text-destructive font-medium text-xs mt-0.5 break-words">
                                    Denda: {formatRupiah(penalty)}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="text-mobile-sm w-full overflow-hidden">
                                <span className="text-muted-foreground text-xs">Petugas: </span>
                                <span className="font-medium text-xs truncate inline-block max-w-[calc(100%-60px)] align-bottom">{installment.credit_applications.members.full_name}</span>
                              </div>
                              
                              <div className="flex flex-col xs:flex-row items-stretch xs:items-center gap-2 pt-1.5 w-full">
                                <Button size="sm" onClick={() => handleSendReminder(installment)} className="flex-1 min-h-[44px] text-sm">
                                  <Send className="h-4 w-4 mr-2 flex-shrink-0" />
                                  <span className="truncate">Kirim Pesan</span>
                                </Button>
                                {sentMessages.has(`installment-${installment.id}`) && <Badge variant="secondary" className="flex items-center gap-1 justify-center xs:justify-start flex-shrink-0">
                                    <Check className="h-3 w-3" />
                                    Terkirim
                                  </Badge>}
                              </div>
                            </div>
                          </Card>;
                  })}
                  </div>
                </ScrollArea>
              </div>
              {filterOverdueData(overdueInstallments).length > itemsPerPage && <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious onClick={() => setOverduePage(p => Math.max(1, p - 1))} className={overduePage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                    {Array.from({
                  length: getTotalPages(filterOverdueData(overdueInstallments).length)
                }, (_, i) => i + 1).map(page => <PaginationItem key={page}>
                        <PaginationLink onClick={() => setOverduePage(page)} isActive={page === overduePage} className="cursor-pointer">
                          {page}
                        </PaginationLink>
                      </PaginationItem>)}
                    <PaginationItem>
                      <PaginationNext onClick={() => setOverduePage(p => Math.min(getTotalPages(filterOverdueData(overdueInstallments).length), p + 1))} className={overduePage === getTotalPages(filterOverdueData(overdueInstallments).length) ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming">
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-mobile-lg">
                <Clock className="h-5 w-5 text-warning flex-shrink-0" />
                Angsuran Akan Jatuh Tempo
              </CardTitle>
              <CardDescription className="text-mobile-sm">
                Kirim pengingat kepada nasabah yang angsurannya akan jatuh tempo dalam 3 hari
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <Input placeholder="Cari nasabah, nomor aplikasi, atau petugas..." value={upcomingSearch} onChange={e => {
              setUpcomingSearch(e.target.value);
              setUpcomingPage(1);
            }} className="w-full sm:max-w-sm" />
              {/* Desktop Table View */}
              <div className="hidden lg:block w-full">
                <ScrollArea className="h-[calc(100vh-420px)] rounded-md border">
                  <div className="overflow-x-auto w-full">
                    <Table className="w-full">
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead>Nasabah</TableHead>
                        <TableHead>No. Aplikasi</TableHead>
                        <TableHead>Angsuran</TableHead>
                        <TableHead>Jatuh Tempo</TableHead>
                        <TableHead>Jumlah</TableHead>
                        <TableHead>Penanggung Jawab</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {upcomingInstallments.length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            Tidak ada angsuran yang akan jatuh tempo
                          </TableCell>
                        </TableRow> : filterUpcomingData(upcomingInstallments).length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            Tidak ada hasil pencarian
                          </TableCell>
                        </TableRow> : paginateData(sortBySentStatus(filterUpcomingData(upcomingInstallments), 'installment'), upcomingPage).map(installment => <TableRow key={installment.id}>
                            <TableCell className="font-medium">
                              {installment.credit_applications.customers.full_name}
                            </TableCell>
                            <TableCell className="font-bold">{installment.credit_applications.application_number}</TableCell>
                            <TableCell>
                              <Badge variant="outline">Ke-{installment.installment_number}</Badge>
                            </TableCell>
                            <TableCell>{formatDate(installment.due_date)}</TableCell>
                            <TableCell>{formatRupiah(Number(installment.total_amount))}</TableCell>
                            <TableCell>{installment.credit_applications.members.full_name}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button size="sm" onClick={() => handleSendReminder(installment)} className="flex items-center gap-2">
                                  <Send className="h-4 w-4" />
                                  Kirim Pesan
                                </Button>
                                {sentMessages.has(`installment-${installment.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                    <Check className="h-3 w-3" />
                                    Terkirim
                                  </Badge>}
                              </div>
                            </TableCell>
                          </TableRow>)}
                    </TableBody>
                  </Table>
                    </div>
                </ScrollArea>
              </div>

              {/* Mobile & Tablet Card View */}
              <div className="lg:hidden">
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {upcomingInstallments.length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada angsuran yang akan jatuh tempo</p> : filterUpcomingData(upcomingInstallments).length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada hasil pencarian</p> : paginateData(sortBySentStatus(filterUpcomingData(upcomingInstallments), 'installment'), upcomingPage).map(installment => <Card key={installment.id} className="p-2.5">
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <p className="font-semibold text-mobile-base truncate">
                                  {installment.credit_applications.customers.full_name}
                                </p>
                                <p className="text-mobile-sm text-muted-foreground">
                                  {installment.credit_applications.application_number}
                                </p>
                              </div>
                              <Badge variant="outline" className="flex-shrink-0">
                                Ke-{installment.installment_number}
                              </Badge>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 text-mobile-sm">
                              <div>
                                <span className="text-muted-foreground">Jatuh Tempo:</span>
                                <p className="font-medium">{formatDate(installment.due_date)}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Jumlah:</span>
                                <p className="font-medium">{formatRupiah(Number(installment.total_amount))}</p>
                              </div>
                            </div>
                            
                            <div className="text-mobile-sm">
                              <span className="text-muted-foreground">Petugas: </span>
                              <span className="font-medium text-xs">{installment.credit_applications.members.full_name}</span>
                            </div>
                            
                            <div className="flex items-center gap-2 pt-1.5">
                              <Button size="sm" onClick={() => handleSendReminder(installment)} className="flex-1 min-h-[44px]">
                                <Send className="h-4 w-4 mr-2" />
                                Kirim Pesan
                              </Button>
                              {sentMessages.has(`installment-${installment.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                  <Check className="h-3 w-3" />
                                  Terkirim
                                </Badge>}
                            </div>
                          </div>
                        </Card>)}
                  </div>
                </ScrollArea>
              </div>
              {filterUpcomingData(upcomingInstallments).length > itemsPerPage && <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious onClick={() => setUpcomingPage(p => Math.max(1, p - 1))} className={upcomingPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                    {Array.from({
                  length: getTotalPages(filterUpcomingData(upcomingInstallments).length)
                }, (_, i) => i + 1).map(page => <PaginationItem key={page}>
                        <PaginationLink onClick={() => setUpcomingPage(page)} isActive={page === upcomingPage} className="cursor-pointer">
                          {page}
                        </PaginationLink>
                      </PaginationItem>)}
                    <PaginationItem>
                      <PaginationNext onClick={() => setUpcomingPage(p => Math.min(getTotalPages(filterUpcomingData(upcomingInstallments).length), p + 1))} className={upcomingPage === getTotalPages(filterUpcomingData(upcomingInstallments).length) ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="receipts">
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-mobile-lg">
                <CheckCircle className="h-5 w-5 text-success flex-shrink-0" />
                Bukti Pembayaran
              </CardTitle>
              <CardDescription className="text-mobile-sm">
                Kirim bukti pembayaran kepada nasabah (7 hari terakhir)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <Input placeholder="Cari nasabah, nomor aplikasi, atau metode..." value={paymentsSearch} onChange={e => {
              setPaymentsSearch(e.target.value);
              setPaymentsPage(1);
            }} className="w-full sm:max-w-sm" />
              
              {/* Desktop Table View */}
              <div className="hidden lg:block w-full">
                <ScrollArea className="h-[calc(100vh-420px)] rounded-md border">
                  <div className="overflow-x-auto w-full">
                    <Table className="w-full">
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead>Nasabah</TableHead>
                        <TableHead>No. Aplikasi</TableHead>
                        <TableHead>Angsuran</TableHead>
                        <TableHead>Tanggal Bayar</TableHead>
                        <TableHead>Jumlah</TableHead>
                        <TableHead>Metode</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentPayments.length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            Tidak ada pembayaran dalam 7 hari terakhir
                          </TableCell>
                        </TableRow> : filterPaymentsData(recentPayments).length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            Tidak ada hasil pencarian
                          </TableCell>
                        </TableRow> : paginateData(sortBySentStatus(filterPaymentsData(recentPayments), 'payment'), paymentsPage).map(payment => <TableRow key={payment.id}>
                            <TableCell className="font-medium">
                              {payment.credit_applications.customers.full_name}
                            </TableCell>
                            <TableCell className="font-bold">{payment.credit_applications.application_number}</TableCell>
                            <TableCell>
                              <Badge variant="outline">Ke-{payment.installments.installment_number}</Badge>
                            </TableCell>
                            <TableCell>{formatDate(payment.payment_date)}</TableCell>
                            <TableCell>{formatRupiah(Number(payment.amount))}</TableCell>
                            <TableCell>
                              <Badge>{payment.payment_method}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button size="sm" onClick={() => handleSendReceipt(payment)} className="flex items-center gap-2">
                                  <Send className="h-4 w-4" />
                                  Kirim Pesan
                                </Button>
                                {sentMessages.has(`payment-${payment.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                    <Check className="h-3 w-3" />
                                    Terkirim
                                  </Badge>}
                              </div>
                            </TableCell>
                          </TableRow>)}
                    </TableBody>
                  </Table>
                    </div>
                </ScrollArea>
              </div>

              {/* Mobile & Tablet Card View */}
              <div className="lg:hidden">
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {recentPayments.length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada pembayaran dalam 7 hari terakhir</p> : filterPaymentsData(recentPayments).length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada hasil pencarian</p> : paginateData(sortBySentStatus(filterPaymentsData(recentPayments), 'payment'), paymentsPage).map(payment => <Card key={payment.id} className="p-2.5">
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <p className="font-semibold text-mobile-base truncate">
                                  {payment.credit_applications.customers.full_name}
                                </p>
                                <p className="text-mobile-sm text-muted-foreground">
                                  {payment.credit_applications.application_number}
                                </p>
                              </div>
                              <Badge variant="outline" className="flex-shrink-0">
                                Ke-{payment.installments.installment_number}
                              </Badge>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 text-mobile-sm">
                              <div>
                                <span className="text-muted-foreground">Tanggal Bayar:</span>
                                <p className="font-medium">{formatDate(payment.payment_date)}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Jumlah:</span>
                                <p className="font-medium">{formatRupiah(Number(payment.amount))}</p>
                              </div>
                            </div>
                            
                            <div className="text-mobile-sm">
                              <span className="text-muted-foreground">Metode: </span>
                              <Badge className="ml-1">{payment.payment_method}</Badge>
                            </div>
                            
                            <div className="flex items-center gap-2 pt-1.5">
                              <Button size="sm" onClick={() => handleSendReceipt(payment)} className="flex-1 min-h-[44px]">
                                <Send className="h-4 w-4 mr-2" />
                                Kirim Pesan
                              </Button>
                              {sentMessages.has(`payment-${payment.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                  <Check className="h-3 w-3" />
                                  Terkirim
                                </Badge>}
                            </div>
                          </div>
                        </Card>)}
                  </div>
                </ScrollArea>
              </div>
              {filterPaymentsData(recentPayments).length > itemsPerPage && <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious onClick={() => setPaymentsPage(p => Math.max(1, p - 1))} className={paymentsPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                    {Array.from({
                  length: getTotalPages(filterPaymentsData(recentPayments).length)
                }, (_, i) => i + 1).map(page => <PaginationItem key={page}>
                        <PaginationLink onClick={() => setPaymentsPage(page)} isActive={page === paymentsPage} className="cursor-pointer">
                          {page}
                        </PaginationLink>
                      </PaginationItem>)}
                    <PaginationItem>
                      <PaginationNext onClick={() => setPaymentsPage(p => Math.min(getTotalPages(filterPaymentsData(recentPayments).length), p + 1))} className={paymentsPage === getTotalPages(filterPaymentsData(recentPayments).length) ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="disbursements">
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-mobile-lg">
                <Send className="h-5 w-5 text-primary flex-shrink-0" />
                Notifikasi Pencairan
              </CardTitle>
              <CardDescription className="text-mobile-sm">
                Kirim notifikasi pencairan kredit kepada nasabah (7 hari terakhir)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <Input placeholder="Cari nasabah atau nomor aplikasi..." value={disbursementsSearch} onChange={e => {
              setDisbursementsSearch(e.target.value);
              setDisbursementsPage(1);
            }} className="w-full sm:max-w-sm" />
              
              {/* Desktop Table View */}
              <div className="hidden lg:block w-full">
                <ScrollArea className="h-[calc(100vh-420px)] rounded-md border">
                  <div className="overflow-x-auto w-full">
                    <Table className="w-full">
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead>Nasabah</TableHead>
                        <TableHead>No. Aplikasi</TableHead>
                        <TableHead>Jumlah Disetujui</TableHead>
                        <TableHead>Tenor</TableHead>
                        <TableHead>Bunga</TableHead>
                        <TableHead>Tanggal Disetujui</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentDisbursements.length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            Tidak ada pencairan dalam 7 hari terakhir
                          </TableCell>
                        </TableRow> : filterDisbursementsData(recentDisbursements).length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            Tidak ada hasil pencarian
                          </TableCell>
                        </TableRow> : paginateData(sortBySentStatus(filterDisbursementsData(recentDisbursements), 'disbursement'), disbursementsPage).map(application => <TableRow key={application.id}>
                            <TableCell className="font-medium">
                              {application.customers.full_name}
                            </TableCell>
                            <TableCell className="font-bold">{application.application_number}</TableCell>
                            <TableCell>{formatRupiah(Number(application.amount_approved))}</TableCell>
                            <TableCell>{application.tenor_months} bulan</TableCell>
                            <TableCell>{application.interest_rate}%</TableCell>
                            <TableCell>{formatDate(application.approved_at)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button size="sm" onClick={() => handleSendDisbursementNotif(application)} className="flex items-center gap-2">
                                  <Send className="h-4 w-4" />
                                  Kirim Pesan
                                </Button>
                                {sentMessages.has(`disbursement-${application.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                    <Check className="h-3 w-3" />
                                    Terkirim
                                  </Badge>}
                              </div>
                            </TableCell>
                          </TableRow>)}
                    </TableBody>
                  </Table>
                    </div>
                </ScrollArea>
              </div>

              {/* Mobile & Tablet Card View */}
              <div className="lg:hidden">
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {recentDisbursements.length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada pencairan dalam 7 hari terakhir</p> : filterDisbursementsData(recentDisbursements).length === 0 ? <p className="text-center text-muted-foreground py-8">Tidak ada hasil pencarian</p> : paginateData(sortBySentStatus(filterDisbursementsData(recentDisbursements), 'disbursement'), disbursementsPage).map(application => <Card key={application.id} className="p-2.5">
                          <div className="space-y-1.5">
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-mobile-base truncate">
                                {application.customers.full_name}
                              </p>
                              <p className="text-mobile-sm text-muted-foreground">
                                {application.application_number}
                              </p>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 text-mobile-sm">
                              <div>
                                <span className="text-muted-foreground">Disetujui:</span>
                                <p className="font-semibold">{formatRupiah(Number(application.amount_approved))}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Tenor:</span>
                                <p className="font-medium">{application.tenor_months} bulan</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Bunga:</span>
                                <p className="font-medium">{application.interest_rate}%</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Tanggal:</span>
                                <p className="font-medium">{formatDate(application.approved_at)}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-2 pt-1.5">
                              <Button size="sm" onClick={() => handleSendDisbursementNotif(application)} className="flex-1 min-h-[44px]">
                                <Send className="h-4 w-4 mr-2" />
                                Kirim Pesan
                              </Button>
                              {sentMessages.has(`disbursement-${application.id}`) && <Badge variant="secondary" className="flex items-center gap-1">
                                  <Check className="h-3 w-3" />
                                  Terkirim
                                </Badge>}
                            </div>
                          </div>
                        </Card>)}
                  </div>
                </ScrollArea>
              </div>
              {filterDisbursementsData(recentDisbursements).length > itemsPerPage && <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious onClick={() => setDisbursementsPage(p => Math.max(1, p - 1))} className={disbursementsPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                    {Array.from({
                  length: getTotalPages(filterDisbursementsData(recentDisbursements).length)
                }, (_, i) => i + 1).map(page => <PaginationItem key={page}>
                        <PaginationLink onClick={() => setDisbursementsPage(page)} isActive={page === disbursementsPage} className="cursor-pointer">
                          {page}
                        </PaginationLink>
                      </PaginationItem>)}
                    <PaginationItem>
                      <PaginationNext onClick={() => setDisbursementsPage(p => Math.min(getTotalPages(filterDisbursementsData(recentDisbursements).length), p + 1))} className={disbursementsPage === getTotalPages(filterDisbursementsData(recentDisbursements).length) ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>;
}