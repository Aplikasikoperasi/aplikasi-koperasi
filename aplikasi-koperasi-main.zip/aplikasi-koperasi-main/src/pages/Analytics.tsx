import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatRupiah, formatDateWIB, getDateStringInWIB } from "@/lib/utils";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, Users, DollarSign, AlertTriangle, BarChart3, PieChart as PieChartIcon, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("30");
  const [loading, setLoading] = useState(true);
  
  // Sales Performance
  const [salesData, setSalesData] = useState<any[]>([]);
  const [topSales, setTopSales] = useState<any[]>([]);
  
  // Collectibility
  const [collectibilityData, setCollectibilityData] = useState<any>(null);
  const [agingData, setAgingData] = useState<any[]>([]);
  
  // Payment Trends
  const [paymentTrends, setPaymentTrends] = useState<any[]>([]);
  const [monthlyStats, setMonthlyStats] = useState<any[]>([]);

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadSalesPerformance(),
        loadCollectibility(),
        loadPaymentTrends(),
      ]);
    } catch (error) {
      console.error("Error loading analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadSalesPerformance = async () => {
    const daysAgo = parseInt(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    // Get applications by member
    const { data: applications } = await supabase
      .from("credit_applications")
      .select(`
        id,
        status,
        amount_approved,
        member_id,
        members!inner(id, full_name)
      `)
      .gte("created_at", startDate.toISOString());

    if (!applications) return;

    // Group by member
    const memberStats: Record<string, any> = {};
    
    applications.forEach((app: any) => {
      const memberId = app.member_id;
      const memberName = app.members?.full_name || "Unknown";
      
      if (!memberStats[memberId]) {
        memberStats[memberId] = {
          name: memberName,
          total: 0,
          approved: 0,
          pending: 0,
          rejected: 0,
          totalAmount: 0,
        };
      }
      
      memberStats[memberId].total++;
      
      if (app.status === "approved" || app.status === "disbursed" || app.status === "completed") {
        memberStats[memberId].approved++;
        memberStats[memberId].totalAmount += Number(app.amount_approved || 0);
      } else if (app.status === "pending") {
        memberStats[memberId].pending++;
      } else if (app.status === "rejected") {
        memberStats[memberId].rejected++;
      }
    });

    const salesArray = Object.values(memberStats)
      .sort((a: any, b: any) => b.totalAmount - a.totalAmount);

    setSalesData(salesArray);
    setTopSales(salesArray.slice(0, 5));
  };

  const loadCollectibility = async () => {
    // Get all applications (including completed)
    const { data: applications } = await supabase
      .from("credit_applications")
      .select(`
        id,
        amount_approved,
        installments!inner(
          id,
          status,
          due_date,
          total_amount,
          paid_amount,
          principal_paid,
          frozen_penalty
        )
      `)
      .in("status", ["approved", "disbursed", "completed"]);

    if (!applications) return;

    let totalLoan = 0;
    let totalPaid = 0;
    let totalOutstanding = 0;
    let totalOverdue = 0;
    let currentCount = 0;
    let overdueCount = 0;

    const agingBuckets = {
      "0-30": 0,
      "31-60": 0,
      "61-90": 0,
      "90+": 0,
    };

    applications.forEach((app: any) => {
      const installments = Array.isArray(app.installments) ? app.installments : [];
      
      installments.forEach((inst: any) => {
        const totalAmount = Number(inst.total_amount || 0);
        const paidAmount = Number(inst.paid_amount || 0);
        const penalty = Number(inst.frozen_penalty || 0);
        
        totalLoan += totalAmount;
        totalPaid += paidAmount;
        
        if (!inst.principal_paid) {
          const outstanding = totalAmount - paidAmount + penalty;
          totalOutstanding += outstanding;
          
          if (inst.status === "overdue") {
            totalOverdue += outstanding;
            overdueCount++;
            
            // Calculate aging
            const dueDate = new Date(inst.due_date);
            const today = new Date();
            const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
            
            if (daysOverdue <= 30) agingBuckets["0-30"] += outstanding;
            else if (daysOverdue <= 60) agingBuckets["31-60"] += outstanding;
            else if (daysOverdue <= 90) agingBuckets["61-90"] += outstanding;
            else agingBuckets["90+"] += outstanding;
          } else {
            currentCount++;
          }
        }
      });
    });

    const nplRatio = totalLoan > 0 ? (totalOverdue / totalLoan) * 100 : 0;
    const collectionRate = totalLoan > 0 ? (totalPaid / totalLoan) * 100 : 0;

    setCollectibilityData({
      totalLoan,
      totalPaid,
      totalOutstanding,
      totalOverdue,
      nplRatio,
      collectionRate,
      currentCount,
      overdueCount,
    });

    const agingArray = Object.entries(agingBuckets).map(([name, value]) => ({
      name,
      value: Number(value),
    }));
    
    setAgingData(agingArray);
  };

  const loadPaymentTrends = async () => {
    const daysAgo = parseInt(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    const { data: payments } = await supabase
      .from("payments")
      .select("payment_date, amount")
      .gte("payment_date", getDateStringInWIB(-parseInt(timeRange)))
      .order("payment_date");

    if (!payments) return;

    // Group by date
    const dailyPayments: Record<string, number> = {};
    
    payments.forEach((payment: any) => {
      const date = payment.payment_date;
      if (!dailyPayments[date]) {
        dailyPayments[date] = 0;
      }
      dailyPayments[date] += Number(payment.amount);
    });

    const trendsArray = Object.entries(dailyPayments)
      .map(([date, amount]) => ({
        date: formatDateWIB(date, 'medium').replace(/^\d+\s/, '').slice(0, 6), // "Jan 24" format
        amount: Number(amount),
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    setPaymentTrends(trendsArray);

    // Monthly stats for the last 6 months
    const { data: monthlyPayments } = await supabase
      .from("payments")
      .select("payment_date, amount")
      .gte("payment_date", getDateStringInWIB(-180));

    if (!monthlyPayments) return;

    const monthlyGroups: Record<string, number> = {};
    
    monthlyPayments.forEach((payment: any) => {
      const dateStr = formatDateWIB(payment.payment_date, 'medium');
      const monthKey = dateStr.split(' ').slice(1).join(' '); // "Jan 2024" format
      
      if (!monthlyGroups[monthKey]) {
        monthlyGroups[monthKey] = 0;
      }
      monthlyGroups[monthKey] += Number(payment.amount);
    });

    const monthlyArray = Object.entries(monthlyGroups)
      .map(([month, amount]) => ({ month, amount: Number(amount) }))
      .slice(-6);

    setMonthlyStats(monthlyArray);
  };

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-12 w-64" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <TrendingUp className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div>
            <h1 className="text-2xl font-semibold">Dashboard Analitik</h1>
            <p className="text-muted-foreground">Pantau performa dan tren bisnis Anda</p>
          </div>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">7 Hari Terakhir</SelectItem>
            <SelectItem value="30">30 Hari Terakhir</SelectItem>
            <SelectItem value="90">90 Hari Terakhir</SelectItem>
            <SelectItem value="180">6 Bulan Terakhir</SelectItem>
            <SelectItem value="365">1 Tahun Terakhir</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pinjaman</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatRupiah(collectibilityData?.totalLoan || 0)}
            </div>
            <p className="text-xs text-muted-foreground">Kredit aktif</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tingkat Koleksi</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {collectibilityData?.collectionRate.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              {formatRupiah(collectibilityData?.totalPaid || 0)} terkumpul
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">NPL Ratio</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${collectibilityData?.nplRatio > 5 ? "text-destructive" : "text-green-600"}`}>
              {collectibilityData?.nplRatio.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              {formatRupiah(collectibilityData?.totalOverdue || 0)} menunggak
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{salesData.length}</div>
            <p className="text-xs text-muted-foreground">Petugas aktif</p>
          </CardContent>
        </Card>
      </div>

      {/* Analytics Tabs */}
      <Tabs defaultValue="sales" className="space-y-4">
        <TabsList>
          <TabsTrigger value="sales">
            <Users className="h-4 w-4 mr-1.5" />
            Performa Sales
          </TabsTrigger>
          <TabsTrigger value="collectibility">
            <PieChartIcon className="h-4 w-4 mr-1.5" />
            Kolektibilitas
          </TabsTrigger>
          <TabsTrigger value="payments">
            <TrendingUp className="h-4 w-4 mr-1.5" />
            Tren Pembayaran
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sales" className="mt-3 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Top 5 Sales</CardTitle>
                <CardDescription>Berdasarkan total pencairan</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topSales}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => formatRupiah(Number(value))} />
                    <Bar dataKey="totalAmount" fill="#8884d8" name="Total Pencairan" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status Aplikasi per Sales</CardTitle>
                <CardDescription>Breakdown aplikasi</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topSales}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="approved" fill="#00C49F" name="Disetujui" stackId="a" />
                    <Bar dataKey="pending" fill="#FFBB28" name="Pending" stackId="a" />
                    <Bar dataKey="rejected" fill="#FF8042" name="Ditolak" stackId="a" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Detail Performa Sales</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {salesData.map((sale, idx) => (
                  <div key={idx} className="flex items-center justify-between border-b pb-3">
                    <div className="space-y-1">
                      <p className="font-medium">{sale.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {sale.total} aplikasi • {sale.approved} disetujui • {sale.pending} pending
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{formatRupiah(sale.totalAmount)}</p>
                      <p className="text-sm text-muted-foreground">
                        {sale.total > 0 ? ((sale.approved / sale.total) * 100).toFixed(0) : 0}% approval rate
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="collectibility" className="mt-3 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Aging Analysis</CardTitle>
                <CardDescription>Distribusi tunggakan berdasarkan usia</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={agingData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name} hari: ${formatRupiah(value)}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {agingData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatRupiah(Number(value))} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status Angsuran</CardTitle>
                <CardDescription>Current vs Overdue</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Lancar", value: collectibilityData?.currentCount || 0 },
                        { name: "Menunggak", value: collectibilityData?.overdueCount || 0 },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      <Cell fill="#00C49F" />
                      <Cell fill="#FF8042" />
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Ringkasan Kolektibilitas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Total Outstanding</p>
                  <p className="text-2xl font-bold">{formatRupiah(collectibilityData?.totalOutstanding || 0)}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">NPL Amount</p>
                  <p className="text-2xl font-bold text-destructive">{formatRupiah(collectibilityData?.totalOverdue || 0)}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Collection Rate</p>
                  <p className="text-2xl font-bold text-green-600">{collectibilityData?.collectionRate.toFixed(1)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="mt-3 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tren Pembayaran Harian</CardTitle>
              <CardDescription>Pembayaran dalam {timeRange} hari terakhir</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={paymentTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatRupiah(Number(value))} />
                  <Line type="monotone" dataKey="amount" stroke="#8884d8" name="Jumlah Pembayaran" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Pembayaran Bulanan</CardTitle>
              <CardDescription>6 bulan terakhir</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyStats}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatRupiah(Number(value))} />
                  <Bar dataKey="amount" fill="#00C49F" name="Total Pembayaran" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
