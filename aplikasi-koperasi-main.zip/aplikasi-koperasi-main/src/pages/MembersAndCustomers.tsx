import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, UserPlus, Wallet } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Members from "./Members";
import CustomersWithSubTabs from "./CustomersWithSubTabs";
import Savers from "./Savers";

export default function MembersAndCustomers() {
  const location = useLocation();
  const navigate = useNavigate();
  const [memberCount, setMemberCount] = useState(0);
  const [saverCount, setSaverCount] = useState(0);
  const [totalCustomerCount, setTotalCustomerCount] = useState(0);
  const [activeTab, setActiveTab] = useState("members");

  // Handle navigation state for editing
  useEffect(() => {
    if (location.state) {
      const state = location.state as any;
      if (state.openTab) {
        setActiveTab(state.openTab);
      }
      if (state.editCustomer) {
        // Store in sessionStorage for Customers component to pick up
        sessionStorage.setItem('editCustomer', JSON.stringify(state.editCustomer));
        // Clear the navigation state
        navigate(location.pathname, {
          replace: true,
          state: {}
        });
      }
    }
  }, [location.state]);
  
  useEffect(() => {
    loadMemberCount();
    loadSaverCount();
    loadTotalCustomerCount();

    // Set up realtime subscriptions
    const membersChannel = supabase.channel('members-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'members'
    }, () => loadMemberCount()).subscribe();
    
    const saversChannel = supabase.channel('savers-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'savers'
    }, () => loadSaverCount()).subscribe();
    
    const customersChannel = supabase.channel('customers-total-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, () => loadTotalCustomerCount()).subscribe();
    
    const blockedChannel = supabase.channel('blocked-total-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'blocked_customers'
    }, () => loadTotalCustomerCount()).subscribe();
    
    return () => {
      supabase.removeChannel(membersChannel);
      supabase.removeChannel(saversChannel);
      supabase.removeChannel(customersChannel);
      supabase.removeChannel(blockedChannel);
    };
  }, []);
  
  const loadMemberCount = async () => {
    const { count } = await supabase.from("members").select("id", {
      count: 'exact',
      head: true
    });
    setMemberCount(count || 0);
  };
  
  const loadSaverCount = async () => {
    const { count } = await supabase.from("savers").select("id", {
      count: 'exact',
      head: true
    }).eq("status", "active");
    setSaverCount(count || 0);
  };
  
  const loadTotalCustomerCount = async () => {
    const [activeResult, blockedResult] = await Promise.all([
      supabase.from("customers").select("id", { count: 'exact', head: true }).eq("status", "approved"),
      supabase.from("blocked_customers").select("id", { count: 'exact', head: true })
    ]);
    const activeCount = activeResult.count || 0;
    const blockedCount = blockedResult.count || 0;
    setTotalCustomerCount(activeCount + blockedCount);
  };
  
  return (
    <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-4 w-full max-w-full overflow-hidden mb-3">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div>
            <h1 className="text-2xl font-semibold truncate max-w-full">Data Anggota & Nasabah</h1>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="members" className="gap-1 text-xs sm:text-sm">
            <Users className="h-4 w-4 hidden sm:block" />
            <span>Anggota ({memberCount})</span>
          </TabsTrigger>
          <TabsTrigger value="customers" className="gap-1 text-xs sm:text-sm">
            <UserPlus className="h-4 w-4 hidden sm:block" />
            <span>Nasabah ({totalCustomerCount})</span>
          </TabsTrigger>
          <TabsTrigger value="savers" className="gap-1 text-xs sm:text-sm">
            <Wallet className="h-4 w-4 hidden sm:block" />
            <span>Debitur ({saverCount})</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="members" className="mt-3">
          <Members />
        </TabsContent>

        <TabsContent value="customers" className="mt-3">
          <CustomersWithSubTabs />
        </TabsContent>

        <TabsContent value="savers" className="mt-3">
          <Savers />
        </TabsContent>
      </Tabs>
    </div>
  );
}