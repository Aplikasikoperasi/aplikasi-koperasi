import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProfileSettings } from "@/components/settings/ProfileSettings";
import { SystemSettings } from "@/components/settings/SystemSettings";
import { BackupSettings } from "@/components/settings/BackupSettings";
import { SystemLogs } from "@/components/settings/SystemLogs";
import { BankAccountSettings } from "@/components/settings/BankAccountSettings";
import { WhatsAppSettings } from "@/components/settings/WhatsAppSettings";
import WhatsAppMonitoring from "@/components/settings/WhatsAppMonitoring";
import WhatsAppTemplates from "@/components/settings/WhatsAppTemplates";
import { WhatsAppAutoReminder } from "@/components/settings/WhatsAppAutoReminder";
import { IncentiveSettings } from "@/components/settings/IncentiveSettings";
import { BannerSettings } from "@/components/settings/BannerSettings";
import { DepositAccountSettings } from "@/components/settings/DepositAccountSettings";
import { useUserRole } from "@/hooks/useUserRole";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, Settings2, User, MessageCircle, Award, Database, Activity, Sliders, Eye, FileText, Image, CreditCard, Wallet } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { SuperCodeProvider } from "@/contexts/SuperCodeContext";
const Settings = () => {
  const [user, setUser] = useState<any>(null);
  const [resetting, setResetting] = useState(false);
  const [isOwner, setIsOwner] = useState(false);
  const [superCodeDialogOpen, setSuperCodeDialogOpen] = useState(false);
  const [superCodeInput, setSuperCodeInput] = useState("");
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const {
    role,
    loading
  } = useUserRole();
  const {
    toast
  } = useToast();
  const navigate = useNavigate();

  // Redirect non-owner users
  useEffect(() => {
    if (!loading && role && role !== 'owner') {
      toast({
        title: "Akses Ditolak",
        description: "Anda tidak memiliki izin untuk mengakses pengaturan.",
        variant: "destructive"
      });
      navigate("/dashboard");
    }
  }, [role, loading, navigate, toast]);
  useEffect(() => {
    supabase.auth.getSession().then(({
      data: {
        session
      }
    }) => {
      if (session) {
        setUser(session.user);
        // Check if user is owner from members table as fallback
        checkIfOwner(session.user.id);
      }
    });
  }, []);
  const checkIfOwner = async (userId: string) => {
    const {
      data
    } = await supabase.from("members").select("position").eq("user_id", userId).ilike("position", "owner").single();
    setIsOwner(!!data || role === 'owner');
  };
  useEffect(() => {
    if (role === 'owner') {
      setIsOwner(true);
    }
  }, [role]);
  const verifySuperCode = async (): Promise<boolean> => {
    try {
      // Use secure server-side verification via edge function
      const {
        data: result,
        error
      } = await supabase.functions.invoke('verify-supercode', {
        body: {
          superCodeInput: superCodeInput,
          operation: 'reset_owner_account'
        }
      });
      if (error) {
        toast({
          title: "Error",
          description: "Gagal memverifikasi SuperCode. Silakan coba lagi.",
          variant: "destructive"
        });
        return false;
      }
      if (!result?.valid) {
        toast({
          title: "SuperCode Salah",
          description: result?.error || "SuperCode tidak valid",
          variant: "destructive"
        });
        return false;
      }
      return true;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Gagal memverifikasi SuperCode",
        variant: "destructive"
      });
      return false;
    }
  };
  const handleSuperCodeSubmit = async () => {
    const isValid = await verifySuperCode();
    if (isValid) {
      setSuperCodeDialogOpen(false);
      setSuperCodeInput("");
      setResetDialogOpen(true);
    }
  };
  const openResetDialog = () => {
    setSuperCodeDialogOpen(true);
    setSuperCodeInput("");
  };
  const handleResetOwner = async () => {
    setResetting(true);
    try {
      // Step 1: Reset SuperCode in app_settings (set to null)
      const {
        error: supercodeError
      } = await supabase.from("app_settings").update({
        super_code: null
      }).not("id", "is", null);
      if (supercodeError) {
        console.error("Error resetting supercode:", supercodeError);
        throw new Error("Gagal mereset SuperCode");
      }

      // Step 2: Get all owner members
      const {
        data: owners,
        error: fetchError
      } = await supabase.from("members").select("id, user_id").ilike("position", "owner");
      if (fetchError) throw fetchError;

      // Step 3: Delete all owner members (this will cascade delete auth users)
      for (const owner of owners || []) {
        const {
          error: deleteError
        } = await supabase.from("members").delete().eq("id", owner.id);
        if (deleteError) throw deleteError;
      }
      toast({
        title: "Akun Owner & SuperCode Berhasil Direset",
        description: "Tombol buat akun owner pertama dan SuperCode baru sekarang tersedia di halaman login"
      });

      // Logout and redirect to login
      await supabase.auth.signOut();
    } catch (error: any) {
      toast({
        title: "Gagal mereset akun owner",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setResetting(false);
      setResetDialogOpen(false);
    }
  };
  if (!user) return null;
  return <SuperCodeProvider>
      <div className="space-y-6">
      <header className="mb-6">
        <div className="flex items-center gap-3">
          <Settings2 className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div>
            <h1 className="text-2xl font-semibold">Pengaturan</h1>
            
          </div>
        </div>
      </header>
      
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6 mb-8">
          <TabsTrigger value="profile" className="flex items-center gap-1.5">
            <User className="h-4 w-4" />
            <span>Profil</span>
          </TabsTrigger>
          <TabsTrigger value="system" className="flex items-center gap-1.5">
            <Settings2 className="h-4 w-4" />
            <span>Sistem</span>
          </TabsTrigger>
          <TabsTrigger value="whatsapp" className="flex items-center gap-1.5">
            <MessageCircle className="h-4 w-4" />
            <span>WhatsApp API</span>
          </TabsTrigger>
          <TabsTrigger value="incentive" className="flex items-center gap-1.5">
            <Award className="h-4 w-4" />
            <span>Insentif</span>
          </TabsTrigger>
          <TabsTrigger value="backup" className="flex items-center gap-1.5">
            <Database className="h-4 w-4" />
            <span>Backup</span>
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-1.5">
            <Activity className="h-4 w-4" />
            <span>Logs</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Tabs defaultValue="banner" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="banner" className="flex items-center justify-center gap-1.5">
                <Image className="h-4 w-4" />
                <span>Pengaturan Banner</span>
              </TabsTrigger>
              <TabsTrigger value="business" className="flex items-center justify-center gap-1.5">
                <User className="h-4 w-4" />
                <span>Informasi Usaha</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="banner">
              <BannerSettings />
            </TabsContent>
            
            <TabsContent value="business">
              <div className="space-y-6">
                <ProfileSettings userId={user.id} />
                
                {isOwner && <Card className="w-full border-destructive">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-destructive">
                        <AlertTriangle className="h-5 w-5" />
                        Zona Berbahaya
                      </CardTitle>
                      <CardDescription>
                        Tindakan ini tidak dapat dibatalkan dan akan menghapus semua akun owner
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="destructive" onClick={openResetDialog}>
                        Reset Akun Owner
                      </Button>
                    </CardContent>
                  </Card>}
              </div>
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="system">
          <Tabs defaultValue="credit" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="credit" className="flex items-center justify-center gap-1.5">
                <CreditCard className="h-4 w-4" />
                <span>Pengaturan Pinjaman</span>
              </TabsTrigger>
              <TabsTrigger value="interest" className="flex items-center justify-center gap-1.5">
                <Wallet className="h-4 w-4" />
                <span>Pengaturan Simpanan</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="credit">
              <div className="space-y-6">
                <SystemSettings userId={user.id} />
                <BankAccountSettings />
              </div>
            </TabsContent>
            
            <TabsContent value="interest">
              <DepositAccountSettings />
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="whatsapp">
          <Tabs defaultValue="settings" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="settings" className="flex items-center justify-center gap-1.5">
                <Sliders className="h-4 w-4" />
                <span>Pengaturan</span>
              </TabsTrigger>
              <TabsTrigger value="monitor" className="flex items-center justify-center gap-1.5">
                <Eye className="h-4 w-4" />
                <span>Monitor</span>
              </TabsTrigger>
              <TabsTrigger value="templates" className="flex items-center justify-center gap-1.5">
                <FileText className="h-4 w-4" />
                <span>Template</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="settings">
              <div className="space-y-6">
                <WhatsAppSettings />
                <WhatsAppAutoReminder />
              </div>
            </TabsContent>
            
            <TabsContent value="monitor">
              <WhatsAppMonitoring />
            </TabsContent>
            
            <TabsContent value="templates">
              <WhatsAppTemplates />
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="incentive">
          <IncentiveSettings />
        </TabsContent>

        <TabsContent value="backup">
          <BackupSettings />
        </TabsContent>

        <TabsContent value="logs">
          <SystemLogs />
        </TabsContent>
      </Tabs>

      {/* SuperCode Dialog */}
      <Dialog open={superCodeDialogOpen} onOpenChange={setSuperCodeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Verifikasi SuperCode</DialogTitle>
            <DialogDescription>
              Masukkan SuperCode untuk melanjutkan reset akun owner
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Input type="text" placeholder="Masukkan SuperCode" value={superCodeInput} onChange={e => setSuperCodeInput(e.target.value)} onKeyDown={e => {
              if (e.key === "Enter") {
                handleSuperCodeSubmit();
              }
            }} />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => {
              setSuperCodeDialogOpen(false);
              setSuperCodeInput("");
            }}>
              Batal
            </Button>
            <Button onClick={handleSuperCodeSubmit}>
              Verifikasi
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Reset Confirmation Dialog */}
      <AlertDialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Konfirmasi Reset Akun Owner
            </AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan dan akan menghapus semua akun owner dari sistem serta mereset SuperCode. 
              Owner baru harus membuat SuperCode baru saat pertama kali login.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleResetOwner} disabled={resetting} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {resetting ? "Mereset..." : "Ya, Reset Akun Owner"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </SuperCodeProvider>;
};
export default Settings;