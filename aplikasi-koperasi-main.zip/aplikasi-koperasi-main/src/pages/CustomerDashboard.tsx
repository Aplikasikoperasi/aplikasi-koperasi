import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SkeletonCard } from "@/components/ui/skeleton-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { formatRupiah, formatDate, calculateAge, formatAccountNumber } from "@/lib/utils";
import { LogOut, Star, Inbox, Receipt, AlertCircle, CheckCircle2, ChevronDown, Copy, Check, User, AlertTriangle, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { AchievementBadge } from "@/components/AchievementBadge";
import { MaintenanceBanner } from "@/components/MaintenanceBanner";
import { useCustomerData } from "@/hooks/useCustomerData";
import { ImagePreviewDialog } from "@/components/ImagePreviewDialog";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { generateWhatsAppLink } from "@/lib/whatsappHelper";

interface CustomerData {
  id: string;
  full_name: string;
  id_number: string;
  credit_score: number;
  nik: string;
  phone: string;
  address: string;
  restoration_status: string;
  photo_url?: string;
  date_of_birth?: string;
}

interface CreditApplication {
  id: string;
  application_number: string;
  amount_approved: number;
  tenor_months: number;
  interest_rate: number;
  status: string;
  application_date: string;
  total_paid: number;
  total_outstanding: number;
  total_penalty: number;
}

interface Installment {
  id: string;
  installment_number: number;
  due_date: string;
  total_amount: number;
  paid_amount: number;
  status: string;
  principal_paid: boolean;
  frozen_penalty: number;
  frozen_days_overdue?: number;
  current_penalty?: number;
}

interface Message {
  id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

export default function CustomerDashboard() {
  const navigate = useNavigate();
  const { customerId, loading: customerIdLoading } = useCustomerData();
  const { businessPhone, businessName } = useBusinessInfo();
  const [customer, setCustomer] = useState<CustomerData | null>(null);
  const [applications, setApplications] = useState<CreditApplication[]>([]);
  const [installments, setInstallments] = useState<Record<string, Installment[]>>({});
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [bankAccounts, setBankAccounts] = useState<any[]>([]);
  const [copiedAccount, setCopiedAccount] = useState<string | null>(null);
  const [achievementBadge, setAchievementBadge] = useState<any>(null);
  const [restorationStatus, setRestorationStatus] = useState<any>(null);
  const [isRequestingRestoration, setIsRequestingRestoration] = useState(false);
  const [autoBlockThreshold, setAutoBlockThreshold] = useState<number>(3.7);
  const [photoPreviewOpen, setPhotoPreviewOpen] = useState(false);

  const handleChatAdmin = () => {
    if (!businessPhone) {
      toast.error("Nomor WhatsApp admin belum dikonfigurasi");
      return;
    }
    const message = `Halo ${businessName}, saya ${customer?.full_name || 'nasabah'} (ID: ${customer?.id_number || '-'}) ingin menghubungi admin.`;
    // Use 'app' mode to open native WhatsApp app directly
    const whatsappUrl = generateWhatsAppLink(businessPhone, message, 'app');
    window.location.href = whatsappUrl;
  };

  useEffect(() => {
    if (!customerIdLoading && customerId) {
      loadCustomerData();

      // Optimized realtime subscriptions - hanya update yang relevan
      const channel = supabase
        .channel('customer-dashboard-updates')
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'customers',
            filter: `id=eq.${customerId}`
          },
          (payload) => {
            // Update customer data saja
            setCustomer(payload.new as CustomerData);
          }
        )
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'customer_messages',
            filter: `customer_id=eq.${customerId}`
          },
          (payload) => {
            // Update messages saja
            if (payload.eventType === 'INSERT') {
              setMessages(prev => [payload.new as Message, ...prev]);
            } else if (payload.eventType === 'UPDATE') {
              setMessages(prev => prev.map(msg => 
                msg.id === payload.new.id ? payload.new as Message : msg
              ));
            } else if (payload.eventType === 'DELETE') {
              setMessages(prev => prev.filter(msg => msg.id !== payload.old.id));
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [customerIdLoading, customerId]);

  const loadCustomerData = async () => {
    if (!customerId) return;

    try {
      setLoading(true);

      // Parallel loading untuk semua query yang independent
      const [
        customerResult,
        bankResult,
        appsResult,
        settingsResult,
        messagesResult,
        badgeResult,
        blockResult
      ] = await Promise.all([
        supabase.from("customers").select("*").eq("id", customerId).single(),
        supabase.from("bank_accounts").select("*").eq("is_active", true).order("is_primary", { ascending: false }),
        supabase.from("credit_applications").select(`
          *,
          installments!application_id (
            paid_amount,
            frozen_penalty,
            total_amount,
            principal_paid
          )
        `).eq("customer_id", customerId).order("application_date", { ascending: false }),
        supabase.rpc('get_public_app_settings'),
        supabase.from("customer_messages").select("*").eq("customer_id", customerId).order("created_at", { ascending: false }),
        supabase.rpc('get_customer_achievement_badge', { p_customer_id: customerId }),
        supabase.from("blocked_customers").select("*").eq("customer_id", customerId).maybeSingle()
      ]);

      // Set customer data
      if (customerResult.data) {
        setCustomer(customerResult.data);
      }

      // Set bank accounts
      if (bankResult.data) {
        setBankAccounts(bankResult.data);
      }

      // Process applications
      if (appsResult.data) {
        const appsWithTotals = appsResult.data.map((app: any) => {
          const total_paid = app.installments?.reduce((sum: number, inst: any) => sum + (inst.paid_amount || 0), 0) || 0;
          const total_penalty = app.installments?.reduce((sum: number, inst: any) => sum + (inst.frozen_penalty || 0), 0) || 0;
          const total_amount = app.installments?.reduce((sum: number, inst: any) => sum + (inst.total_amount || 0), 0) || 0;
          const total_outstanding = total_amount - total_paid + total_penalty;

          return {
            ...app,
            total_paid,
            total_penalty,
            total_outstanding: Math.max(0, total_outstanding)
          };
        });
        setApplications(appsWithTotals);

        // Load installments in parallel
        const penaltyRate = (settingsResult.data as any)?.penalty_rate_per_day || 2.0;
        const threshold = (settingsResult.data as any)?.auto_block_threshold || 3.7;
        setAutoBlockThreshold(threshold);

        const installmentPromises = appsResult.data.map(app =>
          supabase.from("installments").select("*").eq("application_id", app.id).order("installment_number")
        );
        
        const installmentResults = await Promise.all(installmentPromises);
        const installmentsMap: Record<string, Installment[]> = {};
        
        installmentResults.forEach((result, index) => {
          if (result.data) {
            const appId = appsResult.data[index].id;
            const instWithPenalty = result.data.map((inst: any) => {
              let currentPenalty = 0;
              if (!inst.principal_paid && inst.status !== 'paid' && inst.due_date) {
                const dueDate = new Date(inst.due_date);
                dueDate.setHours(0, 0, 0, 0);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const daysOverdue = Math.max(0, Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
                if (daysOverdue > 0) {
                  currentPenalty = Math.ceil((daysOverdue * (inst.total_amount * (penaltyRate / 100))) / 1000) * 1000;
                }
              }

              let frozenPenalty = inst.frozen_penalty || 0;
              let frozenDays = inst.frozen_days_overdue || 0;
              if ((!frozenPenalty || frozenPenalty === 0) && inst.paid_at && inst.due_date) {
                const dueDate = new Date(inst.due_date);
                dueDate.setHours(0, 0, 0, 0);
                const paidAt = new Date(inst.paid_at);
                paidAt.setHours(0, 0, 0, 0);
                const daysLate = Math.max(0, Math.floor((paidAt.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
                if (daysLate > 0) {
                  frozenDays = daysLate;
                  frozenPenalty = Math.ceil((daysLate * (inst.total_amount * (penaltyRate / 100))) / 1000) * 1000;
                }
              }

              return { ...inst, current_penalty: currentPenalty, frozen_penalty: frozenPenalty, frozen_days_overdue: frozenDays };
            });
            installmentsMap[appId] = instWithPenalty;
          }
        });
        
        setInstallments(installmentsMap);
      }

      // Set messages
      if (messagesResult.data) {
        setMessages(messagesResult.data);
      }

      // Set achievement badge
      if (badgeResult.data && badgeResult.data.length > 0) {
        setAchievementBadge(badgeResult.data[0]);
      }

      // Set block data
      if (blockResult.data) {
        const canRequest = await supabase.rpc('can_request_restoration', {
          p_customer_id: customerId
        });

        const pendingRequest = await supabase
          .from('customer_restoration_requests')
          .select('*')
          .eq('customer_id', customerId)
          .eq('status', 'pending')
          .maybeSingle();

        const rejectedRequest = await supabase
          .from('customer_restoration_requests')
          .select('reviewed_at, rejection_reason')
          .eq('customer_id', customerId)
          .eq('status', 'rejected')
          .order('reviewed_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        setRestorationStatus({
          isBlocked: true,
          canRequest: canRequest.data || false,
          blockData: blockResult.data,
          pendingRequest: pendingRequest.data,
          lastRejection: rejectedRequest.data
        });
      } else {
        setRestorationStatus({ isBlocked: false });
      }
    } catch (error) {
      console.error("Error loading customer data:", error);
      toast.error(error instanceof Error ? error.message : "Terjadi kesalahan saat memuat data");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      // Clear customer cache
      const { clearCustomerCache } = await import('@/hooks/useCustomerData');
      clearCustomerCache();
      
      // Clear all session data
      await supabase.auth.signOut();
      
      // CRITICAL: Clear ALL localStorage to prevent role confusion and cache issues
      localStorage.clear();
      
      // CRITICAL: Clear ALL sessionStorage
      sessionStorage.clear();
      
      // CRITICAL: Hard redirect to auth page to ensure all cache is cleared
      // This prevents any cached data or role information from persisting
      window.location.href = '/auth';
    } catch (error) {
      console.error('Logout error:', error);
      toast.error("Gagal logout");
    }
  };

  const copyToClipboard = async (text: string, accountId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedAccount(accountId);
      toast.success("Nomor rekening berhasil disalin!");
      
      // Reset copied state after 2 seconds
      setTimeout(() => {
        setCopiedAccount(null);
      }, 2000);
    } catch (error) {
      toast.error("Gagal menyalin nomor rekening");
    }
  };

  const handleRequestRestoration = async () => {
    if (!customer?.id || !restorationStatus?.canRequest) return;

    setIsRequestingRestoration(true);
    try {
      const { error } = await supabase
        .from("customer_restoration_requests")
        .insert({
          customer_id: customer.id,
        });

      if (error) throw error;

      toast.success("Permohonan pemulihan akun Anda telah dikirim dan sedang diproses");
      loadCustomerData(); // Reload to update restoration status
    } catch (error: any) {
      console.error("Error requesting restoration:", error);
      toast.error(error.message || "Gagal mengirim permohonan pemulihan");
    } finally {
      setIsRequestingRestoration(false);
    }
  };

  const unreadCount = messages.filter(m => !m.is_read).length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <SkeletonCard rows={3} />
          <SkeletonCard rows={5} />
          <SkeletonCard rows={5} />
        </div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-destructive">Data tidak ditemukan</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <Button onClick={handleLogout}>Kembali ke Login</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 p-4 md:p-8 animate-fade-in">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-6 animate-slide-in-right">
        <div className="flex items-center justify-end mb-4">
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleChatAdmin}
              title="Chat Admin via WhatsApp"
              className="bg-gradient-to-r from-green-500 via-emerald-400 to-green-600 text-white border-green-300 shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 animate-shimmer-reverse bg-[length:200%_100%] gap-1.5"
            >
              <MessageCircle className="h-4 w-4" />
              <span>Chat Admin</span>
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate("/customer-inbox")}
              className="relative"
            >
              <Inbox className="h-5 w-5" />
              {unreadCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  {unreadCount}
                </Badge>
              )}
            </Button>
            <Button variant="outline" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-3 mb-4">
          <User className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div>
            <h1 className="text-2xl font-semibold">Dashboard Nasabah</h1>
            <p className="text-muted-foreground">Selamat datang, {customer.full_name}</p>
          </div>
        </div>

        {/* Blocked Account Banner */}
        {restorationStatus?.isBlocked && (
          <Card className="mb-6 border-red-600 bg-red-50 dark:bg-red-950/30">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <AlertTriangle className="h-8 w-8 text-red-600 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-bold text-red-700 dark:text-red-400 text-lg mb-2">
                    AKUN ANDA TELAH DIBLOKIR
                  </h3>
                  <p className="text-sm text-red-600 dark:text-red-300 mb-3">
                    Anda tidak dapat mengajukan pinjaman baru sampai akun dipulihkan.
                  </p>
                  <div className="bg-white dark:bg-red-900/20 p-4 rounded-md mb-4">
                    <p className="text-sm font-medium text-red-800 dark:text-red-200 mb-2">
                      Alasan Pemblokiran:
                    </p>
                    {restorationStatus.blockData.is_auto_block ? (
                      <div>
                        <p className="text-sm text-red-700 dark:text-red-300 mb-2">
                          Skor kredit rendah (≤{autoBlockThreshold}): {customer?.credit_score?.toFixed(2)}
                        </p>
                        <p className="text-xs text-red-600 dark:text-red-400">
                          Akun Anda diblokir secara otomatis karena skor kredit di bawah ambang batas minimum {autoBlockThreshold}. 
                          Tingkatkan skor kredit Anda dengan membayar cicilan tepat waktu.
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-red-700 dark:text-red-300 whitespace-pre-line">
                        {restorationStatus.blockData.blocked_reason}
                      </p>
                    )}
                  </div>

                  {restorationStatus.pendingRequest ? (
                    <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-md border border-yellow-200 dark:border-yellow-800">
                      <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                        ⏳ Permohonan pemulihan akun Anda sedang diproses
                      </p>
                      <p className="text-xs text-yellow-700 dark:text-yellow-300 mt-1">
                        Diajukan pada: {new Date(restorationStatus.pendingRequest.requested_at).toLocaleDateString("id-ID")}
                      </p>
                    </div>
                  ) : restorationStatus.lastRejection ? (
                    <div className="space-y-3">
                      <div className="bg-red-100 dark:bg-red-900/30 p-4 rounded-md border border-red-300 dark:border-red-700">
                        <p className="text-sm font-medium text-red-800 dark:text-red-200 mb-2">
                          ❌ Permohonan Terakhir Ditolak
                        </p>
                        <p className="text-sm text-red-700 dark:text-red-300 mb-2">
                          Alasan: {restorationStatus.lastRejection.rejection_reason}
                        </p>
                        {!restorationStatus.canRequest && (
                          <p className="text-xs text-red-600 dark:text-red-400">
                            Anda dapat mengajukan permohonan kembali pada:{" "}
                            {new Date(
                              new Date(restorationStatus.lastRejection.reviewed_at).getTime() + 30 * 24 * 60 * 60 * 1000
                            ).toLocaleDateString("id-ID", {
                              day: "2-digit",
                              month: "long",
                              year: "numeric",
                            })}
                          </p>
                        )}
                      </div>
                      {restorationStatus.canRequest && (
                        <Button
                          onClick={handleRequestRestoration}
                          disabled={isRequestingRestoration}
                          className="w-full"
                        >
                          {isRequestingRestoration ? "Mengirim..." : "Ajukan Permohonan Pemulihan Akun"}
                        </Button>
                      )}
                    </div>
                  ) : restorationStatus.canRequest ? (
                    <Button
                      onClick={handleRequestRestoration}
                      disabled={isRequestingRestoration}
                      className="w-full"
                    >
                      {isRequestingRestoration ? "Mengirim..." : "Ajukan Permohonan Pemulihan Akun"}
                    </Button>
                  ) : null}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Maintenance Banner - Visible to ALL users */}
        <MaintenanceBanner />

        {/* Low Credit Score Warning */}
        {!restorationStatus?.isBlocked && customer.credit_score < 4.0 && (
          <Card className="mb-6 border-red-500 bg-red-50 dark:bg-red-950/20 animate-pulse-subtle">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-8 w-8 text-red-600 dark:text-red-400" />
                </div>
                <div className="flex-1 space-y-2">
                  <h3 className="font-bold text-lg text-red-700 dark:text-red-300">
                    ⚠️ Skor Kredit Anda Rendah
                  </h3>
                  <p className="text-sm text-red-700/90 dark:text-red-300/90">
                    Skor kredit Anda saat ini adalah <span className="font-bold">{customer.credit_score.toFixed(1)}</span> dari 5.0. 
                    Skor kredit yang rendah dapat mempengaruhi persetujuan kredit Anda di masa depan.
                  </p>
                  <div className="bg-white/50 dark:bg-black/20 rounded p-3 mt-3">
                    <p className="text-xs font-semibold mb-2 text-red-800 dark:text-red-200">Cara Meningkatkan Skor:</p>
                    <ul className="text-xs space-y-1 text-red-700/90 dark:text-red-300/90 list-disc list-inside">
                      <li>Bayar semua angsuran tepat waktu untuk menghindari denda</li>
                      <li>Selesaikan pembayaran partial yang masih tertunda</li>
                      <li>Hindari keterlambatan pembayaran di masa depan</li>
                    </ul>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate("/customer-inbox")}
                    className="mt-3 border-red-600 text-red-700 hover:bg-red-100 dark:border-red-400 dark:text-red-300 dark:hover:bg-red-900/20"
                  >
                    Lihat Detail Pesan
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Customer Info */}
        <Card className="mb-6 animate-fade-in hover-scale transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex gap-6">
              {/* Customer Photo */}
              <div className="flex-shrink-0">
                <div 
                  className={`w-24 h-24 rounded-lg overflow-hidden border-2 border-border ${customer.photo_url ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''}`}
                  onClick={() => customer.photo_url && setPhotoPreviewOpen(true)}
                >
                  {customer.photo_url ? (
                    <img 
                      src={customer.photo_url} 
                      alt={customer.full_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-muted flex items-center justify-center">
                      <span className="text-2xl font-bold text-muted-foreground">
                        {customer.full_name.charAt(0)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Customer Info Grid */}
              <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Nomor ID</p>
                  <p className="font-semibold">{customer.id_number}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">NIK</p>
                  <p className="font-semibold">{customer.nik || "-"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tanggal Lahir</p>
                  <p className="font-semibold">
                    {customer.date_of_birth 
                      ? `${formatDate(customer.date_of_birth)} (${calculateAge(customer.date_of_birth)} tahun)` 
                      : "-"}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Skor Kredit</p>
                  <div className="flex items-center gap-2">
                    {/* CRITICAL: Gunakan credit_score langsung dari database tanpa fallback */}
                    <CreditScoreStars 
                      creditScore={customer.credit_score ?? 0} 
                      restorationStatus={customer.restoration_status as "never_restored" | "restored_once" | "permanently_blocked" || "never_restored"} 
                    />
                  </div>
                </div>
              </div>
              
              {/* Achievement Badge */}
              {achievementBadge && achievementBadge.badge_level !== 'none' && (
                <div className="mt-2">
                  <AchievementBadge
                    badgeLevel={achievementBadge.badge_level}
                    badgeName={achievementBadge.badge_name}
                    badgeDescription={achievementBadge.badge_description}
                    consecutivePayments={achievementBadge.consecutive_on_time_payments}
                    onTimePercentage={achievementBadge.on_time_percentage}
                    size="md"
                    showDetails={true}
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Bank Account Information */}
        {bankAccounts.length > 0 && (
          <Card className="mb-6 animate-fade-in border-primary/20">
            <CardHeader className="bg-primary/5">
              <CardTitle className="flex items-center gap-2 text-lg">
                🏦 Informasi Pembayaran
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground mb-4">
                  Lakukan pembayaran angsuran ke salah satu rekening berikut:
                </p>
                {bankAccounts.map((account) => (
                  <div 
                    key={account.id}
                    className="bg-muted/50 p-4 rounded-lg space-y-3 border border-border/50"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold">{account.bank_name}</span>
                        {account.is_primary && (
                          <Badge variant="default" className="text-xs">
                            Utama
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Nomor Rekening</p>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-lg font-mono flex-1">{formatAccountNumber(account.account_number)}</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(account.account_number, account.id)}
                          className="shrink-0"
                        >
                          {copiedAccount === account.id ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <p className="text-sm text-muted-foreground">Atas Nama</p>
                      <p className="font-semibold text-lg">{account.account_holder}</p>
                    </div>
                  </div>
                ))}
                <p className="text-xs text-muted-foreground text-center mt-4">
                  Pastikan untuk menyimpan bukti transfer sebagai konfirmasi pembayaran
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Credit Applications */}
        <div className="space-y-6">
          <h2 className="text-xl font-semibold mb-4">Riwayat Kredit</h2>
          
          {applications.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                Belum ada pengajuan kredit
              </CardContent>
            </Card>
          ) : (
            applications.map((app) => {
              const progress = app.amount_approved > 0 
                ? Math.min(((app.total_paid / app.amount_approved) * 100), 100)
                : 0;
              const appInstallments = installments[app.id] || [];
              
              // Determine if loan is fully paid
              const isFullyPaid = app.total_outstanding === 0 || 
                (appInstallments.length > 0 && appInstallments.every(inst => inst.status === 'paid'));
              
              // Default open state: open if NOT fully paid (active loan), closed if fully paid
              const defaultOpen = !isFullyPaid;

              return (
                <Card key={app.id} className="animate-fade-in hover-scale transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{app.application_number}</CardTitle>
                      <Badge variant={
                        app.status === 'approved' ? 'default' :
                        app.status === 'disbursed' ? 'default' :
                        app.status === 'rejected' ? 'destructive' : 'secondary'
                      }>
                        {app.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Summary */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Jumlah Pinjaman</p>
                        <p className="font-semibold">{formatRupiah(app.amount_approved)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Tenor</p>
                        <p className="font-semibold">{app.tenor_months} Bulan</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Total Dibayar</p>
                        <p className="font-semibold text-green-600">{formatRupiah(app.total_paid)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Sisa Utang</p>
                        <p className="font-semibold text-orange-600">{formatRupiah(app.total_outstanding)}</p>
                      </div>
                    </div>

                    {/* Progress */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-sm font-medium">Progres Pembayaran</p>
                        <p className="text-sm font-semibold">{progress.toFixed(1)}%</p>
                      </div>
                      <Progress value={progress} className="h-2 w-full" />
                    </div>

                    {app.total_penalty > 0 && (
                      <div className="flex items-center gap-2 text-sm text-orange-600">
                        <AlertCircle className="h-4 w-4" />
                        <span>Total Denda: {formatRupiah(app.total_penalty)}</span>
                      </div>
                    )}

                    <Separator />

                    {/* Installments Table - Collapsible */}
                    <Collapsible defaultOpen={defaultOpen}>
                      <div className="flex items-center justify-between">
                        <p className="font-semibold">Tabel Angsuran</p>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="gap-2">
                            <span className="text-sm text-muted-foreground">
                              {isFullyPaid ? 'Lihat Detail' : 'Sembunyikan'}
                            </span>
                            <ChevronDown className="h-4 w-4 transition-transform duration-200 data-[state=open]:rotate-180" />
                          </Button>
                        </CollapsibleTrigger>
                      </div>
                      
                      <CollapsibleContent className="mt-3">
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left p-2">Ke-</th>
                                <th className="text-left p-2">Jatuh Tempo</th>
                                <th className="text-right p-2">Jumlah</th>
                                <th className="text-right p-2">Denda</th>
                                <th className="text-center p-2">Status</th>
                              </tr>
                            </thead>
                            <tbody>
                              {appInstallments.map((inst) => (
                                <tr key={inst.id} className="border-b hover:bg-muted/50">
                                  <td className="p-2">{inst.installment_number}</td>
                                  <td className="p-2">{formatDate(inst.due_date)}</td>
                                  <td className="text-right p-2">{formatRupiah(inst.total_amount)}</td>
                                  <td className="text-right p-2">
                                    {(inst.frozen_penalty && inst.frozen_penalty > 0) ? (
                                      <div className="flex flex-col items-end">
                                        <span className="text-orange-600 font-medium">{formatRupiah(inst.frozen_penalty)}</span>
                                        {inst.frozen_days_overdue > 0 && (
                                          <span className="text-xs text-muted-foreground">({inst.frozen_days_overdue} hari)</span>
                                        )}
                                      </div>
                                    ) : inst.current_penalty && inst.current_penalty > 0 ? (
                                      <span className="text-red-600 font-semibold">{formatRupiah(inst.current_penalty)}</span>
                                    ) : (
                                      <span className="text-muted-foreground">-</span>
                                    )}
                                  </td>
                                  <td className="text-center p-2">
                                    <Badge variant={
                                      inst.status === 'paid' ? 'default' :
                                      inst.status === 'overdue' ? 'destructive' :
                                      inst.status === 'partial' ? 'secondary' : 'outline'
                                    } className="text-xs">
                                      {inst.status === 'paid' ? 'Lunas' :
                                       inst.status === 'overdue' ? 'Menunggak' :
                                       inst.status === 'partial' ? 'Sebagian' : 'Belum Bayar'}
                                    </Badge>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>

      {/* Photo Preview Dialog */}
      <ImagePreviewDialog
        open={photoPreviewOpen}
        onOpenChange={setPhotoPreviewOpen}
        imageUrl={customer?.photo_url || null}
        alt={customer?.full_name}
      />
    </div>
  );
}
