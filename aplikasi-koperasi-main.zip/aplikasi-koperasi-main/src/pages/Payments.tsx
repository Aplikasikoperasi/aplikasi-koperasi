import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { useToast } from "@/hooks/use-toast";
import { formatRupiah, formatDate, cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Search, CheckCircle, AlertCircle, DollarSign } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyPaymentDetailDialog as PaymentDetailDialog } from "@/components/LazyDialogs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePaymentsQuery, useInvalidatePayments } from "@/hooks/usePaymentsQuery";
import { useDebounce } from "@/hooks/use-debounce";
import { SkeletonTable } from "@/components/ui/skeleton-table";
import { SkeletonCard } from "@/components/ui/skeleton-card";
import { Badge } from "@/components/ui/badge";
import { PositionBadge } from "@/components/PositionBadge";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
export default function Payments() {
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<string>("all");
  const [selectedYear, setSelectedYear] = useState<string>("all");
  const {
    toast
  } = useToast();
  const isMobile = useIsMobile();
  const ITEMS_PER_PAGE = 20;
  const invalidatePayments = useInvalidatePayments();
  const {
    viewMode,
    toggleView
  } = useViewPreference('payments');

  // Real-time subscription for payments updates
  useEffect(() => {
    console.log("[Payments] Setting up realtime subscription...");
    const channel = supabase.channel('payments-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'payments'
    }, payload => {
      console.log('[Payments] Realtime update received:', payload);
      // Invalidate queries to refetch data
      invalidatePayments();
      toast({
        title: "Data Diperbarui",
        description: "Data pembayaran telah diperbarui secara real-time"
      });
    }).subscribe(status => {
      console.log('[Payments] Subscription status:', status);
    });
    return () => {
      console.log("[Payments] Cleaning up realtime subscription");
      supabase.removeChannel(channel);
    };
  }, [invalidatePayments, toast]);

  // Use React Query hook with preserved filters
  const {
    data,
    isLoading
  } = usePaymentsQuery({
    searchQuery: debouncedSearch,
    selectedMonth,
    selectedYear,
    page: currentPage,
    itemsPerPage: ITEMS_PER_PAGE
  });
  const payments = data?.payments || [];
  const totalCount = data?.totalCount || 0;

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch, selectedMonth, selectedYear]);
  const calculateRemainingPenalty = (payment: any) => {
    const installment = payment.installments;
    if (!installment) return 0;
    const totalPaid = installment.paid_amount;
    const principalAndInterest = installment.total_amount;
    const frozenPenalty = installment.frozen_penalty || 0;
    const totalWithPenalty = principalAndInterest + frozenPenalty;
    if (totalPaid >= totalWithPenalty) return 0;
    const remainingAfterPrincipal = Math.max(0, totalPaid - principalAndInterest);
    return Math.max(0, frozenPenalty - remainingAfterPrincipal);
  };
  const getPaymentStatus = (paidAmount: number, totalAmount: number, frozenPenalty: number | null) => {
    const totalWithPenalty = totalAmount + (frozenPenalty || 0);
    if (paidAmount >= totalWithPenalty) {
      return {
        label: 'Lunas Penuh',
        variant: 'default' as const,
        color: 'text-success'
      };
    } else if (paidAmount > 0) {
      return {
        label: 'Bayar Sebagian',
        variant: 'secondary' as const,
        color: 'text-warning'
      };
    }
    return {
      label: 'Status Tidak Diketahui',
      variant: 'outline' as const,
      color: 'text-muted-foreground'
    };
  };
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Helper untuk membatasi nomor halaman yang ditampilkan
  const getPaginationRange = () => {
    const delta = isMobile ? 1 : 2; // Tampilkan lebih sedikit di mobile
    const range: (number | string)[] = [];
    const rangeWithDots: (number | string)[] = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }
    if (currentPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }
    rangeWithDots.push(...range);
    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push('...', totalPages);
    } else if (totalPages > 1) {
      rangeWithDots.push(totalPages);
    }
    return rangeWithDots;
  };
  return <div className="w-full max-w-full overflow-hidden">
      

      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader>
          <div className="flex flex-col gap-4 w-full max-w-full overflow-hidden">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="flex items-center gap-3">
                <CardTitle className="text-base sm:text-lg md:text-xl truncate max-w-full">Semua Pembayaran: {totalCount}</CardTitle>
                <ViewToggle viewMode={viewMode} onToggle={toggleView} />
              </div>
            </div>
            
            
            
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Cari ID, nama nasabah..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-9 w-full" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          {isLoading ? <div className="text-center py-8 text-muted-foreground">Memuat data...</div> : <AnimatedViewTransition viewMode={viewMode}>
            {isMobile || viewMode === 'card' ? <div className="space-y-2 w-full max-w-full">
              {payments.length === 0 ? <div className="text-center py-6 text-muted-foreground">
                  Tidak ada data pembayaran
                </div> : payments.map(payment => {
            const frozenPenalty = payment.installments?.frozen_penalty || 0;
            const hasOutstandingPenalty = frozenPenalty > 0;

            // Determine card styling based on penalty status
            const cardStyle = hasOutstandingPenalty ? "border-l-4 border-yellow-500 bg-yellow-50/50" : "border-l-4 border-green-500 bg-green-50/50";
            return <MobileDataCard key={payment.id} id={payment.installments?.credit_applications?.customers?.id_number || "-"} photoUrl={payment.installments?.credit_applications?.customers?.photo_url} name={payment.installments?.credit_applications?.customers?.full_name || "Unknown"} subtitle={`${formatRupiah(Number(payment.amount))} - ${payment.payment_method}`} onClick={() => {
              setSelectedPayment(payment);
              setShowDetail(true);
            }} applicationNumber={payment.installments?.credit_applications?.application_number} installmentNumber={payment.installments?.installment_number} paymentDate={payment.payment_date} penaltyAmount={hasOutstandingPenalty ? frozenPenalty : undefined} creatorMember={payment.creator_member ? {
              full_name: payment.creator_member.full_name,
              position: payment.creator_member.position
            } : null} className={cn("p-2 sm:p-3", cardStyle)} />;
          })}
            </div> : <div className="w-full overflow-x-auto">
              <Table className="min-w-max">
            <TableHeader>
              <TableRow>
                <TableHead>No. ID</TableHead>
                <TableHead>Foto</TableHead>
                <TableHead>Nama Nasabah</TableHead>
                <TableHead>Angsuran Ke</TableHead>
                <TableHead>Tanggal Bayar</TableHead>
                <TableHead>Jumlah Bayar</TableHead>
                <TableHead>Sisa Denda</TableHead>
                <TableHead>Metode Bayar</TableHead>
                <TableHead>Nama Petugas</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.map(payment => {
                const status = getPaymentStatus(payment.amount, payment.installments?.total_amount || 0, payment.installments?.frozen_penalty);
                const bgClass = status.variant === 'default' ? 'bg-success/5' : status.variant === 'secondary' ? 'bg-warning/5' : '';
                return <TableRow key={payment.id} className={cn(bgClass, "cursor-pointer hover:bg-muted/50 transition-colors")} onClick={() => {
                  setSelectedPayment(payment);
                  setShowDetail(true);
                }}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {status.variant === 'default' && <CheckCircle className="h-4 w-4 text-success" />}
                        {status.variant === 'secondary' && <AlertCircle className="h-4 w-4 text-warning" />}
                        {payment.installments?.credit_applications?.customers?.id_number}
                      </div>
                    </TableCell>
                    <TableCell>
                      <ClickableAvatar 
                        src={payment.installments?.credit_applications?.customers?.photo_url}
                        alt={payment.installments?.credit_applications?.customers?.full_name}
                        fallback={payment.installments?.credit_applications?.customers?.full_name?.charAt(0) || "?"}
                        className="h-10 w-10"
                      />
                    </TableCell>
                    <TableCell>{payment.installments?.credit_applications?.customers?.full_name}</TableCell>
                    <TableCell>{payment.installments?.installment_number || "-"}</TableCell>
                    <TableCell>{formatDate(payment.installments?.installment_number === 1 && payment.installments?.credit_applications?.application_date ? payment.installments.credit_applications.application_date : payment.payment_date)}</TableCell>
                    <TableCell className="font-medium">{formatRupiah(Number(payment.amount))}</TableCell>
                    <TableCell>
                      {calculateRemainingPenalty(payment) > 0 ? formatRupiah(calculateRemainingPenalty(payment)) : "Rp. 0"}
                    </TableCell>
                    <TableCell>{payment.payment_method}</TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1.5">
                        <span className="text-sm">{payment.creator_member?.full_name || "Sistem"}</span>
                        {payment.creator_member?.position && <PositionBadge position={payment.creator_member.position} size="sm" />}
                      </div>
                    </TableCell>
                  </TableRow>;
              })}
            </TableBody>
          </Table>
            </div>}
          </AnimatedViewTransition>}
        </CardContent>
      </Card>

      <PaymentDetailDialog open={showDetail} onOpenChange={setShowDetail} payment={selectedPayment} />

      {totalPages > 1 && <div className="flex justify-center sm:justify-end">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious onClick={() => handlePageChange(Math.max(1, currentPage - 1))} className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
              {getPaginationRange().map((page, idx) => <PaginationItem key={idx}>
                  {page === '...' ? <span className="px-2">...</span> : <PaginationLink onClick={() => handlePageChange(page as number)} isActive={currentPage === page} className="cursor-pointer">
                      {page}
                    </PaginationLink>}
                </PaginationItem>)}
              <PaginationItem>
                <PaginationNext onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))} className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>}
    </div>;
}