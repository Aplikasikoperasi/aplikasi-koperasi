import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useUserRole } from "@/hooks/useUserRole";
import { CheckCircle, XCircle, Clock, FileText, UserPlus, FileEdit, Edit3, Wallet, ClipboardCheck, ShieldAlert, Receipt } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyCustomerDetailDialog as CustomerDetailDialog } from "@/components/LazyDialogs";
import { LazyApplicationDetailDialog as ApplicationDetailDialog } from "@/components/LazyDialogs";
import { LazyChangeRequestDetailDialog as ChangeRequestDetailDialog } from "@/components/LazyDialogs";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WithdrawalRequestsList } from "@/components/WithdrawalRequestsList";
import { RestorationRequestDialog } from "@/components/RestorationRequestDialog";
import { useRestorationRequestsQuery, useInvalidateRestorationRequests } from "@/hooks/useRestorationRequestsQuery";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { useInvalidatePendingCustomers } from "@/hooks/usePendingCustomersQuery";
import { useInvalidateApplications } from "@/hooks/useApplicationsQuery";
import { useInvalidateChangeRequests } from "@/hooks/useChangeRequestsQuery";
import { useInvalidateWithdrawalRequests } from "@/hooks/useWithdrawalRequestsQuery";
import { formatDateWIB } from "@/lib/utils";
import { PendingExpensesList } from "@/components/PendingExpensesList";
import SaverCombinedVerificationList from "@/components/SaverCombinedVerificationList";
type VerificationType = 'customer' | 'application' | 'change_request';
export default function Verifications() {
  const [pendingCustomers, setPendingCustomers] = useState<any[]>([]);
  const [pendingApplications, setPendingApplications] = useState<any[]>([]);
  const [changeRequests, setChangeRequests] = useState<any[]>([]);
  const [pendingWithdrawals, setPendingWithdrawals] = useState(0);
  const [pendingExpensesCount, setPendingExpensesCount] = useState(0);
  const [pendingSaverTransactions, setPendingSaverTransactions] = useState(0);
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  const [actionDialog, setActionDialog] = useState<{
    open: boolean;
    item: any;
    action: 'approve' | 'reject' | null;
    type: VerificationType | null;
  }>({
    open: false,
    item: null,
    action: null,
    type: null
  });
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [selectedChangeRequest, setSelectedChangeRequest] = useState<any>(null);
  const [selectedRestorationRequest, setSelectedRestorationRequest] = useState<any>(null);
  const [showCustomerDetail, setShowCustomerDetail] = useState(false);
  const [showApplicationDetail, setShowApplicationDetail] = useState(false);
  const [showChangeRequestDetail, setShowChangeRequestDetail] = useState(false);
  const [showRestorationDialog, setShowRestorationDialog] = useState(false);
  const { isOwner, isAdmin, isSales, isKasir, loading } = useUserRole();
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const canManage = isOwner || isAdmin;
  const canViewSaversAndExpenses = isOwner || isAdmin || isKasir;
  
  const { data: restorationRequests = [], isLoading: restorationLoading } = useRestorationRequestsQuery();
  const invalidateRestoration = useInvalidateRestorationRequests();
  const invalidatePendingCustomers = useInvalidatePendingCustomers();
  const invalidateApplications = useInvalidateApplications();
  const invalidateChangeRequests = useInvalidateChangeRequests();
  const invalidateWithdrawalRequests = useInvalidateWithdrawalRequests();

  // Load current member ID for sales users
  useEffect(() => {
    const loadCurrentMember = async () => {
      if (isSales) {
        const {
          data: {
            user
          }
        } = await supabase.auth.getUser();
        if (user) {
          const {
            data
          } = await supabase.from('members').select('id').eq('user_id', user.id).single();
          if (data) {
            setCurrentMemberId(data.id);
          }
        }
      }
    };
    loadCurrentMember();
  }, [isSales]);
  useEffect(() => {
    loadPendingData();

    // Set up realtime subscriptions
    const customersChannel = supabase.channel('pending-customers-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, () => {
      console.log('🔄 Customer data changed, invalidating...');
      invalidatePendingCustomers();
      loadPendingCustomers();
    }).subscribe();
    const applicationsChannel = supabase.channel('pending-applications-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => {
      console.log('🔄 Application data changed, invalidating...');
      invalidateApplications();
      loadPendingApplications();
    }).subscribe();
    const changeRequestsChannel = supabase.channel('change-requests-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customer_change_requests'
    }, () => {
      console.log('🔄 Change request data changed, invalidating...');
      invalidateChangeRequests();
      loadChangeRequests();
    }).subscribe();
    const withdrawalsChannel = supabase.channel('withdrawals-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'member_balance_withdrawals'
    }, () => {
      console.log('🔄 Withdrawal data changed, invalidating...');
      invalidateWithdrawalRequests();
      loadPendingWithdrawals();
    }).subscribe();
    
    const saverDepositsChannel = supabase.channel('saver-deposits-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'saver_deposits'
    }, () => {
      console.log('🔄 Saver deposit data changed...');
      loadPendingSaverTransactions();
    }).subscribe();

    const saverWithdrawalsChannel = supabase.channel('saver-withdrawals-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'saver_pending_withdrawals'
    }, () => {
      console.log('🔄 Saver withdrawal data changed...');
      loadPendingSaverTransactions();
    }).subscribe();

    const expensesChannel = supabase.channel('expenses-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'expenses'
    }, () => {
      console.log('🔄 Expenses data changed...');
      loadPendingExpenses();
    }).subscribe();

    // Also subscribe to saver_withdrawals table for legacy withdrawals
    const saverWithdrawalsLegacyChannel = supabase.channel('saver-withdrawals-legacy-verification').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'saver_withdrawals'
    }, () => {
      console.log('🔄 Saver withdrawals (legacy) data changed...');
      loadPendingSaverTransactions();
    }).subscribe();

    return () => {
      supabase.removeChannel(customersChannel);
      supabase.removeChannel(applicationsChannel);
      supabase.removeChannel(changeRequestsChannel);
      supabase.removeChannel(withdrawalsChannel);
      supabase.removeChannel(saverDepositsChannel);
      supabase.removeChannel(saverWithdrawalsChannel);
      supabase.removeChannel(expensesChannel);
      supabase.removeChannel(saverWithdrawalsLegacyChannel);
    };
  }, []);
  useEffect(() => {
    const handleRefresh = () => loadPendingData();
    window.addEventListener('page-refresh', handleRefresh);
    return () => window.removeEventListener('page-refresh', handleRefresh);
  }, []);
  const loadPendingData = () => {
    loadPendingCustomers();
    loadPendingApplications();
    loadChangeRequests();
    loadPendingWithdrawals();
    loadPendingSaverTransactions();
    loadPendingExpenses();
  };

  const loadPendingSaverTransactions = async () => {
    try {
      const { count: pendingSaverDeposits } = await supabase
        .from("saver_deposits")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending");

      const { count: pendingSaverWithdrawals } = await supabase
        .from("saver_pending_withdrawals")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending");

      // Also count pending withdrawals from saver_withdrawals table
      const { count: pendingSaverWithdrawalsLegacy } = await supabase
        .from("saver_withdrawals")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending");

      setPendingSaverTransactions((pendingSaverDeposits || 0) + (pendingSaverWithdrawals || 0) + (pendingSaverWithdrawalsLegacy || 0));
    } catch (error) {
      console.error("Error loading pending saver transactions:", error);
    }
  };

  const loadPendingExpenses = async () => {
    try {
      const { count } = await supabase
        .from("expenses")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending");
      setPendingExpensesCount(count || 0);
    } catch (error) {
      console.error("Error loading pending expenses:", error);
    }
  };
  const loadPendingCustomers = async () => {
    const {
      data,
      error
    } = await supabase.from("customers").select("*").eq("status", "pending").order("created_at", {
      ascending: false
    });
    if (error) {
      console.error("Error loading pending customers:", error);
    } else {
      const customersWithCreator = await Promise.all((data || []).map(async customer => {
        if (customer.created_by) {
          const {
            data: memberData
          } = await supabase.from("members").select("full_name, position").eq("id", customer.created_by).single();
          return {
            ...customer,
            creator: memberData
          };
        }
        return customer;
      }));
      setPendingCustomers(customersWithCreator);
    }
  };
  const loadPendingApplications = async () => {
    const {
      data,
      error
    } = await supabase.from("credit_applications").select(`
        *,
        customers (
          id,
          full_name,
          id_number,
          nik,
          phone,
          photo_url,
          credit_score
        ),
        members (
          id,
          full_name,
          position
        )
      `).eq("status", "pending").order("created_at", {
      ascending: false
    });
    if (error) {
      console.error("Error loading pending applications:", error);
    } else {
      setPendingApplications(data || []);
    }
  };
  const loadChangeRequests = async () => {
    const {
      data,
      error
    } = await supabase.from("customer_change_requests").select(`
        *,
        customer:customers (
          id,
          full_name,
          id_number,
          photo_url
        )
      `).eq("status", "pending").order("created_at", {
      ascending: false
    });
    if (error) {
      console.error("Error loading change requests:", error);
      setChangeRequests([]);
      return;
    }

    // Load member data separately
    if (data && data.length > 0) {
      const requesterIds = [...new Set(data.map(r => r.requested_by).filter(Boolean))];
      const reviewerIds = [...new Set(data.map(r => r.reviewed_by).filter(Boolean))];
      const allMemberIds = [...new Set([...requesterIds, ...reviewerIds])];
      if (allMemberIds.length > 0) {
        const {
          data: membersData
        } = await supabase.from("members").select("id, user_id, full_name, position").in("user_id", allMemberIds);
        const membersMap = new Map(membersData?.map(m => [m.user_id, m]) || []);
        const requestsWithMembers = data.map(request => ({
          ...request,
          requester: request.requested_by ? membersMap.get(request.requested_by) : null,
          reviewer: request.reviewed_by ? membersMap.get(request.reviewed_by) : null
        }));
        setChangeRequests(requestsWithMembers);
      } else {
        setChangeRequests(data);
      }
    } else {
      setChangeRequests([]);
    }
  };
  const loadPendingWithdrawals = async () => {
    const {
      count,
      error
    } = await supabase.from("member_balance_withdrawals").select("id", {
      count: "exact",
      head: true
    }).eq("status", "pending");
    if (error) {
      console.error("Error loading pending withdrawals:", error);
      setPendingWithdrawals(0);
    } else {
      setPendingWithdrawals(count || 0);
    }
  };
  const handleCustomerAction = async () => {
    if (!actionDialog.item || !actionDialog.action || actionDialog.type !== 'customer') return;
    try {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user?.id) {
        toast.error("Error: User tidak terautentikasi");
        return;
      }
      if (actionDialog.action === 'approve') {
        const {
          error
        } = await supabase.from("customers").update({
          status: 'approved',
          approved_by: user.id,
          approved_at: new Date().toISOString()
        }).eq("id", actionDialog.item.id);
        if (error) throw error;
        await logSystemEvent({
          category: "customer_management",
          action: "Setujui Nasabah",
          description: `Menyetujui nasabah: ${actionDialog.item.full_name}`,
          metadata: {
            customer_id: actionDialog.item.id,
            customer_name: actionDialog.item.full_name,
            id_number: actionDialog.item.id_number
          }
        });
        toast.success("Nasabah berhasil disetujui");
        // Invalidate queries for immediate update
        invalidatePendingCustomers();
      } else {
        const {
          error
        } = await supabase.from("customers").update({
          status: 'rejected'
        }).eq("id", actionDialog.item.id);
        if (error) throw error;
        await logSystemEvent({
          category: "customer_management",
          action: "Tolak Nasabah",
          description: `Menolak nasabah: ${actionDialog.item.full_name}`,
          metadata: {
            customer_id: actionDialog.item.id,
            customer_name: actionDialog.item.full_name,
            id_number: actionDialog.item.id_number
          }
        });
        toast.success("Nasabah ditolak");
        // Invalidate queries for immediate update
        invalidatePendingCustomers();
      }
      setActionDialog({
        open: false,
        item: null,
        action: null,
        type: null
      });
    } catch (error: any) {
      toast.error(`Gagal memproses nasabah: ${error.message}`);
    }
  };
  const handleApplicationAction = async () => {
    if (!actionDialog.item || !actionDialog.action || actionDialog.type !== 'application') return;
    try {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user?.id) {
        toast.error("Error: User tidak terautentikasi");
        return;
      }
      if (actionDialog.action === 'approve') {
        // Use WIB timestamp for consistent timezone handling
        const { getCurrentTimestampForDB } = await import('@/lib/utils');
        const wibTimestamp = getCurrentTimestampForDB();
        
        const {
          error
        } = await supabase.from("credit_applications").update({
          status: 'approved',
          approved_by: user.id,
          approved_at: wibTimestamp,
          disbursed_at: wibTimestamp, // Explicitly set disbursed_at with WIB
          amount_approved: actionDialog.item.amount_requested
        }).eq("id", actionDialog.item.id);
        if (error) throw error;

        // Process incentive for credit application approval (only if enabled)
        if (actionDialog.item.member_id) {
          try {
            const {
              data: incentiveSettings
            } = await (supabase as any).from('incentive_settings').select('is_enabled, credit_application_enabled').maybeSingle();
            if (incentiveSettings?.is_enabled && incentiveSettings?.credit_application_enabled) {
              await supabase.functions.invoke('process-incentive', {
                body: {
                  type: 'credit_application',
                  application_id: actionDialog.item.id
                }
              });
            }
          } catch (incentiveError) {
            console.error('Failed to process incentive:', incentiveError);
            // Don't block the approval if incentive fails
          }
        }
        await logSystemEvent({
          category: "credit_application",
          action: "Setujui Aplikasi",
          description: `Menyetujui aplikasi kredit: ${actionDialog.item.application_number}`,
          metadata: {
            application_id: actionDialog.item.id,
            application_number: actionDialog.item.application_number,
            customer_name: actionDialog.item.customers?.full_name
          }
        });
        toast.success("Aplikasi kredit berhasil disetujui");

        // Invalidate queries for immediate update
        invalidateApplications();
        window.dispatchEvent(new Event('application-approved'));
        await loadPendingApplications();
      } else {
        const {
          error
        } = await supabase.from("credit_applications").update({
          status: 'rejected'
        }).eq("id", actionDialog.item.id);
        if (error) throw error;
        await logSystemEvent({
          category: "credit_application",
          action: "Tolak Aplikasi",
          description: `Menolak aplikasi kredit: ${actionDialog.item.application_number}`,
          metadata: {
            application_id: actionDialog.item.id,
            application_number: actionDialog.item.application_number,
            customer_name: actionDialog.item.customers?.full_name
          }
        });
        toast.success("Aplikasi kredit ditolak");
        // Invalidate queries for immediate update
        invalidateApplications();
        window.dispatchEvent(new Event('application-rejected'));
        await loadPendingApplications();
      }
      setActionDialog({
        open: false,
        item: null,
        action: null,
        type: null
      });
    } catch (error: any) {
      toast.error(`Gagal memproses aplikasi: ${error.message}`);
    }
  };
  const handleChangeRequestAction = async () => {
    if (!actionDialog.item || !actionDialog.action || actionDialog.type !== 'change_request') return;
    try {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user?.id) {
        toast.error("Error: User tidak terautentikasi");
        return;
      }
      if (actionDialog.action === 'approve') {
        // Apply changes to customer
        const rawNewData = actionDialog.item.new_data || {};
        // Hapus field yang tidak relevan dan normalisasi tanggal lahir
        const allowedKeys = ['full_name', 'nik', 'date_of_birth', 'phone', 'address', 'occupation', 'photo_url'] as const;
        const sanitizedUpdate: Record<string, any> = {};
        allowedKeys.forEach(k => {
          if ((rawNewData as any)[k] !== undefined) sanitizedUpdate[k] = (rawNewData as any)[k];
        });
        // Normalisasi format tanggal lahir ke YYYY-MM-DD atau null
        if ('date_of_birth' in sanitizedUpdate) {
          const dob = sanitizedUpdate.date_of_birth;
          if (!dob || dob === '') {
            sanitizedUpdate.date_of_birth = null;
          } else if (typeof dob === 'string') {
            const iso = /^\d{4}-\d{2}-\d{2}$/.test(dob) ? dob : new Date(dob).toISOString().slice(0, 10);
            sanitizedUpdate.date_of_birth = /^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso : null;
          } else {
            sanitizedUpdate.date_of_birth = null;
          }
        }
        const {
          error: updateError
        } = await supabase.from("customers").update(sanitizedUpdate).eq("id", actionDialog.item.customer_id);
        if (updateError) throw updateError;

        // Update request status
        const {
          error
        } = await supabase.from("customer_change_requests").update({
          status: 'approved',
          reviewed_by: user.id,
          reviewed_at: new Date().toISOString()
        }).eq("id", actionDialog.item.id);
        if (error) throw error;
        await logSystemEvent({
          category: "customer_management",
          action: "Setujui Perubahan Data",
          description: `Menyetujui perubahan data untuk nasabah: ${actionDialog.item.customer?.full_name}`,
          metadata: {
            request_id: actionDialog.item.id,
            customer_id: actionDialog.item.customer_id
          }
        });
        toast.success("Perubahan data berhasil disetujui");
        // Invalidate queries for immediate update
        invalidateChangeRequests();
      } else {
        const {
          error
        } = await supabase.from("customer_change_requests").update({
          status: 'rejected',
          reviewed_by: user.id,
          reviewed_at: new Date().toISOString()
        }).eq("id", actionDialog.item.id);
        if (error) throw error;
        await logSystemEvent({
          category: "customer_management",
          action: "Tolak Perubahan Data",
          description: `Menolak perubahan data untuk nasabah: ${actionDialog.item.customer?.full_name}`,
          metadata: {
            request_id: actionDialog.item.id,
            customer_id: actionDialog.item.customer_id
          }
        });
        toast.success("Perubahan data ditolak");
        // Invalidate queries for immediate update
        invalidateChangeRequests();
      }

      // Reload data immediately after action
      await loadChangeRequests();
      setActionDialog({
        open: false,
        item: null,
        action: null,
        type: null
      });
    } catch (error: any) {
      toast.error(`Gagal memproses permintaan: ${error.message}`);
    }
  };
  const handleEditCustomer = (customer: any) => {
    navigate('/members-customers', {
      state: {
        openTab: 'customers',
        editCustomer: customer
      }
    });
  };
  const handleEditApplication = (application: any) => {
    navigate('/installments-payments', {
      state: {
        openTab: 'applications',
        editApplication: application
      }
    });
  };

  // Check if item is editable by current user
  const isEditableByCurrentUser = (item: any, type: 'customer' | 'application') => {
    if (!isSales || !currentMemberId) return false;
    if (type === 'customer') {
      return item.created_by === currentMemberId;
    } else {
      return item.member_id === currentMemberId;
    }
  };
  const handleAction = () => {
    if (actionDialog.type === 'customer') {
      handleCustomerAction();
    } else if (actionDialog.type === 'application') {
      handleApplicationAction();
    } else if (actionDialog.type === 'change_request') {
      handleChangeRequestAction();
    }
  };
  if (loading) {
    return <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Memuat...</h2>
          <p className="text-muted-foreground">Mohon tunggu</p>
        </div>
      </div>;
  }
  const pendingRestorations = restorationRequests?.filter(r => r.status === 'pending').length || 0;
  const totalPending = pendingCustomers.length + pendingApplications.length + changeRequests.length + pendingWithdrawals + pendingRestorations;
  return <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full max-w-full overflow-hidden mb-3">
        <div className="w-full max-w-full overflow-hidden">
          <div className="flex items-center gap-3">
            <ClipboardCheck className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
            <div>
              <h1 className="text-2xl font-semibold truncate max-w-full">Portal Verifikasi</h1>
              
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="customers" className="w-full">
        <TabsList className={`grid w-full ${canViewSaversAndExpenses ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2'}`}>
          <TabsTrigger value="customers" className="gap-2">
            <UserPlus className="h-4 w-4" />
            <span>Nasabah</span> ({pendingCustomers.length + pendingApplications.length + changeRequests.length + pendingRestorations})
          </TabsTrigger>
          <TabsTrigger value="withdrawals" className="gap-2">
            <Wallet className="h-4 w-4" />
            <span>Insentif</span> ({pendingWithdrawals})
          </TabsTrigger>
          {canViewSaversAndExpenses && (
            <TabsTrigger value="savers" className="gap-2">
              <Wallet className="h-4 w-4" />
              <span>Debitur</span> ({pendingSaverTransactions})
            </TabsTrigger>
          )}
          {canViewSaversAndExpenses && (
            <TabsTrigger value="expenses" className="gap-2">
              <Receipt className="h-4 w-4" />
              <span>Operasional</span> ({pendingExpensesCount})
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="customers" className="mt-3">
          <Card className="w-full max-w-full overflow-hidden">
            <CardHeader className="pb-3">
              <CardTitle className="text-base sm:text-lg md:text-xl flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-primary" />
                Verifikasi Nasabah
                <Badge variant="secondary" className="ml-auto">
                  {pendingCustomers.length + pendingApplications.length + changeRequests.length + pendingRestorations}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6 pt-0">
              <div className="space-y-3 w-full max-w-full">
                {(pendingCustomers.length + pendingApplications.length + changeRequests.length + pendingRestorations) === 0 ? (
                  <div className="flex flex-col items-center gap-2 text-muted-foreground py-6">
                    <CheckCircle className="h-6 w-6" />
                    <p className="text-sm">Tidak ada data yang perlu diverifikasi</p>
                  </div>
                ) : (
                  <>
                    {/* Pendaftaran Nasabah Baru */}
                    {pendingCustomers.map(customer => (
                      <MobileDataCard 
                        key={`customer-${customer.id}`} 
                        id={customer.id_number} 
                        photoUrl={customer.photo_url} 
                        name={customer.full_name} 
                        subtitle={customer.phone}
                        badge={<Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs"><UserPlus className="h-3 w-3 mr-1" />Pendaftaran</Badge>}
                        statusIndicator={isEditableByCurrentUser(customer, 'customer') ? (
                          <div className="absolute -top-1 -right-1">
                            <Badge variant="default" className="h-5 w-5 p-0 flex items-center justify-center rounded-full bg-green-500 hover:bg-green-600">
                              <Edit3 className="h-3 w-3 text-white" />
                            </Badge>
                          </div>
                        ) : undefined} 
                        onClick={() => {
                          setSelectedCustomer(customer);
                          setShowCustomerDetail(true);
                        }} 
                      />
                    ))}

                    {/* Pengajuan Kredit Baru */}
                    {pendingApplications.map(application => (
                      <MobileDataCard 
                        key={`application-${application.id}`} 
                        id={application.application_number} 
                        photoUrl={application.customers?.photo_url} 
                        name={application.customers?.full_name || "Unknown"} 
                        subtitle={`Rp ${application.amount_requested?.toLocaleString('id-ID')} - ${application.tenor_months} bulan`}
                        badge={<Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-xs"><FileText className="h-3 w-3 mr-1" />Kredit</Badge>}
                        statusIndicator={isEditableByCurrentUser(application, 'application') ? (
                          <div className="absolute -top-1 -right-1">
                            <Badge variant="default" className="h-5 w-5 p-0 flex items-center justify-center rounded-full bg-green-500 hover:bg-green-600">
                              <Edit3 className="h-3 w-3 text-white" />
                            </Badge>
                          </div>
                        ) : undefined} 
                        onClick={() => {
                          setSelectedApplication(application);
                          setShowApplicationDetail(true);
                        }} 
                      />
                    ))}

                    {/* Perubahan Data Nasabah */}
                    {changeRequests.map(request => (
                      <MobileDataCard 
                        key={`change-${request.id}`} 
                        id={request.customer?.id_number || ""} 
                        photoUrl={request.customer?.photo_url} 
                        name={request.customer?.full_name || "Unknown"} 
                        subtitle={`Oleh: ${request.requester?.full_name || "Unknown"}`}
                        badge={<Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200 text-xs"><FileEdit className="h-3 w-3 mr-1" />Perubahan</Badge>}
                        onClick={() => {
                          setSelectedChangeRequest(request);
                          setShowChangeRequestDetail(true);
                        }} 
                      />
                    ))}

                    {/* Permintaan Restorasi */}
                    {restorationRequests?.filter(r => r.status === 'pending').map((request) => (
                      <MobileDataCard
                        key={`restoration-${request.id}`}
                        id={request.customers?.phone || ''}
                        photoUrl={request.customers?.photo_url}
                        name={request.customers?.full_name || 'Unknown'}
                        subtitle={`Diajukan: ${formatDateWIB(request.requested_at)}`}
                        badge={<Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 text-xs"><ShieldAlert className="h-3 w-3 mr-1" />Pemulihan</Badge>}
                        onClick={() => {
                          setSelectedRestorationRequest(request);
                          setShowRestorationDialog(true);
                        }}
                      />
                    ))}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdrawals" className="mt-3">
          <Card className="w-full max-w-full overflow-hidden">
            <CardHeader>
              <CardTitle className="text-base sm:text-lg md:text-xl flex items-center gap-2">
                <Wallet className="h-5 w-5" />
                Pengajuan Penarikan Saldo Anggota
              </CardTitle>
            </CardHeader>
            <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
              <WithdrawalRequestsList />
            </CardContent>
          </Card>
        </TabsContent>

        {canManage && (
          <TabsContent value="expenses" className="mt-3">
            <Card className="w-full max-w-full overflow-hidden">
              <CardHeader>
                <CardTitle className="text-base sm:text-lg md:text-xl flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Verifikasi Pengeluaran
                </CardTitle>
              </CardHeader>
              <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
                <PendingExpensesList onCountChange={setPendingExpensesCount} />
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="savers" className="mt-3">
          <SaverCombinedVerificationList onCountChange={setPendingSaverTransactions} />
        </TabsContent>
      </Tabs>

      <CustomerDetailDialog open={showCustomerDetail} onOpenChange={setShowCustomerDetail} customer={selectedCustomer} onEdit={handleEditCustomer} onApprove={canManage ? customer => setActionDialog({
      open: true,
      item: customer,
      action: 'approve',
      type: 'customer'
    }) : undefined} onReject={canManage ? customer => setActionDialog({
      open: true,
      item: customer,
      action: 'reject',
      type: 'customer'
    }) : undefined} />

      <ApplicationDetailDialog open={showApplicationDetail} onOpenChange={setShowApplicationDetail} application={selectedApplication} canApprove={canManage} onEdit={handleEditApplication} onApprove={canManage ? applicationId => {
      const appObj = pendingApplications.find(a => a.id === applicationId) || selectedApplication || {
        id: applicationId
      };
      setActionDialog({
        open: true,
        item: appObj,
        action: 'approve',
        type: 'application'
      });
    } : undefined} onReject={canManage ? applicationId => {
      const appObj = pendingApplications.find(a => a.id === applicationId) || selectedApplication || {
        id: applicationId
      };
      setActionDialog({
        open: true,
        item: appObj,
        action: 'reject',
        type: 'application'
      });
    } : undefined} />

      <ChangeRequestDetailDialog open={showChangeRequestDetail} onOpenChange={setShowChangeRequestDetail} request={selectedChangeRequest} onApprove={canManage ? request => setActionDialog({
      open: true,
      item: request,
      action: 'approve',
      type: 'change_request'
    }) : undefined} onReject={canManage ? request => setActionDialog({
      open: true,
      item: request,
      action: 'reject',
      type: 'change_request'
    }) : undefined} />

      <RestorationRequestDialog 
        open={showRestorationDialog} 
        onOpenChange={setShowRestorationDialog} 
        request={selectedRestorationRequest}
        onUpdate={() => {
          invalidateRestoration();
          setShowRestorationDialog(false);
        }}
      />

      <AlertDialog open={actionDialog.open} onOpenChange={open => !open && setActionDialog({
      open: false,
      item: null,
      action: null,
      type: null
    })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionDialog.action === 'approve' ? 'Setujui ' : 'Tolak '}
              {actionDialog.type === 'customer' ? 'Nasabah' : actionDialog.type === 'application' ? 'Aplikasi Kredit' : 'Perubahan Data'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionDialog.type === 'customer' ? actionDialog.action === 'approve' ? `Apakah Anda yakin ingin menyetujui nasabah ${actionDialog.item?.full_name}? Nasabah akan menjadi aktif dan dapat mengajukan kredit.` : `Apakah Anda yakin ingin menolak nasabah ${actionDialog.item?.full_name}?` : actionDialog.type === 'application' ? actionDialog.action === 'approve' ? `Apakah Anda yakin ingin menyetujui aplikasi kredit ${actionDialog.item?.application_number}?` : `Apakah Anda yakin ingin menolak aplikasi kredit ${actionDialog.item?.application_number}?` : actionDialog.action === 'approve' ? `Apakah Anda yakin ingin menyetujui perubahan data untuk ${actionDialog.item?.customer?.full_name}?` : `Apakah Anda yakin ingin menolak perubahan data untuk ${actionDialog.item?.customer?.full_name}?`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleAction}>
              {actionDialog.action === 'approve' ? 'Setujui' : 'Tolak'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>;
}