import { useEffect, useState } from "react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SkeletonCard } from "@/components/ui/skeleton-card";
import { formatRupiah, cn } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { useDashboardQuery } from "@/hooks/useDashboardQuery";
import SalesPerformance from "./SalesPerformance";
import { BarChart3, Crown, AlertTriangle } from "lucide-react";
import { useDataPrefetch } from "@/hooks/useDataPrefetch";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";

// Dashboard menggunakan RPC function untuk performa optimal
// Semua kalkulasi dilakukan di database server, bukan di client
export default function Dashboard() {
  const {
    isSales,
    isOwner,
    isAdmin
  } = useUserRole();
  const {
    data: dashboardData,
    isLoading: loading,
    error
  } = useDashboardQuery();
  const [royalCustomersCount, setRoyalCustomersCount] = useState<number>(0);
  const [nplCount, setNplCount] = useState<number>(0);
  const [nplTotalAmount, setNplTotalAmount] = useState<number>(0);
  const navigate = useNavigate();

  // Start background prefetch of all page data
  useDataPrefetch();

  // Fetch royal customers count (customers with more than 1 credit application)
  useEffect(() => {
    const fetchRoyalCustomers = async () => {
      const {
        data,
        error
      } = await supabase.from('credit_applications').select('customer_id').neq('status', 'pending').neq('status', 'rejected');
      if (!error && data) {
        // Count unique customers with more than 1 application
        const customerCounts = data.reduce((acc: Record<string, number>, app) => {
          acc[app.customer_id] = (acc[app.customer_id] || 0) + 1;
          return acc;
        }, {});
        const royalCount = Object.values(customerCounts).filter(count => count > 1).length;
        setRoyalCustomersCount(royalCount);
      }
    };

    // Initial fetch
    fetchRoyalCustomers();

    // Subscribe to realtime changes
    const channel = supabase.channel('dashboard-royal-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => {
      // Refetch when applications change
      fetchRoyalCustomers();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Fetch NPL count and total amount
  useEffect(() => {
    const fetchNPLData = async () => {
      const {
        data,
        error
      } = await supabase.from('credit_applications').select(`
          id,
          amount_approved,
          installments!application_id (
            id,
            status,
            due_date,
            total_amount,
            paid_amount
          )
        `).in('status', ['approved', 'disbursed', 'overdue', 'unpaid', 'partial']);
      if (!error && data) {
        // Filter applications that have overdue installments
        const nplApplications = data.filter(app => {
          return app.installments?.some(i => i.status === 'overdue');
        });

        // Calculate total overdue amount
        const totalOverdue = nplApplications.reduce((sum, app) => {
          const overdueInstallments = app.installments?.filter(i => i.status === 'overdue') || [];
          const appOverdue = overdueInstallments.reduce((appSum, i) => appSum + (i.total_amount - (i.paid_amount || 0)), 0);
          return sum + appOverdue;
        }, 0);
        setNplCount(nplApplications.length);
        setNplTotalAmount(totalOverdue);
      }
    };

    // Initial fetch
    fetchNPLData();

    // Subscribe to realtime changes
    const channel = supabase.channel('dashboard-npl-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'installments'
    }, () => {
      fetchNPLData();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => {
      fetchNPLData();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Navigate to royal customers page
  const handleRoyalCardClick = () => {
    navigate('/royal-customers');
  };

  // Navigate to NPL page
  const handleNPLCardClick = () => {
    navigate('/npl-customers');
  };
  useEffect(() => {
    document.title = "Dashboard Keuangan | Ringkasan";
    const metaDesc = document.querySelector('meta[name="description"]');
    const content = "Dashboard keuangan: total dicairkan, total pembayaran, angsuran berjalan, dan total keseluruhan angsuran.";
    if (metaDesc) metaDesc.setAttribute("content", content);else {
      const m = document.createElement("meta");
      m.name = "description";
      m.content = content;
      document.head.appendChild(m);
    }
  }, []);

  // Extract data dari dashboardData dengan default values (cast as any untuk bypass Json type)
  const data = dashboardData as any;
  const appsDisbursedCount = data?.apps_disbursed_count || 0;
  const totalDisbursed = data?.total_disbursed || 0;
  const paymentsCount = data?.payments_count || 0;
  const paymentsTotal = data?.payments_total || 0;
  const ongoingCount = data?.ongoing_count || 0;
  const ongoingTotal = data?.ongoing_total || 0;
  const overdueCount = data?.overdue_count || 0;
  const overdueTotal = data?.overdue_total || 0;
  const monthlyOverdueCount = data?.monthly_overdue_count || 0;
  const monthlyOverdueTotal = data?.monthly_overdue_total || 0;
  const installmentsCount = data?.installments_count || 0;
  const installmentsTotal = data?.installments_total || 0;
  const principalTotal = data?.principal_total || 0;
  const interestTotal = data?.interest_total || 0;
  const penaltyPaid = data?.penalty_paid || 0;
  const penaltyUnpaid = data?.penalty_unpaid || 0;
  const totalAdminFee = data?.total_admin_fee || 0;
  const appsWithAdminFeeCount = data?.apps_with_admin_fee_count || 0;
  const monthlyDisbursed = data?.monthly_disbursed || 0;
  const monthlyUnpaidInstallments = data?.monthly_unpaid_installments || 0;
  const monthlyPaidInstallments = data?.monthly_paid_installments || 0;
  const monthlyInterest = data?.monthly_interest || 0;
  const monthlyCashFlow = data?.monthly_cash_flow || 0;
  return <div className="w-full p-4">
      {/* If user is sales (not owner/admin), show SalesPerformance instead */}
      {isSales && !isOwner && !isAdmin ? <SalesPerformance /> : <>
          <header className="mb-6">
            <div className="flex items-center gap-3">
              <BarChart3 className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
              <div>
                <h1 className="text-2xl font-semibold">Dashboard Keuangan</h1>
                
              </div>
            </div>
          </header>

          {loading ? <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-6 gap-4">
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
            </div> : error ? <Card>
              <CardContent className="p-6">
                <p className="text-destructive">Gagal memuat data dashboard</p>
              </CardContent>
            </Card> : <main>
          <section aria-labelledby="ringkasan-utama" className="mb-6">
            <h2 id="ringkasan-utama" className="text-xl font-semibold mb-4">Ringkasan Utama</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">Total Dicairkan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-blue-900">{formatRupiah(totalDisbursed)}</div>
                  <p className="text-sm text-muted-foreground">Jumlah Aplikasi: {appsDisbursedCount}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">Total Dibayarkan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-green-900">{formatRupiah(paymentsTotal)}</div>
                  <p className="text-sm text-muted-foreground">Jumlah Angsuran Terbayar: {paymentsCount}</p>
                  <p className="text-xs text-muted-foreground">Hanya pokok + bunga (tidak termasuk denda)</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">Total Berjalan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-orange-900">{formatRupiah(ongoingTotal)}</div>
                  <p className="text-sm text-muted-foreground">Jumlah Angsuran: {ongoingCount} (unpaid/overdue/partial)</p>
                  <p className="text-xs text-muted-foreground">Tidak termasuk denda</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">Total Angsuran</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-3xl font-bold">{formatRupiah(installmentsTotal)}</div>
                  <p className="text-sm text-muted-foreground">Jumlah Total Angsuran: {installmentsCount}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <span>Pokok: <strong className="text-blue-900">{formatRupiah(principalTotal)}</strong></span>
                    <span>Bunga: <strong className="text-green-900">{formatRupiah(interestTotal)}</strong></span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">Cash Flow</CardTitle>
              </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      {(() => {
                      const cashFlow = paymentsTotal - totalDisbursed;
                      const isPositive = cashFlow >= 0;
                      return <>
                            <div className={cn("text-3xl font-bold", isPositive ? "text-green-900" : "text-red-600")}>
                              {formatRupiah(Math.abs(cashFlow))}
                            </div>
                            {isPositive && <span className="px-2 py-0.5 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                                Surplus
                              </span>}
                          </>;
                    })()}
                    </div>
                    <p className="text-sm text-muted-foreground">Dibayarkan - Dicairkan</p>
                  </div>
                </CardContent>
            </Card>
            </div>
          </section>

          <section aria-labelledby="ringkasan-nasabah" className="mb-6">
            <h2 id="ringkasan-nasabah" className="text-xl font-semibold mb-4">Ringkasan Nasabah</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950 cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-[1.02]" onClick={handleRoyalCardClick}>
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-amber-700 dark:text-amber-400">
                  <Crown className="h-5 w-5" />
                  Nasabah Royal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 text-center">
                  <div className="text-3xl font-bold text-amber-900 dark:text-amber-300">{royalCustomersCount}</div>
                  <p className="text-sm text-amber-700 dark:text-amber-400">Nasabah dengan kredit lebih dari 1</p>
                  <p className="text-xs text-amber-600 dark:text-amber-500 mt-2">Klik untuk lihat detail</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950 dark:to-orange-950 cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-[1.02]" onClick={handleNPLCardClick}>
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-red-700 dark:text-red-400">
                  <AlertTriangle className="h-5 w-5" />
                  Kredit Macet (NPL)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 text-center">
                  <div className="text-3xl font-bold text-red-900 dark:text-red-300">{nplCount}</div>
                  
                  
                  <p className="text-xs text-red-600 dark:text-red-500 mt-1">Klik untuk lihat detail</p>
                </div>
              </CardContent>
            </Card>
            </div>
          </section>

          <section aria-labelledby="keuangan-bulanan" className="mt-6 mb-6">
            <h2 id="keuangan-bulanan" className="text-xl font-semibold mb-4">Keuangan Bulanan (Bulan Ini)</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-600">Total Dicairkan</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-blue-900">{formatRupiah(monthlyDisbursed)}</div>
                    <p className="text-sm text-muted-foreground">Pencairan bulan ini</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-green-600">Sudah Dibayar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-green-900">{formatRupiah(monthlyPaidInstallments)}</div>
                    <p className="text-sm text-muted-foreground">Angsuran bulan ini yang sudah dibayar</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-green-600">Belum Dibayar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-orange-900">{formatRupiah(monthlyUnpaidInstallments)}</div>
                    <p className="text-sm text-muted-foreground">Angsuran jatuh tempo bulan ini yang belum dibayar</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-green-600">Cash Flow</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className={cn("text-3xl font-bold", monthlyCashFlow >= 0 ? "text-green-900" : "text-red-600")}>
                      {formatRupiah(monthlyCashFlow)}
                    </div>
                    <p className="text-sm text-muted-foreground">Angsuran Dibayar - Dicairkan</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-green-600">Total Bunga</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold">{formatRupiah(monthlyInterest)}</div>
                    <p className="text-sm text-muted-foreground">Total bunga angsuran bulan ini</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-red-600">Menunggak</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-red-600">{formatRupiah(monthlyOverdueTotal)}</div>
                    <p className="text-sm text-muted-foreground">Angsuran overdue bulan ini: {monthlyOverdueCount}</p>
                    <p className="text-xs text-muted-foreground">Jatuh tempo di bulan berjalan</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          <section aria-labelledby="detail-tambahan" className="mt-6">
            <h2 id="detail-tambahan" className="text-xl font-semibold mb-4">Detail Denda & Biaya</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-600">Denda Sudah Dibayar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-green-900">{formatRupiah(penaltyPaid)}</div>
                    <p className="text-sm text-muted-foreground">Total denda yang sudah dibayarkan nasabah</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-red-600">Denda Belum Dibayar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-red-600">{formatRupiah(penaltyUnpaid)}</div>
                    <p className="text-sm text-muted-foreground">Total denda yang masih tertunggak</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-blue-600">Total Biaya Admin</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-blue-900">{formatRupiah(totalAdminFee)}</div>
                    <p className="text-sm text-muted-foreground">Dari {appsWithAdminFeeCount} aplikasi yang dikenakan Admin</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-red-600">Angsuran Menunggak</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="text-3xl font-bold text-red-600">{formatRupiah(overdueTotal)}</div>
                    <p className="text-sm text-muted-foreground">Angsuran yang sudah jatuh tempo belum dibayar</p>
                    <p className="text-xs text-muted-foreground">Tidak termasuk denda</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>
        </main>}
        </>}

    </div>;
}