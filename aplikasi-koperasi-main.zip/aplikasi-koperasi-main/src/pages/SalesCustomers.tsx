import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { Users, Phone, MapPin, Calendar, CreditCard, Star, Search } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { useUserRole } from "@/hooks/useUserRole";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Input } from "@/components/ui/input";
import { useDebounce } from "@/hooks/use-debounce";
import { AchievementBadge } from "@/components/AchievementBadge";

interface CustomerData {
  id: string;
  full_name: string;
  phone: string;
  address: string;
  id_number: string;
  nik: string | null;
  credit_score: number | null;
  photo_url: string | null;
  created_at: string;
  totalApplications: number;
  approvedApplications: number;
  totalDisbursed: number;
  badge_level?: string;
  badge_name?: string;
}

interface ApplicationStats {
  customer_id: string;
  total: number;
  approved: number;
  disbursed: number;
}

export default function SalesCustomers() {
  const [customersData, setCustomersData] = useState<CustomerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [totalCount, setTotalCount] = useState(0);
  const debouncedSearch = useDebounce(searchQuery, 300);
  const itemsPerPage = 15;
  const { isSales } = useUserRole();

  const fetchCustomers = useCallback(async () => {
    try {
      setLoading(true);
      
      // Get current user and member_id if sales
      const { data: { user } } = await supabase.auth.getUser();
      
      // Calculate pagination offset
      const from = (currentPage - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;

      // Build base query with search filter
      let customersQuery = supabase
        .from('customers')
        .select(`
          id,
          full_name,
          phone,
          address,
          id_number,
          nik,
          credit_score,
          photo_url,
          created_at
        `, { count: 'exact' });

      // Apply search filter if present
      if (debouncedSearch.trim()) {
        customersQuery = customersQuery.or(
          `full_name.ilike.%${debouncedSearch}%,phone.ilike.%${debouncedSearch}%,id_number.ilike.%${debouncedSearch}%,address.ilike.%${debouncedSearch}%`
        );
      }

      // Filter by created_by for sales role
      let memberData: { id: string } | null = null;
      let relatedCustomerIds: string[] = [];
      
      if (isSales && user) {
        const { data } = await supabase
          .from('members')
          .select('id')
          .eq('user_id', user.id)
          .single();
        memberData = data;
        
        if (memberData) {
          // Get applications by this member to include those customers too
          const { data: applicationsData } = await supabase
            .from('credit_applications')
            .select('customer_id')
            .eq('member_id', memberData.id);
          
          relatedCustomerIds = applicationsData?.map(a => a.customer_id) || [];
          
          if (relatedCustomerIds.length > 0) {
            customersQuery = customersQuery.or(
              `created_by.eq.${memberData.id},id.in.(${relatedCustomerIds.join(',')})`
            );
          } else {
            customersQuery = customersQuery.eq('created_by', memberData.id);
          }
        }
      }

      // Apply pagination and ordering
      const { data: customers, error, count } = await customersQuery
        .order('created_at', { ascending: false })
        .range(from, to);

      if (error) {
        console.error('Error fetching customers:', error);
        return;
      }

      setTotalCount(count || 0);

      if (!customers || customers.length === 0) {
        setCustomersData([]);
        return;
      }

      // Extract customer IDs for batch queries
      const customerIds = customers.map(c => c.id);

      // OPTIMIZED: Single batch query for all credit applications
      // Instead of N queries (one per customer), we do 1 query
      const { data: allApplications } = await supabase
        .from('credit_applications')
        .select('customer_id, status, amount_approved, amount_requested')
        .in('customer_id', customerIds);

      // OPTIMIZED: Single batch RPC call for all badges
      // Instead of N RPC calls (one per customer), we do 1 RPC call
      const { data: allBadges } = await supabase.rpc('get_customers_achievement_badges', {
        p_customer_ids: customerIds
      });

      // Process applications into a map for O(1) lookup
      const applicationStatsMap = new Map<string, ApplicationStats>();
      
      if (allApplications) {
        for (const app of allApplications) {
          const existing = applicationStatsMap.get(app.customer_id) || {
            customer_id: app.customer_id,
            total: 0,
            approved: 0,
            disbursed: 0
          };
          
          existing.total++;
          
          if (['approved', 'disbursed', 'completed'].includes(app.status)) {
            existing.approved++;
            existing.disbursed += app.amount_approved || app.amount_requested || 0;
          }
          
          applicationStatsMap.set(app.customer_id, existing);
        }
      }

      // Process badges into a map for O(1) lookup
      const badgesMap = new Map<string, { badge_level: string; badge_name: string }>();
      
      if (allBadges) {
        for (const badge of allBadges) {
          badgesMap.set(badge.customer_id, {
            badge_level: badge.badge_level,
            badge_name: badge.badge_name
          });
        }
      }

      // Combine all data - now just O(n) array iteration, no async calls
      const customersWithStats: CustomerData[] = customers.map(customer => {
        const stats = applicationStatsMap.get(customer.id);
        const badge = badgesMap.get(customer.id);
        
        return {
          ...customer,
          totalApplications: stats?.total || 0,
          approvedApplications: stats?.approved || 0,
          totalDisbursed: stats?.disbursed || 0,
          badge_level: badge?.badge_level,
          badge_name: badge?.badge_name
        };
      });

      setCustomersData(customersWithStats);
    } catch (error) {
      console.error('Error fetching customers:', error);
    } finally {
      setLoading(false);
    }
  }, [currentPage, debouncedSearch, isSales, itemsPerPage]);

  useEffect(() => {
    document.title = "Daftar Nasabah";
    fetchCustomers();
  }, [fetchCustomers]);

  // Realtime subscription - separate from main fetch
  useEffect(() => {
    const channel = supabase
      .channel('sales-customers-realtime')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'customers'
      }, () => {
        console.log('Customer data changed, reloading...');
        fetchCustomers();
      })
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'credit_applications'
      }, () => {
        console.log('Applications data changed, reloading...');
        fetchCustomers();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchCustomers]);

  // Reset to page 1 when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch]);

  const getCreditScoreColor = (score: number | null) => {
    if (!score) return "text-gray-500";
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  // Server-side pagination calculations
  const totalPages = Math.ceil(totalCount / itemsPerPage);

  const goToPage = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="w-full p-4 md:p-6">
        <div className="flex items-center gap-3 mb-6">
          <Users className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-blue-900">Daftar Nasabah</h1>
        </div>
        <p className="text-muted-foreground">Memuat data...</p>
      </div>
    );
  }

  return (
    <div className="w-full p-4 md:p-6">
      <header className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Users className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-blue-900">Daftar Nasabah</h1>
        </div>
        <p className="text-muted-foreground mb-4">
          {isSales ? "Nasabah Anda" : "Semua Nasabah"} • Total: {totalCount} nasabah
        </p>
        
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Cari berdasarkan nama, telepon, NIK, atau alamat..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </header>

      {customersData.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          {debouncedSearch ? "Tidak ada nasabah yang ditemukan" : "Belum ada nasabah terdaftar"}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {customersData.map(customer => (
            <Card key={customer.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start gap-3">
                  <ClickableAvatar 
                    src={customer.photo_url}
                    alt={customer.full_name}
                    fallback={customer.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                    className="h-12 w-12"
                    fallbackClassName="bg-blue-100 text-blue-900"
                  />
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg break-words">{customer.full_name}</CardTitle>
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm text-muted-foreground break-all font-bold">{customer.id_number}</p>
                      {customer.badge_level && customer.badge_name && (
                        <AchievementBadge
                          badgeLevel={customer.badge_level}
                          badgeName={customer.badge_name}
                          badgeDescription=""
                          consecutivePayments={0}
                          onTimePercentage={0}
                          size="sm"
                          showDetails={false}
                        />
                      )}
                    </div>
                  </div>
                  {customer.credit_score && (
                    <div className="flex items-center gap-1">
                      <Star className={`h-4 w-4 ${getCreditScoreColor(customer.credit_score)}`} />
                      <span className={`text-sm font-semibold ${getCreditScoreColor(customer.credit_score)}`}>
                        {customer.credit_score}
                      </span>
                    </div>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="h-4 w-4 flex-shrink-0" />
                    <span className="break-all">{customer.phone}</span>
                  </div>
                  <div className="flex items-start gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4 flex-shrink-0 mt-0.5" />
                    <span className="break-words line-clamp-2">{customer.address}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-4 w-4 flex-shrink-0" />
                    <span>{format(new Date(customer.created_at), "dd MMM yyyy", { locale: id })}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-border space-y-2">
                  <div className="text-sm text-muted-foreground">
                    Disetujui : {customer.approvedApplications} Aplikasi
                  </div>
                  {customer.totalDisbursed > 0 && (
                    <div className="flex justify-between items-start text-sm">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <CreditCard className="h-3 w-3" />
                        Total Dicairkan
                      </span>
                      <span className="font-semibold text-blue-900 dark:text-blue-300 text-right break-all">
                        Rp {(customer.totalDisbursed / 1000000).toFixed(1)}jt
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground">
            Halaman {currentPage} dari {totalPages} • Total {totalCount} nasabah
          </div>
          
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => goToPage(1)} 
              disabled={currentPage === 1}
            >
              Pertama
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => goToPage(currentPage - 1)} 
              disabled={currentPage === 1}
            >
              Sebelumnya
            </Button>
            
            {/* Page numbers */}
            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let pageNum;
                if (totalPages <= 5) {
                  pageNum = i + 1;
                } else if (currentPage <= 3) {
                  pageNum = i + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                } else {
                  pageNum = currentPage - 2 + i;
                }
                return (
                  <Button
                    key={pageNum}
                    variant={currentPage === pageNum ? "default" : "outline"}
                    size="sm"
                    onClick={() => goToPage(pageNum)}
                    className="min-w-[40px]"
                  >
                    {pageNum}
                  </Button>
                );
              })}
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => goToPage(currentPage + 1)} 
              disabled={currentPage === totalPages}
            >
              Selanjutnya
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => goToPage(totalPages)} 
              disabled={currentPage === totalPages}
            >
              Terakhir
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
