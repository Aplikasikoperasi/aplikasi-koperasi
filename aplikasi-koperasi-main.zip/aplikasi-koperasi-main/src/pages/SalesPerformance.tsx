import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Users, FileText, CheckCircle, DollarSign, Calendar, Target, Award, BarChart3, AlertTriangle, Star, Crown } from "lucide-react";
import { formatRupiah, formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Separator } from "@/components/ui/separator";
import { ClickableAvatar } from "@/components/ClickableAvatar";
interface PerformanceData {
  totalCustomers: number;
  totalApplications: number;
  approvedApplications: number;
  rejectedApplications: number;
  totalDisbursed: number;
  totalCollected: number;
  overdueInstallments: number;
  onTimePayments: number;
  averageCreditScore: number;
  totalOverdueAmount: number;
  totalUnpaidPenalties: number;
  performingApplications: number; // Aplikasi kredit yang lancar (tidak ada angsuran overdue)
  nplApplications: number; // Aplikasi kredit yang macet (ada angsuran overdue)
  monthlyData: MonthlyPerformance[];
  recentApplications: any[];
  allApplications: any[]; // Semua aplikasi untuk filtering
  // New metrics
  outstandingBalance: number; // Total sisa pokok pinjaman yang belum dibayar
  repeatCustomers: number; // Nasabah yang mengajukan kredit lebih dari 1 kali
  portfolioAtRisk30: number; // Nilai pinjaman dengan tunggakan 1-30 hari
  portfolioAtRisk60: number; // Nilai pinjaman dengan tunggakan 31-60 hari
  portfolioAtRisk90: number; // Nilai pinjaman dengan tunggakan >90 hari
  aging1to30: number; // Tunggakan 1-30 hari
  aging31to60: number; // Tunggakan 31-60 hari
  aging61to90: number; // Tunggakan 61-90 hari
  agingOver90: number; // Tunggakan >90 hari
  averageTicketSize: number; // Rata-rata nilai pengajuan yang disetujui
}
interface MonthlyPerformance {
  month: string;
  monthKey: string; // YYYY-MM format for filtering
  applications: number;
  approved: number;
  disbursed: number;
  collected: number;
}
export default function SalesPerformance() {
  const [performance, setPerformance] = useState<PerformanceData>({
    totalCustomers: 0,
    totalApplications: 0,
    approvedApplications: 0,
    rejectedApplications: 0,
    totalDisbursed: 0,
    totalCollected: 0,
    overdueInstallments: 0,
    onTimePayments: 0,
    averageCreditScore: 0,
    totalOverdueAmount: 0,
    totalUnpaidPenalties: 0,
    performingApplications: 0,
    nplApplications: 0,
    monthlyData: [],
    recentApplications: [],
    allApplications: [],
    outstandingBalance: 0,
    repeatCustomers: 0,
    portfolioAtRisk30: 0,
    portfolioAtRisk60: 0,
    portfolioAtRisk90: 0,
    aging1to30: 0,
    aging31to60: 0,
    aging61to90: 0,
    agingOver90: 0,
    averageTicketSize: 0
  });
  const [loading, setLoading] = useState(true);
  const [memberName, setMemberName] = useState("");
  const [selectedMonth, setSelectedMonth] = useState<MonthlyPerformance | null>(null);
  const [selectedMonthApplications, setSelectedMonthApplications] = useState<any[]>([]);
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [showMonthDetail, setShowMonthDetail] = useState(false);
  const [showAppDetail, setShowAppDetail] = useState(false);
  const [showRepeatCustomersDetail, setShowRepeatCustomersDetail] = useState(false);
  const [showAllCustomersDetail, setShowAllCustomersDetail] = useState(false);
  const [showTotalApplicationsDetail, setShowTotalApplicationsDetail] = useState(false);
  const [showNPLDetail, setShowNPLDetail] = useState(false);
  const [repeatCustomersData, setRepeatCustomersData] = useState<any[]>([]);
  const [allCustomersData, setAllCustomersData] = useState<any[]>([]);
  const [totalApplicationsData, setTotalApplicationsData] = useState<any[]>([]);
  const [nplApplicationsData, setNPLApplicationsData] = useState<any[]>([]);
  const {
    toast
  } = useToast();
  const isMobile = useIsMobile();
  useEffect(() => {
    loadPerformanceData();

    // Set up realtime subscriptions for auto-sync
    const channel = supabase.channel('sales-performance-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => {
      console.log('🔄 Applications data changed, reloading performance...');
      loadPerformanceData();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'installments'
    }, () => {
      console.log('🔄 Installments data changed, reloading performance...');
      loadPerformanceData();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'payments'
    }, () => {
      console.log('🔄 Payments data changed, reloading performance...');
      loadPerformanceData();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, () => {
      console.log('🔄 Customers data changed, reloading performance...');
      loadPerformanceData();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const loadPerformanceData = async () => {
    try {
      setLoading(true);

      // Get current user's member_id
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "Silakan login terlebih dahulu",
          variant: "destructive"
        });
        return;
      }
      const {
        data: memberData
      } = await supabase.from("members").select("id, full_name").eq("user_id", user.id).maybeSingle();
      if (!memberData) {
        toast({
          title: "Error",
          description: "Data anggota tidak ditemukan",
          variant: "destructive"
        });
        return;
      }
      setMemberName(memberData.full_name);
      const memberId = memberData.id;

      // Load customers created by this sales OR customers they applied credit for
      const {
        data: applicationsData
      } = await supabase.from("credit_applications").select("customer_id").eq("member_id", memberId);
      const relatedCustomerIds = applicationsData?.map(a => a.customer_id) || [];

      // Load total customers with their details
      let customersQuery = supabase.from("customers").select(`
          id, 
          full_name, 
          id_number, 
          credit_score, 
          nik, 
          phone, 
          address, 
          photo_url,
          created_at
        `);
      if (relatedCustomerIds.length > 0) {
        customersQuery = customersQuery.or(`created_by.eq.${memberId},id.in.(${relatedCustomerIds.join(',')})`);
      } else {
        customersQuery = customersQuery.eq("created_by", memberId);
      }
      const {
        data: customers
      } = await customersQuery.order("created_at", {
        ascending: false
      });
      const totalCustomers = customers?.length || 0;
      // CRITICAL: Gunakan credit_score langsung dari database tanpa fallback
      const avgCreditScore = customers?.length ? customers.reduce((sum, c) => sum + (c.credit_score ?? 0), 0) / customers.length : 0;

      // Load applications by this sales
      const {
        data: applications
      } = await supabase.from("credit_applications").select(`
          *,
          customers (full_name, id_number),
          installments!application_id (*)
        `).eq("member_id", memberId).order("created_at", {
        ascending: false
      });
      const totalApplications = applications?.length || 0;
      const approvedApplications = applications?.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed").length || 0;
      const rejectedApplications = applications?.filter(a => a.status === "rejected").length || 0;
      const totalDisbursed = applications?.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed").reduce((sum, a) => sum + Number(a.amount_approved || 0), 0) || 0;

      // Calculate collected payments
      const {
        data: payments
      } = await supabase.from("payments").select("amount, application_id").in("application_id", applications?.map(a => a.id) || []);
      const totalCollected = payments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;

      // Calculate installment performance (must be defined before use)
      const allInstallments = applications?.flatMap(a => a.installments || []) || [];

      // Calculate performing vs NPL applications
      const disbursedApplications = applications?.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed") || [];
      const performingApplications = disbursedApplications.filter(app => {
        const appInstallments = allInstallments.filter(i => i.application_id === app.id);
        // Aplikasi performing jika tidak ada installment yang overdue
        return appInstallments.length > 0 && !appInstallments.some(i => i.status === "overdue");
      }).length;
      const nplApplications = disbursedApplications.filter(app => {
        const appInstallments = allInstallments.filter(i => i.application_id === app.id);
        // Aplikasi NPL jika ada installment yang overdue
        return appInstallments.length > 0 && appInstallments.some(i => i.status === "overdue");
      }).length;
      const overdueInstallments = allInstallments.filter(i => i.status === "overdue").length;
      const onTimePayments = allInstallments.filter(i => i.status === "paid" && i.paid_at && new Date(i.paid_at) <= new Date(i.due_date)).length;

      // Calculate total overdue amount (unpaid installments)
      const totalOverdueAmount = allInstallments.filter(i => i.status === "overdue").reduce((sum, i) => sum + (Number(i.total_amount) - Number(i.paid_amount || 0)), 0);

      // Get penalty rate from app_settings
      const {
        data: appSettings
      } = await supabase.from("app_settings").select("penalty_rate_per_day").order("updated_at", {
        ascending: false
      }).limit(1).maybeSingle();
      const penaltyRatePerDay = Number(appSettings?.penalty_rate_per_day || 2.0);
      const today = new Date();

      // Calculate total unpaid penalties - REALTIME calculation
      let totalUnpaidPenalties = 0;
      allInstallments.forEach(i => {
        if (i.principal_paid) {
          // Jika pokok sudah lunas, gunakan frozen penalty
          totalUnpaidPenalties += Number(i.frozen_penalty || 0);
        } else if (i.status === "overdue") {
          // Jika masih menunggak, hitung denda secara realtime
          const dueDate = new Date(i.due_date);
          const daysOverdue = Math.max(0, Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
          if (daysOverdue > 0) {
            const unpaidAmount = Number(i.total_amount) - Number(i.paid_amount || 0);
            const penalty = unpaidAmount * (penaltyRatePerDay / 100) * daysOverdue;
            // Round penalty to nearest 1000 (round up)
            const roundedPenalty = Math.ceil(penalty / 1000) * 1000;
            totalUnpaidPenalties += roundedPenalty;
          }
        }
      });

      // === NEW METRICS CALCULATIONS ===

      // 1. Outstanding Balance - Total sisa pokok yang belum dibayar
      const outstandingBalance = allInstallments.filter(i => !i.principal_paid).reduce((sum, i) => sum + Number(i.principal_amount || 0), 0);

      // 2. Repeat Customers - Nasabah yang mengajukan kredit lebih dari 1 kali
      const customerApplicationCount = new Map<string, {
        count: number;
        name: string;
        id_number: string;
        customerId: string;
        applications: any[];
      }>();
      applications?.forEach(app => {
        const existing = customerApplicationCount.get(app.customer_id);
        if (existing) {
          existing.count++;
          existing.applications.push(app);
        } else {
          customerApplicationCount.set(app.customer_id, {
            count: 1,
            name: app.customers?.full_name || '-',
            id_number: app.customers?.id_number || '-',
            customerId: app.customer_id,
            applications: [app]
          });
        }
      });
      const repeatCustomersArray = Array.from(customerApplicationCount.values()).filter(item => item.count > 1).sort((a, b) => b.count - a.count);
      const repeatCustomers = repeatCustomersArray.length;

      // 4. Portfolio at Risk (PAR) - Berdasarkan umur tunggakan
      const par30Apps = new Set<string>();
      const par60Apps = new Set<string>();
      const par90Apps = new Set<string>();
      allInstallments.filter(i => i.status === "overdue").forEach(i => {
        const daysOverdue = Math.floor((today.getTime() - new Date(i.due_date).getTime()) / (1000 * 60 * 60 * 24));
        if (daysOverdue >= 1 && daysOverdue <= 30) {
          par30Apps.add(i.application_id);
        } else if (daysOverdue >= 31 && daysOverdue <= 60) {
          par60Apps.add(i.application_id);
        } else if (daysOverdue > 60) {
          par90Apps.add(i.application_id);
        }
      });
      const portfolioAtRisk30 = applications?.filter(app => par30Apps.has(app.id)).reduce((sum, app) => sum + Number(app.amount_approved || 0), 0) || 0;
      const portfolioAtRisk60 = applications?.filter(app => par60Apps.has(app.id)).reduce((sum, app) => sum + Number(app.amount_approved || 0), 0) || 0;
      const portfolioAtRisk90 = applications?.filter(app => par90Apps.has(app.id)).reduce((sum, app) => sum + Number(app.amount_approved || 0), 0) || 0;

      // 5. Aging Analysis - Breakdown tunggakan berdasarkan umur
      let aging1to30 = 0;
      let aging31to60 = 0;
      let aging61to90 = 0;
      let agingOver90 = 0;
      allInstallments.filter(i => i.status === "overdue").forEach(i => {
        const daysOverdue = Math.floor((today.getTime() - new Date(i.due_date).getTime()) / (1000 * 60 * 60 * 24));
        const overdueAmount = Number(i.total_amount) - Number(i.paid_amount || 0);
        if (daysOverdue >= 1 && daysOverdue <= 30) {
          aging1to30 += overdueAmount;
        } else if (daysOverdue >= 31 && daysOverdue <= 60) {
          aging31to60 += overdueAmount;
        } else if (daysOverdue >= 61 && daysOverdue <= 90) {
          aging61to90 += overdueAmount;
        } else if (daysOverdue > 90) {
          agingOver90 += overdueAmount;
        }
      });

      // 6. Average Ticket Size - Rata-rata nilai pengajuan yang disetujui
      const averageTicketSize = approvedApplications > 0 ? applications?.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed").reduce((sum, a) => sum + Number(a.amount_approved || 0), 0) / approvedApplications : 0;

      // Calculate monthly performance (last 6 months)
      const monthlyData = calculateMonthlyPerformance(applications || [], payments || []);
      setPerformance({
        totalCustomers,
        totalApplications,
        approvedApplications,
        rejectedApplications,
        totalDisbursed,
        totalCollected,
        overdueInstallments,
        onTimePayments,
        averageCreditScore: Math.round(avgCreditScore * 10) / 10,
        totalOverdueAmount,
        totalUnpaidPenalties,
        performingApplications,
        nplApplications,
        monthlyData,
        recentApplications: applications?.slice(0, 10) || [],
        allApplications: applications || [],
        // Simpan semua aplikasi
        outstandingBalance,
        repeatCustomers,
        portfolioAtRisk30,
        portfolioAtRisk60,
        portfolioAtRisk90,
        aging1to30,
        aging31to60,
        aging61to90,
        agingOver90,
        averageTicketSize: Math.round(averageTicketSize)
      });

      // Store repeat customers data for dialog
      setRepeatCustomersData(repeatCustomersArray);

      // Prepare all customers data with their application counts
      const customersWithApps = customers?.map(customer => {
        const customerApps = applications?.filter(app => app.customer_id === customer.id) || [];
        const approvedApps = customerApps.filter(app => app.status === 'approved' || app.status === 'disbursed' || app.status === 'completed');
        const totalDisbursed = approvedApps.reduce((sum, app) => sum + Number(app.amount_approved || 0), 0);
        return {
          ...customer,
          applicationCount: customerApps.length,
          approvedCount: approvedApps.length,
          totalDisbursed: totalDisbursed,
          applications: customerApps
        };
      }) || [];
      setAllCustomersData(customersWithApps);

      // Store total applications data with details
      const applicationsWithDetails = applications?.map(app => {
        const appInstallments = app.installments || [];
        const totalPaid = appInstallments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0);
        const totalAmount = appInstallments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0);
        const overdueCount = appInstallments.filter((inst: any) => inst.status === 'overdue').length;
        return {
          ...app,
          totalPaid,
          totalAmount,
          overdueCount,
          progress: totalAmount > 0 ? totalPaid / totalAmount * 100 : 0
        };
      }) || [];
      setTotalApplicationsData(applicationsWithDetails);

      // Store NPL applications data
      const nplApps = applicationsWithDetails.filter(app => app.overdueCount > 0);
      setNPLApplicationsData(nplApps);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Gagal memuat data kinerja",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const calculateMonthlyPerformance = (applications: any[], payments: any[]): MonthlyPerformance[] => {
    const monthlyMap = new Map<string, MonthlyPerformance>();
    const now = new Date();

    // Initialize last 12 months (1 year)
    for (let i = 11; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = date.toISOString().slice(0, 7);
      const monthName = date.toLocaleDateString("id-ID", {
        month: "short",
        year: "numeric"
      });
      monthlyMap.set(monthKey, {
        month: monthName,
        monthKey: monthKey,
        applications: 0,
        approved: 0,
        disbursed: 0,
        collected: 0
      });
    }

    // Aggregate application data - use application_date if available, fallback to created_at
    applications.forEach(app => {
      // Use application_date first, then approved_at, then created_at
      const dateToUse = app.application_date || app.approved_at || app.created_at;
      if (!dateToUse) return;
      const monthKey = dateToUse.slice(0, 7);
      if (monthlyMap.has(monthKey)) {
        const data = monthlyMap.get(monthKey)!;
        data.applications++;
        if (app.status === "approved" || app.status === "disbursed") {
          data.approved++;
          // Count disbursed amount for both approved and disbursed status
          data.disbursed += Number(app.amount_approved || 0);
        }
      }
    });

    // Aggregate payment data - use payment_date
    payments.forEach(payment => {
      const dateToUse = payment.payment_date || payment.created_at;
      if (!dateToUse) return;
      const monthKey = dateToUse.slice(0, 7);
      if (monthlyMap.has(monthKey)) {
        const data = monthlyMap.get(monthKey)!;
        data.collected += Number(payment.amount || 0);
      }
    });
    return Array.from(monthlyMap.values());
  };
  const approvalRate = performance.totalApplications > 0 ? (performance.approvedApplications / performance.totalApplications * 100).toFixed(1) : "0";

  // Collection Rate = Perbandingan aplikasi performing vs total approved applications
  const totalDisbursedApps = (performance.performingApplications || 0) + (performance.nplApplications || 0);
  const collectionRate = totalDisbursedApps > 0 ? (performance.performingApplications / totalDisbursedApps * 100).toFixed(1) : "0";
  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Memuat data kinerja...</p>
        </div>
      </div>;
  }
  return <div className="overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <Award className="w-8 h-8 text-primary" />
            Laporan Kinerja Sales
          </h1>
          
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {/* 1. Nasabah Royal */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow border-amber-200 bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950" onClick={() => window.location.href = '/royal-customers'}>
          <CardHeader className="space-y-3">
            <div className="flex items-center justify-center gap-2">
              <Crown className="h-5 w-5 text-amber-600" />
              <CardTitle className="text-base font-semibold text-amber-900 dark:text-amber-100">
                Nasabah Royal
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-4xl font-bold text-amber-900 dark:text-amber-300 text-center">
              {performance.repeatCustomers}
            </div>
            <p className="text-xs text-center text-muted-foreground">
              Nasabah dengan kredit lebih dari 1
            </p>
            <p className="text-xs text-center text-amber-600 dark:text-amber-400 font-medium">
              Klik untuk lihat detail
            </p>
          </CardContent>
        </Card>

        {/* 2. Total Nasabah */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = '/sales-customers'}>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Total Nasabah</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-center">
            <div className="text-3xl font-bold">{performance.totalCustomers}</div>
            <p className="text-sm text-muted-foreground">Nasabah terdaftar</p>
            <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">
              Klik untuk lihat detail
            </p>
          </CardContent>
        </Card>

        {/* 3. Total Pengajuan */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = '/sales-applications'}>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Total Pengajuan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-center">
            <div className="text-3xl font-bold">{performance.totalApplications}</div>
            <p className="text-sm text-muted-foreground">{performance.approvedApplications} disetujui, {performance.rejectedApplications} ditolak</p>
            <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">
              Klik untuk lihat detail
            </p>
          </CardContent>
        </Card>

        {/* 4. Kredit Lancar */}
        

        {/* 5. Kredit Macet */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = '/sales-npl'}>
          <CardHeader>
            <CardTitle className="text-red-600 text-center">Kredit Macet (NPL)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-center">
            <div className="text-3xl font-bold text-destructive">{performance.nplApplications}</div>
            <p className="text-sm text-muted-foreground">Aplikasi dengan angsuran menunggak</p>
            <p className="text-xs text-red-600 dark:text-red-400 font-medium">
              Klik untuk lihat detail
            </p>
          </CardContent>
        </Card>

        {/* 6. Rata-rata Skor Kredit */}
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Rata-rata Skor Kredit</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-warning">{performance.averageCreditScore}</div>
              <p className="text-sm text-muted-foreground">Kualitas portofolio nasabah</p>
            </div>
          </CardContent>
        </Card>

        {/* 7. Total Pencairan */}
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Total Pencairan</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-blue-900">{formatRupiah(performance.totalDisbursed)}</div>
              <p className="text-sm text-muted-foreground">Dari {performance.approvedApplications} pengajuan</p>
            </div>
          </CardContent>
        </Card>

        {/* 8. Total Terkumpul */}
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Total Terkumpul</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-green-900">{formatRupiah(performance.totalCollected)}</div>
              <p className="text-sm text-muted-foreground">Dari pembayaran angsuran</p>
            </div>
          </CardContent>
        </Card>

        {/* 9. Rata-rata Nilai Kredit */}
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Rata-rata Nilai Kredit</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-blue-900">{formatRupiah(performance.averageTicketSize)}</div>
              <p className="text-sm text-muted-foreground">Per pengajuan yang disetujui</p>
            </div>
          </CardContent>
        </Card>

        {/* 10. Jumlah Tunggakan */}
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600 text-center">Jumlah Tunggakan</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-destructive">{formatRupiah(performance.totalOverdueAmount)}</div>
              <p className="text-sm text-muted-foreground">Dari {performance.overdueInstallments} angsuran menunggak</p>
            </div>
          </CardContent>
        </Card>

        {/* 11. Sisa Pinjaman Aktif */}
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600 text-center">Sisa Pinjaman Aktif</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-orange-900">{formatRupiah(performance.outstandingBalance)}</div>
              <p className="text-sm text-muted-foreground">Total pokok yang belum dibayar</p>
            </div>
          </CardContent>
        </Card>

        {/* 12. Denda Belum Dibayar */}
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600 text-center">Denda Belum Dibayar</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-1">
              <div className="text-3xl font-bold text-warning">{formatRupiah(performance.totalUnpaidPenalties)}</div>
              <p className="text-sm text-muted-foreground">Akumulasi denda yang belum terbayar</p>
            </div>
          </CardContent>
        </Card>

      </div>


      {/* Recent Applications */}
      <Card>
        <CardHeader className="bg-blue-50">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            10 Pengajuan Terakhir
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isMobile ? (/* Mobile Card View */
        <div className="space-y-3">
              {performance.recentApplications.map(app => <Card key={app.id} className="cursor-pointer hover:bg-accent/50 transition-colors border border-blue-300" onClick={() => {
            setSelectedApplication(app);
            setShowAppDetail(true);
          }}>
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-base truncate">{app.customers?.full_name}</h3>
                        {app.status === "pending" && <Badge variant="secondary">Pending</Badge>}
                        {app.status === "approved" && <Badge className="bg-blue-500">Disetujui</Badge>}
                        {app.status === "disbursed" && <Badge className="bg-green-500">Dicairkan</Badge>}
                        {app.status === "rejected" && <Badge variant="destructive">Ditolak</Badge>}
                      </div>
                      <div className="text-sm">
                        <p className="text-muted-foreground">ID: {app.customers?.id_number}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-muted-foreground">Tanggal</p>
                          <p className="font-medium">{formatDate(app.application_date)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-muted-foreground">Pengajuan</p>
                          <p className="font-medium">{formatRupiah(app.amount_requested)}</p>
                        </div>
                      </div>
                      {/* Progress Kredit */}
                      {(app.status === "approved" || app.status === "disbursed") && app.installments && <div className="mt-3 pt-3 border-t space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Progress Pembayaran</span>
                            <span className="font-semibold">
                              {(() => {
                        const totalInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0);
                        const paidInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0);
                        const percentage = totalInstallments > 0 ? Math.round(paidInstallments / totalInstallments * 100) : 0;
                        return `${percentage}%`;
                      })()}
                            </span>
                          </div>
                          <Progress value={(() => {
                    const totalInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0);
                    const paidInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0);
                    return totalInstallments > 0 ? paidInstallments / totalInstallments * 100 : 0;
                  })()} className="h-2" />
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Dibayar: {formatRupiah(app.installments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0))}</span>
                            <span>Total: {formatRupiah(app.installments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0))}</span>
                          </div>
                        </div>}

                    </div>
                  </CardContent>
                </Card>)}
            </div>) : (/* Desktop Table View */
        <ScrollArea className="h-[400px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Nasabah</TableHead>
                    <TableHead>ID Nasabah</TableHead>
                    <TableHead className="text-right">Jumlah Pengajuan</TableHead>
                    <TableHead className="text-right">Disetujui</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {performance.recentApplications.map(app => <TableRow key={app.id}>
                      <TableCell>{formatDate(app.application_date)}</TableCell>
                      <TableCell className="font-medium">{app.customers?.full_name}</TableCell>
                      <TableCell className="font-bold">{app.customers?.id_number}</TableCell>
                      <TableCell className="text-right">{formatRupiah(app.amount_requested)}</TableCell>
                      <TableCell className="text-right">
                        {app.amount_approved ? formatRupiah(app.amount_approved) : "-"}
                      </TableCell>
                      <TableCell>
                        {(app.status === "approved" || app.status === "disbursed") && app.installments ? <div className="min-w-[180px] space-y-1">
                            <div className="flex items-center gap-2">
                              <Progress value={(() => {
                        const totalInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0);
                        const paidInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0);
                        return totalInstallments > 0 ? paidInstallments / totalInstallments * 100 : 0;
                      })()} className="h-2 flex-1" />
                              <span className="text-xs font-semibold min-w-[40px] text-right">
                                {(() => {
                          const totalInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0);
                          const paidInstallments = app.installments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0);
                          return totalInstallments > 0 ? Math.round(paidInstallments / totalInstallments * 100) : 0;
                        })()}%
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {formatRupiah(app.installments.reduce((sum: number, inst: any) => sum + Number(inst.paid_amount || 0), 0))} / {formatRupiah(app.installments.reduce((sum: number, inst: any) => sum + Number(inst.total_amount || 0), 0))}
                            </p>
                          </div> : <span className="text-sm text-muted-foreground">-</span>}
                      </TableCell>
                      <TableCell>
                        {app.status === "pending" && <Badge variant="secondary">Pending</Badge>}
                        {app.status === "approved" && <Badge className="bg-blue-500">Disetujui</Badge>}
                        {app.status === "disbursed" && <Badge className="bg-green-500">Dicairkan</Badge>}
                        {app.status === "rejected" && <Badge variant="destructive">Ditolak</Badge>}
                      </TableCell>
                    </TableRow>)}
                </TableBody>
              </Table>
            </ScrollArea>)}
        </CardContent>
      </Card>

      {/* Monthly Performance */}
      <Card>
        <CardHeader className="bg-blue-50">
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Kinerja Bulanan (1 Tahun Terakhir)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isMobile ? (/* Mobile Card View */
        <div className="space-y-3">
              {performance.monthlyData.map((month, index) => <Card key={index} className="cursor-pointer hover:bg-accent/50 transition-colors border border-blue-300" onClick={() => {
            setSelectedMonth(month);
            // Filter dari SEMUA aplikasi, bukan hanya 10 terakhir
            const monthApps = performance.allApplications.filter(app => {
              const dateToUse = app.application_date || app.approved_at || app.created_at;
              return dateToUse && dateToUse.slice(0, 7) === month.monthKey;
            });
            console.log('🔍 Month:', month.month, 'MonthKey:', month.monthKey, 'Found apps:', monthApps.length);
            console.log('📊 Sample app installments:', monthApps[0]?.installments?.length);
            setSelectedMonthApplications(monthApps);
            setShowMonthDetail(true);
          }}>
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-base">{month.month}</h3>
                        <Badge variant="outline">{month.applications} Pengajuan</Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-muted-foreground">Disetujui</p>
                          <p className="font-medium">{month.approved}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-muted-foreground">Pencairan</p>
                          <p className="font-medium">{formatRupiah(month.disbursed)}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>)}
            </div>) : (/* Desktop Table View */
        <ScrollArea className="h-[300px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Bulan</TableHead>
                    <TableHead className="text-right">Pengajuan</TableHead>
                    <TableHead className="text-right">Disetujui</TableHead>
                    <TableHead className="text-right">Pencairan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {performance.monthlyData.map((month, index) => <TableRow key={index}>
                      <TableCell className="font-medium">{month.month}</TableCell>
                      <TableCell className="text-right">{month.applications}</TableCell>
                      <TableCell className="text-right">{month.approved}</TableCell>
                      <TableCell className="text-right">{formatRupiah(month.disbursed)}</TableCell>
                    </TableRow>)}
                </TableBody>
              </Table>
            </ScrollArea>)}
        </CardContent>
      </Card>

      {/* Month Detail Dialog - Mobile */}
      <ResponsiveDialog open={showMonthDetail} onOpenChange={setShowMonthDetail}>
        <ResponsiveDialogContent className="max-w-md">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle>Detail Kinerja Bulanan</ResponsiveDialogTitle>
          </ResponsiveDialogHeader>
          {selectedMonth && <div className="space-y-4">
              <div className="text-center py-2">
                <h3 className="text-xl font-bold">{selectedMonth.month}</h3>
              </div>
              <Separator />
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Total Pengajuan</span>
                  <span className="font-bold text-lg">{selectedMonth.applications}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Disetujui</span>
                  <span className="font-bold text-lg text-green-600">{selectedMonth.approved}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Total Pencairan</span>
                  <span className="font-bold text-lg text-primary">{formatRupiah(selectedMonth.disbursed)}</span>
                </div>
                {selectedMonth.applications > 0 && <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                    <span className="text-muted-foreground">Tingkat Persetujuan</span>
                    <span className="font-bold text-lg">
                      {(selectedMonth.approved / selectedMonth.applications * 100).toFixed(1)}%
                    </span>
                  </div>}
              </div>

              {/* Daftar Pengajuan di Bulan Ini */}
              {selectedMonthApplications.length > 0 && <>
                  <Separator />
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Daftar Pengajuan ({selectedMonthApplications.length})</h4>
                    <ScrollArea className="h-[300px]">
                      <div className="space-y-2">
                        {selectedMonthApplications.map(app => <Card key={app.id} className="cursor-pointer hover:bg-accent/50 transition-colors" onClick={() => {
                    setSelectedApplication(app);
                    setShowAppDetail(true);
                    setShowMonthDetail(false);
                  }}>
                            <CardContent className="p-3">
                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="font-semibold text-sm">{app.customers?.full_name}</span>
                                  {app.status === "pending" && <Badge variant="secondary" className="text-xs">Pending</Badge>}
                                  {app.status === "approved" && <Badge className="bg-blue-500 text-xs">Disetujui</Badge>}
                                  {app.status === "disbursed" && <Badge className="bg-green-500 text-xs">Dicairkan</Badge>}
                                  {app.status === "rejected" && <Badge variant="destructive" className="text-xs">Ditolak</Badge>}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {app.customers?.id_number} • {formatDate(app.application_date)}
                                </div>
                                <div className="flex justify-between items-center text-xs">
                                  <span className="text-muted-foreground">Tenor:</span>
                                  <span className="font-medium">{app.tenor_months} Bulan</span>
                                </div>
                                <div className="flex justify-between items-center text-xs">
                                  <span className="text-muted-foreground">Pengajuan:</span>
                                  <span className="font-medium">{formatRupiah(app.amount_requested)}</span>
                                </div>
                                {app.amount_approved && <div className="flex justify-between items-center text-xs">
                                    <span className="text-muted-foreground">Disetujui:</span>
                                    <span className="font-medium text-green-600">{formatRupiah(app.amount_approved)}</span>
                                  </div>}
                                {app.installments && app.installments.length > 0 && <>
                                    <div className="flex justify-between items-center text-xs">
                                      <span className="text-muted-foreground">Angsuran:</span>
                                      <span className="font-medium">{app.installments.length} x {formatRupiah(app.installments[0]?.total_amount || 0)}</span>
                                    </div>
                                    <div className="space-y-1">
                                      <div className="flex justify-between items-center text-xs">
                                        <span className="text-muted-foreground">Progress Kredit:</span>
                                        <span className="font-medium">
                                          {(app.installments.filter((i: any) => i.status === "paid").length / app.installments.length * 100).toFixed(0)}%
                                        </span>
                                      </div>
                                      <Progress value={app.installments.filter((i: any) => i.status === "paid").length / app.installments.length * 100} className="h-2 w-full" />
                                      <div className="text-xs text-muted-foreground text-right">
                                        {app.installments.filter((i: any) => i.status === "paid").length} / {app.installments.length} Lunas
                                      </div>
                                    </div>
                                  </>}
                              </div>
                            </CardContent>
                          </Card>)}
                      </div>
                    </ScrollArea>
                  </div>
                </>}
            </div>}
        </ResponsiveDialogContent>
      </ResponsiveDialog>

      {/* Application Detail Dialog - Mobile */}
      <ResponsiveDialog open={showAppDetail} onOpenChange={setShowAppDetail}>
        <ResponsiveDialogContent className="max-w-md">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle>Detail Pengajuan</ResponsiveDialogTitle>
          </ResponsiveDialogHeader>
          {selectedApplication && <div className="space-y-4">
              <div className="text-center py-2">
                <h3 className="text-xl font-bold">{selectedApplication.customers?.full_name}</h3>
                <p className="text-sm text-muted-foreground">ID: {selectedApplication.customers?.id_number}</p>
              </div>
              <Separator />
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Tanggal Pengajuan</span>
                  <span className="font-medium">{formatDate(selectedApplication.application_date)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Jumlah Pengajuan</span>
                  <span className="font-bold text-lg">{formatRupiah(selectedApplication.amount_requested)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Jumlah Disetujui</span>
                  <span className="font-bold text-lg text-green-600">
                    {selectedApplication.amount_approved ? formatRupiah(selectedApplication.amount_approved) : "-"}
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Tenor</span>
                  <span className="font-medium">{selectedApplication.tenor_months} Bulan</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Jumlah Angsuran</span>
                  <span className="font-medium">{selectedApplication.installments?.length || 0} Angsuran</span>
                </div>
                
                {/* Progress Kredit */}
                {selectedApplication.installments && selectedApplication.installments.length > 0 && <>
                    <div className="space-y-2 p-3 bg-muted/50 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground text-sm">Progress Kredit</span>
                        <span className="font-bold text-lg">
                          {(selectedApplication.installments.filter((i: any) => i.status === "paid").length / selectedApplication.installments.length * 100).toFixed(0)}%
                        </span>
                      </div>
                      <Progress value={selectedApplication.installments.filter((i: any) => i.status === "paid").length / selectedApplication.installments.length * 100} className="h-2 w-full" />
                      <div className="flex justify-between items-center text-xs text-muted-foreground">
                        <span>{selectedApplication.installments.filter((i: any) => i.status === "paid").length} / {selectedApplication.installments.length} Angsuran Lunas</span>
                      </div>
                    </div>
                    
                    {/* Next Due Date */}
                    {(() => {
                const nextDue = selectedApplication.installments.filter((i: any) => i.status === "unpaid" || i.status === "overdue").sort((a: any, b: any) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())[0];
                return nextDue && <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                          <span className="text-muted-foreground">Jatuh Tempo Berikutnya</span>
                          <div className="text-right">
                            <div className="font-medium">{formatDate(nextDue.due_date)}</div>
                            <div className="text-xs text-muted-foreground">{formatRupiah(nextDue.total_amount)}</div>
                          </div>
                        </div>;
              })()}
                  </>}
                
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground">Status</span>
                  <div>
                    {selectedApplication.status === "pending" && <Badge variant="secondary">Pending</Badge>}
                    {selectedApplication.status === "approved" && <Badge className="bg-blue-500">Disetujui</Badge>}
                    {selectedApplication.status === "disbursed" && <Badge className="bg-green-500">Dicairkan</Badge>}
                    {selectedApplication.status === "rejected" && <Badge variant="destructive">Ditolak</Badge>}
                  </div>
                </div>
              </div>
            </div>}
        </ResponsiveDialogContent>
      </ResponsiveDialog>

      {/* Repeat Customers Detail Dialog */}
      <ResponsiveDialog open={showRepeatCustomersDetail} onOpenChange={setShowRepeatCustomersDetail}>
        <ResponsiveDialogContent className="max-w-2xl">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle>Detail Nasabah Loyal</ResponsiveDialogTitle>
          </ResponsiveDialogHeader>
          <div className="space-y-4">
            <div className="text-center py-2">
              <h3 className="text-xl font-bold">{repeatCustomersData.length} Nasabah Loyal</h3>
              <p className="text-sm text-muted-foreground">Nasabah yang mengajukan kredit lebih dari 1 kali</p>
            </div>
            <Separator />
            
            {repeatCustomersData.length === 0 ? <p className="text-center text-muted-foreground py-8">Belum ada nasabah loyal</p> : <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {repeatCustomersData.map((customer, index) => <Card key={customer.customerId} className="hover:bg-accent/50 transition-colors">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Customer Header */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                                <span className="text-lg font-bold text-purple-600">{index + 1}</span>
                              </div>
                              <div>
                                <h4 className="font-semibold text-base">{customer.name}</h4>
                                <p className="text-sm text-muted-foreground">ID: {customer.id_number}</p>
                              </div>
                            </div>
                            <Badge variant="secondary" className="text-sm">
                              {customer.count}x Pengajuan
                            </Badge>
                          </div>

                          <Separator />

                          {/* Applications List */}
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-muted-foreground">Riwayat Pengajuan:</p>
                            {customer.applications.map((app: any, appIndex: number) => <div key={app.id} className="flex items-center justify-between p-2 bg-muted/30 rounded-lg">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium text-muted-foreground">#{appIndex + 1}</span>
                                    <span className="text-sm font-bold">{app.application_number}</span>
                                  </div>
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-xs text-muted-foreground">
                                      {formatDate(app.application_date)}
                                    </span>
                                    <span className="text-xs">•</span>
                                    <span className="text-xs font-medium">
                                      {formatRupiah(app.amount_approved || app.amount_requested)}
                                    </span>
                                  </div>
                                </div>
                                <Badge variant={app.status === 'approved' ? 'default' : app.status === 'disbursed' ? 'default' : app.status === 'completed' ? 'default' : app.status === 'rejected' ? 'destructive' : 'secondary'} className="text-xs">
                                  {app.status}
                                </Badge>
                              </div>)}
                          </div>

                          {/* Summary Stats */}
                          <div className="grid grid-cols-2 gap-2 pt-2">
                            <div className="p-2 bg-muted/30 rounded-lg">
                              <p className="text-xs text-muted-foreground">Total Pengajuan</p>
                              <p className="text-sm font-bold text-purple-600">
                                {formatRupiah(customer.applications.reduce((sum: number, app: any) => sum + Number(app.amount_approved || app.amount_requested || 0), 0))}
                              </p>
                            </div>
                            <div className="p-2 bg-muted/30 rounded-lg">
                              <p className="text-xs text-muted-foreground">Status Terbaru</p>
                              <p className="text-sm font-bold">
                                {customer.applications[customer.applications.length - 1]?.status || '-'}
                              </p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>)}
                </div>
              </ScrollArea>}
          </div>
        </ResponsiveDialogContent>
      </ResponsiveDialog>

      {/* All Customers Detail Dialog */}
      <ResponsiveDialog open={showAllCustomersDetail} onOpenChange={setShowAllCustomersDetail}>
        <ResponsiveDialogContent className="max-w-2xl">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle>Detail Semua Nasabah</ResponsiveDialogTitle>
          </ResponsiveDialogHeader>
          <div className="space-y-4">
            <div className="text-center py-2">
              <h3 className="text-xl font-bold">{allCustomersData.length} Nasabah Terdaftar</h3>
              <p className="text-sm text-muted-foreground">Daftar lengkap nasabah yang Anda daftarkan</p>
            </div>
            <Separator />
            
            {allCustomersData.length === 0 ? <p className="text-center text-muted-foreground py-8">Belum ada nasabah terdaftar</p> : <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {allCustomersData.map((customer, index) => <Card key={customer.id} className="hover:bg-accent/50 transition-colors">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Customer Header */}
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0">
                              <ClickableAvatar
                                src={customer.photo_url}
                                alt={customer.full_name}
                                fallback={customer.full_name.charAt(0)}
                                className="w-12 h-12"
                                fallbackClassName="bg-primary/10 text-primary text-lg"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <h4 className="font-semibold text-base">{customer.full_name}</h4>
                                  <p className="text-sm text-muted-foreground">ID: {customer.id_number}</p>
                                  <p className="text-xs text-muted-foreground">NIK: {customer.nik || '-'}</p>
                                </div>
                                <div className="flex flex-col items-end gap-1">
                                  <div className="flex items-center gap-1">
                                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                    {/* CRITICAL: Gunakan credit_score langsung dari database tanpa fallback */}
                                    <span className="text-sm font-semibold">{customer.credit_score?.toFixed(1) ?? '0.0'}</span>
                                  </div>
                                  <Badge variant="secondary" className="text-xs">
                                    {customer.applicationCount || 0}x Pengajuan
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>

                          <Separator />

                          {/* Customer Stats */}
                          <div className="grid grid-cols-3 gap-2">
                            <div className="p-2 bg-muted/30 rounded-lg">
                              <p className="text-xs text-muted-foreground">Total Pengajuan</p>
                              <p className="text-sm font-bold">{customer.applicationCount || 0}</p>
                            </div>
                            <div className="p-2 bg-muted/30 rounded-lg">
                              <p className="text-xs text-muted-foreground">Disetujui</p>
                              <p className="text-sm font-bold text-green-600">{customer.approvedCount || 0}</p>
                            </div>
                            <div className="p-2 bg-muted/30 rounded-lg">
                              <p className="text-xs text-muted-foreground">Total Kredit</p>
                              <p className="text-sm font-bold text-blue-600">
                                {customer.totalDisbursed > 0 ? formatRupiah(customer.totalDisbursed) : '-'}
                              </p>
                            </div>
                          </div>

                          {/* Contact Info */}
                          {(customer.phone || customer.address) && <>
                              <Separator />
                              <div className="space-y-1 text-xs">
                                {customer.phone && <p className="text-muted-foreground">
                                    📱 {customer.phone}
                                  </p>}
                                {customer.address && <p className="text-muted-foreground">
                                    📍 {customer.address}
                                  </p>}
                              </div>
                            </>}

                          {/* Recent Applications */}
                          {customer.applications && customer.applications.length > 0 && <>
                              <Separator />
                              <div className="space-y-2">
                                <p className="text-xs font-medium text-muted-foreground">
                                  Pengajuan Terbaru:
                                </p>
                                <div className="space-y-1">
                                  {customer.applications.slice(0, 2).map((app: any) => <div key={app.id} className="flex items-center justify-between text-xs p-1.5 bg-muted/20 rounded">
                                      <span className="text-muted-foreground font-bold">{app.application_number}</span>
                                      <Badge variant={app.status === 'approved' ? 'default' : app.status === 'disbursed' ? 'default' : app.status === 'completed' ? 'default' : app.status === 'rejected' ? 'destructive' : 'secondary'} className="text-xs">
                                        {app.status}
                                      </Badge>
                                    </div>)}
                                </div>
                              </div>
                            </>}
                        </div>
                      </CardContent>
                    </Card>)}
                </div>
              </ScrollArea>}
          </div>
        </ResponsiveDialogContent>
      </ResponsiveDialog>

      {/* Total Applications Detail Dialog */}
      <ResponsiveDialog open={showTotalApplicationsDetail} onOpenChange={setShowTotalApplicationsDetail}>
        <ResponsiveDialogContent className="max-w-3xl">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle>Detail Semua Pengajuan Kredit</ResponsiveDialogTitle>
          </ResponsiveDialogHeader>
          <div className="space-y-4">
            <div className="text-center py-2">
              <h3 className="text-xl font-bold">{totalApplicationsData.length} Total Pengajuan</h3>
              <p className="text-sm text-muted-foreground">
                {performance.approvedApplications} disetujui • {performance.rejectedApplications} ditolak
              </p>
            </div>
            <Separator />
            
            {totalApplicationsData.length === 0 ? <p className="text-center text-muted-foreground py-8">Belum ada pengajuan kredit</p> : <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {totalApplicationsData.map((app, index) => <Card key={app.id} className="hover:bg-accent/50 transition-colors">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Application Header */}
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold text-base">{app.application_number}</h4>
                              <p className="text-sm text-muted-foreground">
                                {app.customers?.full_name} ({app.customers?.id_number})
                              </p>
                            </div>
                            <Badge variant={app.status === 'approved' ? 'default' : app.status === 'disbursed' ? 'default' : app.status === 'completed' ? 'default' : app.status === 'rejected' ? 'destructive' : 'secondary'}>
                              {app.status}
                            </Badge>
                          </div>

                          <Separator />

                          {/* Application Details */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Tanggal Pengajuan</p>
                              <p className="text-sm font-medium">{formatDate(app.application_date)}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Jumlah Pengajuan</p>
                              <p className="text-sm font-medium">{formatRupiah(app.amount_requested)}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Disetujui</p>
                              <p className="text-sm font-medium text-green-600">
                                {app.amount_approved ? formatRupiah(app.amount_approved) : '-'}
                              </p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Tenor</p>
                              <p className="text-sm font-medium">{app.tenor_months} Bulan</p>
                            </div>
                          </div>

                          {/* Progress Bar for Approved/Disbursed */}
                          {(app.status === 'approved' || app.status === 'disbursed' || app.status === 'completed') && <>
                              <Separator />
                              <div className="space-y-2">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-muted-foreground">Progress Pembayaran</span>
                                  <span className="font-semibold">{app.progress.toFixed(1)}%</span>
                                </div>
                                <Progress value={app.progress} className="h-2 w-full" />
                                <div className="flex justify-between text-xs text-muted-foreground">
                                  <span>Dibayar: {formatRupiah(app.totalPaid)}</span>
                                  <span>Total: {formatRupiah(app.totalAmount)}</span>
                                </div>
                                {app.overdueCount > 0 && <div className="flex items-center gap-1 text-xs text-destructive">
                                    <AlertTriangle className="h-3 w-3" />
                                    <span>{app.overdueCount} angsuran menunggak</span>
                                  </div>}
                              </div>
                            </>}
                        </div>
                      </CardContent>
                    </Card>)}
                </div>
              </ScrollArea>}
          </div>
        </ResponsiveDialogContent>
      </ResponsiveDialog>

      {/* NPL Applications Detail Dialog */}
      <ResponsiveDialog open={showNPLDetail} onOpenChange={setShowNPLDetail}>
        <ResponsiveDialogContent className="max-w-3xl">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle>Detail Kredit Macet (NPL)</ResponsiveDialogTitle>
          </ResponsiveDialogHeader>
          <div className="space-y-4">
            <div className="text-center py-2">
              <h3 className="text-xl font-bold text-destructive">{nplApplicationsData.length} Aplikasi Bermasalah</h3>
              <p className="text-sm text-muted-foreground">Aplikasi dengan angsuran yang menunggak</p>
            </div>
            <Separator />
            
            {nplApplicationsData.length === 0 ? <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
                <p className="text-muted-foreground">Tidak ada kredit macet</p>
                <p className="text-sm text-muted-foreground mt-1">Semua aplikasi berjalan lancar!</p>
              </div> : <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {nplApplicationsData.map((app, index) => <Card key={app.id} className="border-destructive/50 hover:bg-destructive/5 transition-colors">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Application Header */}
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0">
                                <AlertTriangle className="h-5 w-5 text-destructive" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-base">{app.application_number}</h4>
                                <p className="text-sm text-muted-foreground">
                                  {app.customers?.full_name} ({app.customers?.id_number})
                                </p>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge variant="destructive" className="text-xs">
                                    {app.overdueCount} Angsuran Menunggak
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    {app.status}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>

                          <Separator />

                          {/* Application Details */}
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Nilai Pinjaman</p>
                              <p className="text-sm font-medium">{formatRupiah(app.amount_approved)}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Total Dibayar</p>
                              <p className="text-sm font-medium text-green-600">{formatRupiah(app.totalPaid)}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">Sisa Utang</p>
                              <p className="text-sm font-medium text-orange-600">
                                {formatRupiah(app.totalAmount - app.totalPaid)}
                              </p>
                            </div>
                          </div>

                          {/* Progress Bar */}
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">Progress Pembayaran</span>
                              <span className="font-semibold text-destructive">{app.progress.toFixed(1)}%</span>
                            </div>
                            <Progress value={app.progress} className="h-2 w-full" />
                          </div>

                          {/* Installment Summary */}
                          <div className="p-3 bg-destructive/5 rounded-lg border border-destructive/20">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Total Angsuran:</span>
                              <span className="font-medium">{app.installments?.length || 0}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm mt-1">
                              <span className="text-muted-foreground">Sudah Dibayar:</span>
                              <span className="font-medium text-green-600">
                                {app.installments?.filter((i: any) => i.status === 'paid').length || 0}
                              </span>
                            </div>
                            <div className="flex items-center justify-between text-sm mt-1">
                              <span className="text-muted-foreground">Menunggak:</span>
                              <span className="font-medium text-destructive">{app.overdueCount}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>)}
                </div>
              </ScrollArea>}
          </div>
        </ResponsiveDialogContent>
      </ResponsiveDialog>
    </div>;
}