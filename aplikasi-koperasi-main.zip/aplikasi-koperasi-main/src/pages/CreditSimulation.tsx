import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Calculator, TrendingUp, Calendar, Banknote, Percent, Info } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatRupiah } from "@/lib/utils";
import { openWhatsAppChat } from "@/lib/whatsappHelper";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
interface CreditSettings {
  interest_type: string;
  flat_interest_rate: number;
  custom_rates: any;
  max_tenor_months: number;
  admin_fee_enabled: boolean;
  admin_fee_amount: number;
  admin_fee_minimum: number;
  first_installment_type: string;
}
export default function CreditSimulation() {
  const navigate = useNavigate();
  const {
    businessName,
    logoUrl,
    businessPhone
  } = useBusinessInfo();
  const [settings, setSettings] = useState<CreditSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [loanAmount, setLoanAmount] = useState(5000000);
  const [tenorMonths, setTenorMonths] = useState(12);
  const [showResult, setShowResult] = useState(false);
  const [interestRates, setInterestRates] = useState<Map<number, number>>(new Map());
  useEffect(() => {
    loadSettings();
  }, []);
  useEffect(() => {
    if (settings) {
      loadAllInterestRates();
    }
  }, [settings]);
  const loadSettings = async () => {
    try {
      const {
        data
      } = await supabase.rpc('get_public_app_settings');
      if (data) {
        setSettings({
          interest_type: (data as any).interest_type || 'flat',
          flat_interest_rate: (data as any).flat_interest_rate || 10,
          custom_rates: (data as any).custom_rates || null,
          max_tenor_months: (data as any).max_tenor_months || 12,
          admin_fee_enabled: (data as any).admin_fee_enabled || false,
          admin_fee_amount: (data as any).admin_fee_amount || 0,
          admin_fee_minimum: (data as any).admin_fee_minimum || 0,
          first_installment_type: (data as any).first_installment_type || 'next_month'
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  // Use the same RPC function as Applications page for consistency
  const loadAllInterestRates = async () => {
    if (!settings) return;
    const rates = new Map<number, number>();
    const maxTenor = settings.max_tenor_months || 24;
    for (let tenor = 1; tenor <= maxTenor; tenor++) {
      try {
        const {
          data,
          error
        } = await supabase.rpc('get_interest_rate', {
          p_tenor_months: tenor,
          p_interest_type: settings.interest_type || null,
          p_flat_rate: settings.flat_interest_rate || null,
          p_custom_rates: settings.custom_rates || null
        });
        if (!error && data) {
          rates.set(tenor, data);
        } else {
          rates.set(tenor, settings.flat_interest_rate || 4.0);
        }
      } catch (e) {
        rates.set(tenor, settings.flat_interest_rate || 4.0);
      }
    }
    setInterestRates(rates);
  };
  const getInterestRate = (tenor: number): number => {
    return interestRates.get(tenor) || settings?.flat_interest_rate || 4.0;
  };
  const calculateSimulation = () => {
    if (!settings) return null;
    const interestRate = getInterestRate(tenorMonths);
    const totalInterest = loanAmount * (interestRate / 100) * tenorMonths;
    const totalAmount = loanAmount + totalInterest;
    const monthlyInstallment = totalAmount / tenorMonths;

    // Admin fee calculation with minimum
    let adminFee = 0;
    if (settings.admin_fee_enabled) {
      const calculatedFee = Math.round(loanAmount * (settings.admin_fee_amount / 100));
      const minimumFee = settings.admin_fee_minimum || 0;
      adminFee = Math.max(calculatedFee, minimumFee);
    }

    // Check if first installment is paid upfront (BUSINESS RULE: tenor < 4 bulan = next_month)
    const effectiveFirstInstallmentType = tenorMonths < 4 ? 'next_month' : settings.first_installment_type;
    const firstInstallmentDeducted = effectiveFirstInstallmentType === 'paid_upfront';

    // Net disbursement (amount customer actually receives after deductions)
    let disbursedAmount = loanAmount - adminFee;
    if (firstInstallmentDeducted) {
      disbursedAmount = disbursedAmount - Math.ceil(monthlyInstallment / 1000) * 1000;
    }
    return {
      loanAmount,
      interestRate,
      totalInterest,
      totalAmount,
      monthlyInstallment,
      adminFee,
      disbursedAmount,
      tenorMonths,
      firstInstallmentDeducted
    };
  };
  const result = calculateSimulation();
  const formatNumber = (value: string) => {
    const num = value.replace(/\D/g, '');
    return num ? parseInt(num) : 0;
  };
  const tenorOptions = settings ? Array.from({
    length: settings.max_tenor_months
  }, (_, i) => i + 1) : [];
  if (loading) {
    return <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Memuat...</div>
      </div>;
  }
  return <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-background opacity-50" />
      
      <div className="container mx-auto px-4 py-8 relative z-10 max-w-2xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            {logoUrl && <img src={logoUrl} alt={businessName} className="w-10 h-10 rounded-lg object-cover" />}
            <div>
              <h1 className="text-xl font-bold">{businessName}</h1>
              <p className="text-sm text-muted-foreground">Simulasi Kredit</p>
            </div>
          </div>
        </div>

        {/* Main Card */}
        <Card className="shadow-xl border-primary/20">
          <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-primary" />
              Simulasi Kredit
            </CardTitle>
            <CardDescription>
              Hitung estimasi cicilan kredit Anda sebelum mengajukan pinjaman
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6 pt-6">
            {/* Loan Amount Input */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Banknote className="h-4 w-4 text-primary" />
                Jumlah Pinjaman
              </Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                  Rp
                </span>
                <Input type="text" value={loanAmount.toLocaleString('id-ID')} onChange={e => setLoanAmount(formatNumber(e.target.value))} className="pl-10 text-lg font-semibold" placeholder="5.000.000" />
              </div>
              <Slider value={[loanAmount]} onValueChange={value => setLoanAmount(value[0])} min={1000000} max={100000000} step={500000} className="mt-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Rp 1 Juta</span>
                <span>Rp 100 Juta</span>
              </div>
            </div>

            {/* Tenor Selection - show rate like Applications page */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-primary" />
                Tenor (Jangka Waktu)
              </Label>
              <Select value={tenorMonths.toString()} onValueChange={v => setTenorMonths(parseInt(v))}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih tenor" />
                </SelectTrigger>
                <SelectContent>
                  {tenorOptions.map(month => <SelectItem key={month} value={month.toString()}>
                      {month} bulan - {getInterestRate(month)}%
                    </SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Interest Rate Info */}
            <div className="bg-muted/50 rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground flex items-center gap-2">
                  <Percent className="h-4 w-4" />
                  Bunga per Bulan
                </span>
                <Badge variant="secondary" className="text-lg font-bold">
                  {getInterestRate(tenorMonths)}%
                </Badge>
              </div>
              {settings?.interest_type === 'tiered' && <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Info className="h-3 w-3" />
                  Bunga berjenjang berdasarkan tenor yang dipilih
                </p>}
            </div>

            <Button onClick={() => setShowResult(true)} className="w-full" size="lg">
              <Calculator className="mr-2 h-4 w-4" />
              Hitung Simulasi
            </Button>

            {/* Results */}
            {showResult && result && <>
                <Separator />
                
                <div className="space-y-4 animate-fade-in">
                  <h3 className="font-semibold flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    Hasil Simulasi
                  </h3>

                  <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl p-6 space-y-4">
                    {/* Monthly Installment - Highlighted */}
                    <div className="text-center py-4 bg-background rounded-lg shadow-sm">
                      <p className="text-sm text-muted-foreground mb-1">Cicilan per Bulan</p>
                      <p className="text-3xl font-bold text-primary">
                        {formatRupiah(Math.ceil(result.monthlyInstallment / 1000) * 1000)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        selama {result.tenorMonths} bulan
                      </p>
                    </div>

                    {/* Details Grid */}
                    

                    <div className="bg-background rounded-lg p-4 space-y-2">
                      <p className="text-xs text-muted-foreground font-medium">
                        Rincian Dana Diterima
                      </p>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Pinjaman Pokok</span>
                          <span>{formatRupiah(result.loanAmount)}</span>
                        </div>
                        {result.adminFee > 0 && <div className="flex justify-between text-orange-600">
                            <span>Biaya Admin</span>
                            <span>- {formatRupiah(result.adminFee)}</span>
                          </div>}
                        {result.firstInstallmentDeducted && <>
                            <div className="flex justify-between text-blue-600">
                              <span>Bayar Angsuran Pertama</span>
                              <span>- {formatRupiah(Math.ceil(result.monthlyInstallment / 1000) * 1000)}</span>
                            </div>
                            <div className="flex justify-between text-muted-foreground text-xs italic">
                              <span>Sisa Angsuran</span>
                              <span>{result.tenorMonths - 1} bulan</span>
                            </div>
                          </>}
                        <Separator className="my-2" />
                        <div className="flex justify-between font-bold text-green-600 text-base">
                          <span>Dana Diterima</span>
                          <span>{formatRupiah(result.disbursedAmount)}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Disclaimer */}
                  <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-lg p-4">
                    <p className="text-xs text-amber-800 dark:text-amber-200">
                      <strong>Catatan:</strong> Hasil simulasi ini hanya estimasi. Jumlah sebenarnya dapat berbeda 
                      berdasarkan verifikasi dan persetujuan dari pihak {businessName}. Hubungi kami untuk informasi lebih lanjut.
                    </p>
                  </div>

                  {/* CTA */}
                  <div className="flex gap-3">
                    <Button variant="outline" onClick={() => navigate("/")} className="flex-1">
                      Kembali
                    </Button>
                    <Button onClick={() => {
                  if (!businessPhone) {
                    navigate("/auth");
                    return;
                  }
                  
                  // Build detailed breakdown message
                  let rincianPotongan = '';
                  if (result.adminFee > 0 || result.firstInstallmentDeducted) {
                    rincianPotongan = `\n📝 *Rincian Dana Diterima*\n`;
                    rincianPotongan += `• Pinjaman Pokok: ${formatRupiah(result.loanAmount)}\n`;
                    if (result.adminFee > 0) {
                      rincianPotongan += `• Biaya Admin: -${formatRupiah(result.adminFee)}\n`;
                    }
                    if (result.firstInstallmentDeducted) {
                      rincianPotongan += `• Angsuran Pertama: -${formatRupiah(Math.ceil(result.monthlyInstallment / 1000) * 1000)}\n`;
                      rincianPotongan += `• Sisa Angsuran: ${result.tenorMonths - 1} kali bayar\n`;
                    }
                    rincianPotongan += `• *Dana Diterima: ${formatRupiah(result.disbursedAmount)}*\n`;
                  }
                  
                  const message = `Halo ${businessName}, saya tertarik untuk mengajukan kredit dengan rincian simulasi berikut:\n\n` + 
                    `📋 *Simulasi Kredit*\n` + 
                    `• Pinjaman: ${formatRupiah(result.loanAmount)}\n` + 
                    `• Tenor: ${result.tenorMonths} bulan\n` + 
                    `• Bunga: ${result.interestRate}%/bulan\n` + 
                    `• Cicilan/bulan: ${formatRupiah(Math.ceil(result.monthlyInstallment / 1000) * 1000)}\n` +
                    rincianPotongan +
                    `\nMohon informasi lebih lanjut untuk proses pendaftaran. Terima kasih.`;

                  // Prefer native app deep-link (whatsapp://send) with safe fallback handled by helper
                  openWhatsAppChat(businessPhone, message);
                }} className="flex-1">
                      Daftar Sekarang
                    </Button>
                  </div>
                </div>
              </>}
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-8">
          © {new Date().getFullYear()} {businessName}. Simulasi ini hanya perkiraan.
        </p>
      </div>
    </div>;
}