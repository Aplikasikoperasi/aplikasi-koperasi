import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { useMembersQuery, useInvalidateMembers } from "@/hooks/useMembersQuery";
import { useDebounce } from "@/hooks/use-debounce";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle, ResponsiveDialogTrigger, ResponsiveDialogDescription } from "@/components/ui/responsive-dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, CalendarIcon, Upload, X, Search, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { SuccessCheckmark } from "@/components/ui/success-checkmark";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Switch } from "@/components/ui/switch";
import { compressImage } from "@/lib/imageCompression";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDate, calculateAge, getTodayInWIB } from "@/lib/utils";
import { DatePicker } from "@/components/ui/date-picker";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { id as idLocale } from "date-fns/locale";
import { sanitizeDateForDatabase } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyMemberDetailDialog as MemberDetailDialog } from "@/components/LazyDialogs";
import { MemberDeleteMigrationDialog } from "@/components/MemberDeleteMigrationDialog";
import { useNavigate } from "react-router-dom";
import { PositionBadge } from "@/components/PositionBadge";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
export default function Members() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<any>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progressMessage, setProgressMessage] = useState("");
  const [progressValue, setProgressValue] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [currentPage, setCurrentPage] = useState(1);
  const [showAccessDenied, setShowAccessDenied] = useState(false);
  const [deleteMigrationDialogOpen, setDeleteMigrationDialogOpen] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState<any>(null);
  const [activatingAccount, setActivatingAccount] = useState<string | null>(null);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [onlineUserIds, setOnlineUserIds] = useState<Set<string>>(new Set());
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  const isMobile = useIsMobile();
  const {
    toast
  } = useToast();
  const {
    role,
    isOwner,
    isAdmin,
    isSales
  } = useUserRole();
  const ITEMS_PER_PAGE = 20;
  const { viewMode, toggleView } = useViewPreference('members');

  // Use React Query hooks
  const { data, isLoading: loading } = useMembersQuery({ 
    searchQuery: debouncedSearch, 
    page: currentPage, 
    itemsPerPage: ITEMS_PER_PAGE 
  });
  const members = data?.members || [];
  const totalCount = data?.totalCount || 0;
  const invalidateMembers = useInvalidateMembers();
  const [formData, setFormData] = useState({
    full_name: "",
    position: "",
    phone: "",
    nik: "",
    occupation: "",
    address: "",
    pin: ""
  });
  const [dateOfBirth, setDateOfBirth] = useState<Date | undefined>();
  
  // Field validation errors state
  const [fieldErrors, setFieldErrors] = useState<{
    photo?: string;
    full_name?: string;
    dateOfBirth?: string;
    nik?: string;
    phone?: string;
    position?: string;
    occupation?: string;
    address?: string;
    pin?: string;
  }>({});

  // Validation functions
  const validatePhoto = (hasPhoto: boolean) => {
    if (!hasPhoto) return "Foto wajib diupload";
    return undefined;
  };

  const validateFullName = (value: string) => {
    if (!value.trim()) return "Nama lengkap wajib diisi";
    return undefined;
  };

  const validateDateOfBirth = (value: Date | undefined) => {
    if (!value) return "Tanggal lahir wajib diisi";
    return undefined;
  };

  const validateNIK = (value: string) => {
    if (!value || value.trim() === '') return "NIK wajib diisi";
    const nikPattern = /^\d{15,18}$/;
    if (!nikPattern.test(value)) return "NIK harus 15-18 digit angka";
    return undefined;
  };

  const validatePhone = (value: string) => {
    if (!value.trim()) return "Nomor telepon wajib diisi";
    const phonePattern = /^(\+62|08)\d{8,}$/;
    if (!phonePattern.test(value.replace(/\s/g, ''))) return "Harus dimulai 08 atau +62, min 10 digit";
    return undefined;
  };

  const validatePosition = (value: string) => {
    if (!value || value.trim() === '') return "Posisi wajib dipilih";
    return undefined;
  };

  const validateOccupation = (value: string) => {
    if (!value || value.trim() === '') return "Pekerjaan wajib diisi";
    return undefined;
  };

  const validateAddress = (value: string) => {
    if (!value || value.trim() === '') return "Alamat wajib diisi";
    return undefined;
  };

  const validatePin = (value: string, position: string, isEditing: boolean) => {
    if (position === 'Kasir' && !isEditing) {
      if (!value || value.trim() === '') return "PIN kasir wajib diisi";
      if (value.length !== 6 || !/^\d{6}$/.test(value)) return "PIN harus 6 digit angka";
    }
    return undefined;
  };

  // Handle field blur for validation
  const handleFieldBlur = (field: string, value: any) => {
    let error: string | undefined;
    switch (field) {
      case 'full_name':
        error = validateFullName(value);
        break;
      case 'dateOfBirth':
        error = validateDateOfBirth(value);
        break;
      case 'nik':
        error = validateNIK(value);
        break;
      case 'phone':
        error = validatePhone(value);
        break;
      case 'position':
        error = validatePosition(value);
        break;
      case 'occupation':
        error = validateOccupation(value);
        break;
      case 'address':
        error = validateAddress(value);
        break;
      case 'pin':
        error = validatePin(value, formData.position, !!editingMember);
        break;
    }
    setFieldErrors(prev => ({ ...prev, [field]: error }));
  };

  // Clear error when user starts typing
  const clearFieldError = (field: string) => {
    if (fieldErrors[field as keyof typeof fieldErrors]) {
      setFieldErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };
  useEffect(() => {
    // Set up realtime subscriptions for auto-sync
    const membersChannel = supabase.channel('members-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'members'
    }, () => {
      console.log('🔄 Members data changed, reloading...');
      setCurrentPage(1);
      invalidateMembers();
    }).subscribe();

    // Listen for online status updates from AppLayout
    const handleOnlineUsersUpdate = (event: CustomEvent) => {
      const {
        onlineUserIds
      } = event.detail;
      console.log('📡 Received online users update:', onlineUserIds);
      setOnlineUserIds(new Set(onlineUserIds));
    };
    window.addEventListener('online-users-updated', handleOnlineUsersUpdate as EventListener);
    return () => {
      supabase.removeChannel(membersChannel);
      window.removeEventListener('online-users-updated', handleOnlineUsersUpdate as EventListener);
    };
  }, [invalidateMembers]);

  // Map current auth user to member row for self-indicator fallback
  useEffect(() => {
    supabase.auth.getUser().then(({
      data: {
        user
      }
    }) => {
      setCurrentUserId(user?.id || null);
      if (user?.id) {
        supabase.from('members').select('id').eq('user_id', user.id).maybeSingle().then(({
          data
        }) => {
          setCurrentMemberId(data?.id || null);
        });
      }
    });
  }, []);

  // Listen for pull-to-refresh
  useEffect(() => {
    const handleRefresh = () => invalidateMembers();
    window.addEventListener('page-refresh', handleRefresh);
    return () => window.removeEventListener('page-refresh', handleRefresh);
  }, [invalidateMembers]);

  // Reset to page 1 when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('📝 Submitting member form', {
      editing: !!editingMember,
      formData,
      dateOfBirth
    });
    
    // Validate all fields and collect errors
    const errors: typeof fieldErrors = {};
    const invalidFields: string[] = [];
    
    const photoError = validatePhoto(!!photoFile || !!editingMember?.photo_url);
    if (photoError) {
      errors.photo = photoError;
      invalidFields.push("Foto");
    }
    
    const nameError = validateFullName(formData.full_name);
    if (nameError) {
      errors.full_name = nameError;
      invalidFields.push("Nama Lengkap");
    }
    
    const dobError = validateDateOfBirth(dateOfBirth);
    if (dobError) {
      errors.dateOfBirth = dobError;
      invalidFields.push("Tanggal Lahir");
    }
    
    const nikError = validateNIK(formData.nik);
    if (nikError) {
      errors.nik = nikError;
      invalidFields.push("NIK");
    }
    
    const phoneError = validatePhone(formData.phone);
    if (phoneError) {
      errors.phone = phoneError;
      invalidFields.push("Nomor Telepon");
    }
    
    const positionError = validatePosition(formData.position);
    if (positionError) {
      errors.position = positionError;
      invalidFields.push("Posisi");
    }
    
    const occupationError = validateOccupation(formData.occupation);
    if (occupationError) {
      errors.occupation = occupationError;
      invalidFields.push("Pekerjaan");
    }
    
    const addressError = validateAddress(formData.address);
    if (addressError) {
      errors.address = addressError;
      invalidFields.push("Alamat");
    }
    
    const pinError = validatePin(formData.pin, formData.position, !!editingMember);
    if (pinError) {
      errors.pin = pinError;
      invalidFields.push("PIN Kasir");
    }
    
    // Set all errors at once
    setFieldErrors(errors);
    
    // If there are validation errors, show toast and return
    if (invalidFields.length > 0) {
      const dialogContent = document.querySelector('[role="dialog"]');
      if (dialogContent) {
        dialogContent.scrollTop = 0;
      }
      
      toast({
        title: "❌ Data Tidak Lengkap!",
        description: `Mohon perbaiki: ${invalidFields.join(", ")}`,
        variant: "destructive",
        duration: 7000
      });
      return;
    }
    
    setUploading(true);
    setProgressMessage("Memvalidasi data...");
    setProgressValue(10);
    
    try {
      const name = formData.full_name.trim();
      let positionToSave = formData.position.trim() || (role === 'admin' || role === 'owner' ? 'Sales' : '');
      let photoUrl = editingMember?.photo_url || null;

      // Handle photo upload if there's a new photo
      if (photoFile) {
        setProgressMessage("Mengompresi foto...");
        setProgressValue(20);
        const compressedFile = await compressImage(photoFile, 0.5, 800);
        
        setProgressMessage("Mengunggah foto...");
        setProgressValue(40);
        const fileExt = compressedFile.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${fileName}`;
        const {
          error: uploadError
        } = await supabase.storage.from('customer-photos').upload(filePath, compressedFile, {
          cacheControl: '3600',
          upsert: false
        });
        if (uploadError) {
          throw uploadError;
        }
        const {
          data: {
            publicUrl
          }
        } = supabase.storage.from('customer-photos').getPublicUrl(filePath);
        photoUrl = publicUrl;
        setProgressValue(60);
      }
      
      setProgressMessage("Menyimpan data anggota...");
      setProgressValue(80);
      if (editingMember) {
        // Clean full_name before update
        const cleanFullName = formData.full_name.trim().replace(/\s+/g, ' ');
        const sanitizedDOB = sanitizeDateForDatabase(dateOfBirth);

        // Validate date_of_birth if provided
        if (dateOfBirth && !sanitizedDOB) {
          toast({
            title: "❌ Format Tanggal Lahir Tidak Valid",
            description: "Tahun harus antara 1900-2100",
            variant: "destructive",
            duration: 5000
          });
          setUploading(false);
          return;
        }
        const {
          error
        } = await supabase.from("members").update({
          full_name: cleanFullName,
          position: positionToSave,
          phone: formData.phone,
          nik: formData.nik,
          occupation: formData.occupation,
          address: formData.address,
          date_of_birth: sanitizedDOB,
          photo_url: photoUrl
        }).eq("id", editingMember.id);
        if (error) {
          console.error('Update member error:', error);
          throw error;
        }

        // If date of birth exists, regenerate auth account to fix any email issues
        if (sanitizedDOB && editingMember.user_id) {
          console.log('Regenerating auth account for member:', editingMember.id);
          try {
            const {
              error: authError
            } = await supabase.functions.invoke('create-member-auth', {
              body: {
                memberId: editingMember.id,
                fullName: cleanFullName,
                dateOfBirth: sanitizedDOB,
                position: positionToSave
                // PIN tidak diubah saat edit - hanya bisa diubah via Edit PIN dengan supercode
              }
            });
            if (authError) {
              console.warn('Failed to regenerate auth:', authError);
            }
          } catch (authErr) {
            console.warn('Auth regeneration error:', authErr);
          }
        }
        await logSystemEvent({
          category: "member_management",
          action: "Update Anggota",
          description: `Memperbarui data anggota: ${formData.full_name}`,
          metadata: {
            member_id: editingMember.id,
            member_name: formData.full_name,
            position: formData.position
          }
        });
        
        // Show success animation
        setProgressMessage("");
        setProgressValue(100);
        setShowSuccess(true);
        
        toast({
          title: "✅ Data anggota berhasil diperbarui",
          duration: 3000
        });
        
        // Delay closing to show success animation
        setTimeout(() => {
          setOpen(false);
          resetForm();
          setShowSuccess(false);
          setCurrentPage(1);
          invalidateMembers();
          window.dispatchEvent(new Event('member-updated'));
        }, 1500);
      } else {
        // Generate next unique member_number safely
        const formattedDOB = sanitizeDateForDatabase(dateOfBirth);

        // Validate date_of_birth if provided
        if (dateOfBirth && !formattedDOB) {
          toast({
            title: "❌ Format Tanggal Lahir Tidak Valid",
            description: "Tahun harus antara 1900-2100",
            variant: "destructive",
            duration: 5000
          });
          setUploading(false);
          return;
        }
        const attemptInsert = async () => {
          const {
            data: allMembers,
            error: fetchError
          } = await supabase.from("members").select("member_number");
          if (fetchError) {
            throw fetchError;
          }
          let maxNum = 0;
          for (const m of allMembers || []) {
            const numStr = (m as any).member_number as string;
            // Extract numeric part after 'A' prefix
            const n = parseInt(numStr?.replace(/^A/, '') || '0', 10);
            if (!isNaN(n) && n > maxNum) maxNum = n;
          }
          const nextNumber = 'A' + (maxNum + 1).toString().padStart(3, "0");
          // Clean full_name before insert
          const cleanFullName = formData.full_name.trim().replace(/\s+/g, ' ');
          const {
            data,
            error
          } = await supabase.from("members").insert([{
            member_number: nextNumber,
            full_name: cleanFullName,
            position: positionToSave,
            phone: formData.phone,
            nik: formData.nik,
            occupation: formData.occupation,
            address: formData.address,
            date_of_birth: formattedDOB,
            photo_url: photoUrl
          }]).select().single();
          return {
            data,
            error
          } as {
            data: any;
            error: any;
          };
        };
        let newMember: any = null;
        for (let i = 0; i < 3; i++) {
          const {
            data,
            error
          } = await attemptInsert();
          if (!error) {
            newMember = data;
            break;
          }
          // Retry only when unique constraint on member_number is hit
          if ((error?.code === "23505" || (error?.message || "").includes("duplicate key value")) && (error?.message || "").includes("members_member_number_key")) {
            continue;
          }
          throw error;
        }
        if (!newMember) {
          throw new Error("Gagal membuat nomor anggota unik. Coba lagi.");
        }

        // Create auth account with PIN if applicable
        if (formattedDOB) {
          console.log('Creating auth account for new member:', newMember.id);
          try {
            const cleanFullName = formData.full_name.trim().replace(/\s+/g, ' ');
            const { error: authError } = await supabase.functions.invoke('create-member-auth', {
              body: {
                memberId: newMember.id,
                fullName: cleanFullName,
                dateOfBirth: formattedDOB,
                position: positionToSave,
                pin: positionToSave === 'Kasir' ? formData.pin : undefined
              }
            });
            if (authError) {
              console.error('Failed to create auth:', authError);
              // Don't throw, just warn - member record is already created
              toast({
                title: "⚠️ Peringatan",
                description: "Anggota berhasil dibuat tapi akun login gagal. Silakan aktifkan manual.",
                duration: 5000
              });
            }
          } catch (authErr) {
            console.warn('Auth creation error:', authErr);
          }
        }

        await logSystemEvent({
          category: "member_management",
          action: "Tambah Anggota",
          description: `Menambahkan anggota baru: ${formData.full_name} (${formData.position})`,
          metadata: {
            member_id: newMember.id,
            member_name: formData.full_name,
            member_number: newMember.member_number,
            position: formData.position,
            has_account: formattedDOB ? true : false,
            has_pin: positionToSave === 'Kasir' && formData.pin ? true : false
          }
        });
        
        // Show success animation
        setProgressMessage("");
        setProgressValue(100);
        setShowSuccess(true);
        
        toast({
          title: formattedDOB ? "✅ Data anggota dan akun login berhasil dibuat" : "✅ Data anggota berhasil ditambahkan",
          description: formattedDOB ? undefined : "Tanggal lahir diperlukan untuk membuat akun login",
          duration: 4000
        });
        
        // Delay closing to show success animation
        setTimeout(() => {
          setOpen(false);
          resetForm();
          setShowSuccess(false);
          setCurrentPage(1);
          invalidateMembers();
          window.dispatchEvent(new Event('member-created'));
        }, 1500);
      }
    } catch (error: any) {
      console.error('❌ Member insert error:', error);
      const errorMsg = error.message || 'Terjadi kesalahan tidak dikenal';
      const errorCode = error.code || 'NO_CODE';
      const errorDetails = error.details || '';
      const errorHint = error.hint || '';
      toast({
        title: "❌ Gagal Menyimpan Data Anggota",
        description: `${errorMsg}${errorCode !== 'NO_CODE' ? `\nCode: ${errorCode}` : ''}${errorDetails ? `\nDetails: ${errorDetails}` : ''}${errorHint ? `\nHint: ${errorHint}` : ''}`,
        variant: "destructive",
        duration: 10000
      });
    } finally {
      setUploading(false);
      setProgressMessage("");
      setProgressValue(0);
    }
  };
  const handleActivateAccount = async (member: any) => {
    if (!member.date_of_birth) {
      toast({
        title: "Tidak dapat mengaktifkan akun",
        description: "Tanggal lahir diperlukan untuk membuat akun",
        variant: "destructive"
      });
      return;
    }
    if (!confirm(`Aktifkan akun untuk ${member.full_name}?`)) return;
    setActivatingAccount(member.id);
    try {
      const {
        data,
        error
      } = await supabase.functions.invoke('create-member-auth', {
        body: {
          memberId: member.id,
          fullName: member.full_name,
          dateOfBirth: member.date_of_birth,
          position: member.position,
          pin: member.position === 'Kasir' && member.pin ? member.pin : undefined
        }
      });
      if (error) throw error;
      toast({
        title: "✅ Akun Berhasil Diaktifkan",
        description: `Email: ${data.email}\nPassword: ${data.password}`,
        duration: 10000
      });
      invalidateMembers();
    } catch (error) {
      console.error('Error activating account:', error);
      toast({
        title: "Gagal mengaktifkan akun",
        description: error instanceof Error ? error.message : "Terjadi kesalahan",
        variant: "destructive"
      });
    } finally {
      setActivatingAccount(null);
    }
  };
  const handleToggleStatus = async (member: any) => {
    const newStatus = !member.is_active;
    const action = newStatus ? "mengaktifkan" : "menonaktifkan";
    if (!confirm(`Apakah Anda yakin ingin ${action} anggota ${member.full_name}?`)) return;
    try {
      // Check if the member being deactivated is the current logged-in user
      const { data: { user } } = await supabase.auth.getUser();
      const isCurrentUser = user && member.user_id === user.id;

      const {
        error
      } = await supabase.from("members").update({
        is_active: newStatus
      }).eq("id", member.id);
      if (error) throw error;
      await logSystemEvent({
        category: "member_management",
        action: newStatus ? "Aktivasi Anggota" : "Nonaktifkan Anggota",
        description: `${newStatus ? "Mengaktifkan" : "Menonaktifkan"} anggota: ${member.full_name}`,
        metadata: {
          member_id: member.id,
          member_name: member.full_name,
          new_status: newStatus,
          auto_signout: !newStatus && isCurrentUser
        }
      });
      
      // If deactivating the current user, sign them out automatically
      if (!newStatus && isCurrentUser) {
        toast({
          title: "⚠️ Akun Dinonaktifkan",
          description: "Akun Anda telah dinonaktifkan. Anda akan keluar otomatis.",
          variant: "destructive"
        });
        
        // Wait a moment for user to see the message
        setTimeout(async () => {
          await supabase.auth.signOut();
          navigate('/auth');
        }, 2000);
      } else {
        toast({
          title: `Anggota berhasil di${action}`,
          description: newStatus ? "Anggota dapat login kembali ke sistem" : "Anggota tidak dapat login hingga diaktifkan kembali"
        });
      }
      
      setCurrentPage(1);
      invalidateMembers();
      window.dispatchEvent(new Event('member-status-changed'));
    } catch (error) {
      console.error('Error toggling member status:', error);
      toast({
        title: `Gagal ${action} anggota`,
        variant: "destructive"
      });
    }
  };
  const handleDelete = async (id: string) => {
    const memberToDelete = members.find(m => m.id === id);

    // Check if admin trying to delete owner/admin
    if (role === 'admin' && (memberToDelete?.position?.toLowerCase() === 'owner' || memberToDelete?.position?.toLowerCase() === 'admin')) {
      setShowAccessDenied(true);
      return;
    }
    
    // Open migration dialog
    setMemberToDelete(memberToDelete);
    setDeleteMigrationDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!memberToDelete) return;

    await logSystemEvent({
      category: "member_management",
      action: "Hapus Anggota",
      description: `Menghapus anggota: ${memberToDelete.full_name}`,
      metadata: {
        member_id: memberToDelete.id,
        member_name: memberToDelete.full_name,
        position: memberToDelete.position
      }
    });
    
    setCurrentPage(1);
    invalidateMembers();
    window.dispatchEvent(new Event('member-deleted'));
    setMemberToDelete(null);
  };
  const resetForm = () => {
    setFormData({
      full_name: "",
      position: "",
      phone: "",
      nik: "",
      occupation: "",
      address: "",
      pin: ""
    });
    setDateOfBirth(undefined);
    setPhotoFile(null);
    setPhotoPreview(null);
    setEditingMember(null);
    setFieldErrors({}); // Reset validation errors
    setProgressMessage("");
    setProgressValue(0);
  };
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
  };
  const openEditDialog = (member: any) => {
    // Check if admin trying to edit owner/admin
    if (role === 'admin' && (member.position?.toLowerCase() === 'owner' || member.position?.toLowerCase() === 'admin')) {
      setShowAccessDenied(true);
      return;
    }
    setEditingMember(member);
    setFormData({
      full_name: member.full_name || "",
      position: member.position || "",
      phone: member.phone || "",
      nik: member.nik || "",
      occupation: member.occupation || "",
      address: member.address || "",
      pin: member.pin || ""
    });
    setDateOfBirth(member.date_of_birth ? new Date(member.date_of_birth) : undefined);
    setPhotoPreview(member.photo_url || null);
    setOpen(true);
  };
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Helper untuk membatasi nomor halaman yang ditampilkan
  const getPaginationRange = () => {
    const delta = isMobile ? 1 : 2;
    const range: (number | string)[] = [];
    const rangeWithDots: (number | string)[] = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }
    if (currentPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }
    rangeWithDots.push(...range);
    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push('...', totalPages);
    } else if (totalPages > 1) {
      rangeWithDots.push(totalPages);
    }
    return rangeWithDots;
  };
  return <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row justify-end items-start sm:items-center gap-3 mb-3">
        <div className="flex gap-2 w-full sm:w-auto">
          {(isOwner || isAdmin) && <ResponsiveDialog open={open} onOpenChange={o => {
          setOpen(o);
          if (!o) resetForm();
        }}>
              <ResponsiveDialogTrigger asChild>
                <Button className="min-h-[44px] flex-1 sm:flex-initial flex-shrink-0">
                  <Plus className="h-4 w-4 mr-2" />
                  Tambah Anggota
                </Button>
            </ResponsiveDialogTrigger>
          <ResponsiveDialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <ResponsiveDialogHeader>
              <ResponsiveDialogTitle>{editingMember ? "Edit" : "Tambah"} Anggota</ResponsiveDialogTitle>
              <ResponsiveDialogDescription>
                Lengkapi data anggota, lalu simpan untuk menambahkan.
              </ResponsiveDialogDescription>
            </ResponsiveDialogHeader>
            <form id="member-form" onSubmit={handleSubmit} className="space-y-4">
              {/* Photo Upload - Horizontal Layout */}
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-4">
                  <div className="relative flex-shrink-0">
                    <Avatar className={cn("h-16 w-16 border-2", fieldErrors.photo ? "border-destructive" : "border-dashed border-muted-foreground/50")}>
                      <AvatarImage src={photoPreview || undefined} />
                      <AvatarFallback className="bg-muted text-muted-foreground text-lg">
                        {formData.full_name?.substring(0, 2).toUpperCase() || "?"}
                      </AvatarFallback>
                    </Avatar>
                    {photoPreview && (
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-1 -right-1 h-5 w-5 rounded-full"
                        onClick={removePhoto}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium">Foto Member *</span>
                    <Input 
                      type="file" 
                      accept="image/*" 
                      onChange={(e) => {
                        handlePhotoChange(e);
                        clearFieldError('photo');
                      }} 
                      className="hidden" 
                      id="photo-upload" 
                    />
                    <Label htmlFor="photo-upload" className="cursor-pointer">
                      <Button type="button" variant="outline" size="sm" asChild>
                        <span>
                          <Upload className="h-4 w-4 mr-2" />
                          {photoPreview ? "Ganti" : "Upload"}
                        </span>
                      </Button>
                    </Label>
                  </div>
                </div>
                {fieldErrors.photo && (
                  <p className="text-sm text-destructive text-center flex items-center justify-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.photo}
                  </p>
                )}
              </div>

              {/* Full Name */}
              <div>
                <Label htmlFor="full_name" className={fieldErrors.full_name ? "text-destructive" : ""}>Nama Lengkap *</Label>
                <Input 
                  id="full_name" 
                  value={formData.full_name} 
                  onChange={e => {
                    setFormData({ ...formData, full_name: e.target.value.toUpperCase() });
                    clearFieldError('full_name');
                  }}
                  onBlur={() => handleFieldBlur('full_name', formData.full_name)}
                  className={fieldErrors.full_name ? "border-destructive" : ""}
                />
                {fieldErrors.full_name && (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.full_name}
                  </p>
                )}
              </div>

              {/* Date of Birth */}
              <div>
                <Label className={fieldErrors.dateOfBirth ? "text-destructive" : ""}>Tanggal Lahir *</Label>
                <DatePicker 
                  value={dateOfBirth} 
                  onChange={(date) => {
                    setDateOfBirth(date);
                    clearFieldError('dateOfBirth');
                  }} 
                  placeholder="dd/MM/yyyy" 
                  maxDate={getTodayInWIB()} 
                  minDate={new Date("1900-01-01")} 
                />
                {fieldErrors.dateOfBirth ? (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.dateOfBirth}
                  </p>
                ) : !editingMember && !dateOfBirth && (
                  <p className="text-sm text-muted-foreground mt-1">
                    Tanggal lahir diperlukan untuk membuat akun login
                  </p>
                )}
              </div>

              {/* NIK */}
              <div>
                <Label htmlFor="nik" className={fieldErrors.nik ? "text-destructive" : ""}>NIK *</Label>
                <Input 
                  id="nik" 
                  value={formData.nik} 
                  onChange={e => {
                    setFormData({ ...formData, nik: e.target.value });
                    clearFieldError('nik');
                  }}
                  onBlur={() => handleFieldBlur('nik', formData.nik)}
                  placeholder="Nomor Induk Kependudukan"
                  className={fieldErrors.nik ? "border-destructive" : ""}
                />
                {fieldErrors.nik && (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.nik}
                  </p>
                )}
              </div>

              {/* Phone */}
              <div>
                <Label htmlFor="phone" className={fieldErrors.phone ? "text-destructive" : ""}>Nomor Telepon *</Label>
                <Input 
                  id="phone" 
                  type="tel" 
                  value={formData.phone} 
                  onChange={e => {
                    let value = e.target.value;
                    const hasPlus = value.startsWith('+');
                    value = value.replace(/[^\d+]/g, '');
                    if (hasPlus && !value.startsWith('+')) {
                      value = '+' + value.replace(/\+/g, '');
                    } else {
                      value = value.replace(/\+/g, '');
                    }
                    setFormData({ ...formData, phone: value });
                    clearFieldError('phone');
                  }}
                  onBlur={() => handleFieldBlur('phone', formData.phone)}
                  placeholder="08xxx atau +62xxx"
                  className={fieldErrors.phone ? "border-destructive" : ""}
                />
                {fieldErrors.phone ? (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.phone}
                  </p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">
                    Harus dimulai dengan 08 atau +62 dan minimal 10 digit
                  </p>
                )}
              </div>

              {/* Position */}
              <div>
                <Label htmlFor="position" className={fieldErrors.position ? "text-destructive" : ""}>Posisi *</Label>
                <Select 
                  value={formData.position} 
                  onValueChange={v => {
                    setFormData({ ...formData, position: v });
                    clearFieldError('position');
                  }} 
                  disabled={editingMember && role === 'admin' && editingMember.position?.toLowerCase() !== 'sales'}
                >
                  <SelectTrigger className={fieldErrors.position ? "border-destructive" : ""}>
                    <SelectValue placeholder="Pilih posisi" />
                  </SelectTrigger>
                  <SelectContent>
                    {role === 'owner' && <SelectItem value="Owner">Owner</SelectItem>}
                    {role === 'owner' && <SelectItem value="Admin">Admin</SelectItem>}
                    <SelectItem value="Sales">Sales</SelectItem>
                    {(role === 'owner' || role === 'admin') && <SelectItem value="Kasir">Kasir</SelectItem>}
                  </SelectContent>
                </Select>
                {fieldErrors.position && (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.position}
                  </p>
                )}
              </div>
              
              {/* PIN for Kasir (new members only) */}
              {formData.position === 'Kasir' && !editingMember && (
                <div>
                  <Label htmlFor="pin" className={fieldErrors.pin ? "text-destructive" : ""}>PIN Kasir (6 Digit) *</Label>
                  <Input 
                    id="pin" 
                    type="password" 
                    value={formData.pin} 
                    onChange={e => {
                      setFormData({ ...formData, pin: e.target.value.replace(/\D/g, '').slice(0, 6) });
                      clearFieldError('pin');
                    }}
                    onBlur={() => handleFieldBlur('pin', formData.pin)}
                    placeholder="Masukkan 6 digit PIN" 
                    maxLength={6}
                    className={fieldErrors.pin ? "border-destructive" : ""}
                  />
                  {fieldErrors.pin ? (
                    <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      {fieldErrors.pin}
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground mt-1">PIN untuk akses login tahap kedua kasir</p>
                  )}
                </div>
              )}
              
              {/* PIN info for editing Kasir */}
              {formData.position === 'Kasir' && editingMember && (
                <div className="p-3 bg-muted/50 rounded-md border border-border">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium">PIN Kasir:</span> Untuk mengubah PIN, gunakan tombol "Ubah PIN Kasir" di halaman detail anggota (memerlukan Supercode).
                  </p>
                </div>
              )}
              
              {/* Occupation */}
              <div>
                <Label htmlFor="occupation" className={fieldErrors.occupation ? "text-destructive" : ""}>Pekerjaan *</Label>
                <Input 
                  id="occupation" 
                  value={formData.occupation} 
                  onChange={e => {
                    setFormData({ ...formData, occupation: e.target.value });
                    clearFieldError('occupation');
                  }}
                  onBlur={() => handleFieldBlur('occupation', formData.occupation)}
                  placeholder="Masukkan pekerjaan"
                  className={fieldErrors.occupation ? "border-destructive" : ""}
                />
                {fieldErrors.occupation && (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.occupation}
                  </p>
                )}
              </div>

              {/* Address */}
              <div>
                <Label htmlFor="address" className={fieldErrors.address ? "text-destructive" : ""}>Alamat *</Label>
                <Input 
                  id="address" 
                  value={formData.address} 
                  onChange={e => {
                    setFormData({ ...formData, address: e.target.value });
                    clearFieldError('address');
                  }}
                  onBlur={() => handleFieldBlur('address', formData.address)}
                  placeholder="Masukkan alamat"
                  className={fieldErrors.address ? "border-destructive" : ""}
                />
                {fieldErrors.address && (
                  <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.address}
                  </p>
                )}
              </div>
              
              {/* Inline Progress Indicator */}
              {uploading && progressMessage && !showSuccess && (
                <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span className="text-sm font-medium">{progressMessage}</span>
                  </div>
                  <Progress value={progressValue} className="h-2" />
                  <p className="text-xs text-muted-foreground text-center">
                    Mohon tunggu, jangan tutup form ini...
                  </p>
                </div>
              )}
              
              {/* Success Animation */}
              <SuccessCheckmark 
                show={showSuccess} 
                message={editingMember ? "Data anggota berhasil diperbarui!" : "Anggota berhasil ditambahkan!"}
              />
              
              {!showSuccess && (
                <Button type="submit" className="w-full" disabled={uploading}>
                  {uploading ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Memproses...
                    </span>
                  ) : editingMember ? "Perbarui Anggota" : "Tambah Anggota"}
                </Button>
              )}
            </form>
          </ResponsiveDialogContent>
        </ResponsiveDialog>}
        </div>
      </div>

      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <CardTitle className="truncate">Daftar Anggota</CardTitle>
              <ViewToggle viewMode={viewMode} onToggle={toggleView} />
            </div>
            <div className="flex items-center gap-2 sm:ml-auto">
              <div className="relative w-full sm:w-64 md:w-72">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Cari ID, Nama..." value={searchQuery} onChange={e => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }} className="pl-9 min-h-[44px] w-full" />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          {loading ? <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">Memuat data...</p>
            </div> : <AnimatedViewTransition viewMode={viewMode}>
            {(isMobile || isSales || viewMode === 'card') ? (/* Card View - For Mobile, Sales Users, and Card View Mode */
        <div className="w-full max-w-full">
              {members.length === 0 && searchQuery ? <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
                  <Search className="h-8 w-8" />
                  <p className="font-medium text-sm sm:text-base">Tidak Ditemukan</p>
                  <p className="text-xs sm:text-sm text-center px-4">Tidak ada anggota dengan ID, Nama atau NIK "{searchQuery}"</p>
                </div> : <div className={cn("grid gap-3", isMobile ? "grid-cols-1" : "grid-cols-2 lg:grid-cols-3 xl:grid-cols-4")}>
                  {members.map(member => {
              const isOnline = member.user_id && onlineUserIds.has(member.user_id) || currentMemberId && member.id === currentMemberId;
              return <Card key={member.id} className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden" onClick={() => {
                setSelectedMember(member);
                setShowDetail(true);
              }}>
                        <CardContent className="p-3">
                          <div className="flex items-center gap-3">
                            {/* Avatar with Online Status */}
                            <div className="relative flex-shrink-0 mt-1">
                              <ClickableAvatar 
                                src={member.photo_url}
                                alt={member.full_name}
                                fallback={member.full_name?.substring(0, 2).toUpperCase()}
                                className="h-14 w-14"
                                fallbackClassName="bg-primary/10 text-primary text-lg"
                              />
                              {isOnline ? <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full bg-green-500 ring-2 ring-background" title="Online" /> : <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full bg-gray-400 ring-2 ring-background" title="Offline" />}
                            </div>
                            
                            {/* Member Info */}
                            <div className="flex-1 min-w-0 space-y-1.5">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1 min-w-0">
                                  <h3 className="font-semibold text-sm line-clamp-1">
                                    {member.full_name}
                                  </h3>
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <PositionBadge position={member.position} size="sm" />
                                    {!member.is_active && (
                                      <Badge variant="destructive" className="text-xs">
                                        Nonaktif
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                                <Badge 
                                  variant={isOnline ? "default" : "secondary"} 
                                  className={cn(
                                    "text-xs flex-shrink-0",
                                    isOnline && "animate-shimmer bg-gradient-to-r from-green-500 via-emerald-400 to-green-600 bg-[length:200%_100%] text-white border-green-300"
                                  )}
                                >
                                  {isOnline ? "Online" : "Offline"}
                                </Badge>
                              </div>
                              <Badge variant="outline" className="text-xs w-fit font-bold">
                                {member.member_number}
                              </Badge>
                              
                              {/* Join Date */}
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <CalendarIcon className="h-3 w-3" />
                                <span>Bergabung: {format(new Date(member.effective_join_date || member.created_at), 'dd MMM yyyy', {
                            locale: idLocale
                          })}</span>
                              </div>
                              
                              {/* Statistics - Only show if there's data */}
                              {((member.approved_applications || 0) > 0 || (member.total_amount_disbursed || 0) > 0) && <div className="flex items-center gap-3 pt-1 text-xs">
                                  <div className="flex items-center gap-1">
                                    <span className="text-muted-foreground">Aplikasi:</span>
                                    <span className="font-semibold text-foreground">
                                      {member.approved_applications || 0}
                                    </span>
                                  </div>
                                  <div className="h-3 w-px bg-border" />
                                  <div className="flex items-center gap-1">
                                    <span className="text-muted-foreground">Pencairan:</span>
                                    <span className="font-semibold text-foreground">
                                      {new Intl.NumberFormat('id-ID', {
                              style: 'currency',
                              currency: 'IDR',
                              minimumFractionDigits: 0,
                              maximumFractionDigits: 0
                            }).format(member.total_amount_disbursed || 0)}
                                    </span>
                                  </div>
                                </div>}
                            </div>
                          </div>
                        </CardContent>
                      </Card>;
            })}
                </div>}
            </div>) : (/* Desktop View - Table */
        <div className="w-full">
              <ScrollArea className="h-[calc(100vh-320px)] w-full">
                <div className="overflow-x-auto min-w-full">
                  <Table className="min-w-max">
            <TableHeader>
              <TableRow>
                <TableHead>No. ID</TableHead>
                <TableHead>Foto</TableHead>
                <TableHead>Nama</TableHead>
                <TableHead>NIK</TableHead>
                <TableHead>Tanggal Lahir</TableHead>
                <TableHead>Usia</TableHead>
                <TableHead>Pekerjaan</TableHead>
                <TableHead>Telepon</TableHead>
                <TableHead>Alamat</TableHead>
                <TableHead>Tanggal Pendaftaran</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.length === 0 && searchQuery ? <TableRow>
                  <TableCell colSpan={9} className="text-center py-8">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Search className="h-8 w-8" />
                      <p className="font-medium">Status Anggota</p>
                      <p className="text-sm">Tidak ada anggota dengan ID, Nama atau NIK "{searchQuery}"</p>
                    </div>
                  </TableCell>
                 </TableRow> : members.map(member => <TableRow key={member.id} className={cn(searchQuery ? "bg-yellow-50 dark:bg-yellow-950/20" : "", "cursor-pointer hover:bg-muted/50 transition-colors")} onClick={() => {
                    setSelectedMember(member);
                    setShowDetail(true);
                  }}>
                  <TableCell className="font-bold">{member.member_number}</TableCell>
                  <TableCell>
                    <div className="relative inline-block">
                      <ClickableAvatar 
                        src={member.photo_url}
                        alt={member.full_name}
                        fallback={member.full_name?.charAt(0)}
                        className="w-10 h-10"
                      />
                      {(member.user_id && onlineUserIds.has(member.user_id) || currentMemberId && member.id === currentMemberId) && <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full bg-green-500 ring-2 ring-background" title="Online" />}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span>{member.full_name}</span>
                      <PositionBadge position={member.position} size="sm" />
                      {!member.is_active && (
                        <Badge variant="destructive" className="text-xs">
                          Nonaktif
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{member.nik || "-"}</TableCell>
                  <TableCell>{formatDate(member.date_of_birth)}</TableCell>
                  <TableCell>
                    {calculateAge(member.date_of_birth) !== null ? `${calculateAge(member.date_of_birth)} tahun` : "-"}
                  </TableCell>
                  <TableCell>{member.occupation || "-"}</TableCell>
                  <TableCell>{member.phone}</TableCell>
                  <TableCell>{member.address || "-"}</TableCell>
                  <TableCell>
                    {new Date(member.effective_join_date || member.created_at).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: 'long',
                        year: 'numeric'
                      })}
                  </TableCell>
                </TableRow>)}
            </TableBody>
          </Table>
                </div>
              </ScrollArea>
            </div>)
            }</AnimatedViewTransition>}
        </CardContent>
      </Card>

      {/* Member Detail Dialog for Mobile */}
      <MemberDetailDialog open={showDetail} onOpenChange={setShowDetail} member={selectedMember} isOnline={selectedMember && (selectedMember.user_id && onlineUserIds.has(selectedMember.user_id) || currentMemberId && selectedMember.id === currentMemberId)} onEdit={openEditDialog} onDelete={member => handleDelete(member.id)} onToggleActive={handleToggleStatus} onActivateAccount={handleActivateAccount} />

      {totalCount > ITEMS_PER_PAGE && <Card>
          <CardContent className="pt-6">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious onClick={() => currentPage > 1 && handlePageChange(currentPage - 1)} className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                </PaginationItem>
                {getPaginationRange().map((page, idx) => <PaginationItem key={idx}>
                    {page === '...' ? <span className="px-2">...</span> : <PaginationLink onClick={() => handlePageChange(page as number)} isActive={currentPage === page} className="cursor-pointer">
                        {page}
                      </PaginationLink>}
                  </PaginationItem>)}
                <PaginationItem>
                  <PaginationNext onClick={() => currentPage < totalPages && handlePageChange(currentPage + 1)} className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </CardContent>
        </Card>}

      <AlertDialog open={showAccessDenied} onOpenChange={setShowAccessDenied}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Akses Ditolak</AlertDialogTitle>
            <AlertDialogDescription>
              Anda tidak memiliki izin untuk mengedit atau menghapus anggota dengan posisi Owner atau Admin.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Button onClick={() => setShowAccessDenied(false)}>OK</Button>
        </AlertDialogContent>
      </AlertDialog>

      <MemberDeleteMigrationDialog
        open={deleteMigrationDialogOpen}
        onOpenChange={setDeleteMigrationDialogOpen}
        memberToDelete={memberToDelete}
        onConfirmDelete={handleConfirmDelete}
      />
    </div>;
}