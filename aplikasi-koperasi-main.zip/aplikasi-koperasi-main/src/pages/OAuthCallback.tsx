import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

export default function OAuthCallback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleCallback = async () => {
      try {
        const code = searchParams.get('code');
        const errorParam = searchParams.get('error');

        if (errorParam) {
          throw new Error(`OAuth error: ${errorParam}`);
        }

        if (!code) {
          throw new Error('No authorization code received');
        }

        // Get settings to retrieve oauth credentials
        const { data: settingsData, error: settingsError } = await supabase
          .from('google_drive_settings')
          .select('oauth_client_id, oauth_client_secret')
          .single();

        if (settingsError) throw settingsError;
        if (!settingsData?.oauth_client_id || !settingsData?.oauth_client_secret) {
          throw new Error('OAuth credentials not found');
        }

        // Exchange code for tokens
        const redirectUrl = `${window.location.origin}/oauth/callback`;
        const { data, error } = await supabase.functions.invoke('google-drive-oauth-exchange', {
          body: { 
            code, 
            redirectUrl,
            clientId: settingsData.oauth_client_id,
            clientSecret: settingsData.oauth_client_secret
          }
        });

        if (error) throw error;

        // Get redirect path from sessionStorage
        const redirectPath = sessionStorage.getItem('oauth_redirect') || '/settings';
        sessionStorage.removeItem('oauth_redirect');

        // Navigate back to settings
        navigate(redirectPath, { 
          state: { 
            message: `Berhasil terhubung sebagai ${data.email}`,
            type: 'success' 
          } 
        });
      } catch (error) {
        console.error('OAuth callback error:', error);
        setError(error instanceof Error ? error.message : 'Unknown error occurred');
        
        // Redirect to settings with error after 3 seconds
        setTimeout(() => {
          navigate('/settings', { 
            state: { 
              message: error instanceof Error ? error.message : 'OAuth login gagal',
              type: 'error' 
            } 
          });
        }, 3000);
      }
    };

    handleCallback();
  }, [searchParams, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-4">
        {error ? (
          <>
            <div className="text-destructive text-lg font-semibold">Error</div>
            <p className="text-muted-foreground">{error}</p>
            <p className="text-sm text-muted-foreground">Mengalihkan kembali ke pengaturan...</p>
          </>
        ) : (
          <>
            <Loader2 className="h-8 w-8 animate-spin mx-auto" />
            <p className="text-muted-foreground">Memproses login Google Drive...</p>
          </>
        )}
      </div>
    </div>
  );
}
