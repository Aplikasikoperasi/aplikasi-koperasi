import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { MessageSquare, Send, Users, AlertCircle, Info, CheckCircle, Radio, Power } from "lucide-react";
import { useUserRole } from "@/hooks/useUserRole";
import { useNavigate } from "react-router-dom";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
export default function BroadcastMessages() {
  const navigate = useNavigate();
  const {
    isOwner,
    isAdmin,
    loading: roleLoading
  } = useUserRole();
  const [customers, setCustomers] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState<"info" | "announcement" | "reminder">("info");
  const [recipientType, setRecipientType] = useState<"customers" | "members">("customers");
  const [sendToAll, setSendToAll] = useState(true);
  const [selectedCustomers, setSelectedCustomers] = useState<string[]>([]);
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [templates, setTemplates] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [templateVariables, setTemplateVariables] = useState<Record<string, string>>({});
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maintenanceTitle, setMaintenanceTitle] = useState("Mode Maintenance");
  const [maintenanceMessage, setMaintenanceMessage] = useState("Sistem sedang dalam maintenance. Mohon maaf atas ketidaknyamanan ini.");
  const [updatingMaintenance, setUpdatingMaintenance] = useState(false);
  useEffect(() => {
    if (!roleLoading && !isOwner && !isAdmin) {
      toast.error("Akses ditolak");
      navigate("/dashboard");
    }
  }, [isOwner, isAdmin, roleLoading, navigate]);
  useEffect(() => {
    loadCustomers();
    loadMembers();
    loadTemplates();
    loadMaintenanceSettings();

    // Subscribe to real-time changes
    const subscription = supabase
      .channel('maintenance-mode-changes-broadcast')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'app_settings'
        },
        () => {
          loadMaintenanceSettings();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadMaintenanceSettings = async () => {
    const { data, error } = await supabase
      .from("app_settings")
      .select("maintenance_mode_enabled, maintenance_message, maintenance_title")
      .maybeSingle();
    
    if (!error && data) {
      setMaintenanceMode(data.maintenance_mode_enabled || false);
      setMaintenanceMessage(data.maintenance_message || "Sistem sedang dalam maintenance. Mohon maaf atas ketidaknyamanan ini.");
      setMaintenanceTitle(data.maintenance_title || "Mode Maintenance");
    }
  };
  const loadCustomers = async () => {
    const {
      data,
      error
    } = await supabase.from("customers").select("id, full_name, id_number").eq("status", "approved").order("full_name");
    if (!error && data) {
      setCustomers(data);
    }
  };
  const loadMembers = async () => {
    const {
      data,
      error
    } = await supabase.from("members").select("id, full_name, member_number, position").eq("is_active", true).order("full_name");
    if (!error && data) {
      setMembers(data);
    }
  };
  const loadTemplates = async () => {
    const {
      data,
      error
    } = await supabase.from("whatsapp_message_templates").select("*").eq("is_active", true).order("name");
    if (!error && data) {
      setTemplates(data);
    }
  };
  const extractVariables = (content: string): string[] => {
    const regex = /\{\{([^}]+)\}\}/g;
    const matches = content.matchAll(regex);
    return Array.from(matches, m => m[1]);
  };
  const replaceVariables = (content: string, variables: Record<string, string>): string => {
    let result = content;
    Object.entries(variables).forEach(([key, value]) => {
      result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
    });
    return result;
  };
  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    if (!templateId || templateId === "none") {
      setTitle("");
      setMessage("");
      setTemplateVariables({});
      return;
    }
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setTitle(template.title);
      setMessage(template.content);

      // Extract variables and initialize empty values
      const variables = extractVariables(template.content);
      const initialVariables: Record<string, string> = {};
      variables.forEach(v => {
        initialVariables[v] = "";
      });
      setTemplateVariables(initialVariables);
    }
  };
  const handleVariableChange = (variableName: string, value: string) => {
    const newVariables = {
      ...templateVariables,
      [variableName]: value
    };
    setTemplateVariables(newVariables);

    // Update message with replaced variables
    const template = templates.find(t => t.id === selectedTemplate);
    if (template) {
      setMessage(replaceVariables(template.content, newVariables));
    }
  };
  const handleSendMessages = async () => {
    if (!title.trim() || !message.trim()) {
      toast.error("Judul dan pesan harus diisi");
      return;
    }
    if (!sendToAll && recipientType === "customers" && selectedCustomers.length === 0) {
      toast.error("Pilih minimal satu nasabah");
      return;
    }
    if (!sendToAll && recipientType === "members" && selectedMembers.length === 0) {
      toast.error("Pilih minimal satu anggota");
      return;
    }
    setSending(true);
    try {
      // Check WhatsApp settings
      const {
        data: whatsappSettings
      } = await supabase.from("whatsapp_settings").select("is_enabled, broadcast_delay_seconds").maybeSingle();
      const whatsappEnabled = whatsappSettings?.is_enabled || false;
      const broadcastDelay = (whatsappSettings?.broadcast_delay_seconds || 1) * 1000; // Convert to milliseconds

      if (recipientType === "customers") {
        const targetCustomers = sendToAll ? customers.map(c => c.id) : selectedCustomers;
        const messages = targetCustomers.map(customerId => ({
          customer_id: customerId,
          title: title.trim(),
          message: message.trim(),
          type: messageType,
          is_read: false,
          created_at: new Date().toISOString()
        }));
        const {
          error
        } = await supabase.from("customer_messages").insert(messages);
        if (error) throw error;

        // Send via WhatsApp if enabled
        if (whatsappEnabled) {
          let whatsappSent = 0;
          const fullCustomers = sendToAll ? customers : customers.filter(c => selectedCustomers.includes(c.id));
          for (const customer of fullCustomers) {
            const {
              data: customerData
            } = await supabase.from("customers").select("phone").eq("id", customer.id).maybeSingle();
            if (customerData?.phone) {
              const whatsappMessage = `📢 *${title.trim()}*\n\n${message.trim()}`;
              try {
                await supabase.functions.invoke('send-whatsapp-message', {
                  body: {
                    phone_number: customerData.phone,
                    message: whatsappMessage
                  }
                });
                whatsappSent++;
                // Delay to avoid rate limiting (configurable)
                await new Promise(resolve => setTimeout(resolve, broadcastDelay));
              } catch (whatsappError) {
                console.error(`Failed to send WhatsApp to ${customer.id}:`, whatsappError);
              }
            }
          }
          toast.success(`Berhasil mengirim pesan ke ${targetCustomers.length} nasabah (${whatsappSent} via WhatsApp)`);
        } else {
          toast.success(`Berhasil mengirim pesan ke ${targetCustomers.length} nasabah`);
        }
      } else {
        const targetMembers = sendToAll ? members.map(m => m.id) : selectedMembers;
        const messages = targetMembers.map(memberId => ({
          member_id: memberId,
          title: title.trim(),
          message: message.trim(),
          type: messageType,
          is_read: false,
          created_at: new Date().toISOString()
        }));
        const {
          error
        } = await supabase.from("member_messages").insert(messages);
        if (error) throw error;

        // Send via WhatsApp if enabled
        if (whatsappEnabled) {
          let whatsappSent = 0;
          const fullMembers = sendToAll ? members : members.filter(m => selectedMembers.includes(m.id));
          for (const member of fullMembers) {
            const {
              data: memberData
            } = await supabase.from("members").select("phone").eq("id", member.id).maybeSingle();
            if (memberData?.phone) {
              const whatsappMessage = `📢 *${title.trim()}*\n\n${message.trim()}`;
              try {
                await supabase.functions.invoke('send-whatsapp-message', {
                  body: {
                    phone_number: memberData.phone,
                    message: whatsappMessage
                  }
                });
                whatsappSent++;
                // Delay to avoid rate limiting (configurable)
                await new Promise(resolve => setTimeout(resolve, broadcastDelay));
              } catch (whatsappError) {
                console.error(`Failed to send WhatsApp to ${member.id}:`, whatsappError);
              }
            }
          }
          toast.success(`Berhasil mengirim pesan ke ${targetMembers.length} anggota (${whatsappSent} via WhatsApp)`);
        } else {
          toast.success(`Berhasil mengirim pesan ke ${targetMembers.length} anggota`);
        }
      }

      // Reset form
      setTitle("");
      setMessage("");
      setMessageType("info");
      setSendToAll(true);
      setSelectedCustomers([]);
      setSelectedMembers([]);
      setSelectedTemplate("");
      setTemplateVariables({});
    } catch (error) {
      console.error("Error sending messages:", error);
      toast.error("Gagal mengirim pesan");
    } finally {
      setSending(false);
    }
  };
  const toggleCustomerSelection = (customerId: string) => {
    setSelectedCustomers(prev => prev.includes(customerId) ? prev.filter(id => id !== customerId) : [...prev, customerId]);
  };
  const toggleMemberSelection = (memberId: string) => {
    setSelectedMembers(prev => prev.includes(memberId) ? prev.filter(id => id !== memberId) : [...prev, memberId]);
  };
  const selectAllCustomers = () => {
    setSelectedCustomers(customers.map(c => c.id));
  };
  const deselectAllCustomers = () => {
    setSelectedCustomers([]);
  };
  const selectAllMembers = () => {
    setSelectedMembers(members.map(m => m.id));
  };
  const deselectAllMembers = () => {
    setSelectedMembers([]);
  };

  const handleMaintenanceModeToggle = async (enabled: boolean) => {
    setUpdatingMaintenance(true);
    try {
      // Get the settings ID first
      const { data: settingsData } = await supabase
        .from("app_settings")
        .select("id")
        .maybeSingle();

      if (!settingsData) {
        throw new Error("Settings not found");
      }

      const { error } = await supabase
        .from("app_settings")
        .update({
          maintenance_mode_enabled: enabled,
          maintenance_message: maintenanceMessage,
          maintenance_title: maintenanceTitle,
          updated_at: new Date().toISOString()
        })
        .eq("id", settingsData.id);

      if (error) throw error;

      setMaintenanceMode(enabled);
      toast.success(enabled ? "Mode maintenance diaktifkan" : "Mode maintenance dinonaktifkan");
    } catch (error) {
      console.error("Error updating maintenance mode:", error);
      toast.error("Gagal mengubah mode maintenance");
      // Revert the toggle state
      setMaintenanceMode(!enabled);
    } finally {
      setUpdatingMaintenance(false);
    }
  };

  const handleUpdateMaintenanceMessage = async () => {
    setUpdatingMaintenance(true);
    try {
      // Get the settings ID first
      const { data: settingsData } = await supabase
        .from("app_settings")
        .select("id")
        .maybeSingle();

      if (!settingsData) {
        throw new Error("Settings not found");
      }

      const { error } = await supabase
        .from("app_settings")
        .update({
          maintenance_message: maintenanceMessage,
          maintenance_title: maintenanceTitle,
          updated_at: new Date().toISOString()
        })
        .eq("id", settingsData.id);

      if (error) throw error;

      toast.success("Pesan maintenance berhasil diperbarui");
    } catch (error) {
      console.error("Error updating maintenance message:", error);
      toast.error("Gagal memperbarui pesan maintenance");
    } finally {
      setUpdatingMaintenance(false);
    }
  };
  if (roleLoading) {
    return <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>;
  }
  if (!isOwner && !isAdmin) {
    return null;
  }
  return <div className="overflow-hidden">
      <div className="flex items-center gap-3 mb-6">
        <Radio className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
        <div>
          <h1 className="text-2xl font-semibold">Broadcast Pesan</h1>
        </div>
      </div>

      <Tabs defaultValue="messages" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="messages" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            Kirim Pesan
          </TabsTrigger>
          <TabsTrigger value="maintenance" className="flex items-center gap-2">
            <Power className="h-4 w-4" />
            Mode Maintenance
          </TabsTrigger>
        </TabsList>

        {/* Tab Content: Kirim Pesan */}
        <TabsContent value="messages">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Form Section */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Buat Pesan Baru
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="template">Gunakan Template (Opsional)</Label>
                    <Select value={selectedTemplate || "none"} onValueChange={handleTemplateSelect}>
                      <SelectTrigger id="template">
                        <SelectValue placeholder="Pilih template atau buat pesan manual" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Tanpa Template (Manual)</SelectItem>
                        {templates.map(template => <SelectItem key={template.id} value={template.id}>
                            {template.name} - {template.category}
                          </SelectItem>)}
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">
                      Pilih template yang sudah dibuat atau buat pesan manual
                    </p>
                  </div>

                  {selectedTemplate && selectedTemplate !== "none" && Object.keys(templateVariables).length > 0 && <div className="space-y-3 p-4 bg-muted rounded-lg">
                      <Label className="text-base">Isi Variabel Template</Label>
                      {Object.keys(templateVariables).map(variable => <div key={variable} className="space-y-2">
                          <Label htmlFor={`var-${variable}`} className="text-sm">
                            {variable.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </Label>
                          <Input id={`var-${variable}`} value={templateVariables[variable]} onChange={e => handleVariableChange(variable, e.target.value)} placeholder={`Masukkan ${variable}`} />
                        </div>)}
                    </div>}

                  <div className="space-y-2">
                    <Label htmlFor="title">Judul Pesan *</Label>
                    <Input id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="Contoh: Pengumuman Hari Libur" maxLength={100} disabled={!!selectedTemplate && selectedTemplate !== "none"} />
                    {selectedTemplate && selectedTemplate !== "none" && <p className="text-xs text-muted-foreground">
                        Judul diambil dari template
                      </p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type">Tipe Pesan</Label>
                    <Select value={messageType} onValueChange={(value: any) => setMessageType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="info">
                          <div className="flex items-center gap-2">
                            <Info className="h-4 w-4 text-blue-500" />
                            <span>Informasi</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="announcement">
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span>Pengumuman</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="reminder">
                          <div className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-orange-500" />
                            <span>Pengingat</span>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Isi Pesan *</Label>
                    <Textarea id="message" value={message} onChange={e => (!selectedTemplate || selectedTemplate === "none") && setMessage(e.target.value)} placeholder="Tulis pesan yang akan dikirim ke nasabah..." rows={8} maxLength={500} disabled={!!selectedTemplate && selectedTemplate !== "none" && Object.keys(templateVariables).length > 0} className={selectedTemplate && selectedTemplate !== "none" ? "bg-muted" : ""} />
                    <p className="text-xs text-muted-foreground">
                      {message.length}/500 karakter
                      {selectedTemplate && selectedTemplate !== "none" && " (Preview dengan variabel terisi)"}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="recipientType">Kirim Ke</Label>
                    <Select value={recipientType} onValueChange={(value: any) => {
                    setRecipientType(value);
                    setSendToAll(true);
                    setSelectedCustomers([]);
                    setSelectedMembers([]);
                  }}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="customers">Nasabah</SelectItem>
                        <SelectItem value="members">Anggota/Staf</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2 pt-2">
                    <Checkbox id="sendToAll" checked={sendToAll} onCheckedChange={checked => setSendToAll(checked as boolean)} />
                    <Label htmlFor="sendToAll" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer">
                      Kirim ke semua {recipientType === "customers" ? "nasabah" : "anggota"}
                    </Label>
                  </div>

                  <Button onClick={handleSendMessages} disabled={sending} className="w-full" size="lg">
                    <Send className="mr-2 h-5 w-5" />
                    {sending ? "Mengirim..." : "Kirim Pesan"}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recipient Selection Section */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      <span>Penerima</span>
                    </div>
                    {!sendToAll && <span className="text-sm font-normal text-muted-foreground">
                        {recipientType === "customers" ? `${selectedCustomers.length} dipilih` : `${selectedMembers.length} dipilih`}
                      </span>}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {sendToAll ? <div className="text-center py-8">
                      <Users className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                      <p className="text-sm text-muted-foreground">
                        Pesan akan dikirim ke semua {recipientType === "customers" ? `${customers.length} nasabah` : `${members.length} anggota`}
                      </p>
                    </div> : <div className="space-y-3">
                      <div className="flex gap-2 pb-2">
                        <Button variant="outline" size="sm" onClick={recipientType === "customers" ? selectAllCustomers : selectAllMembers} className="flex-1">
                          Pilih Semua
                        </Button>
                        <Button variant="outline" size="sm" onClick={recipientType === "customers" ? deselectAllCustomers : deselectAllMembers} className="flex-1">
                          Batal Semua
                        </Button>
                      </div>
                      
                      <div className="max-h-96 overflow-y-auto space-y-2 border rounded-md p-3">
                        {recipientType === "customers" ? customers.map(customer => <div key={customer.id} className="flex items-center space-x-2 p-2 rounded hover:bg-muted cursor-pointer" onClick={() => toggleCustomerSelection(customer.id)}>
                              <Checkbox checked={selectedCustomers.includes(customer.id)} onCheckedChange={() => toggleCustomerSelection(customer.id)} />
                              <div className="flex-1">
                                <p className="text-sm font-medium">{customer.full_name}</p>
                                <p className="text-xs text-muted-foreground">{customer.id_number}</p>
                              </div>
                            </div>) : members.map(member => <div key={member.id} className="flex items-center space-x-2 p-2 rounded hover:bg-muted cursor-pointer" onClick={() => toggleMemberSelection(member.id)}>
                              <Checkbox checked={selectedMembers.includes(member.id)} onCheckedChange={() => toggleMemberSelection(member.id)} />
                              <div className="flex-1">
                                <p className="text-sm font-medium">{member.full_name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {member.position} {member.member_number && `• ${member.member_number}`}
                                </p>
                              </div>
                            </div>)}
                      </div>
                    </div>}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Tab Content: Mode Maintenance */}
        <TabsContent value="maintenance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Power className="h-5 w-5" />
                Mode Maintenance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="maintenance-toggle" className="text-base font-medium">
                    Aktifkan Mode Maintenance
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Tampilkan banner pemberitahuan maintenance pada semua halaman
                  </p>
                </div>
                <Switch
                  id="maintenance-toggle"
                  checked={maintenanceMode}
                  onCheckedChange={handleMaintenanceModeToggle}
                  disabled={updatingMaintenance}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-title">Judul Banner</Label>
                <Input
                  id="maintenance-title"
                  value={maintenanceTitle}
                  onChange={(e) => setMaintenanceTitle(e.target.value)}
                  placeholder="Mode Maintenance"
                  maxLength={100}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-message">Pesan Maintenance</Label>
                <Textarea
                  id="maintenance-message"
                  value={maintenanceMessage}
                  onChange={(e) => setMaintenanceMessage(e.target.value)}
                  placeholder="Sistem sedang dalam maintenance..."
                  rows={3}
                  maxLength={300}
                />
                <p className="text-xs text-muted-foreground">
                  {maintenanceMessage.length}/300 karakter
                </p>
              </div>

              <Button
                onClick={handleUpdateMaintenanceMessage}
                disabled={updatingMaintenance || !maintenanceTitle.trim() || !maintenanceMessage.trim()}
                size="sm"
                variant="outline"
              >
                {updatingMaintenance ? "Menyimpan..." : "Simpan Pesan"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>;
}