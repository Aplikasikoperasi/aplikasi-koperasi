import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatRupiah } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Calendar, DollarSign, User, Clock, Search, Phone, MapPin } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { id } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useDebounce } from "@/hooks/use-debounce";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
interface NPLApplicationData {
  id: string;
  application_number: string;
  application_date: string;
  customer_name: string;
  customer_id_number: string;
  customer_phone: string;
  customer_address: string;
  customer_id: string;
  member_name: string;
  amount_approved: number;
  tenor_months: number;
  status: string;
  overdueCount: number;
  totalOverdueAmount: number;
  totalPenalty: number;
  oldestOverdueDays: number;
  disbursed_at: string | null;
  overdueInstallments: Array<{
    installment_number: number;
    due_date: string;
    total_amount: number;
    paid_amount: number;
    days_overdue: number;
    penalty: number;
  }>;
}
export default function NPLCustomers() {
  const [nplData, setNplData] = useState<NPLApplicationData[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const debouncedSearch = useDebounce(searchQuery, 300);
  const itemsPerPage = 15;
  const fetchNPLApplications = async () => {
    try {
      const {
        data: applications,
        error
      } = await supabase.from('credit_applications').select(`
          id,
          application_number,
          application_date,
          amount_approved,
          tenor_months,
          status,
          disbursed_at,
          customer_id,
          customers (
            id,
            full_name,
            id_number,
            phone,
            address
          ),
          members (
            full_name
          ),
          installments!application_id (
            id,
            installment_number,
            status,
            due_date,
            total_amount,
            paid_amount,
            penalty_rate_per_day
          )
        `).in('status', ['approved', 'disbursed', 'overdue', 'unpaid', 'partial']);
      if (!error && applications) {
        const today = new Date();

        // Filter applications that have overdue installments (NPL)
        const nplApplications = applications.map(app => {
          const overdueInstallments = app.installments?.filter(i => i.status === 'overdue') || [];
          if (overdueInstallments.length === 0) return null;
          const totalOverdueAmount = overdueInstallments.reduce((sum, i) => sum + (i.total_amount - (i.paid_amount || 0)), 0);
          const overdueDays = overdueInstallments.map(i => differenceInDays(today, new Date(i.due_date)));
          const oldestOverdueDays = Math.max(...overdueDays);

          // Calculate penalty for each overdue installment
          const overdueDetails = overdueInstallments.map(installment => {
            const daysOverdue = differenceInDays(today, new Date(installment.due_date));
            const penaltyRate = installment.penalty_rate_per_day || 2.0;
            const unpaidAmount = installment.total_amount - (installment.paid_amount || 0);
            const penalty = unpaidAmount * (penaltyRate / 100) * daysOverdue;
            return {
              installment_number: installment.installment_number,
              due_date: installment.due_date,
              total_amount: installment.total_amount,
              paid_amount: installment.paid_amount || 0,
              days_overdue: daysOverdue,
              penalty
            };
          });
          const totalPenalty = overdueDetails.reduce((sum, i) => sum + i.penalty, 0);
          return {
            id: app.id,
            application_number: app.application_number,
            application_date: app.application_date,
            customer_name: app.customers?.full_name || '-',
            customer_id_number: app.customers?.id_number || '-',
            customer_phone: app.customers?.phone || '-',
            customer_address: app.customers?.address || '-',
            customer_id: app.customer_id,
            member_name: app.members?.full_name || '-',
            amount_approved: app.amount_approved || 0,
            tenor_months: app.tenor_months,
            status: app.status,
            overdueCount: overdueInstallments.length,
            totalOverdueAmount,
            totalPenalty,
            oldestOverdueDays,
            disbursed_at: app.disbursed_at,
            overdueInstallments: overdueDetails
          };
        }).filter((app): app is NPLApplicationData => app !== null).sort((a, b) => b.oldestOverdueDays - a.oldestOverdueDays);
        setNplData(nplApplications);
      }
    } catch (error) {
      console.error('Error fetching NPL applications:', error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    document.title = "Nasabah NPL | Kredit Bermasalah";
    fetchNPLApplications();
    const channel = supabase.channel('npl-customers-realtime').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => {
      fetchNPLApplications();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'installments'
    }, () => {
      fetchNPLApplications();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const getSeverityBadge = (days: number) => {
    if (days >= 90) return <Badge variant="destructive">Sangat Kritis</Badge>;
    if (days >= 60) return <Badge variant="destructive">Kritis</Badge>;
    if (days >= 30) return <Badge className="bg-orange-600">Perhatian</Badge>;
    return <Badge className="bg-yellow-600">Baru</Badge>;
  };
  const toggleCard = (appId: string) => {
    setExpandedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(appId)) {
        newSet.delete(appId);
      } else {
        newSet.add(appId);
      }
      return newSet;
    });
  };

  // Filter by search
  const filteredData = nplData.filter(app => {
    if (!debouncedSearch) return true;
    const search = debouncedSearch.toLowerCase();
    return app.application_number.toLowerCase().includes(search) || app.customer_name.toLowerCase().includes(search) || app.customer_id_number.toLowerCase().includes(search) || app.customer_phone.includes(search) || app.customer_address.toLowerCase().includes(search);
  });

  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentData = filteredData.slice(startIndex, endIndex);
  const goToPage = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Calculate total statistics
  const totalNPL = filteredData.length;
  const totalOverdueAmount = filteredData.reduce((sum, app) => sum + app.totalOverdueAmount, 0);
  const totalPenaltyAmount = filteredData.reduce((sum, app) => sum + app.totalPenalty, 0);
  if (loading) {
    return <div className="w-full p-4 md:p-6">
        <div className="flex items-center gap-3 mb-6">
          <AlertTriangle className="h-8 w-8 text-red-600" />
          <h1 className="text-3xl font-bold text-red-900">Nasabah NPL</h1>
        </div>
        <p className="text-muted-foreground">Memuat data...</p>
      </div>;
  }
  return <div className="w-full p-4 md:p-6">
      <header className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <AlertTriangle className="h-8 w-8 text-red-600" />
          <h1 className="font-bold text-red-900 text-2xl">Kredit Bermasalah (NPL)</h1>
        </div>
        <p className="text-muted-foreground mb-4">
          Kredit Bermasalah (Non-Performing Loan) • Total: {totalNPL} aplikasi
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950">
            <p className="text-xs text-muted-foreground mb-1">Total Tunggakan Angsuran</p>
            <p className="text-xl font-bold text-red-900 dark:text-red-300">
              {formatRupiah(totalOverdueAmount)}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-orange-50 dark:bg-orange-950">
            <p className="text-xs text-muted-foreground mb-1">Total Denda</p>
            <p className="text-xl font-bold text-orange-900 dark:text-orange-300">
              {formatRupiah(totalPenaltyAmount)}
            </p>
          </div>
        </div>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input type="text" placeholder="Cari berdasarkan nama, telepon, NIK, atau alamat..." value={searchQuery} onChange={e => {
          setSearchQuery(e.target.value);
          setCurrentPage(1);
        }} className="pl-10" />
        </div>

        {totalPages > 1 && <p className="text-sm text-muted-foreground mt-4">
            Halaman {currentPage} dari {totalPages} • Menampilkan {startIndex + 1}-
            {Math.min(endIndex, filteredData.length)} dari {filteredData.length} aplikasi
          </p>}
      </header>

      <div className="space-y-4">
        {currentData.map(app => {
        const isExpanded = expandedCards.has(app.id);
        return <Card key={app.id} className="border-red-200 shadow-lg overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-950 dark:to-orange-950 p-4 md:p-6">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      {getSeverityBadge(app.oldestOverdueDays)}
                      <CardTitle className="text-xl md:text-2xl break-words">
                        {app.customer_name}
                      </CardTitle>
                    </div>
                    <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <span className="font-bold break-all">{app.customer_id_number}</span>
                      </div>
                      <div className="flex items-center gap-1 break-all">
                        <Phone className="h-4 w-4 flex-shrink-0" />
                        <span className="break-all">{app.customer_phone}</span>
                      </div>
                      <div className="flex items-start gap-1">
                        <MapPin className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <span className="break-words">{app.customer_address}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="h-4 w-4 flex-shrink-0" />
                        <span className="break-all">
                          <span className="text-xs text-muted-foreground">PJ Kredit:</span>{' '}
                          <span className="font-medium">{app.member_name}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-4 md:p-6">
                <div className="mb-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950">
                      <div className="text-xs text-muted-foreground mb-1">Total Tunggakan</div>
                      <div className="text-lg font-bold text-red-900 dark:text-red-300 break-all">
                        {formatRupiah(app.totalOverdueAmount)}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 dark:bg-orange-950">
                      <div className="text-xs text-muted-foreground mb-1">Total Denda</div>
                      <div className="text-lg font-bold text-orange-900 dark:text-orange-300 break-all">
                        {formatRupiah(app.totalPenalty)}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-900">
                      <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Hari Tertunggak
                      </div>
                      <div className="text-lg font-bold text-gray-900 dark:text-gray-300">
                        {app.oldestOverdueDays} hari
                      </div>
                    </div>
                  </div>
                </div>

                <Collapsible open={isExpanded} onOpenChange={() => toggleCard(app.id)}>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full flex items-center justify-between">
                      <span className="font-semibold">
                        Detail Kredit & Angsuran Menunggak ({app.overdueCount})
                      </span>
                      {isExpanded ? <Clock className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>

                  <CollapsibleContent className="mt-3 space-y-3">
                    {/* Credit Info */}
                    <div className="p-3 rounded-lg border border-border bg-accent/50">
                      <h4 className="font-semibold mb-2">Informasi Kredit</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">No. Aplikasi</span>
                          <span className="font-medium break-all">{app.application_number}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Nilai Disetujui</span>
                          <span className="font-semibold break-all">
                            {formatRupiah(app.amount_approved)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Tenor</span>
                          <span className="font-medium">{app.tenor_months} bulan</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Tanggal Pengajuan
                          </span>
                          <span className="font-medium">
                            {format(new Date(app.application_date), 'dd MMM yyyy', {
                          locale: id
                        })}
                          </span>
                        </div>
                        {app.disbursed_at && <div className="flex justify-between">
                            <span className="text-muted-foreground flex items-center gap-1">
                              <DollarSign className="h-3 w-3" />
                              Dicairkan
                            </span>
                            <span className="font-medium">
                              {format(new Date(app.disbursed_at), 'dd MMM yyyy', {
                          locale: id
                        })}
                            </span>
                          </div>}
                      </div>
                    </div>

                    {/* Overdue Installments */}
                    <div>
                      <h4 className="font-semibold mb-2">Angsuran yang Menunggak</h4>
                      <div className="space-y-2">
                        {app.overdueInstallments.map(inst => <div key={inst.installment_number} className="p-3 rounded-lg border border-red-200 bg-red-50 dark:bg-red-950">
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-semibold text-sm">
                                Angsuran ke-{inst.installment_number}
                              </span>
                              <Badge variant="destructive" className="text-xs">
                                {inst.days_overdue} hari
                              </Badge>
                            </div>
                            <div className="space-y-1 text-xs">
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Jatuh Tempo</span>
                                <span className="font-medium">
                                  {format(new Date(inst.due_date), 'dd MMM yyyy', {
                              locale: id
                            })}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Total Angsuran</span>
                                <span className="font-semibold break-all">
                                  {formatRupiah(inst.total_amount)}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Sudah Dibayar</span>
                                <span className="font-medium break-all">
                                  {formatRupiah(inst.paid_amount)}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Sisa Tunggakan</span>
                                <span className="font-bold text-red-700 dark:text-red-400 break-all">
                                  {formatRupiah(inst.total_amount - inst.paid_amount)}
                                </span>
                              </div>
                              <div className="flex justify-between pt-1 border-t border-red-200">
                                <span className="text-muted-foreground">Denda</span>
                                <span className="font-bold text-orange-700 dark:text-orange-400 break-all">
                                  {formatRupiah(inst.penalty)}
                                </span>
                              </div>
                            </div>
                          </div>)}
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </CardContent>
            </Card>;
      })}
      </div>

      {currentData.length === 0 && <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">
            {searchQuery ? 'Tidak ada hasil yang cocok dengan pencarian' : 'Tidak ada kredit bermasalah (NPL)'}
          </p>
        </div>}

      {/* Pagination Controls */}
      {totalPages > 1 && <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground">
            Menampilkan {startIndex + 1}-{Math.min(endIndex, filteredData.length)} dari{' '}
            {filteredData.length} aplikasi
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-center">
            <Button variant="outline" size="sm" onClick={() => goToPage(1)} disabled={currentPage === 1}>
              Pertama
            </Button>
            <Button variant="outline" size="sm" onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1}>
              Sebelumnya
            </Button>

            {/* Page numbers */}
            <div className="flex items-center gap-1">
              {Array.from({
            length: Math.min(5, totalPages)
          }, (_, i) => {
            let pageNum;
            if (totalPages <= 5) {
              pageNum = i + 1;
            } else if (currentPage <= 3) {
              pageNum = i + 1;
            } else if (currentPage >= totalPages - 2) {
              pageNum = totalPages - 4 + i;
            } else {
              pageNum = currentPage - 2 + i;
            }
            return <Button key={pageNum} variant={currentPage === pageNum ? 'default' : 'outline'} size="sm" onClick={() => goToPage(pageNum)} className="min-w-[40px]">
                    {pageNum}
                  </Button>;
          })}
            </div>

            <Button variant="outline" size="sm" onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages}>
              Selanjutnya
            </Button>
            <Button variant="outline" size="sm" onClick={() => goToPage(totalPages)} disabled={currentPage === totalPages}>
              Terakhir
            </Button>
          </div>
        </div>}
    </div>;
}