import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Building2, Mail, MessageCircle, Calculator, LogIn } from "lucide-react";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { BannerSlideshow } from "@/components/BannerSlideshow";

const Index = () => {
  const navigate = useNavigate();
  const {
    businessName,
    businessDescription,
    businessPhone,
    businessEmail,
    logoUrl,
    loading
  } = useBusinessInfo();
  const whatsappPhone = businessPhone ? businessPhone.replace(/[^0-9]/g, "").replace(/^0/, "62") : "";
  const getWhatsAppDeepLink = () => {
    const ua = navigator.userAgent || "";
    const isAndroid = /android/i.test(ua);
    const message = encodeURIComponent(`Halo ${businessName || 'Admin'}, saya ingin bertanya tentang layanan kredit.`);
    if (isAndroid) {
      return `intent://send?phone=${whatsappPhone}&text=${message}#Intent;scheme=whatsapp;package=com.whatsapp;end`;
    }
    return `whatsapp://send?phone=${whatsappPhone}&text=${message}`;
  };
  const openWhatsApp = () => {
    if (!whatsappPhone) return;
    window.location.href = getWhatsAppDeepLink();
  };
  return <div className="h-screen flex flex-col bg-gradient-to-br from-primary/10 via-background to-accent/10 relative overflow-hidden">
      {/* Animated gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-background opacity-50 animate-gradient" style={{
      backgroundSize: '400% 400%'
    }} />

      {/* Header - Compact */}
      <header className="relative z-20 bg-background/80 backdrop-blur-md border-b border-border/50 shrink-0">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-center">
            <div className="flex items-center gap-4">
              {logoUrl ? <div className="flex-shrink-0 w-14 h-14 md:w-16 md:h-16 rounded-xl overflow-hidden animate-logo-container">
                  <img key={logoUrl} src={logoUrl} alt={businessName} className="w-full h-full object-cover animate-logo" />
                </div> : <div className="flex-shrink-0 w-14 h-14 md:w-16 md:h-16 bg-primary rounded-xl animate-scale-in flex items-center justify-center">
                  <Building2 className="w-7 h-7 md:w-8 md:h-8 text-primary-foreground" />
                </div>}
              <div className="flex flex-col">
                <h1 className="font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent text-xl md:text-2xl font-mono leading-tight">
                  {loading ? "Memuat..." : businessName}
                </h1>
                <p className="text-muted-foreground font-mono font-light text-sm leading-tight">
                  {loading ? "Memuat deskripsi..." : businessDescription}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main Content - Takes remaining space */}
      <main className="flex-1 flex flex-col relative z-10 overflow-hidden">
        {/* Login button row */}
        <div className="w-full flex justify-end px-4 py-2 shrink-0">
          <Button onClick={() => navigate("/auth")} size="sm" className="bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] transition-all duration-500 shadow-md hover:shadow-lg border-2 border-primary px-5 gap-2 font-semibold rounded-xl">
            <LogIn className="h-4 w-4" />
            Masuk
          </Button>
        </div>
        
        <div className="container mx-auto px-4 py-1 flex flex-col flex-1 max-w-4xl">
          
          {/* Banner Slideshow - Flexible height */}
          <div className="flex-1 flex flex-col items-center justify-start min-h-0 mt-14">
            <BannerSlideshow />
            
            {/* Buttons below banner */}
            <div className="flex flex-col items-center gap-3 py-3 mt-12">
              <Button onClick={() => navigate("/simulasi-kredit")} variant="outline" size="default" className="text-base px-6 rounded-xl gap-2 border-2 border-primary shadow-lg hover:shadow-xl transition-all bg-gradient-to-r from-primary via-accent to-primary text-primary-foreground animate-shimmer animate-glow bg-[length:200%_100%]">
                <Calculator className="h-4 w-4" />
                Simulasi Angsuran
              </Button>
              
              {/* Contact buttons */}
              <div className="flex items-center gap-3">
                {businessPhone && (
                  <Button
                    variant="default"
                    size="lg"
                    onClick={openWhatsApp}
                    className="bg-[#25D366] hover:bg-[#20BD5A] text-white gap-2 rounded-xl border-2 border-[#25D366] shadow-md hover:shadow-lg transition-all"
                    aria-label={`Buka WhatsApp chat ke ${businessPhone}`}
                  >
                    <MessageCircle className="h-5 w-5" />
                    Ajukan Pinjaman
                  </Button>
                )}
                {businessEmail && (
                  <Button
                    variant="outline"
                    size="lg"
                    asChild
                    className="gap-2 rounded-xl border-2 border-primary shadow-md hover:shadow-lg transition-all"
                  >
                    <a href={`mailto:${businessEmail}`}>
                      <Mail className="h-5 w-5" />
                      Email
                    </a>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer - Compact */}
      <footer className="relative z-10 bg-background/50 border-t border-border/30 shrink-0">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-center text-xs">
            <span className="text-muted-foreground">
              © {new Date().getFullYear()} {businessName}
            </span>
          </div>
        </div>
      </footer>
    </div>;
};
export default Index;