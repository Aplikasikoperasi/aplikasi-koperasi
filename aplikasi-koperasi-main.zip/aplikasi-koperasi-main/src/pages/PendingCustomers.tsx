import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { usePendingCustomersQuery, useInvalidatePendingCustomers } from "@/hooks/usePendingCustomersQuery";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useUserRole } from "@/hooks/useUserRole";
import { CheckCircle, XCircle, Clock, User, UserCheck } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { calculateAge, formatDateWIB } from "@/lib/utils";
import { format } from "date-fns";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyCustomerDetailDialog as CustomerDetailDialog } from "@/components/LazyDialogs";

export default function PendingCustomers() {
  const [actionDialog, setActionDialog] = useState<{ open: boolean; customer: any; action: 'approve' | 'reject' | null }>({ open: false, customer: null, action: null });
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const { toast } = useToast();
  const { isOwner, isAdmin, loading: roleLoading } = useUserRole();
  const isMobile = useIsMobile();
  const { data: pendingCustomers = [], isLoading } = usePendingCustomersQuery();
  const invalidatePendingCustomers = useInvalidatePendingCustomers();

  useEffect(() => {
    if (roleLoading) return;

    if (!isOwner && !isAdmin) {
      toast({ 
        title: "Akses Ditolak", 
        description: "Hanya owner dan admin yang dapat mengakses halaman ini",
        variant: "destructive" 
      });
      return;
    }

    // Set up realtime subscription
    const channel = supabase
      .channel('pending-customers-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'customers'
      }, () => {
        console.log('🔄 Customer data changed, reloading pending customers...');
        invalidatePendingCustomers();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isOwner, isAdmin, roleLoading, invalidatePendingCustomers]);
  
  // Listen for pull-to-refresh
  useEffect(() => {
    const handleRefresh = () => invalidatePendingCustomers();
    window.addEventListener('page-refresh', handleRefresh);
    return () => window.removeEventListener('page-refresh', handleRefresh);
  }, [invalidatePendingCustomers]);

  const handleAction = async () => {
    if (!actionDialog.customer || !actionDialog.action) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (actionDialog.action === 'approve') {
        const { error } = await supabase
          .from("customers")
          .update({
            status: 'approved',
            approved_by: user?.id,
            approved_at: new Date().toISOString()
          })
          .eq("id", actionDialog.customer.id);

        if (error) throw error;

        await logSystemEvent({
          category: "customer_management",
          action: "Setujui Nasabah",
          description: `Menyetujui nasabah: ${actionDialog.customer.full_name}`,
          metadata: {
            customer_id: actionDialog.customer.id,
            customer_name: actionDialog.customer.full_name,
            id_number: actionDialog.customer.id_number
          }
        });

        toast({ title: "Nasabah berhasil disetujui" });
        // Force immediate reload
        invalidatePendingCustomers();
        window.dispatchEvent(new Event('customer-approved'));
      } else {
        const { error } = await supabase
          .from("customers")
          .update({
            status: 'rejected'
          })
          .eq("id", actionDialog.customer.id);

        if (error) throw error;

        await logSystemEvent({
          category: "customer_management",
          action: "Tolak Nasabah",
          description: `Menolak nasabah: ${actionDialog.customer.full_name}`,
          metadata: {
            customer_id: actionDialog.customer.id,
            customer_name: actionDialog.customer.full_name,
            id_number: actionDialog.customer.id_number
          }
        });

        toast({ title: "Nasabah ditolak" });
      }

      setActionDialog({ open: false, customer: null, action: null });
      // Force immediate reload
      invalidatePendingCustomers();
      window.dispatchEvent(new Event('customer-status-changed'));
    } catch (error: any) {
      toast({ 
        title: "Gagal memproses nasabah", 
        description: error.message,
        variant: "destructive" 
      });
    }
  };

  if (isLoading || roleLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Memuat...</h2>
          <p className="text-muted-foreground">Mohon tunggu, memeriksa hak akses Anda</p>
        </div>
      </div>
    );
  }

  if (!isOwner && !isAdmin) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <XCircle className="h-16 w-16 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Akses Ditolak</h2>
          <p className="text-muted-foreground">Hanya owner dan admin yang dapat mengakses halaman ini</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-full space-y-6 overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full max-w-full overflow-hidden">
        <div className="w-full max-w-full overflow-hidden">
          <div className="flex items-center gap-3">
            <UserCheck className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
            <div>
              <h1 className="text-2xl font-semibold truncate max-w-full">Verifikasi Nasabah</h1>
              <p className="text-muted-foreground mt-1 text-sm sm:text-base">Nasabah yang didaftarkan sales menunggu persetujuan</p>
            </div>
          </div>
        </div>
        <Badge variant="secondary" className="text-base sm:text-lg px-3 sm:px-4 py-2 flex-shrink-0">
          <Clock className="h-4 w-4 mr-2" />
          {pendingCustomers.length} Pending
        </Badge>
      </div>

      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader>
          <CardTitle className="text-base sm:text-lg md:text-xl">Nasabah Menunggu Verifikasi</CardTitle>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          {isMobile ? (
            <div className="space-y-3 w-full max-w-full">
              {pendingCustomers.length === 0 ? (
                <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
                  <CheckCircle className="h-8 w-8" />
                  <p className="font-medium">Tidak ada nasabah pending</p>
                  <p className="text-sm">Semua nasabah sudah diverifikasi</p>
                </div>
              ) : (
                pendingCustomers.map((customer) => (
                  <MobileDataCard
                    key={customer.id}
                    id={customer.id_number}
                    photoUrl={customer.photo_url}
                    name={customer.full_name}
                    subtitle={customer.phone}
                    onClick={() => {
                      setSelectedCustomer(customer);
                      setShowDetail(true);
                    }}
                  />
                ))
              )}
            </div>
          ) : (
            <div className="w-full">
              <ScrollArea className="h-[calc(100vh-320px)] w-full">
                <div className="overflow-x-auto min-w-full">
                  <Table className="min-w-max">
              <TableHeader>
                <TableRow>
                  <TableHead>No. ID</TableHead>
                  <TableHead>Foto</TableHead>
                  <TableHead>Nama</TableHead>
                  <TableHead>NIK</TableHead>
                  <TableHead>Tanggal Lahir</TableHead>
                  <TableHead>Usia</TableHead>
                  <TableHead>Pekerjaan</TableHead>
                  <TableHead>Telepon</TableHead>
                  <TableHead>Alamat</TableHead>
                  <TableHead>Didaftarkan oleh</TableHead>
                  <TableHead>Tanggal Pendaftaran</TableHead>
                  <TableHead>Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingCustomers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="text-center py-8">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <CheckCircle className="h-8 w-8" />
                        <p className="font-medium">Tidak ada nasabah pending</p>
                        <p className="text-sm">Semua nasabah sudah diverifikasi</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  pendingCustomers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-bold">{customer.id_number}</TableCell>
                      <TableCell>
                        <ClickableAvatar 
                          src={customer.photo_url}
                          alt={customer.full_name}
                          fallback={customer.full_name?.charAt(0)}
                          className="w-10 h-10"
                        />
                      </TableCell>
                      <TableCell>{customer.full_name}</TableCell>
                      <TableCell>{customer.nik}</TableCell>
                      <TableCell>
                        {customer.date_of_birth ? (
                          formatDateWIB(customer.date_of_birth, 'long')
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {calculateAge(customer.date_of_birth) !== null 
                          ? `${calculateAge(customer.date_of_birth)} tahun` 
                          : "-"}
                      </TableCell>
                      <TableCell>{customer.occupation || "-"}</TableCell>
                      <TableCell>{customer.phone}</TableCell>
                      <TableCell className="max-w-xs truncate">{customer.address}</TableCell>
                      <TableCell>
                        {customer.creator ? (
                          <div className="text-sm">
                            <div className="font-medium">{customer.creator.full_name}</div>
                            <div className="text-muted-foreground">{customer.creator.position}</div>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {formatDateWIB(customer.created_at, 'long')}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="default"
                            onClick={() => setActionDialog({ open: true, customer, action: 'approve' })}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Setujui
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => setActionDialog({ open: true, customer, action: 'reject' })}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Tolak
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
                </div>
              </ScrollArea>
            </div>
          )}
        </CardContent>
      </Card>

      <CustomerDetailDialog
        open={showDetail}
        onOpenChange={setShowDetail}
        customer={selectedCustomer}
        onApprove={(customer) => setActionDialog({ open: true, customer, action: 'approve' })}
        onReject={(customer) => setActionDialog({ open: true, customer, action: 'reject' })}
      />

      <AlertDialog open={actionDialog.open} onOpenChange={(open) => !open && setActionDialog({ open: false, customer: null, action: null })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionDialog.action === 'approve' ? 'Setujui Nasabah' : 'Tolak Nasabah'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionDialog.action === 'approve' 
                ? `Apakah Anda yakin ingin menyetujui nasabah ${actionDialog.customer?.full_name}? Nasabah akan menjadi aktif dan dapat mengajukan kredit.`
                : `Apakah Anda yakin ingin menolak nasabah ${actionDialog.customer?.full_name}? Data akan dipindahkan ke status ditolak.`
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleAction}>
              {actionDialog.action === 'approve' ? 'Setujui' : 'Tolak'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
