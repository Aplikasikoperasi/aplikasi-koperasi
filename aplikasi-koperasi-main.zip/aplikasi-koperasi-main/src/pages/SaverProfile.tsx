import { useNavigate } from "react-router-dom";
import { useSaverAuth } from "@/contexts/SaverAuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TierBadge } from "@/components/SaverDetailDialog";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { User, Phone, MapPin, Calendar, CreditCard, Briefcase, Building2, X, IdCard, Mail } from "lucide-react";
import { formatDateWIB } from "@/lib/utils";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import SaverPinSettings from "@/components/SaverPinSettings";

export default function SaverProfile() {
  const navigate = useNavigate();
  const {
    saver,
    isAuthenticated
  } = useSaverAuth();
  const {
    businessName,
    logoUrl
  } = useBusinessInfo();
  const [saverDetails, setSaverDetails] = useState<{
    tier_level: string;
    pin_hash: string | null;
  } | null>(null);
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/auth");
    }
  }, [isAuthenticated, navigate]);
  useEffect(() => {
    if (saver?.id) {
      loadSaverDetails();
    }
  }, [saver?.id]);
  const loadSaverDetails = async () => {
    if (!saver?.id) return;
    const {
      data,
      error
    } = await supabase.from("savers").select("tier_level, pin_hash").eq("id", saver.id).single();
    if (!error && data) {
      setSaverDetails(data);
    }
  };
  if (!saver) {
    return null;
  }
  return <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b-2 border-primary/30 bg-card sticky top-0 z-10 shadow-lg pt-safe-top">
        <div className="container mx-auto px-4 min-h-[56px] flex items-center justify-between gap-2 relative">
          {/* Center - Business Logo & Name */}
          <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-2 sm:gap-3">
            {logoUrl ? <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-md overflow-hidden flex-shrink-0 animate-logo-container">
                <img key={logoUrl} src={logoUrl} alt={businessName || "Logo"} className="w-full h-full object-cover animate-logo" />
              </div> : <div className="w-8 h-8 sm:w-10 sm:h-10 bg-primary rounded-md flex items-center justify-center flex-shrink-0">
                <Building2 className="w-4 h-4 sm:w-5 sm:h-5 text-primary-foreground" />
              </div>}
            <span className="text-base sm:text-xl font-semibold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent truncate max-w-[160px] sm:max-w-none font-mono">
              {businessName || "Mitradana"}
            </span>
          </div>

          {/* Right - Close Button */}
          <Button variant="outline" size="sm" className="min-h-[44px] min-w-[44px] ml-auto" onClick={() => navigate("/saver-dashboard")}>
            <X className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Page Title */}
        

        {/* Profile Card - Photo Left, Info Right */}
        <Card className="animate-fade-in">
          <CardContent className="pt-6">
            <div className="flex flex-row gap-4 md:gap-6">
              {/* Left - Photo Only */}
              <div className="flex flex-col items-center flex-shrink-0 pt-4 sm:pt-6 md:pt-8">
                <div className="w-20 h-20 sm:w-24 sm:h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-primary/30 shadow-lg">
                  {saver.photo_url ? <img src={saver.photo_url} alt={saver.full_name} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-muted flex items-center justify-center">
                      <span className="text-2xl sm:text-3xl md:text-4xl font-bold text-muted-foreground">
                        {saver.full_name.charAt(0)}
                      </span>
                    </div>}
                </div>
              </div>

              {/* Right - All Info */}
              <div className="flex-1 space-y-6">
                {/* Personal Info Section */}
                <div>
                  
                  <div className="space-y-3">
                    {/* Name & Badge */}
                    <div className="flex items-center gap-3 mb-4 flex-wrap">
                      <h2 className="text-xl font-bold">{saver.full_name}</h2>
                      <TierBadge tier={saverDetails?.tier_level || "silver"} size="md" />
                    </div>
                    {/* Account Number */}
                    <div className="flex items-start gap-3">
                      <CreditCard className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-xs text-muted-foreground">No. Rekening</p>
                        <p className="font-semibold font-mono text-base">
                          {saver.account_number.length === 10 ? saver.account_number.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3') : saver.account_number.replace(/(\d{4})(?=\d)/g, '$1 ')}
                        </p>
                      </div>
                    </div>

                    {/* Phone */}
                    

                    {/* Email */}
                    {saver.email && <div className="flex items-start gap-3">
                        <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <div>
                          <p className="text-xs text-muted-foreground">Email</p>
                          <p className="font-semibold text-sm">{saver.email}</p>
                        </div>
                      </div>}


                    {/* Occupation */}
                    {saver.occupation}

                    {/* Address */}
                    <div className="flex items-start gap-3">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-xs text-muted-foreground">Alamat</p>
                        <p className="font-semibold text-sm">{saver.address}</p>
                      </div>
                    </div>
                  {/* Saver Number */}
                  

                  {/* Status */}
                  

                  {/* Created At */}
                  <div className="flex items-start gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Terdaftar Sejak</p>
                      <p className="font-semibold text-sm">{formatDateWIB(new Date(saver.created_at))}</p>
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PIN Settings */}
        <SaverPinSettings 
          saverId={saver.id} 
          hasPin={!!saverDetails?.pin_hash} 
          onPinUpdated={loadSaverDetails}
        />
      </main>
    </div>;
}