import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { useToast } from "@/hooks/use-toast";
import { Eye, CheckCircle, XCircle, Plus, Download, Search, Star, Trash2, Lock, Edit, MessageSquare, AlertTriangle, MoreVertical, Loader2, FileText, Printer } from "lucide-react";
import { generateBulkNamePlatePDF } from "@/lib/generateNamePlatePDF";

import { NamePlateSelectionDialog } from "@/components/NamePlateSelectionDialog";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { Progress } from "@/components/ui/progress";
import { SuccessCheckmark } from "@/components/ui/success-checkmark";
import { Label } from "@/components/ui/label";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { formatRupiah, formatDate, cn, getNowInWIB } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyApplicationDetailDialog as ApplicationDetailDialog } from "@/components/LazyDialogs";
import { AchievementBadge } from "@/components/AchievementBadge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle, ResponsiveDialogTrigger } from "@/components/ui/responsive-dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { DatePicker } from "@/components/ui/date-picker";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useUserRole } from "@/hooks/useUserRole";
import { generateAgreementWord } from "@/lib/generateAgreementWord";
import { generateAgreementWhatsAppMessage } from "@/lib/agreementTemplate";
import { LazyDisbursementReceiptDialog as DisbursementReceiptDialog } from "@/components/LazyDialogs";
import { generateDisbursementReceiptMessage, openWhatsAppChat } from "@/lib/whatsappHelper";
import { CurrencyInput } from "@/components/ui/currency-input";
import { LazyAgreementPreviewDialog as AgreementPreviewDialog } from "@/components/LazyDialogs";
import { sanitizeDateForDatabase } from "@/lib/utils";
import { useApplicationsQuery, useApplicationStats, useInvalidateApplications } from "@/hooks/useApplicationsQuery";
import { useDebounce } from "@/hooks/use-debounce";
import { useCustomersQuery } from "@/hooks/useCustomersQuery";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
import { getTodayInWIB } from "@/lib/utils";
import { UpdateNoKKDialog } from "@/components/UpdateNoKKDialog";

const formSchema = z.object({
  customer_id: z.string().min(1, "Nasabah harus dipilih"),
  member_id: z.string().min(1, "Anggota penanggung jawab harus dipilih"),
  amount_requested: z.string().min(1, "Jumlah pengajuan harus diisi"),
  tenor_months: z.string().min(1, "Tenor harus dipilih"),
  application_date: z.date({
    required_error: "Tanggal pengajuan harus dipilih"
  }).max(getTodayInWIB(), "Tanggal pengajuan tidak boleh lebih dari hari ini"),
  collateral_description: z.string().min(1, "Deskripsi jaminan wajib diisi")
});
const editFormSchema = z.object({
  customer_id: z.string().min(1, "Nasabah harus dipilih"),
  member_id: z.string().min(1, "Anggota penanggung jawab harus dipilih"),
  amount_requested: z.string().min(1, "Jumlah pengajuan harus diisi"),
  tenor_months: z.string().min(1, "Tenor harus dipilih"),
  application_date: z.date({
    required_error: "Tanggal pengajuan harus dipilih"
  }).max(getTodayInWIB(), "Tanggal pengajuan tidak boleh lebih dari hari ini"),
  collateral_description: z.string().min(1, "Deskripsi jaminan wajib diisi")
});
const disbursementFormSchema = z.object({
  disbursement_date: z.date({
    required_error: "Tanggal pencairan harus dipilih"
  })
});
export default function Applications() {
  const [eligibleCustomers, setEligibleCustomers] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string>("all");
  const [customerSearchOpen, setCustomerSearchOpen] = useState(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState("");
  const [memberSearchOpen, setMemberSearchOpen] = useState(false);
  const [memberSearchQuery, setMemberSearchQuery] = useState("");
  const [excludedCustomers, setExcludedCustomers] = useState<Map<string, {customer: any, reason: string}>>(new Map());
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 20;
  
  const {
    toast
  } = useToast();
  const {
    role,
    isOwner,
    isAdmin,
    isSales,
    isKasir
  } = useUserRole();

  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  
  // Use React Query hooks for data loading
  const { data: applicationsData, isLoading } = useApplicationsQuery({
    searchQuery: debouncedSearch,
    memberFilter: selectedMemberFilter,
    page: currentPage,
    itemsPerPage: ITEMS_PER_PAGE,
  });
  
  const { data: statsData } = useApplicationStats();
  const invalidateApplications = useInvalidateApplications();

  // Use shared customers query hook - load ALL eligible customers for credit application
  // All roles (Owner, Admin, Sales) should see all eligible customers when applying for credit
  const { data: customersData, isLoading: loadingCustomers } = useCustomersQuery({ 
    searchQuery: "",
    page: 1, 
    itemsPerPage: 1000, // Load all customers for filtering
    isSalesUser: false, // Don't filter by sales - all eligible customers visible for credit application
    currentMemberId: null
  });
  const allCustomersWithBadges = customersData?.customers || [];
  
  const applications = applicationsData?.applications || [];
  const totalCount = applicationsData?.totalCount || 0;
  const applicationStats = statsData || {
    pending: { count: 0, amount: 0 },
    unpaid: { count: 0, amount: 0 },
    paid: { count: 0, amount: 0 },
    rejected: { count: 0, amount: 0 },
    disbursed: { count: 0, amount: 0 },
    not_disbursed: { count: 0, amount: 0 },
  };
  
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [simulation, setSimulation] = useState<{
    monthlyInstallment: number;
    totalInterest: number;
    totalPayment: number;
    principalPerMonth: number;
    interestPerMonth: number;
    adminFee: number;
    firstInstallmentDeducted: boolean;
    netDisbursement: number;
    baseInterestRate?: number;
    discountApplied?: number;
    badgeLevel?: string | null;
    finalInterestRate?: number;
  } | null>(null);
  const [appSettings, setAppSettings] = useState<any>(null);
  const [interestRates, setInterestRates] = useState<Map<number, number>>(new Map());
  const [disbursementDialogOpen, setDisbursementDialogOpen] = useState(false);
  const [disbursementData, setDisbursementData] = useState<any>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [superCodeDialogOpen, setSuperCodeDialogOpen] = useState(false);
  const [superCodeInput, setSuperCodeInput] = useState("");
  const [superCodeError, setSuperCodeError] = useState("");
  const [selectedAppForAction, setSelectedAppForAction] = useState<any>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState<'edit' | 'delete' | null>(null);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  const [pendingApproval, setPendingApproval] = useState<{
    applicationId: string;
    amountRequested: number;
  } | null>(null);
  const [installments, setInstallments] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [progressMessage, setProgressMessage] = useState("");
  const [progressValue, setProgressValue] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  const [agreementPreviewOpen, setAgreementPreviewOpen] = useState(false);
  const [agreementPreviewData, setAgreementPreviewData] = useState<any>(null);
  const [currentAgreementApp, setCurrentAgreementApp] = useState<any>(null);
  const [isBulkPrinting, setIsBulkPrinting] = useState(false);
  const [namePlateDialogOpen, setNamePlateDialogOpen] = useState(false);
  const [namePlateApps, setNamePlateApps] = useState<any[]>([]);
  const [isLoadingNamePlates, setIsLoadingNamePlates] = useState(false);
  
  // State untuk dialog konfirmasi pernyataan
  const [confirmationDialogOpen, setConfirmationDialogOpen] = useState(false);
  const [pendingFormValues, setPendingFormValues] = useState<z.infer<typeof formSchema> | null>(null);
  
  // State untuk dialog update No. KK (untuk nasabah lama yang belum punya no_kk)
  const [updateNoKKDialogOpen, setUpdateNoKKDialogOpen] = useState(false);
  const [customerNeedingNoKK, setCustomerNeedingNoKK] = useState<{
    id: string;
    full_name: string;
    id_number: string;
  } | null>(null);


  // Business info for name plate
  const { businessName, logoUrl } = useBusinessInfo();

  // Real-time subscription for credit applications updates
  useEffect(() => {
    console.log("[Applications] Setting up realtime subscription...");
    
    const channel = supabase
      .channel('applications-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'credit_applications'
        },
        (payload) => {
          console.log('[Applications] Realtime update received:', payload);
          // Invalidate queries to refetch data
          invalidateApplications();
          toast({ 
            title: "Data Diperbarui", 
            description: "Data aplikasi kredit telah diperbarui secara real-time"
          });
        }
      )
      .subscribe((status) => {
        console.log('[Applications] Subscription status:', status);
      });

    return () => {
      console.log("[Applications] Cleaning up realtime subscription");
      supabase.removeChannel(channel);
    };
  }, [invalidateApplications, toast]);
  const isMobile = useIsMobile();
  const { viewMode, toggleView } = useViewPreference('applications');

  // Function to get interest rate from database settings
  const getInterestRate = async (tenor: number): Promise<number> => {
    // Use the new overloaded function with snapshot parameters
    const {
      data,
      error
    } = await supabase.rpc('get_interest_rate', {
      p_tenor_months: tenor,
      p_interest_type: appSettings?.interest_type || null,
      p_flat_rate: appSettings?.flat_interest_rate || null,
      p_custom_rates: appSettings?.custom_rates || null
    });
    if (error) {
      console.error('Error getting interest rate:', error);
      return 4.0; // fallback
    }
    return data || 4.0;
  };

  // Get interest rate from cache
  const getInterestRateSync = (tenor: number): number => {
    return interestRates.get(tenor) || 4.0;
  };
  
  const disbursementForm = useForm<z.infer<typeof disbursementFormSchema>>({
    resolver: zodResolver(disbursementFormSchema),
    defaultValues: {
      disbursement_date: new Date()
    }
  });
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customer_id: "",
      member_id: "",
      amount_requested: "",
      tenor_months: "",
      application_date: new Date(),
      collateral_description: ""
    }
  });
  const editForm = useForm<z.infer<typeof editFormSchema>>({
    resolver: zodResolver(editFormSchema),
    defaultValues: {
      customer_id: "",
      member_id: "",
      amount_requested: "",
      tenor_months: "",
      application_date: new Date(),
      collateral_description: ""
    }
  });

  // Calculate simulation whenever amount or tenor changes
  // This calculation is available for ALL ROLES (owner, admin, sales)
  useEffect(() => {
    const calculateSimulation = async () => {
      const amount = parseFloat(form.watch("amount_requested"));
      const tenor = parseInt(form.watch("tenor_months"));
      const customerId = form.watch("customer_id");
      
      if (amount > 0 && tenor > 0) {
        let baseInterestRate = await getInterestRate(tenor);
        let discountApplied = 0;
        let badgeLevel = null;
        
        // Check if badge discount is enabled and apply discount
        if (customerId && appSettings?.badge_discount_enabled) {
          const selectedCustomer = eligibleCustomers.find(c => c.id === customerId);
          const badge = selectedCustomer?.achievementBadge;
          if (badge && badge.badge_level) {
            const badgeName = badge.badge_name;
            
            if (badgeName === "Platinum Elite" && appSettings.platinum_discount > 0) {
              discountApplied = appSettings.platinum_discount;
              badgeLevel = "Platinum Elite";
            } else if (badgeName === "Diamond Premier" && appSettings.diamond_discount > 0) {
              discountApplied = appSettings.diamond_discount;
              badgeLevel = "Diamond Premier";
            } else if (badgeName === "Gold Member" && appSettings.gold_discount > 0) {
              discountApplied = appSettings.gold_discount;
              badgeLevel = "Gold Member";
            }
          }
        }
        
        const interestRate = baseInterestRate - discountApplied;
        
        // Flat rate calculation per month: (Pokok/Tenor) + (Pokok x Bunga)
        const principalPerMonth = amount / tenor;
        const interestPerMonth = amount * (interestRate / 100);
        const monthlyInstallmentRaw = principalPerMonth + interestPerMonth;

        // Round monthly installment to nearest 1000 (round up)
        const monthlyInstallment = Math.ceil(monthlyInstallmentRaw / 1000) * 1000;
        const totalPayment = monthlyInstallment * tenor;
        const totalInterest = interestPerMonth * tenor;

        // Calculate admin fee as percentage with minimum (using fallback values if appSettings not loaded)
        const adminFeeEnabled = appSettings?.admin_fee_enabled || false;
        const adminFeePercent = appSettings?.admin_fee_amount || 0;
        const adminFeeMinimum = appSettings?.admin_fee_minimum || 0;
        let adminFee = 0;
        if (adminFeeEnabled && adminFeePercent > 0) {
          const calculatedFee = Math.round(amount * (adminFeePercent / 100));
          adminFee = Math.max(calculatedFee, adminFeeMinimum);
        }

        // Check if first installment is paid upfront (default to next_month if not set)
        // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama, meskipun setting 'paid_upfront'
        const firstInstallmentType = appSettings?.first_installment_type || 'next_month';
        const firstInstallmentDeducted = tenor >= 4 && firstInstallmentType === 'paid_upfront';

        // Net disbursement (amount customer actually receives after deductions)
        let netDisbursement = amount - adminFee;
        if (firstInstallmentDeducted) {
          netDisbursement = netDisbursement - monthlyInstallment;
        }
        console.log('📊 Simulation calculated for role:', role, {
          amount,
          tenor,
          monthlyInstallment,
          adminFee,
          firstInstallmentDeducted,
          netDisbursement
        });
        setSimulation({
          monthlyInstallment,
          totalInterest,
          totalPayment,
          principalPerMonth,
          interestPerMonth,
          adminFee,
          firstInstallmentDeducted,
          netDisbursement,
          baseInterestRate,
          discountApplied,
          badgeLevel,
          finalInterestRate: interestRate
        });
      } else {
        setSimulation(null);
      }
    };
    calculateSimulation();
  }, [form.watch("amount_requested"), form.watch("tenor_months"), form.watch("customer_id"), appSettings, eligibleCustomers, role]);

  // Auto-set member_id and application_date when dialog opens
  useEffect(() => {
    if (dialogOpen) {
      // Always set application_date to current date in WIB when dialog opens (fresh date)
      form.setValue("application_date", getNowInWIB());

      // For sales users, auto-set member_id
      if (isSales && currentMemberId) {
        form.setValue("member_id", currentMemberId);
      }
    }
  }, [dialogOpen, isSales, currentMemberId]);
  useEffect(() => {
    loadMembers();
    loadAppSettings();
    loadInterestRates();
    loadCurrentMemberId();

    // Setup realtime for app_settings changes
    const settingsChannel = supabase
      .channel('app-settings-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'app_settings'
        },
        () => {
          console.log('🔄 Settings updated, reloading...');
          loadAppSettings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(settingsChannel);
    };
  }, []);

  // Reset to page 1 when search or filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch, selectedMemberFilter]);

  // Auto-load installments when applications change
  useEffect(() => {
    if (applications.length > 0) {
      loadInstallments();
    }
  }, [applications]);

  // Handle events that require data refresh
  useEffect(() => {
    const handleRefresh = () => {
      invalidateApplications();
      loadMembers();
    };
    
    const handleDataChange = () => {
      invalidateApplications();
    };
    
    window.addEventListener('page-refresh', handleRefresh);
    window.addEventListener('application-approved', handleDataChange);
    window.addEventListener('application-rejected', handleDataChange);
    window.addEventListener('application-updated', handleDataChange);
    window.addEventListener('installments-updated', handleDataChange);
    
    return () => {
      window.removeEventListener('page-refresh', handleRefresh);
      window.removeEventListener('application-approved', handleDataChange);
      window.removeEventListener('application-rejected', handleDataChange);
      window.removeEventListener('application-updated', handleDataChange);
      window.removeEventListener('installments-updated', handleDataChange);
    };
  }, [invalidateApplications]);

  // Check for preselected customer from navigation
  useEffect(() => {
    const preselectedCustomerData = sessionStorage.getItem('preselectedCustomer');
    if (preselectedCustomerData) {
      try {
        const customer = JSON.parse(preselectedCustomerData);
        // Set the customer in the form
        form.setValue('customer_id', customer.id);
        // Open the dialog
        setDialogOpen(true);
        // Clear the session storage
        sessionStorage.removeItem('preselectedCustomer');
      } catch (error) {
        console.error('Error parsing preselected customer:', error);
      }
    }
  }, []);
  const loadAppSettings = async () => {
    try {
      const {
        data,
        error
      } = await supabase.rpc('get_public_app_settings');
      if (error) {
        console.error('Error loading app settings:', error);
        // Set default settings as fallback for all roles
        setAppSettings({
          first_installment_type: 'next_month',
          admin_fee_enabled: false,
          admin_fee_amount: 0,
          penalty_rate_per_day: 2.0
        });
      } else if (data) {
        console.log('✅ App settings loaded successfully for user role:', role);
        setAppSettings(data);
      }
    } catch (err) {
      console.error('Failed to load app settings:', err);
      // Set default settings as fallback
      setAppSettings({
        first_installment_type: 'next_month',
        admin_fee_enabled: false,
        admin_fee_amount: 0,
        penalty_rate_per_day: 2.0
      });
    }
  };
  const loadInstallments = async () => {
    // OPTIMIZED: Only load installments for current page's applications
    // This will be called AFTER applications are loaded
    if (applications.length === 0) return;
    const appIds = applications.map(a => a.id);
    const {
      data,
      error
    } = await supabase.from("installments").select("*").in("application_id", appIds);
    if (!error) {
      setInstallments(data || []);
    }
  };
  const isApplicationFullyPaid = (applicationId: string): boolean => {
    const appInstallments = installments.filter(i => i.application_id === applicationId);
    return appInstallments.length > 0 && appInstallments.every(i => i.status === "paid");
  };
  const getApplicationStatus = (applicationId: string): 'paid' | 'active-overdue' | 'active-penalty' | 'active-clean' | 'pending' => {
    const appInstallments = installments.filter(i => i.application_id === applicationId);
    if (appInstallments.length === 0) return 'pending';

    // Check if all paid
    const allPaid = appInstallments.every(i => i.status === "paid");
    if (allPaid) return 'paid';

    // Check if any installment is overdue (menunggak)
    const hasOverdue = appInstallments.some(i => i.status === "overdue");
    if (hasOverdue) return 'active-overdue';

    // Check if any installment has frozen penalty
    const hasPenalty = appInstallments.some(i => Number(i.frozen_penalty || 0) > 0);
    if (hasPenalty) return 'active-penalty';
    return 'active-clean';
  };
  const getStatusColor = (status: 'paid' | 'active-overdue' | 'active-penalty' | 'active-clean' | 'pending'): string => {
    switch (status) {
      case 'paid':
        return 'bg-green-50 border-l-4 border-green-500';
      case 'active-overdue':
        return 'bg-red-50 border-l-4 border-red-600';
      case 'active-penalty':
        return 'bg-red-50 border-l-4 border-red-500';
      case 'active-clean':
        return 'bg-yellow-50 border-l-4 border-yellow-500';
      default:
        return '';
    }
  };
  const loadInterestRates = async () => {
    const rates = new Map<number, number>();
    // Preload interest rates for tenors based on max_tenor_months setting
    const maxTenor = appSettings?.max_tenor_months || 24;
    for (let tenor = 1; tenor <= maxTenor; tenor++) {
      const rate = await getInterestRate(tenor);
      rates.set(tenor, rate);
    }
    setInterestRates(rates);
  };

  // Filter customers for credit eligibility (menggunakan data dari useCustomersQuery hook)
  useEffect(() => {
    const filterEligibleCustomers = async () => {
      if (allCustomersWithBadges.length === 0) {
        console.log("⚠️ No customers loaded yet, skipping filter");
        setEligibleCustomers([]);
        setExcludedCustomers(new Map());
        return;
      }

      console.log("🔍 Starting customer eligibility filter...");
      console.log("📊 Total customers to filter:", allCustomersWithBadges.length);

      // Get blocked customers
      const { data: blockedCustomers } = await supabase
        .from("blocked_customers")
        .select("customer_id");
      const blockedIds = new Set(blockedCustomers?.map(bc => bc.customer_id) || []);
      console.log("🚫 Blocked customers:", blockedIds.size);

      // NOTE: Tidak lagi memfilter berdasarkan aplikasi pending sesuai permintaan pengguna
      // Filter hanya menggunakan status blokir, kredit aktif, dan denda yang belum dibayar


      // Get customers with active credit based on credit applications status
      const { data: activeApplications } = await supabase
        .from("credit_applications")
        .select("customer_id,status");

      const customersWithActiveCredit = new Set(
        (activeApplications || [])
          .filter((app: any) => app.status !== "completed" && app.status !== "rejected" && app.status !== "not_disbursed")
          .map((app: any) => app.customer_id)
          .filter(Boolean)
      );
      
      console.log("🔴 Customers with active credit (by applications):", customersWithActiveCredit.size);


      // Get customers with unpaid penalties in ACTIVE applications
      const { data: installmentsWithPenalty } = await supabase
        .from("installments")
        .select(`
          credit_applications!inner(
            customer_id
          )
        `)
        .gt("frozen_penalty", 0);

      const customersWithUnpaidPenalties = new Set(
        installmentsWithPenalty
          ?.map((inst: any) => inst.credit_applications?.customer_id)
          .filter(Boolean) || []
      );
      console.log("💰 Customers with unpaid penalties:", customersWithUnpaidPenalties.size);

      // Track excluded customers with reasons
      const excludedMap = new Map<string, {customer: any, reason: string}>();
      
      // Filter eligible customers
      const eligible = allCustomersWithBadges.filter(customer => {
        // 1. Exclude if blocked
        if (blockedIds.has(customer.id)) {
          excludedMap.set(customer.id, {customer, reason: 'Nasabah sedang diblokir'});
          return false;
        }


        // 3. Exclude if has active credit (unpaid principal installments)
        if (customersWithActiveCredit.has(customer.id)) {
          excludedMap.set(customer.id, {customer, reason: 'Masih memiliki cicilan pokok yang belum lunas'});
          console.log("🚫 EXCLUDED:", customer.full_name, "- has unpaid principal");
          return false;
        }

        // 4. Exclude if has unpaid penalties (denda)
        if (customersWithUnpaidPenalties.has(customer.id)) {
          excludedMap.set(customer.id, {
            customer, 
            reason: 'Masih memiliki denda yang belum dibayar'
          });
          return false;
        }


        return true;
      });

      console.log(`✅ Eligible customers: ${eligible.length} out of ${allCustomersWithBadges.length}`);
      console.log(`❌ Excluded customers: ${excludedMap.size}`);
      
      setEligibleCustomers(eligible);
      setExcludedCustomers(excludedMap);
    };

    filterEligibleCustomers();
  }, [allCustomersWithBadges]);
  const loadMembers = async () => {
    // Get user_ids with 'owner' role
    const {
      data: ownerRoles
    } = await supabase.from("user_roles").select("user_id").eq("role", "owner");
    const ownerUserIds = ownerRoles?.map(r => r.user_id) || [];

    // Fetch members who have active credit applications (not rejected/completed)
    const { data: activeMembersData } = await supabase
      .from("credit_applications")
      .select(`
        member_id,
        members!inner(id, full_name, user_id)
      `)
      .not("status", "eq", "rejected")
      .not("status", "eq", "completed");

    if (!activeMembersData) {
      setMembers([]);
      return;
    }

    // Extract unique members and exclude owners
    const uniqueMembersMap = new Map();
    activeMembersData.forEach((app: any) => {
      if (app.members && app.member_id) {
        const isOwner = ownerUserIds.includes(app.members.user_id);
        if (!isOwner) {
          uniqueMembersMap.set(app.member_id, {
            id: app.members.id,
            full_name: app.members.full_name,
            user_id: app.members.user_id
          });
        }
      }
    });

    const membersArray = Array.from(uniqueMembersMap.values()).sort((a, b) => 
      a.full_name.localeCompare(b.full_name)
    );

    setMembers(membersArray);
  };
  const loadCurrentMemberId = async () => {
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    if (user) {
      const {
        data: memberData
      } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
      if (memberData) {
        setCurrentMemberId(memberData.id);
      }
    }
  };
  
  // Handler untuk menampilkan dialog konfirmasi sebelum submit
  const handleFormSubmit = async (values: z.infer<typeof formSchema>) => {
    // Cek apakah nasabah sudah punya No. KK
    const selectedCustomer = eligibleCustomers.find(c => c.id === values.customer_id);
    
    if (selectedCustomer) {
      // Fetch latest customer data to check no_kk (in case it was just updated)
      const { data: customerData } = await supabase
        .from("customers")
        .select("id, full_name, id_number, no_kk")
        .eq("id", values.customer_id)
        .single();
      
      if (customerData && (!customerData.no_kk || customerData.no_kk.trim() === '')) {
        // Nasabah belum punya No. KK - tampilkan dialog update
        setCustomerNeedingNoKK({
          id: customerData.id,
          full_name: customerData.full_name,
          id_number: customerData.id_number,
        });
        setPendingFormValues(values);
        setUpdateNoKKDialogOpen(true);
        return;
      }
    }
    
    // Simpan values form sementara dan tampilkan dialog konfirmasi
    setPendingFormValues(values);
    setConfirmationDialogOpen(true);
  };
  
  // Handler setelah No. KK berhasil diupdate
  const handleNoKKUpdateSuccess = () => {
    // Setelah update sukses, lanjutkan ke dialog konfirmasi
    if (pendingFormValues) {
      setConfirmationDialogOpen(true);
    }
  };
  
  // Handler saat user menyetujui pernyataan
  const handleConfirmSubmit = () => {
    if (pendingFormValues) {
      setConfirmationDialogOpen(false);
      onSubmit(pendingFormValues);
    }
  };
  
  // Handler saat user membatalkan
  const handleCancelConfirmation = () => {
    setConfirmationDialogOpen(false);
    setPendingFormValues(null);
  };
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    // Prevent double submission
    if (isSubmitting) {
      return;
    }
    setIsSubmitting(true);
    setProgressMessage("Memvalidasi data...");
    setProgressValue(20);
    try {
      // Auto-set member_id for sales users (safety check)
      let finalMemberId = values.member_id;
      if (isSales && currentMemberId && !finalMemberId) {
        finalMemberId = currentMemberId;
      }

      // Validate member_id is set
      if (!finalMemberId) {
        toast({
          title: "Penanggung jawab harus dipilih",
          description: "Silakan pilih anggota penanggung jawab",
          variant: "destructive"
        });
        return;
      }

      // Get customer NIK to check eligibility
      const selectedCustomer = eligibleCustomers.find(c => c.id === values.customer_id);
      if (!selectedCustomer?.nik) {
        toast({
          title: "Data nasabah tidak lengkap",
          description: "NIK nasabah tidak ditemukan",
          variant: "destructive"
        });
        return;
      }

      // Verify customer status from database (additional safety check)
      const {
        data: customerData,
        error: customerError
      } = await supabase.from("customers").select("status, full_name").eq("id", values.customer_id).single();
      if (customerError || !customerData) {
        toast({
          title: "Gagal memverifikasi data nasabah",
          variant: "destructive"
        });
        return;
      }
      if (customerData.status !== 'approved') {
        toast({
          title: "Nasabah belum diverifikasi",
          description: `Nasabah "${customerData.full_name}" masih berstatus ${customerData.status}. Hanya nasabah yang sudah diverifikasi (approved) yang dapat mengajukan kredit.`,
          variant: "destructive"
        });
        return;
      }

      // Note: Validasi kelayakan kredit dilakukan sepenuhnya oleh server-side function can_apply_for_credit
      // Client-side validation dihapus karena data installments hanya dimuat untuk halaman saat ini (pagination)
      // yang menyebabkan false positive untuk customer dengan aplikasi di halaman lain

      // Check credit eligibility
      const {
        data: eligibilityData,
        error: eligibilityError
      } = await supabase.rpc('can_apply_for_credit', {
        check_nik: selectedCustomer.nik
      });
      if (eligibilityError) {
        console.error('Eligibility check error:', eligibilityError);
        toast({
          title: "Gagal memeriksa kelayakan kredit",
          variant: "destructive"
        });
        return;
      }
      const eligibility = eligibilityData as any;
      if (!eligibility?.can_apply) {
        console.log('Credit eligibility check failed:', eligibility);
        toast({
          title: "Nasabah tidak dapat mengajukan kredit",
          description: eligibility?.message || "Nasabah masih memiliki kewajiban yang belum diselesaikan",
          variant: "destructive"
        });

        // Log untuk debugging
        await logSystemEvent({
          category: "credit_application",
          action: "application_rejected_eligibility",
          description: `Pengajuan kredit ditolak - ${selectedCustomer.full_name}`,
          metadata: {
            customer_id: values.customer_id,
            customer_name: selectedCustomer.full_name,
            nik: selectedCustomer.nik,
            reason: eligibility?.reason,
            message: eligibility?.message,
            credit_score: eligibility?.credit_score
          }
        });
        return;
      }
      const tenor = parseInt(values.tenor_months);
      let baseInterestRate = await getInterestRate(tenor);
      let discountApplied = 0;
      let badgeLevel = null;
      
      // Apply badge discount if enabled
      if (appSettings?.badge_discount_enabled) {
        const selectedCustomer = eligibleCustomers.find(c => c.id === values.customer_id);
        if (selectedCustomer?.achievementBadge?.badgeName) {
          const badgeName = selectedCustomer.achievementBadge.badgeName;
          
          if (badgeName === "Platinum Elite" && appSettings.platinum_discount > 0) {
            discountApplied = appSettings.platinum_discount;
            badgeLevel = "Platinum Elite";
          } else if (badgeName === "Diamond Premier" && appSettings.diamond_discount > 0) {
            discountApplied = appSettings.diamond_discount;
            badgeLevel = "Diamond Premier";
          } else if (badgeName === "Gold Member" && appSettings.gold_discount > 0) {
            discountApplied = appSettings.gold_discount;
            badgeLevel = "Gold Member";
          }
        }
      }
      
      const interestRate = baseInterestRate - discountApplied;
      const applicationNumber = `APP-${Date.now()}`;

      // Get current user for auto-approval check
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();

      // Determine status based on role: owner/admin auto-approve, sales needs approval
      const applicationStatus = isOwner || isAdmin ? 'approved' : 'pending';
      const amountRequested = parseFloat(values.amount_requested);

      // Calculate admin fee if enabled (with minimum)
      let adminFee = 0;
      if (appSettings?.admin_fee_enabled && appSettings?.admin_fee_amount > 0) {
        const calculatedFee = Math.round(amountRequested * (appSettings.admin_fee_amount / 100));
        const adminFeeMinimum = appSettings?.admin_fee_minimum || 0;
        adminFee = Math.max(calculatedFee, adminFeeMinimum);
      }
      // Validate application_date
      const sanitizedAppDate = sanitizeDateForDatabase(values.application_date);
      if (!sanitizedAppDate) {
        toast({
          title: "Error",
          description: "Format tanggal pengajuan tidak valid (tahun harus antara 1900-2100)",
          variant: "destructive"
        });
        return;
      }

      setProgressMessage("Menyimpan pengajuan kredit...");
      setProgressValue(60);

      // Prepare data for insert (use finalMemberId)
      // SNAPSHOT: Simpan pengaturan owner yang berlaku saat kredit dibuat
      const insertData: any = {
        customer_id: values.customer_id,
        member_id: finalMemberId,
        amount_requested: amountRequested,
        tenor_months: tenor,
        interest_rate: interestRate,
        original_interest_rate: discountApplied > 0 ? baseInterestRate : null,
        discount_applied: discountApplied,
        discount_badge_level: badgeLevel,
        purpose: "Modal Usaha",
        application_number: applicationNumber,
        application_date: sanitizedAppDate,
        collateral_description: values.collateral_description,
        status: applicationStatus,
        admin_fee_amount: adminFee, // Set admin fee for all applications
        // SNAPSHOT pengaturan owner saat kredit dibuat
        penalty_rate_per_day: appSettings?.penalty_rate_per_day || 2.0,
        interest_type_snapshot: appSettings?.interest_type || null,
        flat_interest_rate_snapshot: appSettings?.flat_interest_rate || null,
        custom_rates_snapshot: appSettings?.custom_rates || null,
        // BUSINESS RULE: Tenor < 4 bulan PAKSA next_month, >= 4 bulan ikut setting owner
        first_installment_type: tenor < 4 ? 'next_month' : (appSettings?.first_installment_type || 'next_month')
      };

      // If auto-approved, set approval fields with WIB timestamp
      if (applicationStatus === 'approved') {
        const { getCurrentTimestampForDB, getTodayDateForDB } = await import('@/lib/utils');
        const wibTimestamp = getCurrentTimestampForDB();
        const wibDate = getTodayDateForDB();
        
        insertData.approved_by = user?.id;
        insertData.approved_at = wibTimestamp;
        insertData.disbursed_at = wibTimestamp; // Explicitly set disbursed_at with WIB
        insertData.amount_approved = amountRequested;
      }
      const {
        data: insertedApp,
        error
      } = await supabase.from("credit_applications").insert(insertData).select('id, member_id').single();
      if (error) {
        console.error('[Applications] Error inserting credit application:', error, { insertData });
        // Check if it's a unique constraint violation
        if (error.code === '23505' || error.message?.includes('unique_active_application_per_customer')) {
          toast({
            title: "Pengajuan gagal",
            description: "Nasabah sudah memiliki pengajuan atau kredit yang masih aktif",
            variant: "destructive"
          });
        } else {
          toast({
            title: "Gagal mengajukan kredit",
            description: error.message || "Terjadi kesalahan saat menyimpan pengajuan kredit",
            variant: "destructive"
          });
        }
      } else {
        // Process incentive if auto-approved (only if enabled)
        if (applicationStatus === 'approved' && insertedApp?.member_id) {
          try {
            const {
              data: incentiveSettings
            } = await (supabase as any).from('incentive_settings').select('is_enabled, credit_application_enabled').maybeSingle();
            if (incentiveSettings?.is_enabled && incentiveSettings?.credit_application_enabled) {
              await supabase.functions.invoke('process-incentive', {
                body: {
                  type: 'credit_application',
                  application_id: insertedApp.id
                }
              });
            }
          } catch (incentiveError) {
            console.error('Failed to process incentive:', incentiveError);
          }
        }
        const actionDescription = applicationStatus === 'approved' ? `Membuat dan menyetujui aplikasi kredit untuk ${selectedCustomer.full_name} (auto-approved)` : `Membuat aplikasi kredit untuk ${selectedCustomer.full_name} (menunggu persetujuan)`;
        await logSystemEvent({
          category: "credit_application",
          action: "Buat Aplikasi Kredit",
          description: actionDescription,
          metadata: {
            customer_id: values.customer_id,
            customer_name: selectedCustomer.full_name,
            amount_requested: amountRequested,
            tenor_months: tenor,
            application_number: applicationNumber,
            status: applicationStatus,
            auto_approved: applicationStatus === 'approved'
          }
        });
        
        // Show success animation
        setProgressMessage("");
        setProgressValue(100);
        setShowSuccess(true);
        
        const successMessage = applicationStatus === 'approved' ? "Pengajuan kredit berhasil dibuat dan disetujui" : "Pengajuan kredit berhasil dibuat dan menunggu persetujuan";
        toast({
          title: successMessage
        });
        
        // Delay closing to show success animation
        setTimeout(() => {
          setDialogOpen(false);
          setShowSuccess(false);
          // Reset form and set application_date to fresh current date
          form.reset({
            customer_id: "",
            member_id: isSales && currentMemberId ? currentMemberId : "",
            amount_requested: "",
            tenor_months: "",
            application_date: new Date(),
            // Always use fresh current date
            collateral_description: ""
          });
          // Force immediate reload across all pages
          invalidateApplications();
          window.dispatchEvent(new Event('application-created'));
        }, 1500);
      }
    } finally {
      setIsSubmitting(false);
      setProgressMessage("");
      setProgressValue(0);
    }
  };
  const openApprovalDialog = (applicationId: string, amountRequested: number) => {
    setPendingApproval({
      applicationId,
      amountRequested
    });
    setApprovalDialogOpen(true);
    disbursementForm.reset({
      disbursement_date: new Date()
    });
  };
  const onDisbursementSubmit = async (values: z.infer<typeof disbursementFormSchema>) => {
    if (!pendingApproval) return;
    const {
      applicationId,
      amountRequested
    } = pendingApproval;

    // Get application details
    const {
      data: application
    } = await supabase.from("credit_applications").select(`
        *,
        customers!inner (full_name, phone, id_number),
        members!inner (full_name)
      `).eq("id", applicationId).maybeSingle();
    if (!application) {
      toast({
        title: "Data aplikasi tidak ditemukan",
        variant: "destructive"
      });
      return;
    }
    const disbursementDate = format(values.disbursement_date, "yyyy-MM-dd'T'HH:mm:ss.SSSxxx");
    const userId = (await supabase.auth.getUser()).data.user?.id;

    // Calculate disbursement details based on app settings
    let netAmount = amountRequested;
    let firstInstallmentAmount = 0;
    let adminFee = 0;

    // Calculate first installment amount for display
    // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama, meskipun setting 'paid_upfront'
    const tenor = application.tenor_months;
    if (tenor >= 4 && appSettings?.first_installment_type === 'paid_upfront') {
      const interestRate = application.interest_rate;
      const principalPerMonth = amountRequested / tenor;
      const interestPerMonth = amountRequested * (interestRate / 100);
      const monthlyInstallmentRaw = principalPerMonth + interestPerMonth;
      firstInstallmentAmount = Math.ceil(monthlyInstallmentRaw / 1000) * 1000;
      netAmount -= firstInstallmentAmount;
    }

    // Calculate admin fee for display (with minimum)
    if (appSettings?.admin_fee_enabled && appSettings?.admin_fee_amount > 0) {
      const calculatedFee = Math.round(amountRequested * (appSettings.admin_fee_amount / 100));
      const adminFeeMinimum = appSettings?.admin_fee_minimum || 0;
      adminFee = Math.max(calculatedFee, adminFeeMinimum);
      netAmount -= adminFee;
    }

    // Approve the application with custom disbursement date
    const {
      error
    } = await supabase.from("credit_applications").update({
      status: "approved",
      amount_approved: amountRequested,
      approved_at: disbursementDate,
      approved_by: userId,
      admin_fee_amount: adminFee // Save admin fee amount
    }).eq("id", applicationId);
    if (error) {
      toast({
        title: "Gagal menyetujui pengajuan",
        variant: "destructive"
      });
      return;
    }

    // Process incentive for approval (only if enabled)
    if (application.member_id) {
      try {
        const {
          data: incentiveSettings
        } = await (supabase as any).from('incentive_settings').select('is_enabled, credit_application_enabled').maybeSingle();
        if (incentiveSettings?.is_enabled && incentiveSettings?.credit_application_enabled) {
          await supabase.functions.invoke('process-incentive', {
            body: {
              type: 'credit_application',
              application_id: applicationId
            }
          });
        }
      } catch (incentiveError) {
        console.error('Failed to process incentive:', incentiveError);
      }
    }

    // Wait for database triggers to complete (installment generation + auto payments)
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Log the approval event
    await logSystemEvent({
      category: "credit_application",
      action: "Setujui Aplikasi Kredit",
      description: `Menyetujui aplikasi kredit untuk ${application.customers.full_name}`,
      metadata: {
        application_id: applicationId,
        customer_name: application.customers.full_name,
        member_name: application.members.full_name,
        amount_approved: amountRequested,
        net_amount: netAmount,
        first_installment_amount: firstInstallmentAmount,
        admin_fee: adminFee
      }
    });

    // Send notification message to customer
    try {
      const {
        data: customerData
      } = await supabase.from("customers").select("id").eq("id_number", application.customers.id_number).maybeSingle();
      if (customerData) {
        let message = `Selamat! Pengajuan kredit Anda sebesar ${formatRupiah(amountRequested)} telah disetujui. `;
        if (firstInstallmentAmount > 0) {
          message += `Angsuran pertama sebesar ${formatRupiah(firstInstallmentAmount)} akan dipotong dari pencairan. `;
        }
        if (adminFee > 0) {
          message += `Biaya admin sebesar ${formatRupiah(adminFee)} akan dipotong. `;
        }
        message += `Total yang akan Anda terima: ${formatRupiah(netAmount)}. Terima kasih atas kepercayaan Anda.`;
        await supabase.from("customer_messages").insert({
          customer_id: customerData.id,
          title: "Pengajuan Kredit Disetujui",
          message,
          type: "announcement",
          is_read: false
        });
      }
    } catch (msgError) {
      console.error("Failed to send approval notification:", msgError);
    }

    // Close approval dialog first
    setApprovalDialogOpen(false);
    setPendingApproval(null);

    // Show disbursement receipt popup with all details
    setDisbursementData({
      customerName: application.customers.full_name,
      memberName: application.members.full_name,
      disbursementDate: disbursementDate,
      amountRequested,
      firstInstallmentAmount: firstInstallmentAmount > 0 ? firstInstallmentAmount : undefined,
      adminFee: adminFee > 0 ? adminFee : undefined,
      netAmount,
      customerPhone: application.customers.phone,
      applicationNumber: application.application_number
    });
    setDisbursementDialogOpen(true);
    toast({
      title: "Pengajuan kredit disetujui"
    });
    // Force immediate reload across all pages
    invalidateApplications();
    window.dispatchEvent(new Event('application-approved'));

    // Automatically show agreement preview after approval
    setTimeout(async () => {
      const agreementData = await prepareAgreementData(application);
      if (agreementData) {
        setAgreementPreviewData(agreementData);
        setCurrentAgreementApp(application);
        setAgreementPreviewOpen(true);
      }
    }, 500); // Small delay to ensure disbursement dialog is shown first
  };
  const handleReject = async (applicationId: string) => {
    const application = applications.find(a => a.id === applicationId);
    const {
      error
    } = await supabase.from("credit_applications").update({
      status: "rejected",
      approved_at: new Date().toISOString(),
      approved_by: (await supabase.auth.getUser()).data.user?.id
    }).eq("id", applicationId);
    if (error) {
      toast({
        title: "Gagal menolak pengajuan",
        variant: "destructive"
      });
    } else {
      await logSystemEvent({
        category: "credit_application",
        action: "Tolak Aplikasi Kredit",
        description: `Menolak aplikasi kredit untuk ${application?.customers?.full_name}`,
        metadata: {
          application_id: applicationId,
          customer_name: application?.customers?.full_name,
          application_number: application?.application_number
        }
      });

      // Send notification message to customer
      try {
        const {
          data: customerData
        } = await supabase.from("customers").select("id").eq("id_number", application?.customers?.id_number).maybeSingle();
        if (customerData) {
          await supabase.from("customer_messages").insert({
            customer_id: customerData.id,
            title: "Pengajuan Kredit Ditolak",
            message: `Mohon maaf, pengajuan kredit Anda tidak dapat disetujui pada saat ini. Silakan hubungi kami untuk informasi lebih lanjut.`,
            type: "info",
            is_read: false
          });
        }
      } catch (msgError) {
        console.error("Failed to send rejection notification:", msgError);
      }
      toast({
        title: "Pengajuan kredit ditolak"
      });
      // Force immediate reload
      invalidateApplications();
      window.dispatchEvent(new Event('application-rejected'));
    }
  };
  const handleDelete = async (applicationId: string) => {
    if (!confirm("Apakah Anda yakin ingin menghapus data aplikasi kredit ini? Tindakan ini tidak dapat dibatalkan.")) {
      return;
    }
    const application = applications.find(a => a.id === applicationId);
    const {
      error
    } = await supabase.from("credit_applications").delete().eq("id", applicationId);
    if (error) {
      toast({
        title: "Gagal menghapus aplikasi kredit",
        description: error.message,
        variant: "destructive"
      });
    } else {
      await logSystemEvent({
        category: "credit_application",
        action: "Hapus Aplikasi Kredit",
        description: `Menghapus aplikasi kredit untuk ${application?.customers?.full_name}`,
        metadata: {
          application_id: applicationId,
          customer_name: application?.customers?.full_name,
          application_number: application?.application_number
        }
      });
      toast({
        title: "Aplikasi kredit berhasil dihapus"
      });
      // Reload data
      invalidateApplications();
    }
  };
  const calculateMonthlyInstallment = (amount: number, tenor: number, interestRate: number): number => {
    const principalPerMonth = amount / tenor;
    const interestPerMonth = amount * (interestRate / 100);
    const monthlyInstallmentRaw = principalPerMonth + interestPerMonth;
    return Math.ceil(monthlyInstallmentRaw / 1000) * 1000;
  };
  const prepareAgreementData = async (app: any) => {
    // Fetch customer details
    const {
      data: customer
    } = await supabase.from("customers").select("*").eq("id", app.customer_id).maybeSingle();

    // Fetch owner data from members table (PIHAK KEDUA)
    let {
      data: ownerMember
    } = await supabase.from("members").select("*").eq("position", "owner").order("created_at", {
      ascending: true
    }).limit(1).maybeSingle();
    if (!ownerMember) {
      const {
        data: ownerFallback
      } = await supabase.from("members").select("*").ilike("position", "%owner%").order("created_at", {
        ascending: true
      }).limit(1).maybeSingle();
      ownerMember = ownerFallback || null;
    }
    if (!ownerMember) {
      // Final fallback: find a user with 'owner' role and use their member record
      const {
        data: ownerRole
      } = await supabase.from("user_roles").select("user_id").eq("role", "owner").order("created_at", {
        ascending: true
      }).limit(1).maybeSingle();
      if (ownerRole?.user_id) {
        const {
          data: memberByRole
        } = await supabase.from("members").select("*").eq("user_id", ownerRole.user_id).maybeSingle();
        ownerMember = memberByRole || null;
      }
    }
    if (!ownerMember) {
      toast({
        title: "Data owner tidak ditemukan",
        description: "Pastikan ada anggota dengan posisi 'owner' yang terdaftar",
        variant: "destructive"
      });
      return;
    }

    // Fetch witness (member penanggung jawab) from application
    const {
      data: responsibleMember
    } = await supabase.from("members").select("*").eq("id", app.member_id).maybeSingle();
    const witnessName = responsibleMember?.full_name || "";
    if (!customer || !ownerMember) {
      toast({
        title: "Data tidak lengkap",
        variant: "destructive"
      });
      return;
    }

    // Use the application_date from database for the agreement document
    const applicationDate = app.application_date ? new Date(app.application_date) : new Date();
    const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    const dayName = days[applicationDate.getDay()];
    const day = applicationDate.getDate();
    const month = months[applicationDate.getMonth()];
    const year = applicationDate.getFullYear();
    const amount = Number(app.amount_approved || app.amount_requested);
    const tenor = app.tenor_months;
    const isShortTenor = tenor <= 3;
    const interestRate = app.interest_rate;
    const monthlyInstallment = calculateMonthlyInstallment(amount, tenor, interestRate);

    // Tentukan jadwal angsuran pertama berdasarkan SNAPSHOT saat kredit dibuat
    // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama
    const effectiveFirstInstallmentType = isShortTenor ? 'next_month' : (app.first_installment_type || 'next_month');
    const firstInstallmentDeducted = effectiveFirstInstallmentType === 'paid_upfront';

    // Hitung biaya admin menggunakan SNAPSHOT saat kredit dibuat
    const adminFee = app.admin_fee_amount || 0;
    const adminFeePercentage = adminFee > 0 ? Math.round((adminFee / amount) * 100) : 0;

    // Hitung pencairan bersih yang diterima nasabah
    let netDisbursement = amount - adminFee;
    if (firstInstallmentDeducted) {
      netDisbursement = netDisbursement - monthlyInstallment;
    }

    // Hitung tanggal angsuran pertama
    const firstInstallmentDate = new Date(applicationDate);
    if (effectiveFirstInstallmentType === 'next_month') {
      firstInstallmentDate.setMonth(firstInstallmentDate.getMonth() + 1);
    }
    const firstInstallmentDay = firstInstallmentDate.getDate();
    const firstInstallmentMonth = months[firstInstallmentDate.getMonth()];
    const firstInstallmentYear = firstInstallmentDate.getFullYear();

    // Return agreement data for preview
    return {
      customer,
      ownerMember,
      witnessName,
      applicationDate,
      amount,
      tenor,
      interestRate,
      monthlyInstallment,
      isShortTenor,
      firstInstallmentDeducted,
      adminFee,
      adminFeePercentage,
      netDisbursement,
      firstInstallmentDate,
      collateralDescription: app.collateral_description,
      penaltyRate: app.penalty_rate_per_day || 2.0, // Use snapshot penalty rate
      app // Keep reference to original app for document generation
    };
  };
  const generateAgreementDocument = async (agreementData: any) => {
    try {
      await generateAgreementWord(agreementData);
      toast({
        title: "Dokumen perjanjian berhasil diunduh"
      });
    } catch (error) {
      console.error('Error generating Word document:', error);
      toast({
        title: "Gagal membuat dokumen",
        variant: "destructive"
      });
    }
  };
  const handleAgreementPreview = async (app: any) => {
    // Close detail dialog first to prevent overlap
    setShowDetail(false);
    const data = await prepareAgreementData(app);
    if (data) {
      setAgreementPreviewData(data);
      setCurrentAgreementApp(app);
      setAgreementPreviewOpen(true);
    }
  };
  const handleDownloadAgreement = () => {
    if (agreementPreviewData) {
      generateAgreementDocument(agreementPreviewData);
      setAgreementPreviewOpen(false);
    }
  };
  const handleSendAgreementWhatsApp = () => {
    if (!agreementPreviewData || !currentAgreementApp) return;
    
    const message = generateAgreementWhatsAppMessage(
      agreementPreviewData,
      currentAgreementApp.application_number
    );
    
    openWhatsAppChat(agreementPreviewData.customer.phone, message);
    toast({
      title: "WhatsApp dibuka",
      description: "Silakan kirim pesan perjanjian kepada nasabah"
    });
  };
  const getStatusBadge = (app: any) => {
    const status = app.status;
    const colorClasses: any = {
      pending: "text-yellow-600 dark:text-yellow-400",
      approved: "text-green-600 dark:text-green-500",
      rejected: "text-red-600 dark:text-red-500",
      disbursed: "text-green-600 dark:text-green-500"
    };
    let statusText = status;
    if ((status === 'approved' || status === 'rejected') && app.approver) {
      const action = status === 'approved' ? 'Disetujui' : 'Ditolak';
      statusText = `${action} oleh ${app.approver.full_name} - ${app.approver.position}`;
    } else {
      // Translate status text to Indonesian
      const statusTranslation: any = {
        pending: "Menunggu",
        approved: "Disetujui",
        rejected: "Ditolak",
        disbursed: "Dicairkan"
      };
      statusText = statusTranslation[status] || status;
    }
    return <span className={`font-semibold ${colorClasses[status] || "text-gray-600"}`}>{statusText}</span>;
  };
  const verifySuperCode = async () => {
    setSuperCodeError("");
    if (!superCodeInput) {
      setSuperCodeError("Masukkan SuperCode");
      return false;
    }
    try {
      // Use secure server-side verification via edge function
      const {
        data: result,
        error: verifyError
      } = await supabase.functions.invoke('verify-supercode', {
        body: {
          superCodeInput: superCodeInput,
          operation: 'application_supercode_verification'
        }
      });
      if (verifyError) {
        setSuperCodeError("Gagal memverifikasi SuperCode. Silakan coba lagi.");
        return false;
      }
      if (!result?.valid) {
        setSuperCodeError(result?.error || "SuperCode tidak valid");
        return false;
      }
      return true;
    } catch (error: any) {
      setSuperCodeError(error.message || "Gagal memverifikasi SuperCode");
      return false;
    }
  };
  const handleSuperCodeSubmit = async () => {
    const isValid = await verifySuperCode();
    if (!isValid) return;
    setSuperCodeDialogOpen(false);
    setSuperCodeInput("");
    if (editMode === 'delete') {
      setDeleteDialogOpen(true);
    } else if (editMode === 'edit') {
      openEditForm();
    }
  };
  const handleDeleteApplication = async () => {
    if (!selectedApplication) return;
    try {
      const {
        error
      } = await supabase.from("credit_applications").delete().eq("id", selectedApplication.id);
      if (error) throw error;
      await logSystemEvent({
        category: "credit_application",
        action: "Hapus Pengajuan",
        description: `Menghapus pengajuan kredit: ${selectedApplication.application_number}`,
        metadata: {
          application_id: selectedApplication.id,
          customer_name: selectedApplication.customers?.full_name,
          amount: selectedApplication.amount_requested
        }
      });
      toast({
        title: "Berhasil",
        description: "Pengajuan kredit berhasil dihapus"
      });

      // Reload data
      invalidateApplications();
      setDeleteDialogOpen(false);
      setSelectedApplication(null);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Gagal menghapus pengajuan",
        variant: "destructive"
      });
    }
  };
  const openDeleteDialog = (app: any) => {
    if (!isOwner && !isAdmin) {
      toast({
        title: "Akses Ditolak",
        description: "Hanya Owner dan Admin yang dapat menghapus pengajuan kredit",
        variant: "destructive"
      });
      return;
    }
    setSelectedApplication(app);
    setEditMode('delete');
    setSuperCodeDialogOpen(true);
  };
  const openEditDialog = (app: any) => {
    if (role !== "owner" && role !== "admin") {
      toast({
        title: "Akses Ditolak",
        description: "Hanya Owner dan Admin yang dapat mengedit pengajuan kredit",
        variant: "destructive"
      });
      return;
    }
    setSelectedApplication(app);
    setEditMode('edit');
    setSuperCodeDialogOpen(true);
  };
  const openEditForm = () => {
    if (!selectedApplication) return;

    // Populate edit form with selected application data
    editForm.reset({
      customer_id: selectedApplication.customer_id,
      member_id: selectedApplication.member_id,
      amount_requested: selectedApplication.amount_requested.toString(),
      tenor_months: selectedApplication.tenor_months.toString(),
      application_date: selectedApplication.application_date ? new Date(selectedApplication.application_date) : new Date(selectedApplication.created_at),
      collateral_description: selectedApplication.collateral_description || ""
    });
    setEditDialogOpen(true);
  };
  const onEditSubmit = async (values: z.infer<typeof editFormSchema>) => {
    if (!selectedApplication) return;
    try {
      // Lock customer_id - prevent any changes to customer name
      const lockedCustomerId = selectedApplication.customer_id;
      const tenor = parseInt(values.tenor_months);
      const interestRate = await getInterestRate(tenor);
      const newApplicationDate = format(values.application_date, "yyyy-MM-dd");
      const oldApplicationDate = selectedApplication.application_date || format(new Date(selectedApplication.created_at), "yyyy-MM-dd");

      // Track what changed for appropriate feedback
      const dateChanged = newApplicationDate !== oldApplicationDate;
      const memberChanged = values.member_id !== selectedApplication.member_id;
      const oldMemberId = selectedApplication.member_id;
      const newMemberId = values.member_id;

      // CRITICAL: Transfer incentives if member (sales responsible) changed
      if (memberChanged && oldMemberId && newMemberId) {
        console.log('Transferring incentives from', oldMemberId, 'to', newMemberId);

        // Transfer all member_balance_transactions related to this application
        const {
          error: transferError
        } = await supabase.from("member_balance_transactions").update({
          member_id: newMemberId
        }).eq("application_id", selectedApplication.id);
        if (transferError) {
          console.error("Error transferring incentives:", transferError);
          toast({
            title: "Peringatan",
            description: "Gagal mentransfer insentif ke penanggung jawab baru",
            variant: "destructive"
          });
          throw transferError;
        }

        // Also transfer transactions related to installments and payments of this application
        // First get all installments for this application
        const {
          data: appInstallments
        } = await supabase.from("installments").select("id").eq("application_id", selectedApplication.id);
        if (appInstallments && appInstallments.length > 0) {
          const installmentIds = appInstallments.map(i => i.id);

          // Transfer transactions related to these installments
          const {
            error: transferInstallmentError
          } = await supabase.from("member_balance_transactions").update({
            member_id: newMemberId
          }).in("installment_id", installmentIds);
          if (transferInstallmentError) {
            console.error("Error transferring installment incentives:", transferInstallmentError);
          }

          // Get payments for these installments
          const {
            data: appPayments
          } = await supabase.from("payments").select("id").in("installment_id", installmentIds);
          if (appPayments && appPayments.length > 0) {
            const paymentIds = appPayments.map(p => p.id);

            // Transfer transactions related to these payments
            const {
              error: transferPaymentError
            } = await supabase.from("member_balance_transactions").update({
              member_id: newMemberId
            }).in("payment_id", paymentIds);
            if (transferPaymentError) {
              console.error("Error transferring payment incentives:", transferPaymentError);
            }
          }
        }

        // Recalculate statistics for both old and new members
        await supabase.rpc('update_member_statistics', {
          p_member_id: oldMemberId
        });
        await supabase.rpc('update_member_statistics', {
          p_member_id: newMemberId
        });
      }

      // CRITICAL: Only regenerate installments if application_date changed
      let installmentsRegenerated = false;
      if (dateChanged && (selectedApplication.status === 'approved' || selectedApplication.status === 'disbursed')) {
        console.log('🔄 Application date changed - Regenerating installments for', selectedApplication.application_number);
        
        // Step 1: Delete all payments for this application
        const { error: deletePaymentsError } = await supabase
          .from("payments")
          .delete()
          .eq("application_id", selectedApplication.id);
        
        if (deletePaymentsError) {
          console.error("Error deleting payments:", deletePaymentsError);
          throw new Error("Gagal menghapus data pembayaran lama");
        }
        
        // Step 2: Delete all installments for this application
        const { error: deleteInstallmentsError } = await supabase
          .from("installments")
          .delete()
          .eq("application_id", selectedApplication.id);
        
        if (deleteInstallmentsError) {
          console.error("Error deleting installments:", deleteInstallmentsError);
          throw new Error("Gagal menghapus data angsuran lama");
        }
        
        installmentsRegenerated = true;
        console.log('✅ Deleted all payments and installments due to date change');
      }

      // Step 3: Update application with new data
      const originalStatus = selectedApplication.status;
      const {
        error: updateError
      } = await supabase.from("credit_applications").update({
        // customer_id is locked, always use original customer_id
        member_id: values.member_id,
        amount_requested: parseFloat(values.amount_requested),
        amount_approved: parseFloat(values.amount_requested), // Update amount_approved to match
        tenor_months: tenor,
        interest_rate: interestRate,
        application_date: newApplicationDate,
        collateral_description: values.collateral_description,
      }).eq("id", selectedApplication.id);
      
      if (updateError) throw updateError;
      
      // Step 4: For approved/disbursed/completed apps, force regenerate installments by temporarily changing status
      if (installmentsRegenerated) {
        // Temporarily set to pending
        await supabase
          .from("credit_applications")
          .update({ status: 'pending' })
          .eq("id", selectedApplication.id);
        
        // Wait for the status change to be processed
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // Set to 'unpaid' (belum lunas) since all payments/installments were reset
        // CRITICAL: Use original approved_at and disbursed_at to maintain correct due dates
        const { error: regenerateError } = await supabase
          .from("credit_applications")
          .update({ 
            status: 'unpaid', // Always set to unpaid after reset, even if was completed before
            // Preserve original approval and disbursement dates
            approved_at: selectedApplication.approved_at,
            disbursed_at: selectedApplication.disbursed_at,
          })
          .eq("id", selectedApplication.id);
        
        if (regenerateError) {
          console.error("Error regenerating installments:", regenerateError);
          throw new Error("Gagal me-regenerate angsuran");
        }
        
        // Wait for trigger to complete
        await new Promise(resolve => setTimeout(resolve, 500));
        
        console.log('✅ Installments regenerated - status set to unpaid');
      }
      await logSystemEvent({
        category: "credit_application",
        action: "Edit Aplikasi Kredit",
        description: `Mengedit aplikasi kredit: ${selectedApplication.application_number}${memberChanged ? ' (Penanggung jawab diubah - insentif ditransfer)' : ''}${installmentsRegenerated ? ' (Tanggal pengajuan diubah - Angsuran di-regenerate)' : ''}`,
        metadata: {
          application_id: selectedApplication.id,
          customer_name: selectedApplication.customers?.full_name,
          amount_requested: parseFloat(values.amount_requested),
          tenor_months: tenor,
          old_application_date: oldApplicationDate,
          new_application_date: newApplicationDate,
          date_changed: dateChanged,
          member_changed: memberChanged,
          old_member_id: memberChanged ? oldMemberId : null,
          new_member_id: memberChanged ? newMemberId : null,
          installments_regenerated: installmentsRegenerated,
          incentives_transferred: memberChanged
        }
      });

      // Show appropriate success message based on what was changed
      let successMessage = "Pengajuan kredit berhasil diperbarui";
      if (installmentsRegenerated && memberChanged) {
        successMessage = "Tanggal pengajuan diubah - angsuran di-regenerate dan insentif ditransfer ke penanggung jawab baru";
      } else if (installmentsRegenerated) {
        successMessage = "Tanggal pengajuan diubah - seluruh angsuran telah di-regenerate dari awal";
      } else if (memberChanged) {
        successMessage = "Penanggung jawab berhasil dipindahkan - seluruh insentif kredit kini milik sales baru";
      }
      toast({
        title: "Berhasil",
        description: successMessage
      });
      setEditDialogOpen(false);
      setSelectedApplication(null);

      // Force reload and trigger events for all related pages
      invalidateApplications();
      window.dispatchEvent(new Event('application-updated'));
      window.dispatchEvent(new Event('installments-updated'));

      // If member changed, trigger member-related events for reports and balance updates
      if (memberChanged) {
        window.dispatchEvent(new Event('member-stats-updated'));
        window.dispatchEvent(new Event('member-balance-updated'));
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Gagal memperbarui pengajuan",
        variant: "destructive"
      });
    }
  };
  const canApprove = role === "owner" || role === "admin";

  // Open name plate selection dialog
  const openNamePlateDialog = async () => {
    try {
      setIsLoadingNamePlates(true);
      setNamePlateDialogOpen(true);
      
      // Fetch all active credit applications (disbursed, unpaid)
      const { data: activeApps, error } = await supabase
        .from('credit_applications')
        .select(`
          id,
          application_number,
          application_date,
          amount_approved,
          amount_requested,
          tenor_months,
          customers:customer_id (
            full_name,
            id_number,
            photo_url
          ),
          members:member_id (
            full_name
          )
        `)
        .in('status', ['approved', 'disbursed', 'unpaid'])
        .order('application_number', { ascending: true });

      if (error) throw error;

      setNamePlateApps(activeApps || []);
    } catch (error: any) {
      console.error('Error loading name plates:', error);
      toast({
        title: "Gagal memuat data",
        description: error.message || "Terjadi kesalahan saat memuat data kredit aktif",
        variant: "destructive"
      });
      setNamePlateDialogOpen(false);
    } finally {
      setIsLoadingNamePlates(false);
    }
  };

  // Handler for printing selected name plates
  const handlePrintSelectedNamePlates = async (selectedIds: string[], action: 'print' | 'download') => {
    try {
      setIsBulkPrinting(true);

      // Filter selected applications
      const selectedApps = namePlateApps.filter(app => selectedIds.includes(app.id));

      if (selectedApps.length === 0) {
        toast({
          title: "Tidak ada yang dipilih",
          description: "Pilih minimal satu name plate untuk dicetak",
          variant: "destructive"
        });
        return;
      }

      // Transform data for bulk PDF generation
      const namePlateDataArray = selectedApps.map(app => ({
        businessName: businessName || 'Sistem Kredit',
        logoUrl: logoUrl || undefined,
        customerName: (app.customers as any)?.full_name || '',
        customerId: (app.customers as any)?.id_number || '',
        customerPhotoUrl: (app.customers as any)?.photo_url || undefined,
        applicationNumber: app.application_number || '',
        applicationDate: app.application_date || undefined,
        loanAmount: app.amount_approved || app.amount_requested,
        tenorMonths: app.tenor_months,
        memberName: (app.members as any)?.full_name || '',
      }));

      // Generate bulk PDF with specified action
      const count = await generateBulkNamePlatePDF(namePlateDataArray, action);
      
      toast({
        title: "Berhasil",
        description: action === 'print' 
          ? `${count} Name Plate berhasil dikirim ke printer`
          : `${count} Name Plate berhasil didownload dalam satu file PDF`
      });

      setNamePlateDialogOpen(false);
    } catch (error: any) {
      console.error('Bulk print error:', error);
      toast({
        title: "Gagal mencetak",
        description: error.message || "Terjadi kesalahan saat mencetak name plate",
        variant: "destructive"
      });
    } finally {
      setIsBulkPrinting(false);
    }
  };

  // Server-side pagination - no need for client-side filtering
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  const paginatedApplications = applications; // Already paginated from server

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Helper untuk membatasi nomor halaman yang ditampilkan
  const getPaginationRange = () => {
    const delta = isMobile ? 1 : 2;
    const range: (number | string)[] = [];
    const rangeWithDots: (number | string)[] = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }
    if (currentPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }
    rangeWithDots.push(...range);
    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push('...', totalPages);
    } else if (totalPages > 1) {
      rangeWithDots.push(totalPages);
    }
    return rangeWithDots;
  };
  return <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 w-full max-w-full overflow-hidden mb-3">
        <div className="flex items-center gap-3">
          {/* Bulk Print Name Plates Button - Only for owner/admin */}
          {(isOwner || isAdmin) && (
            <Button
              variant="outline"
              size="sm"
              onClick={openNamePlateDialog}
              disabled={isBulkPrinting || isLoadingNamePlates}
              className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
            >
              {(isBulkPrinting || isLoadingNamePlates) ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Printer className="h-4 w-4 mr-2" />
              )}
              {isBulkPrinting ? 'Memproses...' : 'Cetak Name Plate'}
            </Button>
          )}
        </div>
        {!isKasir && (
          <ResponsiveDialog open={dialogOpen} onOpenChange={open => {
          setDialogOpen(open);
          if (open && isSales && currentMemberId) {
            form.setValue("member_id", currentMemberId);
          }
        }}>
            <ResponsiveDialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="h-4 w-4 mr-2" />
                Ajukan Kredit
              </Button>
            </ResponsiveDialogTrigger>
          <ResponsiveDialogContent className="max-w-2xl">
            <ResponsiveDialogHeader>
              <ResponsiveDialogTitle>Pengajuan Kredit Baru</ResponsiveDialogTitle>
            </ResponsiveDialogHeader>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(handleFormSubmit, (errors) => {
                  console.error('[Applications] Form validation failed', errors);
                  toast({
                    title: 'Form belum lengkap',
                    description: 'Periksa kembali isian nasabah, penanggung jawab, jumlah, tenor, dan tanggal pengajuan.',
                    variant: 'destructive',
                  });
                })}
                className="space-y-4"
              >
                <FormField control={form.control} name="customer_id" render={({
                field
              }) => <FormItem className="flex flex-col">
                      <FormLabel>Nasabah</FormLabel>
                      <Popover open={customerSearchOpen} onOpenChange={setCustomerSearchOpen}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button variant="outline" role="combobox" className={cn("w-full justify-between", !field.value && "text-muted-foreground")}>
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  {field.value ? (
                                    <>
                                      <span className="truncate">{eligibleCustomers.find(customer => customer.id === field.value)?.full_name}</span>
                                      {(() => {
                                        const selectedCustomer = eligibleCustomers.find(customer => customer.id === field.value);
                                        const badge = selectedCustomer?.achievementBadge;
                                      if (badge && badge.badge_level && badge.badge_level !== 'none') {
                                        return (
                                          <AchievementBadge 
                                            badgeLevel={badge.badge_level}
                                            badgeName={badge.badge_name}
                                            badgeDescription={badge.badge_description}
                                            consecutivePayments={badge.consecutive_on_time_payments}
                                            onTimePercentage={badge.on_time_percentage}
                                            size="sm"
                                            showDetails={false}
                                          />
                                        );
                                      }
                                      return null;
                                    })()}
                                  </>
                                ) : (
                                  "Cari nasabah..."
                                )}
                              </div>
                              <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-[var(--radix-popper-anchor-width)] min-w-[500px] max-w-[90vw] p-0" align="start" sideOffset={8}>
                          <Command>
                            <CommandInput placeholder="Ketik nama atau ID nasabah..." value={customerSearchQuery} onValueChange={setCustomerSearchQuery} />
                            <CommandList>
                              <CommandEmpty>
                                {(() => {
                                  // Check if searched customer exists in excluded list
                                  const searchLower = customerSearchQuery.toLowerCase().trim();
                                  if (searchLower) {
                                    const excluded = Array.from(excludedCustomers.values()).find(
                                      item => 
                                        item.customer.full_name.toLowerCase().includes(searchLower) ||
                                        item.customer.id_number?.toLowerCase().includes(searchLower) ||
                                        item.customer.phone?.toLowerCase().includes(searchLower) ||
                                        item.customer.nik?.toLowerCase().includes(searchLower)
                                    );
                                    
                                    if (excluded) {
                                      return (
                                        <div className="p-4 text-sm">
                                          <div className="flex items-start gap-2">
                                            <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
                                            <div className="space-y-1">
                                              <p className="font-medium text-foreground">
                                                {excluded.customer.full_name}
                                              </p>
                                              <p className="text-muted-foreground">
                                                Tidak dapat mengajukan kredit
                                              </p>
                                              <p className="text-amber-600 dark:text-amber-400 font-medium">
                                                Alasan: {excluded.reason}
                                              </p>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    }
                                  }
                                  return <span>Nasabah tidak ditemukan.</span>;
                                })()}
                              </CommandEmpty>
                              <CommandGroup>
                                {eligibleCustomers
                                  .filter(customer => {
                                    // Filter by search query
                                    const searchLower = customerSearchQuery.toLowerCase();
                                    const matchesSearch = customer.full_name.toLowerCase().includes(searchLower) || 
                                                         customer.id_number?.toLowerCase().includes(searchLower) || 
                                                         customer.phone?.toLowerCase().includes(searchLower);
                                    
                                    return matchesSearch;
                                  })
                                   .map(customer => <CommandItem key={customer.id} value={`${customer.full_name}-${customer.id_number}-${customer.phone}`} keywords={[customer.full_name, customer.id_number || '', customer.phone || '']} onSelect={() => {
                             form.setValue("customer_id", customer.id);
                             setCustomerSearchOpen(false);
                             setCustomerSearchQuery("");
                           }}>
                                      <div className="flex items-start justify-between gap-3 w-full">
                                        <div className="flex flex-col flex-1 min-w-0">
                                          <span className="font-medium break-words whitespace-normal leading-tight">{customer.full_name}</span>
                                          <span className="text-sm text-muted-foreground break-words whitespace-normal leading-tight">
                                            ID: {customer.id_number} | {customer.phone}
                                          </span>
                                        </div>
                                        {customer.achievementBadge && customer.achievementBadge.badge_level && customer.achievementBadge.badge_level !== 'none' && (
                                          <div className="flex-shrink-0">
                                            <AchievementBadge 
                                              badgeLevel={customer.achievementBadge.badge_level}
                                              badgeName={customer.achievementBadge.badge_name}
                                              badgeDescription={customer.achievementBadge.badge_description}
                                              consecutivePayments={customer.achievementBadge.consecutive_on_time_payments}
                                              onTimePercentage={customer.achievementBadge.on_time_percentage}
                                              size="sm"
                                              showDetails={false}
                                            />
                                          </div>
                                        )}
                                      </div>
                                    </CommandItem>)}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>} />

                <FormField control={form.control} name="member_id" render={({
                field
              }) => <FormItem className="flex flex-col">
                      <FormLabel>Anggota Penanggung Jawab</FormLabel>
                      {isOwner || isAdmin ? <Popover open={memberSearchOpen} onOpenChange={setMemberSearchOpen}>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button variant="outline" role="combobox" className={cn("w-full justify-between", !field.value && "text-muted-foreground")}>
                                {field.value ? members.find(member => member.id === field.value)?.full_name : "Cari anggota penanggung jawab..."}
                                <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-[var(--radix-popper-anchor-width)] min-w-[500px] max-w-[90vw] p-0" align="start" sideOffset={8}>
                            <Command>
                              <CommandInput placeholder="Ketik nama anggota..." value={memberSearchQuery} onValueChange={setMemberSearchQuery} />
                              <CommandList>
                                <CommandEmpty>Anggota tidak ditemukan.</CommandEmpty>
                                <CommandGroup>
                                  {members.filter(member => {
                            const searchLower = memberSearchQuery.toLowerCase();
                            return member.full_name.toLowerCase().includes(searchLower) || member.member_number?.toLowerCase().includes(searchLower) || member.position?.toLowerCase().includes(searchLower);
                          }).map(member => <CommandItem key={member.id} value={`${member.full_name}-${member.member_number}-${member.position}`} keywords={[member.full_name, member.member_number || '', member.position || '']} onSelect={() => {
                            form.setValue("member_id", member.id);
                            setMemberSearchOpen(false);
                            setMemberSearchQuery("");
                          }}>
                                        <div className="flex flex-col w-full">
                                          <span className="font-medium break-words whitespace-normal leading-tight">{member.full_name}</span>
                                          <span className="text-sm text-muted-foreground break-words whitespace-normal leading-tight">
                                            {member.position} {member.member_number ? `| No: ${member.member_number}` : ''}
                                          </span>
                                        </div>
                                      </CommandItem>)}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover> : <FormControl>
                          <Input value={members.find(m => m.id === field.value)?.full_name || "Memuat..."} disabled className="bg-muted" />
                        </FormControl>}
                      <FormMessage />
                    </FormItem>} />

                <FormField control={form.control} name="amount_requested" render={({
                field
              }) => <FormItem>
                      <FormLabel>Jumlah Pengajuan</FormLabel>
                      <FormControl>
                        <CurrencyInput placeholder="0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>} />

                <FormField control={form.control} name="tenor_months" render={({
                field
              }) => {
                const selectedTenor = parseInt(field.value) || 0;
                const isShortTenor = selectedTenor > 0 && selectedTenor <= 3;
                const isLongTenor = selectedTenor >= 4;
                return <FormItem>
                        <FormLabel>Tenor (Bulan)</FormLabel>
                        <Select onValueChange={async value => {
                    field.onChange(value);
                    const rate = await getInterestRate(parseInt(value));
                    toast({
                      title: `Suku bunga: ${rate}%`,
                      description: `Untuk tenor ${value} bulan`
                    });
                  }} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih tenor" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Array.from({
                        length: appSettings?.max_tenor_months || 24
                      }, (_, i) => i + 1).map(month => <SelectItem key={month} value={month.toString()}>
                                {month} bulan - {getInterestRateSync(month)}%
                              </SelectItem>)}
                          </SelectContent>
                        </Select>
                        {isShortTenor && <div className="flex items-start gap-2 mt-2 p-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 rounded-md">
                            <CalendarIcon className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                              <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
                                Angsuran Pertama: Bulan Berikutnya
                              </p>
                              <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
                                Untuk tenor 1-3 bulan, angsuran pertama dimulai di bulan berikutnya setelah pencairan
                              </p>
                            </div>
                          </div>}
                        {isLongTenor && appSettings?.first_installment_type === 'paid_upfront' && <div className="flex items-start gap-2 mt-2 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-md">
                            <CalendarIcon className="h-4 w-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                              <p className="text-sm font-medium text-amber-900 dark:text-amber-100">
                                Angsuran Pertama: Potong Di Awal
                              </p>
                              <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                                Untuk tenor 4+ bulan, angsuran pertama dipotong saat pencairan (sesuai pengaturan owner)
                              </p>
                            </div>
                          </div>}
                        {isLongTenor && appSettings?.first_installment_type !== 'paid_upfront' && <div className="flex items-start gap-2 mt-2 p-3 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900 rounded-md">
                            <CalendarIcon className="h-4 w-4 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                              <p className="text-sm font-medium text-green-900 dark:text-green-100">
                                Angsuran Pertama: Bulan Berikutnya
                              </p>
                              <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                                Untuk tenor 4+ bulan, angsuran pertama dimulai di bulan berikutnya (sesuai pengaturan owner)
                              </p>
                            </div>
                          </div>}
                        <FormMessage />
                      </FormItem>;
              }} />

                {(isOwner || isAdmin) && <FormField control={form.control} name="application_date" render={({
                field
              }) => <FormItem className="flex flex-col">
                        <FormLabel>Tanggal Pengajuan Kredit</FormLabel>
                        <FormControl>
                          <DatePicker 
                            value={field.value} 
                            onChange={field.onChange} 
                            placeholder="dd/MM/yyyy"
                            maxDate={getTodayInWIB()}
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground mt-1">
                          Tanggal pengajuan tidak boleh lebih dari hari ini. Pilih tanggal lalu untuk data historis.
                        </p>
                        <FormMessage />
                      </FormItem>} />}

                <FormField control={form.control} name="collateral_description" render={({
                field
              }) => <FormItem>
                      <FormLabel>Deskripsi Jaminan <span className="text-destructive">*</span></FormLabel>
                      <FormControl>
                        <Textarea placeholder="Deskripsikan jaminan (wajib diisi)..." {...field} />
                      </FormControl>
                      <FormDescription className="text-xs">Kolom ini wajib diisi untuk melanjutkan pengajuan</FormDescription>
                      <FormMessage />
                    </FormItem>} />

                 {simulation && <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <span className="text-primary">💰</span> Rincian Pengajuan & Angsuran
                      </CardTitle>
                      <p className="text-xs text-muted-foreground mt-1">
                        Perhitungan otomatis berdasarkan pengaturan sistem owner
                      </p>
                      {simulation.badgeLevel && simulation.discountApplied > 0 && (
                        <div className="mt-3 p-3 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border border-green-200 dark:border-green-900 rounded-md">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">🎉</span>
                            <div>
                              <p className="text-sm font-semibold text-green-900 dark:text-green-100">
                                Diskon Badge {simulation.badgeLevel}!
                              </p>
                              <p className="text-xs text-green-700 dark:text-green-300 mt-0.5">
                                Bunga Normal: {simulation.baseInterestRate}% → Diskon: -{simulation.discountApplied}% → <strong>Bunga Final: {simulation.finalInterestRate}%</strong>
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      {(() => {
                    const selectedTenor = parseInt(form.watch("tenor_months")) || 0;
                    const isShortTenor = selectedTenor > 0 && selectedTenor <= 3;
                    if (isShortTenor) {
                      return <div className="mt-3 p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md border border-blue-300 dark:border-blue-700">
                              <p className="text-xs font-medium text-blue-900 dark:text-blue-100">
                                📅 Tenor 1-3 bulan: Angsuran pertama otomatis dimulai bulan berikutnya
                              </p>
                            </div>;
                    } else if (selectedTenor >= 4 && simulation.firstInstallmentDeducted) {
                      return <div className="mt-3 p-2 bg-amber-100 dark:bg-amber-900/30 rounded-md border border-amber-300 dark:border-amber-700">
                              <p className="text-xs font-medium text-amber-900 dark:text-amber-100">
                                📅 Tenor 4+ bulan: Angsuran pertama dipotong di awal (sesuai pengaturan owner)
                              </p>
                            </div>;
                    } else if (selectedTenor >= 4) {
                      return <div className="mt-3 p-2 bg-green-100 dark:bg-green-900/30 rounded-md border border-green-300 dark:border-green-700">
                              <p className="text-xs font-medium text-green-900 dark:text-green-100">
                                📅 Tenor 4+ bulan: Angsuran pertama dimulai bulan berikutnya (sesuai pengaturan owner)
                              </p>
                            </div>;
                    }
                    return null;
                  })()}
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Requested Amount */}
                      <div className="bg-muted/50 rounded-lg p-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Jumlah Pengajuan</span>
                          <span className="text-lg font-bold">{formatRupiah(parseFloat(form.watch("amount_requested")) || 0)}</span>
                        </div>
                      </div>

                      {/* Deductions */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Potongan Pencairan:</p>
                        {simulation.adminFee > 0 && <div className="flex justify-between text-sm pl-3 border-l-2 border-destructive/30">
                            <span className="text-muted-foreground">Biaya Admin</span>
                            <span className="font-medium text-destructive">-{formatRupiah(simulation.adminFee)}</span>
                          </div>}
                        {simulation.firstInstallmentDeducted && <div className="flex justify-between text-sm pl-3 border-l-2 border-destructive/30">
                            <span className="text-muted-foreground">Angsuran Pertama (Potong di Awal)</span>
                            <span className="font-medium text-destructive">-{formatRupiah(simulation.monthlyInstallment)}</span>
                          </div>}
                        {simulation.adminFee === 0 && !simulation.firstInstallmentDeducted && <p className="text-xs text-muted-foreground italic pl-3">Tidak ada potongan</p>}
                      </div>

                      {/* Net Disbursement Section - Most Important */}
                      <div className="bg-background rounded-lg p-4 border border-primary/30 shadow-sm">
                        <p className="text-sm text-muted-foreground mb-1">Dana yang Diterima Saat Pencairan</p>
                        <p className="text-3xl font-bold text-primary">
                          {formatRupiah(simulation.netDisbursement)}
                        </p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {simulation.firstInstallmentDeducted ? `Sisa ${form.watch("tenor_months") ? parseInt(form.watch("tenor_months")) - 1 : 0} angsuran lagi` : `Total ${form.watch("tenor_months") || 0} angsuran`}
                        </p>
                      </div>

                      {/* Monthly Installment */}
                      <div className="bg-background rounded-lg p-4 border border-border">
                        <p className="text-sm text-muted-foreground mb-1">Angsuran per Bulan</p>
                        <p className="text-2xl font-bold text-foreground">
                          {formatRupiah(simulation.monthlyInstallment)}
                        </p>
                        <div className="mt-2 pt-2 border-t space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">• Pokok</span>
                            <span className="font-medium">{formatRupiah(simulation.principalPerMonth)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">• Bunga</span>
                            <span className="font-medium">{formatRupiah(simulation.interestPerMonth)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Total Payment Summary */}
                      <div className="pt-3 border-t bg-muted/50 rounded-lg p-3">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Total Bunga Keseluruhan</span>
                            <span className="text-base font-semibold">{formatRupiah(simulation.totalInterest)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Total Pembayaran (Semua Angsuran)</span>
                            <span className="text-lg font-bold text-primary">{formatRupiah(simulation.totalPayment)}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>}

                {/* Inline Progress Indicator */}
                {isSubmitting && progressMessage && !showSuccess && (
                  <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <Loader2 className="h-5 w-5 animate-spin text-primary" />
                      <span className="text-sm font-medium">{progressMessage}</span>
                    </div>
                    <Progress value={progressValue} className="h-2" />
                    <p className="text-xs text-muted-foreground text-center">
                      Mohon tunggu, jangan tutup form ini...
                    </p>
                  </div>
                )}
                
                {/* Success Animation */}
                <SuccessCheckmark 
                  show={showSuccess} 
                  message="Pengajuan kredit berhasil dibuat!"
                />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} disabled={isSubmitting}>
                    Batal
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Memproses...
                      </span>
                    ) : "Ajukan"}
                  </Button>
                </div>
              </form>
            </Form>
          </ResponsiveDialogContent>
        </ResponsiveDialog>
        )}
        
        {/* Dialog Konfirmasi Pernyataan Penanggung Jawab */}
        <AlertDialog open={confirmationDialogOpen} onOpenChange={setConfirmationDialogOpen}>
          <AlertDialogContent className="max-w-lg">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-lg font-semibold text-center">
                Pernyataan Penanggung Jawab Kredit
              </AlertDialogTitle>
              <AlertDialogDescription asChild>
                <div className="text-sm text-muted-foreground space-y-4 pt-4">
                  <p className="text-center font-medium text-foreground">SURAT PERNYATAAN</p>
                  <p className="text-justify leading-relaxed">
                    Dengan ini saya{" "}
                    <span className="font-semibold text-foreground">
                      {pendingFormValues?.member_id 
                        ? members.find(m => m.id === pendingFormValues.member_id)?.full_name || "-"
                        : "-"}
                    </span>{" "}
                    menyatakan bersedia menjadi penanggung jawab dan sebagai saksi serta menjamin 
                    kelancaran pembayaran angsuran kredit ini sampai selesai.
                  </p>
                  <p className="text-justify leading-relaxed">
                    Apabila nasabah{" "}
                    <span className="font-semibold text-foreground">
                      {pendingFormValues?.customer_id 
                        ? eligibleCustomers.find(c => c.id === pendingFormValues.customer_id)?.full_name || "-"
                        : "-"}
                    </span>{" "}
                    melarikan diri dan tidak membayar angsuran, maka saya yang akan menggantikan 
                    dan membayar seluruh sisa pinjaman yang belum dibayarkan.
                  </p>
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="flex-col sm:flex-row gap-2 mt-4">
              <AlertDialogCancel 
                onClick={handleCancelConfirmation}
                className="w-full sm:w-auto"
              >
                Batal
              </AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleConfirmSubmit}
                className="w-full sm:w-auto"
              >
                Setuju
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      <Card className="w-full max-w-full overflow-hidden animate-fade-in">
        <CardHeader>
          <div className="flex flex-col gap-4 w-full max-w-full overflow-hidden">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full max-w-full overflow-hidden">
              <div className="flex items-center gap-2">
                <CardTitle className="text-base sm:text-lg md:text-xl truncate max-w-full">Semua Pengajuan: {totalCount}</CardTitle>
                <ViewToggle viewMode={viewMode} onToggle={toggleView} />
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap sm:flex-nowrap sm:ml-auto">
                <Select value={selectedMemberFilter} onValueChange={setSelectedMemberFilter}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Filter Penanggung Jawab" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Penanggung Jawab</SelectItem>
                    {members.map(member => <SelectItem key={member.id} value={member.id}>
                        {member.full_name}
                      </SelectItem>)}
                  </SelectContent>
                </Select>
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input placeholder="Cari ID, nama nasabah..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-9 w-full" />
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          <AnimatedViewTransition viewMode={viewMode}>
          {(isMobile || viewMode === 'card') ? <div className="space-y-3 w-full max-w-full">
              {paginatedApplications.length === 0 ? <div className="text-center py-8 text-muted-foreground">
                  Tidak ada data pengajuan
                </div> : paginatedApplications.map(app => {
            const appStatus = getApplicationStatus(app.id);
            const cardColorClass = app.status === 'approved' || app.status === 'disbursed' ? getStatusColor(appStatus) : '';
            const statusIcon = appStatus === 'paid' ? <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" /> : appStatus === 'active-overdue' ? <AlertTriangle className="h-4 w-4 text-red-600 flex-shrink-0" /> : appStatus === 'active-penalty' ? <AlertTriangle className="h-4 w-4 text-red-500 flex-shrink-0" /> : appStatus === 'active-clean' ? <div className="h-2 w-2 rounded-full bg-yellow-500 flex-shrink-0" /> : null;

            // Calculate progress for approved/disbursed applications
            const appInstallments = installments.filter(i => i.application_id === app.id);
            const totalInstallments = appInstallments.length;
            const paidInstallments = appInstallments.filter(i => i.status === 'paid').length;
            const progressValue = totalInstallments > 0 ? paidInstallments / totalInstallments * 100 : 0;
            const progressLabel = `${paidInstallments}/${totalInstallments} Angsuran`;
            const isSilenced = appInstallments.some(i => i.is_silenced);

            // Tentukan tipe angsuran pertama berdasarkan SNAPSHOT saat kredit dibuat
            // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama
            const tenor = app.tenor_months;
            const effectiveFirstInstallmentType = tenor < 4 ? 'next_month' : (app.first_installment_type || 'next_month');

            console.log('[Applications] First installment label data', {
              appId: app.id,
              tenor,
              appFirstType: app.first_installment_type,
              globalFirstType: appSettings?.first_installment_type,
              effectiveFirstInstallmentType,
            });

            return <MobileDataCard key={app.id} id={app.customers?.id_number || app.application_number} photoUrl={app.customers?.photo_url} name={app.customers?.full_name || "Unknown"} subtitle={`${formatRupiah(app.amount_requested)} - ${app.tenor_months} bulan`} onClick={() => {
              setSelectedApplication(app);
              setShowDetail(true);
            }}
              className={cardColorClass}
              statusIndicator={statusIcon}
              progressValue={app.status === 'approved' || app.status === 'disbursed' ? progressValue : undefined}
              progressLabel={app.status === 'approved' || app.status === 'disbursed' ? progressLabel : undefined}
              disbursedAt={app.status !== 'pending' && app.status !== 'rejected' ? (app.disbursed_at || app.approved_at) : undefined}
              firstInstallmentType={app.status !== 'pending' && app.status !== 'rejected' ? effectiveFirstInstallmentType : undefined}
              isSilenced={isSilenced}
              responsibleMember={app.members ? {
                full_name: app.members.full_name,
                position: app.members.position,
              } : null}
            />;
          })}
            </div> : <div className="w-full">
              <ScrollArea className="h-[calc(100vh-280px)] w-full rounded-md border">
                <div className="overflow-x-auto">
                  <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">No. ID</TableHead>
                <TableHead className="min-w-[150px]">Nasabah</TableHead>
                <TableHead className="hidden xl:table-cell">Penanggung Jawab</TableHead>
                <TableHead className="min-w-[120px]">Jumlah</TableHead>
                <TableHead className="hidden">Tgl Pengajuan</TableHead>
                <TableHead className="w-[80px]">Tenor</TableHead>
                <TableHead className="hidden xl:table-cell">Bunga</TableHead>
                <TableHead className="min-w-[120px]">Angsuran</TableHead>
                <TableHead className="hidden 2xl:table-cell">Jaminan</TableHead>
                <TableHead className="hidden lg:table-cell min-w-[100px]">Perjanjian</TableHead>
                <TableHead className="min-w-[100px]">Status</TableHead>
                <TableHead className="hidden xl:table-cell">Tgl Pencairan</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedApplications.map(app => {
                    const amount = Number(app.status === 'approved' || app.status === 'disbursed' ? app.amount_approved : app.amount_requested);
                    const monthlyInstallment = calculateMonthlyInstallment(amount, app.tenor_months, app.interest_rate);
                    const appStatus = getApplicationStatus(app.id);
                    const rowColorClass = app.status === 'approved' || app.status === 'disbursed' ? getStatusColor(appStatus) : '';
                    return <TableRow key={app.id} className={cn(rowColorClass, "transition-colors cursor-pointer hover:bg-muted/50")} onClick={() => {
                      setSelectedApplication(app);
                      setShowDetail(true);
                    }}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {appStatus === 'paid' && <CheckCircle className="h-4 w-4 text-green-600" />}
                        {appStatus === 'active-overdue' && <AlertTriangle className="h-4 w-4 text-red-600" />}
                        {appStatus === 'active-penalty' && <AlertTriangle className="h-4 w-4 text-red-500" />}
                        {appStatus === 'active-clean' && <div className="h-2 w-2 rounded-full bg-yellow-500" />}
                        <span className="truncate">{app.customers?.id_number}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <ClickableAvatar 
                          src={app.customers?.photo_url}
                          alt={app.customers?.full_name}
                          fallback={app.customers?.full_name?.charAt(0)?.toUpperCase() || "N"}
                          className="h-8 w-8 flex-shrink-0"
                        />
                        <div className="flex flex-col gap-1">
                          <span className="truncate">{app.customers?.full_name}</span>
                          {appStatus === 'paid' && <Badge className="bg-green-500 hover:bg-green-600 text-white text-[10px] px-1.5 py-0 h-4 w-fit">
                              ✓ LUNAS
                            </Badge>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden xl:table-cell">{app.members?.full_name || "-"}</TableCell>
                    <TableCell className="whitespace-nowrap">{formatRupiah(Number(app.amount_requested))}</TableCell>
                    <TableCell className="hidden whitespace-nowrap">
                      {formatDate(app.application_date || app.created_at)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">{app.tenor_months} bln</TableCell>
                    <TableCell className="hidden xl:table-cell">{app.interest_rate}%</TableCell>
                    <TableCell className="font-semibold text-primary whitespace-nowrap">
                      {formatRupiah(monthlyInstallment)}
                    </TableCell>
                    <TableCell className="hidden 2xl:table-cell">
                      <span className="truncate block max-w-[150px]">{app.collateral_description || "tidak ada"}</span>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      {app.status === "approved" && <div className="flex flex-col gap-1 min-w-[100px]">
                          <Button size="sm" variant="outline" className="w-full justify-center text-xs px-2 h-7" onClick={e => {
                            e.stopPropagation();
                            handleAgreementPreview(app);
                          }}>
                            <Download className="h-3 w-3 mr-1" />
                            <span className="truncate">Perjanjian</span>
                          </Button>
                          <Button size="sm" variant="outline" className="w-full justify-center text-xs px-2 h-7" onClick={async e => {
                            e.stopPropagation();
                            // Fetch app settings to calculate correct amounts
                            const {
                              data: settings
                            } = await supabase.rpc('get_public_app_settings');
                            let netAmount = app.amount_requested;
                            let firstInstallmentAmount = undefined;
                            let adminFee = undefined;

                            // Calculate first installment if paid upfront
                            // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama
                            if (app.tenor_months >= 4 && (settings as any)?.first_installment_type === 'paid_upfront') {
                              const {
                                data: firstInstallment
                              } = await supabase.from("installments").select("total_amount").eq("application_id", app.id).eq("installment_number", 1).maybeSingle();
                              if (firstInstallment) {
                                firstInstallmentAmount = firstInstallment.total_amount;
                                netAmount -= firstInstallmentAmount;
                              }
                            }

                            // Calculate admin fee as percentage if enabled (with minimum)
                            if ((settings as any)?.admin_fee_enabled && (settings as any)?.admin_fee_amount > 0) {
                              const calculatedFee = Math.round(app.amount_requested * ((settings as any).admin_fee_amount / 100));
                              const adminFeeMinimum = (settings as any)?.admin_fee_minimum || 0;
                              adminFee = Math.max(calculatedFee, adminFeeMinimum);
                              netAmount -= adminFee;
                            }

                            // Generate WhatsApp message
                            const message = generateDisbursementReceiptMessage({
                              customerName: app.customers?.full_name || '',
                              memberName: app.members?.full_name || '',
                              disbursementDate: app.approved_at || '',
                              amountRequested: app.amount_requested,
                              firstInstallmentAmount,
                              adminFee,
                              netAmount,
                              applicationNumber: app.application_number,
                              creditScore: app.customers?.credit_score,
                              customerIdNumber: app.customers?.id_number,
                              dateOfBirth: app.customers?.date_of_birth
                            });

                            // Get customer phone number with fallback fetch
                            let customerPhone = (app.customers?.phone || '').trim();
                            if (!customerPhone) {
                              const {
                                data: fetched
                              } = await supabase.from('customers').select('phone').eq('id', app.customer_id).maybeSingle();
                              customerPhone = (fetched as any)?.phone || '';
                            }
                            if (!customerPhone) {
                              toast({
                                title: "Error",
                                description: "Nomor telepon nasabah tidak tersedia",
                                variant: "destructive"
                              });
                              return;
                            }

                            // Buka WhatsApp menggunakan helper yang sama dengan halaman WhatsApp Notification
                            openWhatsAppChat(customerPhone, message);
                            toast({
                              title: "Berhasil",
                              description: "Membuka WhatsApp..."
                            });
                          }}>
                            <MessageSquare className="h-3 w-3 mr-1" />
                            <span className="truncate">Struk</span>
                          </Button>
                        </div>}
                    </TableCell>
                    <TableCell>
                      <div className="max-w-[120px]">{getStatusBadge(app)}</div>
                    </TableCell>
                    <TableCell className="hidden xl:table-cell whitespace-nowrap">
                      {app.approved_at ? formatDate(app.approved_at) : "-"}
                    </TableCell>
                  </TableRow>;
                  })}
            </TableBody>
          </Table>
                </div>
              </ScrollArea>
            </div>}
          </AnimatedViewTransition>
        </CardContent>
      </Card>

      <ApplicationDetailDialog open={showDetail} onOpenChange={setShowDetail} application={selectedApplication} installments={installments} canApprove={canApprove} onApprove={openApprovalDialog} onReject={handleReject} onDownloadAgreement={handleAgreementPreview} onSendWhatsApp={async app => {
      // Fetch app settings to calculate correct amounts
      const {
        data: settings
      } = await supabase.rpc('get_public_app_settings');
      let netAmount = app.amount_requested;
      let firstInstallmentAmount = undefined;
      let adminFee = undefined;

      // Calculate first installment if paid upfront
      // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama
      if (app.tenor_months >= 4 && (settings as any)?.first_installment_type === 'paid_upfront') {
        const {
          data: firstInstallment
        } = await supabase.from("installments").select("total_amount").eq("application_id", app.id).eq("installment_number", 1).maybeSingle();
        if (firstInstallment) {
          firstInstallmentAmount = firstInstallment.total_amount;
          netAmount -= firstInstallmentAmount;
        }
      }

      // Use saved admin fee from application (not recalculated from current settings)
      if (app.admin_fee_amount && app.admin_fee_amount > 0) {
        adminFee = app.admin_fee_amount;
        netAmount -= adminFee;
      }

      // Generate WhatsApp message
      const message = generateDisbursementReceiptMessage({
        customerName: app.customers?.full_name || '',
        memberName: app.members?.full_name || '',
        disbursementDate: app.approved_at || '',
        amountRequested: app.amount_requested,
        firstInstallmentAmount,
        adminFee,
        netAmount,
        applicationNumber: app.application_number,
        creditScore: app.customers?.credit_score,
        customerIdNumber: app.customers?.id_number,
        dateOfBirth: app.customers?.date_of_birth
      });

      // Get customer phone number with fallback fetch
      let customerPhone = (app.customers?.phone || '').trim();
      if (!customerPhone) {
        const {
          data: fetched
        } = await supabase.from('customers').select('phone').eq('id', app.customer_id).maybeSingle();
        customerPhone = (fetched as any)?.phone || '';
      }
      if (!customerPhone) {
        toast({
          title: "Error",
          description: "Nomor telepon nasabah tidak tersedia",
          variant: "destructive"
        });
        return;
      }

      // Buka WhatsApp menggunakan helper yang sama dengan halaman WhatsApp Notification
      openWhatsAppChat(customerPhone, message);
      toast({
        title: "Berhasil",
        description: "Membuka WhatsApp..."
      });
    }} onEdit={openEditDialog} onDelete={openDeleteDialog} />

      {totalPages > 1 && <div className="flex justify-center sm:justify-end">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious onClick={() => handlePageChange(Math.max(1, currentPage - 1))} className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
              {getPaginationRange().map((page, idx) => <PaginationItem key={idx}>
                  {page === '...' ? <span className="px-2">...</span> : <PaginationLink onClick={() => handlePageChange(page as number)} isActive={currentPage === page} className="cursor-pointer">
                      {page}
                    </PaginationLink>}
                </PaginationItem>)}
              <PaginationItem>
                <PaginationNext onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))} className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>}

      {disbursementData && <DisbursementReceiptDialog open={disbursementDialogOpen} onOpenChange={setDisbursementDialogOpen} data={disbursementData} />}

      {/* Dialog untuk update No. KK nasabah lama */}
      <UpdateNoKKDialog
        open={updateNoKKDialogOpen}
        onOpenChange={setUpdateNoKKDialogOpen}
        customer={customerNeedingNoKK}
        onSuccess={handleNoKKUpdateSuccess}
      />

      <Dialog open={superCodeDialogOpen} onOpenChange={setSuperCodeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Verifikasi SuperCode
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="supercode">SuperCode</Label>
              <Input 
                id="supercode" 
                type="password" 
                value={superCodeInput} 
                onChange={e => {
                  setSuperCodeInput(e.target.value);
                  setSuperCodeError("");
                }} 
                placeholder="Masukkan SuperCode" 
                className={superCodeError ? "border-destructive" : ""}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    handleSuperCodeSubmit();
                  }
                }} 
              />
              {superCodeError && (
                <p className="text-sm text-destructive">{superCodeError}</p>
              )}
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => {
            setSuperCodeDialogOpen(false);
            setSuperCodeInput("");
            setSuperCodeError("");
          }}>
              Batal
            </Button>
            <Button onClick={handleSuperCodeSubmit}>
              Verifikasi
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Pengajuan Kredit</DialogTitle>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField control={editForm.control} name="customer_id" render={({
              field
            }) => <FormItem>
                    <FormLabel>Nasabah</FormLabel>
                    <FormControl>
                      <Input 
                        value={selectedApplication?.customers?.full_name || ""} 
                        disabled 
                        className="cursor-not-allowed opacity-60"
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground mt-1">Nama nasabah tidak dapat diubah</p>
                    <FormMessage />
                  </FormItem>} />

              <FormField control={editForm.control} name="member_id" render={({
              field
            }) => <FormItem className="flex flex-col">
                    <FormLabel>Anggota Penanggung Jawab</FormLabel>
                    <Popover open={memberSearchOpen} onOpenChange={setMemberSearchOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button variant="outline" role="combobox" className={cn("w-full justify-between", !field.value && "text-muted-foreground")}>
                            {field.value ? members.find(member => member.id === field.value)?.full_name : "Cari anggota penanggung jawab..."}
                            <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-[var(--radix-popper-anchor-width)] min-w-[500px] max-w-[90vw] p-0" align="start" sideOffset={8}>
                        <Command>
                          <CommandInput placeholder="Ketik nama anggota..." value={memberSearchQuery} onValueChange={setMemberSearchQuery} />
                          <CommandList>
                            <CommandEmpty>Anggota tidak ditemukan.</CommandEmpty>
                            <CommandGroup>
                              {members.filter(member => {
                          const searchLower = memberSearchQuery.toLowerCase();
                          return member.full_name.toLowerCase().includes(searchLower) || member.member_number?.toLowerCase().includes(searchLower) || member.position?.toLowerCase().includes(searchLower);
                        }).map(member => <CommandItem key={member.id} value={`${member.full_name}-${member.member_number}-${member.position}`} keywords={[member.full_name, member.member_number || '', member.position || '']} onSelect={() => {
                          editForm.setValue("member_id", member.id);
                          setMemberSearchOpen(false);
                          setMemberSearchQuery("");
                        }}>
                                    <div className="flex flex-col w-full">
                                      <span className="font-medium break-words whitespace-normal leading-tight">{member.full_name}</span>
                                      <span className="text-sm text-muted-foreground break-words whitespace-normal leading-tight">
                                        {member.position} {member.member_number ? `| No: ${member.member_number}` : ''}
                                      </span>
                                    </div>
                                  </CommandItem>)}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>} />

              <FormField control={editForm.control} name="amount_requested" render={({
              field
            }) => <FormItem>
                    <FormLabel>Jumlah Pengajuan</FormLabel>
                    <FormControl>
                      <CurrencyInput 
                        placeholder="0" 
                        {...field} 
                        disabled={!!selectedApplication?.disbursed_at}
                      />
                    </FormControl>
                    {selectedApplication?.disbursed_at && (
                      <p className="text-xs text-muted-foreground mt-1">Tidak dapat diubah setelah dicairkan</p>
                    )}
                    <FormMessage />
                  </FormItem>} />

              <FormField control={editForm.control} name="tenor_months" render={({
              field
            }) => <FormItem>
                    <FormLabel>Tenor (Bulan)</FormLabel>
                    <Select 
                      disabled={!!selectedApplication?.disbursed_at}
                      onValueChange={async value => {
                        field.onChange(value);
                        const rate = await getInterestRate(parseInt(value));
                        toast({
                          title: `Suku bunga: ${rate}%`,
                          description: `Untuk tenor ${value} bulan`
                        });
                      }} 
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger className={selectedApplication?.disbursed_at ? "cursor-not-allowed opacity-60" : ""}>
                          <SelectValue placeholder="Pilih tenor" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Array.from({
                    length: appSettings?.max_tenor_months || 24
                  }, (_, i) => i + 1).map(month => <SelectItem key={month} value={month.toString()}>
                            {month} bulan - {getInterestRateSync(month)}%
                          </SelectItem>)}
                      </SelectContent>
                    </Select>
                    {selectedApplication?.disbursed_at && (
                      <p className="text-xs text-muted-foreground mt-1">Tidak dapat diubah setelah dicairkan</p>
                    )}
                    <FormMessage />
                  </FormItem>} />

              <FormField control={editForm.control} name="application_date" render={({
              field
            }) => <FormItem className="flex flex-col">
                    <FormLabel>Tanggal Pengajuan Kredit</FormLabel>
                    <FormControl>
                      <DatePicker 
                        value={field.value} 
                        onChange={field.onChange} 
                        placeholder="dd/MM/yyyy"
                        maxDate={getTodayInWIB()}
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground mt-1">
                      Tanggal pengajuan tidak boleh lebih dari hari ini
                    </p>
                    <FormMessage />
                  </FormItem>} />

              <FormField control={editForm.control} name="collateral_description" render={({
              field
            }) => <FormItem>
                    <FormLabel>Deskripsi Jaminan (Opsional)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Deskripsikan jaminan jika ada..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>} />

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => {
                setEditDialogOpen(false);
                setSelectedApplication(null);
              }}>
                  Batal
                </Button>
                <Button type="submit">Simpan Perubahan</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <Trash2 className="w-5 h-5" />
              Hapus Pengajuan Kredit
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p>
              Apakah Anda yakin ingin menghapus pengajuan kredit dari nasabah{" "}
              <span className="font-semibold">
                {selectedApplication?.customers?.full_name}
              </span>{" "}
              dengan nomor{" "}
              <span className="font-semibold">
                {selectedApplication?.application_number}
              </span>?
            </p>
            <p className="text-sm text-muted-foreground">
              Tindakan ini tidak dapat dibatalkan.
            </p>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Batal
            </Button>
            <Button variant="destructive" onClick={handleDeleteApplication}>
              Hapus
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Approval Dialog with Disbursement Date */}
      <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Setujui Pengajuan Kredit</DialogTitle>
          </DialogHeader>
          <Form {...disbursementForm}>
            <form onSubmit={disbursementForm.handleSubmit(onDisbursementSubmit)} className="space-y-4">
              <FormField control={disbursementForm.control} name="disbursement_date" render={({
              field
            }) => <FormItem className="flex flex-col">
                    <FormLabel>Tanggal Pencairan</FormLabel>
                    <FormControl>
                      <DatePicker value={field.value} onChange={field.onChange} placeholder="dd/MM/yyyy" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>} />

              <div className="text-sm text-muted-foreground">
                Tanggal ini akan digunakan untuk pembukuan laporan keuangan. Jika tidak diisi, sistem akan menggunakan tanggal hari ini.
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => {
                setApprovalDialogOpen(false);
                setPendingApproval(null);
              }}>
                  Batal
                </Button>
                <Button type="submit">
                  Setujui & Cairkan
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Agreement Preview Dialog */}
      {agreementPreviewData && <AgreementPreviewDialog open={agreementPreviewOpen} onOpenChange={setAgreementPreviewOpen} agreementData={agreementPreviewData} onDownload={handleDownloadAgreement} onSendWhatsApp={handleSendAgreementWhatsApp} />}

      {/* Name Plate Selection Dialog */}
      <NamePlateSelectionDialog
        open={namePlateDialogOpen}
        onOpenChange={setNamePlateDialogOpen}
        applications={namePlateApps}
        isLoading={isLoadingNamePlates}
        onPrint={handlePrintSelectedNamePlates}
        isPrinting={isBulkPrinting}
        businessName={businessName}
        logoUrl={logoUrl}
      />
    </div>;
}