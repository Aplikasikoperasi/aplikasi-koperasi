import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatRupiah } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { FileText, Calendar, DollarSign, User, TrendingUp, Search } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useUserRole } from "@/hooks/useUserRole";
import { useDebounce } from "@/hooks/use-debounce";
interface ApplicationData {
  id: string;
  application_number: string;
  application_date: string;
  customer_name: string;
  customer_id_number: string;
  amount_requested: number;
  amount_approved: number | null;
  tenor_months: number;
  status: string;
  purpose: string;
  interest_rate: number;
  approved_at: string | null;
  disbursed_at: string | null;
  monthly_installment: number | null;
}
export default function SalesApplications() {
  const [applicationsData, setApplicationsData] = useState<ApplicationData[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const itemsPerPage = 15;
  const {
    isSales,
    isOwner,
    isAdmin
  } = useUserRole();
  const fetchApplications = async () => {
    try {
      // Get current user and member_id if sales
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();

      // Build applications query
      let query = supabase.from('credit_applications').select(`
          id,
          application_number,
          application_date,
          amount_requested,
          amount_approved,
          tenor_months,
          status,
          purpose,
          interest_rate,
          approved_at,
          disbursed_at,
          customers (
            full_name,
            id_number
          ),
          installments (
            total_amount
          )
        `);

      // Filter by member_id for sales role
      if (isSales && user) {
        const {
          data: memberData
        } = await supabase.from('members').select('id').eq('user_id', user.id).single();
        if (memberData) {
          query = query.eq('member_id', memberData.id);
        }
      }
      const {
        data: applications,
        error
      } = await query.order('application_date', {
        ascending: false
      });
      if (!error && applications) {
        const formattedData = applications.map(app => ({
          id: app.id,
          application_number: app.application_number,
          application_date: app.application_date,
          customer_name: app.customers?.full_name || '-',
          customer_id_number: app.customers?.id_number || '-',
          amount_requested: app.amount_requested,
          amount_approved: app.amount_approved,
          tenor_months: app.tenor_months,
          status: app.status,
          purpose: app.purpose,
          interest_rate: app.interest_rate,
          approved_at: app.approved_at,
          disbursed_at: app.disbursed_at,
          monthly_installment: app.installments && app.installments.length > 0 ? app.installments[0].total_amount : null
        }));
        setApplicationsData(formattedData);
      }
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    document.title = "Daftar Pengajuan Kredit";

    // Initial fetch
    fetchApplications();

    // Subscribe to realtime changes
    const channel = supabase.channel('sales-applications-realtime').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => {
      console.log('Applications data changed, reloading...');
      fetchApplications();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [isSales]);
  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, {
      label: string;
      variant: "default" | "secondary" | "destructive" | "outline";
    }> = {
      pending: {
        label: "Menunggu",
        variant: "secondary"
      },
      approved: {
        label: "Disetujui",
        variant: "default"
      },
      rejected: {
        label: "Ditolak",
        variant: "destructive"
      },
      disbursed: {
        label: "Dicairkan",
        variant: "default"
      },
      completed: {
        label: "Lunas",
        variant: "default"
      },
      overdue: {
        label: "Menunggak",
        variant: "destructive"
      },
      unpaid: {
        label: "Belum Lunas",
        variant: "secondary"
      },
      partial: {
        label: "Sebagian",
        variant: "secondary"
      }
    };
    const config = statusMap[status] || {
      label: status,
      variant: "outline"
    };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  // Filter data based on selected status and search query
  const filteredData = applicationsData
    .filter(app => filterStatus === "all" || app.status === filterStatus)
    .filter(app => {
      if (!debouncedSearch) return true;
      const search = debouncedSearch.toLowerCase();
      return (
        app.application_number.toLowerCase().includes(search) ||
        app.customer_name.toLowerCase().includes(search) ||
        app.customer_id_number.toLowerCase().includes(search) ||
        app.purpose.toLowerCase().includes(search)
      );
    });

  // Pagination calculations
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentData = filteredData.slice(startIndex, endIndex);
  const goToPage = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Reset to page 1 when filter or search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [filterStatus, debouncedSearch]);

  // Calculate statistics
  const totalApplications = applicationsData.length;
  const approvedCount = applicationsData.filter(a => a.status === 'approved' || a.status === 'disbursed' || a.status === 'completed').length;
  const rejectedCount = applicationsData.filter(a => a.status === 'rejected').length;
  const pendingCount = applicationsData.filter(a => a.status === 'pending').length;
  if (loading) {
    return <div className="w-full p-4 md:p-6">
        <div className="flex items-center gap-3 mb-6">
          <FileText className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-blue-900">Daftar Pengajuan Kredit</h1>
        </div>
        <p className="text-muted-foreground">Memuat data...</p>
      </div>;
  }
  return <div className="w-full p-4 md:p-6">
      <header className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <FileText className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-blue-900">Daftar Pengajuan Kredit</h1>
        </div>
        <p className="text-muted-foreground">
          {isSales ? "Pengajuan Anda" : "Semua Pengajuan"} • Total: {totalApplications} pengajuan
        </p>
        
        {/* Search Filter */}
        <div className="mt-4 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari berdasarkan nomor, nama nasabah, No. ID, atau tujuan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </header>

      {/* Filter */}
      

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {currentData.map(app => <Card key={app.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <CardTitle className="text-base break-all">{app.application_number}</CardTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <User className="h-3 w-3 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground break-words">{app.customer_name}</p>
                  </div>
                </div>
                {getStatusBadge(app.status)}
              </div>
            </CardHeader>
            
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground mb-1">Pengajuan</p>
                  <p className="font-semibold text-blue-900 dark:text-blue-300 break-all">
                    {formatRupiah(app.amount_requested)}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Disetujui</p>
                  <p className="font-semibold text-green-900 dark:text-green-300 break-all">
                    {app.amount_approved ? formatRupiah(app.amount_approved) : '-'}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-border space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Tenor</span>
                  <span className="font-medium">{app.tenor_months} bulan</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    Bunga
                  </span>
                  <span className="font-medium">{app.interest_rate}%</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <DollarSign className="h-3 w-3" />
                    Angsuran/Bulan
                  </span>
                  <span className="font-medium text-primary">
                    {app.monthly_installment ? formatRupiah(app.monthly_installment) : '-'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Tanggal
                  </span>
                  <span className="font-medium">
                    {format(new Date(app.application_date), "dd MMM yyyy", {
                  locale: id
                })}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-border">
                <p className="text-xs text-muted-foreground">Tujuan</p>
                <p className="text-sm font-medium break-words line-clamp-2">{app.purpose}</p>
              </div>

              {app.disbursed_at && <div className="pt-2 border-t border-border">
                  <p className="text-xs text-muted-foreground">Dicairkan</p>
                  <p className="text-sm font-medium">
                    {format(new Date(app.disbursed_at), "dd MMM yyyy HH:mm", {
                locale: id
              })}
                  </p>
                </div>}
            </CardContent>
          </Card>)}
      </div>

      {currentData.length === 0 && <div className="text-center py-12">
          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Tidak ada pengajuan dengan filter yang dipilih</p>
        </div>}

      {/* Pagination Controls */}
      {totalPages > 1 && <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground">
            Menampilkan {startIndex + 1}-{Math.min(endIndex, filteredData.length)} dari {filteredData.length} pengajuan
          </div>
          
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <Button variant="outline" size="sm" onClick={() => goToPage(1)} disabled={currentPage === 1}>
              Pertama
            </Button>
            <Button variant="outline" size="sm" onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1}>
              Sebelumnya
            </Button>
            
            {/* Page numbers */}
            <div className="flex items-center gap-1">
              {Array.from({
            length: Math.min(5, totalPages)
          }, (_, i) => {
            let pageNum;
            if (totalPages <= 5) {
              pageNum = i + 1;
            } else if (currentPage <= 3) {
              pageNum = i + 1;
            } else if (currentPage >= totalPages - 2) {
              pageNum = totalPages - 4 + i;
            } else {
              pageNum = currentPage - 2 + i;
            }
            return <Button key={pageNum} variant={currentPage === pageNum ? "default" : "outline"} size="sm" onClick={() => goToPage(pageNum)} className="min-w-[40px]">
                    {pageNum}
                  </Button>;
          })}
            </div>
            
            <Button variant="outline" size="sm" onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages}>
              Selanjutnya
            </Button>
            <Button variant="outline" size="sm" onClick={() => goToPage(totalPages)} disabled={currentPage === totalPages}>
              Terakhir
            </Button>
          </div>
        </div>}
    </div>;
}