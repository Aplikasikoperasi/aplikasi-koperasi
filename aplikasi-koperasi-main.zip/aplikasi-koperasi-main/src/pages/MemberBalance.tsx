import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Wallet, TrendingUp, Calendar, History } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { MemberBalanceWithdrawal } from "@/components/MemberBalanceWithdrawal";
import { MemberYearEndBonusWithdrawal } from "@/components/MemberYearEndBonusWithdrawal";
import { MemberIncentiveBreakdown } from "@/components/MemberIncentiveBreakdown";
import { Badge } from "@/components/ui/badge";
interface Transaction {
  id: string;
  amount: number;
  type: string;
  description: string;
  created_at: string;
  balance_type?: string;
}
interface WithdrawalRequest {
  id: string;
  amount: number;
  status: string;
  requested_at: string;
  withdrawal_method?: string;
  bank_account_info?: string;
  rejection_reason?: string;
  withdrawal_type?: string;
}
interface MonthlyBalance {
  period_month: string;
  total_earned: number;
  total_withdrawn: number;
  available_balance: number;
  is_held: boolean;
  hold_reason: string | null;
}
export default function MemberBalance() {
  const {
    toast
  } = useToast();
  const [loading, setLoading] = useState(true);
  const [regularBalance, setRegularBalance] = useState(0);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [thrBalance, setThrBalance] = useState(0);
  const [monthlyBalances, setMonthlyBalances] = useState<MonthlyBalance[]>([]);
  const [incentiveEnabled, setIncentiveEnabled] = useState(false);
  const [thrEnabled, setThrEnabled] = useState(false);
  const [thrWithdrawalDate, setThrWithdrawalDate] = useState<number>(7);
  const [creditApplicationEnabled, setCreditApplicationEnabled] = useState(false);
  const [installmentPaymentEnabled, setInstallmentPaymentEnabled] = useState(false);
  const [thrCalculationDetails, setThrCalculationDetails] = useState<{
    totalPayments: number;
    incentiveType: string;
    incentiveAmount: number;
    calculatedTHR: number;
  } | null>(null);
  const [regularIncentiveDetails, setRegularIncentiveDetails] = useState<{
    creditApplicationIncentive: number;
    installmentPaymentIncentive: number;
    totalRegular: number;
  } | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [memberId, setMemberId] = useState<string | null>(null);
  const [isInactive, setIsInactive] = useState(false);
  const [deactivatedAt, setDeactivatedAt] = useState<string | null>(null);
  const [memberRole, setMemberRole] = useState<string>('sales');
  useEffect(() => {
    loadMemberData();
  }, []);

  // Subscribe to realtime changes for incentive settings
  useEffect(() => {
    const channel = supabase.channel("incentive-settings-updates").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "incentive_settings"
    }, (payload: any) => {
      if (payload.new) {
        if (memberRole === 'kasir') {
          setIncentiveEnabled(payload.new.kasir_payment_enabled || false);
          setThrEnabled(payload.new.kasir_holiday_enabled || false);
          setThrWithdrawalDate(payload.new.kasir_year_end_bonus_withdrawal_date || 7);
        } else {
          const creditAppEnabled = payload.new.credit_application_enabled || false;
          const installmentEnabled = payload.new.installment_payment_enabled || false;
          const regularIncentiveActive = creditAppEnabled || installmentEnabled;
          setIncentiveEnabled(regularIncentiveActive);
          setCreditApplicationEnabled(creditAppEnabled);
          setInstallmentPaymentEnabled(installmentEnabled);
          setThrEnabled(payload.new.holiday_enabled || false);
          setThrWithdrawalDate(payload.new.year_end_bonus_withdrawal_date || 7);
        }
      }
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [memberRole]);
  const loadMemberData = async () => {
    try {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) throw new Error("User not found");

      // Get member ID, status, and position
      const {
        data: member,
        error: memberError
      } = await supabase.from("members").select("id, is_active, deactivated_at, position, user_id").eq("user_id", user.id).single();
      if (memberError) throw memberError;
      if (!member) throw new Error("Member not found");
      setMemberId(member.id);
      setIsInactive(!member.is_active);
      setDeactivatedAt(member.deactivated_at);

      // Determine role from position
      const position = member.position?.toLowerCase() || 'sales';
      const isKasir = position === 'kasir';
      setMemberRole(isKasir ? 'kasir' : 'sales');

      // Sync monthly balances in background (don't await)
      supabase.functions.invoke('sync-monthly-balance').catch(console.error);

      // Execute all queries in parallel for better performance
      const [incentiveSettingsRes, availableBalanceRes, monthlyDataRes, balanceDataRes] = await Promise.all([supabase.from("incentive_settings").select("*").single(), (supabase as any).rpc("get_member_available_balance", {
        p_member_id: member.id
      }), supabase.from("member_monthly_balance_summary").select("*").eq("member_id", member.id).order("period_month", {
        ascending: false
      }), (supabase as any).rpc("get_member_balance_detailed", {
        p_member_id: member.id
      }).single()]);

      // Process incentive settings based on role
      const incentiveSettings = incentiveSettingsRes.data;
      if (isKasir) {
        // Kasir-specific settings
        const kasirPaymentEnabled = incentiveSettings?.kasir_payment_enabled || false;
        setIncentiveEnabled(kasirPaymentEnabled);
        setCreditApplicationEnabled(false);
        setInstallmentPaymentEnabled(kasirPaymentEnabled);
        setThrEnabled(incentiveSettings?.kasir_holiday_enabled || false);
        setThrWithdrawalDate(incentiveSettings?.kasir_year_end_bonus_withdrawal_date || 7);
      } else {
        // Sales-specific settings
        const creditAppEnabled = incentiveSettings?.credit_application_enabled || false;
        const installmentEnabled = incentiveSettings?.installment_payment_enabled || false;
        const regularIncentiveActive = creditAppEnabled || installmentEnabled;
        setIncentiveEnabled(regularIncentiveActive);
        setCreditApplicationEnabled(creditAppEnabled);
        setInstallmentPaymentEnabled(installmentEnabled);
        setThrEnabled(incentiveSettings?.holiday_enabled || false);
        setThrWithdrawalDate(incentiveSettings?.year_end_bonus_withdrawal_date || 7);
      }

      // Process balance data
      if (availableBalanceRes.error) throw availableBalanceRes.error;
      setAvailableBalance(Number(availableBalanceRes.data || 0));
      if (monthlyDataRes.error) throw monthlyDataRes.error;
      setMonthlyBalances(monthlyDataRes.data || []);
      if (balanceDataRes.error) throw balanceDataRes.error;
      setRegularBalance(Number(balanceDataRes.data?.regular_balance || 0));
      setThrBalance(Number(balanceDataRes.data?.thr_balance || 0));

      // THR/Year-end bonus calculation is now based on actual transactions only
      // No estimation needed - just use the actual balance from get_member_balance_detailed
      // The thrBalance is already set from balanceDataRes.data?.thr_balance
      // Only show calculation details if there are actual transactions
      try {
        const thrEnabledForRole = isKasir ? incentiveSettings?.kasir_holiday_enabled : incentiveSettings?.holiday_enabled;
        if (incentiveSettings?.is_enabled && thrEnabledForRole || isKasir && incentiveSettings?.kasir_enabled && incentiveSettings?.kasir_holiday_enabled) {
          const holidayType = isKasir ? incentiveSettings?.kasir_holiday_type : incentiveSettings?.holiday_type;
          const holidayAmount = isKasir ? incentiveSettings?.kasir_holiday_amount : incentiveSettings?.holiday_amount;

          // Get actual year_end_bonus transactions to show details
          const actualThrBalance = Number(balanceDataRes.data?.thr_balance || 0);

          // Calculate total payments from actual transactions (reverse calculation for display)
          let totalPaymentsFromTransactions = 0;
          if (holidayType === "percentage" && Number(holidayAmount || 0) > 0) {
            const percentage = Number(holidayAmount);
            totalPaymentsFromTransactions = actualThrBalance * 100 / percentage;
          }
          setThrCalculationDetails({
            totalPayments: totalPaymentsFromTransactions,
            incentiveType: holidayType || 'fixed',
            incentiveAmount: Number(holidayAmount || 0),
            calculatedTHR: actualThrBalance // Use actual balance, not estimate
          });
        }
      } catch (e) {
        console.warn("THR calculation details skipped:", e);
      }

      // Get transactions and withdrawals in parallel
      const [transactionsRes, withdrawalsRes] = await Promise.all([supabase.from("member_balance_transactions").select("*").eq("member_id", member.id).order("created_at", {
        ascending: false
      }).limit(100), supabase.from("member_balance_withdrawals").select("*").eq("member_id", member.id).order("requested_at", {
        ascending: false
      }).limit(50)]);
      if (transactionsRes.error) throw transactionsRes.error;
      const transactionsData = transactionsRes.data || [];
      setTransactions(transactionsData);
      if (withdrawalsRes.error) throw withdrawalsRes.error;
      setWithdrawals(withdrawalsRes.data || []);

      // Calculate regular incentive breakdown (Bulan Ini)
      // IMPORTANT: we cannot rely on `transactionsData` because it is limited to last 100 rows
      // and can miss older transactions within the same month (especially when there are many `holiday` rows).
      // So we fetch the monthly totals directly using period_month.
      const now = new Date();
      const currentPeriodMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
      const monthlyTypes = isKasir ? ["kasir_payment"] as const : ["credit_application", "installment_payment"] as const;
      const {
        data: monthTx,
        error: monthTxError
      } = await supabase.from("member_balance_transactions").select("type, amount").eq("member_id", member.id).eq("balance_type", "regular").eq("period_month", currentPeriodMonth).in("type", monthlyTypes as unknown as string[]).range(0, 5000);
      if (monthTxError) throw monthTxError;
      const sumByType = (type: string) => (monthTx || []).filter((t: any) => t.type === type).reduce((sum: number, t: any) => sum + Number(t.amount || 0), 0);
      if (isKasir) {
        const kasirPaymentIncentive = sumByType("kasir_payment");
        setRegularIncentiveDetails({
          creditApplicationIncentive: 0,
          installmentPaymentIncentive: kasirPaymentIncentive,
          totalRegular: kasirPaymentIncentive
        });
      } else {
        const creditAppIncentive = sumByType("credit_application");
        const installmentIncentive = sumByType("installment_payment");
        setRegularIncentiveDetails({
          creditApplicationIncentive: creditAppIncentive,
          installmentPaymentIncentive: installmentIncentive,
          totalRegular: creditAppIncentive + installmentIncentive
        });
      }
    } catch (error: any) {
      console.error("Error loading member balance:", error);
      toast({
        title: "Gagal Memuat Data",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0
    }).format(amount);
  };
  const getTransactionTypeLabel = (type: string, balanceType?: string) => {
    const types: Record<string, string> = {
      credit_application: "Insentif Pengajuan Kredit",
      installment_payment: "Insentif Pembayaran Angsuran",
      kasir_payment: "Insentif Input Pembayaran Kasir",
      kasir_holiday: "Bonus Akhir Tahun Kasir",
      holiday: "Bonus Akhir Tahun",
      withdrawal: balanceType === 'year_end_bonus' ? "Penarikan Bonus Akhir Tahun" : "Penarikan Saldo",
      deduction: "Pengurangan",
      adjustment: "Penyesuaian"
    };
    return types[type] || type;
  };
  const getWithdrawalStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline">Menunggu</Badge>;
      case "approved":
        return <Badge className="bg-green-600">Disetujui</Badge>;
      case "rejected":
        return <Badge variant="destructive">Ditolak</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  // Calculate days inactive
  const getDaysInactive = () => {
    if (!deactivatedAt) return 0;
    const deactivated = new Date(deactivatedAt);
    const now = new Date();
    return Math.floor((now.getTime() - deactivated.getTime()) / (1000 * 60 * 60 * 24));
  };
  const daysInactive = getDaysInactive();
  const daysUntilForfeit = 90 - daysInactive;
  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>;
  }
  return <div className="w-full p-4 md:p-6">
      <div className="flex items-center gap-2 mb-3">
        <Wallet className="h-6 w-6" />
        <h1 className="text-2xl font-semibold">
          Saldo {memberRole === 'kasir' ? 'Kasir' : ''}
        </h1>
      </div>

      {/* Inactive Member Warning */}
      {isInactive && daysInactive > 0 && <div className="mb-4">
          {daysUntilForfeit > 0 ? <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="text-amber-600 mt-0.5">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-amber-900 mb-1">Status Anggota Tidak Aktif</h3>
                  <p className="text-sm text-amber-800 mb-2">
                    Anda telah tidak aktif selama {daysInactive} hari. Saldo akan hangus otomatis jika tidak aktif lebih dari 90 hari.
                  </p>
                  <p className="text-xs text-amber-700 font-medium">
                    ⏱️ Sisa waktu sebelum saldo hangus: {daysUntilForfeit} hari
                  </p>
                </div>
              </div>
            </div> : <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="text-red-600 mt-0.5">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-red-900 mb-1">Saldo Hangus</h3>
                  <p className="text-sm text-red-800">
                    Anda telah tidak aktif lebih dari 90 hari. Saldo Anda telah dihanguskan sesuai kebijakan sistem.
                  </p>
                </div>
              </div>
            </div>}
        </div>}

      {/* Balance Cards */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle>Saldo Bulanan</CardTitle>
              </div>
              <Badge variant={incentiveEnabled ? "default" : "secondary"} className="gap-1">
                <TrendingUp className="h-3 w-3" />
                {incentiveEnabled ? "Aktif" : "Nonaktif"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex-1 pr-4">
                <div className="text-3xl font-bold text-primary">
                  {formatCurrency(regularBalance)}
                </div>
                <div className="text-sm text-muted-foreground mt-2 space-y-1">
                  <div className="flex items-center gap-2">
                    <span>Saldo Tersedia:</span>
                    <span className="font-medium text-green-600">{formatCurrency(availableBalance)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>Saldo Tertahan:</span>
                    <span className="font-medium text-amber-600">{formatCurrency(regularBalance - availableBalance)}</span>
                  </div>
                  <p className="text-xs text-muted-foreground/80 mt-2 italic">
                    *Saldo tertahan adalah saldo bulan berjalan atau saldo yang memiliki tunggakan Angsuran  
                  </p>
                </div>
              </div>
              {memberId && <MemberBalanceWithdrawal memberId={memberId} currentBalance={availableBalance} onSuccess={loadMemberData} />}
            </div>

            {regularIncentiveDetails && incentiveEnabled && <div className="border-t pt-4 space-y-2 text-sm">
                <div className="font-semibold text-muted-foreground mb-2 flex items-center justify-between">
                  <span>Rincian Insentif {memberRole === 'kasir' ? 'Kasir' : 'Regular'} (Bulan Ini)</span>
                  {!incentiveEnabled && <span className="text-xs font-normal text-amber-600">*Perhitungan berhenti</span>}
                </div>
                {memberRole !== 'kasir' && creditApplicationEnabled && <div className="flex justify-between">
                    <span className="text-muted-foreground">Insentif Pengajuan Kredit:</span>
                    <span className="font-medium">{formatCurrency(regularIncentiveDetails.creditApplicationIncentive)}</span>
                  </div>}
                {installmentPaymentEnabled && <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {memberRole === 'kasir' ? 'Insentif Input Pembayaran:' : 'Insentif Pembayaran Angsuran:'}
                    </span>
                    <span className="font-medium">{formatCurrency(regularIncentiveDetails.installmentPaymentIncentive)}</span>
                  </div>}
                <div className="flex justify-between border-t pt-2">
                  <span className="text-muted-foreground font-semibold">Total Insentif:</span>
                  <span className="font-bold text-primary">{formatCurrency(regularIncentiveDetails.totalRegular)}</span>
                </div>
              </div>}

            {/* Regular balance withdrawal history - show last 3 */}
            {(() => {
            const regularWithdrawals = withdrawals
              .filter(w => w.withdrawal_type === 'regular' && w.status === 'approved')
              .slice(0, 3);
            if (regularWithdrawals.length === 0) return null;
            return <div className="border-t pt-4 space-y-2">
                  <div className="font-semibold text-muted-foreground text-sm mb-2">
                    Histori Penarikan Saldo Bulanan
                  </div>
                  <div className="space-y-2">
                    {regularWithdrawals.map(w => <div key={w.id} className="flex items-center justify-between p-2 bg-muted/30 rounded text-sm">
                        <span className="text-muted-foreground">
                          {format(new Date(w.requested_at), "dd MMM yyyy", {
                      locale: id
                    })}
                        </span>
                        <span className="font-medium text-primary">
                          {formatCurrency(w.amount)}
                        </span>
                      </div>)}
                  </div>
                </div>;
          })()}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle>Bonus Akhir Tahun</CardTitle>
                <CardDescription>
                  Dapat ditarik mulai tanggal {thrWithdrawalDate} Desember
                </CardDescription>
              </div>
              <Badge variant={thrEnabled ? "default" : "secondary"} className="gap-1">
                <TrendingUp className="h-3 w-3" />
                {thrEnabled ? "Aktif" : "Nonaktif"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold text-amber-600">
                {formatCurrency(thrBalance)}
              </div>
              {memberId && <MemberYearEndBonusWithdrawal memberId={memberId} currentBalance={thrBalance} onSuccess={loadMemberData} />}
            </div>
            
            {thrCalculationDetails && <div className="border-t pt-4 space-y-2 text-sm">
                <div className="font-semibold text-muted-foreground mb-2">
                  Rincian Perhitungan (1 Jan - 1 Des {new Date().getFullYear()})
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    {memberRole === 'kasir' ? 'Total Pembayaran Diinput:' : 'Total Pembayaran Terkumpul:'}
                  </span>
                  <span className="font-medium">{formatCurrency(thrCalculationDetails.totalPayments)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bonus Akhir Tahun:</span>
                  <span className="font-medium">
                    {thrCalculationDetails.incentiveType === "percentage" ? `${thrCalculationDetails.incentiveAmount}%` : formatCurrency(thrCalculationDetails.incentiveAmount)}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-muted-foreground font-semibold">Perkiraan Bonus:</span>
                  <span className="font-bold text-amber-600">{formatCurrency(thrCalculationDetails.calculatedTHR)}</span>
                </div>
              </div>}

            {/* Year-end bonus withdrawal history - show last 3 */}
            {(() => {
            const yearEndWithdrawals = withdrawals
              .filter(w => w.withdrawal_type === 'year_end_bonus' && w.status === 'approved')
              .slice(0, 3);
            if (yearEndWithdrawals.length === 0) return null;
            return <div className="border-t pt-4 space-y-2">
                  <div className="font-semibold text-muted-foreground text-sm mb-2">
                    Histori Penarikan Bonus Akhir Tahun
                  </div>
                  <div className="space-y-2">
                    {yearEndWithdrawals.map(w => <div key={w.id} className="flex items-center justify-between p-2 bg-muted/30 rounded text-sm">
                        <span className="text-muted-foreground">
                          {format(new Date(w.requested_at), "dd MMM yyyy", {
                      locale: id
                    })}
                        </span>
                        <span className="font-medium text-amber-600">
                          {formatCurrency(w.amount)}
                        </span>
                      </div>)}
                  </div>
                </div>;
          })()}
          </CardContent>
        </Card>
      </div>

      {/* Incentive Breakdown Report */}
      {memberId && <MemberIncentiveBreakdown memberId={memberId} />}


      {/* Withdrawal Requests - Last 12 months */}
      {(() => {
        const twelveMonthsAgo = new Date();
        twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);
        const recentWithdrawals = withdrawals.filter(w => new Date(w.requested_at) >= twelveMonthsAgo);
        
        if (recentWithdrawals.length === 0) return null;
        
        return <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Riwayat Pengajuan Penarikan
            </CardTitle>
            <CardDescription>
              Status pengajuan penarikan saldo Anda (12 bulan terakhir)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentWithdrawals.map(withdrawal => <div key={withdrawal.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-medium">
                        {formatCurrency(withdrawal.amount)}
                      </p>
                      <Badge variant="outline" className={`text-xs ${withdrawal.withdrawal_type === 'year_end_bonus' ? 'border-amber-500 text-amber-600' : 'border-primary text-primary'}`}>
                        {withdrawal.withdrawal_type === 'year_end_bonus' ? 'Bonus Akhir Tahun' : 'Saldo Bulanan'}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {withdrawal.withdrawal_method === "cash" ? "Tunai" : "Transfer"}
                      </Badge>
                    </div>
                    {withdrawal.withdrawal_method === "transfer" && withdrawal.bank_account_info && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Rekening: {withdrawal.bank_account_info}
                      </p>
                    )}
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(withdrawal.requested_at), "dd MMMM yyyy, HH:mm", {
                  locale: id
                })}
                    </p>
                    {withdrawal.rejection_reason && <p className="text-sm text-destructive mt-1">
                        {withdrawal.rejection_reason}
                      </p>}
                  </div>
                  <div>{getWithdrawalStatusBadge(withdrawal.status)}</div>
                </div>)}
            </div>
          </CardContent>
        </Card>;
      })()}

      {/* Monthly Withdrawal History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base md:text-lg">
            <Calendar className="h-5 w-5" />
            Histori Penarikan Saldo (12 Bulan Terakhir)
          </CardTitle>
          <CardDescription className="text-xs md:text-sm">
            Rincian penarikan saldo dan sisa saldo per bulan
          </CardDescription>
        </CardHeader>
        <CardContent>
          {(() => {
          // Generate last 12 months data
          const monthlyData = [];
          for (let i = 0; i < 12; i++) {
            const date = new Date();
            date.setMonth(date.getMonth() - i);
            const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
            const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);
            const periodMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

            // Calculate REGULAR withdrawals only for this month (exclude year_end_bonus)
            const monthWithdrawals = withdrawals.filter((w: WithdrawalRequest) => {
              const wDate = new Date(w.requested_at);
              return wDate >= monthStart && wDate <= monthEnd && w.status === 'approved' && w.withdrawal_type !== 'year_end_bonus';
            });
            const totalWithdrawn = monthWithdrawals.reduce((sum: number, w: any) => sum + Number(w.amount || 0), 0);

            // Get total regular incentive earned for this month from monthly balances
            // Note: THR/year-end bonus is shown separately in the "Saldo Bonus Akhir Tahun" card
            const monthBalance = monthlyBalances.find(mb => mb.period_month === periodMonth);
            const totalIncentive = monthBalance ? Number(monthBalance.total_earned || 0) : 0;

            // Check if there's any activity in this month
            const hasActivity = totalIncentive > 0 || totalWithdrawn > 0;

            // Get available balance for this month from monthly balances
            // This only shows regular balance - THR is displayed separately
            const monthAvailableBalance = monthBalance ? Number(monthBalance.available_balance || 0) : null;
            monthlyData.push({
              month: format(monthStart, "MMMM yyyy", {
                locale: id
              }),
              monthShort: format(monthStart, "MMM yyyy", {
                locale: id
              }),
              withdrawn: totalWithdrawn,
              totalIncentive: totalIncentive,
              balance: i === 0 ? regularBalance : hasActivity ? monthAvailableBalance : null,
              hasData: i === 0 || hasActivity,
              count: monthWithdrawals.length
            });
          }
          return <>
                {/* Desktop Table */}
                <div className="hidden md:block border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="text-left p-3 text-sm font-semibold">Bulan</th>
                          <th className="text-right p-3 text-sm font-semibold">Total Insentif</th>
                          <th className="text-right p-3 text-sm font-semibold">Penarikan</th>
                          <th className="text-right p-3 text-sm font-semibold">Sisa Saldo</th>
                        </tr>
                      </thead>
                      <tbody>
                        {monthlyData.map((data, index) => <tr key={index} className="border-t hover:bg-muted/30">
                            <td className="p-3 text-sm">
                              {data.month}
                              {data.count > 0 && <span className="ml-2 text-xs text-muted-foreground">
                                  ({data.count}x penarikan)
                                </span>}
                            </td>
                            <td className="p-3 text-sm text-right font-medium text-green-600">
                              {data.totalIncentive > 0 ? formatCurrency(data.totalIncentive) : '-'}
                            </td>
                            <td className="p-3 text-sm text-right font-medium">
                              {data.withdrawn > 0 ? formatCurrency(data.withdrawn) : '-'}
                            </td>
                            <td className="p-3 text-sm text-right font-semibold text-primary">
                              {data.balance !== null ? formatCurrency(data.balance) : '-'}
                            </td>
                          </tr>)}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Mobile Cards */}
                <div className="md:hidden space-y-2">
                  {monthlyData.map((data, index) => <div key={index} className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{data.monthShort}</span>
                        {data.count > 0 && <Badge variant="outline" className="text-xs">
                            {data.count}x penarikan
                          </Badge>}
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div>
                          <p className="text-muted-foreground">Insentif</p>
                          <p className="font-medium text-green-600">
                            {data.totalIncentive > 0 ? formatCurrency(data.totalIncentive) : '-'}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Penarikan</p>
                          <p className="font-medium">
                            {data.withdrawn > 0 ? formatCurrency(data.withdrawn) : '-'}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Sisa</p>
                          <p className="font-semibold text-primary">
                            {data.balance !== null ? formatCurrency(data.balance) : '-'}
                          </p>
                        </div>
                      </div>
                    </div>)}
                </div>
              </>;
        })()}
        </CardContent>
      </Card>
    </div>;
}