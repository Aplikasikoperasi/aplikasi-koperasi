import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { BarChart3, TrendingUp, TrendingDown, DollarSign, Users, FileText, AlertTriangle, CheckCircle2, Award, Download, Calendar, PieChart, ChevronLeft, ChevronRight, X, Activity, Database, Server, FileBarChart } from "lucide-react";
import { formatRupiah, formatDate, formatDateWIB, getDateStringInWIB, cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useIsMobile } from "@/hooks/use-mobile";
import { useUserRole } from "@/hooks/useUserRole";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Document, Packer, Paragraph, Table as DocTable, TableCell as DocTableCell, TableRow as DocTableRow, WidthType, BorderStyle, AlignmentType } from "docx";
import { saveAs } from "file-saver";
import { BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart as RechartsPie, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from "recharts";
import { useDeviceDetection } from "@/hooks/use-device-detection";
import { useLocation, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { IncentiveReport } from "@/components/IncentiveReport";

// Format Y-axis values to K (thousands)
const formatYAxisValue = (value: number): string => {
  return `${(value / 1000).toFixed(0)}K`;
};
interface FinancialStats {
  totalDisbursed: number;
  totalCollected: number;
  totalOutstanding: number;
  totalOverdue: number;
  totalOverdueAmount: number; // Total rupiah angsuran yang menunggak
  totalPenalties: number;
  totalPenaltiesPaid: number;
  totalPenaltiesUnpaid: number;
  totalApplications: number;
  approvedApplications: number;
  rejectedApplications: number;
  pendingApplications: number;
  pendingApprovalApplications: number; // New: applications waiting for approval
  completedApplications: number; // Applications with all installments paid
  totalAdminFees: number;
  // Jumlah angsuran berdasarkan status
  installmentsPaid: number;
  installmentsUnpaid: number;
  installmentsOverdue: number;
}
interface MemberPerformance {
  id: string;
  full_name: string;
  position: string;
  totalApplications: number;
  approvedApplications: number;
  rejectedApplications: number;
  totalDisbursed: number;
  totalCollected: number;
  penaltiesCollected: number;
  adminFeesCollected: number;
  outstandingInstallments: number;
  outstandingPenalties: number;
  approvalRate: number;
  performingApplications: number; // Aplikasi kredit yang lancar (tidak ada angsuran overdue)
  nplApplications: number; // Aplikasi kredit yang macet (ada angsuran overdue)
}
interface DetailedApplication {
  id: string;
  application_number: string;
  customer_name: string;
  member_name: string;
  amount_approved: number;
  status: string;
  approved_at: string;
  application_date?: string;
  total_paid: number;
  total_outstanding: number;
  penalties_paid: number;
  penalties_unpaid: number;
  tenor_months: number;
  total_installments: number;
}
interface MonthlyFinancialData {
  month: string;
  year: number;
  totalDisbursed: number;
  totalCollected: number;
  penaltiesPaid: number;
  adminFeesCollected: number;
  totalExpenses: number;
  totalIncentives: number;
  netIncome: number;
}
interface CustomerGrowthData {
  month: string;
  year: number;
  newCustomers: number;
  totalCustomers: number;
}
interface ChartDataPoint {
  name: string;
  value: number;
  [key: string]: string | number;
}
interface TrafficData {
  date: string;
  requests: number;
  dbQueries: number;
  errors: number;
}
interface PenaltyDetail {
  installment_id: string;
  customer_name: string;
  customer_id_number: string;
  application_number: string;
  installment_number: number;
  penalty_amount: number;
  paid_at: string;
  total_payment: number;
  paid_amount: number;
}
export default function Reports() {
  const [financialStats, setFinancialStats] = useState<FinancialStats>({
    totalDisbursed: 0,
    totalCollected: 0,
    totalOutstanding: 0,
    totalOverdue: 0,
    totalOverdueAmount: 0,
    totalPenalties: 0,
    totalPenaltiesPaid: 0,
    totalPenaltiesUnpaid: 0,
    totalApplications: 0,
    approvedApplications: 0,
    rejectedApplications: 0,
    pendingApplications: 0,
    pendingApprovalApplications: 0,
    completedApplications: 0,
    totalAdminFees: 0,
    installmentsPaid: 0,
    installmentsUnpaid: 0,
    installmentsOverdue: 0
  });
  const [totalPaidIncentives, setTotalPaidIncentives] = useState(0);
  const [totalPaidYearEndBonus, setTotalPaidYearEndBonus] = useState(0);
  const [totalOperationalExpenses, setTotalOperationalExpenses] = useState(0);
  const [memberPerformance, setMemberPerformance] = useState<MemberPerformance[]>([]);
  const [detailedApplications, setDetailedApplications] = useState<DetailedApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailedSearch, setDetailedSearch] = useState("");
  const [detailedPage, setDetailedPage] = useState(1);
  const [monthlyData, setMonthlyData] = useState<MonthlyFinancialData[]>([]);
  const [customerGrowthData, setCustomerGrowthData] = useState<CustomerGrowthData[]>([]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [availableYears, setAvailableYears] = useState<number[]>([]);
  const [chartYearFilter, setChartYearFilter] = useState<string>("last12");
  const [trendYearFilter, setTrendYearFilter] = useState<string>("last12");
  const [customerGrowthYearFilter, setCustomerGrowthYearFilter] = useState<string>("last12");
  const [showAnnualDialog, setShowAnnualDialog] = useState(false);
  const [showYearSelectorDialog, setShowYearSelectorDialog] = useState(false);
  const [mobileSelectedYear, setMobileSelectedYear] = useState(new Date().getFullYear());
  const [selectedMember, setSelectedMember] = useState<MemberPerformance | null>(null);
  const [showMemberDialog, setShowMemberDialog] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<DetailedApplication | null>(null);
  const [showApplicationDialog, setShowApplicationDialog] = useState(false);
  const [selectedMonthDetail, setSelectedMonthDetail] = useState<{
    month: string;
    year: number;
    applications: DetailedApplication[];
  } | null>(null);
  const [trafficData, setTrafficData] = useState<TrafficData[]>([]);
  const [trafficLoading, setTrafficLoading] = useState(false);
  const [trafficTabOpened, setTrafficTabOpened] = useState(false);
  const [penaltyDetails, setPenaltyDetails] = useState<PenaltyDetail[]>([]);
  const [showPenaltyDetailDialog, setShowPenaltyDetailDialog] = useState(false);
  const [selectedMonthPenaltyDetails, setSelectedMonthPenaltyDetails] = useState<PenaltyDetail[]>([]);

  // Analytics tab state
  const [analyticsTimeRange, setAnalyticsTimeRange] = useState("30");
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [salesData, setSalesData] = useState<any[]>([]);
  const [topSales, setTopSales] = useState<any[]>([]);
  const [collectibilityData, setCollectibilityData] = useState<any>(null);
  const [agingData, setAgingData] = useState<any[]>([]);
  const [paymentTrends, setPaymentTrends] = useState<any[]>([]);
  const [monthlyPaymentStats, setMonthlyPaymentStats] = useState<any[]>([]);
  const itemsPerPage = 20;
  const isMobile = useIsMobile();
  const device = useDeviceDetection();
  const isPhone = device.isMobile;
  const location = useLocation();
  const navigate = useNavigate();
  const {
    isSales,
    isOwner,
    isAdmin
  } = useUserRole();
  const {
    toast
  } = useToast();

  // Set default tab based on role: sales get 'detailed', owner/admin get from URL or 'financial'
  const getDefaultTab = () => {
    const urlTab = new URLSearchParams(location.search).get('tab');
    // Redirect deprecated 'analytics' tab to 'financial'
    if (urlTab === 'analytics') return 'financial';
    if (urlTab) return urlTab;

    // Default to 'charts' (Grafik Kinerja) for all users
    return 'charts';
  };
  const [activeTab, setActiveTab] = useState(getDefaultTab());

  // Load analytics when tab is opened
  useEffect(() => {
    if (activeTab === 'analytics') {
      console.log('🔄 Loading analytics data...');
      loadAnalytics();
    }
  }, [activeTab, analyticsTimeRange]);
  const loadAnalytics = useCallback(async () => {
    setAnalyticsLoading(true);
    try {
      console.log('📊 Fetching analytics data...');
      await Promise.all([loadSalesPerformance(), loadCollectibility(), loadPaymentTrends()]);
      console.log('✅ Analytics data loaded successfully');
    } catch (error) {
      console.error("❌ Error loading analytics:", error);
      toast({
        title: "Gagal memuat data analitik",
        description: "Terjadi kesalahan saat memuat data. Silakan coba lagi.",
        variant: "destructive"
      });
    } finally {
      setAnalyticsLoading(false);
    }
  }, [analyticsTimeRange]);
  const loadSalesPerformance = async () => {
    const daysAgo = parseInt(analyticsTimeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);
    const {
      data: applications
    } = await supabase.from("credit_applications").select(`
        id,
        status,
        amount_approved,
        member_id,
        members!inner(id, full_name)
      `).gte("created_at", startDate.toISOString());
    if (!applications) return;
    const memberStats: Record<string, any> = {};
    applications.forEach((app: any) => {
      const memberId = app.member_id;
      const memberName = app.members?.full_name || "Unknown";
      if (!memberStats[memberId]) {
        memberStats[memberId] = {
          name: memberName,
          total: 0,
          approved: 0,
          pending: 0,
          rejected: 0,
          totalAmount: 0
        };
      }
      memberStats[memberId].total++;
      if (app.status === "approved" || app.status === "disbursed" || app.status === "completed") {
        memberStats[memberId].approved++;
        memberStats[memberId].totalAmount += Number(app.amount_approved || 0);
      } else if (app.status === "pending") {
        memberStats[memberId].pending++;
      } else if (app.status === "rejected") {
        memberStats[memberId].rejected++;
      }
    });
    const salesArray = Object.values(memberStats).sort((a: any, b: any) => b.totalAmount - a.totalAmount);
    setSalesData(salesArray);
    setTopSales(salesArray.slice(0, 5));
  };
  const loadCollectibility = async () => {
    const {
      data: applications
    } = await supabase.from("credit_applications").select(`
        id,
        amount_approved,
        installments!inner(
          id,
          status,
          due_date,
          total_amount,
          paid_amount,
          principal_paid,
          frozen_penalty
        )
      `).in("status", ["approved", "disbursed", "completed"]);
    if (!applications) return;
    let totalLoan = 0;
    let totalPaid = 0;
    let totalOutstanding = 0;
    let totalOverdue = 0;
    let currentCount = 0;
    let overdueCount = 0;
    const agingBuckets = {
      "0-30": 0,
      "31-60": 0,
      "61-90": 0,
      "90+": 0
    };
    applications.forEach((app: any) => {
      const installments = Array.isArray(app.installments) ? app.installments : [];
      installments.forEach((inst: any) => {
        const totalAmount = Number(inst.total_amount || 0);
        const paidAmount = Number(inst.paid_amount || 0);
        const penalty = Number(inst.frozen_penalty || 0);
        totalLoan += totalAmount;
        totalPaid += paidAmount;
        if (!inst.principal_paid) {
          const outstanding = totalAmount - paidAmount + penalty;
          totalOutstanding += outstanding;
          if (inst.status === "overdue") {
            totalOverdue += outstanding;
            overdueCount++;
            const dueDate = new Date(inst.due_date);
            const today = new Date();
            const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
            if (daysOverdue <= 30) agingBuckets["0-30"] += outstanding;else if (daysOverdue <= 60) agingBuckets["31-60"] += outstanding;else if (daysOverdue <= 90) agingBuckets["61-90"] += outstanding;else agingBuckets["90+"] += outstanding;
          } else {
            currentCount++;
          }
        }
      });
    });
    const nplRatio = totalLoan > 0 ? totalOverdue / totalLoan * 100 : 0;
    const collectionRate = totalLoan > 0 ? totalPaid / totalLoan * 100 : 0;
    setCollectibilityData({
      totalLoan,
      totalPaid,
      totalOutstanding,
      totalOverdue,
      nplRatio,
      collectionRate,
      currentCount,
      overdueCount
    });
    const agingArray = Object.entries(agingBuckets).map(([name, value]) => ({
      name,
      value: Number(value)
    }));
    setAgingData(agingArray);
  };
  const loadPaymentTrends = async () => {
    const daysAgo = parseInt(analyticsTimeRange);
    const {
      data: payments
    } = await supabase.from("payments").select("payment_date, amount").gte("payment_date", getDateStringInWIB(-daysAgo)).order("payment_date");
    if (!payments) return;
    const dailyPayments: Record<string, number> = {};
    payments.forEach((payment: any) => {
      const date = payment.payment_date;
      if (!dailyPayments[date]) {
        dailyPayments[date] = 0;
      }
      dailyPayments[date] += Number(payment.amount);
    });
    const trendsArray = Object.entries(dailyPayments).map(([date, amount]) => ({
      date: formatDateWIB(date, 'medium').replace(/^\d+\s/, '').slice(0, 6),
      amount: Number(amount)
    })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setPaymentTrends(trendsArray);

    // Monthly stats for the last 6 months
    const {
      data: monthlyPayments
    } = await supabase.from("payments").select("payment_date, amount").gte("payment_date", getDateStringInWIB(-180));
    if (!monthlyPayments) return;
    const monthlyGroups: Record<string, {
      amount: number;
      date: Date;
    }> = {};
    monthlyPayments.forEach((payment: any) => {
      const date = new Date(payment.payment_date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (!monthlyGroups[monthKey]) {
        monthlyGroups[monthKey] = {
          amount: 0,
          date
        };
      }
      monthlyGroups[monthKey].amount += Number(payment.amount);
    });
    const monthlyArray = Object.entries(monthlyGroups).map(([key, data]) => ({
      month: data.date.toLocaleDateString("id-ID", {
        year: "numeric",
        month: "short"
      }),
      amount: Number(data.amount),
      sortKey: key
    })).sort((a, b) => a.sortKey.localeCompare(b.sortKey)).slice(-6);
    setMonthlyPaymentStats(monthlyArray);
  };
  useEffect(() => {
    loadReports();
    // Realtime disabled for performance
  }, []);

  // Listen for pull-to-refresh
  useEffect(() => {
    const handleRefresh = () => loadReports();
    window.addEventListener('page-refresh', handleRefresh);
    return () => window.removeEventListener('page-refresh', handleRefresh);
  }, []);
  const loadTrafficData = async () => {
    setTrafficLoading(true);
    try {
      // Generate sample data for the last 30 days
      const data: TrafficData[] = [];
      const today = new Date();
      for (let i = 29; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);

        // Generate realistic-looking sample data
        const baseRequests = Math.floor(Math.random() * 500) + 200;
        const baseQueries = Math.floor(baseRequests * (Math.random() * 0.5 + 1.5));
        const baseErrors = Math.floor(baseRequests * (Math.random() * 0.02));
        data.push({
          date: date.toLocaleDateString('id-ID'),
          requests: baseRequests,
          dbQueries: baseQueries,
          errors: baseErrors
        });
      }
      setTrafficData(data);
    } catch (error) {
      console.error('Error loading traffic data:', error);
    } finally {
      setTrafficLoading(false);
    }
  };
  const loadReports = async () => {
    setLoading(true);

    // Helper to fetch all rows (bypass 1000 limit)
    const fetchAllRows = async <T,>(table: string, selectCols: string): Promise<T[]> => {
      const pageSize = 1000;
      let from = 0;
      let all: T[] = [];
      while (true) {
        const {
          data,
          error
        } = await supabase.from(table as any).select(selectCols as any).range(from, from + pageSize - 1);
        if (error) {
          console.error(`fetchAllRows error on ${table}:`, error);
          throw error;
        }
        if (data && (data as any).length) all = all.concat(data as any);
        if (!data || (data as any).length < pageSize) break;
        from += pageSize;
      }
      return all;
    };

    // Load all data in parallel - fetch ALL rows + dashboard summary untuk konsistensi
    const [applications, installments, payments, members, appSettings, customers, dashboardSummary, expenses] = await Promise.all([fetchAllRows("credit_applications", "*, customers(full_name), members(full_name)"), fetchAllRows("installments", "*"), fetchAllRows("payments", "*"), fetchAllRows("members", "*"), supabase.rpc('get_public_app_settings').then(r => r.data), fetchAllRows("customers", "id, created_at, created_by"), supabase.rpc('get_financial_dashboard_summary').then(r => r.data), fetchAllRows("expenses", "id, amount, expense_date, status")]);
    const penaltyRate = (appSettings as any)?.penalty_rate_per_day || 2.0;

    // NEW LOGIC: No owner filtering, use all applications  
    const allApplications = applications as any[] || [];
    const allPayments = payments as any[] || [];
    const allInstallments = installments as any[] || [];

    // 1) Total Dicairkan - SAMA SEPERTI DASHBOARD: approved, disbursed, atau completed
    const disbursedApps = allApplications.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed");
    const totalDisbursed = disbursedApps.reduce((sum, a) => sum + Number(a.amount_approved || 0), 0);

    // 2) Total Sudah Dibayar - SAMA PERSIS DENGAN DASHBOARD: menggunakan RPC yang sama
    const totalCollected = Number((dashboardSummary as any)?.payments_total || 0);

    // 3) Total Outstanding (Angsuran Berjalan) - same as Dashboard
    const ongoingInstallments = allInstallments.filter(i => i.status !== "paid");
    const totalOutstanding = ongoingInstallments.reduce((sum, i) => {
      const total = Number(i.total_amount || 0);
      const paid = Number(i.paid_amount || 0);
      return sum + Math.max(0, total - paid);
    }, 0);

    // 4) Total Installments - same as Dashboard (all installments)
    const totalInstallmentsAmount = allInstallments.reduce((sum, i) => sum + Number(i.total_amount || 0), 0);

    // Calculate completed applications (all installments paid)
    const completedApps = allApplications?.filter(app => {
      if (app.status !== "approved" && app.status !== "disbursed" && app.status !== "completed") return false;
      const appInstallments = allInstallments.filter(i => i.application_id === app.id);
      // Has installments AND all are paid
      return appInstallments.length > 0 && appInstallments.every(i => i.status === "paid");
    }).length || 0;

    // Calculate pending applications (disbursed but not all installments paid)
    const pendingApps = allApplications?.filter(app => {
      if (app.status !== "approved" && app.status !== "disbursed") return false;
      const appInstallments = allInstallments.filter(i => i.application_id === app.id);
      // Ada angsuran DAN tidak semua angsuran lunas
      return appInstallments.length > 0 && !appInstallments.every(i => i.status === "paid");
    }).length || 0;

    // Calculate total overdue amount (hanya yang menunggak)
    const totalOverdueAmount = allInstallments?.filter(i => i.status === "overdue").reduce((sum, i) => sum + (Number(i.total_amount) - Number(i.paid_amount)), 0) || 0;

    // Calculate installments by status
    const installmentsPaid = allInstallments?.filter(i => i.status === "paid").length || 0;
    const installmentsUnpaid = allInstallments?.filter(i => i.status === "unpaid").length || 0;
    const installmentsOverdue = allInstallments?.filter(i => i.status === "overdue").length || 0;

    // Calculate financial statistics
    const stats: FinancialStats = {
      totalApplications: allApplications?.length || 0,
      approvedApplications: disbursedApps.length,
      rejectedApplications: allApplications?.filter(a => a.status === "rejected").length || 0,
      pendingApplications: pendingApps,
      pendingApprovalApplications: allApplications?.filter(a => a.status === "pending").length || 0,
      completedApplications: completedApps,
      totalDisbursed: totalDisbursed,
      totalCollected: totalCollected,
      totalOutstanding: totalOutstanding,
      totalOverdue: allInstallments?.filter(i => i.status === "overdue").length || 0,
      totalOverdueAmount: totalOverdueAmount,
      totalPenalties: 0,
      totalPenaltiesPaid: 0,
      totalPenaltiesUnpaid: 0,
      totalAdminFees: 0,
      installmentsPaid: installmentsPaid,
      installmentsUnpaid: installmentsUnpaid,
      installmentsOverdue: installmentsOverdue
    };

    // Calculate penalties PAID - CARA BARU: hitung dari selisih payment vs paid_amount HANYA untuk installment yang principal_paid=true
    // Ini lebih akurat karena hanya menghitung denda yang benar-benar terbayar saat principal lunas
    // Exclude pembayaran historis (Input data kredit lama)
    const paidPenaltyInstallments = allInstallments.filter(i => i.principal_paid === true);

    // Hitung total payments untuk installments yang principal_paid (exclude historical)
    const paidPenaltyPaymentsMap = new Map<string, number>();
    allPayments.forEach(p => {
      const isHistorical = p.notes && p.notes.includes("Input data kredit lama");
      if (!isHistorical && p.installment_id) {
        const instId = p.installment_id;
        paidPenaltyPaymentsMap.set(instId, (paidPenaltyPaymentsMap.get(instId) || 0) + Number(p.amount || 0));
      }
    });

    // Hitung selisih untuk setiap installment yang principal_paid DAN simpan detailnya
    const penaltyDetailsList: PenaltyDetail[] = [];
    const penaltiesPaid = paidPenaltyInstallments.reduce((sum, i) => {
      const totalPaymentForInst = paidPenaltyPaymentsMap.get(i.id) || 0;
      const totalAmount = Number(i.total_amount || 0);
      // Denda terbayar = total pembayaran - total angsuran (pokok + bunga)
      const penaltyForInst = Math.max(0, totalPaymentForInst - totalAmount);

      // Simpan detail jika ada penalty
      if (penaltyForInst > 0) {
        // Find application for this installment
        const app = allApplications.find(a => a.id === i.application_id);
        if (app && app.customers) {
          penaltyDetailsList.push({
            installment_id: i.id,
            customer_name: (app.customers as any).full_name || '-',
            customer_id_number: (app.customers as any).id_number || '-',
            application_number: app.application_number || '-',
            installment_number: i.installment_number,
            penalty_amount: penaltyForInst,
            paid_at: i.paid_at || '',
            total_payment: totalPaymentForInst,
            paid_amount: totalAmount
          });
        }
      }
      return sum + penaltyForInst;
    }, 0);
    setPenaltyDetails(penaltyDetailsList);

    // Calculate penalties UNPAID - SAMA SEPERTI DASHBOARD: sum(frozen_penalty) dari installments yang belum lunas
    const penaltiesUnpaid = allInstallments.filter(i => i.status !== 'paid').reduce((sum, i) => sum + Number(i.frozen_penalty || 0), 0);
    stats.totalPenaltiesPaid = penaltiesPaid;
    stats.totalPenaltiesUnpaid = penaltiesUnpaid;
    stats.totalPenalties = penaltiesPaid + penaltiesUnpaid;

    // Calculate total admin fees - dari yang tercatat permanen di setiap aplikasi
    const totalAdminFees = disbursedApps.reduce((sum, app) => sum + Number(app.admin_fee_amount || 0), 0);
    stats.totalAdminFees = totalAdminFees;
    setFinancialStats(stats);

    // Fetch approved member balance withdrawals to calculate paid incentives and bonuses
    const {
      data: approvedWithdrawals,
      error: withdrawalError
    } = await supabase.from('member_balance_withdrawals').select('amount, withdrawal_type, reviewed_at').eq('status', 'approved');
    if (withdrawalError) {
      console.error('Error fetching withdrawals:', withdrawalError);
    }

    // Calculate total paid incentives (regular withdrawals) and year-end bonuses
    let paidIncentives = 0;
    let paidYearEndBonus = 0;
    if (approvedWithdrawals) {
      approvedWithdrawals.forEach(withdrawal => {
        const amount = Number(withdrawal.amount || 0);
        if (withdrawal.withdrawal_type === 'year_end_bonus') {
          paidYearEndBonus += amount;
        } else {
          // 'regular' or any other type counts as incentive
          paidIncentives += amount;
        }
      });
    }
    setTotalPaidIncentives(paidIncentives);
    setTotalPaidYearEndBonus(paidYearEndBonus);

    // Calculate member performance - exclude Owner position (case insensitive)
    const memberPerf: MemberPerformance[] = (members as any[])?.filter(member => !member.position || member.position.toLowerCase() !== "owner" && !member.position.toLowerCase().includes("owner")) // Filter out Owner
    .map(member => {
      const memberApps = (applications as any[])?.filter(a => a.member_id === member.id) || [];
      const approvedApps = memberApps.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed");
      const rejectedApps = memberApps.filter(a => a.status === "rejected");
      const totalDisbursed = approvedApps.reduce((sum, a) => sum + Number(a.amount_approved || 0), 0);

      // Calculate total collected for this member's applications - SAMA SEPERTI DASHBOARD
      const memberAppIds = approvedApps.map(a => a.id);
      const memberInstallments = (installments as any[])?.filter(i => memberAppIds.includes(i.application_id)) || [];
      const totalCollected = memberInstallments.reduce((sum, i) => sum + Number(i.paid_amount || 0), 0);

      // Calculate penalties collected for this member - SAMA SEPERTI DASHBOARD
      const memberPayments = allPayments?.filter(p => memberAppIds.includes(p.application_id)) || [];
      const historicalMemberPayments = memberPayments.filter(p => p.notes && p.notes.includes("Input data kredit lama"));
      const historicalMemberPaymentsTotal = historicalMemberPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const totalMemberPaymentsAmount = memberPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const totalMemberPaidFromInstallments = memberInstallments.reduce((sum, i) => sum + Number(i.paid_amount || 0), 0);
      const penaltiesCollected = Math.max(0, totalMemberPaymentsAmount - totalMemberPaidFromInstallments - historicalMemberPaymentsTotal);

      // Calculate admin fees collected for this member - dari yang tercatat permanen di setiap aplikasi
      const adminFeesCollected = approvedApps.reduce((sum, app) => sum + Number(app.admin_fee_amount || 0), 0);

      // Calculate outstanding installments for this member
      const outstandingInstallments = memberInstallments.filter(i => i.status !== 'paid').reduce((sum, i) => sum + (Number(i.total_amount) - Number(i.paid_amount)), 0);

      // Calculate outstanding penalties for this member - SAMA SEPERTI DASHBOARD
      const outstandingPenalties = memberInstallments.filter(i => i.status !== 'paid').reduce((sum, i) => sum + Number(i.frozen_penalty || 0), 0);

      // Calculate performing vs NPL applications
      // Performing = aplikasi yang tidak ada angsuran overdue
      // NPL = aplikasi yang ada angsuran overdue
      const performingApps = approvedApps.filter(app => {
        const appInstallments = memberInstallments.filter(i => i.application_id === app.id);
        // Aplikasi performing jika tidak ada installment yang overdue
        return appInstallments.length > 0 && !appInstallments.some(i => i.status === "overdue");
      }).length;
      const nplApps = approvedApps.filter(app => {
        const appInstallments = memberInstallments.filter(i => i.application_id === app.id);
        // Aplikasi NPL jika ada installment yang overdue
        return appInstallments.length > 0 && appInstallments.some(i => i.status === "overdue");
      }).length;
      const totalProcessedApps = approvedApps.length + rejectedApps.length; // Total yang sudah diproses

      return {
        id: member.id,
        full_name: member.full_name,
        position: member.position,
        totalApplications: totalProcessedApps,
        // Hanya hitung approved + rejected
        approvedApplications: approvedApps.length,
        rejectedApplications: rejectedApps.length,
        totalDisbursed,
        totalCollected,
        penaltiesCollected,
        adminFeesCollected,
        outstandingInstallments,
        outstandingPenalties,
        approvalRate: totalProcessedApps > 0 ? approvedApps.length / totalProcessedApps * 100 : 0,
        performingApplications: performingApps,
        nplApplications: nplApps
      };
    }).sort((a, b) => b.totalDisbursed - a.totalDisbursed) || [];
    setMemberPerformance(memberPerf);

    // Calculate monthly financial data
    const monthlyFinancial: {
      [key: string]: MonthlyFinancialData;
    } = {};

    // Process disbursements - gunakan application_date sebagai tanggal pengajuan
    allApplications?.forEach(app => {
      if (app.status === "approved" || app.status === "disbursed" || app.status === "completed") {
        const referenceDate = app.application_date;
        if (!referenceDate) return;
        const date = new Date(referenceDate);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        if (!monthlyFinancial[monthKey]) {
          monthlyFinancial[monthKey] = {
            month: date.toLocaleDateString('id-ID', {
              month: 'long'
            }),
            year: date.getFullYear(),
            totalDisbursed: 0,
            totalCollected: 0,
            penaltiesPaid: 0,
            adminFeesCollected: 0,
            totalExpenses: 0,
            totalIncentives: 0,
            netIncome: 0
          };
        }
        monthlyFinancial[monthKey].totalDisbursed += Number(app.amount_approved || 0);

        // Admin fee dari yang tercatat permanen di aplikasi ini
        if (app.admin_fee_amount && Number(app.admin_fee_amount) > 0) {
          monthlyFinancial[monthKey].adminFeesCollected += Number(app.admin_fee_amount);
        }
      }
    });

    // Process collected amounts - SAMA SEPERTI DASHBOARD: HANYA dari paid_at
    // KONSISTENSI: Gunakan Cash Basis Accounting - hanya hitung pembayaran yang benar-benar terjadi
    let debugTotalOctober = 0;
    let debugCountOctober = 0;
    allInstallments?.forEach(installment => {
      // Skip jika tidak ada pembayaran atau tidak ada paid_at, atau status bukan paid/partial
      const paidAmount = Number(installment.paid_amount || 0);
      const isValidStatus = installment.status === 'paid' || installment.status === 'partial';
      if (paidAmount <= 0 || !installment.paid_at || !isValidStatus) {
        return;
      }

      // HANYA gunakan paid_at - tanggal pembayaran AKTUAL
      const referenceDate = new Date(installment.paid_at);
      const monthKey = `${referenceDate.getFullYear()}-${String(referenceDate.getMonth() + 1).padStart(2, '0')}`;

      // Debug untuk Oktober 2025
      if (monthKey === '2025-10') {
        debugTotalOctober += paidAmount;
        debugCountOctober++;
      }
      if (!monthlyFinancial[monthKey]) {
        monthlyFinancial[monthKey] = {
          month: referenceDate.toLocaleDateString('id-ID', {
            month: 'long'
          }),
          year: referenceDate.getFullYear(),
          totalDisbursed: 0,
          totalCollected: 0,
          penaltiesPaid: 0,
          adminFeesCollected: 0,
          totalExpenses: 0,
          totalIncentives: 0,
          netIncome: 0
        };
      }

      // Tambahkan paid_amount dari installment ke totalCollected bulan tersebut
      monthlyFinancial[monthKey].totalCollected += paidAmount;
    });
    console.log('🔍 DEBUG REPORTS Oktober 2025:', {
      totalCollected: debugTotalOctober,
      count: debugCountOctober,
      formatted: formatRupiah(debugTotalOctober)
    });

    // Hitung denda terbayar per bulan - CARA BARU: dari selisih payment vs paid_amount untuk installment yang principal_paid=true
    // Alokasikan ke bulan berdasarkan paid_at
    paidPenaltyInstallments.forEach(i => {
      if (!i.paid_at) return; // Skip jika tidak ada paid_at

      const totalPaymentForInst = paidPenaltyPaymentsMap.get(i.id) || 0;
      const paidAmount = Number(i.paid_amount || 0);
      const penaltyForInst = Math.max(0, totalPaymentForInst - paidAmount);
      if (penaltyForInst > 0) {
        const referenceDate = new Date(i.paid_at);
        const monthKey = `${referenceDate.getFullYear()}-${String(referenceDate.getMonth() + 1).padStart(2, '0')}`;
        if (!monthlyFinancial[monthKey]) {
          monthlyFinancial[monthKey] = {
            month: referenceDate.toLocaleDateString('id-ID', {
              month: 'long'
            }),
            year: referenceDate.getFullYear(),
            totalDisbursed: 0,
            totalCollected: 0,
            penaltiesPaid: 0,
            adminFeesCollected: 0,
            totalExpenses: 0,
            totalIncentives: 0,
            netIncome: 0
          };
        }
        monthlyFinancial[monthKey].penaltiesPaid += penaltyForInst;
      }
    });

    // Process expenses - hanya yang status 'verified'
    const verifiedExpenses = (expenses as any[] || []).filter(e => e.status === 'verified');
    let totalExpensesSum = 0;
    verifiedExpenses.forEach(expense => {
      if (!expense.expense_date) return;
      const expenseAmount = Number(expense.amount || 0);
      totalExpensesSum += expenseAmount;
      const date = new Date(expense.expense_date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (!monthlyFinancial[monthKey]) {
        monthlyFinancial[monthKey] = {
          month: date.toLocaleDateString('id-ID', { month: 'long' }),
          year: date.getFullYear(),
          totalDisbursed: 0,
          totalCollected: 0,
          penaltiesPaid: 0,
          adminFeesCollected: 0,
          totalExpenses: 0,
          totalIncentives: 0,
          netIncome: 0
        };
      }
      monthlyFinancial[monthKey].totalExpenses += expenseAmount;
    });
    setTotalOperationalExpenses(totalExpensesSum);

    // Process incentive withdrawals per month based on reviewed_at date
    if (approvedWithdrawals) {
      approvedWithdrawals.forEach(withdrawal => {
        if (!withdrawal.reviewed_at) return;
        const amount = Number(withdrawal.amount || 0);
        const date = new Date(withdrawal.reviewed_at);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        if (!monthlyFinancial[monthKey]) {
          monthlyFinancial[monthKey] = {
            month: date.toLocaleDateString('id-ID', { month: 'long' }),
            year: date.getFullYear(),
            totalDisbursed: 0,
            totalCollected: 0,
            penaltiesPaid: 0,
            adminFeesCollected: 0,
            totalExpenses: 0,
            totalIncentives: 0,
            netIncome: 0
          };
        }
        monthlyFinancial[monthKey].totalIncentives += amount;
      });
    }

    // Calculate net income for each month (include expenses and incentives)
    Object.values(monthlyFinancial).forEach(month => {
      month.netIncome = month.totalCollected + month.adminFeesCollected + month.penaltiesPaid - month.totalDisbursed - month.totalExpenses - month.totalIncentives;
    });

    // Convert to array and sort by date - FILTER HANYA BULAN YANG SUDAH TERJADI
    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const monthlyArray = Object.keys(monthlyFinancial).sort((a, b) => b.localeCompare(a)).map(key => monthlyFinancial[key]);
    setMonthlyData(monthlyArray);

    // Extract unique years from monthly data and sort descending
    const years = [...new Set(monthlyArray.map(m => m.year))].sort((a, b) => b - a);
    setAvailableYears(years);

    // Update selected year if current selection has no data
    if (years.length > 0 && !years.includes(selectedYear)) {
      setSelectedYear(years[0]);
    }

    // Hitung pertumbuhan nasabah berbasis TANGGAL PENGAJUAN PERTAMA (application_date), fallback ke created_at
    // 1) Peta tanggal paling awal per nasabah dari aplikasi kredit
    const earliestByCustomer: Record<string, Date> = {};
    (applications as any[] || []).forEach(app => {
      const ts = new Date(app.application_date ?? app.created_at);
      const current = earliestByCustomer[app.customer_id];
      if (!current || ts < current) earliestByCustomer[app.customer_id] = ts;
    });

    // 2) Ambil semua nasabah, gunakan tanggal paling awal dari peta di atas, fallback ke created_at nasabah
    const allCustomers = customers as any[] || [];
    const customerGrowth: {
      [key: string]: CustomerGrowthData;
    } = {};
    const customersByMonth: {
      [key: string]: Set<string>;
    } = {};
    allCustomers.forEach(customer => {
      const baseDate = earliestByCustomer[customer.id] ?? new Date(customer.created_at);
      const monthKey = `${baseDate.getFullYear()}-${String(baseDate.getMonth() + 1).padStart(2, '0')}`;
      if (!customerGrowth[monthKey]) {
        customerGrowth[monthKey] = {
          month: baseDate.toLocaleDateString('id-ID', {
            month: 'short',
            year: 'numeric'
          }),
          year: baseDate.getFullYear(),
          newCustomers: 0,
          totalCustomers: 0
        };
      }
      if (!customersByMonth[monthKey]) customersByMonth[monthKey] = new Set();
      customersByMonth[monthKey].add(customer.id);
    });

    // 3) Hitung kumulatif
    let cumulativeCustomers = new Set<string>();
    const sortedMonths = Object.keys(customerGrowth).sort();
    sortedMonths.forEach(monthKey => {
      const monthCustomers = customersByMonth[monthKey] || new Set<string>();
      const newCustomersCount = monthCustomers.size;
      monthCustomers.forEach(c => cumulativeCustomers.add(c));
      customerGrowth[monthKey].newCustomers = newCustomersCount;
      customerGrowth[monthKey].totalCustomers = cumulativeCustomers.size;
    });
    const customerGrowthArray = sortedMonths.filter(key => key <= currentMonthKey) // Filter hanya bulan sampai sekarang
    .sort((a, b) => b.localeCompare(a)).map(key => customerGrowth[key]);
    setCustomerGrowthData(customerGrowthArray);

    // Prepare detailed applications
    const detailedApps: DetailedApplication[] = allApplications?.filter(a => a.status === "approved" || a.status === "disbursed" || a.status === "completed").map(app => {
      const appInstallments = (allInstallments as any[])?.filter(i => i.application_id === app.id) || [];

      // Total Paid - SAMA SEPERTI DASHBOARD: hanya dari paid_amount (pokok + bunga)
      const totalPaid = appInstallments.reduce((sum, i) => sum + Number(i.paid_amount || 0), 0);
      const totalOutstanding = appInstallments.filter(i => i.status !== "paid").reduce((sum, i) => sum + (Number(i.total_amount) - Number(i.paid_amount)), 0);

      // Calculate penalties paid - SAMA SEPERTI DASHBOARD
      const appPayments = allPayments?.filter(p => p.application_id === app.id) || [];
      const historicalAppPayments = appPayments.filter(p => p.notes && p.notes.includes("Input data kredit lama"));
      const historicalAppPaymentsTotal = historicalAppPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const totalAppPaymentsAmount = appPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const totalAppPaidFromInstallments = appInstallments.reduce((sum, i) => sum + Number(i.paid_amount || 0), 0);
      const penaltiesPaid = Math.max(0, totalAppPaymentsAmount - totalAppPaidFromInstallments - historicalAppPaymentsTotal);

      // Calculate penalties unpaid - REALTIME calculation (for sales dashboard)
      let penaltiesUnpaid = 0;
      const today = new Date();
      appInstallments.forEach(i => {
        if (i.principal_paid) {
          // Jika pokok sudah lunas, gunakan frozen penalty
          penaltiesUnpaid += Number(i.frozen_penalty || 0);
        } else if (i.status === "overdue") {
          // Jika masih menunggak, hitung denda secara realtime
          const dueDate = new Date(i.due_date);
          const daysOverdue = Math.max(0, Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
          if (daysOverdue > 0) {
            const unpaidAmount = Number(i.total_amount) - Number(i.paid_amount || 0);
            const penalty = unpaidAmount * (penaltyRate / 100) * daysOverdue;
            // Round penalty to nearest 1000 (round up)
            const roundedPenalty = Math.ceil(penalty / 1000) * 1000;
            penaltiesUnpaid += roundedPenalty;
          }
        } else if (i.status !== 'paid') {
          // Untuk status lainnya (unpaid, partial), gunakan frozen_penalty
          penaltiesUnpaid += Number(i.frozen_penalty || 0);
        }
      });
      return {
        id: app.id,
        application_number: app.application_number,
        customer_name: app.customers?.full_name || "-",
        member_name: app.members?.full_name || "-",
        amount_approved: Number(app.amount_approved),
        status: app.status,
        approved_at: app.approved_at || app.created_at,
        application_date: app.application_date,
        total_paid: totalPaid,
        total_outstanding: totalOutstanding,
        penalties_paid: penaltiesPaid,
        penalties_unpaid: penaltiesUnpaid,
        tenor_months: app.tenor_months || 0,
        total_installments: appInstallments.length
      };
    }) || [];
    setDetailedApplications(detailedApps);
    setLoading(false);
  };
  const calculatePerformanceScore = (member: MemberPerformance) => {
    let score = 0;

    // 1. Approval Rate (40 points max)
    const approvalScore = member.approvalRate / 100 * 40;
    score += approvalScore;

    // 2. Collection Rate (35 points max)
    // Collection Rate = Perbandingan aplikasi performing vs total approved applications
    const collectionRate = member.approvedApplications > 0 ? member.performingApplications / member.approvedApplications * 100 : 0;
    const collectionScore = collectionRate / 100 * 35;
    score += collectionScore;

    // 3. Outstanding Penalty Impact (15 points deduction max)
    // Semakin besar denda, semakin besar pengurangan
    const penaltyRatio = member.totalDisbursed > 0 ? member.outstandingPenalties / member.totalDisbursed * 100 : 0;
    const penaltyDeduction = Math.min(15, penaltyRatio * 3); // Max 15 points deduction
    score -= penaltyDeduction;

    // 4. Outstanding Installments Impact (10 points deduction max)
    const outstandingRatio = member.totalDisbursed > 0 ? member.outstandingInstallments / member.totalDisbursed * 100 : 0;
    const outstandingDeduction = Math.min(10, outstandingRatio / 10);
    score -= outstandingDeduction;

    // Ensure score is between 0 and 100
    return Math.max(0, Math.min(100, score));
  };
  const getPerformanceBadge = (member: MemberPerformance) => {
    const score = calculatePerformanceScore(member);
    if (score >= 80) return <Badge className="bg-success">Excellent ({score.toFixed(0)})</Badge>;
    if (score >= 65) return <Badge className="bg-primary">Good ({score.toFixed(0)})</Badge>;
    if (score >= 50) return <Badge className="bg-warning">Fair ({score.toFixed(0)})</Badge>;
    if (score >= 35) return <Badge variant="secondary">Poor ({score.toFixed(0)})</Badge>;
    return <Badge variant="destructive">Very Poor ({score.toFixed(0)})</Badge>;
  };
  const filterDetailedData = (data: DetailedApplication[]) => {
    if (!detailedSearch.trim()) return data;
    const search = detailedSearch.toLowerCase();
    return data.filter(app => app.application_number.toLowerCase().includes(search) || app.customer_name.toLowerCase().includes(search) || app.member_name.toLowerCase().includes(search));
  };
  const paginateData = (data: DetailedApplication[], page: number) => {
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return data.slice(startIndex, endIndex);
  };
  const getTotalPages = (dataLength: number) => {
    return Math.ceil(dataLength / itemsPerPage);
  };

  // Helper untuk membatasi nomor halaman yang ditampilkan di detailed applications
  const getDetailedPaginationRange = () => {
    const totalDetailedPages = getTotalPages(filterDetailedData(detailedApplications).length);
    const delta = isMobile ? 1 : 2;
    const range: (number | string)[] = [];
    const rangeWithDots: (number | string)[] = [];
    for (let i = Math.max(2, detailedPage - delta); i <= Math.min(totalDetailedPages - 1, detailedPage + delta); i++) {
      range.push(i);
    }
    if (detailedPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }
    rangeWithDots.push(...range);
    if (detailedPage + delta < totalDetailedPages - 1) {
      rangeWithDots.push('...', totalDetailedPages);
    } else if (totalDetailedPages > 1) {
      rangeWithDots.push(totalDetailedPages);
    }
    return rangeWithDots;
  };
  const downloadAnnualReport = async () => {
    const filteredData = monthlyData.filter(m => m.year === selectedYear);

    // Calculate yearly totals
    const yearlyTotals = filteredData.reduce((acc, month) => ({
      totalDisbursed: acc.totalDisbursed + month.totalDisbursed,
      totalCollected: acc.totalCollected + month.totalCollected,
      penaltiesPaid: acc.penaltiesPaid + month.penaltiesPaid,
      adminFeesCollected: acc.adminFeesCollected + month.adminFeesCollected,
      netIncome: acc.netIncome + month.netIncome
    }), {
      totalDisbursed: 0,
      totalCollected: 0,
      penaltiesPaid: 0,
      adminFeesCollected: 0,
      netIncome: 0
    });
    const doc = new Document({
      sections: [{
        children: [new Paragraph({
          text: `LAPORAN KEUANGAN TAHUNAN ${selectedYear}`,
          alignment: AlignmentType.CENTER,
          spacing: {
            after: 400
          }
        }), new Paragraph({
          text: `Tanggal: ${new Date().toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}`,
          alignment: AlignmentType.CENTER,
          spacing: {
            after: 600
          }
        }), new DocTable({
          width: {
            size: 100,
            type: WidthType.PERCENTAGE
          },
          rows: [new DocTableRow({
            children: [new DocTableCell({
              children: [new Paragraph({
                text: "Bulan"
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: "Pengeluaran (Modal)"
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: "Pemasukan (Angsuran)"
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: "Biaya Admin"
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: "Denda Terbayar"
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: "Pendapatan Bersih"
              })]
            })]
          }), ...filteredData.map(month => new DocTableRow({
            children: [new DocTableCell({
              children: [new Paragraph({
                text: month.month
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(month.totalDisbursed)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(month.totalCollected)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(month.adminFeesCollected)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(month.penaltiesPaid)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(month.netIncome)
              })]
            })]
          })), new DocTableRow({
            children: [new DocTableCell({
              children: [new Paragraph({
                text: "TOTAL"
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(yearlyTotals.totalDisbursed)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(yearlyTotals.totalCollected)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(yearlyTotals.adminFeesCollected)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(yearlyTotals.penaltiesPaid)
              })]
            }), new DocTableCell({
              children: [new Paragraph({
                text: formatRupiah(yearlyTotals.netIncome)
              })]
            })]
          })]
        })]
      }]
    });
    const blob = await Packer.toBlob(doc);
    saveAs(blob, `Laporan-Keuangan-${selectedYear}.docx`);
  };
  return <div className="w-full max-w-full overflow-hidden">
      {/* Show header for owner/admin only */}
      {!(isSales && !isOwner && !isAdmin) && <header className="mb-3">
          <div className="flex items-center gap-3">
            <FileBarChart className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
            <div>
              <h1 className="text-2xl font-semibold">Laporan</h1>
              
            </div>
          </div>
        </header>}

      <Tabs value={activeTab} onValueChange={val => {
      setActiveTab(val);
      const newParams = new URLSearchParams(location.search);
      newParams.set('tab', val);
      navigate({
        search: newParams.toString()
      }, {
        replace: true
      });
    }} className="space-y-6">
        {/* Show TabsList for Owner and Admin - they can access all tabs including 'detailed' */}
        {/* Sales (non-owner, non-admin) don't see TabsList - they only see 'detailed' tab by default */}
        {!(isSales && !isOwner && !isAdmin) && <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1">
            <TabsTrigger value="charts" className="text-xs flex items-center gap-1.5">
              <BarChart3 className="h-4 w-4" />
              <span>Grafik Kinerja</span>
            </TabsTrigger>
            <TabsTrigger value="performance" className="text-xs flex items-center gap-1.5">
              <Users className="h-4 w-4" />
              <span>Kinerja Anggota</span>
            </TabsTrigger>
            <TabsTrigger value="annual" className="text-xs flex items-center gap-1.5" onClick={e => {
          if (isPhone) {
            e.preventDefault();
            setShowYearSelectorDialog(true);
          }
        }}>
              <Calendar className="h-4 w-4" />
              <span>Laporan Tahunan</span>
            </TabsTrigger>
            <TabsTrigger value="incentives" className="text-xs flex items-center gap-1.5">
              <Award className="h-4 w-4" />
              <span>Laporan Insentif</span>
            </TabsTrigger>
          </TabsList>}

        <TabsContent value="charts" className="mt-3 space-y-6">
{/* Monthly Financial Performance */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Kinerja Keuangan Bulanan
              </CardTitle>
              <Select value={chartYearFilter} onValueChange={setChartYearFilter}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Pilih Periode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last12">12 Bulan Terakhir</SelectItem>
                  {availableYears.map(year => (
                    <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={
                  chartYearFilter === "last12" 
                    ? monthlyData.slice(0, 12).reverse()
                    : monthlyData.filter(m => m.year === Number(chartYearFilter)).reverse()
                }>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="month" 
                    tickFormatter={(value, index) => {
                      const filteredData = chartYearFilter === "last12" 
                        ? monthlyData.slice(0, 12).reverse()
                        : monthlyData.filter(m => m.year === Number(chartYearFilter)).reverse();
                      const dataIndex = filteredData[index];
                      if (dataIndex) {
                        const shortMonth = value.substring(0, 3);
                        const shortYear = String(dataIndex.year).slice(-2);
                        return `${shortMonth} ${shortYear}`;
                      }
                      return value;
                    }}
                  />
                  <YAxis tickFormatter={formatYAxisValue} />
                  <Tooltip 
                    formatter={(value: number) => formatRupiah(value)} 
                    labelFormatter={(label, payload) => {
                      if (payload && payload.length > 0 && payload[0].payload) {
                        const data = payload[0].payload as MonthlyFinancialData;
                        return `${data.month} ${data.year}`;
                      }
                      return label;
                    }}
                  />
                  <Legend />
                  <Bar dataKey="adminFeesCollected" name="Biaya Admin" fill="#3b82f6" animationDuration={600} animationEasing="ease-in-out" />
                  <Bar dataKey="totalExpenses" name="Biaya Operasional" fill="#a855f7" animationDuration={600} animationEasing="ease-in-out" animationBegin={100} />
                  <Bar dataKey="totalIncentives" name="Pengeluaran Insentif" fill="#ec4899" animationDuration={600} animationEasing="ease-in-out" animationBegin={200} />
                  <Bar dataKey="penaltiesPaid" name="Denda" fill="#f59e0b" animationDuration={600} animationEasing="ease-in-out" animationBegin={300} />
                  <Bar dataKey="totalDisbursed" name="Modal Keluar" fill="#ef4444" animationDuration={600} animationEasing="ease-in-out" animationBegin={400} />
                  <Bar dataKey="totalCollected" name="Pemasukan" fill="#22c55e" animationDuration={600} animationEasing="ease-in-out" animationBegin={500} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Net Income Trend */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Tren Pendapatan Bersih
              </CardTitle>
              <Select value={trendYearFilter} onValueChange={setTrendYearFilter}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Pilih Periode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last12">12 Bulan Terakhir</SelectItem>
                  {availableYears.map(year => (
                    <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={
                  trendYearFilter === "last12" 
                    ? monthlyData.slice(0, 12).reverse()
                    : monthlyData.filter(m => m.year === Number(trendYearFilter)).reverse()
                }>
                  <defs>
                    <linearGradient id="positiveGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#22c55e" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="negativeGradient" x1="0" y1="1" x2="0" y2="0">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="month" 
                    tickFormatter={(value, index) => {
                      const filteredData = trendYearFilter === "last12" 
                        ? monthlyData.slice(0, 12).reverse()
                        : monthlyData.filter(m => m.year === Number(trendYearFilter)).reverse();
                      const dataIndex = filteredData[index];
                      if (dataIndex) {
                        const shortMonth = value.substring(0, 3);
                        const shortYear = String(dataIndex.year).slice(-2);
                        return `${shortMonth} ${shortYear}`;
                      }
                      return value;
                    }}
                  />
                  <YAxis 
                    tickFormatter={formatYAxisValue} 
                    tick={(props: any) => {
                      const { x, y, payload } = props;
                      const isZero = payload.value === 0;
                      return (
                        <text 
                          x={x} 
                          y={y} 
                          dy={4} 
                          textAnchor="end" 
                          fill={isZero ? '#3b82f6' : '#666'}
                          fontWeight={isZero ? 'bold' : 'normal'}
                          fontSize={12}
                        >
                          {formatYAxisValue(payload.value)}
                        </text>
                      );
                    }}
                  />
                  <ReferenceLine y={0} stroke="#3b82f6" strokeWidth={2} />
                  <Tooltip 
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length > 0) {
                        const data = payload[0].payload as MonthlyFinancialData;
                        return (
                          <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
                            <p className="font-semibold text-sm mb-2">{data.month} {data.year}</p>
                            <div className="space-y-1 text-xs">
                              <div className="flex justify-between gap-4">
                                <span className="text-green-600">+ Pemasukan</span>
                                <span className="font-medium">{formatRupiah(data.totalCollected)}</span>
                              </div>
                              <div className="flex justify-between gap-4">
                                <span className="text-blue-600">+ Biaya Admin</span>
                                <span className="font-medium">{formatRupiah(data.adminFeesCollected)}</span>
                              </div>
                              <div className="flex justify-between gap-4">
                                <span className="text-amber-600">+ Denda</span>
                                <span className="font-medium">{formatRupiah(data.penaltiesPaid)}</span>
                              </div>
                              <div className="border-t border-border my-1.5 pt-1.5">
                                <div className="flex justify-between gap-4">
                                  <span className="text-red-600">- Modal Keluar</span>
                                  <span className="font-medium">{formatRupiah(data.totalDisbursed)}</span>
                                </div>
                                <div className="flex justify-between gap-4">
                                  <span className="text-purple-600">- Biaya Operasional</span>
                                  <span className="font-medium">{formatRupiah(data.totalExpenses)}</span>
                                </div>
                                <div className="flex justify-between gap-4">
                                  <span className="text-pink-600">- Pengeluaran Insentif</span>
                                  <span className="font-medium">{formatRupiah(data.totalIncentives)}</span>
                                </div>
                              </div>
                              <div className="border-t border-border pt-1.5 mt-1.5">
                                <div className="flex justify-between gap-4">
                                  <span className={`font-bold ${data.netIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                    = Pendapatan Bersih
                                  </span>
                                  <span className={`font-bold ${data.netIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                    {formatRupiah(data.netIncome)}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend 
                    payload={[
                      { value: 'Surplus (Positif)', type: 'rect', color: '#22c55e' },
                      { value: 'Defisit (Negatif)', type: 'rect', color: '#ef4444' }
                    ]}
                  />
                  {/* Area untuk nilai positif */}
                  <Area 
                    type="monotone" 
                    dataKey={(data: MonthlyFinancialData) => data.netIncome >= 0 ? data.netIncome : 0}
                    name="Surplus" 
                    stroke="#22c55e" 
                    strokeWidth={2}
                    fill="url(#positiveGradient)"
                    connectNulls
                    animationDuration={800}
                    animationEasing="ease-in-out"
                  />
                  {/* Area untuk nilai negatif */}
                  <Area 
                    type="monotone" 
                    dataKey={(data: MonthlyFinancialData) => data.netIncome < 0 ? data.netIncome : 0}
                    name="Defisit" 
                    stroke="#ef4444" 
                    strokeWidth={2}
                    fill="url(#negativeGradient)"
                    connectNulls
                    animationDuration={800}
                    animationEasing="ease-in-out"
                    animationBegin={100}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Customer Growth */}
          <Card>
            <CardHeader className="p-2 sm:p-4 flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-1.5 sm:gap-2 text-sm sm:text-base">
                <Users className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                Pertumbuhan Nasabah
              </CardTitle>
              <Select value={customerGrowthYearFilter} onValueChange={setCustomerGrowthYearFilter}>
                <SelectTrigger className="w-[140px] sm:w-[160px] h-8 text-xs sm:text-sm">
                  <SelectValue placeholder="Pilih Periode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last12">12 Bulan Terakhir</SelectItem>
                  {availableYears.map(year => (
                    <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent className="p-2 sm:p-4 pt-0">
              <div className="w-full overflow-x-auto -mx-2 sm:mx-0">
                <div className="min-w-[400px] sm:min-w-0">
                  <ResponsiveContainer width="100%" height={isMobile ? 200 : 280}>
                    <LineChart data={
                      customerGrowthYearFilter === "last12" 
                        ? customerGrowthData.slice(0, 12).reverse()
                        : customerGrowthData.filter(m => m.year === Number(customerGrowthYearFilter)).reverse()
                    }>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis 
                        dataKey="month" 
                        tick={{ fontSize: isMobile ? 9 : 11 }} 
                        angle={isMobile ? -45 : 0} 
                        textAnchor={isMobile ? "end" : "middle"} 
                        height={isMobile ? 50 : 30}
                        tickFormatter={(value, index) => {
                          const filteredData = customerGrowthYearFilter === "last12" 
                            ? customerGrowthData.slice(0, 12).reverse()
                            : customerGrowthData.filter(m => m.year === Number(customerGrowthYearFilter)).reverse();
                          const dataIndex = filteredData[index];
                          if (dataIndex) {
                            const shortMonth = value.substring(0, 3);
                            const shortYear = String(dataIndex.year).slice(-2);
                            return `${shortMonth} ${shortYear}`;
                          }
                          return value;
                        }}
                      />
                      <YAxis tick={{ fontSize: isMobile ? 9 : 11 }} width={isMobile ? 35 : 50} tickFormatter={formatYAxisValue} />
                      <Tooltip 
                        contentStyle={{
                          fontSize: isMobile ? '10px' : '12px',
                          backgroundColor: 'hsl(var(--background))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '6px',
                          padding: isMobile ? '4px 8px' : '8px 12px'
                        }}
                        labelFormatter={(label, payload) => {
                          if (payload && payload.length > 0 && payload[0].payload) {
                            const data = payload[0].payload as CustomerGrowthData;
                            return `${data.month} ${data.year}`;
                          }
                          return label;
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: isMobile ? '10px' : '11px' }} iconSize={isMobile ? 8 : 12} />
                      <Line type="monotone" dataKey="newCustomers" name="Baru" stroke="hsl(var(--success))" strokeWidth={isMobile ? 1.5 : 2} dot={{ fill: 'hsl(var(--success))', r: isMobile ? 2 : 3 }} animationDuration={800} animationEasing="ease-in-out" />
                      <Line type="monotone" dataKey="totalCustomers" name="Total" stroke="hsl(var(--primary))" strokeWidth={isMobile ? 1.5 : 2} dot={{ fill: 'hsl(var(--primary))', r: isMobile ? 2 : 3 }} animationDuration={800} animationEasing="ease-in-out" animationBegin={200} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Summary Cards */}
              <div className="grid grid-cols-2 gap-1.5 sm:gap-3 mt-2 sm:mt-4">
                <div className="text-center p-1.5 sm:p-2.5 bg-success/10 rounded-lg">
                  <p className="text-[9px] sm:text-xs text-muted-foreground mb-0.5 sm:mb-1">Nasabah Baru</p>
                  <p className="text-sm sm:text-lg font-bold text-success">
                    {(customerGrowthYearFilter === "last12" 
                      ? customerGrowthData.slice(0, 12)
                      : customerGrowthData.filter(m => m.year === Number(customerGrowthYearFilter))
                    ).reduce((sum, data) => sum + data.newCustomers, 0)}
                  </p>
                  <p className="text-[8px] sm:text-[10px] text-muted-foreground mt-0.5">
                    {customerGrowthYearFilter === "last12" ? "12 Bulan" : customerGrowthYearFilter}
                  </p>
                </div>
                <div className="text-center p-1.5 sm:p-2.5 bg-primary/10 rounded-lg">
                  <p className="text-[9px] sm:text-xs text-muted-foreground mb-0.5 sm:mb-1">Total Saat Ini</p>
                  <p className="text-sm sm:text-lg font-bold text-primary">
                    {customerGrowthData.length > 0 ? customerGrowthData[0].totalCustomers : 0}
                  </p>
                  <p className="text-[8px] sm:text-[10px] text-muted-foreground mt-0.5">Akumulasi</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            {/* Capital Recovery Progress - Kurva Modal */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Kurva Modal
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(() => {
                const modalKeluar = financialStats.totalDisbursed;
                const pengeluaranInsentif = totalPaidIncentives + totalPaidYearEndBonus;
                const totalPengeluaranAll = pengeluaranInsentif + totalOperationalExpenses;
                const totalPengeluaran = modalKeluar + totalPengeluaranAll;
                const modalKembali = financialStats.totalCollected + financialStats.totalAdminFees + financialStats.totalPenaltiesPaid;
                const sisaModal = Math.max(0, totalPengeluaran - modalKembali);
                const recoveryPercent = totalPengeluaran > 0 ? modalKembali / totalPengeluaran * 100 : 0;
                const remainingPercent = totalPengeluaran > 0 ? sisaModal / totalPengeluaran * 100 : 0;

                // Calculate net recovery (modal kembali dikurangi semua pengeluaran)
                const netModalKembali = Math.max(0, modalKembali - totalPengeluaranAll);
                const sisaModalKeluar = Math.max(0, modalKeluar - netModalKembali);
                const netRecoveryPercent = modalKeluar > 0 ? netModalKembali / modalKeluar * 100 : 0;
                return <>
                      <ResponsiveContainer width="100%" height={300}>
                        <RechartsPie>
                          <Pie data={[{
                        name: "Modal Kembali Bersih",
                        value: netModalKembali
                      }, {
                        name: "Pengeluaran Operasional",
                        value: totalOperationalExpenses
                      }, {
                        name: "Sisa Modal Keluar",
                        value: sisaModalKeluar
                      }, {
                        name: "Pengeluaran Insentif",
                        value: pengeluaranInsentif
                      }].filter(d => d.value > 0)} cx="50%" cy="50%" innerRadius={50} outerRadius={80} fill="#8884d8" dataKey="value" labelLine={false} label={({
                        name,
                        percent
                      }) => `${(percent * 100).toFixed(1)}%`}>
                            <Cell fill="#22c55e" />
                            <Cell fill="#ef4444" />
                            <Cell fill="#f59e0b" />
                            <Cell fill="#a855f7" />
                          </Pie>
                          <Tooltip formatter={(value: number) => formatRupiah(value)} />
                          <Legend verticalAlign="bottom" height={36} formatter={value => <span className="text-xs">{value}</span>} />
                        </RechartsPie>
                      </ResponsiveContainer>
                      
                      {/* Visual Progress Info */}
                      <div className="space-y-3 mt-4">
                        {/* Progress Bar - Net Recovery */}
                        <div className="relative">
                          <div className="h-3 bg-amber-100 dark:bg-amber-950/30 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all duration-500" style={{
                          width: `${Math.min(100, netRecoveryPercent)}%`
                        }} />
                          </div>
                          <p className="text-xs text-center mt-1.5 text-muted-foreground">
                            {netRecoveryPercent.toFixed(1)}% modal kembali bersih (setelah dikurangi pengeluaran)
                          </p>
                        </div>
                        
                        {/* Calculation Flow */}
                        <div className="space-y-2 p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-muted-foreground">Modal Keluar</span>
                            <span className="font-bold">{formatRupiah(modalKeluar)}</span>
                          </div>
                          
                          {/* Breakdown Pemasukan */}
                          <div className="pl-2 border-l-2 border-blue-300 space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-blue-600">Pembayaran Angsuran</span>
                              <span className="font-semibold text-blue-600">+ {formatRupiah(financialStats.totalCollected)}</span>
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-green-600">Denda Dibayar</span>
                              <span className="font-semibold text-green-600">+ {formatRupiah(financialStats.totalPenaltiesPaid)}</span>
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-cyan-600">Biaya Admin</span>
                              <span className="font-semibold text-cyan-600">+ {formatRupiah(financialStats.totalAdminFees)}</span>
                            </div>
                            <div className="flex items-center justify-between text-xs pt-1 border-t border-dashed">
                              <span className="text-muted-foreground font-medium">Total Pemasukan</span>
                              <span className="font-bold text-blue-600">{formatRupiah(modalKembali)}</span>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-purple-600">Pengeluaran Insentif</span>
                            <span className="font-bold text-purple-600">- {formatRupiah(pengeluaranInsentif)}</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-red-600">Pengeluaran Operasional</span>
                            <span className="font-bold text-red-600">- {formatRupiah(totalOperationalExpenses)}</span>
                          </div>
                          <Separator className="my-1" />
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-green-600 font-medium">Modal Kembali Bersih</span>
                            <span className="font-bold text-green-600">{formatRupiah(netModalKembali)}</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-amber-600 font-medium">Sisa Modal Keluar</span>
                            <span className="font-bold text-amber-600">{formatRupiah(sisaModalKeluar)}</span>
                          </div>
                        </div>
                        
                        {/* Breakdown Denda & Biaya Admin */}
                        {(financialStats.totalPenaltiesPaid > 0 || financialStats.totalAdminFees > 0) && <div className="border-t pt-2 mt-2">
                            <p className="text-[10px] text-muted-foreground mb-1.5">Detail Pemasukan Denda & Biaya:</p>
                            <div className="grid grid-cols-2 gap-2">
                              <div className="text-center p-1.5 bg-green-50/50 dark:bg-green-950/10 rounded">
                                <p className="text-[9px] text-muted-foreground">Denda Dibayar</p>
                                <p className="text-[11px] font-semibold text-green-600">{formatRupiah(financialStats.totalPenaltiesPaid)}</p>
                              </div>
                              <div className="text-center p-1.5 bg-cyan-50/50 dark:bg-cyan-950/10 rounded">
                                <p className="text-[9px] text-muted-foreground">Biaya Admin</p>
                                <p className="text-[11px] font-semibold text-cyan-600">{formatRupiah(financialStats.totalAdminFees)}</p>
                              </div>
                            </div>
                          </div>}
                        
                        {/* Breakdown Insentif */}
                        {pengeluaranInsentif > 0 && <div className="border-t pt-2 mt-2">
                            <p className="text-[10px] text-muted-foreground mb-1.5">Detail Pengeluaran Insentif:</p>
                            <div className="grid grid-cols-2 gap-2">
                              <div className="text-center p-1.5 bg-purple-50/50 dark:bg-purple-950/10 rounded">
                                <p className="text-[9px] text-muted-foreground">Insentif Bulanan</p>
                                <p className="text-[11px] font-semibold text-purple-600">{formatRupiah(totalPaidIncentives)}</p>
                              </div>
                              <div className="text-center p-1.5 bg-purple-50/50 dark:bg-purple-950/10 rounded">
                                <p className="text-[9px] text-muted-foreground">Bonus Akhir Tahun</p>
                                <p className="text-[11px] font-semibold text-purple-600">{formatRupiah(totalPaidYearEndBonus)}</p>
                              </div>
                            </div>
                          </div>}
                      </div>
                    </>;
              })()}
              </CardContent>
            </Card>

            {/* Combined Status Card - Pengajuan & Angsuran */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Status Kredit & Angsuran
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status Pengajuan Kredit */}
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-1.5">
                    <FileText className="h-4 w-4" />
                    Status Pengajuan Kredit
                  </h4>
                  {(() => {
                  const disetujui = financialStats.approvedApplications;
                  const ditolak = financialStats.rejectedApplications;
                  const belumLunas = financialStats.pendingApplications;
                  const lunas = financialStats.completedApplications;
                  const total = disetujui + ditolak + belumLunas + lunas;
                  const totalAktif = disetujui + belumLunas + lunas;
                  const successRate = total > 0 ? disetujui / (disetujui + ditolak || 1) * 100 : 0;
                  const completionRate = totalAktif > 0 ? lunas / totalAktif * 100 : 0;
                  return <>
                        <ResponsiveContainer width="100%" height={180}>
                          <RechartsPie>
                            <Pie data={[{
                          name: "Lunas",
                          value: lunas
                        }, {
                          name: "Belum Lunas",
                          value: belumLunas
                        }, {
                          name: "Ditolak",
                          value: ditolak
                        }].filter(d => d.value > 0)} cx="50%" cy="50%" innerRadius={35} outerRadius={60} fill="#8884d8" dataKey="value" labelLine={false} label={({
                          percent
                        }) => `${(percent * 100).toFixed(0)}%`}>
                              <Cell fill="#22c55e" />
                              <Cell fill="#f59e0b" />
                              <Cell fill="#ef4444" />
                            </Pie>
                            <Tooltip />
                          </RechartsPie>
                        </ResponsiveContainer>
                        
                        <div className="space-y-2 mt-2">
                          <div>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-muted-foreground">Tingkat Persetujuan</span>
                              <span className="font-medium text-green-600">{successRate.toFixed(1)}%</span>
                            </div>
                            <div className="h-1.5 bg-red-100 dark:bg-red-950/30 rounded-full overflow-hidden">
                              <div className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all duration-500" style={{
                            width: `${successRate}%`
                          }} />
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-muted-foreground">Tingkat Pelunasan</span>
                              <span className="font-medium text-blue-600">{completionRate.toFixed(1)}%</span>
                            </div>
                            <div className="h-1.5 bg-amber-100 dark:bg-amber-950/30 rounded-full overflow-hidden">
                              <div className="h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full transition-all duration-500" style={{
                            width: `${completionRate}%`
                          }} />
                            </div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-4 gap-1 mt-3">
                          <div className="text-center p-1 bg-green-50 dark:bg-green-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Disetujui</p>
                            <p className="text-xs font-bold text-green-600">{disetujui}</p>
                          </div>
                          <div className="text-center p-1 bg-blue-50 dark:bg-blue-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Lunas</p>
                            <p className="text-xs font-bold text-blue-600">{lunas}</p>
                          </div>
                          <div className="text-center p-1 bg-amber-50 dark:bg-amber-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Aktif</p>
                            <p className="text-xs font-bold text-amber-600">{belumLunas}</p>
                          </div>
                          <div className="text-center p-1 bg-red-50 dark:bg-red-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Ditolak</p>
                            <p className="text-xs font-bold text-red-600">{ditolak}</p>
                          </div>
                        </div>
                      </>;
                })()}
                </div>

                <Separator />

                {/* Status Angsuran */}
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4" />
                    Status Angsuran
                  </h4>
                  {(() => {
                  const lunas = financialStats.installmentsPaid;
                  const belumJatuhTempo = financialStats.installmentsUnpaid;
                  const menunggak = financialStats.installmentsOverdue;
                  const total = lunas + belumJatuhTempo + menunggak;
                  const totalJatuhTempo = lunas + menunggak;
                  const paymentRate = total > 0 ? lunas / total * 100 : 0;
                  const overdueRate = totalJatuhTempo > 0 ? menunggak / totalJatuhTempo * 100 : 0;
                  const healthRate = 100 - overdueRate;
                  return <>
                        <ResponsiveContainer width="100%" height={180}>
                          <RechartsPie>
                            <Pie data={[{
                          name: "Lunas",
                          value: lunas
                        }, {
                          name: "Belum Jatuh Tempo",
                          value: belumJatuhTempo
                        }, {
                          name: "Menunggak",
                          value: menunggak
                        }].filter(d => d.value > 0)} cx="50%" cy="50%" innerRadius={35} outerRadius={60} fill="#8884d8" dataKey="value" labelLine={false} label={({
                          percent
                        }) => `${(percent * 100).toFixed(0)}%`}>
                              <Cell fill="#22c55e" />
                              <Cell fill="#3b82f6" />
                              <Cell fill="#ef4444" />
                            </Pie>
                            <Tooltip />
                          </RechartsPie>
                        </ResponsiveContainer>
                        
                        <div className="space-y-2 mt-2">
                          <div>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-muted-foreground">Tingkat Pelunasan</span>
                              <span className="font-medium text-green-600">{paymentRate.toFixed(1)}%</span>
                            </div>
                            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                              <div className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all duration-500" style={{
                            width: `${paymentRate}%`
                          }} />
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-muted-foreground">Kesehatan Angsuran</span>
                              <span className={`font-medium ${healthRate >= 90 ? 'text-green-600' : healthRate >= 70 ? 'text-amber-600' : 'text-red-600'}`}>
                                {healthRate.toFixed(1)}%
                              </span>
                            </div>
                            <div className="h-1.5 bg-red-100 dark:bg-red-950/30 rounded-full overflow-hidden">
                              <div className={`h-full rounded-full transition-all duration-500 ${healthRate >= 90 ? 'bg-gradient-to-r from-green-500 to-green-400' : healthRate >= 70 ? 'bg-gradient-to-r from-amber-500 to-amber-400' : 'bg-gradient-to-r from-red-500 to-red-400'}`} style={{
                            width: `${healthRate}%`
                          }} />
                            </div>
                            
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-1.5 mt-3">
                          <div className="text-center p-1 bg-green-50 dark:bg-green-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Lunas</p>
                            <p className="text-xs font-bold text-green-600">{lunas}</p>
                          </div>
                          <div className="text-center p-1 bg-blue-50 dark:bg-blue-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Belum Tempo</p>
                            <p className="text-xs font-bold text-blue-600">{belumJatuhTempo}</p>
                          </div>
                          <div className="text-center p-1 bg-red-50 dark:bg-red-950/20 rounded">
                            <p className="text-[8px] text-muted-foreground">Menunggak</p>
                            <p className="text-xs font-bold text-red-600">{menunggak}</p>
                          </div>
                        </div>
                      </>;
                })()}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>


        {/* Annual Financial Report Tab - Desktop/Tablet Only */}
        <TabsContent value="annual" className="mt-3 hidden sm:block">
          <Card className="flex flex-col h-full">
            <CardHeader className="py-4 px-6">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="flex items-center gap-1.5 text-base">
                  <Calendar className="h-5 w-5" />
                  Laporan Keuangan Tahunan
                </CardTitle>
                <div className="flex items-center gap-2">
                  <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="px-3 py-2 border rounded-lg bg-background text-sm">
                    {availableYears.length > 0 ? availableYears.map(year => <option key={year} value={year}>{year}</option>) : <option value={new Date().getFullYear()}>{new Date().getFullYear()}</option>}
                  </select>
                  <Button onClick={downloadAnnualReport} size="sm" className="gap-1 text-sm px-4">
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4 flex-1 flex flex-col overflow-hidden">
              <div className="flex flex-1 flex-col overflow-hidden">
                <ScrollArea className="flex-1">
                  <div className="w-full">
                    <Table className="text-[10px] sm:text-xs md:text-sm w-full table-fixed">
                      <TableHeader>
                        <TableRow>
                          <TableHead className="sticky left-0 bg-background z-10 w-[12%] md:w-[10%] px-1 md:px-2">Bulan</TableHead>
                          <TableHead className="text-right w-[13%] px-1 md:px-2">KREDIT</TableHead>
                          <TableHead className="text-right w-[14%] px-1 md:px-2">ANGSURAN</TableHead>
                          <TableHead className="text-right w-[12%] px-1 md:px-2">Admin</TableHead>
                          <TableHead className="text-right w-[11%] px-1 md:px-2">DENDA</TableHead>
                          <TableHead className="text-right w-[14%] px-1 md:px-2">OPERASIONAL</TableHead>
                          <TableHead className="text-right w-[14%] px-1 md:px-2">CASH FLOW</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monthlyData.filter(m => m.year === selectedYear).map((month, index) => <TableRow key={index}>
                            <TableCell className="font-medium sticky left-0 bg-background z-10 px-1 md:px-2 truncate">{month.month}</TableCell>
                          <TableCell className="text-right text-destructive px-1 md:px-2">
                            <button onClick={() => {
                            const monthApps = detailedApplications.filter(app => {
                              const appDate = new Date(app.application_date || app.approved_at);
                              return appDate.toLocaleDateString('id-ID', {
                                month: 'long'
                              }) === month.month && appDate.getFullYear() === month.year;
                            });
                            setSelectedMonthDetail({
                              month: month.month,
                              year: month.year,
                              applications: monthApps
                            });
                          }} className="hover:underline cursor-pointer w-full text-right truncate">
                              {formatRupiah(month.totalDisbursed)}
                            </button>
                          </TableCell>
                            <TableCell className="text-right text-success px-1 md:px-2 truncate">{formatRupiah(month.totalCollected)}</TableCell>
                            <TableCell className="text-right text-primary px-1 md:px-2 truncate">{formatRupiah(month.adminFeesCollected)}</TableCell>
                            <TableCell className="text-right text-warning px-1 md:px-2">
                              <button onClick={() => {
                            // Filter penalty details untuk bulan ini
                            const monthPenalties = penaltyDetails.filter(detail => {
                              const paidDate = new Date(detail.paid_at);
                              return paidDate.toLocaleDateString('id-ID', {
                                month: 'long'
                              }) === month.month && paidDate.getFullYear() === month.year;
                            });
                            setSelectedMonthPenaltyDetails(monthPenalties);
                            setShowPenaltyDetailDialog(true);
                          }} className="hover:underline cursor-pointer w-full text-right truncate" disabled={month.penaltiesPaid === 0}>
                                {formatRupiah(month.penaltiesPaid)}
                              </button>
                            </TableCell>
                            <TableCell className="text-right text-destructive px-1 md:px-2 truncate">{formatRupiah(month.totalExpenses)}</TableCell>
                            <TableCell className={`text-right font-bold px-1 md:px-2 truncate ${month.netIncome >= 0 ? 'text-success' : 'text-destructive'}`}>
                              {formatRupiah(month.netIncome)}
                            </TableCell>
                          </TableRow>)}
                        {monthlyData.filter(m => m.year === selectedYear).length > 0 && <TableRow className="font-bold bg-muted">
                            <TableCell className="sticky left-0 bg-muted z-10 px-1 md:px-2 truncate">TOTAL</TableCell>
                            <TableCell className="text-right text-destructive px-1 md:px-2 truncate">
                              {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.totalDisbursed, 0))}
                            </TableCell>
                            <TableCell className="text-right text-success px-1 md:px-2 truncate">
                              {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.totalCollected, 0))}
                            </TableCell>
                            <TableCell className="text-right text-primary px-1 md:px-2 truncate">
                              {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.adminFeesCollected, 0))}
                            </TableCell>
                            <TableCell className="text-right text-warning px-1 md:px-2 truncate">
                              {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.penaltiesPaid, 0))}
                            </TableCell>
                            <TableCell className="text-right text-destructive px-1 md:px-2 truncate">
                              {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.totalExpenses, 0))}
                            </TableCell>
                            <TableCell className={`text-right px-1 md:px-2 truncate ${monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.netIncome, 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                              {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.netIncome, 0))}
                            </TableCell>
                          </TableRow>}
                      </TableBody>
                    </Table>
                  </div>
                </ScrollArea>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Member Performance Tab */}
        <TabsContent value="performance" className="mt-3 space-y-4 sm:space-y-6">
          <Card>
            <CardHeader className="p-2 sm:p-4">
              <CardTitle className="flex items-center gap-1.5 sm:gap-2 text-sm sm:text-base">
                <Users className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                Kinerja Sales & Admin
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-4 pt-0">
              {/* Mobile & Tablet Card View */}
              <div className="lg:hidden space-y-1.5 sm:space-y-2">
                {memberPerformance.map((member, index) => <Card key={member.id} className="cursor-pointer hover:bg-muted/50 hover:shadow-md hover:scale-[1.01] transition-all duration-200" onClick={() => {
                setSelectedMember(member);
                setShowMemberDialog(true);
              }}>
                    <CardContent className="p-2 sm:p-3">
                      <div className="flex items-start justify-between mb-1.5 sm:mb-2 gap-1">
                        <div className="flex items-center gap-1 sm:gap-1.5 min-w-0">
                          {index < 3 && <Award className="h-3 w-3 sm:h-3.5 sm:w-3.5 text-warning flex-shrink-0" />}
                          <div className="min-w-0">
                            <h3 className="font-semibold text-[11px] sm:text-xs truncate">{member.full_name}</h3>
                            <Badge variant="outline" className="mt-0.5 text-[9px] sm:text-[10px] px-1 py-0">{member.position}</Badge>
                          </div>
                        </div>
                        {getPerformanceBadge(member)}
                      </div>
                      <div className="grid grid-cols-2 gap-1 sm:gap-1.5 text-[9px] sm:text-[10px]">
                        <div className="min-w-0">
                          <p className="text-muted-foreground truncate">Pengajuan</p>
                          <p className="font-semibold text-xs sm:text-sm">{member.totalApplications}</p>
                        </div>
                        <div className="min-w-0">
                          <p className="text-muted-foreground truncate">Disetujui</p>
                          <p className="font-semibold text-success text-xs sm:text-sm">{member.approvedApplications}</p>
                        </div>
                        <div className="min-w-0">
                          <p className="text-muted-foreground truncate">Dicairkan</p>
                          <p className="font-semibold text-[9px] sm:text-[10px] truncate">{(member.totalDisbursed / 1000000).toFixed(1)}jt</p>
                        </div>
                        <div className="min-w-0">
                          <p className="text-muted-foreground truncate">Terkumpul</p>
                          <p className="font-semibold text-success text-[9px] sm:text-[10px] truncate">{(member.totalCollected / 1000000).toFixed(1)}jt</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>)}
                {memberPerformance.length === 0 && <div className="text-center text-muted-foreground py-6 sm:py-8 text-[10px] sm:text-xs">
                    Belum ada data kinerja anggota
                  </div>}
              </div>

              {/* Desktop Table View */}
              <ScrollArea className="h-[calc(100vh-400px)] hidden lg:block">
                <div className="overflow-x-auto min-w-full">
                  <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nama</TableHead>
                      <TableHead>Posisi</TableHead>
                      <TableHead className="text-right">Total Pengajuan</TableHead>
                      <TableHead className="text-right">Disetujui</TableHead>
                      <TableHead className="text-right">Ditolak</TableHead>
                      <TableHead className="text-right">Tingkat Persetujuan</TableHead>
                      <TableHead className="text-right">Total Dicairkan</TableHead>
                      <TableHead className="text-right">Total Dibayar  </TableHead>
                      <TableHead className="text-right">Total Berjalan  </TableHead>
                      <TableHead className="text-right">Denda Belum Dibayar</TableHead>
                      <TableHead className="text-right">Biaya Admin</TableHead>
                      <TableHead>Performa</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {memberPerformance.map((member, index) => <TableRow key={member.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {index < 3 && <Award className="h-4 w-4 text-warning" />}
                            {member.full_name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{member.position}</Badge>
                        </TableCell>
                        <TableCell className="text-right">{member.totalApplications}</TableCell>
                        <TableCell className="text-right text-success">{member.approvedApplications}</TableCell>
                        <TableCell className="text-right text-destructive">{member.rejectedApplications}</TableCell>
                        <TableCell className="text-right">
                          <span className={member.approvalRate >= 70 ? "text-success" : "text-warning"}>
                            {member.approvalRate.toFixed(1)}%
                          </span>
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatRupiah(member.totalDisbursed)}
                        </TableCell>
                        <TableCell className="text-right font-medium text-success">
                          {formatRupiah(member.totalCollected)}
                        </TableCell>
                        <TableCell className="text-right font-medium text-warning">
                          {formatRupiah(member.outstandingInstallments)}
                        </TableCell>
                        <TableCell className="text-right font-medium text-destructive">
                          {formatRupiah(member.outstandingPenalties)}
                        </TableCell>
                        <TableCell className="text-right font-medium text-primary">
                          {formatRupiah(member.adminFeesCollected)}
                        </TableCell>
                        <TableCell>{getPerformanceBadge(member)}</TableCell>
                      </TableRow>)}
                    {memberPerformance.length > 0 && <TableRow className="font-bold bg-muted/50">
                        <TableCell className="font-bold">TOTAL</TableCell>
                        <TableCell></TableCell>
                        <TableCell className="text-right">
                          {memberPerformance.reduce((sum, m) => sum + m.totalApplications, 0)}
                        </TableCell>
                        <TableCell className="text-right text-success">
                          {memberPerformance.reduce((sum, m) => sum + m.approvedApplications, 0)}
                        </TableCell>
                        <TableCell className="text-right text-destructive">
                          {memberPerformance.reduce((sum, m) => sum + m.rejectedApplications, 0)}
                        </TableCell>
                        <TableCell className="text-right">
                          {memberPerformance.length > 0 ? (memberPerformance.reduce((sum, m) => sum + m.approvalRate, 0) / memberPerformance.length).toFixed(1) : 0}%
                        </TableCell>
                        <TableCell className="text-right">
                          {formatRupiah(memberPerformance.reduce((sum, m) => sum + m.totalDisbursed, 0))}
                        </TableCell>
                        <TableCell className="text-right text-success">
                          {formatRupiah(memberPerformance.reduce((sum, m) => sum + m.totalCollected, 0))}
                        </TableCell>
                        <TableCell className="text-right text-warning">
                          {formatRupiah(memberPerformance.reduce((sum, m) => sum + m.outstandingInstallments, 0))}
                        </TableCell>
                        <TableCell className="text-right text-destructive">
                          {formatRupiah(memberPerformance.reduce((sum, m) => sum + m.outstandingPenalties, 0))}
                        </TableCell>
                        <TableCell className="text-right text-primary">
                          {formatRupiah(memberPerformance.reduce((sum, m) => sum + m.adminFeesCollected, 0))}
                        </TableCell>
                        <TableCell></TableCell>
                      </TableRow>}
                    {memberPerformance.length === 0 && <TableRow>
                        <TableCell colSpan={13} className="text-center text-muted-foreground">
                          Belum ada data kinerja anggota
                        </TableCell>
                      </TableRow>}
                    </TableBody>
                  </Table>
                    </div>
                </ScrollArea>
            </CardContent>
          </Card>

          {/* Top Performers */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Award className="h-4 w-4 text-warning" />
                  Top Pencairan
                </CardTitle>
              </CardHeader>
              <CardContent>
                {memberPerformance.slice(0, 3).map((member, idx) => <div key={member.id} className="flex justify-between items-center py-2 border-b last:border-0">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-muted-foreground">#{idx + 1}</span>
                      <span className="font-medium">{member.full_name}</span>
                    </div>
                    <span className="text-sm font-bold text-primary">
                      {formatRupiah(member.totalDisbursed)}
                    </span>
                  </div>)}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  Top Koleksi
                </CardTitle>
              </CardHeader>
              <CardContent>
                {[...memberPerformance].sort((a, b) => b.totalCollected - a.totalCollected).slice(0, 3).map((member, idx) => <div key={member.id} className="flex justify-between items-center py-2 border-b last:border-0">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-muted-foreground">#{idx + 1}</span>
                      <span className="font-medium">{member.full_name}</span>
                    </div>
                    <span className="text-sm font-bold text-success">
                      {formatRupiah(member.totalCollected)}
                    </span>
                  </div>)}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Top Approval Rate
                </CardTitle>
              </CardHeader>
              <CardContent>
                {[...memberPerformance].sort((a, b) => b.approvalRate - a.approvalRate).slice(0, 3).map((member, idx) => <div key={member.id} className="flex justify-between items-center py-2 border-b last:border-0">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-muted-foreground">#{idx + 1}</span>
                      <span className="font-medium">{member.full_name}</span>
                    </div>
                    <span className="text-sm font-bold text-primary">
                      {member.approvalRate.toFixed(1)}%
                    </span>
                  </div>)}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Incentive Report Tab */}
        <TabsContent value="incentives" className="mt-3 space-y-6">
          <IncentiveReport />
        </TabsContent>
      </Tabs>

      {/* Month Detail Dialog - Disbursement Breakdown */}
      <Dialog open={!!selectedMonthDetail} onOpenChange={() => setSelectedMonthDetail(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Detail Pencairan {selectedMonthDetail?.month} {selectedMonthDetail?.year}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Total {selectedMonthDetail?.applications.length || 0} aplikasi dicairkan
            </div>
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>No. Aplikasi</TableHead>
                    <TableHead>Nasabah</TableHead>
                    <TableHead>Tanggal</TableHead>
                    <TableHead className="text-right">Jumlah Pencairan</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedMonthDetail?.applications.map(app => <TableRow key={app.id}>
                      <TableCell className="font-medium">{app.application_number}</TableCell>
                      <TableCell>{app.customer_name}</TableCell>
                      <TableCell>{format(new Date(app.application_date || app.approved_at), 'dd/MM/yyyy')}</TableCell>
                      <TableCell className="text-right font-semibold">
                        {formatRupiah(app.amount_approved)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={app.status === 'completed' ? 'default' : app.status === 'disbursed' ? 'secondary' : 'outline'}>
                          {app.status === 'approved' ? 'Disetujui' : app.status === 'disbursed' ? 'Dicairkan' : app.status === 'completed' ? 'Lunas' : app.status}
                        </Badge>
                      </TableCell>
                    </TableRow>)}
                </TableBody>
              </Table>
            </div>
            <div className="flex justify-end pt-4 border-t">
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Total Pencairan</div>
                <div className="text-2xl font-bold text-destructive">
                  {formatRupiah(selectedMonthDetail?.applications.reduce((sum, app) => sum + app.amount_approved, 0) || 0)}
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Member Performance Detail Dialog */}
      <Dialog open={showMemberDialog} onOpenChange={setShowMemberDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Kinerja Anggota</DialogTitle>
          </DialogHeader>
          {selectedMember && <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg">{selectedMember.full_name}</h3>
                  <Badge variant="outline" className="mt-1">{selectedMember.position}</Badge>
                </div>
                {getPerformanceBadge(selectedMember)}
              </div>
              
              <Separator />
              
              <div className="space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-muted-foreground text-xs">Total Pengajuan</p>
                    <p className="font-bold text-lg">{selectedMember.totalApplications}</p>
                  </div>
                  <div className="p-3 bg-success/10 rounded-lg">
                    <p className="text-muted-foreground text-xs">Disetujui</p>
                    <p className="font-bold text-lg text-success">{selectedMember.approvedApplications}</p>
                  </div>
                  <div className="p-3 bg-destructive/10 rounded-lg">
                    <p className="text-muted-foreground text-xs">Ditolak</p>
                    <p className="font-bold text-lg text-destructive">{selectedMember.rejectedApplications}</p>
                  </div>
                  <div className="p-3 bg-success/10 rounded-lg">
                    <p className="text-muted-foreground text-xs">Kredit Lancar</p>
                    <p className="font-bold text-lg text-success">{selectedMember.performingApplications}</p>
                  </div>
                  <div className="p-3 bg-destructive/10 rounded-lg">
                    <p className="text-muted-foreground text-xs">Kredit Macet (NPL)</p>
                    <p className="font-bold text-lg text-destructive">{selectedMember.nplApplications}</p>
                  </div>
                </div>
                
                <Separator />
                
                <DetailRow label="Tingkat Persetujuan" value={`${selectedMember.approvalRate.toFixed(1)}%`} />
                <DetailRow label="Collection Rate" value={`${selectedMember.approvedApplications > 0 ? (selectedMember.performingApplications / selectedMember.approvedApplications * 100).toFixed(1) : 0}%`} />
                <DetailRow label="Total Dicairkan" value={formatRupiah(selectedMember.totalDisbursed)} />
                <DetailRow label="Total Terkumpul" value={formatRupiah(selectedMember.totalCollected)} />
                <DetailRow label="Biaya Admin" value={formatRupiah(selectedMember.adminFeesCollected)} />
                <DetailRow label="Denda Terkumpul" value={formatRupiah(selectedMember.penaltiesCollected)} />
                <DetailRow label="Tunggakan Angsuran" value={formatRupiah(selectedMember.outstandingInstallments)} />
                <DetailRow label="Denda Belum Dibayar" value={formatRupiah(selectedMember.outstandingPenalties)} />
              </div>
            </div>}
        </DialogContent>
      </Dialog>

      {/* Application Detail Dialog */}
      <Dialog open={showApplicationDialog} onOpenChange={setShowApplicationDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Pinjaman</DialogTitle>
          </DialogHeader>
          {selectedApplication && <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg">{selectedApplication.application_number}</h3>
                  <p className="text-sm text-muted-foreground">{formatDate(selectedApplication.approved_at)}</p>
                </div>
                <Badge variant={selectedApplication.amount_approved > 0 && Math.min(selectedApplication.total_paid / selectedApplication.amount_approved * 100, 100) === 100 ? "default" : "secondary"} className={selectedApplication.amount_approved > 0 && Math.min(selectedApplication.total_paid / selectedApplication.amount_approved * 100, 100) === 100 ? "bg-success" : ""}>
                  {selectedApplication.amount_approved > 0 ? `${Math.min(selectedApplication.total_paid / selectedApplication.amount_approved * 100, 100).toFixed(1)}%` : "0%"}
                </Badge>
              </div>
              
              <Separator />
              
              <div className="space-y-3 text-sm">
                <DetailRow label="Nasabah" value={selectedApplication.customer_name} />
                <DetailRow label="Petugas" value={selectedApplication.member_name} />
                <DetailRow label="Status" value={selectedApplication.status === "approved" || selectedApplication.status === "disbursed" ? "Aktif" : selectedApplication.status} />
                <DetailRow label="Tenor" value={`${selectedApplication.tenor_months} Bulan`} />
                <DetailRow label="Jumlah Angsuran" value={`${selectedApplication.total_installments} Angsuran`} />
                
                <Separator />
                
                <div className="space-y-2">
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span className="text-muted-foreground">Jumlah Disetujui:</span>
                    <span className="font-bold">{formatRupiah(selectedApplication.amount_approved)}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-success/10 rounded">
                    <span className="text-muted-foreground">Total Terbayar:</span>
                    <span className="font-bold text-success">{formatRupiah(selectedApplication.total_paid)}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-warning/10 rounded">
                    <span className="text-muted-foreground">Sisa Piutang:</span>
                    <span className="font-bold text-warning">{formatRupiah(selectedApplication.total_outstanding)}</span>
                  </div>
                </div>
                
                <Separator />
                
                <DetailRow label="Denda Dibayar" value={formatRupiah(selectedApplication.penalties_paid)} />
                <DetailRow label="Denda Belum Dibayar" value={formatRupiah(selectedApplication.penalties_unpaid)} />
              </div>
            </div>}
        </DialogContent>
      </Dialog>

      {/* Year Selector Dialog for Mobile - Shown First */}
      {isPhone && <Dialog open={showYearSelectorDialog} onOpenChange={setShowYearSelectorDialog}>
          <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Pilih Tahun Laporan
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Tahun</label>
              <select value={mobileSelectedYear} onChange={e => setMobileSelectedYear(Number(e.target.value))} className="w-full px-3 py-2 border rounded-lg bg-background">
                {Array.from({
                length: 5
              }, (_, i) => new Date().getFullYear() - i).map(year => <option key={year} value={year}>{year}</option>)}
              </select>
            </div>
            <Button className="w-full" onClick={() => {
            setSelectedYear(mobileSelectedYear);
            setShowYearSelectorDialog(false);
            setShowAnnualDialog(true);
          }}>
              Tampilkan Laporan
            </Button>
          </div>
        </DialogContent>
      </Dialog>}

      {/* Full-Screen Annual Report Dialog for Mobile - Table Only */}
      {isPhone && <Dialog open={showAnnualDialog} onOpenChange={setShowAnnualDialog}>
        <DialogContent className="max-w-[100vw] w-[100vw] h-[100vh] max-h-[100vh] m-0 p-0 flex items-center justify-center rounded-none">
          <div className="w-full h-full overflow-y-auto px-4 py-6 space-y-4">
            {/* Header */}
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold">Laporan Tahunan {selectedYear}</h2>
            </div>

            {/* Monthly Cards */}
            {monthlyData.filter(m => m.year === selectedYear).map((month, index) => <div key={index} className="bg-card border rounded-lg p-4 space-y-3 shadow-sm">
                <div className="font-bold text-lg border-b pb-2 mb-3">
                  {month.month}
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Pengeluaran</span>
                    <span className="text-destructive font-semibold">
                      {formatRupiah(month.totalDisbursed)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Pemasukan</span>
                    <span className="text-success font-semibold">
                      {formatRupiah(month.totalCollected)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Biaya Admin</span>
                    <span className="text-primary font-semibold">
                      {formatRupiah(month.adminFeesCollected)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Denda</span>
                    <span className="text-warning font-semibold">
                      {formatRupiah(month.penaltiesPaid)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center pt-2 border-t">
                    <span className="font-semibold">Pendapatan Bersih</span>
                    <span className={`font-bold text-lg ${month.netIncome >= 0 ? 'text-success' : 'text-destructive'}`}>
                      {formatRupiah(month.netIncome)}
                    </span>
                  </div>
                </div>
              </div>)}

            {/* Total Summary Card */}
            {monthlyData.filter(m => m.year === selectedYear).length > 0 && <div className="bg-muted/50 border rounded-lg p-4 space-y-3 shadow-md">
                <div className="font-bold text-xl border-b pb-2 mb-3">
                  TOTAL TAHUNAN
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium">Total Pengeluaran</span>
                    <span className="text-destructive font-bold text-lg">
                      {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.totalDisbursed, 0))}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium">Total Pemasukan</span>
                    <span className="text-success font-bold text-lg">
                      {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.totalCollected, 0))}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium">Total Admin</span>
                    <span className="text-primary font-bold text-lg">
                      {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.adminFeesCollected, 0))}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium">Total Denda</span>
                    <span className="text-warning font-bold text-lg">
                      {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.penaltiesPaid, 0))}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center pt-3 border-t-2">
                    <span className="font-bold text-lg">PENDAPATAN BERSIH</span>
                    <span className={`font-bold text-2xl ${monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.netIncome, 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                      {formatRupiah(monthlyData.filter(m => m.year === selectedYear).reduce((sum, m) => sum + m.netIncome, 0))}
                    </span>
                  </div>
                </div>
              </div>}
          </div>
        </DialogContent>
      </Dialog>}
      
      {/* Penalty Detail Dialog */}
      <Dialog open={showPenaltyDetailDialog} onOpenChange={setShowPenaltyDetailDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              Perincian Denda Terbayar
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-warning/10 rounded-lg border border-warning/20">
              <span className="font-semibold text-lg">Total Denda:</span>
              <span className="font-bold text-2xl text-warning">
                {formatRupiah(selectedMonthPenaltyDetails.reduce((sum, d) => sum + d.penalty_amount, 0))}
              </span>
            </div>
            
            {selectedMonthPenaltyDetails.length === 0 ? <div className="text-center py-8 text-muted-foreground">
                Tidak ada denda yang terbayar
              </div> : <ScrollArea className="h-[500px] pr-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>No. Aplikasi</TableHead>
                      <TableHead>Nasabah</TableHead>
                      <TableHead>ID Nasabah</TableHead>
                      <TableHead className="text-center">Angsuran Ke</TableHead>
                      <TableHead className="text-right">Total Bayar</TableHead>
                      <TableHead className="text-right">Pokok+Bunga</TableHead>
                      <TableHead className="text-right">Denda</TableHead>
                      <TableHead>Tgl Lunas</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedMonthPenaltyDetails.sort((a, b) => new Date(b.paid_at).getTime() - new Date(a.paid_at).getTime()).map((detail, index) => <TableRow key={index}>
                          <TableCell className="font-medium">{detail.application_number}</TableCell>
                          <TableCell>{detail.customer_name}</TableCell>
                          <TableCell className="text-muted-foreground font-bold">{detail.customer_id_number}</TableCell>
                          <TableCell className="text-center">{detail.installment_number}</TableCell>
                          <TableCell className="text-right font-medium">{formatRupiah(detail.total_payment)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(detail.paid_amount)}</TableCell>
                          <TableCell className="text-right font-bold text-warning">{formatRupiah(detail.penalty_amount)}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">{formatDate(detail.paid_at)}</TableCell>
                        </TableRow>)}
                  </TableBody>
                </Table>
              </ScrollArea>}
            
            <div className="flex justify-between items-center p-3 bg-muted rounded-lg mt-4">
              <span className="font-semibold">Total {selectedMonthPenaltyDetails.length} Angsuran dengan Denda</span>
              <span className="font-bold text-lg text-warning">
                {formatRupiah(selectedMonthPenaltyDetails.reduce((sum, d) => sum + d.penalty_amount, 0))}
              </span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>;
}

// Helper component for detail rows
function DetailRow({
  label,
  value
}: {
  label: string;
  value: string;
}) {
  return <div className="flex justify-between gap-4">
      <span className="text-muted-foreground font-medium">{label}:</span>
      <span className="text-right flex-1 break-words font-semibold">{value}</span>
    </div>;
}