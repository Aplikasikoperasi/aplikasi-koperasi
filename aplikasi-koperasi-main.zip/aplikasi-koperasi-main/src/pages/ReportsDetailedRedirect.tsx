import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

export default function ReportsDetailedRedirect() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    // Preserve existing params but force tab=detailed
    params.set('tab', 'detailed');
    navigate({ pathname: '/reports', search: params.toString() ? `?${params.toString()}` : '?tab=detailed' }, { replace: true });
  }, [navigate, location.search]);

  return null;
}
