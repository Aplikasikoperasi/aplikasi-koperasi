import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useDebounce } from "@/hooks/use-debounce";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { useCustomersQuery, useCustomersWithoutAuthQuery, useInvalidateCustomers } from "@/hooks/useCustomersQuery";
import { useMembersQuery } from "@/hooks/useMembersQuery";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle, ResponsiveDialogTrigger } from "@/components/ui/responsive-dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useUserRole } from "@/hooks/useUserRole";
import { Plus, Pencil, Trash2, Upload, X, Search, ShieldAlert, Star, AlertCircle, Loader2, Users } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { SuccessCheckmark } from "@/components/ui/success-checkmark";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { Textarea } from "@/components/ui/textarea";
import { compressImage } from "@/lib/imageCompression";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { DatePicker } from "@/components/ui/date-picker";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn, calculateAge, getTodayInWIB } from "@/lib/utils";
import { format } from "date-fns";
import { sanitizeDateForDatabase } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "sonner";
import { MobileDataCard } from "@/components/MobileDataCard";
import { SkeletonCard } from "@/components/ui/skeleton-card";
import { SkeletonTable } from "@/components/ui/skeleton-table";
import { LazyCustomerDetailDialog as CustomerDetailDialog } from "@/components/LazyDialogs";
import { AchievementBadge } from "@/components/AchievementBadge";
import { useCustomerDataPrefetch } from "@/hooks/useCustomerDataPrefetch";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
export default function Customers() {
  const [open, setOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<any>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progressMessage, setProgressMessage] = useState<string>("");
  const [progressValue, setProgressValue] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [currentPage, setCurrentPage] = useState(1);
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [customerToBlock, setCustomerToBlock] = useState<any>(null);
  const [blockReason, setBlockReason] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [creatingBulkAuth, setCreatingBulkAuth] = useState(false);
  const [existingNoKKCustomers, setExistingNoKKCustomers] = useState<Array<{
    id: string;
    full_name: string;
    id_number: string;
  }>>([]);
  const [checkingNoKK, setCheckingNoKK] = useState(false);
  const {
    role,
    isOwner,
    isAdmin,
    isSales
  } = useUserRole();
  const canManage = isOwner || isAdmin;
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const ITEMS_PER_PAGE = 20;
  const { viewMode, toggleView } = useViewPreference('customers');
  
  // Pre-fetch customer data on hover
  const { prefetchCustomerData, getCachedData } = useCustomerDataPrefetch();

  // Use React Query hooks
  const { data: customersData, isLoading: loading, refetch } = useCustomersQuery({ 
    searchQuery: debouncedSearch, 
    page: currentPage, 
    itemsPerPage: ITEMS_PER_PAGE,
    isSalesUser: isSales
  });
  const customers = customersData?.customers || [];
  const totalCount = customersData?.totalCount || 0;
  const invalidateCustomers = useInvalidateCustomers();
  
  // Force refresh on mount to show latest data
  useEffect(() => {
    refetch();
  }, []);

  // Fetch count of customers without auth (for bulk creation)
  const { data: customersWithoutAuth = 0 } = useCustomersWithoutAuthQuery();

  // Fetch members list for dropdown
  const { data: membersData } = useMembersQuery({ searchQuery: "" });
  const members = useMemo(() => {
    const allMembers = membersData?.members || [];
    return allMembers.filter((m: any) => m.position !== "Owner");
  }, [membersData]);
  const [formData, setFormData] = useState({
    full_name: "",
    nik: "",
    no_kk: "",
    phone: "",
    address: "",
    occupation: "",
    created_by: ""
  });
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  const [dateOfBirth, setDateOfBirth] = useState<Date | undefined>();
  
  // Field validation errors state
  const [fieldErrors, setFieldErrors] = useState<{
    photo?: string;
    full_name?: string;
    nik?: string;
    no_kk?: string;
    dateOfBirth?: string;
    phone?: string;
    address?: string;
    occupation?: string;
  }>({});

  // Realtime validation functions
  const validatePhoto = (hasPhoto: boolean) => {
    if (!hasPhoto) {
      return "Foto wajib diupload";
    }
    return undefined;
  };

  const validateFullName = (value: string) => {
    if (!value.trim()) {
      return "Nama lengkap wajib diisi";
    }
    return undefined;
  };

  const validateNIK = (value: string) => {
    if (!value || value.trim() === '') {
      return "NIK wajib diisi";
    }
    const nikPattern = /^\d{15,18}$/;
    if (!nikPattern.test(value)) {
      return "NIK harus 15-18 digit angka";
    }
    return undefined;
  };

  const validateDateOfBirth = (value: Date | undefined) => {
    if (!value) {
      return "Tanggal lahir wajib diisi";
    }
    const today = new Date();
    const birthDate = new Date(value);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age < 18) {
      return "Usia minimal 18 tahun";
    }
    return undefined;
  };

  const validatePhone = (value: string) => {
    if (!value.trim()) {
      return "Telepon wajib diisi";
    }
    const phonePattern = /^(\+62|08)\d{8,}$/;
    if (!phonePattern.test(value.replace(/\s/g, ''))) {
      return "Harus dimulai 08 atau +62, min 10 digit";
    }
    return undefined;
  };

  const validateAddress = (value: string) => {
    if (!value.trim()) {
      return "Alamat wajib diisi";
    }
    return undefined;
  };

  const validateOccupation = (value: string) => {
    if (!value || value.trim() === '') {
      return "Pekerjaan wajib diisi";
    }
    return undefined;
  };

  const validateNoKK = (value: string, isEditing: boolean = false) => {
    // For new customers, No. KK is REQUIRED
    // For editing existing customers (legacy data), it remains optional
    if (!value || value.trim() === '') {
      if (isEditing) {
        return undefined; // Optional when editing (for legacy data)
      }
      return "No. KK wajib diisi untuk pendaftaran nasabah baru";
    }
    const noKKPattern = /^\d{16}$/;
    if (!noKKPattern.test(value)) {
      return "No. KK harus tepat 16 digit angka";
    }
    return undefined;
  };

  // Update field error on blur
  const handleFieldBlur = (field: string, value: any) => {
    let error: string | undefined;
    switch (field) {
      case 'full_name':
        error = validateFullName(value);
        break;
      case 'nik':
        error = validateNIK(value);
        break;
      case 'no_kk':
        error = validateNoKK(value, !!editingCustomer);
        break;
      case 'dateOfBirth':
        error = validateDateOfBirth(value);
        break;
      case 'phone':
        error = validatePhone(value);
        break;
      case 'address':
        error = validateAddress(value);
        break;
      case 'occupation':
        error = validateOccupation(value);
        break;
    }
    setFieldErrors(prev => ({ ...prev, [field]: error }));
  };

  // Clear error when user starts typing
  const clearFieldError = (field: string) => {
    if (fieldErrors[field as keyof typeof fieldErrors]) {
      setFieldErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  // Check for existing customers with the same No. KK
  const checkExistingNoKK = async (noKK: string) => {
    if (!noKK || noKK.length < 16) {
      setExistingNoKKCustomers([]);
      return;
    }
    
    setCheckingNoKK(true);
    try {
      let query = supabase
        .from("customers")
        .select("id, full_name, id_number")
        .eq("no_kk", noKK)
        .eq("status", "approved")
        .limit(10);
      
      // Exclude current customer when editing
      if (editingCustomer?.id) {
        query = query.neq("id", editingCustomer.id);
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error("Error checking No. KK:", error);
        return;
      }
      
      setExistingNoKKCustomers(data || []);
    } catch (error) {
      console.error("Error checking No. KK:", error);
    } finally {
      setCheckingNoKK(false);
    }
  };

  const [registrationDate, setRegistrationDate] = useState<Date | undefined>();
  useEffect(() => {
    loadCurrentMember();

    // Set up realtime subscriptions for auto-sync
    const channel = supabase.channel('customers-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, () => {
      console.log('🔄 Customer data changed (including credit score), reloading...');
      invalidateCustomers();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'blocked_customers'
    }, () => {
      console.log('🔄 Blocked customer data changed, reloading...');
      invalidateCustomers();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'members'
    }, () => {
      console.log('🔄 Member data changed, reloading...');
      invalidateCustomers();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'installments'
    }, () => {
      console.log('🔄 Installment data changed, refreshing customer credit scores...');
      invalidateCustomers();
    }).on('postgres_changes', {
      event: 'INSERT',
      schema: 'public',
      table: 'payments'
    }, () => {
      console.log('🔄 Payment recorded, refreshing customer credit scores...');
      invalidateCustomers();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [invalidateCustomers]);

  // Listen for pull-to-refresh
  useEffect(() => {
    const handleRefresh = () => invalidateCustomers();
    window.addEventListener('page-refresh', handleRefresh);
    return () => window.removeEventListener('page-refresh', handleRefresh);
  }, [invalidateCustomers]);

  // Handle edit from navigation state (from Verifications page)
  useEffect(() => {
    const editCustomerData = sessionStorage.getItem('editCustomer');
    if (editCustomerData) {
      try {
        const customer = JSON.parse(editCustomerData);
        sessionStorage.removeItem('editCustomer');
        // Wait a bit for component to be fully mounted
        setTimeout(() => openEditDialog(customer), 100);
      } catch (error) {
        console.error('Error parsing edit customer data:', error);
      }
    }
  }, []);
  // Reset to page 1 when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch]);

  const loadCurrentMember = async () => {
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    if (user) {
      const {
        data: memberData
      } = await supabase.from("members").select("id").eq("user_id", user.id).single();
      if (memberData) {
        setCurrentMemberId(memberData.id);
        setFormData(prev => ({
          ...prev,
          created_by: memberData.id
        }));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (uploading) {
      console.log('Already uploading, skipping duplicate submission');
      return;
    }
    setUploading(true);
    setProgressMessage("Memvalidasi data...");
    setProgressValue(10);
    try {
      // Validate all fields and collect errors
      const errors: typeof fieldErrors = {};
      
      if (!photoFile && !editingCustomer?.photo_url) {
        errors.photo = "Foto wajib diupload";
      }
      if (!formData.full_name.trim()) {
        errors.full_name = "Nama lengkap wajib diisi";
      }
      
      // Validate NIK
      if (!formData.nik || formData.nik.trim() === '') {
        errors.nik = "NIK wajib diisi";
      } else {
        const nikPattern = /^\d{15,18}$/;
        if (!nikPattern.test(formData.nik)) {
          errors.nik = "NIK harus 15-18 digit angka";
        }
      }
      
      // Validate date of birth
      if (!dateOfBirth) {
        errors.dateOfBirth = "Tanggal lahir wajib diisi";
      } else {
        const today = new Date();
        const birthDate = new Date(dateOfBirth);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }
        if (age < 18) {
          errors.dateOfBirth = "Usia minimal 18 tahun";
        }
      }
      
      // Validate phone
      if (!formData.phone.trim()) {
        errors.phone = "Telepon wajib diisi";
      } else {
        const phonePattern = /^(\+62|08)\d{8,}$/;
        if (!phonePattern.test(formData.phone.replace(/\s/g, ''))) {
          errors.phone = "Harus dimulai 08 atau +62, min 10 digit";
        }
      }
      
      if (!formData.address.trim()) {
        errors.address = "Alamat wajib diisi";
      }
      if (!formData.occupation || formData.occupation.trim() === '') {
        errors.occupation = "Pekerjaan wajib diisi";
      }
      
      // Validate No. KK - REQUIRED for new customers, optional for editing (legacy data)
      if (!editingCustomer) {
        // New customer - No. KK is mandatory
        if (!formData.no_kk || formData.no_kk.trim() === '') {
          errors.no_kk = "No. KK wajib diisi untuk pendaftaran nasabah baru";
        } else {
          const noKKPattern = /^\d{16}$/;
          if (!noKKPattern.test(formData.no_kk)) {
            errors.no_kk = "No. KK harus tepat 16 digit angka";
          }
        }
      } else {
        // Editing existing customer - No. KK is optional (for legacy data)
        if (formData.no_kk && formData.no_kk.trim() !== '') {
          const noKKPattern = /^\d{16}$/;
          if (!noKKPattern.test(formData.no_kk)) {
            errors.no_kk = "No. KK harus tepat 16 digit angka";
          }
        }
      }
      
      // Set all errors at once
      setFieldErrors(errors);
      
      // If there are any errors, show toast and stop
      if (Object.keys(errors).length > 0) {
        const errorFields = [];
        if (errors.photo) errorFields.push("Foto");
        if (errors.full_name) errorFields.push("Nama Lengkap");
        if (errors.nik) errorFields.push("NIK");
        if (errors.no_kk) errorFields.push("No. KK");
        if (errors.dateOfBirth) errorFields.push("Tanggal Lahir");
        if (errors.phone) errorFields.push("Telepon");
        if (errors.address) errorFields.push("Alamat");
        if (errors.occupation) errorFields.push("Pekerjaan");
        
        toast.error(`Data Tidak Valid: Periksa kembali ${errorFields.join(", ")}`);
        setUploading(false);
        setProgressMessage("");
        setProgressValue(0);
        return;
      }

      // Check for duplicate NIK in customers table (excluding current customer when editing)
      if (formData.nik) {
        let nikQuery = supabase.from("customers").select("id, full_name").eq("nik", formData.nik);

        // If editing, exclude the current customer
        if (editingCustomer) {
          nikQuery = nikQuery.neq("id", editingCustomer.id);
        }
        const {
          data: existingCustomer,
          error: customerCheckError
        } = await nikQuery.limit(1).maybeSingle();
        if (customerCheckError && customerCheckError.code !== "PGRST116") {
          throw customerCheckError;
        }
        if (existingCustomer) {
          toast.error(`NIK Sudah Terdaftar: NIK ini sudah digunakan oleh nasabah: ${existingCustomer.full_name}`);
          setUploading(false);
          setProgressMessage("");
          setProgressValue(0);
          return;
        }

        // Check if NIK exists in blocked customers
        const {
          data: blockedCustomers,
          error: blockedCheckError
        } = await supabase.from("blocked_customers").select("customer_id");
        if (blockedCheckError) throw blockedCheckError;
        if (blockedCustomers && blockedCustomers.length > 0) {
          const blockedCustomerIds = blockedCustomers.map(bc => bc.customer_id);
          const {
            data: blockedCustomerData
          } = await supabase.from("customers").select("nik, full_name").in("id", blockedCustomerIds).eq("nik", formData.nik).single();
          if (blockedCustomerData) {
            toast.error(`NIK Diblokir: NIK ini sudah diblokir atas nama: ${blockedCustomerData.full_name}. Hubungi owner untuk pemulihan data`);
            setUploading(false);
            setProgressMessage("");
            setProgressValue(0);
            return;
          }
        }
      }
      let photoUrl = editingCustomer?.photo_url || null;

      // Handle photo upload if there's a new photo
      if (photoFile) {
        try {
          // Show compression progress - inline in form
          setProgressMessage("Mengompresi foto...");
          setProgressValue(20);
          
          // Compress the image using our custom function
          const compressedFile = await compressImage(photoFile, 0.5, 800);
          
          setProgressMessage("Mengunggah foto...");
          setProgressValue(40);

          // Upload to Supabase Storage - always use .jpg extension now
          const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.jpg`;
          const filePath = `${fileName}`;
          const {
            error: uploadError
          } = await supabase.storage.from('customer-photos').upload(filePath, compressedFile, {
            cacheControl: '3600',
            upsert: false,
            contentType: 'image/jpeg'
          });
          
          if (uploadError) {
            throw new Error(`Gagal upload foto: ${uploadError.message}`);
          }

          // Get public URL
          const {
            data: {
              publicUrl
            }
          } = supabase.storage.from('customer-photos').getPublicUrl(filePath);
          photoUrl = publicUrl;
          setProgressValue(60);
        } catch (photoError: any) {
          console.error('Photo upload error:', photoError);
          toast.error(photoError.message || "Gagal mengunggah foto. Silakan coba lagi.");
          setUploading(false);
          setProgressMessage("");
          setProgressValue(0);
          return;
        }
      }
      setProgressMessage("Menyimpan data nasabah...");
      setProgressValue(80);
      if (editingCustomer) {
        const dataToSave: any = {
          full_name: formData.full_name,
          nik: formData.nik,
          no_kk: formData.no_kk || null,
          date_of_birth: sanitizeDateForDatabase(dateOfBirth),
          phone: formData.phone,
          address: formData.address,
          occupation: formData.occupation,
          photo_url: photoUrl,
          created_by: formData.created_by || null
        };

        // Validate date_of_birth if provided
        if (dateOfBirth && !dataToSave.date_of_birth) {
          toast.error("Format tanggal lahir tidak valid (tahun harus antara 1900-2100)");
          setUploading(false);
          setProgressMessage("");
          setProgressValue(0);
          return;
        }
        // Only update created_at when user explicitly changes it
        const originalReg = editingCustomer?.created_at ? new Date(editingCustomer.created_at) : null;
        if (registrationDate && (!originalReg || registrationDate.getTime() !== originalReg.getTime())) {
          dataToSave.created_at = registrationDate.toISOString();
        }
        console.log('Updating customer with data:', dataToSave);
        const {
          data,
          error,
          count
        } = await supabase.from("customers").update(dataToSave).eq("id", editingCustomer.id).select();
        if (error) {
          console.error('Update error:', error);
          throw error;
        }

        // Check if any row was actually updated
        if (!data || data.length === 0) {
          throw new Error("Data tidak dapat diperbarui. Pastikan Anda memiliki izin untuk mengedit data ini.");
        }
        console.log('Update successful:', data);
        await logSystemEvent({
          category: "customer_management",
          action: "Update Nasabah",
          description: `Memperbarui data nasabah: ${formData.full_name}`,
          metadata: {
            customer_id: editingCustomer.id,
            customer_name: formData.full_name,
            nik: formData.nik
          }
        });
        
        // Show success animation
        setProgressMessage("");
        setProgressValue(100);
        setShowSuccess(true);
        
        toast.success("Data nasabah berhasil diperbarui");
        
        // Delay closing to show success animation
        setTimeout(() => {
          setOpen(false);
          resetForm();
          setShowSuccess(false);
          // Force immediate reload across all pages
          invalidateCustomers();
          window.dispatchEvent(new Event('customer-updated'));
        }, 1500);
      } else {
        const {
          data: allCustomers,
          error: fetchError
        } = await supabase.from("customers").select("id_number");
        if (fetchError) throw fetchError;
        let maxNum = 0;
        for (const c of allCustomers || []) {
          const numStr = c.id_number as string;
          // Extract numeric part after 'N' prefix
          const n = parseInt(numStr?.replace(/^N/, '') || '0', 10);
          if (!isNaN(n) && n > maxNum) maxNum = n;
        }
        const nextIdNumber = 'N' + (maxNum + 1).toString().padStart(5, "0");

        // Status akan ditentukan oleh trigger auto_approve_customer_by_role()
        // Owner/Admin: otomatis approved
        // Sales: pending (perlu verifikasi)
        const dataToSave = {
          id_number: nextIdNumber,
          full_name: formData.full_name,
          nik: formData.nik,
          no_kk: formData.no_kk || null,
          date_of_birth: sanitizeDateForDatabase(dateOfBirth),
          phone: formData.phone,
          address: formData.address,
          occupation: formData.occupation,
          photo_url: photoUrl,
          created_by: currentMemberId || null,
          created_at: registrationDate ? registrationDate.toISOString() : new Date().toISOString(),
          status: 'pending' // Default pending, akan diubah oleh trigger jika owner/admin
        };

        // Validate date_of_birth if provided
        if (dateOfBirth && !dataToSave.date_of_birth) {
          toast.error("Format tanggal lahir tidak valid (tahun harus antara 1900-2100)");
          setUploading(false);
          setProgressMessage("");
          setProgressValue(0);
          return;
        }
        console.log('Inserting new customer with data:', dataToSave);
        console.log('Current member ID:', currentMemberId);
        const {
          data: insertedCustomer,
          error
        } = await supabase.from("customers").insert([dataToSave]).select().single();
        if (error) {
          console.error('Insert error details:', error);
          throw error;
        }

        // Create auth account asynchronously via edge function (non-blocking)
        // Only for approved customers (owner/admin) with required data
        if ((isOwner || isAdmin) && insertedCustomer && formData.nik && dateOfBirth) {
          setProgressMessage("Membuat akun login...");
          setProgressValue(90);
          
          try {
            const { data: authResult, error: authError } = await supabase.functions.invoke('create-customer-auth', {
              body: {
                customerId: insertedCustomer.id,
                idNumber: formData.nik,
                dateOfBirth: dateOfBirth.toISOString(),
                fullName: formData.full_name
              }
            });
            
            if (authError) {
              console.error('Auth creation error:', authError);
              // Non-blocking - just log the error, customer is already saved
              toast.warning("Nasabah tersimpan, namun akun login gagal dibuat. Silakan coba buat akun manual.");
            } else {
              console.log('Auth created successfully:', authResult);
            }
          } catch (authErr) {
            console.error('Auth creation exception:', authErr);
            // Non-blocking - customer is already saved
          }
        }

        // Show success animation
        setProgressMessage("");
        setProgressValue(100);
        setShowSuccess(true);
        
        // Toast message akan disesuaikan dengan role
        if (isOwner || isAdmin) {
          toast.success("Nasabah berhasil ditambahkan dan akun login dibuat");
        } else {
          toast.success("Nasabah berhasil ditambahkan dan menunggu persetujuan owner/admin");
        }
        await logSystemEvent({
          category: "customer_management",
          action: "Tambah Nasabah",
          description: `Menambahkan nasabah baru: ${formData.full_name}`,
          metadata: {
            customer_name: formData.full_name,
            id_number: nextIdNumber,
            nik: formData.nik
          }
        });
        
        // Delay closing to show success animation
        setTimeout(() => {
          setOpen(false);
          resetForm();
          setShowSuccess(false);
          // Force immediate reload
          invalidateCustomers();
          window.dispatchEvent(new Event('customer-created'));
        }, 1500);
      }
    } catch (error: any) {
      toast.error(`Gagal menyimpan data nasabah: ${error.message}`);
    } finally {
      setUploading(false);
      setProgressMessage("");
      setProgressValue(0);
    }
  };
  const handleDelete = async (id: string) => {
    if (!confirm("Apakah Anda yakin ingin menghapus nasabah ini?")) return;
    const customerToDelete = customers.find(c => c.id === id);
    const {
      error
    } = await supabase.from("customers").delete().eq("id", id);
    if (error) {
      toast.error("Gagal menghapus nasabah");
    } else {
      await logSystemEvent({
        category: "customer_management",
        action: "Hapus Nasabah",
        description: `Menghapus nasabah: ${customerToDelete?.full_name}`,
        metadata: {
          customer_id: id,
          customer_name: customerToDelete?.full_name,
          id_number: customerToDelete?.id_number
        }
      });
      toast.success("Nasabah berhasil dihapus");
      // Force immediate reload
      invalidateCustomers();
    }
  };
  const resetForm = () => {
    setFormData({
      full_name: "",
      nik: "",
      no_kk: "",
      phone: "",
      address: "",
      occupation: "",
      created_by: currentMemberId || ""
    });
    setDateOfBirth(undefined);
    setRegistrationDate(undefined);
    setPhotoFile(null);
    setPhotoPreview(null);
    setEditingCustomer(null);
    setProgressMessage("");
    setProgressValue(0);
    setFieldErrors({}); // Reset validation errors
    setExistingNoKKCustomers([]); // Reset No. KK warning
  };
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
  };
  const openEditDialog = (customer: any) => {
    setEditingCustomer(customer);
    setFormData({
      full_name: customer.full_name || "",
      nik: customer.nik || "",
      no_kk: customer.no_kk || "",
      phone: customer.phone || "",
      address: customer.address || "",
      occupation: customer.occupation || "",
      created_by: customer.created_by || ""
    });
    setDateOfBirth(customer.date_of_birth ? new Date(customer.date_of_birth) : undefined);
    setRegistrationDate(customer.created_at ? new Date(customer.created_at) : undefined);
    setPhotoPreview(customer.photo_url || null);
    setOpen(true);
  };
  const openBlockDialog = (customer: any) => {
    if (!isOwner && !isAdmin && !isSales) {
      toast.error("Anda tidak memiliki izin untuk memblokir nasabah");
      return;
    }
    setCustomerToBlock(customer);
    setBlockReason("");
    setBlockDialogOpen(true);
  };
  const handleBlockCustomer = async () => {
    if (!blockReason.trim()) {
      toast.error("Alasan pemblokiran harus diisi");
      return;
    }
    try {
      // Gunakan RPC aman untuk memblokir nasabah (menangani duplikasi & blokir permanen)
      const {
        data,
        error
      } = await supabase.rpc('block_customer', {
        p_customer_id: customerToBlock.id,
        p_reason: blockReason
      });
      if (error) throw error;
      const result = data as {
        success: boolean;
        message: string;
      } | null;
      if (!result?.success) {
        throw new Error(result?.message || 'Gagal memblokir nasabah');
      }
      await logSystemEvent({
        category: "blocking",
        action: "Blokir Nasabah",
        description: `Memblokir nasabah: ${customerToBlock.full_name}`,
        metadata: {
          customer_id: customerToBlock.id,
          customer_name: customerToBlock.full_name,
          id_number: customerToBlock.id_number,
          reason: blockReason
        }
      });
      toast.success(result.message || 'Nasabah berhasil diblokir dengan skor kredit 1');
      setBlockDialogOpen(false);
      setCustomerToBlock(null);
      setBlockReason('');
      // Force immediate reload
      invalidateCustomers();
      window.dispatchEvent(new Event('customer-blocked'));
    } catch (error: any) {
      toast.error(`Gagal memblokir nasabah: ${error.message}`);
    }
  };
  const handleApplyCredit = (customer: any) => {
    // Store customer data in sessionStorage to pre-fill the application form
    sessionStorage.setItem('preselectedCustomer', JSON.stringify({
      id: customer.id,
      full_name: customer.full_name,
      nik: customer.nik,
      credit_score: customer.credit_score
    }));

    // Navigate to applications page
    navigate('/applications', {
      state: {
        customerId: customer.id
      }
    });
  };
  const handleBulkCreateAuth = async () => {
    if (customersWithoutAuth === 0) {
      toast.error("Semua nasabah sudah memiliki akun login");
      return;
    }
    setCreatingBulkAuth(true);
    try {
      const {
        data,
        error
      } = await supabase.functions.invoke('create-bulk-customer-auth', {
        body: {}
      });
      if (error) throw error;
      if (data.success) {
        toast.success(`Akun Login Berhasil Dibuat: Berhasil membuat ${data.created} akun login${data.failed > 0 ? `, ${data.failed} gagal` : ''}`);

        // Log the event
        await logSystemEvent({
          category: "customer_management",
          action: "Buat Akun Login Massal",
          description: `Membuat ${data.created} akun login nasabah`,
          metadata: {
            created: data.created,
            failed: data.failed,
            errors: data.errors
          }
        });

        // Reload customers to update UI
        invalidateCustomers();
      } else {
        throw new Error(data.error || 'Gagal membuat akun');
      }
    } catch (error: any) {
      console.error('Error creating bulk auth accounts:', error);
      toast.error(`Gagal Membuat Akun Login: ${error.message || "Terjadi kesalahan saat membuat akun login massal"}`);
    } finally {
      setCreatingBulkAuth(false);
    }
  };

  // Server-side pagination - no need for client-side filtering
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Reset to page 1 when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch]);

  // Helper untuk membatasi nomor halaman yang ditampilkan
  const getPaginationRange = () => {
    const delta = isMobile ? 1 : 2;
    const range: (number | string)[] = [];
    const rangeWithDots: (number | string)[] = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }
    if (currentPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }
    rangeWithDots.push(...range);
    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push('...', totalPages);
    } else if (totalPages > 1) {
      rangeWithDots.push(totalPages);
    }
    return rangeWithDots;
  };
  return <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row justify-end items-start sm:items-center gap-3 mb-3">
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          {canManage && customersWithoutAuth > 0 && <Button className="min-h-[44px] w-full sm:w-auto flex-shrink-0" variant="secondary" onClick={handleBulkCreateAuth} disabled={creatingBulkAuth}>
              <Plus className="h-4 w-4 mr-2" />
              {creatingBulkAuth ? "Membuat..." : `Buat ${customersWithoutAuth} Akun Login`}
            </Button>}
          <ResponsiveDialog open={open} onOpenChange={o => {
          setOpen(o);
          if (!o) resetForm();
        }}>
            <ResponsiveDialogTrigger asChild>
              <Button className="min-h-[44px] w-full sm:w-auto flex-shrink-0">
                <Plus className="h-4 w-4 mr-2" />
                Tambah Nasabah
              </Button>
            </ResponsiveDialogTrigger>
          <ResponsiveDialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <ResponsiveDialogHeader>
              <ResponsiveDialogTitle>{editingCustomer ? "Edit" : "Tambah"} Nasabah</ResponsiveDialogTitle>
            </ResponsiveDialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Photo Upload - Horizontal Layout */}
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-4">
                  <div className="relative flex-shrink-0">
                    <Avatar className={`h-16 w-16 border-2 ${fieldErrors.photo ? 'border-destructive' : 'border-dashed border-muted-foreground/50'}`}>
                      <AvatarImage src={photoPreview || undefined} />
                      <AvatarFallback className="bg-muted text-muted-foreground text-lg">
                        {formData.full_name?.substring(0, 2).toUpperCase() || "?"}
                      </AvatarFallback>
                    </Avatar>
                    {photoPreview && (
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-1 -right-1 h-5 w-5 rounded-full"
                        onClick={removePhoto}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium">Foto Nasabah *</span>
                    <Input type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" id="photo-upload" />
                    <Label htmlFor="photo-upload" className="cursor-pointer">
                      <Button type="button" variant="outline" size="sm" asChild>
                        <span>
                          <Upload className="h-4 w-4 mr-2" />
                          {photoPreview ? "Ganti" : "Upload"}
                        </span>
                      </Button>
                    </Label>
                  </div>
                </div>
                {fieldErrors.photo && (
                  <p className="text-sm text-destructive text-center flex items-center justify-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {fieldErrors.photo}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="full_name">Nama Lengkap *</Label>
                <Input 
                  id="full_name" 
                  value={formData.full_name} 
                  onChange={e => {
                    setFormData({ ...formData, full_name: e.target.value.toUpperCase() });
                    clearFieldError('full_name');
                  }}
                  onBlur={() => handleFieldBlur('full_name', formData.full_name)}
                  className={fieldErrors.full_name ? 'border-destructive focus-visible:ring-destructive' : ''}
                  required 
                />
                {fieldErrors.full_name && (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.full_name}</p>
                )}
              </div>
              <div>
                <Label htmlFor="nik">NIK *</Label>
                <Input 
                  id="nik" 
                  value={formData.nik} 
                  onChange={e => {
                    const value = e.target.value;
                    // Only allow numeric input
                    if (value === '' || /^\d+$/.test(value)) {
                      setFormData({ ...formData, nik: value });
                      clearFieldError('nik');
                    }
                  }}
                  onBlur={() => handleFieldBlur('nik', formData.nik)}
                  className={fieldErrors.nik ? 'border-destructive focus-visible:ring-destructive' : ''}
                  placeholder="15-18 digit angka" 
                  maxLength={18} 
                  required 
                />
                {fieldErrors.nik ? (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.nik}</p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">
                    NIK harus berupa angka saja dengan panjang 15-18 digit
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="no_kk">
                  No. Kartu Keluarga (KK) {!editingCustomer && <span className="text-destructive">*</span>}
                </Label>
                <Input 
                  id="no_kk" 
                  value={formData.no_kk} 
                  onChange={e => {
                    const value = e.target.value;
                    // Only allow numeric input
                    if (value === '' || /^\d+$/.test(value)) {
                      setFormData({ ...formData, no_kk: value });
                      clearFieldError('no_kk');
                      // Clear existing customers warning when input changes
                      if (value.length < 16) {
                        setExistingNoKKCustomers([]);
                      }
                    }
                  }}
                  onBlur={() => {
                    handleFieldBlur('no_kk', formData.no_kk);
                    // Check for existing customers with same No. KK
                    if (formData.no_kk.length === 16) {
                      checkExistingNoKK(formData.no_kk);
                    }
                  }}
                  className={fieldErrors.no_kk ? 'border-destructive focus-visible:ring-destructive' : existingNoKKCustomers.length > 0 ? 'border-amber-500 focus-visible:ring-amber-500' : ''}
                  placeholder={editingCustomer ? "16 digit angka (opsional)" : "16 digit angka (wajib)"}
                  maxLength={16} 
                  required={!editingCustomer}
                />
                {fieldErrors.no_kk ? (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.no_kk}</p>
                ) : existingNoKKCustomers.length > 0 ? (
                  <div className="mt-2 p-2 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg">
                    <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-300 mb-1.5">
                      <Users className="h-3.5 w-3.5" />
                      <p className="text-xs font-semibold">No. KK sudah terdaftar</p>
                    </div>
                    <p className="text-[11px] text-amber-600 dark:text-amber-400 mb-1.5">
                      Nasabah berikut memiliki No. KK yang sama:
                    </p>
                    <div className="space-y-1 max-h-20 overflow-y-auto">
                      {existingNoKKCustomers.map(c => (
                        <div key={c.id} className="text-[11px] flex justify-between items-center bg-white dark:bg-amber-900/20 px-2 py-1 rounded">
                          <span className="font-medium truncate">{c.full_name}</span>
                          <span className="text-muted-foreground ml-2">{c.id_number}</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] text-amber-600 dark:text-amber-400 mt-1.5 italic">
                      Jika ini anggota keluarga, Anda dapat melanjutkan pendaftaran.
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">
                    {editingCustomer 
                      ? "Digunakan untuk validasi kredit keluarga (16 digit, opsional untuk data lama)"
                      : "Wajib diisi untuk validasi kredit keluarga (harus 16 digit)"
                    }
                  </p>
                )}
              </div>
              <div>
                <Label>Tanggal Lahir *</Label>
                <DatePicker 
                  value={dateOfBirth} 
                  onChange={(date) => {
                    setDateOfBirth(date);
                    clearFieldError('dateOfBirth');
                    // Validate immediately when date is selected
                    setTimeout(() => handleFieldBlur('dateOfBirth', date), 100);
                  }} 
                  placeholder="dd/MM/yyyy" 
                  maxDate={getTodayInWIB()} 
                  minDate={new Date("1900-01-01")} 
                />
                {fieldErrors.dateOfBirth ? (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.dateOfBirth}</p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">
                    Nasabah harus berusia minimal 18 tahun
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="phone">Telepon *</Label>
                <Input 
                  id="phone" 
                  value={formData.phone} 
                  onChange={e => {
                    // Auto-format: remove spaces, hyphens, and non-numeric characters (except + at start)
                    let value = e.target.value;
                    const hasPlus = value.startsWith('+');
                    value = value.replace(/[^\d+]/g, ''); // Remove all except digits and +
                    if (hasPlus && !value.startsWith('+')) {
                      value = '+' + value.replace(/\+/g, '');
                    } else {
                      value = value.replace(/\+/g, '');
                    }
                    setFormData({ ...formData, phone: value });
                    clearFieldError('phone');
                  }}
                  onBlur={() => handleFieldBlur('phone', formData.phone)}
                  className={fieldErrors.phone ? 'border-destructive focus-visible:ring-destructive' : ''}
                  placeholder="08xxx atau +62xxx" 
                  required 
                />
                {fieldErrors.phone ? (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.phone}</p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">
                    Harus dimulai dengan 08 atau +62 dan minimal 10 digit
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="address">Alamat *</Label>
                <Textarea 
                  id="address" 
                  value={formData.address} 
                  onChange={e => {
                    setFormData({ ...formData, address: e.target.value });
                    clearFieldError('address');
                  }}
                  onBlur={() => handleFieldBlur('address', formData.address)}
                  className={fieldErrors.address ? 'border-destructive focus-visible:ring-destructive' : ''}
                  required 
                />
                {fieldErrors.address && (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.address}</p>
                )}
              </div>
              <div>
                <Label htmlFor="occupation">Pekerjaan *</Label>
                <Input 
                  id="occupation" 
                  value={formData.occupation} 
                  onChange={e => {
                    setFormData({ ...formData, occupation: e.target.value });
                    clearFieldError('occupation');
                  }}
                  onBlur={() => handleFieldBlur('occupation', formData.occupation)}
                  className={fieldErrors.occupation ? 'border-destructive focus-visible:ring-destructive' : ''}
                  placeholder="Masukkan pekerjaan" 
                  required 
                />
                {fieldErrors.occupation && (
                  <p className="text-xs text-destructive mt-1 font-medium">{fieldErrors.occupation}</p>
                )}
              </div>
              
              {editingCustomer && <div>
                  <Label>Tanggal Pendaftaran (Opsional untuk Nasabah Lama)</Label>
                  <DatePicker value={registrationDate} onChange={setRegistrationDate} placeholder="dd/MM/yyyy" maxDate={getTodayInWIB()} />
                  <p className="text-xs text-muted-foreground mt-1">
                    Edit tanggal ini untuk mendaftarkan nasabah sebagai nasabah lama/legacy
                  </p>
                </div>}
              
              {/* Inline Progress Indicator */}
              {uploading && progressMessage && !showSuccess && (
                <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span className="text-sm font-medium">{progressMessage}</span>
                  </div>
                  <Progress value={progressValue} className="h-2" />
                  <p className="text-xs text-muted-foreground text-center">
                    Mohon tunggu, jangan tutup form ini...
                  </p>
                </div>
              )}
              
              {/* Success Animation */}
              <SuccessCheckmark 
                show={showSuccess} 
                message={editingCustomer ? "Data nasabah berhasil diperbarui!" : "Nasabah berhasil ditambahkan!"}
              />
              
              <Button type="submit" className="w-full" disabled={uploading}>
                {uploading ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Memproses...
                  </span>
                ) : editingCustomer ? "Perbarui" : "Tambah"} Nasabah
              </Button>
            </form>
          </ResponsiveDialogContent>
        </ResponsiveDialog>
        </div>
      </div>

      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <CardTitle className="truncate">Semua Nasabah Aktif</CardTitle>
              <ViewToggle viewMode={viewMode} onToggle={toggleView} />
            </div>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto sm:ml-auto">
              <div className="relative w-full sm:w-64 md:w-72">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Cari ID atau Nama..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-9 min-h-[44px] w-full" />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          {loading ? isMobile ? <div className="space-y-3">
                {Array.from({
            length: 5
          }).map((_, i) => <SkeletonCard key={i} rows={4} />)}
              </div> : <SkeletonTable rows={10} columns={9} /> : <AnimatedViewTransition viewMode={viewMode}>
            {(isMobile || viewMode === 'card') ? (/* Mobile View - Cards */
        <div className="w-full max-w-full space-y-3">
                {customers.length === 0 && searchQuery ? <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
                  <Search className="h-8 w-8" />
                  <p className="font-medium text-sm sm:text-base">Data tidak ditemukan</p>
                  <p className="text-xs sm:text-sm text-center px-4">Tidak ada customer dengan ID atau nama "{searchQuery}"</p>
                </div> : customers.map(customer => (
                  <div key={customer.id} onMouseEnter={() => prefetchCustomerData(customer.id)}>
                    <MobileDataCard 
                      id={customer.id_number} 
                      photoUrl={customer.photo_url} 
                      name={customer.full_name} 
                      subtitle={customer.occupation || customer.phone} 
                      creditScore={customer.credit_score} 
                      restorationStatus={(customer.restoration_status || "never_restored") as "never_restored" | "restored_once" | "permanently_blocked"}
                      registrationDate={customer.effective_registration_date || customer.created_at}
                      totalActiveLoanAmount={customer.total_active_loan_amount}
                      totalCompletedLoanAmount={customer.total_completed_loan_amount}
                      statusIndicator={customer.hasIncompleteData ? (
                        <Badge variant="destructive" className="gap-1">
                          <AlertCircle className="h-3 w-3" />
                          Data Tidak Lengkap
                        </Badge>
                      ) : undefined}
                      achievementBadge={customer.achievementBadge}
                      onClick={() => {
                        setSelectedCustomer(customer);
                        setShowDetail(true);
                      }} 
                    />
                  </div>
                ))}
            </div>) : (/* Desktop View - Table */
        <div className="w-full">
              <ScrollArea className="h-[calc(100vh-320px)] w-full">
                <div className="overflow-x-auto min-w-full">
                  <Table className="min-w-max">
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead>No. ID</TableHead>
                <TableHead>Foto</TableHead>
                <TableHead>Nama</TableHead>
                <TableHead>NIK</TableHead>
                <TableHead>Tanggal Lahir</TableHead>
                <TableHead>Pekerjaan</TableHead>
                <TableHead>Telepon</TableHead>
                <TableHead>Alamat</TableHead>
                <TableHead>Didaftarkan oleh</TableHead>
                <TableHead>Skor Kredit</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
                {customers.length === 0 && searchQuery ? <TableRow>
                  <TableCell colSpan={12} className="text-center py-8">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Search className="h-8 w-8" />
                      <p className="font-medium">Data tidak ditemukan</p>
                      <p className="text-sm">Tidak ada customer dengan ID atau nama "{searchQuery}"</p>
                    </div>
                  </TableCell>
                </TableRow> : customers.map(customer => <TableRow 
                  key={customer.id} 
                  className={cn(
                    searchQuery ? "bg-yellow-50 dark:bg-yellow-950/20" : "", 
                    customer.hasIncompleteData ? "bg-red-50 dark:bg-red-950/20" : "", 
                    "cursor-pointer hover:bg-muted/50 transition-colors"
                  )} 
                  onMouseEnter={() => prefetchCustomerData(customer.id)}
                  onClick={() => {
                    setSelectedCustomer(customer);
                    setShowDetail(true);
                  }}>
                    <TableCell>
                      {customer.hasIncompleteData && (
                        <div className="flex items-center justify-center">
                          <AlertCircle className="h-5 w-5 text-destructive" />
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="font-bold">{customer.id_number}</TableCell>
                    <TableCell>
                      <ClickableAvatar 
                        src={customer.photo_url}
                        alt={customer.full_name}
                        fallback={customer.full_name?.charAt(0)}
                        className="w-10 h-10"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>{customer.full_name}</span>
                        {customer.achievementBadge && customer.achievementBadge.badge_level !== 'none' && (
                          <AchievementBadge
                            badgeLevel={customer.achievementBadge.badge_level}
                            badgeName={customer.achievementBadge.badge_name}
                            badgeDescription={customer.achievementBadge.badge_description}
                            consecutivePayments={customer.achievementBadge.consecutive_on_time_payments}
                            onTimePercentage={customer.achievementBadge.on_time_percentage}
                            size="sm"
                            showDetails={true}
                          />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{customer.nik}</TableCell>
                    <TableCell>
                      {customer.date_of_birth ? new Date(customer.date_of_birth).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: 'long',
                        year: 'numeric'
                      }) : <span className="text-muted-foreground">-</span>}
                    </TableCell>
                    <TableCell>{customer.occupation || "-"}</TableCell>
                    <TableCell>{customer.phone}</TableCell>
                    <TableCell className="max-w-xs truncate">{customer.address}</TableCell>
                    <TableCell>
                      {customer.member ? <div className="text-sm">
                          <div className="font-medium">{customer.member.full_name}</div>
                          <div className="text-muted-foreground">{customer.member.position}</div>
                        </div> : <span className="text-muted-foreground">-</span>}
                    </TableCell>
                    <TableCell>
                      <CreditScoreStars creditScore={customer.credit_score ?? 5} restorationStatus={customer.restoration_status as "never_restored" | "restored_once" | "permanently_blocked" || "never_restored"} />
                    </TableCell>
                  </TableRow>)}
            </TableBody>
          </Table>
                </div>
              </ScrollArea>
            </div>)}
          </AnimatedViewTransition>}
        </CardContent>
      </Card>

      {/* Customer Detail Dialog for Mobile */}
      <CustomerDetailDialog 
        open={showDetail} 
        onOpenChange={setShowDetail} 
        customer={selectedCustomer} 
        prefetchedData={selectedCustomer ? getCachedData(selectedCustomer.id) : null}
        onEdit={openEditDialog} 
        onDelete={customer => handleDelete(customer.id)} 
        onBlock={openBlockDialog} 
        onApplyCredit={handleApplyCredit} 
      />

      {totalPages > 1 && <Card>
          <CardContent className="pt-6">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious onClick={() => currentPage > 1 && handlePageChange(currentPage - 1)} className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                </PaginationItem>
                {getPaginationRange().map((page, idx) => <PaginationItem key={idx}>
                    {page === '...' ? <span className="px-2">...</span> : <PaginationLink onClick={() => handlePageChange(page as number)} isActive={currentPage === page} className="cursor-pointer">
                        {page}
                      </PaginationLink>}
                  </PaginationItem>)}
                <PaginationItem>
                  <PaginationNext onClick={() => currentPage < totalPages && handlePageChange(currentPage + 1)} className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"} />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </CardContent>
        </Card>}

      <AlertDialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Blokir Nasabah</AlertDialogTitle>
            <AlertDialogDescription>
              Anda akan memblokir nasabah: <strong>{customerToBlock?.full_name}</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4">
            <Label htmlFor="block-reason">Alasan Pemblokiran *</Label>
            <Textarea id="block-reason" value={blockReason} onChange={e => setBlockReason(e.target.value)} placeholder="Tuliskan alasan pemblokiran nasabah ini..." className="mt-2" rows={4} />
            <p className="text-sm text-muted-foreground mt-2">
              Diblokir oleh: {role === 'owner' ? 'Owner' : role === 'admin' ? 'Admin' : 'Sales'}
            </p>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
            setBlockReason("");
            setCustomerToBlock(null);
          }}>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleBlockCustomer} disabled={!blockReason.trim()} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Blokir Nasabah
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>;
}