import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DollarSign, TrendingUp, CreditCard, Calendar, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCashierDashboard } from "@/hooks/useCashierDashboard";
import { SkeletonTable } from "@/components/ui/skeleton-table";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { useIsMobile } from "@/hooks/use-mobile";

type ChartPeriod = "7days" | "30days" | "year";

const TRANSACTIONS_PER_PAGE = 15;

export default function CashierDashboard() {
  const { data, isLoading } = useCashierDashboard();
  const [chartPeriod, setChartPeriod] = useState<ChartPeriod>("7days");
  const [transactionPage, setTransactionPage] = useState(1);
  const isMobile = useIsMobile();

  if (isLoading) {
    return (
      <div className="w-full p-4 space-y-6">
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-32 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
        <SkeletonTable rows={5} columns={6} />
      </div>
    );
  }

  if (!data) return null;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getPaymentMethodBadge = (method: string) => {
    const variants: Record<string, "default" | "secondary" | "outline"> = {
      cash: "default",
      transfer: "secondary",
      other: "outline",
    };
    return variants[method.toLowerCase()] || "outline";
  };

  const getChartData = () => {
    if (!data) return [];
    switch (chartPeriod) {
      case "7days":
        return data.chartData.last7Days;
      case "30days":
        return data.chartData.last30Days;
      case "year":
        return data.chartData.yearToDate;
      default:
        return data.chartData.last7Days;
    }
  };

  const getChartTitle = () => {
    switch (chartPeriod) {
      case "7days":
        return "7 Hari Terakhir";
      case "30days":
        return "30 Hari Terakhir";
      case "year":
        return "Tahun Berjalan";
      default:
        return "7 Hari Terakhir";
    }
  };

  const getChartSummary = () => {
    const chartData = getChartData();
    const total = chartData.reduce((sum, item) => sum + item.total, 0);
    const count = chartData.length;
    const average = count > 0 ? total / count : 0;
    const highest = Math.max(...chartData.map(item => item.total), 0);
    
    return { total, count, average, highest };
  };

  const getPaginatedTransactions = () => {
    if (!data) return [];
    const startIndex = (transactionPage - 1) * TRANSACTIONS_PER_PAGE;
    return data.recentTransactions.slice(startIndex, startIndex + TRANSACTIONS_PER_PAGE);
  };

  const totalTransactionPages = data ? Math.ceil(data.recentTransactions.length / TRANSACTIONS_PER_PAGE) : 0;

  return (
    <div className="w-full p-4 space-y-6">
      <header className="space-y-2">
        <h1 className="text-2xl font-semibold">Dashboard Kasir</h1>
        <p className="text-muted-foreground">
          {data.member.full_name} - Laporan Transaksi Pembayaran
        </p>
      </header>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hari Ini</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(data.stats.today.total)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {data.stats.today.count} transaksi
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Minggu Ini</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(data.stats.week.total)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {data.stats.week.count} transaksi
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bulan Ini</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(data.stats.month.total)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {data.stats.month.count} transaksi
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Semua</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(data.stats.allTime.total)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {data.stats.allTime.count} transaksi
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Chart with Period Filter */}
      <Card>
        <CardHeader className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Transaksi {getChartTitle()}</CardTitle>
              <CardDescription>Grafik pembayaran yang Anda input</CardDescription>
            </div>
            <Tabs value={chartPeriod} onValueChange={(v) => setChartPeriod(v as ChartPeriod)} className="w-full sm:w-auto">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="7days" className="text-xs sm:text-sm">7 Hari</TabsTrigger>
                <TabsTrigger value="30days" className="text-xs sm:text-sm">30 Hari</TabsTrigger>
                <TabsTrigger value="year" className="text-xs sm:text-sm">Tahun Ini</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          {isMobile ? (
            // Mobile View: Cards Summary
            <div className="grid grid-cols-2 gap-3">
              <Card className="border-border/50">
                <CardHeader className="p-3 pb-2">
                  <CardDescription className="text-xs">Total</CardDescription>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <div className="text-lg font-bold">{formatCurrency(getChartSummary().total)}</div>
                </CardContent>
              </Card>
              
              <Card className="border-border/50">
                <CardHeader className="p-3 pb-2">
                  <CardDescription className="text-xs">Rata-rata</CardDescription>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <div className="text-lg font-bold">{formatCurrency(getChartSummary().average)}</div>
                </CardContent>
              </Card>
              
              <Card className="border-border/50">
                <CardHeader className="p-3 pb-2">
                  <CardDescription className="text-xs">Tertinggi</CardDescription>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <div className="text-lg font-bold">{formatCurrency(getChartSummary().highest)}</div>
                </CardContent>
              </Card>
              
              <Card className="border-border/50">
                <CardHeader className="p-3 pb-2">
                  <CardDescription className="text-xs">
                    {chartPeriod === "year" ? "Bulan Aktif" : "Hari Aktif"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <div className="text-lg font-bold">
                    {getChartSummary().count} {chartPeriod === "year" ? "bulan" : "hari"}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            // Desktop/Tablet View: Chart
            <ChartContainer
              config={{
                total: {
                  label: "Total Pembayaran",
                  color: "hsl(var(--primary))",
                },
              }}
              className="h-[300px] sm:h-[350px] md:h-[400px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart 
                  data={getChartData()} 
                  margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted/50" />
                  <XAxis 
                    dataKey="date" 
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11, fontWeight: 'bold' }}
                    angle={chartPeriod === "30days" ? -45 : 0}
                    textAnchor={chartPeriod === "30days" ? "end" : "middle"}
                    height={chartPeriod === "30days" ? 60 : 30}
                  />
                  <YAxis 
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11, fontWeight: 'bold' }}
                    tickFormatter={(value) => {
                      if (value >= 1000000) return `${(value / 1000000).toFixed(1)}jt`;
                      if (value >= 1000) return `${(value / 1000).toFixed(0)}rb`;
                      return value.toString();
                    }}
                  />
                  <ChartTooltip 
                    content={<ChartTooltipContent />}
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Bar 
                    dataKey="total" 
                    fill="hsl(var(--primary))"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={chartPeriod === "year" ? 80 : 40}
                    isAnimationActive={true}
                    animationDuration={800}
                    animationEasing="ease-in-out"
                  />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </CardContent>
      </Card>

      {/* Payment Method Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {Object.entries(data.methodStats).map(([method, stats]) => (
          <Card key={method}>
            <CardHeader>
              <CardTitle className="text-sm font-medium capitalize">
                {method === "cash" ? "Tunai" : method === "transfer" ? "Transfer" : method}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">{formatCurrency(stats.total)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.count} transaksi
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Transaksi 7 Hari Terakhir</CardTitle>
          <CardDescription>
            {data.recentTransactions.length} pembayaran dalam 7 hari terakhir
            {totalTransactionPages > 1 && ` • Halaman ${transactionPage} dari ${totalTransactionPages}`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isMobile ? (
            // Mobile View: Card List
            <div className="space-y-3">
              {data.recentTransactions.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  Belum ada transaksi dalam 7 hari terakhir
                </div>
              ) : (
                getPaginatedTransactions().map((transaction) => (
                  <Card key={transaction.id} className="border-border/50">
                    <CardContent className="p-4 space-y-2">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1 flex-1">
                          <p className="font-medium text-sm">{transaction.customer}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(transaction.date), "dd MMM yyyy", { locale: id })}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-sm">
                            {formatCurrency(transaction.amount)}
                          </p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center pt-2 border-t">
                        <div className="flex gap-2 items-center">
                          <Badge variant={getPaymentMethodBadge(transaction.method)} className="text-xs">
                            {transaction.method === "cash" ? "Tunai" : transaction.method === "transfer" ? "Transfer" : transaction.method}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            Angsuran #{transaction.installmentNumber}
                          </span>
                        </div>
                        <p className="text-xs font-mono text-muted-foreground">
                          {transaction.application}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          ) : (
            // Desktop/Tablet View: Table
            <div className="overflow-x-auto -mx-6 sm:mx-0">
              <div className="inline-block min-w-full align-middle px-6 sm:px-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[100px]">Tanggal</TableHead>
                      <TableHead className="min-w-[150px]">Nasabah</TableHead>
                      <TableHead className="min-w-[120px]">No. Aplikasi</TableHead>
                      <TableHead className="min-w-[100px]">Angsuran Ke</TableHead>
                      <TableHead className="min-w-[100px]">Metode</TableHead>
                      <TableHead className="text-right min-w-[120px]">Jumlah</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.recentTransactions.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          Belum ada transaksi dalam 7 hari terakhir
                        </TableCell>
                      </TableRow>
                    ) : (
                      getPaginatedTransactions().map((transaction) => (
                        <TableRow key={transaction.id} className="hover:bg-muted/50 transition-colors">
                          <TableCell className="font-medium whitespace-nowrap">
                            {format(new Date(transaction.date), "dd MMM yyyy", { locale: id })}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">{transaction.customer}</TableCell>
                          <TableCell className="font-mono text-sm">{transaction.application}</TableCell>
                          <TableCell className="text-center">{transaction.installmentNumber}</TableCell>
                          <TableCell>
                            <Badge variant={getPaymentMethodBadge(transaction.method)} className="whitespace-nowrap">
                              {transaction.method === "cash" ? "Tunai" : transaction.method === "transfer" ? "Transfer" : transaction.method}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-medium whitespace-nowrap">
                            {formatCurrency(transaction.amount)}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
          
          {/* Pagination Controls */}
          {totalTransactionPages > 1 && (
            <div className="flex items-center justify-between pt-4 border-t mt-4">
              <p className="text-sm text-muted-foreground">
                Menampilkan {((transactionPage - 1) * TRANSACTIONS_PER_PAGE) + 1}-{Math.min(transactionPage * TRANSACTIONS_PER_PAGE, data.recentTransactions.length)} dari {data.recentTransactions.length}
              </p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setTransactionPage(p => Math.max(1, p - 1))}
                  disabled={transactionPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                  <span className="hidden sm:inline ml-1">Sebelumnya</span>
                </Button>
                <span className="text-sm font-medium px-2">
                  {transactionPage} / {totalTransactionPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setTransactionPage(p => Math.min(totalTransactionPages, p + 1))}
                  disabled={transactionPage === totalTransactionPages}
                >
                  <span className="hidden sm:inline mr-1">Selanjutnya</span>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
