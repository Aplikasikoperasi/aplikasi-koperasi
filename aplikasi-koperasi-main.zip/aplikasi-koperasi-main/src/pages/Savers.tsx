import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { UserPlus, Search, ChevronLeft, ChevronRight, Phone, Calendar, Wallet, Briefcase, ArrowUpCircle, Sparkles, Plus, Minus } from "lucide-react";
import { formatRupiah } from "@/lib/utils";
import { useSaversQuery } from "@/hooks/useSaversQuery";
import { useDebounce } from "@/hooks/use-debounce";
import { formatDateWIB } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import SaverRegistrationDialog from "@/components/SaverRegistrationDialog";
import SaverDetailDialog, { TierBadge } from "@/components/SaverDetailDialog";
import SaverEditDialog from "@/components/SaverEditDialog";
import SaverDepositDialog from "@/components/SaverDepositDialog";
import SaverWithdrawalDialog from "@/components/SaverWithdrawalDialog";
import { useIsMobile } from "@/hooks/use-mobile";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { cn } from "@/lib/utils";
import { useUserRole } from "@/contexts/UserRoleContext";

export default function Savers() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [showRegistration, setShowRegistration] = useState(false);
  const [selectedSaver, setSelectedSaver] = useState<any>(null);
  const [editingSaver, setEditingSaver] = useState<any>(null);
  const [depositSaver, setDepositSaver] = useState<any>(null);
  const [withdrawalSaver, setWithdrawalSaver] = useState<any>(null);
  const pageSize = 10;
  const isMobile = useIsMobile();
  const { viewMode, toggleView } = useViewPreference('savers');
  const { isOwner, isAdmin, isKasir } = useUserRole();
  const canManageDeposit = isOwner || isAdmin || isKasir;
  const canViewDetail = isOwner || isAdmin || isKasir;

  const debouncedSearch = useDebounce(search, 300);

  const { data, isLoading, refetch } = useSaversQuery({
    search: debouncedSearch,
    page,
    pageSize,
  });

  // Reset page when search changes
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);

  // Setup realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel("savers-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "savers" },
        () => refetch()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [refetch]);

  const totalPages = Math.ceil((data?.totalCount || 0) / pageSize);

  // Skeleton cards for loading state
  const renderSkeletonCards = () => (
    <div className="grid grid-cols-1 gap-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <Card key={i} className="w-full">
          <CardContent className="p-3">
            <div className="flex items-start gap-3">
              <Skeleton className="h-14 w-14 rounded-full flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-1/3" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari debitur..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <ViewToggle viewMode={viewMode} onToggle={toggleView} />
          <Button onClick={() => setShowRegistration(true)}>
            <UserPlus className="h-4 w-4 mr-2" />
            Daftar Debitur
          </Button>
        </div>
      </div>

      <AnimatedViewTransition viewMode={viewMode}>
        {viewMode === 'card' ? (
          /* Card View */
          <div className="space-y-3">
            {isLoading ? (
              renderSkeletonCards()
            ) : data?.savers.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  {search ? "Tidak ada debitur yang cocok" : "Belum ada debitur terdaftar"}
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-3">
                {data?.savers.map((saver) => (
                  <Card
                    key={saver.id}
                    className={`w-full transition-shadow ${canViewDetail ? 'cursor-pointer hover:shadow-lg' : ''}`}
                    onClick={() => canViewDetail && setSelectedSaver(saver)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        {/* Avatar */}
                        <div className="relative flex-shrink-0 self-center" onClick={(e) => e.stopPropagation()}>
                          <ClickableAvatar
                            src={saver.photo_url}
                            alt={saver.full_name}
                            fallback={saver.full_name.substring(0, 2).toUpperCase()}
                            className="h-14 w-14"
                            fallbackClassName="bg-primary/10 text-primary text-lg"
                          />
                          {/* Status indicator */}
                          <span
                            className={cn(
                              "absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2 ring-background",
                              saver.status === "active" ? "bg-green-500" : "bg-gray-400"
                            )}
                            title={saver.status === "active" ? "Aktif" : "Nonaktif"}
                          />
                        </div>

                        {/* Saver Info */}
                        <div className="flex-1 min-w-0 space-y-1.5">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h3 className="font-semibold text-sm line-clamp-1">
                                  {saver.full_name}
                                </h3>
                                <TierBadge tier={saver.tier_level || 'silver'} size="sm" />
                              </div>
                              <Badge
                                variant={saver.status === "active" ? "default" : "secondary"}
                                className="text-xs mt-1"
                              >
                                {saver.status === "active" ? "Aktif" : "Nonaktif"}
                              </Badge>
                            </div>
                          </div>

                          {/* ID Numbers */}
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-mono font-bold bg-primary/10 px-2 py-0.5 rounded border border-primary/20">
                              {saver.saver_number}
                            </span>
                            <span className="text-xs font-mono bg-muted px-2 py-0.5 rounded border border-border">
                              Rek: {saver.account_number}
                            </span>
                          </div>

                          {/* Balance with Breakdown */}
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5 text-sm font-bold text-primary">
                              <Wallet className="h-3.5 w-3.5" />
                              <span>{formatRupiah(saver.balance || 0)}</span>
                            </div>
                            <div className="flex items-center gap-3 text-[10px] text-muted-foreground pl-5">
                              <span className="flex items-center gap-1">
                                <ArrowUpCircle className="h-2.5 w-2.5 text-green-600" />
                                Deposit: {formatRupiah(saver.deposit_balance || 0)}
                              </span>
                              <span className="flex items-center gap-1">
                                <Sparkles className="h-2.5 w-2.5 text-amber-500" />
                                Bunga: {formatRupiah(saver.interest_balance || 0)}
                              </span>
                            </div>
                          </div>

                          {/* Occupation */}
                          {saver.occupation && (
                            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Briefcase className="h-3 w-3" />
                              <span>{saver.occupation}</span>
                            </div>
                          )}

                          {/* Phone */}
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            <span>{saver.phone}</span>
                          </div>

                          {/* Registration Date */}
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            <span>Terdaftar: {formatDateWIB(saver.created_at)}</span>
                          </div>

                          {/* Action Buttons - Only for Owner/Admin */}
                          {canManageDeposit && (
                            <div className="flex items-center gap-2 pt-2" onClick={(e) => e.stopPropagation()}>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs border-green-500 text-green-600 hover:bg-green-50 hover:text-green-700"
                                onClick={() => setDepositSaver(saver)}
                              >
                                <Plus className="h-3 w-3 mr-1" />
                                Deposit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs border-red-500 text-red-600 hover:bg-red-50 hover:text-red-700"
                                onClick={() => setWithdrawalSaver(saver)}
                                disabled={!saver.balance || saver.balance <= 0}
                              >
                                <Minus className="h-3 w-3 mr-1" />
                                Penarikan
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Table View */
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No. ID</TableHead>
                  <TableHead>No. Rekening</TableHead>
                  <TableHead>Nama</TableHead>
                  <TableHead className="hidden sm:table-cell">Saldo</TableHead>
                  <TableHead className="hidden md:table-cell">Telepon</TableHead>
                  <TableHead className="hidden lg:table-cell">Tgl Daftar</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 8 }).map((_, j) => (
                        <TableCell key={j}>
                          <Skeleton className="h-4 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : data?.savers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      {search ? "Tidak ada debitur yang cocok" : "Belum ada debitur terdaftar"}
                    </TableCell>
                  </TableRow>
                ) : (
                  data?.savers.map((saver) => (
                    <TableRow key={saver.id} className={canViewDetail ? "cursor-pointer hover:bg-muted/50" : ""} onClick={() => canViewDetail && setSelectedSaver(saver)}>
                      <TableCell className="font-medium">{saver.saver_number}</TableCell>
                      <TableCell className="font-mono text-sm">{saver.account_number}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span>{saver.full_name}</span>
                          <TierBadge tier={saver.tier_level || 'silver'} size="sm" />
                        </div>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell font-semibold text-primary">
                        {formatRupiah(saver.balance || 0)}
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{saver.phone}</TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {formatDateWIB(saver.created_at)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={saver.status === "active" ? "default" : "secondary"}
                        >
                          {saver.status === "active" ? "Aktif" : "Nonaktif"}
                        </Badge>
                      </TableCell>
                      {canManageDeposit && (
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 w-7 p-0 border-green-500 text-green-600 hover:bg-green-50 hover:text-green-700"
                              onClick={() => setDepositSaver(saver)}
                              title="Deposit"
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 w-7 p-0 border-red-500 text-red-600 hover:bg-red-50 hover:text-red-700"
                              onClick={() => setWithdrawalSaver(saver)}
                              disabled={!saver.balance || saver.balance <= 0}
                              title="Tarik"
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </AnimatedViewTransition>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Menampilkan {((page - 1) * pageSize) + 1} - {Math.min(page * pageSize, data?.totalCount || 0)} dari {data?.totalCount || 0} debitur
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">
              {page} / {totalPages}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      <SaverRegistrationDialog
        open={showRegistration}
        onOpenChange={setShowRegistration}
      />

      <SaverDetailDialog
        saver={selectedSaver}
        open={!!selectedSaver}
        onOpenChange={(open) => !open && setSelectedSaver(null)}
        onEdit={(saver) => setEditingSaver(saver)}
      />

      <SaverEditDialog
        saver={editingSaver}
        open={!!editingSaver}
        onOpenChange={(open) => !open && setEditingSaver(null)}
      />

      {/* Deposit Dialog */}
      {depositSaver && (
        <SaverDepositDialog
          saverId={depositSaver.id}
          saverName={depositSaver.full_name}
          currentBalance={depositSaver.balance || 0}
          open={!!depositSaver}
          onOpenChange={(open) => !open && setDepositSaver(null)}
          onSuccess={() => {
            setDepositSaver(null);
            refetch();
          }}
        />
      )}

      {/* Withdrawal Dialog */}
      {withdrawalSaver && (
        <SaverWithdrawalDialog
          saverId={withdrawalSaver.id}
          saverName={withdrawalSaver.full_name}
          currentBalance={withdrawalSaver.balance || 0}
          open={!!withdrawalSaver}
          onOpenChange={(open) => !open && setWithdrawalSaver(null)}
          onSuccess={() => {
            setWithdrawalSaver(null);
            refetch();
          }}
        />
      )}
    </div>
  );
}
