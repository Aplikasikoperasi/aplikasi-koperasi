import { useEffect, useState } from "react";
import { useDebounce } from "@/hooks/use-debounce";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { useBlockedCustomersQuery, useInvalidateBlockedCustomers } from "@/hooks/useBlockedCustomersQuery";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Shield, Search, UserCheck, AlertTriangle, Star, Lock, Ban, ShieldAlert } from "lucide-react";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { useToast } from "@/hooks/use-toast";
import { useUserRole } from "@/hooks/useUserRole";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { formatDate, calculateAge, cn } from "@/lib/utils";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyBlockedCustomerDetailDialog as BlockedCustomerDetailDialog } from "@/components/LazyDialogs";
import { useQueryClient } from "@tanstack/react-query";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
interface BlockedCustomer {
  id: string;
  customer_id: string;
  blocked_at: string;
  blocked_reason: string;
  consecutive_missed_months: number;
  blocked_by: string | null;
  customers: {
    id_number: string;
    full_name: string;
    nik: string;
    phone: string;
    address: string;
    photo_url: string | null;
    date_of_birth: string | null;
    credit_score: number | null;
    restoration_status: "never_restored" | "restored_once" | "permanently_blocked";
  };
  blocker?: {
    full_name: string;
  } | null;
}
const BlockedCustomers = () => {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const [superCodeDialogOpen, setSuperCodeDialogOpen] = useState(false);
  const [superCodeInput, setSuperCodeInput] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<BlockedCustomer | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [showDetail, setShowDetail] = useState(false);
  const [autoBlockThreshold, setAutoBlockThreshold] = useState<number>(3.7);
  const { toast } = useToast();
  const { role } = useUserRole();
  const isMobile = useIsMobile();
  const ITEMS_PER_PAGE = 20;
  const { viewMode, toggleView } = useViewPreference('blocked-customers');
  
  const { data, isLoading } = useBlockedCustomersQuery({
    searchQuery: debouncedSearch, 
    page: currentPage, 
    itemsPerPage: ITEMS_PER_PAGE 
  });
  const blockedCustomers = data?.blockedCustomers || [];
  const totalCount = data?.totalCount || 0;
  const invalidateBlockedCustomers = useInvalidateBlockedCustomers();
  useEffect(() => {
    // Load threshold from settings
    const loadThreshold = async () => {
      const { data: appSettings } = await supabase.rpc('get_public_app_settings');
      const threshold = (appSettings as any)?.auto_block_threshold || 3.7;
      setAutoBlockThreshold(threshold);
    };
    loadThreshold();

    // Set up realtime subscription for credit score updates
    const channel = supabase.channel('blocked-customers-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, () => {
      console.log('🔄 Customer data changed, reloading...');
      setCurrentPage(1);
      invalidateBlockedCustomers();
    }).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'blocked_customers'
    }, () => {
      console.log('🔄 Blocked customer data changed, reloading...');
      setCurrentPage(1);
      invalidateBlockedCustomers();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [invalidateBlockedCustomers]);

  // Listen for pull-to-refresh
  useEffect(() => {
    const handleRefresh = () => invalidateBlockedCustomers();
    window.addEventListener('page-refresh', handleRefresh);
    return () => window.removeEventListener('page-refresh', handleRefresh);
  }, [invalidateBlockedCustomers]);

  // Helper function to format blocked reason with current threshold
  const formatBlockedReason = (bc: BlockedCustomer) => {
    const isAutoBlock = bc.blocked_reason?.toLowerCase().includes('skor kredit rendah') || 
                        bc.blocked_reason?.toLowerCase().includes('3.7') ||
                        bc.blocked_reason?.toLowerCase().includes('≤');
    
    if (isAutoBlock) {
      return `Skor kredit rendah (≤${autoBlockThreshold}): ${bc.customers.credit_score?.toFixed(2)}`;
    }
    return bc.blocked_reason;
  };
  const verifySuperCode = async () => {
    if (!superCodeInput) {
      toast({
        title: "Error",
        description: "Masukkan SuperCode",
        variant: "destructive"
      });
      return false;
    }
    try {
      // Use secure server-side verification via edge function
      const {
        data: result,
        error: verifyError
      } = await supabase.functions.invoke('verify-supercode', {
        body: {
          superCodeInput: superCodeInput,
          operation: 'restore_blocked_customer'
        }
      });
      if (verifyError) {
        toast({
          title: "Error",
          description: "Gagal memverifikasi SuperCode. Silakan coba lagi.",
          variant: "destructive"
        });
        return false;
      }
      if (!result?.valid) {
        toast({
          title: "SuperCode Salah",
          description: result?.error || "SuperCode tidak valid",
          variant: "destructive"
        });
        return false;
      }
      return true;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Gagal memverifikasi SuperCode",
        variant: "destructive"
      });
      return false;
    }
  };
  const handleSuperCodeSubmit = async () => {
    const isValid = await verifySuperCode();
    if (!isValid) return;
    setSuperCodeDialogOpen(false);
    setSuperCodeInput("");
    setRestoreDialogOpen(true);
  };
  const handleRestore = async () => {
    if (!selectedCustomer) return;
    try {
      // Call the restore function from database
      const {
        data,
        error
      } = await supabase.rpc('restore_blocked_customer', {
        p_customer_id: selectedCustomer.customer_id
      });
      if (error) throw error;
      const result = data as {
        success: boolean;
        message: string;
      };
      if (!result.success) {
        toast({
          title: "Gagal",
          description: result.message,
          variant: "destructive"
        });
        return;
      }
      toast({
        title: "Berhasil",
        description: result.message || "Nasabah berhasil dipulihkan dengan skor kredit 5"
      });
      await logSystemEvent({
        category: "blocking",
        action: "Pulihkan Nasabah",
        description: `Memulihkan nasabah dari pemblokiran: ${selectedCustomer.customers.full_name}`,
        metadata: {
          customer_id: selectedCustomer.customer_id,
          customer_name: selectedCustomer.customers.full_name,
          id_number: selectedCustomer.customers.id_number,
          restoration_status: selectedCustomer.customers.restoration_status
        }
      });
      setRestoreDialogOpen(false);
      setSelectedCustomer(null);
      setCurrentPage(1);
      invalidateBlockedCustomers();
      // Invalidate customers query so restored customer appears in active list
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      window.dispatchEvent(new Event('customer-restored'));
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Gagal memulihkan nasabah",
        variant: "destructive"
      });
    }
  };
  const openRestoreDialog = (customer: BlockedCustomer) => {
    if (role !== "owner" && role !== "admin") {
      toast({
        title: "Akses Ditolak",
        description: "Hanya Owner atau Admin yang dapat memulihkan nasabah diblokir",
        variant: "destructive"
      });
      return;
    }

    // Check if permanently blocked
    if (customer.customers.restoration_status as string === "permanently_blocked") {
      toast({
        title: "Blokir Permanen",
        description: "Nasabah dengan status blokir permanen tidak dapat dipulihkan",
        variant: "destructive"
      });
      return;
    }
    setSelectedCustomer(customer);
    setSuperCodeDialogOpen(true);
  };
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Helper untuk membatasi nomor halaman yang ditampilkan
  const getPaginationRange = () => {
    const delta = isMobile ? 1 : 2;
    const range: (number | string)[] = [];
    const rangeWithDots: (number | string)[] = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }
    if (currentPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }
    rangeWithDots.push(...range);
    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push('...', totalPages);
    } else if (totalPages > 1) {
      rangeWithDots.push(totalPages);
    }
    return rangeWithDots;
  };
  return <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full max-w-full overflow-hidden mb-3">
        <div className="w-full max-w-full overflow-hidden">
          
          
        </div>
      </div>

      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full max-w-full overflow-hidden">
            <div className="flex items-center gap-3">
              <CardTitle className="text-base sm:text-lg md:text-xl">Nasabah Diblokir: {totalCount}</CardTitle>
              <ViewToggle viewMode={viewMode} onToggle={toggleView} />
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          <div className="mb-4 w-full max-w-full">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Cari nama, NIK, telepon..." value={searchQuery} onChange={e => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }} className="pl-10 w-full" />
            </div>
          </div>

          {isLoading ? <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">Memuat data...</p>
            </div> : <AnimatedViewTransition viewMode={viewMode}>
            {(isMobile || viewMode === 'card') ? <div className="space-y-3 w-full max-w-full">
              {blockedCustomers.length === 0 ? <div className="text-center py-8 text-muted-foreground">
                  {searchQuery ? "Data tidak ditemukan" : "Tidak ada nasabah yang diblokir"}
                </div> : blockedCustomers.map(bc => {
                  const isPermanent = bc.customers.restoration_status === 'permanently_blocked';
                  return (
                    <Card key={bc.id} className="cursor-pointer hover:shadow-md transition-all border-l-4 border-l-destructive" onClick={() => {
                      setSelectedCustomer(bc);
                      setShowDetail(true);
                    }}>
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <ClickableAvatar 
                            src={bc.customers.photo_url}
                            alt={bc.customers.full_name}
                            fallback={bc.customers.full_name?.substring(0, 2).toUpperCase()}
                            className="h-14 w-14 flex-shrink-0"
                            fallbackClassName="bg-destructive/10 text-destructive font-semibold"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <div className="flex-1 min-w-0">
                                <h3 className="font-semibold text-sm truncate">{bc.customers.full_name}</h3>
                                <p className="text-xs text-muted-foreground">{bc.customers.id_number}</p>
                              </div>
                              <Badge variant={isPermanent ? "destructive" : "outline"} className="flex-shrink-0 text-xs">
                                {isPermanent ? <><Ban className="h-3 w-3 mr-1" />Permanen</> : "Diblokir"}
                              </Badge>
                            </div>
                            <div className="space-y-1.5 mt-2">
                              <div className="flex items-center gap-1.5 text-xs">
                                <span className="text-muted-foreground">📞</span>
                                <span>{bc.customers.phone}</span>
                              </div>
                              <div className="flex items-center gap-1.5 text-xs">
                                <AlertTriangle className="h-3 w-3 text-destructive" />
                                <span className="line-clamp-1 text-muted-foreground">{formatBlockedReason(bc)}</span>
                              </div>
                              <div className="flex items-center justify-between gap-2 text-xs">
                                <span className="text-muted-foreground">Diblokir: {formatDate(bc.blocked_at)}</span>
                                <CreditScoreStars creditScore={bc.customers.credit_score || 0} restorationStatus={bc.customers.restoration_status || 'never_restored'} />
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
            </div> : <div className="w-full">
              <ScrollArea className="h-[calc(100vh-320px)] w-full">
                <div className="rounded-md border overflow-x-auto min-w-full">
                  <Table className="min-w-max">
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Foto</TableHead>
                  <TableHead>Nama</TableHead>
                  <TableHead>NIK</TableHead>
                  <TableHead>Tanggal Lahir</TableHead>
                  <TableHead>Usia</TableHead>
                  <TableHead>Alamat</TableHead>
                  <TableHead>Telepon</TableHead>
                  <TableHead>Tanggal Diblokir</TableHead>
                  <TableHead>Bulan Menunggak</TableHead>
                  <TableHead>Alasan</TableHead>
                  <TableHead>Diblokir Oleh</TableHead>
                 </TableRow>
              </TableHeader>
              <TableBody>
                {blockedCustomers.length === 0 ? <TableRow>
                    <TableCell colSpan={12} className="text-center py-8 text-muted-foreground">
                      {searchQuery ? "Data tidak ditemukan" : "Tidak ada nasabah yang diblokir"}
                    </TableCell>
                  </TableRow> : blockedCustomers.map(bc => <TableRow key={bc.id} className="cursor-pointer hover:bg-muted/50" onClick={() => {
                    setSelectedCustomer(bc);
                    setShowDetail(true);
                  }}>
                      <TableCell className="font-medium">
                        {bc.customers.id_number}
                      </TableCell>
                      <TableCell>
                        <ClickableAvatar 
                          src={bc.customers.photo_url}
                          alt={bc.customers.full_name}
                          fallback={bc.customers.full_name.charAt(0)}
                          className="h-10 w-10"
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        {bc.customers.full_name}
                      </TableCell>
                      <TableCell>
                        <span className="font-mono text-red-600 font-semibold">
                          {bc.customers.nik || "-"}
                        </span>
                      </TableCell>
                      <TableCell>
                        {formatDate(bc.customers.date_of_birth)}
                      </TableCell>
                      <TableCell>
                        {calculateAge(bc.customers.date_of_birth) !== null ? `${calculateAge(bc.customers.date_of_birth)} tahun` : "-"}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate">
                        {bc.customers.address}
                      </TableCell>
                      <TableCell>{bc.customers.phone}</TableCell>
                      <TableCell>
                        {formatDate(bc.blocked_at)}
                      </TableCell>
                      <TableCell className="text-center">
                        {bc.consecutive_missed_months}
                      </TableCell>
                      <TableCell className="max-w-[250px]">
                        <span className="text-sm text-muted-foreground">
                          {formatBlockedReason(bc)}
                        </span>
                      </TableCell>
                      <TableCell>
                        {bc.blocked_by === null ? <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                            Sistem
                          </Badge> : bc.blocker?.full_name || "-"}
                      </TableCell>
                    </TableRow>)}
              </TableBody>
            </Table>
          </div>
              </ScrollArea>
            </div>}
          </AnimatedViewTransition>}
        </CardContent>
      </Card>

      <BlockedCustomerDetailDialog open={showDetail} onOpenChange={setShowDetail} blockedCustomer={selectedCustomer} canRestore={role === "owner" || role === "admin"} onRestore={openRestoreDialog} />

      {totalPages > 1 && <div className="flex justify-center sm:justify-end">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious onClick={() => handlePageChange(Math.max(1, currentPage - 1))} className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
              {getPaginationRange().map((page, idx) => <PaginationItem key={idx}>
                  {page === '...' ? <span className="px-2">...</span> : <PaginationLink onClick={() => handlePageChange(page as number)} isActive={currentPage === page} className="cursor-pointer">
                      {page}
                    </PaginationLink>}
                </PaginationItem>)}
              <PaginationItem>
                <PaginationNext onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))} className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>}


      <Dialog open={superCodeDialogOpen} onOpenChange={setSuperCodeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Verifikasi SuperCode
            </DialogTitle>
            <DialogDescription>
              Masukkan SuperCode untuk memulihkan nasabah{" "}
              <span className="font-semibold">
                {selectedCustomer?.customers.full_name}
              </span>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="supercode">SuperCode</Label>
              <Input id="supercode" type="password" value={superCodeInput} onChange={e => setSuperCodeInput(e.target.value)} placeholder="Masukkan SuperCode" onKeyDown={e => {
              if (e.key === 'Enter') {
                handleSuperCodeSubmit();
              }
            }} />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => {
            setSuperCodeDialogOpen(false);
            setSuperCodeInput("");
          }}>
              Batal
            </Button>
            <Button onClick={handleSuperCodeSubmit}>
              Verifikasi
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Pulihkan Nasabah</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin memulihkan nasabah{" "}
              <span className="font-semibold">
                {selectedCustomer?.customers.full_name}
              </span>
              ? Nasabah ini akan dapat mengajukan pinjaman kembali.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleRestore}>
              Pulihkan
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>;
};
export default BlockedCustomers;