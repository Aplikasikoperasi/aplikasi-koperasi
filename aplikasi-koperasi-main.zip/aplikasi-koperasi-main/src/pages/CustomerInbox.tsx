import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Mail, MailOpen, Info, AlertCircle, CheckCircle, Trash2, Inbox as InboxIcon, ArrowLeft } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { id as idLocale } from "date-fns/locale";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useNavigate } from "react-router-dom";
import { useCustomerData } from "@/hooks/useCustomerData";

interface Message {
  id: string;
  title: string;
  message: string;
  type: "info" | "announcement" | "reminder" | "warning" | "payment" | "receipt";
  is_read: boolean;
  created_at: string;
}

export default function CustomerInbox() {
  const navigate = useNavigate();
  const { customerId, loading: customerLoading } = useCustomerData();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; messageId: string | null }>({
    open: false,
    messageId: null,
  });
  const [deleteAllDialog, setDeleteAllDialog] = useState(false);
  const [autoBlockThreshold, setAutoBlockThreshold] = useState<number>(3.7);

  // Load auto block threshold
  useEffect(() => {
    const loadThreshold = async () => {
      const { data: appSettings } = await supabase.rpc('get_public_app_settings');
      const threshold = (appSettings as any)?.auto_block_threshold || 3.7;
      setAutoBlockThreshold(threshold);
    };
    loadThreshold();
  }, []);

  useEffect(() => {
    if (!customerLoading && customerId) {
      loadMessages();
      
      // Subscribe to realtime updates - hanya update state, tidak reload penuh
      const channel = supabase
        .channel('customer-messages-changes')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'customer_messages',
            filter: `customer_id=eq.${customerId}`
          },
          (payload) => {
            setMessages(prev => [payload.new as Message, ...prev]);
          }
        )
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'customer_messages',
            filter: `customer_id=eq.${customerId}`
          },
          (payload) => {
            setMessages(prev => prev.map(msg => 
              msg.id === payload.new.id ? payload.new as Message : msg
            ));
          }
        )
        .on(
          'postgres_changes',
          {
            event: 'DELETE',
            schema: 'public',
            table: 'customer_messages',
            filter: `customer_id=eq.${customerId}`
          },
          (payload) => {
            setMessages(prev => prev.filter(msg => msg.id !== payload.old.id));
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [customerLoading, customerId]);

  const loadMessages = async () => {
    if (!customerId) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("customer_messages")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setMessages((data || []) as Message[]);
    } catch (error) {
      console.error("Error loading messages:", error);
      toast.error("Gagal memuat pesan");
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (messageId: string) => {
    try {
      const { error } = await supabase
        .from("customer_messages")
        .update({ is_read: true })
        .eq("id", messageId);

      if (error) throw error;
      
      setMessages(prev => 
        prev.map(msg => msg.id === messageId ? { ...msg, is_read: true } : msg)
      );
    } catch (error) {
      console.error("Error marking message as read:", error);
    }
  };

  const handleMessageClick = (message: Message) => {
    setSelectedMessage(message);
    if (!message.is_read) {
      markAsRead(message.id);
    }
  };

  const handleDeleteMessage = async () => {
    if (!deleteDialog.messageId) return;

    try {
      const { error } = await supabase
        .from("customer_messages")
        .delete()
        .eq("id", deleteDialog.messageId);

      if (error) throw error;

      toast.success("Pesan berhasil dihapus");
      setMessages(prev => prev.filter(msg => msg.id !== deleteDialog.messageId));
      if (selectedMessage?.id === deleteDialog.messageId) {
        setSelectedMessage(null);
      }
    } catch (error) {
      console.error("Error deleting message:", error);
      toast.error("Gagal menghapus pesan");
    } finally {
      setDeleteDialog({ open: false, messageId: null });
    }
  };

  const handleDeleteAllMessages = async () => {
    if (!customerId) return;

    try {
      const { error } = await supabase
        .from("customer_messages")
        .delete()
        .eq("customer_id", customerId);

      if (error) throw error;

      toast.success("Semua pesan berhasil dihapus");
      setMessages([]);
      setSelectedMessage(null);
      setDeleteAllDialog(false);
    } catch (error) {
      console.error("Error deleting all messages:", error);
      toast.error("Gagal menghapus semua pesan");
    }
  };

  // Helper function untuk format message dengan threshold dinamis
  const formatMessageText = (text: string) => {
    // Replace any hardcoded threshold dengan threshold dinamis
    return text
      .replace(/threshold\s*[≤<=]\s*\d+\.?\d*/gi, `threshold ≤ ${autoBlockThreshold}`)
      .replace(/(\d+\.?\d*)\s*\(threshold.*?\)/gi, (match, score) => `${score} (threshold ≤ ${autoBlockThreshold})`)
      .replace(/skor.*?minimum\s*\d+\.?\d*/gi, `skor kredit minimum ${autoBlockThreshold}`)
      .replace(/ambang batas minimum\s*\d+\.?\d*/gi, `ambang batas minimum ${autoBlockThreshold}`);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "info":
        return <Info className="h-4 w-4 text-blue-500" />;
      case "announcement":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "reminder":
        return <AlertCircle className="h-4 w-4 text-orange-500" />;
      case "warning":
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case "payment":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "receipt":
        return <CheckCircle className="h-4 w-4 text-blue-500" />;
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  const getTypeBadge = (type: string) => {
    const variants: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      info: { label: "Informasi", variant: "default" },
      announcement: { label: "Pengumuman", variant: "secondary" },
      reminder: { label: "Pengingat", variant: "outline" },
      warning: { label: "Peringatan", variant: "destructive" },
      payment: { label: "Pembayaran", variant: "default" },
      receipt: { label: "Kwitansi", variant: "secondary" },
    };
    const config = variants[type] || variants.info;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const unreadCount = messages.filter(m => !m.is_read).length;

  if (customerLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 md:p-8">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/customer-dashboard")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <InboxIcon className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div>
            <h1 className="text-2xl font-semibold">Kotak Pesan</h1>
            <p className="text-muted-foreground">
              {unreadCount > 0 ? `${unreadCount} pesan belum dibaca` : "Semua pesan sudah dibaca"}
            </p>
          </div>
        </div>
        {messages.length > 0 && (
          <Button
            variant="destructive"
            size="sm"
            onClick={() => setDeleteAllDialog(true)}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Hapus Semua
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Daftar Pesan</CardTitle>
            </CardHeader>
            <CardContent>
              {messages.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Belum ada pesan
                </p>
              ) : (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      onClick={() => handleMessageClick(msg)}
                      className={`p-3 rounded-lg cursor-pointer transition-colors hover:bg-muted/50 ${
                        selectedMessage?.id === msg.id ? "bg-muted" : ""
                      } ${!msg.is_read ? "border-l-4 border-primary" : ""}`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          {getTypeIcon(msg.type)}
                          <p className="font-semibold text-sm truncate">{formatMessageText(msg.title)}</p>
                        </div>
                        {!msg.is_read ? (
                          <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                        ) : (
                          <MailOpen className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {formatMessageText(msg.message)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(msg.created_at), {
                          addSuffix: true,
                          locale: idLocale,
                        })}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Message Detail */}
        <div className="lg:col-span-2">
          <Card className="min-h-[600px]">
            <CardHeader>
              <CardTitle>Detail Pesan</CardTitle>
            </CardHeader>
            <CardContent>
              {!selectedMessage ? (
                <div className="flex flex-col items-center justify-center h-[500px] text-center">
                  <InboxIcon className="h-16 w-16 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    Pilih pesan untuk melihat detail
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {getTypeIcon(selectedMessage.type)}
                        <h3 className="text-xl font-semibold">
                          {formatMessageText(selectedMessage.title)}
                        </h3>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        {getTypeBadge(selectedMessage.type)}
                        <span>•</span>
                        <span>
                          {formatDistanceToNow(new Date(selectedMessage.created_at), {
                            addSuffix: true,
                            locale: idLocale,
                          })}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() =>
                        setDeleteDialog({ open: true, messageId: selectedMessage.id })
                      }
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="prose prose-sm max-w-none">
                    <p className="whitespace-pre-line">{formatMessageText(selectedMessage.message)}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <AlertDialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog({ ...deleteDialog, open })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pesan</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus pesan ini? Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteMessage}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteAllDialog} onOpenChange={setDeleteAllDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Semua Pesan?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus semua pesan dari kotak masuk Anda. 
              Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAllMessages}>
              Ya, Hapus Semua
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
