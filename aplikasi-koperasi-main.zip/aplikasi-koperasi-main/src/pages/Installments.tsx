import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useDebounce } from "@/hooks/use-debounce";
import { logSystemEvent } from "@/lib/systemLogger";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { useToast } from "@/hooks/use-toast";
import { formatRupiah, formatDate, cn, roundToThousand } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Search, Plus, AlertTriangle, Clock, DollarSign, Filter, MessageSquare } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LazyInstallmentPaymentDialog as InstallmentPaymentDialog } from "@/components/LazyDialogs";
import { useUserRole } from "@/hooks/useUserRole";
import { generateInstallmentReminderMessage, openWhatsAppChat } from "@/lib/whatsappHelper";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { LazyInstallmentDetailDialog as InstallmentDetailDialog } from "@/components/LazyDialogs";
import { SkeletonTable } from "@/components/ui/skeleton-table";
import { SkeletonCard } from "@/components/ui/skeleton-card";
import { useInstallmentsQuery, usePenaltyRate, useInvalidateInstallments } from "@/hooks/useInstallmentsQuery";
import { ViewToggle } from "@/components/ViewToggle";
import { useViewPreference } from "@/hooks/useViewPreference";
import { AnimatedViewTransition } from "@/components/AnimatedViewTransition";
export default function Installments() {
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [selectedInstallmentId, setSelectedInstallmentId] = useState<string | null>(null);
  const [selectedInstallment, setSelectedInstallment] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const {
    toast
  } = useToast();
  const {
    isOwner,
    isAdmin,
    isSales,
    isKasir
  } = useUserRole();
  const canMakePayment = isOwner || isAdmin || isKasir;
  const isMobile = useIsMobile();
  const ITEMS_PER_PAGE = 20;
  const invalidateInstallments = useInvalidateInstallments();
  const {
    viewMode,
    toggleView
  } = useViewPreference('installments');

  // Real-time subscription for installments updates
  useEffect(() => {
    console.log("[Installments] Setting up realtime subscription...");
    const channel = supabase.channel('installments-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'installments'
    }, payload => {
      console.log('[Installments] Realtime update received:', payload);
      // Invalidate queries to refetch data
      invalidateInstallments();
      toast({
        title: "Data Diperbarui",
        description: "Data angsuran telah diperbarui secara real-time"
      });
    }).subscribe(status => {
      console.log('[Installments] Subscription status:', status);
    });
    return () => {
      console.log("[Installments] Cleaning up realtime subscription");
      supabase.removeChannel(channel);
    };
  }, [invalidateInstallments, toast]);

  // Use React Query hooks with preserved filters
  const {
    data: penaltyRateData
  } = usePenaltyRate();
  const penaltyRate = penaltyRateData || 2.0;
  const {
    data,
    isLoading
  } = useInstallmentsQuery({
    searchQuery: debouncedSearch,
    selectedMember: selectedMemberFilter,
    page: currentPage,
    itemsPerPage: ITEMS_PER_PAGE
  });
  const installments = data?.installments || [];
  const totalCount = data?.totalCount || 0;
  const members = data?.uniqueMembers || [];
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch, selectedMemberFilter]);
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  const calculatePenalty = (dueDate: string, paidAmount: number, totalAmount: number, frozenPenalty?: number, principalPaid?: boolean) => {
    // If pokok sudah lunas, gunakan denda beku (frozen)
    if (principalPaid) return Number(frozenPenalty || 0);
    // Jika belum jatuh tempo atau sudah lunas penuh, tidak ada denda
    const today = new Date();
    const due = new Date(dueDate);
    if (today <= due || paidAmount >= totalAmount) return 0;
    // Konsisten dengan dialog detail: denda per hari = roundToThousand(total_amount * (rate/100))
    const daysOverdue = Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
    const dailyPenalty = roundToThousand(totalAmount * (penaltyRate / 100));
    return Math.max(0, daysOverdue * dailyPenalty);
  };
  const getDaysOverdue = (dueDate: string, paidAmount: number, totalAmount: number) => {
    if (paidAmount >= totalAmount) return 0;
    const today = new Date();
    const due = new Date(dueDate);
    return today <= due ? 0 : Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
  };
  const isReminder = (dueDate: string, paidAmount: number, totalAmount: number) => {
    if (paidAmount >= totalAmount) return false;
    const diffDays = Math.ceil((new Date(dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 3;
  };
  const getStatusBadge = (status: string, paidAmount: number, totalAmount: number, frozenPenalty: number | null) => {
    if (paidAmount >= totalAmount + (frozenPenalty || 0)) {
      return <Badge variant="default" className="bg-success text-success-foreground">Lunas</Badge>;
    }
    if (paidAmount > 0) {
      return <Badge variant="outline" className="border-warning text-warning">Sebagian</Badge>;
    }
    return <Badge variant="destructive">Belum Bayar</Badge>;
  };
  const handlePayment = (installmentId: string) => {
    setSelectedInstallmentId(installmentId);
    setPaymentDialogOpen(true);
  };
  const handleDetailClick = (installment: any) => {
    setSelectedInstallment(installment);
    setShowDetail(true);
  };
  const handleSendReminder = async (installment: any) => {
    if (!installment.credit_application?.customer?.phone) {
      toast({
        variant: "destructive",
        title: "Gagal",
        description: "Nomor telepon pelanggan tidak tersedia"
      });
      return;
    }
    const message = generateInstallmentReminderMessage(installment);
    openWhatsAppChat(installment.credit_application.customer.phone, message);
    toast({
      title: "Berhasil",
      description: "Pengingat pembayaran telah dikirim via WhatsApp"
    });
  };
  const getPaginationRange = (current: number, total: number) => {
    const delta = 2;
    const range = [];
    const rangeWithDots = [];
    let l;
    for (let i = 1; i <= total; i++) {
      if (i === 1 || i === total || i >= current - delta && i <= current + delta) {
        range.push(i);
      }
    }
    for (let i of range) {
      if (l) {
        if (i - l === 2) {
          rangeWithDots.push(l + 1);
        } else if (i - l !== 1) {
          rangeWithDots.push('...');
        }
      }
      rangeWithDots.push(i);
      l = i;
    }
    return rangeWithDots;
  };
  return <div className="w-full max-w-full overflow-hidden animate-fade-in">

      <Card className="w-full max-w-full overflow-hidden animate-fade-in">
        <CardHeader>
          <div className="flex flex-col gap-4 w-full max-w-full overflow-hidden">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="flex items-center gap-2">
                <CardTitle className="text-base sm:text-lg md:text-xl truncate max-w-full">Semua Angsuran: {totalCount}</CardTitle>
                <ViewToggle viewMode={viewMode} onToggle={toggleView} />
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap sm:flex-nowrap sm:ml-auto">
                <Select value={selectedMemberFilter} onValueChange={setSelectedMemberFilter}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Filter Penanggung Jawab" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Penanggung Jawab</SelectItem>
                    {members.map(member => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input 
                placeholder="Cari nama, ID nasabah..." 
                value={searchQuery} 
                onChange={(e) => setSearchQuery(e.target.value)} 
                className="pl-9 w-full" 
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          {isLoading ? isMobile || viewMode === 'card' ? <div className="space-y-3">
                {Array.from({
            length: 5
          }).map((_, i) => <SkeletonCard key={i} rows={3} />)}
              </div> : <SkeletonTable rows={10} columns={9} /> : <AnimatedViewTransition viewMode={viewMode}>
            {isMobile || viewMode === 'card' ? <div className="space-y-3 w-full max-w-full">
              {installments.length === 0 ? <div className="text-center py-8 text-muted-foreground">
                  Tidak ada data angsuran
                </div> : installments.map(inst => {
            const penalty = calculatePenalty(inst.due_date, inst.paid_amount, inst.total_amount, inst.frozen_penalty, inst.principal_paid);
            const remainingAmount = inst.total_amount - inst.paid_amount + penalty;

            // Calculate days difference
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const dueDate = new Date(inst.due_date);
            dueDate.setHours(0, 0, 0, 0);
            const diffTime = dueDate.getTime() - today.getTime();
            const daysUntilDue = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

            // Determine card color based on status
            let cardStyle = "hover:shadow-md transition-all duration-300";
            let statusIcon = null;
            let statusBadge = null;

            // Check if principal paid but has penalty (special case)
            const hasPrincipalPaidWithPenalty = inst.principal_paid && (inst.frozen_penalty || 0) > 0;
            
            // Check if partially paid
            const isPartial = inst.paid_amount > 0 && inst.paid_amount < inst.total_amount;
            
            if (hasPrincipalPaidWithPenalty) {
              // Orange/amber for principal paid but penalty remains
              cardStyle = cn(cardStyle, "bg-amber-50 border-l-4 border-amber-500");
              statusBadge = <Badge className="bg-amber-500 text-white text-xs">Pokok Lunas - Sisa Denda</Badge>;
            } else if (isPartial) {
              // Yellow for partial payment
              cardStyle = cn(cardStyle, "bg-yellow-50 border-l-4 border-yellow-500");
            } else if (daysUntilDue < 0) {
              // Red for overdue (past due date)
              cardStyle = cn(cardStyle, "bg-red-50 border-l-4 border-red-600");
              statusIcon = <AlertTriangle className="h-4 w-4 text-red-600 flex-shrink-0 animate-pulse" />;
              statusBadge = <Badge variant="destructive" className="text-xs">Menunggak</Badge>;
            } else if (daysUntilDue === 0) {
              // Yellow for due today
              cardStyle = cn(cardStyle, "bg-yellow-50 border-l-4 border-yellow-500");
            } else if (daysUntilDue >= 1 && daysUntilDue <= 3) {
              // Green for reminder period (1-3 days before due)
              cardStyle = cn(cardStyle, "bg-green-50 border-l-4 border-green-500");
            }
            return <div key={inst.id} className="space-y-1">
              {statusBadge && <div className="ml-1">{statusBadge}</div>}
              <MobileDataCard id={inst.credit_applications?.customers?.id_number || "-"} photoUrl={inst.credit_applications?.customers?.photo_url} name={inst.credit_applications?.customers?.full_name || "Unknown"} subtitle={`Angsuran ke-${inst.installment_number}/${inst.credit_applications?.tenor_months || "-"} - ${formatRupiah(inst.total_amount)}${inst.status === 'paid' ? ' (Lunas)' : ''}`} remainingAmount={inst.status !== 'paid' && remainingAmount > 0 ? remainingAmount : undefined} dueDate={inst.due_date} penaltyAmount={penalty} isSilenced={inst.is_silenced} onClick={() => {
              setSelectedInstallment(inst);
              setShowDetail(true);
            }} responsibleMember={inst.credit_applications?.members ? {
              full_name: inst.credit_applications.members.full_name,
              position: inst.credit_applications.members.position
            } : null} statusIndicator={statusIcon} className={cardStyle} />
            </div>;
          })}
            </div> : <div className="w-full relative">
              <div className="overflow-auto h-[calc(100vh-320px)] w-full">
                <Table className="min-w-max relative">
                  <TableHeader className="sticky top-0 z-20 bg-background shadow-sm">
              <TableRow className="bg-background">
                 <TableHead className="sticky top-0 z-30 bg-background">ID</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Nama</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Penanggung Jawab</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">KET</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Jatuh Tempo</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Angsuran</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Denda / Hari</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Keterlambatan</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Total Denda</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Terbayar</TableHead>
                <TableHead className="sticky top-0 z-30 bg-background">Sisa Tagihan</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {installments.map((inst, index) => {
                  const penalty = calculatePenalty(inst.due_date, inst.paid_amount, inst.total_amount, inst.frozen_penalty, inst.principal_paid);
                  const dailyPenalty = roundToThousand(inst.total_amount * (penaltyRate / 100));
                  const remainingAmount = inst.total_amount - inst.paid_amount + penalty;
                  const daysOverdue = getDaysOverdue(inst.due_date, inst.paid_amount, inst.total_amount);

                  // Calculate days difference (same logic as mobile)
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  const dueDate = new Date(inst.due_date);
                  dueDate.setHours(0, 0, 0, 0);
                  const diffTime = dueDate.getTime() - today.getTime();
                  const daysUntilDue = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                  // Determine row color based on status (same as mobile)
                  let bgClass = "";
                  let isOverdue = false;
                  let statusBadge = null;

                  // Check if principal paid but has penalty (special case)
                  const hasPrincipalPaidWithPenalty = inst.principal_paid && (inst.frozen_penalty || 0) > 0;
                  
                  // Check if partially paid
                  const isPartial = inst.paid_amount > 0 && inst.paid_amount < inst.total_amount;
                  
                  if (hasPrincipalPaidWithPenalty) {
                    // Orange/amber for principal paid but penalty remains
                    bgClass = "bg-amber-50 hover:bg-amber-100";
                    statusBadge = <Badge className="bg-amber-500 text-white text-xs ml-2">Sisa Denda</Badge>;
                  } else if (isPartial) {
                    // Yellow for partial payment
                    bgClass = "bg-yellow-50 hover:bg-yellow-100";
                  } else if (daysUntilDue < 0) {
                    // Red for overdue (past due date)
                    bgClass = "bg-red-50 hover:bg-red-100";
                    isOverdue = true;
                    statusBadge = <Badge variant="destructive" className="text-xs ml-2">Menunggak</Badge>;
                  } else if (daysUntilDue === 0) {
                    // Yellow for due today
                    bgClass = "bg-yellow-50 hover:bg-yellow-100";
                  } else if (daysUntilDue >= 1 && daysUntilDue <= 3) {
                    // Green for reminder period (1-3 days before due)
                    bgClass = "bg-green-50 hover:bg-green-100";
                  }
                  return <TableRow key={inst.id} className={cn(bgClass, "cursor-pointer hover:bg-muted/50 transition-colors")} onClick={() => {
                    setSelectedInstallment(inst);
                    setShowDetail(true);
                  }}>
                     <TableCell>
                       <div className="flex items-center gap-2">
                         {isOverdue && <AlertTriangle className="h-4 w-4 text-red-600" />}
                         <span>{inst.credit_applications?.customers?.id_number}</span>
                         {statusBadge}
                         {inst.is_silenced && (
                           <span className="text-xs bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-1.5 py-0.5 rounded border border-purple-300 dark:border-purple-700" title="Silent Mode - Tidak ada reminder otomatis">
                             🔕
                           </span>
                         )}
                       </div>
                     </TableCell>
                    <TableCell>{inst.credit_applications?.customers?.full_name}</TableCell>
                    <TableCell>{inst.credit_applications?.members?.full_name || "-"}</TableCell>
                    <TableCell>{inst.installment_number} / {inst.credit_applications?.tenor_months || "-"}</TableCell>
                    <TableCell>{formatDate(inst.due_date)}</TableCell>
                    <TableCell>{formatRupiah(inst.total_amount)}</TableCell>
                    <TableCell>{formatRupiah(dailyPenalty)}</TableCell>
                    <TableCell>{daysOverdue > 0 ? `${daysOverdue} hari` : "-"}</TableCell>
                    <TableCell>{penalty > 0 ? formatRupiah(penalty) : "Rp. 0"}</TableCell>
                    <TableCell>{formatRupiah(inst.paid_amount)}</TableCell>
                    <TableCell className="font-semibold text-primary">
                      {formatRupiah(remainingAmount)}
                    </TableCell>
                  </TableRow>;
                })}
            </TableBody>
          </Table>
              </div>
            </div>}
          </AnimatedViewTransition>}
        </CardContent>
      </Card>

      <InstallmentDetailDialog open={showDetail} onOpenChange={setShowDetail} installment={selectedInstallment} onPay={inst => {
      setSelectedInstallmentId(inst.id);
      setPaymentDialogOpen(true);
    }} />

      {totalPages > 1 && <div className="flex justify-center sm:justify-end">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
              {getPaginationRange(currentPage, totalPages).map((page, idx) => <PaginationItem key={idx}>
                  {page === '...' ? <span className="px-2">...</span> : <PaginationLink onClick={() => setCurrentPage(page as number)} isActive={currentPage === page} className="cursor-pointer">
                      {page}
                    </PaginationLink>}
                </PaginationItem>)}
              <PaginationItem>
                <PaginationNext onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))} className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"} />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>}

      <InstallmentPaymentDialog open={paymentDialogOpen} onOpenChange={open => {
      setPaymentDialogOpen(open);
      if (!open) setSelectedInstallmentId(null);
    }} onSuccess={() => {
      setSelectedInstallmentId(null);
    }} preSelectedInstallmentId={selectedInstallmentId} />
    </div>;
}