import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatRupiah } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Crown, Phone, MapPin, Calendar, DollarSign, ChevronDown, ChevronUp, Search } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useUserRole } from "@/hooks/useUserRole";
import { Input } from "@/components/ui/input";
import { useDebounce } from "@/hooks/use-debounce";
import { AchievementBadge } from "@/components/AchievementBadge";
interface CreditDetail {
  id: string;
  application_number: string;
  application_date: string;
  amount_approved: number | null;
  amount_requested: number;
  tenor_months: number;
  status: string;
  installment_amount: number;
}
interface RoyalCustomerData {
  customer: {
    id: string;
    full_name: string;
    phone: string;
    address: string;
    id_number?: string;
  };
  credits: CreditDetail[];
  totalAmount: number;
  activeCredits: number;
  completedCredits: number;
  badge_level?: string;
  badge_name?: string;
}
export default function RoyalCustomers() {
  const [royalCustomersData, setRoyalCustomersData] = useState<RoyalCustomerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const itemsPerPage = 15;
  const {
    role,
    isOwner,
    isAdmin,
    isSales
  } = useUserRole();
  const fetchRoyalCustomers = async () => {
    try {
      // Get current user and member_id if sales
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      let query = supabase.from('credit_applications').select(`
            id,
            customer_id,
            member_id,
            amount_approved,
            amount_requested,
            tenor_months,
            interest_rate,
            status,
            application_number,
            application_date,
            customers (
              id,
              full_name,
              phone,
              address,
              id_number
            ),
            installments (
              total_amount
            )
          `).neq('status', 'pending').neq('status', 'rejected');

      // Filter by member_id for sales role
      if (isSales && user) {
        const {
          data: memberData
        } = await supabase.from('members').select('id').eq('user_id', user.id).single();
        if (memberData) {
          query = query.eq('member_id', memberData.id);
        }
      }
      const {
        data: applications,
        error
      } = await query.order('application_date', {
        ascending: false
      });
      if (!error && applications) {
        const customerMap = new Map();
        applications.forEach(app => {
          const customerId = app.customer_id;
          const approvedAmount = app.amount_approved || app.amount_requested;

          // Ambil angsuran/bulan dari data installment yang sudah dibuat (snapshot)
          const installmentAmount = app.installments && app.installments.length > 0 ? app.installments[0].total_amount : approvedAmount / app.tenor_months;
          if (!customerMap.has(customerId)) {
            customerMap.set(customerId, {
              customer: app.customers,
              credits: [],
              totalAmount: 0,
              activeCredits: 0,
              completedCredits: 0
            });
          }
          const customerData = customerMap.get(customerId);
          customerData.credits.push({
            ...app,
            installment_amount: installmentAmount
          });
          customerData.totalAmount += approvedAmount;

          // Status 'completed' atau 'paid' = kredit selesai
          // Status lainnya (approved, disbursed, unpaid, overdue, partial) = kredit aktif
          if (app.status === 'completed' || app.status === 'paid') {
            customerData.completedCredits++;
          } else {
            customerData.activeCredits++;
          }
        });
        const royalCustomers = Array.from(customerMap.values()).filter(data => data.credits.length > 1).sort((a, b) => b.totalAmount - a.totalAmount);

        // Fetch badge data for each customer
        const customersWithBadges = await Promise.all(royalCustomers.map(async royalData => {
          const {
            data: badgeData
          } = await supabase.rpc('get_customer_achievement_badge', {
            p_customer_id: royalData.customer.id
          });
          return {
            ...royalData,
            badge_level: badgeData?.[0]?.badge_level,
            badge_name: badgeData?.[0]?.badge_name
          };
        }));
        setRoyalCustomersData(customersWithBadges);
      }
    } catch (error) {
      console.error('Error fetching royal customers:', error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    document.title = "Nasabah Royal | Kredit Lebih dari 1";

    // Initial fetch
    fetchRoyalCustomers();

    // Subscribe to realtime changes on credit_applications
    const channel = supabase.channel('royal-customers-realtime').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, payload => {
      console.log('Credit application changed:', payload);
      // Refetch data when any credit application changes
      fetchRoyalCustomers();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, {
      label: string;
      variant: "default" | "secondary" | "destructive" | "outline";
    }> = {
      completed: {
        label: "Lunas",
        variant: "default"
      },
      paid: {
        label: "Lunas",
        variant: "default"
      },
      unpaid: {
        label: "Belum Lunas",
        variant: "secondary"
      },
      overdue: {
        label: "Menunggak",
        variant: "destructive"
      },
      disbursed: {
        label: "Dicairkan",
        variant: "outline"
      },
      approved: {
        label: "Disetujui",
        variant: "outline"
      },
      partial: {
        label: "Sebagian",
        variant: "secondary"
      }
    };
    const config = statusMap[status] || {
      label: status,
      variant: "outline"
    };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };
  const toggleCard = (customerId: string) => {
    setExpandedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(customerId)) {
        newSet.delete(customerId);
      } else {
        newSet.add(customerId);
      }
      return newSet;
    });
  };

  // Filter customers based on search
  const filteredCustomers = royalCustomersData.filter(royalData => {
    if (!debouncedSearch) return true;
    const searchLower = debouncedSearch.toLowerCase();
    return royalData.customer.full_name.toLowerCase().includes(searchLower) || royalData.customer.phone.includes(searchLower) || royalData.customer.address.toLowerCase().includes(searchLower) || royalData.customer.id_number && royalData.customer.id_number.toLowerCase().includes(searchLower);
  });

  // Pagination calculations
  const totalPages = Math.ceil(filteredCustomers.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentData = filteredCustomers.slice(startIndex, endIndex);
  const goToPage = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  if (loading) {
    return <div className="w-full p-4 md:p-6">
        <div className="flex items-center gap-3 mb-6">
          <Crown className="h-8 w-8 text-amber-600" />
          <h1 className="text-3xl font-bold text-amber-900">Nasabah Royal</h1>
        </div>
        <p className="text-muted-foreground">Memuat data...</p>
      </div>;
  }
  return <div className="w-full p-4 md:p-6">
      <header className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Crown className="h-8 w-8 text-amber-600" />
          <h1 className="text-3xl font-bold text-amber-900">Nasabah Royal</h1>
        </div>
        <p className="text-muted-foreground mb-4">
          Nasabah dengan lebih dari 1 kredit{isSales ? " (Nasabah Anda)" : ""} • Total: {filteredCustomers.length} nasabah
        </p>
        
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input type="text" placeholder="Cari berdasarkan nama, telepon, NIK, atau alamat..." value={searchQuery} onChange={e => {
          setSearchQuery(e.target.value);
          setCurrentPage(1);
        }} className="pl-10" />
        </div>
        
        {totalPages > 1 && <p className="text-sm text-muted-foreground mt-4">
            Halaman {currentPage} dari {totalPages} • Menampilkan {startIndex + 1}-{Math.min(endIndex, filteredCustomers.length)} dari {filteredCustomers.length} nasabah
          </p>}
      </header>

      <div className="space-y-4">
        {currentData.map((royalData, index) => {
        const globalIndex = startIndex + index;
        const isExpanded = expandedCards.has(royalData.customer.id);
        return <Card key={royalData.customer.id} className="border-amber-200 shadow-lg overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950 p-4 md:p-6">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className="bg-amber-600 hover:bg-amber-700 flex-shrink-0">
                        Rank #{globalIndex + 1}
                      </Badge>
                      <CardTitle className="text-xl md:text-2xl break-words">{royalData.customer.full_name}</CardTitle>
                    </div>
                    <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                      {royalData.customer.id_number && <div className="flex items-center gap-2 flex-wrap">
                          <span className="break-all font-bold">{royalData.customer.id_number}</span>
                          {royalData.badge_level && royalData.badge_name && <AchievementBadge badgeLevel={royalData.badge_level} badgeName={royalData.badge_name} badgeDescription="" consecutivePayments={0} onTimePercentage={0} size="sm" showDetails={false} />}
                        </div>}
                      <div className="flex items-center gap-1 break-all">
                        <Phone className="h-4 w-4 flex-shrink-0" />
                        <span className="break-all">{royalData.customer.phone}</span>
                      </div>
                      <div className="flex items-start gap-1">
                        <MapPin className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <span className="break-words">{royalData.customer.address}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-center sm:text-right flex-shrink-0">
                    
                    
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-4 md:p-6">
                <div className="mb-4">
                  {/* Desktop & Tablet: 3 kolom sejajar */}
                  <div className="hidden sm:grid sm:grid-cols-3 gap-3 md:gap-4">
                    <div className="p-3 md:p-4 rounded-lg bg-blue-50 dark:bg-blue-950">
                      <div className="text-xs md:text-sm text-muted-foreground mb-1">Total Nilai Kredit</div>
                      <div className="text-lg md:text-2xl font-bold text-blue-900 dark:text-blue-300 break-all">
                        {formatRupiah(royalData.totalAmount)}
                      </div>
                    </div>
                    <div className="p-3 md:p-4 rounded-lg bg-green-50 dark:bg-green-950">
                      <div className="text-xs md:text-sm text-muted-foreground mb-1">Kredit Aktif</div>
                      <div className="text-lg md:text-2xl font-bold text-green-900 dark:text-green-300">
                        {royalData.activeCredits}
                      </div>
                    </div>
                    <div className="p-3 md:p-4 rounded-lg bg-gray-50 dark:bg-gray-900">
                      <div className="text-xs md:text-sm text-muted-foreground mb-1">Kredit Selesai</div>
                      <div className="text-lg md:text-2xl font-bold text-gray-900 dark:text-gray-300">
                        {royalData.completedCredits}
                      </div>
                    </div>
                  </div>

                  {/* Mobile: Total di atas, Aktif & Selesai sejajar di bawah */}
                  <div className="sm:hidden space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950">
                      <div className="text-xs text-muted-foreground mb-1">Total Nilai Kredit</div>
                      <div className="text-lg font-bold text-blue-900 dark:text-blue-300 break-all">
                        {formatRupiah(royalData.totalAmount)}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950">
                        <div className="text-xs text-muted-foreground mb-1">Kredit Aktif</div>
                        <div className="text-lg font-bold text-green-900 dark:text-green-300">
                          {royalData.activeCredits}
                        </div>
                      </div>
                      <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-900">
                        <div className="text-xs text-muted-foreground mb-1">Kredit Selesai</div>
                        <div className="text-lg font-bold text-gray-900 dark:text-gray-300">
                          {royalData.completedCredits}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <Collapsible open={isExpanded} onOpenChange={() => toggleCard(royalData.customer.id)}>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full flex items-center justify-between">
                      <span className="font-semibold">Riwayat Kredit ({royalData.credits.length})</span>
                      {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  
                  <CollapsibleContent className="mt-3 space-y-3">
                    {royalData.credits.map(credit => <div key={credit.id} className="p-3 md:p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors">
                        <div className="space-y-3">
                          {/* Row 1: No Aplikasi & Status */}
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="text-xs text-muted-foreground mb-1">No. Aplikasi</div>
                              <div className="font-medium text-sm md:text-base break-all">{credit.application_number}</div>
                            </div>
                            <div className="flex-shrink-0">
                              {getStatusBadge(credit.status)}
                            </div>
                          </div>
                          
                          {/* Row 2: Tanggal */}
                          <div>
                            <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              Tanggal Pengajuan
                            </div>
                            <div className="font-medium text-sm md:text-base">
                              {format(new Date(credit.application_date), "dd MMMM yyyy", {
                          locale: id
                        })}
                            </div>
                          </div>
                          
                          {/* Row 3: Nilai & Angsuran */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Nilai Disetujui</div>
                              <div className="font-semibold text-sm md:text-base text-blue-900 dark:text-blue-300 break-all">
                                {formatRupiah(credit.amount_approved || credit.amount_requested)}
                              </div>
                            </div>
                            
                            <div>
                              <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                                <DollarSign className="h-3 w-3" />
                                Angsuran/Bulan
                              </div>
                              <div className="font-semibold text-sm md:text-base text-green-900 dark:text-green-300 break-all">
                                {formatRupiah(credit.installment_amount)}
                              </div>
                            </div>
                          </div>
                          
                          {/* Row 4: Tenor */}
                          <div className="pt-2 border-t border-border">
                            <div className="flex items-center gap-2 text-xs md:text-sm">
                              <span className="text-muted-foreground">Tenor:</span>
                              <span className="font-medium">{credit.tenor_months} bulan</span>
                            </div>
                          </div>
                        </div>
                      </div>)}
                  </CollapsibleContent>
                </Collapsible>
              </CardContent>
            </Card>;
      })}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground">
            Menampilkan {startIndex + 1}-{Math.min(endIndex, filteredCustomers.length)} dari {filteredCustomers.length} nasabah
          </div>
          
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <Button variant="outline" size="sm" onClick={() => goToPage(1)} disabled={currentPage === 1}>
              Pertama
            </Button>
            <Button variant="outline" size="sm" onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1}>
              Sebelumnya
            </Button>
            
            {/* Page numbers */}
            <div className="flex items-center gap-1">
              {Array.from({
            length: Math.min(5, totalPages)
          }, (_, i) => {
            let pageNum;
            if (totalPages <= 5) {
              pageNum = i + 1;
            } else if (currentPage <= 3) {
              pageNum = i + 1;
            } else if (currentPage >= totalPages - 2) {
              pageNum = totalPages - 4 + i;
            } else {
              pageNum = currentPage - 2 + i;
            }
            return <Button key={pageNum} variant={currentPage === pageNum ? "default" : "outline"} size="sm" onClick={() => goToPage(pageNum)} className="min-w-[40px]">
                    {pageNum}
                  </Button>;
          })}
            </div>
            
            <Button variant="outline" size="sm" onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages}>
              Selanjutnya
            </Button>
            <Button variant="outline" size="sm" onClick={() => goToPage(totalPages)} disabled={currentPage === totalPages}>
              Terakhir
            </Button>
          </div>
        </div>}
    </div>;
}