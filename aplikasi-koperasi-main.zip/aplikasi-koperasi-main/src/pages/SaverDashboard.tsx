import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSaverAuth } from "@/contexts/SaverAuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TierBadge } from "@/components/SaverDetailDialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDateWIB, formatRupiah, getNowInWIB } from "@/lib/utils";
import {
  User,
  Phone,
  MapPin,
  Calendar,
  CreditCard,
  Wallet,
  Briefcase,
  Award,
  Medal,
  Trophy,
  ArrowUpCircle,
  ArrowDownCircle,
  Sparkles,
  TrendingUp,
  Banknote,
  Building2,
  ChevronLeft,
  ChevronRight,
  LogOut,
  RefreshCw,
  AlertTriangle,
  KeyRound,
  MessageCircle,
  Plus,
  Minus,
  ArrowLeftRight,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import SaverWithdrawalConfirmationPopup from "@/components/SaverWithdrawalConfirmationPopup";
import SaverSelfDepositDialog from "@/components/SaverSelfDepositDialog";
import SaverSelfWithdrawalDialog from "@/components/SaverSelfWithdrawalDialog";
import SaverTransferDialog from "@/components/SaverTransferDialog";
import { generateWhatsAppLink } from "@/lib/whatsappHelper";

interface DepositTransaction {
  id: string;
  amount: number;
  deposit_date: string;
  transaction_type: string;
  remaining_balance: number;
  is_eligible_for_interest: boolean;
  payment_method: string | null;
  payment_details: string | null;
  notes: string | null;
  created_at: string;
  created_by: string | null;
  created_by_member?: { full_name: string } | null;
  approved_by: string | null;
  approved_by_member?: { full_name: string } | null;
  status: string | null;
  transaction_number: string | null;
}

interface InterestTransaction {
  id: string;
  amount: number;
  interest_rate: number;
  tier_level: string;
  principal_amount: number;
  period_month: string;
  payment_date: string;
  created_at: string;
}

interface WithdrawalTransaction {
  id: string;
  amount: number;
  withdrawal_date: string;
  status: string;
  notes: string | null;
  payment_method: string | null;
  payment_details: string | null;
  created_at: string;
  processed_by: string | null;
  processed_by_member?: { full_name: string } | null;
  transaction_number: string | null;
}

const ITEMS_PER_PAGE = 5;

export default function SaverDashboard() {
  const navigate = useNavigate();
  const { saver, logout, isAuthenticated } = useSaverAuth();
  const { businessName, logoUrl, businessPhone } = useBusinessInfo();
  
  const [deposits, setDeposits] = useState<DepositTransaction[]>([]);
  const [interests, setInterests] = useState<InterestTransaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalTransaction[]>([]);
  const [loadingTransactions, setLoadingTransactions] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  
  const [depositsPage, setDepositsPage] = useState(1);
  const [interestsPage, setInterestsPage] = useState(1);
  const [withdrawalsPage, setWithdrawalsPage] = useState(1);
  
  const currentDate = getNowInWIB();
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());

  // Dialog states
  const [depositDialogOpen, setDepositDialogOpen] = useState(false);
  const [withdrawalDialogOpen, setWithdrawalDialogOpen] = useState(false);
  const [transferDialogOpen, setTransferDialogOpen] = useState(false);

  const [saverDetails, setSaverDetails] = useState<{
    balance: number;
    deposit_balance: number;
    interest_balance: number;
    tier_level: string;
    has_pin: boolean;
  } | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/auth");
    }
  }, [isAuthenticated, navigate]);

  // Load saver details and transactions
  useEffect(() => {
    if (saver?.id) {
      loadSaverDetails();
      loadTransactions();
    }
  }, [saver?.id, selectedMonth, selectedYear]);

  const loadSaverDetails = async () => {
    if (!saver?.id) return;
    
    const { data, error } = await supabase
      .from("savers")
      .select("balance, deposit_balance, interest_balance, tier_level, pin_hash")
      .eq("id", saver.id)
      .single();

    if (!error && data) {
      setSaverDetails({
        balance: data.balance || 0,
        deposit_balance: data.deposit_balance || 0,
        interest_balance: data.interest_balance || 0,
        tier_level: data.tier_level || "silver",
        has_pin: !!data.pin_hash,
      });
    }
  };

  const loadTransactions = async () => {
    if (!saver?.id) return;
    setLoadingTransactions(true);

    const startDate = new Date(selectedYear, selectedMonth - 1, 1);
    const endDate = new Date(selectedYear, selectedMonth, 0, 23, 59, 59);

    try {
      const [depositsRes, interestsRes, withdrawalsRes] = await Promise.all([
        supabase
          .from("saver_deposits")
          .select("*, created_by_member:members!saver_deposits_created_by_fkey(full_name), approved_by_member:members!saver_deposits_approved_by_fkey(full_name)")
          .eq("saver_id", saver.id)
          .gte("deposit_date", startDate.toISOString())
          .lte("deposit_date", endDate.toISOString())
          .order("deposit_date", { ascending: false }),
        supabase
          .from("saver_interest_transactions")
          .select("*")
          .eq("saver_id", saver.id)
          .gte("payment_date", startDate.toISOString())
          .lte("payment_date", endDate.toISOString())
          .order("payment_date", { ascending: false }),
        supabase
          .from("saver_withdrawals")
          .select("*, processed_by_member:members!saver_withdrawals_processed_by_fkey(full_name)")
          .eq("saver_id", saver.id)
          .gte("withdrawal_date", startDate.toISOString())
          .lte("withdrawal_date", endDate.toISOString())
          .order("withdrawal_date", { ascending: false })
          .order("created_at", { ascending: false }),
      ]);

      setDeposits(depositsRes.data || []);
      setInterests(interestsRes.data || []);
      setWithdrawals(withdrawalsRes.data || []);
    } catch (error) {
      console.error("Error loading transactions:", error);
    } finally {
      setLoadingTransactions(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadSaverDetails(), loadTransactions()]);
    toast.success("Data diperbarui");
    setRefreshing(false);
  };

  const handleLogout = async () => {
    await logout();
    toast.success("Berhasil keluar");
    // CRITICAL: Hard redirect to auth page to ensure all cache is cleared
    window.location.href = '/auth';
  };

  const handleChatAdmin = () => {
    if (!businessPhone) {
      toast.error("Nomor WhatsApp admin belum dikonfigurasi");
      return;
    }
    const message = `Halo ${businessName}, saya ${saver?.full_name || 'debitur'} (No. Rek: ${saver?.account_number || '-'}) ingin menghubungi admin.`;
    const whatsappUrl = generateWhatsAppLink(businessPhone, message, 'app');
    window.location.href = whatsappUrl;
  };

  const handleTransactionSuccess = () => {
    loadSaverDetails();
    loadTransactions();
  };

  const getTierIcon = (tier: string) => {
    switch (tier?.toLowerCase()) {
      case "gold":
        return <Medal className="h-4 w-4 text-yellow-500" />;
      case "platinum":
        return <Trophy className="h-4 w-4 text-purple-500" />;
      default:
        return <Award className="h-4 w-4 text-gray-400" />;
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier?.toLowerCase()) {
      case "gold":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "platinum":
        return "bg-purple-100 text-purple-800 border-purple-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  // Get registration date from saver
  const registrationDate = saver ? new Date(saver.created_at) : currentDate;
  const registrationYear = registrationDate.getFullYear();
  const registrationMonth = registrationDate.getMonth() + 1;

  const allMonths = [
    { value: 1, label: "Januari" },
    { value: 2, label: "Februari" },
    { value: 3, label: "Maret" },
    { value: 4, label: "April" },
    { value: 5, label: "Mei" },
    { value: 6, label: "Juni" },
    { value: 7, label: "Juli" },
    { value: 8, label: "Agustus" },
    { value: 9, label: "September" },
    { value: 10, label: "Oktober" },
    { value: 11, label: "November" },
    { value: 12, label: "Desember" },
  ];

  // Filter months based on selected year and registration date
  const months = allMonths.filter((m) => {
    // If selected year is before registration year, no months available
    if (selectedYear < registrationYear) return false;
    // If selected year is the registration year, only show months from registration onwards
    if (selectedYear === registrationYear) return m.value >= registrationMonth;
    // If selected year is current year, only show months up to current month
    if (selectedYear === currentDate.getFullYear()) return m.value <= currentDate.getMonth() + 1;
    // Otherwise show all months
    return true;
  });

  // Generate years from registration year to current year
  const years = Array.from(
    { length: currentDate.getFullYear() - registrationYear + 1 },
    (_, i) => currentDate.getFullYear() - i
  ).filter((year) => year >= registrationYear);

  // Auto-adjust month when year changes and selected month becomes invalid
  useEffect(() => {
    const validMonths = allMonths.filter((m) => {
      if (selectedYear < registrationYear) return false;
      if (selectedYear === registrationYear) return m.value >= registrationMonth;
      if (selectedYear === currentDate.getFullYear()) return m.value <= currentDate.getMonth() + 1;
      return true;
    });
    
    if (validMonths.length > 0 && !validMonths.some((m) => m.value === selectedMonth)) {
      // Set to the latest valid month
      setSelectedMonth(validMonths[validMonths.length - 1].value);
    }
  }, [selectedYear, registrationYear, registrationMonth]);

  const totalDepositsPages = Math.ceil(deposits.length / ITEMS_PER_PAGE);
  const totalInterestsPages = Math.ceil(interests.length / ITEMS_PER_PAGE);
  const totalWithdrawalsPages = Math.ceil(withdrawals.length / ITEMS_PER_PAGE);

  if (!saver) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b-2 border-primary/30 bg-card sticky top-0 z-10 shadow-lg pt-safe-top">
        <div className="container mx-auto px-4 min-h-[56px] flex items-center justify-between gap-2 relative">
          {/* Left - Profile Button */}
          <Button
            variant="outline"
            size="sm"
            className="min-h-[44px] gap-2"
            onClick={() => navigate("/saver-profile")}
          >
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Profil</span>
          </Button>

          {/* Center - Business Logo & Name */}
          <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-2 sm:gap-3">
            {logoUrl ? (
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-md overflow-hidden flex-shrink-0 animate-logo-container">
                <img
                  key={logoUrl}
                  src={logoUrl}
                  alt={businessName || "Logo"}
                  className="w-full h-full object-cover animate-logo"
                />
              </div>
            ) : (
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-primary rounded-md flex items-center justify-center flex-shrink-0">
                <Building2 className="w-4 h-4 sm:w-5 sm:h-5 text-primary-foreground" />
              </div>
            )}
            <span className="text-base sm:text-xl font-semibold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent truncate max-w-[160px] sm:max-w-none font-mono">
              {businessName || "Mitradana"}
            </span>
          </div>

          {/* Right - Action Buttons */}
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="min-h-[44px] min-w-[44px]"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
            </Button>

            <Button variant="ghost" size="sm" className="min-h-[44px] min-w-[44px]" onClick={handleLogout}>
              <LogOut className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Keluar</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Page Title */}
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Dashboard Debitur</h1>
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2 bg-gradient-to-r from-green-400 via-emerald-300 to-green-500 hover:from-green-500 hover:via-emerald-400 hover:to-green-600 border-green-300 shadow-md animate-shimmer bg-[length:200%_100%] dark:from-green-600 dark:via-emerald-500 dark:to-green-700"
            onClick={handleChatAdmin}
          >
            <MessageCircle className="h-4 w-4 text-white" />
            <span className="text-xs font-bold text-white drop-shadow-sm">Chat Admin</span>
          </Button>
        </div>

        {/* PIN Not Set Warning */}
        {saverDetails && saverDetails.has_pin === false && (
          <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-700 rounded-lg animate-fade-in">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-amber-800 dark:text-amber-200">
                  PIN Belum Diatur
                </p>
                <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">
                  Anda belum mengatur PIN. PIN diperlukan untuk mengkonfirmasi penarikan saldo.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3 border-amber-400 text-amber-700 hover:bg-amber-100 dark:border-amber-600 dark:text-amber-300 dark:hover:bg-amber-900/50"
                  onClick={() => navigate("/saver-profile")}
                >
                  <KeyRound className="h-4 w-4 mr-2" />
                  Atur PIN Sekarang
                </Button>
              </div>
            </div>
          </div>
        )}
        {/* Profile Card */}
        <Card className="animate-fade-in">
          <CardContent className="pt-6">
            <div className="flex gap-6 items-center">
              {/* Photo */}
              <div className="flex-shrink-0">
                <div className="w-24 h-24 rounded-lg overflow-hidden border-2 border-border">
                  {saver.photo_url ? (
                    <img
                      src={saver.photo_url}
                      alt={saver.full_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-muted flex items-center justify-center">
                      <span className="text-2xl font-bold text-muted-foreground">
                        {saver.full_name.charAt(0)}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Info Grid */}
              <div className="flex-1 space-y-4">
                {/* Name & Badge - Same Row */}
                <div>
                  <p className="text-sm text-muted-foreground">Nama Lengkap</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold">{saver.full_name}</p>
                    <TierBadge tier={saverDetails?.tier_level || "silver"} size="sm" />
                  </div>
                </div>
                {/* Account Number */}
                <div>
                  <p className="text-sm text-muted-foreground">No. Rekening</p>
                  <p className="font-semibold">{saver.account_number.replace(/(\d{4})(?=\d)/g, '$1 ')}</p>
                </div>
                {/* Registration Date */}
                <div>
                  <p className="text-sm text-muted-foreground">Terdaftar Sejak</p>
                  <p className="font-semibold flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                    {formatDateWIB(saver.created_at)}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Balance Card */}
        <Card className="bg-gradient-to-r from-primary/10 to-primary/5">
          <CardContent className="pt-6">
            <div className="text-center mb-4">
              <p className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                <Wallet className="h-4 w-4" />
                Total Saldo
              </p>
              <p className="text-3xl font-bold text-primary mt-1">
                {formatRupiah(saverDetails?.balance || 0)}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div className="text-center">
                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                  <ArrowUpCircle className="h-3 w-3 text-green-600" />
                  Saldo Deposit
                </p>
                <p className="text-lg font-semibold text-green-600">
                  {formatRupiah(saverDetails?.deposit_balance || 0)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                  <Sparkles className="h-3 w-3 text-amber-500" />
                  Saldo Bunga
                </p>
                <p className="text-lg font-semibold text-amber-600">
                  {formatRupiah(saverDetails?.interest_balance || 0)}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-3 gap-2 pt-4 mt-4 border-t">
              <Button
                variant="outline"
                className="flex-col h-auto py-3 gap-1 bg-green-50 hover:bg-green-100 border-green-200 dark:bg-green-950/20 dark:hover:bg-green-950/30 dark:border-green-800"
                onClick={() => setDepositDialogOpen(true)}
              >
                <Plus className="h-5 w-5 text-green-600" />
                <span className="text-xs font-medium text-green-700 dark:text-green-300">Deposit</span>
              </Button>
              <Button
                variant="outline"
                className="flex-col h-auto py-3 gap-1 bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-950/20 dark:hover:bg-red-950/30 dark:border-red-800"
                onClick={() => setWithdrawalDialogOpen(true)}
              >
                <Minus className="h-5 w-5 text-red-600" />
                <span className="text-xs font-medium text-red-700 dark:text-red-300">Penarikan</span>
              </Button>
              <Button
                variant="outline"
                className="flex-col h-auto py-3 gap-1 bg-blue-50 hover:bg-blue-100 border-blue-200 dark:bg-blue-950/20 dark:hover:bg-blue-950/30 dark:border-blue-800"
                onClick={() => setTransferDialogOpen(true)}
              >
                <ArrowLeftRight className="h-5 w-5 text-blue-600" />
                <span className="text-xs font-medium text-blue-700 dark:text-blue-300">Transfer</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-2 p-3 bg-muted/50 rounded-lg text-center">
          <div>
            <p className="text-xs text-muted-foreground">Total Deposit</p>
            <p className="text-sm font-semibold text-green-600">
              {formatRupiah(deposits.filter((d) => d.status === 'approved').reduce((sum, d) => sum + d.amount, 0))}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Bunga</p>
            <p className="text-sm font-semibold text-amber-600">
              {formatRupiah(interests.reduce((sum, i) => sum + i.amount, 0))}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Penarikan</p>
            <p className="text-sm font-semibold text-red-600">
              {formatRupiah(withdrawals.filter((w) => w.status === "completed").reduce((sum, w) => sum + w.amount, 0))}
            </p>
          </div>
        </div>

        {/* Transaction History Card */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-base">Riwayat Transaksi</CardTitle>
              <div className="flex items-center gap-2">
                <Select
                  value={selectedMonth.toString()}
                  onValueChange={(v) => setSelectedMonth(parseInt(v))}
                >
                  <SelectTrigger className="w-[110px] h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {months.map((m) => (
                      <SelectItem key={m.value} value={m.value.toString()}>
                        {m.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select
                  value={selectedYear.toString()}
                  onValueChange={(v) => setSelectedYear(parseInt(v))}
                >
                  <SelectTrigger className="w-[80px] h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="deposits" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="deposits" className="text-xs">
                  <ArrowUpCircle className="h-3 w-3 mr-1" />
                  Deposit ({deposits.length})
                </TabsTrigger>
                <TabsTrigger value="interest" className="text-xs">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Bunga ({interests.length})
                </TabsTrigger>
                <TabsTrigger value="withdrawals" className="text-xs">
                  <ArrowDownCircle className="h-3 w-3 mr-1" />
                  Penarikan ({withdrawals.length})
                </TabsTrigger>
              </TabsList>


              <TabsContent value="deposits" className="mt-4">
                {loadingTransactions ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Memuat...</p>
                ) : deposits.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Belum ada riwayat deposit</p>
                ) : (
                  <>
                    <div className="space-y-2">
                      {deposits.slice((depositsPage - 1) * ITEMS_PER_PAGE, depositsPage * ITEMS_PER_PAGE).map((deposit) => (
                        <div key={deposit.id} className={`p-3 rounded-lg border ${
                          deposit.status === "rejected" 
                            ? "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800" 
                            : deposit.status === "pending"
                              ? "bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700"
                              : "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800"
                        }`}>
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className={`font-medium ${
                                  deposit.status === "rejected" 
                                    ? "text-red-700 dark:text-red-300 line-through" 
                                    : deposit.status === "pending"
                                      ? "text-amber-700 dark:text-amber-300"
                                      : "text-green-700 dark:text-green-300"
                                }`}>+{formatRupiah(deposit.amount)}</p>
                                <Badge variant="outline" className={`text-xs ${
                                  deposit.status === "rejected" 
                                    ? "bg-red-100 dark:bg-red-900/50 border-red-300" 
                                    : deposit.status === "pending"
                                      ? "bg-amber-100 dark:bg-amber-900/50 border-amber-300"
                                      : "bg-green-100 dark:bg-green-900/50 border-green-300"
                                }`}>
                                  {deposit.transaction_type === "topup" ? "Top Up" : "Deposit"}
                                </Badge>
                              </div>
                              {deposit.transaction_number && (
                                <p className="text-xs font-mono text-primary">
                                  #{deposit.transaction_number}
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground">
                                {formatDateWIB(deposit.deposit_date)}
                              </p>
                              <div className="flex items-center gap-3 flex-wrap text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  {deposit.payment_method === "transfer" ? (
                                    <Building2 className="h-3 w-3 text-blue-500" />
                                  ) : (
                                    <Banknote className="h-3 w-3 text-green-600" />
                                  )}
                                  {deposit.payment_method === "transfer" ? "Transfer" : "Tunai"}
                                </span>
                                {(deposit.approved_by_member?.full_name || deposit.created_by_member?.full_name) && (
                                  <span className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    {deposit.approved_by_member?.full_name || deposit.created_by_member?.full_name}
                                  </span>
                                )}
                              </div>
                              {deposit.payment_details && (
                                <p className="text-xs text-muted-foreground italic">
                                  Detail: {deposit.payment_details}
                                </p>
                              )}
                              {deposit.notes && (
                                <p className="text-xs text-muted-foreground italic">
                                  Ket: {deposit.notes}
                                </p>
                              )}
                            </div>
                            <Badge variant="outline" className={
                              deposit.status === "rejected" 
                                ? "text-xs border-red-500 text-red-600" 
                                : deposit.status === "approved" || deposit.is_eligible_for_interest 
                                  ? "text-xs border-green-500 text-green-600" 
                                  : "text-xs border-yellow-500 text-yellow-600"
                            }>
                              {deposit.status === "rejected" ? "Ditolak" : deposit.status === "approved" ? "Disetujui" : deposit.status === "pending" ? "Pending" : deposit.is_eligible_for_interest ? "Eligible" : "Pending"}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                    {totalDepositsPages > 1 && (
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setDepositsPage((p) => Math.max(1, p - 1))} disabled={depositsPage === 1}>
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <span className="text-sm">
                          {depositsPage} / {totalDepositsPages}
                        </span>
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setDepositsPage((p) => Math.min(totalDepositsPages, p + 1))} disabled={depositsPage === totalDepositsPages}>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </TabsContent>

              <TabsContent value="interest" className="mt-4">
                {loadingTransactions ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Memuat...</p>
                ) : interests.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Belum ada riwayat bunga</p>
                ) : (
                  <>
                    <div className="space-y-2">
                      {interests.slice((interestsPage - 1) * ITEMS_PER_PAGE, interestsPage * ITEMS_PER_PAGE).map((interest) => (
                        <div key={interest.id} className="flex items-center justify-between p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                          <div className="flex-1">
                            <p className="font-medium text-amber-700 dark:text-amber-300">+{formatRupiah(interest.amount)}</p>
                            <p className="text-xs text-muted-foreground">
                              {formatDateWIB(interest.payment_date)} • Bunga {interest.interest_rate}%
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Pokok: {formatRupiah(interest.principal_amount)}
                            </p>
                          </div>
                          <Badge variant="outline" className="text-xs capitalize">
                            {interest.tier_level}
                          </Badge>
                        </div>
                      ))}
                    </div>
                    {totalInterestsPages > 1 && (
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setInterestsPage((p) => Math.max(1, p - 1))} disabled={interestsPage === 1}>
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <span className="text-sm">
                          {interestsPage} / {totalInterestsPages}
                        </span>
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setInterestsPage((p) => Math.min(totalInterestsPages, p + 1))} disabled={interestsPage === totalInterestsPages}>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </TabsContent>

              <TabsContent value="withdrawals" className="mt-4">
                {loadingTransactions ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Memuat...</p>
                ) : withdrawals.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Belum ada riwayat penarikan</p>
                ) : (
                  <>
                    <div className="space-y-2">
                      {withdrawals.slice((withdrawalsPage - 1) * ITEMS_PER_PAGE, withdrawalsPage * ITEMS_PER_PAGE).map((withdrawal) => (
                        <div key={withdrawal.id} className={`p-3 rounded-lg border ${
                          withdrawal.status === "rejected"
                            ? "bg-gray-50 dark:bg-gray-950/20 border-gray-300 dark:border-gray-700"
                            : withdrawal.status === "pending"
                              ? "bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700"
                              : "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800"
                        }`}>
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className={`font-medium ${
                                  withdrawal.status === "rejected" 
                                    ? "text-gray-500 line-through" 
                                    : withdrawal.status === "pending"
                                      ? "text-amber-700 dark:text-amber-300"
                                      : "text-red-700 dark:text-red-300"
                                }`}>-{formatRupiah(withdrawal.amount)}</p>
                                <Badge variant="outline" className={`text-xs ${
                                  withdrawal.status === "rejected" 
                                    ? "bg-gray-100 dark:bg-gray-900/50 border-gray-300" 
                                    : withdrawal.status === "pending"
                                      ? "bg-amber-100 dark:bg-amber-900/50 border-amber-300"
                                      : "bg-red-100 dark:bg-red-900/50 border-red-300"
                                }`}>
                                  Penarikan
                                </Badge>
                              </div>
                              {withdrawal.transaction_number && (
                                <p className="text-xs font-mono text-primary">
                                  #{withdrawal.transaction_number}
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground">
                                {formatDateWIB(withdrawal.withdrawal_date)}
                              </p>
                              <div className="flex items-center gap-3 flex-wrap text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  {withdrawal.payment_method === "transfer" ? (
                                    <Building2 className="h-3 w-3 text-blue-500" />
                                  ) : (
                                    <Banknote className="h-3 w-3 text-green-600" />
                                  )}
                                  {withdrawal.payment_method === "transfer" ? "Transfer" : "Tunai"}
                                </span>
                                {withdrawal.processed_by_member?.full_name && (
                                  <span className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    {withdrawal.processed_by_member.full_name}
                                  </span>
                                )}
                              </div>
                              {withdrawal.payment_details && (
                                <p className="text-xs text-muted-foreground italic">
                                  Detail: {withdrawal.payment_details}
                                </p>
                              )}
                              {withdrawal.notes && (
                                <p className="text-xs text-muted-foreground italic">
                                  Ket: {withdrawal.notes}
                                </p>
                              )}
                            </div>
                            <Badge
                              variant="outline"
                              className={
                                withdrawal.status === "completed"
                                  ? "text-xs border-green-500 text-green-600"
                                  : withdrawal.status === "pending"
                                  ? "text-xs border-yellow-500 text-yellow-600"
                                  : withdrawal.status === "rejected"
                                  ? "text-xs border-red-500 text-red-600"
                                  : "text-xs border-gray-500 text-gray-600"
                              }
                            >
                              {withdrawal.status === "completed" ? "Selesai" : withdrawal.status === "pending" ? "Pending" : withdrawal.status === "rejected" ? "Ditolak" : withdrawal.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                    {totalWithdrawalsPages > 1 && (
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setWithdrawalsPage((p) => Math.max(1, p - 1))} disabled={withdrawalsPage === 1}>
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <span className="text-sm">
                          {withdrawalsPage} / {totalWithdrawalsPages}
                        </span>
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setWithdrawalsPage((p) => Math.min(totalWithdrawalsPages, p + 1))} disabled={withdrawalsPage === totalWithdrawalsPages}>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>

      {/* Withdrawal Confirmation Popup */}
      {saver?.id && (
        <SaverWithdrawalConfirmationPopup
          saverId={saver.id}
          onConfirm={handleTransactionSuccess}
        />
      )}

      {/* Self Deposit Dialog */}
      {saver?.id && saverDetails && (
        <SaverSelfDepositDialog
          open={depositDialogOpen}
          onOpenChange={setDepositDialogOpen}
          saverId={saver.id}
          saverName={saver.full_name}
          hasPin={saverDetails.has_pin}
          onSuccess={handleTransactionSuccess}
        />
      )}

      {/* Self Withdrawal Dialog */}
      {saver?.id && saverDetails && (
        <SaverSelfWithdrawalDialog
          open={withdrawalDialogOpen}
          onOpenChange={setWithdrawalDialogOpen}
          saverId={saver.id}
          saverName={saver.full_name}
          currentBalance={saverDetails.balance}
          hasPin={saverDetails.has_pin}
          onSuccess={handleTransactionSuccess}
        />
      )}

      {/* Transfer Dialog */}
      {saver?.id && saverDetails && (
        <SaverTransferDialog
          open={transferDialogOpen}
          onOpenChange={setTransferDialogOpen}
          saverId={saver.id}
          saverName={saver.full_name}
          saverAccountNumber={saver.account_number || ""}
          currentBalance={saverDetails.deposit_balance}
          hasPin={saverDetails.has_pin}
          onSuccess={handleTransactionSuccess}
        />
      )}
    </div>
  );
}
