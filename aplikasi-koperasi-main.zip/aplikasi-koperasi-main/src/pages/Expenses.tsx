import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useUserRole } from "@/hooks/useUserRole";
import { Plus, Receipt, Calendar, User, DollarSign, CheckCircle, Clock, Search, Paperclip, Zap, Car, UtensilsCrossed, Wifi, Wrench, LucideIcon, Monitor, Building2, Pencil, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileDataCard } from "@/components/MobileDataCard";
import { formatDateWIB } from "@/lib/utils";
import { toast } from "sonner";
import { SupercodeVerificationDialog } from "@/components/SupercodeVerificationDialog";
import { EditExpenseDialog } from "@/components/EditExpenseDialog";

interface Expense {
  id: string;
  expense_date: string;
  pic_id: string | null;
  pic_name: string;
  description: string;
  amount: number;
  category: string;
  status: string;
  created_by: string | null;
  created_by_name: string;
  verified_by: string | null;
  verified_by_name: string | null;
  verified_at: string | null;
  created_at: string;
  updated_at: string;
}

// Category configuration with icons and colors
const EXPENSE_CATEGORIES: { value: string; label: string; icon: LucideIcon; colorClass: string }[] = [
  { value: 'atk', label: 'ATK (Alat Tulis)', icon: Paperclip, colorClass: 'bg-blue-100 dark:bg-blue-900/30' },
  { value: 'peralatan', label: 'Peralatan/Komputer', icon: Monitor, colorClass: 'bg-cyan-100 dark:bg-cyan-900/30' },
  { value: 'sewa', label: 'Sewa/Rental', icon: Building2, colorClass: 'bg-indigo-100 dark:bg-indigo-900/30' },
  { value: 'listrik', label: 'Listrik', icon: Zap, colorClass: 'bg-yellow-100 dark:bg-yellow-900/30' },
  { value: 'transport', label: 'Transport', icon: Car, colorClass: 'bg-green-100 dark:bg-green-900/30' },
  { value: 'konsumsi', label: 'Konsumsi/Makan', icon: UtensilsCrossed, colorClass: 'bg-orange-100 dark:bg-orange-900/30' },
  { value: 'internet', label: 'Internet/Telekomunikasi', icon: Wifi, colorClass: 'bg-purple-100 dark:bg-purple-900/30' },
  { value: 'perawatan', label: 'Perawatan/Maintenance', icon: Wrench, colorClass: 'bg-gray-100 dark:bg-gray-900/30' },
  { value: 'other', label: 'Lainnya', icon: Sparkles, colorClass: 'bg-pink-100 dark:bg-pink-900/30' },
];

const getCategoryConfig = (category: string) => {
  return EXPENSE_CATEGORIES.find(c => c.value === category) || EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
};

interface Member {
  id: string;
  full_name: string;
  position: string;
}

const ITEMS_PER_PAGE = 15;

export default function Expenses() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [members, setMembers] = useState<Member[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [pendingEditExpense, setPendingEditExpense] = useState<Expense | null>(null);
  const [isSupercodeDialogOpen, setIsSupercodeDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Helper to format date for display (DD/MM/YYYY)
  const formatDateDisplay = (isoDate: string) => {
    if (!isoDate) return '';
    const [year, month, day] = isoDate.split('-');
    return `${day}/${month}/${year}`;
  };

  // Helper to parse display date (DD/MM/YYYY) to ISO (YYYY-MM-DD)
  const parseDisplayDate = (displayDate: string) => {
    const cleanDate = displayDate.replace(/\D/g, '');
    if (cleanDate.length === 8) {
      const day = cleanDate.substring(0, 2);
      const month = cleanDate.substring(2, 4);
      const year = cleanDate.substring(4, 8);
      return `${year}-${month}-${day}`;
    }
    return '';
  };

  // Auto separator for date input
  const handleDateInputChange = (value: string) => {
    // Remove all non-digits
    let digits = value.replace(/\D/g, '');
    
    // Limit to 8 digits
    digits = digits.substring(0, 8);
    
    // Add separators
    let formatted = '';
    if (digits.length > 0) {
      formatted = digits.substring(0, 2);
    }
    if (digits.length > 2) {
      formatted += '/' + digits.substring(2, 4);
    }
    if (digits.length > 4) {
      formatted += '/' + digits.substring(4, 8);
    }
    
    setDateDisplayValue(formatted);
    
    // Update formData if complete date
    if (digits.length === 8) {
      const isoDate = parseDisplayDate(formatted);
      setFormData(prev => ({ ...prev, expense_date: isoDate }));
    }
  };

  // Form state
  const today = new Date().toISOString().split('T')[0];
  const [dateDisplayValue, setDateDisplayValue] = useState(formatDateDisplay(today));
  const [formData, setFormData] = useState({
    expense_date: today,
    pic_id: "",
    category: "other",
    description: "",
    amount: ""
  });

  const { isOwner, isAdmin, isKasir, loading: roleLoading } = useUserRole();
  const isMobile = useIsMobile();
  const canVerify = isOwner || isAdmin;

  useEffect(() => {
    loadExpenses();
    loadMembers();

    // Set up realtime subscription
    const channel = supabase
      .channel('expenses-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'expenses'
      }, () => {
        loadExpenses();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentPage, searchQuery]);

  // Reset to page 1 when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  const loadExpenses = async () => {
    setIsLoading(true);
    try {
      // Build base query
      let countQuery = supabase
        .from('expenses')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'verified');

      let dataQuery = supabase
        .from('expenses')
        .select('*')
        .eq('status', 'verified');

      // Apply search filter if query exists
      if (searchQuery.trim()) {
        const search = `%${searchQuery.trim()}%`;
        countQuery = countQuery.or(`description.ilike.${search},pic_name.ilike.${search}`);
        dataQuery = dataQuery.or(`description.ilike.${search},pic_name.ilike.${search}`);
      }

      // Get total count
      const { count, error: countError } = await countQuery;
      if (countError) throw countError;
      setTotalCount(count || 0);

      // Get paginated data
      const from = (currentPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;

      const { data, error } = await dataQuery
        .order('expense_date', { ascending: false })
        .range(from, to);

      if (error) throw error;
      setExpenses(data || []);
    } catch (error: any) {
      console.error('Error loading expenses:', error);
      toast.error('Gagal memuat data pengeluaran');
    } finally {
      setIsLoading(false);
    }
  };

  const loadMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('members')
        .select('id, full_name, position')
        .eq('is_active', true)
        .order('full_name');

      if (error) throw error;
      setMembers(data || []);
    } catch (error: any) {
      console.error('Error loading members:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    // Validation
    if (!formData.expense_date || !formData.pic_id || !formData.description || !formData.amount) {
      toast.error('Semua field harus diisi');
      return;
    }

    const amount = parseFloat(formData.amount.replace(/[^\d]/g, ''));
    if (isNaN(amount) || amount <= 0) {
      toast.error('Jumlah pengeluaran tidak valid');
      return;
    }

    setIsSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('User tidak terautentikasi');
        return;
      }

      // Get current member info
      const { data: memberData } = await supabase
        .from('members')
        .select('id, full_name')
        .eq('user_id', user.id)
        .single();

      if (!memberData) {
        toast.error('Member tidak ditemukan');
        return;
      }

      // Get PIC name
      const selectedPic = members.find(m => m.id === formData.pic_id);
      if (!selectedPic) {
        toast.error('PIC tidak valid');
        return;
      }

      // Determine if auto-verify (owner/admin) or pending (kasir)
      const isAutoVerify = isOwner || isAdmin;
      const status = isAutoVerify ? 'verified' : 'pending';

      const expenseData: any = {
        expense_date: formData.expense_date,
        pic_id: formData.pic_id,
        pic_name: selectedPic.full_name,
        category: formData.category,
        description: formData.description,
        amount: amount,
        status: status,
        created_by: memberData.id,
        created_by_name: memberData.full_name
      };

      // If auto-verify, add verified info
      if (isAutoVerify) {
        expenseData.verified_by = memberData.id;
        expenseData.verified_by_name = memberData.full_name;
        expenseData.verified_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('expenses')
        .insert(expenseData);

      if (error) throw error;

      await logSystemEvent({
        category: 'payment',
        action: isAutoVerify ? 'Input Pengeluaran (Auto-Verified)' : 'Input Pengeluaran (Pending)',
        description: `${memberData.full_name} menginput pengeluaran: ${formData.description} - Rp ${amount.toLocaleString('id-ID')}`,
        metadata: {
          amount: amount,
          pic_name: selectedPic.full_name,
          status: status
        }
      });

      toast.success(isAutoVerify 
        ? 'Pengeluaran berhasil dicatat' 
        : 'Pengeluaran berhasil diajukan, menunggu verifikasi'
      );

      // Reset form
      const todayReset = new Date().toISOString().split('T')[0];
      setFormData({
        expense_date: todayReset,
        pic_id: "",
        category: "other",
        description: "",
        amount: ""
      });
      setDateDisplayValue(formatDateDisplay(todayReset));
      setIsDialogOpen(false);
      loadExpenses();
    } catch (error: any) {
      console.error('Error submitting expense:', error);
      toast.error(`Gagal menyimpan pengeluaran: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatCurrency = (value: string) => {
    const numbers = value.replace(/[^\d]/g, '');
    return numbers ? parseInt(numbers).toLocaleString('id-ID') : '';
  };

  // Handle opening edit dialog - requires supercode for owner
  const handleEditClick = (expense: Expense) => {
    if (!isOwner) {
      toast.error('Hanya Owner yang dapat mengedit pengeluaran');
      return;
    }
    setPendingEditExpense(expense);
    setIsSupercodeDialogOpen(true);
  };

  // After supercode verification success
  const handleSupercodeSuccess = () => {
    if (pendingEditExpense) {
      setEditingExpense(pendingEditExpense);
      setIsEditDialogOpen(true);
      setPendingEditExpense(null);
    }
  };

  // Handle updating expense category
  const handleUpdateCategory = async (newCategory: string) => {
    if (!editingExpense) return;
    
    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('expenses')
        .update({ category: newCategory })
        .eq('id', editingExpense.id);

      if (error) throw error;

      const { data: { user } } = await supabase.auth.getUser();
      const { data: memberData } = await supabase
        .from('members')
        .select('full_name')
        .eq('user_id', user?.id)
        .single();

      await logSystemEvent({
        category: 'payment',
        action: 'Update Kategori Pengeluaran',
        description: `${memberData?.full_name || 'User'} mengubah kategori pengeluaran: ${editingExpense.description.substring(0, 50)}... ke ${getCategoryConfig(newCategory).label}`,
        metadata: {
          expense_id: editingExpense.id,
          old_category: editingExpense.category,
          new_category: newCategory
        }
      });

      toast.success('Kategori berhasil diperbarui');
      setIsEditDialogOpen(false);
      setEditingExpense(null);
      loadExpenses();
    } catch (error: any) {
      console.error('Error updating category:', error);
      toast.error(`Gagal memperbarui kategori: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);

  if (roleLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Memuat...</h2>
          <p className="text-muted-foreground">Mohon tunggu</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full max-w-full overflow-hidden mb-3">
        <div className="w-full max-w-full overflow-hidden">
          <div className="flex items-center gap-3">
            <Receipt className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
            <div>
              <h1 className="text-2xl font-semibold truncate max-w-full">Biaya Operasional</h1>
              <p className="text-sm text-muted-foreground">Kelola biaya operasional bisnis</p>
            </div>
          </div>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex-shrink-0">
              <Plus className="h-4 w-4 mr-2" />
              Input Pengeluaran
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Input Pengeluaran Baru</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="expense_date">Tanggal Pengeluaran</Label>
                <Input
                  id="expense_date"
                  type="text"
                  inputMode="numeric"
                  placeholder="DD/MM/YYYY"
                  value={dateDisplayValue}
                  onChange={(e) => handleDateInputChange(e.target.value)}
                  maxLength={10}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pic_id">PIC (Person in Charge)</Label>
                <Select
                  value={formData.pic_id}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, pic_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih PIC" />
                  </SelectTrigger>
                  <SelectContent>
                    {members.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.full_name} ({member.position})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Kategori</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih Kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    {EXPENSE_CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        <div className="flex items-center gap-2">
                          <cat.icon className="h-4 w-4" />
                          {cat.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Detail Pengeluaran</Label>
                <Textarea
                  id="description"
                  placeholder="Deskripsikan pengeluaran..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Jumlah (Rp)</Label>
                <Input
                  id="amount"
                  type="text"
                  placeholder="0"
                  value={formData.amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, amount: formatCurrency(e.target.value) }))}
                  required
                />
              </div>

              {isKasir && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950 rounded-lg border border-amber-200 dark:border-amber-800">
                  <p className="text-sm text-amber-700 dark:text-amber-300">
                    <Clock className="h-4 w-4 inline mr-1" />
                    Pengeluaran akan menunggu verifikasi dari Admin/Owner
                  </p>
                </div>
              )}

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? 'Menyimpan...' : 'Simpan Pengeluaran'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Expense Dialog - Full Edit */}
        <EditExpenseDialog
          open={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          expense={editingExpense}
          members={members}
          onSuccess={loadExpenses}
        />

        {/* Supercode Verification Dialog */}
        <SupercodeVerificationDialog
          open={isSupercodeDialogOpen}
          onOpenChange={setIsSupercodeDialogOpen}
          onSuccess={handleSupercodeSuccess}
          title="Verifikasi Owner"
          description="Masukkan supercode untuk mengedit pengeluaran"
        />
      </div>

      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <CardTitle className="text-base sm:text-lg flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Daftar Pengeluaran Terverifikasi
              <Badge variant="secondary">{totalCount} total</Badge>
            </CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari deskripsi atau PIC..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="w-full max-w-full overflow-hidden p-3 sm:p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Clock className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : expenses.length === 0 ? (
            <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
              <Receipt className="h-8 w-8" />
              <p className="font-medium">Belum ada pengeluaran</p>
              <p className="text-sm">Klik tombol "Input Pengeluaran" untuk menambahkan</p>
            </div>
          ) : isMobile ? (
            <div className="space-y-3">
              {expenses.map((expense) => {
                const categoryConfig = getCategoryConfig(expense.category);
                return (
                  <MobileDataCard
                    key={expense.id}
                    id={formatDateWIB(expense.expense_date)}
                    name={expense.description}
                    subtitle={`${categoryConfig.label} • PIC: ${expense.pic_name} • Rp ${expense.amount.toLocaleString('id-ID')}`}
                    categoryIcon={categoryConfig.icon}
                    categoryIconClassName={categoryConfig.colorClass}
                    statusIndicator={
                      <Badge variant="default" className="bg-green-500 hover:bg-green-600">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Verified
                      </Badge>
                    }
                    onClick={isOwner ? () => handleEditClick(expense) : undefined}
                  />
                );
              })}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Kategori</TableHead>
                    <TableHead>PIC</TableHead>
                    <TableHead>Detail</TableHead>
                    <TableHead className="text-right">Jumlah</TableHead>
                    <TableHead>Diverifikasi Oleh</TableHead>
                    <TableHead>Waktu Verifikasi</TableHead>
                    {isOwner && <TableHead className="text-center">Aksi</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expenses.map((expense) => {
                    const categoryConfig = getCategoryConfig(expense.category);
                    return (
                      <TableRow key={expense.id}>
                        <TableCell className="whitespace-nowrap">
                          {formatDateWIB(expense.expense_date)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className={`p-1.5 rounded ${categoryConfig.colorClass}`}>
                              <categoryConfig.icon className="h-4 w-4" />
                            </div>
                            <span className="text-sm">{categoryConfig.label}</span>
                          </div>
                        </TableCell>
                        <TableCell>{expense.pic_name}</TableCell>
                        <TableCell className="max-w-[300px] whitespace-pre-wrap break-words">
                          {expense.description}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          Rp {expense.amount.toLocaleString('id-ID')}
                        </TableCell>
                        <TableCell>{expense.verified_by_name || '-'}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          {expense.verified_at ? formatDateWIB(expense.verified_at) : '-'}
                        </TableCell>
                        {isOwner && (
                          <TableCell className="text-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditClick(expense)}
                              title="Edit Pengeluaran (Owner Only)"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-4 flex justify-center">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious 
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }
                    return (
                      <PaginationItem key={pageNum}>
                        <PaginationLink
                          onClick={() => setCurrentPage(pageNum)}
                          isActive={currentPage === pageNum}
                          className="cursor-pointer"
                        >
                          {pageNum}
                        </PaginationLink>
                      </PaginationItem>
                    );
                  })}
                  <PaginationItem>
                    <PaginationNext 
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
