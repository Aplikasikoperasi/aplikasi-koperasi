import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserCheck, UserX } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Customers from "./Customers";
import BlockedCustomers from "./BlockedCustomers";
import { useBlockedCustomersQuery } from "@/hooks/useBlockedCustomersQuery";

export default function CustomersWithSubTabs() {
  const [activeSubTab, setActiveSubTab] = useState("active");
  const [activeCount, setActiveCount] = useState(0);
  
  // Get blocked customers count for the tab badge
  const { data: blockedData } = useBlockedCustomersQuery({
    searchQuery: "",
    page: 1,
    itemsPerPage: 1
  });
  const blockedCount = blockedData?.totalCount || 0;

  // Load active customers count
  useEffect(() => {
    const loadActiveCount = async () => {
      const { count } = await supabase.from("customers").select("id", {
        count: 'exact',
        head: true
      }).eq("status", "approved");
      setActiveCount(count || 0);
    };
    
    loadActiveCount();

    // Set up realtime subscription
    const channel = supabase.channel('active-customers-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, () => loadActiveCount()).subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <div className="w-full">
      <Tabs value={activeSubTab} onValueChange={setActiveSubTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="active" className="gap-1.5 text-xs sm:text-sm">
            <UserCheck className="h-4 w-4" />
            <span>Nasabah Aktif ({activeCount})</span>
          </TabsTrigger>
          <TabsTrigger value="blocked" className="gap-1.5 text-xs sm:text-sm">
            <UserX className="h-4 w-4" />
            <span>Nasabah Diblokir</span>
            {blockedCount > 0 && (
              <span className="ml-1 text-xs bg-destructive/20 text-destructive px-1.5 py-0.5 rounded-full">
                {blockedCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-0">
          <Customers />
        </TabsContent>

        <TabsContent value="blocked" className="mt-0">
          <BlockedCustomers />
        </TabsContent>
      </Tabs>
    </div>
  );
}
