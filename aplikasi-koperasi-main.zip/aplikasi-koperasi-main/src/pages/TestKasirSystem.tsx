import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface TestResult {
  name: string;
  status: 'pending' | 'running' | 'success' | 'error';
  message?: string;
  details?: string;
}

export default function TestKasirSystem() {
  const navigate = useNavigate();
  const [tests, setTests] = useState<TestResult[]>([
    { name: 'Verifikasi Auth Schema', status: 'pending' },
    { name: 'Verifikasi Data Kasir', status: 'pending' },
    { name: 'Test Verifikasi PIN', status: 'pending' },
    { name: 'Test Login Kasir', status: 'pending' },
  ]);
  const [running, setRunning] = useState(false);

  const updateTest = (index: number, updates: Partial<TestResult>) => {
    setTests(prev => prev.map((test, i) => i === index ? { ...test, ...updates } : test));
  };

  const runTests = async () => {
    setRunning(true);

    // Test 1: Verify Auth Schema
    updateTest(0, { status: 'running' });
    try {
      const { data: authCheck, error: authError } = await supabase
        .from('members')
        .select('user_id')
        .eq('position', 'Kasir')
        .limit(1)
        .single();

      if (authError) throw authError;
      if (!authCheck.user_id) throw new Error('Kasir tidak punya user_id');

      // Check auth user exists
      const { data: { user }, error: getUserError } = await supabase.auth.admin.getUserById(authCheck.user_id);
      
      updateTest(0, { 
        status: 'success', 
        message: 'Auth schema clean ✓',
        details: `User ID: ${authCheck.user_id.substring(0, 8)}...`
      });
    } catch (error: any) {
      updateTest(0, { 
        status: 'error', 
        message: 'Auth schema error',
        details: error.message 
      });
      setRunning(false);
      return;
    }

    // Test 2: Verify Kasir Data
    updateTest(1, { status: 'running' });
    try {
      const { data: memberData, error: memberError } = await supabase
        .from('members')
        .select('id, full_name, user_id, pin, date_of_birth, position')
        .eq('position', 'Kasir')
        .limit(1)
        .single();

      if (memberError) throw memberError;
      if (!memberData.pin) throw new Error('PIN tidak ada');
      if (!memberData.user_id) throw new Error('User ID tidak ada');
      if (!memberData.date_of_birth) throw new Error('Tanggal lahir tidak ada');

      // Check role exists
      const { data: roleData, error: roleError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', memberData.user_id)
        .single();

      if (roleError) throw roleError;
      if (roleData.role !== 'kasir') throw new Error(`Role salah: ${roleData.role}`);

      updateTest(1, { 
        status: 'success', 
        message: 'Data kasir lengkap ✓',
        details: `${memberData.full_name} - PIN: ${memberData.pin.substring(0, 2)}****`
      });

      // Test 3: Verify PIN
      updateTest(2, { status: 'running' });
      try {
        const { data: pinValid, error: pinError } = await supabase.rpc('verify_kasir_pin', {
          p_member_id: memberData.id,
          p_pin_input: memberData.pin
        });

        if (pinError) throw pinError;
        if (!pinValid) throw new Error('PIN verification returned false');

        updateTest(2, { 
          status: 'success', 
          message: 'Verifikasi PIN berhasil ✓',
          details: 'RPC function berfungsi dengan baik'
        });

        // Test 4: Test Login
        updateTest(3, { status: 'running' });
        try {
          // Generate email and password
          const cleanedName = memberData.full_name.trim().replace(/\s+/g, '').toLowerCase();
          const email = `${cleanedName}@system.local`;
          
          const dob = new Date(memberData.date_of_birth);
          const day = String(dob.getDate()).padStart(2, '0');
          const month = String(dob.getMonth() + 1).padStart(2, '0');
          const year = dob.getFullYear();
          const password = `${day}${month}${year}`;

          console.log('🔐 Testing sign in...', { email, passwordLength: password.length });

          const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
            email,
            password
          });

          if (signInError) {
            // Try auto-heal
            console.log('⚠️ Sign in failed, attempting auto-heal...');
            
            const { error: healError } = await supabase.functions.invoke('create-member-auth', {
              body: {
                memberId: memberData.id,
                fullName: memberData.full_name,
                dateOfBirth: memberData.date_of_birth,
                position: memberData.position,
                pin: memberData.pin
              }
            });

            if (healError) throw healError;

            // Wait and retry
            await new Promise(r => setTimeout(r, 2000));

            const { data: retryData, error: retryError } = await supabase.auth.signInWithPassword({
              email,
              password
            });

            if (retryError) throw retryError;

            // Sign out immediately
            await supabase.auth.signOut();

            updateTest(3, { 
              status: 'success', 
              message: 'Login berhasil (setelah heal) ✓',
              details: `User: ${retryData.user?.email}`
            });
          } else {
            // Sign out immediately
            await supabase.auth.signOut();

            updateTest(3, { 
              status: 'success', 
              message: 'Login berhasil ✓',
              details: `User: ${signInData.user?.email}`
            });
          }
        } catch (error: any) {
          updateTest(3, { 
            status: 'error', 
            message: 'Login gagal',
            details: error.message || JSON.stringify(error)
          });
          setRunning(false);
          return;
        }
      } catch (error: any) {
        updateTest(2, { 
          status: 'error', 
          message: 'PIN verification gagal',
          details: error.message 
        });
        setRunning(false);
        return;
      }
    } catch (error: any) {
      updateTest(1, { 
        status: 'error', 
        message: 'Data kasir bermasalah',
        details: error.message 
      });
      setRunning(false);
      return;
    }

    setRunning(false);
  };

  return (
    <div className="min-h-screen p-8 bg-background">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Test Sistem Kasir</h1>
          <Button variant="outline" onClick={() => navigate('/auth')}>
            Kembali ke Login
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Automated System Tests</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={runTests} 
              disabled={running}
              className="w-full"
              size="lg"
            >
              {running ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Running Tests...
                </>
              ) : (
                'Jalankan Test Lengkap'
              )}
            </Button>

            <div className="space-y-3 mt-6">
              {tests.map((test, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-3 p-4 rounded-lg border bg-card"
                >
                  <div className="mt-1">
                    {test.status === 'pending' && (
                      <div className="h-5 w-5 rounded-full border-2 border-muted" />
                    )}
                    {test.status === 'running' && (
                      <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
                    )}
                    {test.status === 'success' && (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    )}
                    {test.status === 'error' && (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="font-medium">{test.name}</p>
                    {test.message && (
                      <p className={`text-sm ${
                        test.status === 'success' ? 'text-green-600' : 
                        test.status === 'error' ? 'text-red-600' : 
                        'text-muted-foreground'
                      }`}>
                        {test.message}
                      </p>
                    )}
                    {test.details && (
                      <p className="text-xs text-muted-foreground font-mono">
                        {test.details}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Manual Test</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="bg-muted p-3 rounded">
              <p className="font-semibold mb-2">Login Kasir Existing:</p>
              <code className="block">
                Username: Kasir<br/>
                Password: 27031990<br/>
                PIN: 888888
              </code>
            </div>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => navigate('/auth')}
            >
              Buka Halaman Login
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
