import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, DollarSign, FileText, CreditCard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Applications from "./Applications";
import Installments from "./Installments";
import Payments from "./Payments";
import { useUserRole } from "@/hooks/useUserRole";
export default function InstallmentsAndPayments() {
  const location = useLocation();
  const navigate = useNavigate();
  const [applicationCount, setApplicationCount] = useState(0);
  const [installmentCount, setInstallmentCount] = useState(0);
  const [paymentCount, setPaymentCount] = useState(0);
  const [activeTab, setActiveTab] = useState("installments");
  const {
    isSales
  } = useUserRole();

  // Handle navigation state for editing
  useEffect(() => {
    if (location.state) {
      const state = location.state as any;
      if (state.openTab) {
        setActiveTab(state.openTab);
      }
      if (state.editApplication) {
        // Store in sessionStorage for Applications component to pick up
        sessionStorage.setItem('editApplication', JSON.stringify(state.editApplication));
        // Clear the navigation state
        navigate(location.pathname, {
          replace: true,
          state: {}
        });
      }
    }
  }, [location.state]);
  useEffect(() => {
    loadCounts();

    // Set up realtime subscriptions for counts
    const applicationsChannel = supabase.channel('applications-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, () => loadApplicationCount()).subscribe();
    const installmentsChannel = supabase.channel('installments-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'installments'
    }, () => loadInstallmentCount()).subscribe();
    const paymentsChannel = supabase.channel('payments-count').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'payments'
    }, () => loadPaymentCount()).subscribe();
    return () => {
      supabase.removeChannel(applicationsChannel);
      supabase.removeChannel(installmentsChannel);
      supabase.removeChannel(paymentsChannel);
    };
  }, []);
  const loadCounts = () => {
    loadApplicationCount();
    loadInstallmentCount();
    loadPaymentCount();
  };
  const loadApplicationCount = async () => {
    // Get current user and role info for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let query = supabase.from("credit_applications").select("id", {
      count: 'exact',
      head: true
    }).neq("status", "rejected");
    if (user && isSales) {
      // Filter by member_id or customers created by them
      const {
        data: memberData
      } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
      if (memberData?.id) {
        const {
          data: customersData
        } = await supabase.from("customers").select("id").eq("created_by", memberData.id);
        const customerIds = customersData?.map(c => c.id) || [];
        if (customerIds.length > 0) {
          query = query.or(`member_id.eq.${memberData.id},customer_id.in.(${customerIds.join(',')})`);
        } else {
          query = query.eq("member_id", memberData.id);
        }
      }
    }
    const {
      count
    } = await query;
    setApplicationCount(count || 0);
  };
  const loadInstallmentCount = async () => {
    // Get current user and role info for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let query = supabase.from("installments").select("id", {
      count: 'exact',
      head: true
    }).in("status", ["unpaid", "partial", "overdue"]);
    if (user && isSales) {
      // Filter by member_id or customers created by them
      const {
        data: memberData
      } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
      if (memberData?.id) {
        const {
          data: customersData
        } = await supabase.from("customers").select("id").eq("created_by", memberData.id);
        const customerIds = customersData?.map(c => c.id) || [];

        // Get application IDs
        let appQuery = supabase.from("credit_applications").select("id");
        if (customerIds.length > 0) {
          appQuery = appQuery.or(`member_id.eq.${memberData.id},customer_id.in.(${customerIds.join(',')})`);
        } else {
          appQuery = appQuery.eq("member_id", memberData.id);
        }
        const {
          data: allowedApps
        } = await appQuery;
        const allowedAppIds = allowedApps?.map(a => a.id) || [];
        if (allowedAppIds.length > 0) {
          query = query.in("application_id", allowedAppIds);
        } else {
          setInstallmentCount(0);
          return;
        }
      }
    }
    const {
      count
    } = await query;
    setInstallmentCount(count || 0);
  };
  const loadPaymentCount = async () => {
    // Get current user and role info for sales filtering
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    let query = supabase.from("payments").select("id", {
      count: 'exact',
      head: true
    });
    if (user && isSales) {
      // Filter by member_id or customers created by them
      const {
        data: memberData
      } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
      if (memberData?.id) {
        const {
          data: customersData
        } = await supabase.from("customers").select("id").eq("created_by", memberData.id);
        const customerIds = customersData?.map(c => c.id) || [];

        // Get application IDs
        let appQuery = supabase.from("credit_applications").select("id");
        if (customerIds.length > 0) {
          appQuery = appQuery.or(`member_id.eq.${memberData.id},customer_id.in.(${customerIds.join(',')})`);
        } else {
          appQuery = appQuery.eq("member_id", memberData.id);
        }
        const {
          data: allowedApps
        } = await appQuery;
        const allowedAppIds = allowedApps?.map(a => a.id) || [];
        if (allowedAppIds.length > 0) {
          // Get installment IDs for these applications
          const {
            data: installmentsData
          } = await supabase.from("installments").select("id").in("application_id", allowedAppIds);
          const installmentIds = installmentsData?.map(i => i.id) || [];
          if (installmentIds.length > 0) {
            query = query.in("installment_id", installmentIds);
          } else {
            setPaymentCount(0);
            return;
          }
        } else {
          setPaymentCount(0);
          return;
        }
      }
    }
    const {
      count
    } = await query;
    setPaymentCount(count || 0);
  };
  return <div className="w-full max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full max-w-full overflow-hidden mb-3">
        <div className="w-full max-w-full overflow-hidden">
          <div className="flex items-center gap-3">
            <CreditCard className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
            <div className="flex-1">
              <h1 className="text-2xl font-semibold truncate max-w-full">Kredit & Pembayaran</h1>
            </div>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="installments" className="gap-2">
            <Calendar className="h-4 w-4" />
            Angsuran ({installmentCount})
          </TabsTrigger>
          <TabsTrigger value="payments" className="gap-2">
            <DollarSign className="h-4 w-4" />
            Pembayaran ({paymentCount})
          </TabsTrigger>
          <TabsTrigger value="applications" className="gap-2">
            <FileText className="h-4 w-4" />
            Kredit ({applicationCount})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="installments" className="mt-3">
          <Installments />
        </TabsContent>

        <TabsContent value="payments" className="mt-3">
          <Payments />
        </TabsContent>

        <TabsContent value="applications" className="mt-3">
          <Applications />
        </TabsContent>
      </Tabs>
    </div>;
}