import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Paperclip, Monitor, Building2, Zap, Car, UtensilsCrossed, Wifi, Wrench, Sparkles, LucideIcon } from "lucide-react";

interface Expense {
  id: string;
  expense_date: string;
  pic_id: string | null;
  pic_name: string;
  description: string;
  amount: number;
  category: string;
  status: string;
}

interface Member {
  id: string;
  full_name: string;
  position: string;
}

interface EditExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  expense: Expense | null;
  members: Member[];
  onSuccess: () => void;
}

const EXPENSE_CATEGORIES: { value: string; label: string; icon: LucideIcon; colorClass: string }[] = [
  { value: 'atk', label: 'ATK (Alat Tulis)', icon: Paperclip, colorClass: 'bg-blue-100 dark:bg-blue-900/30' },
  { value: 'peralatan', label: 'Peralatan/Komputer', icon: Monitor, colorClass: 'bg-cyan-100 dark:bg-cyan-900/30' },
  { value: 'sewa', label: 'Sewa/Rental', icon: Building2, colorClass: 'bg-indigo-100 dark:bg-indigo-900/30' },
  { value: 'listrik', label: 'Listrik', icon: Zap, colorClass: 'bg-yellow-100 dark:bg-yellow-900/30' },
  { value: 'transport', label: 'Transport', icon: Car, colorClass: 'bg-green-100 dark:bg-green-900/30' },
  { value: 'konsumsi', label: 'Konsumsi/Makan', icon: UtensilsCrossed, colorClass: 'bg-orange-100 dark:bg-orange-900/30' },
  { value: 'internet', label: 'Internet/Telekomunikasi', icon: Wifi, colorClass: 'bg-purple-100 dark:bg-purple-900/30' },
  { value: 'perawatan', label: 'Perawatan/Maintenance', icon: Wrench, colorClass: 'bg-gray-100 dark:bg-gray-900/30' },
  { value: 'other', label: 'Lainnya', icon: Sparkles, colorClass: 'bg-pink-100 dark:bg-pink-900/30' },
];

export function EditExpenseDialog({ open, onOpenChange, expense, members, onSuccess }: EditExpenseDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dateDisplayValue, setDateDisplayValue] = useState("");
  const [formData, setFormData] = useState({
    expense_date: "",
    pic_id: "",
    category: "other",
    description: "",
    amount: ""
  });

  // Format date for display (DD/MM/YYYY)
  const formatDateDisplay = (isoDate: string) => {
    if (!isoDate) return '';
    const [year, month, day] = isoDate.split('-');
    return `${day}/${month}/${year}`;
  };

  // Parse display date (DD/MM/YYYY) to ISO (YYYY-MM-DD)
  const parseDisplayDate = (displayDate: string) => {
    const cleanDate = displayDate.replace(/\D/g, '');
    if (cleanDate.length === 8) {
      const day = cleanDate.substring(0, 2);
      const month = cleanDate.substring(2, 4);
      const year = cleanDate.substring(4, 8);
      return `${year}-${month}-${day}`;
    }
    return '';
  };

  // Auto separator for date input
  const handleDateInputChange = (value: string) => {
    let digits = value.replace(/\D/g, '');
    digits = digits.substring(0, 8);
    
    let formatted = '';
    if (digits.length > 0) {
      formatted = digits.substring(0, 2);
    }
    if (digits.length > 2) {
      formatted += '/' + digits.substring(2, 4);
    }
    if (digits.length > 4) {
      formatted += '/' + digits.substring(4, 8);
    }
    
    setDateDisplayValue(formatted);
    
    if (digits.length === 8) {
      const isoDate = parseDisplayDate(formatted);
      setFormData(prev => ({ ...prev, expense_date: isoDate }));
    }
  };

  const formatCurrency = (value: string) => {
    const numbers = value.replace(/[^\d]/g, '');
    return numbers ? parseInt(numbers).toLocaleString('id-ID') : '';
  };

  // Initialize form when expense changes
  useEffect(() => {
    if (expense && open) {
      setFormData({
        expense_date: expense.expense_date,
        pic_id: expense.pic_id || "",
        category: expense.category || "other",
        description: expense.description,
        amount: expense.amount.toLocaleString('id-ID')
      });
      setDateDisplayValue(formatDateDisplay(expense.expense_date));
    }
  }, [expense, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting || !expense) return;

    // Validation
    if (!formData.expense_date || !formData.pic_id || !formData.description || !formData.amount) {
      toast.error('Semua field harus diisi');
      return;
    }

    const amount = parseFloat(formData.amount.replace(/[^\d]/g, ''));
    if (isNaN(amount) || amount <= 0) {
      toast.error('Jumlah pengeluaran tidak valid');
      return;
    }

    setIsSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('User tidak terautentikasi');
        return;
      }

      // Get current member info
      const { data: memberData } = await supabase
        .from('members')
        .select('id, full_name')
        .eq('user_id', user.id)
        .single();

      // Get PIC name
      const selectedPic = members.find(m => m.id === formData.pic_id);
      if (!selectedPic) {
        toast.error('PIC tidak valid');
        return;
      }

      // Build update object with changed fields
      const updateData: Record<string, any> = {
        expense_date: formData.expense_date,
        pic_id: formData.pic_id,
        pic_name: selectedPic.full_name,
        category: formData.category,
        description: formData.description,
        amount: amount,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('expenses')
        .update(updateData)
        .eq('id', expense.id);

      if (error) throw error;

      // Build changes description
      const changes: string[] = [];
      if (expense.expense_date !== formData.expense_date) changes.push('tanggal');
      if (expense.pic_id !== formData.pic_id) changes.push('PIC');
      if (expense.category !== formData.category) changes.push('kategori');
      if (expense.description !== formData.description) changes.push('deskripsi');
      if (expense.amount !== amount) changes.push('jumlah');

      await logSystemEvent({
        category: 'payment',
        action: 'Update Pengeluaran',
        description: `${memberData?.full_name || 'User'} mengubah pengeluaran: ${expense.description.substring(0, 30)}... (${changes.join(', ')})`,
        metadata: {
          expense_id: expense.id,
          old_data: {
            expense_date: expense.expense_date,
            pic_id: expense.pic_id,
            pic_name: expense.pic_name,
            category: expense.category,
            description: expense.description,
            amount: expense.amount
          },
          new_data: {
            expense_date: formData.expense_date,
            pic_id: formData.pic_id,
            pic_name: selectedPic.full_name,
            category: formData.category,
            description: formData.description,
            amount: amount
          }
        }
      });

      toast.success('Pengeluaran berhasil diperbarui');
      onOpenChange(false);
      onSuccess();
    } catch (error: any) {
      console.error('Error updating expense:', error);
      toast.error(`Gagal memperbarui pengeluaran: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Pengeluaran</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit_expense_date">Tanggal Pengeluaran</Label>
            <Input
              id="edit_expense_date"
              type="text"
              inputMode="numeric"
              placeholder="DD/MM/YYYY"
              value={dateDisplayValue}
              onChange={(e) => handleDateInputChange(e.target.value)}
              maxLength={10}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit_pic_id">PIC (Person in Charge)</Label>
            <Select
              value={formData.pic_id}
              onValueChange={(value) => setFormData(prev => ({ ...prev, pic_id: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Pilih PIC" />
              </SelectTrigger>
              <SelectContent>
                {members.map((member) => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.full_name} ({member.position})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit_category">Kategori</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Pilih Kategori" />
              </SelectTrigger>
              <SelectContent>
                {EXPENSE_CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    <div className="flex items-center gap-2">
                      <cat.icon className="h-4 w-4" />
                      {cat.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit_description">Detail Pengeluaran</Label>
            <Textarea
              id="edit_description"
              placeholder="Deskripsikan pengeluaran..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit_amount">Jumlah (Rp)</Label>
            <Input
              id="edit_amount"
              type="text"
              placeholder="0"
              value={formData.amount}
              onChange={(e) => setFormData(prev => ({ ...prev, amount: formatCurrency(e.target.value) }))}
              required
            />
          </div>

          <div className="flex gap-2">
            <Button 
              type="button" 
              variant="outline" 
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              Batal
            </Button>
            <Button type="submit" className="flex-1" disabled={isSubmitting}>
              {isSubmitting ? 'Menyimpan...' : 'Simpan Perubahan'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
