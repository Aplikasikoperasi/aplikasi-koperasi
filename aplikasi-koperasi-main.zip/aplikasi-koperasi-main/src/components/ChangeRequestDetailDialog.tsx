import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, XCircle, ArrowRight } from "lucide-react";
import { formatDate } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface ChangeRequestDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  request: any;
  onApprove?: (request: any) => void;
  onReject?: (request: any) => void;
}

const fieldLabels: Record<string, string> = {
  full_name: "Nama Lengkap",
  nik: "NIK",
  date_of_birth: "Tanggal Lahir",
  phone: "No. Telepon",
  address: "Alamat",
  occupation: "Pekerjaan",
  photo_url: "Foto Nasabah",
};

export function ChangeRequestDetailDialog({
  open,
  onOpenChange,
  request,
  onApprove,
  onReject,
}: ChangeRequestDetailDialogProps) {
  const { isOwner, isAdmin } = useUserRole();
  const canManage = isOwner || isAdmin;

  if (!request) return null;

  const getChangedFields = () => {
    const changes: Array<{ field: string; oldValue: any; newValue: any }> = [];
    const oldData = request.old_data || {};
    const newData = request.new_data || {};

    Object.keys(newData).forEach((key) => {
      // Skip email field - aplikasi tidak menggunakan email
      if (key === 'email') return;
      
      // Skip jika kedua nilai kosong/null (data tidak pernah diisi)
      const oldVal = oldData[key];
      const newVal = newData[key];
      
      // Skip jika both empty
      if ((!oldVal || oldVal === '') && (!newVal || newVal === '')) return;
      
      if (oldData[key] !== newData[key]) {
        changes.push({
          field: key,
          oldValue: oldData[key],
          newValue: newData[key],
        });
      }
    });

    return changes;
  };

  const changes = getChangedFields();
  
  // Debug log
  console.log('Change Request Data:', {
    requested_by: request.requested_by,
    requester: request.requester,
    customer: request.customer,
    changes: changes
  });

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="w-full max-w-[95vw] sm:max-w-2xl lg:max-w-3xl max-h-[90vh] overflow-y-auto">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle className="text-base sm:text-lg">Detail Permintaan Perubahan Data</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="space-y-3 sm:space-y-4 px-1">
          {/* Status Badge */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <Badge
              variant={
                request.status === "approved"
                  ? "default"
                  : request.status === "rejected"
                  ? "destructive"
                  : "secondary"
              }
              className="w-fit"
            >
              {request.status === "approved"
                ? "Disetujui"
                : request.status === "rejected"
                ? "Ditolak"
                : "Menunggu"}
            </Badge>
            <span className="text-xs sm:text-sm text-muted-foreground">
              {formatDate(request.created_at)}
            </span>
          </div>

          {/* Customer Info */}
          <div className="bg-muted/50 p-3 sm:p-4 rounded-lg">
            <p className="text-xs sm:text-sm text-muted-foreground mb-1">Nasabah</p>
            <p className="font-semibold text-sm sm:text-base break-words">{request.customer?.full_name}</p>
            <p className="text-xs sm:text-sm text-muted-foreground font-bold">{request.customer?.id_number}</p>
          </div>

          {/* Requester Info */}
          <div className="bg-muted/50 p-3 sm:p-4 rounded-lg">
            <p className="text-xs sm:text-sm text-muted-foreground mb-1">Diajukan oleh</p>
            {request.requester ? (
              <>
                <p className="font-semibold text-sm sm:text-base break-words">{request.requester.full_name}</p>
                <p className="text-xs sm:text-sm text-muted-foreground">
                  {request.requester.position || "Staff"}
                </p>
              </>
            ) : (
              <p className="text-sm sm:text-base text-muted-foreground italic">Data pengaju tidak ditemukan</p>
            )}
          </div>

          <Separator />

          {/* Changes */}
          <div className="space-y-3 sm:space-y-4">
            <h4 className="font-semibold text-sm sm:text-base">Perubahan yang Diajukan:</h4>
            {changes.length === 0 ? (
              <p className="text-sm text-muted-foreground">Tidak ada perubahan</p>
            ) : (
              changes.map((change, index) => (
                <div key={index} className="bg-muted/30 p-3 sm:p-4 rounded-lg space-y-2">
                  <p className="font-medium text-xs sm:text-sm">{fieldLabels[change.field] || change.field}</p>
                  
                  {change.field === "photo_url" ? (
                    <div className="flex flex-col sm:flex-row items-center gap-3 justify-center">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-2">Foto Lama:</p>
                        <Avatar className="h-16 w-16 sm:h-20 sm:w-20 mx-auto">
                          <AvatarImage src={change.oldValue} alt="Old photo" />
                          <AvatarFallback className="bg-destructive/10 text-destructive text-xs">
                            LAMA
                          </AvatarFallback>
                        </Avatar>
                      </div>
                      <ArrowRight className="h-5 w-5 sm:h-6 sm:w-6 flex-shrink-0 text-muted-foreground rotate-90 sm:rotate-0" />
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-2">Foto Baru:</p>
                        <Avatar className="h-16 w-16 sm:h-20 sm:w-20 mx-auto">
                          <AvatarImage src={change.newValue} alt="New photo" />
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            BARU
                          </AvatarFallback>
                        </Avatar>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 text-xs sm:text-sm">
                      <div className="flex-1 bg-destructive/10 text-destructive p-2 sm:p-3 rounded min-w-0">
                        <p className="text-xs text-muted-foreground mb-1">Data Lama:</p>
                        <p className="font-medium break-words">
                          {change.field === "date_of_birth" ? (
                            change.oldValue ? new Date(change.oldValue).toLocaleDateString('id-ID', {
                              day: '2-digit',
                              month: 'long',
                              year: 'numeric'
                            }) : "-"
                          ) : (
                            change.oldValue || "-"
                          )}
                        </p>
                      </div>
                      <ArrowRight className="h-4 w-4 flex-shrink-0 text-muted-foreground self-center rotate-90 sm:rotate-0" />
                      <div className="flex-1 bg-primary/10 text-primary p-2 sm:p-3 rounded min-w-0">
                        <p className="text-xs text-muted-foreground mb-1">Data Baru:</p>
                        <p className="font-medium break-words">
                          {change.field === "date_of_birth" ? (
                            change.newValue ? new Date(change.newValue).toLocaleDateString('id-ID', {
                              day: '2-digit',
                              month: 'long',
                              year: 'numeric'
                            }) : "-"
                          ) : (
                            change.newValue || "-"
                          )}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Notes */}
          {request.notes && (
            <>
              <Separator />
              <div>
                <p className="text-xs sm:text-sm font-medium text-muted-foreground mb-2">Catatan:</p>
                <p className="text-xs sm:text-sm bg-muted/30 p-3 rounded-lg break-words">{request.notes}</p>
              </div>
            </>
          )}

          {/* Review Info */}
          {request.status !== "pending" && request.reviewed_at && (
            <>
              <Separator />
              <div className="bg-muted/30 p-3 sm:p-4 rounded-lg">
                <p className="text-xs sm:text-sm text-muted-foreground break-words">
                  {request.status === "approved" ? "Disetujui" : "Ditolak"} pada{" "}
                  {formatDate(request.reviewed_at)}
                </p>
                {request.reviewer?.full_name && (
                  <p className="text-xs sm:text-sm font-medium mt-1 break-words">oleh: {request.reviewer.full_name}</p>
                )}
              </div>
            </>
          )}

          {/* Action Buttons */}
          {canManage && request.status === "pending" && (
            <>
              <Separator />
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                <Button
                  variant="default"
                  className="flex-1 text-sm sm:text-base"
                  size="sm"
                  onClick={() => {
                    onApprove?.(request);
                    onOpenChange(false);
                  }}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Setujui
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1 text-sm sm:text-base"
                  size="sm"
                  onClick={() => {
                    onReject?.(request);
                    onOpenChange(false);
                  }}
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Tolak
                </Button>
              </div>
            </>
          )}
        </div>
      </ResponsiveDialogContent>
    </ResponsiveDialog>
  );
}
