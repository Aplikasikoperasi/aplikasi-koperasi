import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface AnimatedViewTransitionProps {
  viewMode: 'card' | 'table';
  children: ReactNode;
  className?: string;
}

// Simple wrapper that uses key to trigger re-render animation
export function AnimatedViewTransition({ 
  viewMode, 
  children, 
  className 
}: AnimatedViewTransitionProps) {
  return (
    <div 
      key={viewMode}
      className={cn(
        "animate-fade-in",
        className
      )}
    >
      {children}
    </div>
  );
}

// Hook to generate animated class based on viewMode for inline usage
export function useViewAnimationClass(viewMode: 'card' | 'table') {
  return "animate-fade-in";
}


