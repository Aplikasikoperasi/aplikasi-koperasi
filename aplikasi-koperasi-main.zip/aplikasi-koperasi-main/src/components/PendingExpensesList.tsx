import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useUserRole } from "@/hooks/useUserRole";
import { CheckCircle, XCircle, Clock, Receipt, DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { MobileDataCard } from "@/components/MobileDataCard";
import { formatDateWIB } from "@/lib/utils";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useIsMobile } from "@/hooks/use-mobile";

interface PendingExpense {
  id: string;
  expense_date: string;
  pic_id: string | null;
  pic_name: string;
  description: string;
  amount: number;
  status: string;
  created_by: string | null;
  created_by_name: string;
  created_at: string;
}

interface PendingExpensesListProps {
  onCountChange?: (count: number) => void;
}

export function PendingExpensesList({ onCountChange }: PendingExpensesListProps) {
  const [pendingExpenses, setPendingExpenses] = useState<PendingExpense[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionDialog, setActionDialog] = useState<{
    open: boolean;
    expense: PendingExpense | null;
    action: 'approve' | 'reject' | null;
  }>({
    open: false,
    expense: null,
    action: null
  });

  const { isOwner, isAdmin } = useUserRole();
  const isMobile = useIsMobile();
  const canVerify = isOwner || isAdmin;

  useEffect(() => {
    loadPendingExpenses();

    // Set up realtime subscription
    const channel = supabase
      .channel('pending-expenses-verification')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'expenses'
      }, () => {
        loadPendingExpenses();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadPendingExpenses = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('expenses')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPendingExpenses(data || []);
      onCountChange?.(data?.length || 0);
    } catch (error: any) {
      console.error('Error loading pending expenses:', error);
      toast.error('Gagal memuat data pengeluaran pending');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = async () => {
    if (!actionDialog.expense || !actionDialog.action) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('User tidak terautentikasi');
        return;
      }

      // Get current member info
      const { data: memberData } = await supabase
        .from('members')
        .select('id, full_name')
        .eq('user_id', user.id)
        .single();

      if (!memberData) {
        toast.error('Member tidak ditemukan');
        return;
      }

      if (actionDialog.action === 'approve') {
        const { error } = await supabase
          .from('expenses')
          .update({
            status: 'verified',
            verified_by: memberData.id,
            verified_by_name: memberData.full_name,
            verified_at: new Date().toISOString()
          })
          .eq('id', actionDialog.expense.id);

        if (error) throw error;

        await logSystemEvent({
          category: 'payment',
          action: 'Verifikasi Pengeluaran',
          description: `${memberData.full_name} memverifikasi pengeluaran: ${actionDialog.expense.description} - Rp ${actionDialog.expense.amount.toLocaleString('id-ID')}`,
          metadata: {
            expense_id: actionDialog.expense.id,
            amount: actionDialog.expense.amount,
            created_by: actionDialog.expense.created_by_name
          }
        });

        toast.success('Pengeluaran berhasil diverifikasi');
      } else {
        // Reject - delete the expense
        const { error } = await supabase
          .from('expenses')
          .delete()
          .eq('id', actionDialog.expense.id);

        if (error) throw error;

        await logSystemEvent({
          category: 'payment',
          action: 'Tolak Pengeluaran',
          description: `${memberData.full_name} menolak pengeluaran: ${actionDialog.expense.description} - Rp ${actionDialog.expense.amount.toLocaleString('id-ID')}`,
          metadata: {
            expense_id: actionDialog.expense.id,
            amount: actionDialog.expense.amount,
            created_by: actionDialog.expense.created_by_name
          }
        });

        toast.success('Pengeluaran ditolak');
      }

      setActionDialog({ open: false, expense: null, action: null });
      loadPendingExpenses();
    } catch (error: any) {
      console.error('Error processing expense:', error);
      toast.error(`Gagal memproses pengeluaran: ${error.message}`);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Clock className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (pendingExpenses.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
        <CheckCircle className="h-8 w-8" />
        <p className="font-medium">Tidak ada pengeluaran pending</p>
        <p className="text-sm">Semua pengeluaran sudah diverifikasi</p>
      </div>
    );
  }

  return (
    <>
      {isMobile ? (
        <div className="space-y-3">
          {pendingExpenses.map((expense) => (
            <Card key={expense.id} className="w-full max-w-full overflow-hidden">
              <div className="p-3">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-14 w-14 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                    <Receipt className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-sm line-clamp-2">{expense.description}</h3>
                        <p className="text-xs text-muted-foreground">PIC: {expense.pic_name}</p>
                        <p className="text-xs text-muted-foreground">Oleh: {expense.created_by_name}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-mono font-bold bg-primary/10 px-2 py-0.5 rounded border border-primary/20">
                        {formatDateWIB(expense.expense_date)}
                      </span>
                      <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-700">
                        <DollarSign className="h-3 w-3 mr-1" />
                        Rp {expense.amount.toLocaleString('id-ID')}
                      </Badge>
                    </div>
                    {canVerify && (
                      <div className="flex gap-2 mt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => setActionDialog({ open: true, expense, action: 'approve' })}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Setujui
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => setActionDialog({ open: true, expense, action: 'reject' })}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Tolak
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tanggal</TableHead>
                <TableHead>Detail</TableHead>
                <TableHead>PIC</TableHead>
                <TableHead className="text-right">Jumlah</TableHead>
                <TableHead>Diinput Oleh</TableHead>
                {canVerify && <TableHead className="text-center">Aksi</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingExpenses.map((expense) => (
                <TableRow key={expense.id}>
                  <TableCell className="whitespace-nowrap">
                    {formatDateWIB(expense.expense_date)}
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate">
                    {expense.description}
                  </TableCell>
                  <TableCell>{expense.pic_name}</TableCell>
                  <TableCell className="text-right font-medium">
                    Rp {expense.amount.toLocaleString('id-ID')}
                  </TableCell>
                  <TableCell>{expense.created_by_name}</TableCell>
                  {canVerify && (
                    <TableCell>
                      <div className="flex gap-2 justify-center">
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => setActionDialog({ open: true, expense, action: 'approve' })}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => setActionDialog({ open: true, expense, action: 'reject' })}
                        >
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <AlertDialog open={actionDialog.open} onOpenChange={(open) => !open && setActionDialog({ open: false, expense: null, action: null })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionDialog.action === 'approve' ? 'Verifikasi' : 'Tolak'} Pengeluaran
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionDialog.action === 'approve' 
                ? `Apakah Anda yakin ingin memverifikasi pengeluaran "${actionDialog.expense?.description}" sebesar Rp ${actionDialog.expense?.amount.toLocaleString('id-ID')}?`
                : `Apakah Anda yakin ingin menolak pengeluaran "${actionDialog.expense?.description}" sebesar Rp ${actionDialog.expense?.amount.toLocaleString('id-ID')}? Pengeluaran ini akan dihapus.`
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleAction}>
              {actionDialog.action === 'approve' ? 'Verifikasi' : 'Tolak'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
