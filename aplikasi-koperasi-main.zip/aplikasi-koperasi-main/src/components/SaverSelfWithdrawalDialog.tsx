import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CurrencyInput } from "@/components/ui/currency-input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowDownCircle, Loader2, Wallet, Banknote, Building2, AlertTriangle, KeyRound } from "lucide-react";
import { formatRupiah } from "@/lib/utils";

interface SaverSelfWithdrawalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saverId: string;
  saverName: string;
  currentBalance: number;
  hasPin: boolean;
  onSuccess?: () => void;
}

export default function SaverSelfWithdrawalDialog({
  open,
  onOpenChange,
  saverId,
  saverName,
  currentBalance,
  hasPin,
  onSuccess,
}: SaverSelfWithdrawalDialogProps) {
  const [step, setStep] = useState<"form" | "pin">("form");
  const [amount, setAmount] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [accountHolder, setAccountHolder] = useState("");
  const [pin, setPin] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [pendingWithdrawalId, setPendingWithdrawalId] = useState<string | null>(null);

  const numericAmount = parseInt(amount || "0", 10);

  // Reset form when dialog opens/closes
  useEffect(() => {
    if (!open) {
      setStep("form");
      setAmount("");
      setNotes("");
      setPaymentMethod("cash");
      setBankName("");
      setAccountNumber("");
      setAccountHolder("");
      setPin("");
      setPendingWithdrawalId(null);
    }
  }, [open]);

  const handleFormSubmit = async () => {
    if (numericAmount <= 0) {
      toast.error("Jumlah penarikan harus lebih dari 0");
      return;
    }

    if (numericAmount > currentBalance) {
      toast.error("Saldo tidak mencukupi");
      return;
    }

    if (!hasPin) {
      toast.error("Anda belum mengatur PIN. Silakan atur PIN terlebih dahulu di halaman Profil.");
      return;
    }

    if (paymentMethod === "transfer") {
      if (!bankName.trim() || !accountNumber.trim() || !accountHolder.trim()) {
        toast.error("Lengkapi data rekening tujuan transfer");
        return;
      }
    }

    setIsSubmitting(true);
    try {
      // Check if there's already a pending withdrawal
      const { data: existingPending } = await supabase
        .from("saver_pending_withdrawals")
        .select("id")
        .eq("saver_id", saverId)
        .eq("status", "pending")
        .limit(1);

      if (existingPending && existingPending.length > 0) {
        toast.error("Anda masih memiliki penarikan yang menunggu konfirmasi");
        setIsSubmitting(false);
        return;
      }

      // Prepare payment details
      const paymentDetails = paymentMethod === "transfer"
        ? `${bankName} - ${accountNumber} a.n. ${accountHolder}`
        : null;

      // Create pending withdrawal
      const { data: insertedData, error: pendingError } = await supabase
        .from("saver_pending_withdrawals")
        .insert({
          saver_id: saverId,
          amount: numericAmount,
          payment_method: paymentMethod,
          payment_details: paymentDetails,
          notes: notes || "Pengajuan penarikan mandiri oleh debitur",
          status: "pending",
        })
        .select("id")
        .single();

      if (pendingError) throw pendingError;

      setPendingWithdrawalId(insertedData.id);
      setStep("pin");
      toast.info("Masukkan PIN untuk konfirmasi penarikan");
    } catch (error: any) {
      console.error("Error creating withdrawal:", error);
      toast.error(`Gagal mengajukan penarikan: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePinConfirm = async () => {
    if (pin.length !== 6) {
      toast.error("Masukkan PIN 6 digit");
      return;
    }

    if (!pendingWithdrawalId) {
      toast.error("ID penarikan tidak ditemukan");
      return;
    }

    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke("confirm-saver-withdrawal", {
        body: {
          withdrawal_id: pendingWithdrawalId,
          pin: pin,
          action: "confirm",
        },
      });

      if (error) {
        // Try to parse error body for PIN failure info
        let errorBody: any = null;
        const ctx = (error as any)?.context;
        if (ctx && typeof ctx.json === "function") {
          try {
            const res = typeof ctx.clone === "function" ? ctx.clone() : ctx;
            errorBody = await res.json();
          } catch {}
        }

        if (!errorBody) {
          const msg = String((error as any)?.message ?? "");
          const start = msg.indexOf("{");
          const end = msg.lastIndexOf("}");
          if (start !== -1 && end !== -1 && end > start) {
            try {
              errorBody = JSON.parse(msg.slice(start, end + 1));
            } catch {}
          }
        }

        if (errorBody) {
          if (errorBody.cancelled) {
            toast.error(errorBody.error || "Transaksi dibatalkan karena PIN salah 3x");
            onOpenChange(false);
            onSuccess?.();
            return;
          }

          if (errorBody.attempts !== undefined) {
            toast.error(`PIN salah. Percobaan: ${errorBody.attempts}/3`);
            setPin("");
            return;
          }
        }

        toast.error("Gagal mengkonfirmasi penarikan");
        setPin("");
        return;
      }

      if (data?.error) {
        if (data.cancelled) {
          toast.error(data.error);
          onOpenChange(false);
          onSuccess?.();
          return;
        }

        if (data.attempts !== undefined) {
          toast.error(`PIN salah. Percobaan: ${data.attempts}/3`);
          setPin("");
          return;
        }

        toast.error(data.error);
        setPin("");
        return;
      }

      toast.success("Penarikan berhasil dikonfirmasi! Menunggu persetujuan admin.");
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error("Error confirming withdrawal:", error);
      toast.error("Gagal mengkonfirmasi penarikan");
      setPin("");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = async () => {
    if (pendingWithdrawalId) {
      // Only cancel if still pending (not already confirmed/cancelled)
      await supabase
        .from("saver_pending_withdrawals")
        .update({ status: "cancelled", cancelled_at: new Date().toISOString(), cancel_reason: "Dibatalkan oleh debitur" })
        .eq("id", pendingWithdrawalId)
        .eq("status", "pending");
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(val) => !val && handleCancel()}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowDownCircle className="h-5 w-5 text-red-600" />
            Pengajuan Penarikan
          </DialogTitle>
        </DialogHeader>

        {step === "form" ? (
          <div className="space-y-4">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Debitur</p>
              <p className="font-semibold">{saverName}</p>
            </div>

            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4 text-primary" />
                <span className="text-sm">Saldo Tersedia</span>
              </div>
              <p className="text-xl font-bold text-primary">
                {formatRupiah(currentBalance)}
              </p>
            </div>

            {!hasPin && (
              <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-300 dark:border-red-800 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-700 dark:text-red-300">
                      PIN Belum Diatur
                    </p>
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                      Anda harus mengatur PIN terlebih dahulu di halaman Profil untuk dapat melakukan penarikan.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah Penarikan</Label>
              <CurrencyInput
                id="amount"
                value={amount}
                onChange={(val) => setAmount(val)}
                placeholder="Masukkan jumlah penarikan"
              />
              {numericAmount > currentBalance && (
                <p className="text-sm text-destructive">Saldo tidak mencukupi</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Metode Pencairan</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">
                    <div className="flex items-center gap-2">
                      <Banknote className="h-4 w-4 text-green-600" />
                      <span>Tunai (Cash)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="transfer">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-blue-500" />
                      <span>Transfer Bank</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {paymentMethod === "transfer" && (
              <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                <div className="space-y-2">
                  <Label htmlFor="bank-name">Nama Bank</Label>
                  <Input
                    id="bank-name"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value.toUpperCase())}
                    placeholder="Contoh: BCA, BNI, MANDIRI"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="account-number">Nomor Rekening</Label>
                  <Input
                    id="account-number"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ""))}
                    placeholder="Masukkan nomor rekening"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="account-holder">Nama Pemilik Rekening</Label>
                  <Input
                    id="account-holder"
                    value={accountHolder}
                    onChange={(e) => setAccountHolder(e.target.value.toUpperCase())}
                    placeholder="Nama sesuai rekening"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="notes">Catatan (Opsional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Catatan tambahan..."
                rows={2}
              />
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-sm text-amber-700 dark:text-amber-300">
                ⚠️ Setelah konfirmasi PIN, penarikan akan menunggu verifikasi terlebih dahulu. Chat admin untuk info lebih lanjut.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Jumlah Penarikan</span>
                <span className="text-xl font-bold text-destructive">
                  {formatRupiah(numericAmount)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Metode</span>
                <div className="flex items-center gap-1">
                  {paymentMethod === "transfer" ? (
                    <>
                      <Building2 className="h-4 w-4 text-blue-500" />
                      <span>Transfer Bank</span>
                    </>
                  ) : (
                    <>
                      <Banknote className="h-4 w-4 text-green-600" />
                      <span>Tunai</span>
                    </>
                  )}
                </div>
              </div>
              {paymentMethod === "transfer" && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">Rekening Tujuan:</p>
                  <p className="text-sm font-medium">
                    {bankName} - {accountNumber} a.n. {accountHolder}
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-center block flex items-center justify-center gap-2">
                <KeyRound className="h-4 w-4" />
                Masukkan PIN untuk konfirmasi
              </Label>
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={pin}
                  onChange={setPin}
                  disabled={isSubmitting}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>
          </div>
        )}

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={handleCancel} disabled={isSubmitting}>
            Batal
          </Button>
          {step === "form" ? (
            <Button
              onClick={handleFormSubmit}
              disabled={isSubmitting || numericAmount <= 0 || numericAmount > currentBalance || !hasPin}
            >
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Lanjutkan
            </Button>
          ) : (
            <Button
              onClick={handlePinConfirm}
              disabled={isSubmitting || pin.length !== 6}
            >
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Konfirmasi
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
