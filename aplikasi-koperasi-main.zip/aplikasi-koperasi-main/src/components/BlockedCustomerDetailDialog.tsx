import { useState, useEffect } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { formatDate, calculateAge, formatRupiah } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { AlertTriangle, Ban, ShieldCheck, Calendar, Phone, MapPin, CreditCard, User, Clock, FileText, TrendingDown, Info } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface BlockedCustomerDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  blockedCustomer: any;
  canRestore?: boolean;
  onRestore?: (customer: any) => void;
}

export function BlockedCustomerDetailDialog({
  open,
  onOpenChange,
  blockedCustomer,
  canRestore = false,
  onRestore,
}: BlockedCustomerDetailDialogProps) {
  const { isOwner, isAdmin } = useUserRole();
  const canManage = isOwner || isAdmin;
  const [applications, setApplications] = useState<any[]>([]);
  const [loadingApplications, setLoadingApplications] = useState(false);
  const [blockHistory, setBlockHistory] = useState<any[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [activeCredits, setActiveCredits] = useState<any[]>([]);
  const [loadingActiveCredits, setLoadingActiveCredits] = useState(false);
  const [totalOverdueInstallments, setTotalOverdueInstallments] = useState(0);
  const [autoBlockThreshold, setAutoBlockThreshold] = useState<number>(3.7);

  // Load auto block threshold
  useEffect(() => {
    const loadThreshold = async () => {
      const { data: appSettings } = await supabase.rpc('get_public_app_settings');
      const threshold = (appSettings as any)?.auto_block_threshold || 3.7;
      setAutoBlockThreshold(threshold);
    };
    loadThreshold();
  }, []);

  // Load credit applications
  useEffect(() => {
    if (!open || !blockedCustomer?.customer_id) return;

    const loadApplications = async () => {
      setLoadingApplications(true);
      try {
        const { data } = await supabase
          .from("credit_applications")
          .select(`
            *,
            members(full_name)
          `)
          .eq("customer_id", blockedCustomer.customer_id)
          .order("created_at", { ascending: false });

        setApplications(data || []);
      } catch (error) {
        console.error("Error loading applications:", error);
      } finally {
        setLoadingApplications(false);
      }
    };

    loadApplications();
  }, [open, blockedCustomer]);

  // Load block history
  useEffect(() => {
    if (!open || !blockedCustomer?.customer_id) return;

    const loadBlockHistory = async () => {
      setLoadingHistory(true);
      try {
        const { data } = await supabase
          .from("block_history")
          .select("*")
          .eq("customer_id", blockedCustomer.customer_id)
          .order("blocked_at", { ascending: false});

        setBlockHistory(data || []);
      } catch (error) {
        console.error("Error loading block history:", error);
      } finally {
        setLoadingHistory(false);
      }
    };

    loadBlockHistory();
  }, [open, blockedCustomer]);

  // Load total overdue installments (including paid ones with penalty)
  useEffect(() => {
    if (!open || !blockedCustomer?.customer_id) return;

    const loadTotalOverdueInstallments = async () => {
      try {
        // First, get all application IDs for this customer
        const { data: apps } = await supabase
          .from("credit_applications")
          .select("id")
          .eq("customer_id", blockedCustomer.customer_id);
        
        if (!apps || apps.length === 0) {
          setTotalOverdueInstallments(0);
          return;
        }

        const appIds = apps.map(a => a.id);
        
        // Count all installments that were ever overdue (have frozen_penalty > 0 or currently overdue)
        const { count } = await supabase
          .from("installments")
          .select("*", { count: "exact", head: true })
          .in("application_id", appIds)
          .or("frozen_penalty.gt.0,status.eq.overdue");
        
        setTotalOverdueInstallments(count || 0);
      } catch (error) {
        console.error("Error loading total overdue installments:", error);
        setTotalOverdueInstallments(0);
      }
    };

    loadTotalOverdueInstallments();
  }, [open, blockedCustomer]);

  // Load active/incomplete credits with installment details
  useEffect(() => {
    if (!open || !blockedCustomer?.customer_id) return;

    const loadActiveCredits = async () => {
      setLoadingActiveCredits(true);
      try {
        const { data, error } = await supabase
          .from("credit_applications")
          .select(`
            *,
            members(full_name),
            installments(
              id,
              installment_number,
              due_date,
              total_amount,
              paid_amount,
              status,
              principal_paid
            )
          `)
          .eq("customer_id", blockedCustomer.customer_id)
          .in("status", ["approved", "disbursed"])
          .order("created_at", { ascending: false });

        if (error) {
          console.error("Error loading active credits:", error);
        } else {
          console.log("Active credits loaded:", data);
          setActiveCredits(data || []);
        }
      } catch (error) {
        console.error("Error loading active credits:", error);
      } finally {
        setLoadingActiveCredits(false);
      }
    };

    loadActiveCredits();
  }, [open, blockedCustomer]);

  if (!blockedCustomer) return null;

  const isPermanentlyBlocked = blockedCustomer.customers?.restoration_status === 'permanently_blocked';
  const showRestoreButton = canManage && !isPermanentlyBlocked && onRestore;

  // Helper function untuk format blocked_reason dengan threshold dinamis
  const formatBlockedReason = (reason: string) => {
    const isAutoBlock = reason?.toLowerCase().includes('skor kredit rendah') || 
                        reason?.toLowerCase().includes('diblokir otomatis') ||
                        reason?.toLowerCase().includes('3.7') ||
                        reason?.toLowerCase().includes('2.5') ||
                        reason?.toLowerCase().includes('≤') ||
                        reason?.toLowerCase().includes('threshold');
    
    if (isAutoBlock && blockedCustomer.customers?.credit_score) {
      // Replace any hardcoded threshold dengan threshold dinamis
      return reason.replace(/(\d+\.?\d*)\s*bintang.*?minimum\s*(\d+\.?\d*)/i, 
        `${blockedCustomer.customers.credit_score.toFixed(2)} bintang (minimum ${autoBlockThreshold})`)
        .replace(/threshold\s*[≤<=]\s*\d+\.?\d*/i, `threshold ≤ ${autoBlockThreshold}`)
        .replace(/skor\s*kredit\s*rendah.*?\)/i, `skor kredit rendah (≤${autoBlockThreshold})`);
    }
    return reason;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: any; label: string }> = {
      pending: { variant: "outline", label: "Pending" },
      approved: { variant: "secondary", label: "Disetujui" },
      disbursed: { variant: "default", label: "Dicairkan" },
      rejected: { variant: "destructive", label: "Ditolak" },
      completed: { variant: "default", label: "Selesai" },
    };
    const config = variants[status] || { variant: "outline", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-3xl w-full max-h-[95vh] overflow-y-auto">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle className="flex items-center gap-2 text-base sm:text-lg">
            <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />
            <span className="truncate">Detail Nasabah Diblokir</span>
          </ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="space-y-6 py-4">{/* Removed ScrollArea wrapper */}
            {/* Profile Header Card */}
            <Card className="border-l-4 border-l-destructive">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-6">
                  <div className="flex flex-col items-center sm:items-start gap-3">
                    <ClickableAvatar
                      src={blockedCustomer.customers?.photo_url}
                      alt={blockedCustomer.customers?.full_name}
                      fallback={blockedCustomer.customers?.full_name?.substring(0, 2).toUpperCase()}
                      className="h-24 w-24 sm:h-28 sm:w-28"
                      fallbackClassName="bg-destructive/10 text-destructive text-2xl font-bold"
                    />
                    <div className="text-center sm:text-left">
                      {isPermanentlyBlocked ? (
                        <Badge variant="destructive" className="gap-1.5">
                          <Ban className="h-3.5 w-3.5" />
                          Blokir Permanen
                        </Badge>
                      ) : (
                        <Badge variant="destructive">Diblokir</Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex-1 space-y-3">
                    <div>
                      <h3 className="font-bold text-xl sm:text-2xl">{blockedCustomer.customers?.full_name}</h3>
                      <p className="text-muted-foreground text-sm font-bold">{blockedCustomer.customers?.id_number}</p>
                    </div>
                    {/* CRITICAL: Gunakan credit_score langsung dari database tanpa fallback */}
                    <CreditScoreStars 
                      creditScore={blockedCustomer.customers?.credit_score ?? 0} 
                      restorationStatus={blockedCustomer.customers?.restoration_status || 'never_restored'} 
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <InfoItem icon={<Phone className="h-4 w-4" />} label="Telepon" value={blockedCustomer.customers?.phone} />
                      <InfoItem icon={<CreditCard className="h-4 w-4" />} label="NIK" value={blockedCustomer.customers?.nik || "-"} />
                      <InfoItem 
                        icon={<Calendar className="h-4 w-4" />} 
                        label="Tanggal Lahir" 
                        value={blockedCustomer.customers?.date_of_birth 
                          ? `${formatDate(blockedCustomer.customers.date_of_birth)} (${calculateAge(blockedCustomer.customers.date_of_birth)} th)` 
                          : "-"
                        } 
                      />
                      <InfoItem icon={<MapPin className="h-4 w-4" />} label="Alamat" value={blockedCustomer.customers?.address} />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Block Information Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                  Informasi Pemblokiran
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <DetailRow 
                  label="Tanggal Diblokir" 
                  value={formatDate(blockedCustomer.blocked_at)}
                  icon={<Clock className="h-4 w-4" />}
                />
                <DetailRow 
                  label="Alasan Pemblokiran" 
                  value={formatBlockedReason(blockedCustomer.blocked_reason)}
                  icon={<Info className="h-4 w-4" />}
                />
                <DetailRow 
                  label="Diblokir Oleh" 
                  value={blockedCustomer.blocked_by === null ? "Sistem (Otomatis)" : (blockedCustomer.blocker?.full_name || "-")}
                  icon={<User className="h-4 w-4" />}
                />
                <DetailRow 
                  label="Angsuran Menunggak" 
                  value={`${totalOverdueInstallments} angsuran`}
                  icon={<TrendingDown className="h-4 w-4" />}
                />
                
                {isPermanentlyBlocked && (
                  <div className="bg-destructive/10 p-4 rounded-lg border border-destructive/20 mt-4">
                    <div className="flex gap-3">
                      <Ban className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold text-destructive mb-1">Status Blokir Permanen</p>
                        <p className="text-xs text-destructive/80">
                          Nasabah ini telah diblokir secara permanen dan tidak dapat dipulihkan melalui sistem.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Tabs for Additional Information */}
            <Tabs defaultValue="activeCredits" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="activeCredits">
                  <TrendingDown className="h-4 w-4 mr-2" />
                  Kredit Aktif ({activeCredits.length})
                </TabsTrigger>
                <TabsTrigger value="applications">
                  <FileText className="h-4 w-4 mr-2" />
                  Riwayat ({applications.length})
                </TabsTrigger>
                <TabsTrigger value="history">
                  <Clock className="h-4 w-4 mr-2" />
                  Blokir ({blockHistory.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="activeCredits" className="space-y-3 mt-4">
                {loadingActiveCredits ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  </div>
                ) : activeCredits.length === 0 ? (
                  <Card>
                    <CardContent className="p-8 text-center text-muted-foreground">
                      <TrendingDown className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Tidak ada kredit aktif</p>
                    </CardContent>
                  </Card>
                ) : (
                  activeCredits.map((credit) => {
                    const installments = credit.installments || [];
                    const totalInstallments = installments.length;
                    const paidInstallments = installments.filter((i: any) => i.status === 'paid').length;
                    const overdueInstallments = installments.filter((i: any) => 
                      i.status === 'overdue' || (i.status === 'unpaid' && new Date(i.due_date) < new Date())
                    ).length;
                    const totalPaid = installments.reduce((sum: number, i: any) => sum + (Number(i.paid_amount) || 0), 0);
                    const totalAmount = installments.reduce((sum: number, i: any) => sum + (Number(i.total_amount) || 0), 0);
                    const remainingAmount = totalAmount - totalPaid;

                    return (
                      <Card key={credit.id} className="border-l-4 border-l-destructive">
                        <CardContent className="p-4">
                          <div className="space-y-4">
                            {/* Header */}
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-bold text-lg">{credit.application_number}</p>
                                <p className="text-sm text-muted-foreground">{formatDate(credit.application_date)}</p>
                                <p className="text-xs text-muted-foreground mt-1">Sales: {credit.members?.full_name || "-"}</p>
                              </div>
                              {getStatusBadge(credit.status)}
                            </div>

                            <Separator />

                            {/* Credit Summary */}
                            <div className="grid grid-cols-2 gap-3">
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">Total Pinjaman</p>
                                <p className="font-bold text-base">{formatRupiah(credit.amount_approved || credit.amount_requested)}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">Tenor</p>
                                <p className="font-bold text-base">{credit.tenor_months} bulan</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">Total Dibayar</p>
                                <p className="font-bold text-base text-green-600">{formatRupiah(totalPaid)}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">Sisa Tagihan</p>
                                <p className="font-bold text-base text-destructive">{formatRupiah(remainingAmount)}</p>
                              </div>
                            </div>

                            {/* Installment Progress */}
                            <div className="space-y-2">
                              <div className="flex justify-between items-center text-sm">
                                <span className="text-muted-foreground">Progress Angsuran</span>
                                <span className="font-semibold">{paidInstallments}/{totalInstallments} terbayar</span>
                              </div>
                              <div className="w-full bg-muted rounded-full h-2.5">
                                <div 
                                  className="bg-primary h-2.5 rounded-full transition-all" 
                                  style={{ width: `${totalInstallments > 0 ? (paidInstallments / totalInstallments) * 100 : 0}%` }}
                                ></div>
                              </div>
                              {overdueInstallments > 0 && (
                                <p className="text-xs text-destructive font-semibold">
                                  ⚠️ {overdueInstallments} angsuran menunggak
                                </p>
                              )}
                            </div>

                            {/* Installment Details */}
                            {installments.length > 0 && (
                              <div className="space-y-2">
                                <p className="text-sm font-semibold">Detail Angsuran:</p>
                                <div className="max-h-40 overflow-y-auto space-y-2">
                                  {installments.slice(0, 5).map((inst: any) => (
                                    <div key={inst.id} className="flex justify-between items-center p-2 rounded bg-muted/50 text-xs">
                                      <div className="flex items-center gap-2">
                                        <Badge variant={
                                          inst.status === 'paid' ? 'default' : 
                                          inst.status === 'overdue' ? 'destructive' : 
                                          'outline'
                                        } className="text-[10px]">
                                          {inst.status === 'paid' ? 'Lunas' : 
                                           inst.status === 'overdue' ? 'Terlambat' : 
                                           'Belum'}
                                        </Badge>
                                        <span>Angsuran #{inst.installment_number}</span>
                                      </div>
                                      <div className="text-right">
                                        <p className="font-semibold">{formatRupiah(inst.total_amount)}</p>
                                        <p className="text-muted-foreground">{formatDate(inst.due_date)}</p>
                                      </div>
                                    </div>
                                  ))}
                                  {installments.length > 5 && (
                                    <p className="text-center text-muted-foreground text-xs">
                                      +{installments.length - 5} angsuran lainnya
                                    </p>
                                  )}
                                </div>
                              </div>
                            )}

                            {/* Tujuan Pinjaman */}
                            {credit.purpose && (
                              <div className="pt-2 border-t">
                                <p className="text-xs text-muted-foreground mb-1">Tujuan Pinjaman:</p>
                                <p className="text-sm">{credit.purpose}</p>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </TabsContent>

              <TabsContent value="applications" className="space-y-3 mt-4">
                {loadingApplications ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  </div>
                ) : applications.length === 0 ? (
                  <Card>
                    <CardContent className="p-8 text-center text-muted-foreground">
                      <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Tidak ada riwayat pengajuan kredit</p>
                    </CardContent>
                  </Card>
                ) : (
                  applications.map((app) => (
                    <Card key={app.id}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-semibold">{app.application_number}</p>
                            <p className="text-sm text-muted-foreground">{formatDate(app.application_date)}</p>
                          </div>
                          {getStatusBadge(app.status)}
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm mt-3">
                          <div>
                            <p className="text-muted-foreground text-xs">Jumlah Pinjaman</p>
                            <p className="font-semibold">{formatRupiah(app.amount_approved || app.amount_requested)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Tenor</p>
                            <p className="font-semibold">{app.tenor_months} bulan</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Bunga</p>
                            <p className="font-semibold">{app.interest_rate}%</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Sales</p>
                            <p className="font-semibold text-xs truncate">{app.members?.full_name || "-"}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="history" className="space-y-3 mt-4">
                {loadingHistory ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  </div>
                ) : blockHistory.length === 0 ? (
                  <Card>
                    <CardContent className="p-8 text-center text-muted-foreground">
                      <Clock className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Tidak ada riwayat pemblokiran sebelumnya</p>
                    </CardContent>
                  </Card>
                ) : (
                  blockHistory.map((history, index) => (
                    <Card key={history.id}>
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className="h-8 w-8 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0">
                              <AlertTriangle className="h-4 w-4 text-destructive" />
                            </div>
                            {index < blockHistory.length - 1 && (
                              <div className="w-0.5 flex-1 bg-border mt-2" />
                            )}
                          </div>
                          <div className="flex-1 pb-4">
                            <p className="font-semibold text-sm">{formatDate(history.blocked_at)}</p>
                            <p className="text-sm text-muted-foreground mt-1">{history.reason || "Tidak ada alasan"}</p>
                            {history.customer_nik && (
                              <p className="text-xs text-muted-foreground mt-1">NIK: {history.customer_nik}</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>

        {/* Restore button for owner/admin */}
        {showRestoreButton && (
          <div className="sticky bottom-0 left-0 right-0 bg-background border-t pt-4 pb-2">
            <Button
              className="w-full"
              size="lg"
              onClick={() => {
                onRestore(blockedCustomer);
                onOpenChange(false);
              }}
            >
              <ShieldCheck className="h-4 w-4 mr-2" />
              Pulihkan Nasabah
            </Button>
          </div>
        )}
      </ResponsiveDialogContent>
    </ResponsiveDialog>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-2">
      <div className="text-muted-foreground mt-0.5">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium truncate">{value}</p>
      </div>
    </div>
  );
}

function DetailRow({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
      {icon && <div className="text-muted-foreground mt-0.5">{icon}</div>}
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
        <p className="text-sm font-semibold break-words">{value}</p>
      </div>
    </div>
  );
}
