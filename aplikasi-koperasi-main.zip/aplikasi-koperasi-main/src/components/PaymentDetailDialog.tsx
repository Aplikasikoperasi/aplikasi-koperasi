import { useState, useEffect } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatDate, formatRupiah, roundToThousand, cn } from "@/lib/utils";
import { CheckCircle, AlertCircle, MessageSquare, Edit, Trash2, Crown, Shield, Briefcase, Wallet } from "lucide-react";
import { generatePaymentReceiptMessage, openWhatsAppChat } from "@/lib/whatsappHelper";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "@/hooks/useUserRole";
import { EditPaymentDialog } from "./EditPaymentDialog";
import { PenaltyPaymentDialog } from "./PenaltyPaymentDialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useInvalidateInstallments } from "@/hooks/useInstallmentsQuery";
import { useInvalidatePayments } from "@/hooks/usePaymentsQuery";

interface PaymentDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  payment: any;
}

export function PaymentDetailDialog({
  open,
  onOpenChange,
  payment,
}: PaymentDetailDialogProps) {
  const { toast } = useToast();
  const { isOwner, isAdmin } = useUserRole();
  const invalidateInstallments = useInvalidateInstallments();
  const invalidatePayments = useInvalidatePayments();
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showPenaltyDialog, setShowPenaltyDialog] = useState(false);
  const [superCode, setSuperCode] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [localPayment, setLocalPayment] = useState(payment);
  const [penaltyRate, setPenaltyRate] = useState(0);
  
  useEffect(() => {
    setLocalPayment(payment);
  }, [payment]);

  useEffect(() => {
    const fetchPenaltyRate = async () => {
      const { data: settings } = await supabase
        .from("app_settings")
        .select("penalty_rate_per_day")
        .single();
      
      setPenaltyRate(settings?.penalty_rate_per_day || 0);
    };
    
    fetchPenaltyRate();
  }, []);

  const handleRefreshPayment = async () => {
    try {
      const { data: refreshedPayment } = await supabase
        .from("payments")
        .select(`
          *,
          credit_applications!inner (
            id,
            application_date,
            application_number,
            customer_id,
            tenor_months,
            customers (full_name, id_number, photo_url, phone, credit_score, date_of_birth)
          ),
          installments (
            installment_number,
            frozen_penalty,
            frozen_days_overdue,
            paid_amount,
            total_amount,
            due_date,
            principal_amount
          )
        `)
        .eq("id", localPayment.id)
        .single();

      if (refreshedPayment) {
        // Fetch creator member name based on created_by (user_id)
        let creatorMember = null;
        if (refreshedPayment.created_by) {
          const { data: memberData } = await supabase
            .from("members")
            .select("full_name, member_number, position")
            .eq("user_id", refreshedPayment.created_by)
            .maybeSingle();
          
          creatorMember = memberData;
        }
        
        setLocalPayment({
          ...refreshedPayment,
          creator_member: creatorMember,
        });
      }
      
      // Invalidate queries to ensure parent lists are refreshed too
      invalidateInstallments();
      invalidatePayments();
    } catch (error) {
      console.error("Error refreshing payment:", error);
    }
  };

  // Setup realtime subscription for installment updates
  useEffect(() => {
    if (!localPayment?.installment_id || !open) return;

    const channel = supabase
      .channel(`installment-${localPayment.installment_id}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'installments',
          filter: `id=eq.${localPayment.installment_id}`
        },
        () => {
          handleRefreshPayment();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [localPayment?.installment_id, open]);
  
  if (!localPayment) return null;

  const totalAmount = Number(localPayment.installments?.total_amount || 0);
  const paidAmount = Number(localPayment.installments?.paid_amount || 0);
  const frozenPenalty = Number(localPayment.installments?.frozen_penalty || 0);
  const frozenDaysOverdue = Number(localPayment.installments?.frozen_days_overdue || 0);
  const dueDate = localPayment.installments?.due_date;
  
  // Calculate actual days overdue from payment_date vs due_date for display only
  let actualDaysOverdue = 0;
  let calculatedPenalty = 0;
  
  if (dueDate && localPayment.payment_date) {
    const dueDateObj = new Date(dueDate);
    const paymentDateObj = new Date(localPayment.payment_date);
    
    if (paymentDateObj > dueDateObj) {
      actualDaysOverdue = Math.floor((paymentDateObj.getTime() - dueDateObj.getTime()) / (1000 * 60 * 60 * 24));
      
      // Calculate daily penalty with rounding to thousand, then multiply by days
      const dailyPenalty = roundToThousand(totalAmount * penaltyRate / 100);
      calculatedPenalty = dailyPenalty * actualDaysOverdue;
    }
  }
  
  // FIX: Status harus memeriksa frozen_penalty dari database, bukan calculatedPenalty
  const isFullyPaid = paidAmount >= totalAmount && frozenPenalty === 0;
  const isPartialPaid = paidAmount > 0 && frozenPenalty > 0;
  const hasUnpaidPenalty = frozenPenalty > 0;
  const hasPenaltyInfo = actualDaysOverdue > 0 || frozenPenalty > 0 || frozenDaysOverdue > 0;

  const canEdit = isOwner || isAdmin;

  const handleDeletePayment = async () => {
    if (!superCode) return;
    
    setIsDeleting(true);
    try {
      // Verify SuperCode
      const { data: verifyData, error: verifyError } = await supabase.functions.invoke(
        'verify-supercode',
        {
          body: { 
            superCodeInput: superCode,
            operation: 'delete_payment'
          }
        }
      );

      if (verifyError || !verifyData?.valid) {
        toast({
          title: "SuperCode Salah",
          description: "Kode yang Anda masukkan tidak valid",
          variant: "destructive",
        });
        setIsDeleting(false);
        return;
      }

      // Delete payment
      const { error: deleteError } = await supabase
        .from('payments')
        .delete()
        .eq('id', localPayment.id);

      if (deleteError) throw deleteError;

      toast({
        title: "Berhasil",
        description: "Pembayaran berhasil dihapus",
      });

      // Invalidate queries to refresh data immediately
      invalidateInstallments();
      invalidatePayments();

      // Close dialogs and trigger refresh
      setShowDeleteDialog(false);
      setSuperCode("");
      onOpenChange(false);
      
      // Trigger page refresh event (legacy support)
      window.dispatchEvent(new Event('payments-updated'));
      window.dispatchEvent(new Event('installments-updated'));
      
    } catch (error: any) {
      console.error('Error deleting payment:', error);
      toast({
        title: "Error",
        description: error.message || "Gagal menghapus pembayaran",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-md w-full max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>Detail Pembayaran</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="w-full max-w-full space-y-4 overflow-hidden">
          {/* Customer Info */}
          <div className="flex items-start gap-4">
            <ClickableAvatar 
              src={payment.installments?.credit_applications?.customers?.photo_url || payment.credit_applications?.customers?.photo_url}
              alt={payment.installments?.credit_applications?.customers?.full_name || payment.credit_applications?.customers?.full_name}
              fallback={(payment.installments?.credit_applications?.customers?.full_name || payment.credit_applications?.customers?.full_name)?.substring(0, 2).toUpperCase()}
              className="h-16 w-16 sm:h-20 sm:w-20 flex-shrink-0"
              fallbackClassName="bg-primary/10 text-primary text-lg sm:text-xl"
            />
            <div className="flex-1 min-w-0 space-y-1">
              <h3 className="font-bold text-base sm:text-lg truncate">{payment.installments?.credit_applications?.customers?.full_name || payment.credit_applications?.customers?.full_name}</h3>
              <p className="text-xs sm:text-sm text-muted-foreground truncate">{payment.installments?.credit_applications?.customers?.id_number || payment.credit_applications?.customers?.id_number}</p>
              <div className="flex flex-wrap items-center gap-2">
                {isFullyPaid && (
                  <Badge className="bg-green-600 text-xs">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Lunas
                  </Badge>
                )}
                {isPartialPaid && (
                  <Badge className="bg-yellow-600 text-xs">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    Masih Ada Denda
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Payment Details */}
          <div className="space-y-2 text-xs sm:text-sm">
            <DetailRow label="Angsuran Ke" value={`${localPayment.installments?.installment_number || "-"} / ${localPayment.installments?.credit_applications?.tenor_months || localPayment.credit_applications?.tenor_months || "-"}`} />
            <DetailRow 
              label="Angsuran Pokok" 
              value={formatRupiah(totalAmount)}
              valueClassName="text-green-600 dark:text-green-400"
            />
            {dueDate && (
              <DetailRow label="Tgl Jatuh Tempo" value={formatDate(dueDate)} />
            )}
            <DetailRow 
              label="Tanggal Bayar" 
              value={formatDate(localPayment.payment_date)}
              valueClassName={
                dueDate && new Date(localPayment.payment_date) > new Date(dueDate)
                  ? "text-red-600 dark:text-red-400"
                  : "text-green-600 dark:text-green-400"
              }
            />
            <DetailRow label="Metode Bayar" value={localPayment.payment_method} />
            {localPayment.reference_number && (
              <DetailRow label="No. Referensi" value={localPayment.reference_number} />
            )}
            <Separator />
            {hasPenaltyInfo && (
              <>
                {/* Tampilkan lama hari denda dari frozen_days_overdue jika ada, atau actualDaysOverdue */}
                <DetailRow 
                  label="Lama Hari Denda" 
                  value={frozenDaysOverdue > 0 ? `${frozenDaysOverdue} hari` : (actualDaysOverdue > 0 ? `${actualDaysOverdue} hari` : "0 hari")} 
                />
                <DetailRow 
                  label="Denda Per Hari" 
                  value={`${formatRupiah(roundToThousand(totalAmount * penaltyRate / 100))} (${penaltyRate}%)`} 
                />
                {/* Total Denda = Lama Hari Denda × Denda Per Hari */}
                <DetailRow 
                  label="Total Denda" 
                  value={formatRupiah(
                    (frozenDaysOverdue > 0 ? frozenDaysOverdue : actualDaysOverdue) * roundToThousand(totalAmount * penaltyRate / 100)
                  )}
                  valueClassName="text-yellow-600 dark:text-yellow-400"
                />
              </>
            )}
            <DetailRow 
              label="Jumlah Bayar" 
              value={formatRupiah(Number(localPayment.amount))}
              valueClassName="text-green-600 dark:text-green-400"
            />
            {/* FIX: Tampilkan Sisa Denda jika ada frozen_penalty, meskipun belum ada pembayaran denda */}
            {hasUnpaidPenalty && (
              <DetailRow 
                label="Sisa Denda" 
                value={formatRupiah(frozenPenalty)}
                valueClassName="text-red-600 dark:text-red-400"
              />
            )}
            {localPayment.notes && (
              <DetailRow label="Catatan" value={localPayment.notes} />
            )}
            <Separator />
            <div className="flex justify-between gap-2 sm:gap-4">
              <span className="text-muted-foreground font-medium min-w-[90px] sm:min-w-[100px] text-xs sm:text-sm">Petugas:</span>
              <div className="text-right flex-1 break-words text-xs sm:text-sm font-semibold flex items-center justify-end gap-2 flex-wrap">
                <span>{localPayment.creator_member?.full_name || localPayment.members?.full_name || "Sistem"}</span>
                {localPayment.creator_member?.position && (
                  <Badge 
                    className={cn(
                      "text-xs font-semibold shadow-sm w-fit capitalize inline-flex items-center gap-1",
                      localPayment.creator_member.position.toLowerCase() === 'owner' && "bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 text-white border-purple-300 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]",
                      localPayment.creator_member.position.toLowerCase() === 'admin' && "bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-600 text-white border-blue-300 shadow-md animate-shimmer animate-glow bg-[length:200%_100%]",
                      localPayment.creator_member.position.toLowerCase() === 'sales' && "bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600 text-white border-orange-300 shadow-sm animate-shimmer bg-[length:200%_100%]",
                      localPayment.creator_member.position.toLowerCase() === 'kasir' && "bg-gradient-to-r from-teal-500 via-cyan-400 to-teal-600 text-white border-teal-300 shadow-sm animate-shimmer bg-[length:200%_100%]"
                    )}
                  >
                    {localPayment.creator_member.position.toLowerCase() === 'owner' && <Crown className="h-3 w-3" />}
                    {localPayment.creator_member.position.toLowerCase() === 'admin' && <Shield className="h-3 w-3" />}
                    {localPayment.creator_member.position.toLowerCase() === 'sales' && <Briefcase className="h-3 w-3" />}
                    {localPayment.creator_member.position.toLowerCase() === 'kasir' && <Wallet className="h-3 w-3" />}
                    {localPayment.creator_member.position}
                  </Badge>
                )}
              </div>
            </div>
            <DetailRow label="Tgl Dicatat" value={formatDate(localPayment.created_at)} />
          </div>

          {/* Action Buttons */}
          <div className="sticky bottom-0 left-0 right-0 bg-background border-t pt-4 -mx-4 px-4 pb-4 space-y-2">
            {hasUnpaidPenalty && canEdit && (
              <Button 
                variant="default"
                className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
                onClick={() => setShowPenaltyDialog(true)}
              >
                <AlertCircle className="h-4 w-4 mr-2" />
                Bayar Denda ({formatRupiah(frozenPenalty)})
              </Button>
            )}
            
            {canEdit && (
              <>
                <Button 
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowEditDialog(true)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Pembayaran
                </Button>
                
                <Button 
                  variant="destructive"
                  className="w-full"
                  onClick={() => setShowDeleteDialog(true)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Hapus Pembayaran
                </Button>
              </>
            )}
            
            <Button 
              variant="outline"
              className="w-full bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
              onClick={async () => {
                try {
                  // 1) Coba pakai data yang sudah ada dulu (dua kemungkinan relasi)
                  let customerData =
                    localPayment.installments?.credit_applications?.customers ||
                    localPayment.credit_applications?.customers;
                  let customerPhone = customerData?.phone?.trim() || '';

                  // Simpan applicationNumber (untuk pesan) dari beberapa sumber
                  let applicationNumber =
                    localPayment.credit_applications?.application_number ||
                    localPayment.installments?.credit_applications?.application_number ||
                    '';

                  // 2) Cari customer_id yang paling akurat
                  let customerId: string | null =
                    (localPayment as any)?.credit_applications?.customer_id || null;

                  // Jika customer_id belum ada, coba dapatkan via application_id (lebih stabil)
                  if (!customerId) {
                    const applicationId: string | undefined =
                      (localPayment as any)?.application_id ||
                      (localPayment as any)?.installments?.application_id ||
                      (localPayment as any)?.installments?.credit_applications?.id;

                    if (applicationId) {
                      const { data: appRow, error: appErr } = await supabase
                        .from('credit_applications')
                        .select('customer_id, application_number')
                        .eq('id', applicationId)
                        .maybeSingle();

                      if (appErr) {
                        console.error('Error fetching application:', appErr);
                      }

                      if (appRow) {
                        customerId = appRow.customer_id || customerId;
                        applicationNumber = appRow.application_number || applicationNumber;
                      }
                    }
                  }

                  // 3) Selalu fetch data pelanggan lengkap untuk memastikan id_number dan date_of_birth ada
                  if (!customerId) {
                    toast({
                      title: 'Error',
                      description: 'Data nasabah tidak ditemukan',
                      variant: 'destructive',
                    });
                    return;
                  }

                  const { data: fetchedData, error: customerError } = await supabase
                    .from('customers')
                    .select('phone, full_name, id_number, credit_score, date_of_birth')
                    .eq('id', customerId)
                    .maybeSingle();

                  if (customerError) {
                    console.error('Error fetching customer:', customerError);
                    toast({
                      title: 'Error',
                      description: 'Gagal mengambil data nasabah',
                      variant: 'destructive',
                    });
                    return;
                  }

                  if (!fetchedData) {
                    toast({
                      title: 'Error',
                      description: 'Data nasabah tidak ditemukan',
                      variant: 'destructive',
                    });
                    return;
                  }

                  customerData = fetchedData;
                  customerPhone = fetchedData.phone?.trim() || '';

                  if (!customerPhone) {
                    toast({
                      title: 'Error',
                      description: 'Nomor telepon nasabah tidak tersedia',
                      variant: 'destructive',
                    });
                    return;
                  }

                  // 4) Validasi nomor telepon
                  const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
                  if (!cleanPhone || cleanPhone.length < 8) {
                    toast({
                      title: 'Error',
                      description: 'Format nomor telepon tidak sesuai. Minimal 8 digit.',
                      variant: 'destructive',
                    });
                    return;
                  }

                  // 5) Buat pesan bukti bayar (tanpa info bank)
                  const message = generatePaymentReceiptMessage({
                    customerName: customerData!.full_name,
                    paymentDate: localPayment.payment_date,
                    amount: Number(localPayment.amount),
                    installmentNumber: localPayment.installments?.installment_number || 0,
                    paymentMethod: localPayment.payment_method,
                    referenceNumber: localPayment.reference_number,
                    applicationNumber: applicationNumber || '',
                    creditScore: customerData!.credit_score,
                    customerIdNumber: customerData!.id_number,
                    dateOfBirth: customerData!.date_of_birth,
                    remainingPenalty: Math.max(0, Number(localPayment.installments?.frozen_penalty || 0) - Math.max(0, Number(localPayment.installments?.paid_amount || 0) - Number(localPayment.installments?.total_amount || 0))),
                    totalAmount: Number(localPayment.installments?.total_amount || 0),
                    paidAmount: Number(localPayment.installments?.paid_amount || 0),
                  });

                  openWhatsAppChat(customerPhone, message);

                  toast({
                    title: 'Berhasil',
                    description: 'Membuka WhatsApp...',
                  });
                } catch (error) {
                  console.error('Error sending WhatsApp message:', error);
                  toast({
                    title: 'Error',
                    description: 'Terjadi kesalahan saat mengirim pesan',
                    variant: 'destructive',
                  });
                }
              }}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Kirim Bukti Bayar via WhatsApp
            </Button>
          </div>
        </div>
      </ResponsiveDialogContent>
      
      <EditPaymentDialog
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        payment={localPayment}
        onSuccess={handleRefreshPayment}
      />

      {/* Penalty Payment Dialog */}
      {localPayment.installments && (
        <PenaltyPaymentDialog
          open={showPenaltyDialog}
          onOpenChange={setShowPenaltyDialog}
          installment={{
            id: localPayment.installment_id,
            installment_number: localPayment.installments.installment_number,
            total_amount: localPayment.installments.total_amount,
            frozen_penalty: localPayment.installments.frozen_penalty,
            due_date: localPayment.installments.due_date,
          }}
          remainingPenalty={frozenPenalty}
          onSuccess={handleRefreshPayment}
        />
      )}

      {/* Delete Confirmation Dialog with SuperCode */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pembayaran</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data pembayaran secara permanen dan tidak dapat dibatalkan. Masukkan SuperCode untuk melanjutkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="delete-supercode">SuperCode</Label>
              <Input
                id="delete-supercode"
                type="password"
                placeholder="Masukkan SuperCode"
                value={superCode}
                onChange={(e) => setSuperCode(e.target.value)}
                disabled={isDeleting}
              />
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel 
              onClick={() => {
                setSuperCode("");
              }}
              disabled={isDeleting}
            >
              Batal
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeletePayment}
              disabled={!superCode || isDeleting}
              className="bg-destructive hover:bg-destructive/90"
            >
              {isDeleting ? "Menghapus..." : "Hapus"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </ResponsiveDialog>
  );
}

function DetailRow({ label, value, valueClassName }: { label: string; value: string; valueClassName?: string }) {
  return (
    <div className="flex justify-between gap-2 sm:gap-4">
      <span className="text-muted-foreground font-medium min-w-[90px] sm:min-w-[100px] text-xs sm:text-sm">{label}:</span>
      <span className={cn("text-right flex-1 break-words text-xs sm:text-sm font-semibold", valueClassName)}>{value}</span>
    </div>
  );
}
