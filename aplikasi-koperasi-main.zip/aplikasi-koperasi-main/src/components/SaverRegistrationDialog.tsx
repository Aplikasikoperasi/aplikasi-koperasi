import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Loader2, Upload, X, ArrowLeft, Check, AlertCircle } from "lucide-react";
import { compressImage } from "@/lib/imageCompression";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ActiveMember {
  id: string;
  full_name: string;
  member_number: string | null;
}

// Validate date format dd/mm/yyyy
const validateDateFormat = (value: string) => {
  if (!value || value === "") return false;
  const regex = /^\d{2}\/\d{2}\/\d{4}$/;
  if (!regex.test(value)) return false;
  
  const [day, month, year] = value.split('/').map(Number);
  if (year < 1900 || year > new Date().getFullYear()) return false;
  if (month < 1 || month > 12) return false;
  if (day < 1 || day > 31) return false;
  
  const date = new Date(year, month - 1, day);
  return date.getDate() === day && date.getMonth() === month - 1 && date.getFullYear() === year;
};

// Validate phone number format
const validatePhone = (value: string) => {
  if (!value) return false;
  const cleanPhone = value.replace(/\s/g, '');
  return /^(\+62|08)\d{8,}$/.test(cleanPhone);
};

const formSchema = z.object({
  full_name: z.string()
    .min(1, "Nama lengkap wajib diisi")
    .min(3, "Nama minimal 3 karakter")
    .max(100, "Nama maksimal 100 karakter"),
  id_number: z.string()
    .min(1, "NIK wajib diisi")
    .length(16, "NIK harus tepat 16 digit")
    .regex(/^\d+$/, "NIK hanya boleh berisi angka"),
  phone: z.string()
    .min(1, "Nomor telepon wajib diisi")
    .refine(validatePhone, "Format: 08xxx atau +62xxx, minimal 10 digit"),
  address: z.string()
    .min(1, "Alamat wajib diisi")
    .min(10, "Alamat minimal 10 karakter")
    .max(500, "Alamat maksimal 500 karakter"),
  date_of_birth: z.string()
    .min(1, "Tanggal lahir wajib diisi")
    .refine(validateDateFormat, "Format: dd/mm/yyyy (contoh: 15/08/1990)"),
  email: z.string()
    .email("Format email tidak valid")
    .optional()
    .or(z.literal("")),
  occupation: z.string()
    .min(1, "Pekerjaan wajib diisi")
    .min(2, "Pekerjaan minimal 2 karakter")
    .max(100, "Pekerjaan maksimal 100 karakter"),
  mother_maiden_name: z.string()
    .min(1, "Nama ibu kandung wajib diisi")
    .min(3, "Nama ibu kandung minimal 3 karakter")
    .max(100, "Nama ibu kandung maksimal 100 karakter"),
  initial_balance: z.string()
    .min(1, "Saldo awal wajib diisi")
    .refine((val) => {
      const num = parseFloat(val.replace(/[^\d]/g, ''));
      return !isNaN(num) && num >= 0;
    }, "Saldo awal harus berupa angka valid"),
  registered_by_member_id: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface SaverRegistrationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function SaverRegistrationDialog({
  open,
  onOpenChange,
}: SaverRegistrationDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formValues, setFormValues] = useState<FormValues | null>(null);
  const [activeMembers, setActiveMembers] = useState<ActiveMember[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  // Fetch active members for dropdown (exclude owner and admin)
  useEffect(() => {
    const fetchActiveMembers = async () => {
      // First get user_ids that have owner or admin roles
      const { data: adminRoles } = await supabase
        .from("user_roles")
        .select("user_id")
        .in("role", ["owner", "admin"]);
      
      const excludeUserIds = adminRoles?.map(r => r.user_id) || [];

      // Get active members excluding those with owner/admin roles
      let query = supabase
        .from("members")
        .select("id, full_name, member_number, user_id")
        .eq("is_active", true)
        .order("full_name");
      
      const { data, error } = await query;
      
      if (!error && data) {
        // Filter out members whose user_id is in the excludeUserIds list
        const filteredMembers = data.filter(
          member => !member.user_id || !excludeUserIds.includes(member.user_id)
        );
        setActiveMembers(filteredMembers);
      }
    };

    if (open) {
      fetchActiveMembers();
    }
  }, [open]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      full_name: "",
      id_number: "",
      phone: "",
      address: "",
      date_of_birth: "",
      email: "",
      occupation: "",
      mother_maiden_name: "",
      initial_balance: "",
      registered_by_member_id: "",
    },
  });

  // Auto-format date with separators
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>, onChange: (value: string) => void) => {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    if (value.length >= 5) {
      value = value.slice(0, 5) + '/' + value.slice(5);
    }
    
    if (value.length > 10) {
      value = value.slice(0, 10);
    }
    
    onChange(value);
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      setPhotoError(null);
      const compressedFile = await compressImage(file, 0.7, 800);
      setPhotoFile(compressedFile);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(compressedFile);
    } catch (error) {
      console.error("Error compressing image:", error);
      toast.error("Gagal memproses foto");
    } finally {
      setUploading(false);
    }
  };

  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const convertDateToISO = (dateStr: string): string | null => {
    if (!dateStr) return null;
    const [day, month, year] = dateStr.split('/');
    return `${year}-${month}-${day}`;
  };

  // Handle form validation and show confirmation
  const handleShowConfirmation = async (values: FormValues) => {
    // Validate photo first
    if (!photoFile) {
      setPhotoError("Foto debitur wajib diupload");
      toast.error("Foto debitur wajib diupload", {
        description: "Silakan upload foto terlebih dahulu"
      });
      return;
    }
    
    setPhotoError(null);
    setFormValues(values);
    setShowConfirmation(true);
  };

  const handleBackToForm = () => {
    setShowConfirmation(false);
  };

  const handleConfirmSubmit = async () => {
    if (!formValues || !photoFile) return;
    
    setIsSubmitting(true);
    try {
      let photoUrl = null;

      // Upload photo
      const fileExt = photoFile.name.split('.').pop();
      const fileName = `saver_${Date.now()}.${fileExt}`;
      const filePath = fileName;

      const { error: uploadError } = await supabase.storage
        .from('customer-photos')
        .upload(filePath, photoFile, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('customer-photos')
        .getPublicUrl(filePath);

      photoUrl = publicUrl;

      // Generate saver number and account number
      const { data: saverNumber, error: saverNumError } = await supabase.rpc(
        "generate_saver_number"
      );
      if (saverNumError) throw saverNumError;

      const { data: accountNumber, error: accountNumError } = await supabase.rpc(
        "generate_saver_account_number"
      );
      if (accountNumError) throw accountNumError;

      // Get current logged-in user (this is the operator/petugas)
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error("User tidak terautentikasi");
      }

      // created_by = user_id of the operator who is registering
      const createdByUserId = user.id;

      // recommended_by_member_id = member who recommended this saver (from dropdown, optional)
      const recommendedByMemberId = formValues.registered_by_member_id || null;

      // Parse initial balance
      const initialBalance = formValues.initial_balance 
        ? parseFloat(formValues.initial_balance.replace(/[^\d]/g, '')) || 0 
        : 0;

      // Insert saver with correct field mapping
      const { data: saverData, error: insertError } = await supabase.from("savers").insert({
        saver_number: saverNumber,
        account_number: accountNumber,
        full_name: formValues.full_name,
        id_number: formValues.id_number,
        phone: formValues.phone,
        address: formValues.address,
        date_of_birth: convertDateToISO(formValues.date_of_birth),
        email: formValues.email || null,
        occupation: formValues.occupation || null,
        mother_maiden_name: formValues.mother_maiden_name || null,
        photo_url: photoUrl,
        created_by: createdByUserId, // user_id of operator
        recommended_by_member_id: recommendedByMemberId, // member who recommended (for incentive)
        balance: initialBalance,
        deposit_balance: initialBalance,
      })
      .select()
      .single();

      if (insertError) throw insertError;

      // Create initial deposit transaction if there's an initial balance
      if (initialBalance > 0 && saverData) {
        const { error: depositError } = await supabase
          .from("saver_deposits")
          .insert({
            saver_id: saverData.id,
            amount: initialBalance,
            remaining_balance: initialBalance,
            deposit_date: new Date().toISOString().split('T')[0],
            transaction_type: 'deposit',
            notes: 'Saldo awal pendaftaran',
            is_eligible_for_interest: true,
            created_by: createdByUserId, // user_id of operator who registered
          });

        if (depositError) {
          console.error("Error creating initial deposit:", depositError);
        }
      }

      toast.success("Debitur berhasil didaftarkan!", {
        description: `No. ID: ${saverNumber} | No. Rekening: ${accountNumber}`,
      });

      queryClient.invalidateQueries({ queryKey: ["savers"] });
      form.reset();
      removePhoto();
      setShowConfirmation(false);
      setFormValues(null);
      onOpenChange(false);
    } catch (error: any) {
      console.error("Error registering saver:", error);
      toast.error("Gagal mendaftarkan debitur", {
        description: error.message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Confirmation Preview Component
  const ConfirmationPreview = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-primary">
        <Check className="h-5 w-5" />
        <h3 className="font-semibold">Konfirmasi Data Debitur</h3>
      </div>
      
      <p className="text-sm text-muted-foreground">
        Periksa kembali data berikut sebelum mendaftarkan:
      </p>

      <Card>
        <CardContent className="pt-4 space-y-4">
          {/* Photo & Basic Info */}
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border-2">
              <AvatarImage src={photoPreview || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary text-lg">
                {formValues?.full_name?.substring(0, 2).toUpperCase() || "?"}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="font-semibold text-lg">{formValues?.full_name}</h4>
              <p className="text-sm text-muted-foreground">{formValues?.occupation}</p>
            </div>
          </div>

          <Separator />

          {/* Data Summary */}
          <div className="grid grid-cols-1 gap-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">NIK:</span>
              <span className="font-medium font-mono">{formValues?.id_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Telepon:</span>
              <span className="font-medium">{formValues?.phone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Tanggal Lahir:</span>
              <span className="font-medium">{formValues?.date_of_birth}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Nama Ibu Kandung:</span>
              <span className="font-medium">{formValues?.mother_maiden_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Saldo Awal:</span>
              <span className="font-medium text-green-600">{formValues?.initial_balance}</span>
            </div>
            {formValues?.registered_by_member_id && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Direkomendasikan Oleh:</span>
                <span className="font-medium">
                  {activeMembers.find(m => m.id === formValues.registered_by_member_id)?.full_name || "-"}
                </span>
              </div>
            )}
            {formValues?.email && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{formValues?.email}</span>
              </div>
            )}
            <div className="pt-2">
              <span className="text-muted-foreground">Alamat:</span>
              <p className="font-medium mt-1">{formValues?.address}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 pt-2">
        <Button
          type="button"
          variant="outline"
          className="flex-1"
          onClick={handleBackToForm}
          disabled={isSubmitting}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Kembali
        </Button>
        <Button 
          type="button" 
          className="flex-1" 
          onClick={handleConfirmSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Check className="mr-2 h-4 w-4" />
          )}
          Konfirmasi & Daftarkan
        </Button>
      </div>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {showConfirmation ? "Konfirmasi Pendaftaran" : "Pendaftaran Debitur Baru"}
          </DialogTitle>
        </DialogHeader>

        {showConfirmation ? (
          <ConfirmationPreview />
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleShowConfirmation)} className="space-y-4">
              {/* Photo Upload - Horizontal Layout */}
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-4">
                  <div className="relative flex-shrink-0">
                    <Avatar className={`h-16 w-16 border-2 ${photoError ? 'border-destructive' : 'border-dashed border-muted-foreground/50'}`}>
                      <AvatarImage src={photoPreview || undefined} />
                      <AvatarFallback className="bg-muted text-muted-foreground text-lg">
                        {form.watch("full_name")?.substring(0, 2).toUpperCase() || "?"}
                      </AvatarFallback>
                    </Avatar>
                    {photoPreview && (
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-1 -right-1 h-5 w-5 rounded-full"
                        onClick={removePhoto}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium">Foto Debitur *</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        fileInputRef.current?.click();
                        setPhotoError(null);
                      }}
                      disabled={uploading}
                    >
                      {uploading ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Upload className="h-4 w-4 mr-2" />
                      )}
                      {photoPreview ? "Ganti" : "Upload"}
                    </Button>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handlePhotoChange}
                  />
                </div>
                {photoError && (
                  <Alert variant="destructive" className="py-2">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      {photoError}
                    </AlertDescription>
                  </Alert>
                )}
              </div>

              <FormField
                control={form.control}
                name="full_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Lengkap *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Masukkan nama lengkap" 
                        {...field}
                        onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="id_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>NIK (16 digit) *</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Masukkan NIK"
                        maxLength={16}
                        {...field}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          field.onChange(value);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nomor Telepon *</FormLabel>
                    <FormControl>
                      <Input placeholder="08xxx atau +62xxx" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="date_of_birth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tanggal Lahir *</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="dd/mm/yyyy"
                        value={field.value}
                        onChange={(e) => handleDateChange(e, field.onChange)}
                        maxLength={10}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="occupation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pekerjaan *</FormLabel>
                    <FormControl>
                      <Input placeholder="Masukkan pekerjaan" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="mother_maiden_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Ibu Kandung *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Masukkan nama ibu kandung" 
                        {...field}
                        onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="initial_balance"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Saldo Awal *</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Rp 0"
                        {...field}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^\d]/g, '');
                          const formatted = value ? `Rp ${parseInt(value).toLocaleString('id-ID')}` : '';
                          field.onChange(formatted);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="registered_by_member_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Direkomendasikan Oleh (Opsional)</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(value === "none" ? "" : value)} 
                      value={field.value || "none"}
                      defaultValue="none"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih anggota yang merekomendasikan (opsional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Tidak Ada</SelectItem>
                        {activeMembers.map((member) => (
                          <SelectItem key={member.id} value={member.id}>
                            {member.full_name} {member.member_number ? `(${member.member_number})` : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email (Opsional)</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="Masukkan email (opsional)"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Alamat *</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Masukkan alamat lengkap"
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => onOpenChange(false)}
                  disabled={isSubmitting}
                >
                  Batal
                </Button>
                <Button type="submit" className="flex-1">
                  Lanjutkan
                </Button>
              </div>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
