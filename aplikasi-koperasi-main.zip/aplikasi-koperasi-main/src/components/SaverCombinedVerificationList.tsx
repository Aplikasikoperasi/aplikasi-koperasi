import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatRupiah, formatDateWIB } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { CheckCircle, XCircle, ArrowUpCircle, ArrowDownCircle, Loader2, Clock, Wallet, RefreshCw, Banknote, Building2 } from "lucide-react";
import { logSystemEvent } from "@/lib/systemLogger";
import { SupercodeVerificationDialog } from "@/components/SupercodeVerificationDialog";

interface SaverInfo {
  id: string;
  full_name: string;
  saver_number: string;
  account_number?: string;
  photo_url: string | null;
  balance: number;
}

interface CombinedItem {
  id: string;
  type: "deposit" | "withdrawal" | "pending_withdrawal";
  amount: number;
  date: string;
  notes: string | null;
  created_at: string;
  payment_method?: string | null;
  expires_at?: string;
  requested_by_name?: string;
  created_by_name?: string;
  transaction_number?: string | null;
  saver: SaverInfo;
  canVerify: boolean;
}

interface SaverCombinedVerificationListProps {
  onCountChange?: (count: number) => void;
}

export default function SaverCombinedVerificationList({ 
  onCountChange 
}: SaverCombinedVerificationListProps) {
  const [items, setItems] = useState<CombinedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [actionDialog, setActionDialog] = useState<{
    open: boolean;
    item: CombinedItem | null;
    action: "approve" | "reject" | null;
  }>({ open: false, item: null, action: null });
  const [rejectionReason, setRejectionReason] = useState("");
  const [processing, setProcessing] = useState(false);

  const [supercodeOpen, setSupercodeOpen] = useState(false);
  const [supercodeItem, setSupercodeItem] = useState<CombinedItem | null>(null);

  const { isOwner, isAdmin } = useUserRole();

  const canManage = isOwner || isAdmin;

  useEffect(() => {
    loadAllData();

    // Subscribe to realtime changes
    const depositsChannel = supabase
      .channel("saver-deposits-combined")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "saver_deposits",
      }, (payload) => {
        console.log("🔄 Saver deposits changed:", payload);
        loadAllData();
      })
      .subscribe((status) => {
        console.log("📡 Deposits subscription status:", status);
      });

    const withdrawalsChannel = supabase
      .channel("saver-withdrawals-combined")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "saver_withdrawals",
      }, (payload) => {
        console.log("🔄 Saver withdrawals changed:", payload);
        loadAllData();
      })
      .subscribe((status) => {
        console.log("📡 Withdrawals subscription status:", status);
      });

    const pendingWithdrawalsChannel = supabase
      .channel("pending-withdrawals-combined")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "saver_pending_withdrawals",
      }, (payload) => {
        console.log("🔄 Pending withdrawals changed:", payload);
        loadAllData();
      })
      .subscribe((status) => {
        console.log("📡 Pending withdrawals subscription status:", status);
      });

    return () => {
      supabase.removeChannel(depositsChannel);
      supabase.removeChannel(withdrawalsChannel);
      supabase.removeChannel(pendingWithdrawalsChannel);
    };
  }, []);

  // Update countdown every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setItems((prev) => [...prev]);
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  const loadAllData = async () => {
    try {
      const client = supabase as any;
      
      // Load pending deposits (verifiable by owner/admin)
      const { data: rawDeposits, error: depositsError } = await client
        .from("saver_deposits")
        .select(`
          id, amount, deposit_date, notes, created_at, saver_id, payment_method, transaction_number, created_by,
          savers:saver_id(full_name, account_number, saver_number, photo_url, balance),
          created_by_member:members!saver_deposits_created_by_fkey(full_name)
        `)
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      
      if (depositsError) throw depositsError;
      const deposits = rawDeposits || [];

      // Load pending withdrawals (verifiable)
      const { data: rawWithdrawals, error: withdrawalsError } = await client
        .from("saver_withdrawals")
        .select(`
          id, amount, withdrawal_date, notes, created_at, saver_id, transaction_number,
          savers:saver_id(full_name, account_number, saver_number, photo_url, balance)
        `)
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      
      if (withdrawalsError) throw withdrawalsError;
      const withdrawals = rawWithdrawals || [];

      // Load pending withdrawals waiting for PIN confirmation
      const { data: rawPendingWithdrawals, error: pendingError } = await client
        .from("saver_pending_withdrawals")
        .select(`
          *,
          savers:saver_id(full_name, account_number, saver_number, photo_url, balance),
          members:requested_by(full_name)
        `)
        .eq("status", "pending")
        .order("requested_at", { ascending: false });

      if (pendingError) throw pendingError;
      const pendingWithdrawals = rawPendingWithdrawals || [];

      // Combine and format all items
      const formattedDeposits: CombinedItem[] = deposits
        .filter((d: any) => d.savers)
        .map((d: any) => ({
          id: d.id,
          type: "deposit" as const,
          amount: d.amount,
          date: d.deposit_date,
          notes: d.notes,
          created_at: d.created_at,
          payment_method: d.payment_method,
          transaction_number: d.transaction_number,
          created_by_name: d.created_by_member?.full_name || null,
          saver: {
            id: d.saver_id,
            full_name: d.savers?.full_name || "Unknown",
            saver_number: d.savers?.saver_number || "",
            account_number: d.savers?.account_number || "",
            photo_url: d.savers?.photo_url || null,
            balance: d.savers?.balance || 0,
          },
          canVerify: true,
        }));

      const formattedWithdrawals: CombinedItem[] = withdrawals
        .filter((w: any) => w.savers)
        .map((w: any) => ({
          id: w.id,
          type: "withdrawal" as const,
          amount: w.amount,
          date: w.withdrawal_date,
          notes: w.notes,
          created_at: w.created_at,
          transaction_number: w.transaction_number,
          saver: {
            id: w.saver_id,
            full_name: w.savers?.full_name || "Unknown",
            saver_number: w.savers?.saver_number || "",
            account_number: w.savers?.account_number || "",
            photo_url: w.savers?.photo_url || null,
            balance: w.savers?.balance || 0,
          },
          canVerify: true,
        }));

      const formattedPendingWithdrawals: CombinedItem[] = pendingWithdrawals.map((pw: any) => ({
        id: pw.id,
        type: "pending_withdrawal" as const,
        amount: pw.amount,
        date: pw.requested_at,
        notes: pw.notes,
        created_at: pw.requested_at,
        payment_method: pw.payment_method,
        expires_at: pw.expires_at,
        requested_by_name: pw.members?.full_name || "Admin",
        transaction_number: pw.transaction_number,
        saver: {
          id: pw.saver_id,
          full_name: pw.savers?.full_name || "Unknown",
          saver_number: pw.savers?.saver_number || "",
          account_number: pw.savers?.account_number || "",
          photo_url: pw.savers?.photo_url || null,
          balance: pw.savers?.balance || 0,
        },
        canVerify: false,
      }));

      const allItems = [...formattedDeposits, ...formattedWithdrawals, ...formattedPendingWithdrawals]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      setItems(allItems);
      onCountChange?.(allItems.length);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadAllData();
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diff = expires.getTime() - now.getTime();

    if (diff <= 0) return "Kadaluarsa";

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}j ${minutes}m`;
  };

  const approveItem = async (item: CombinedItem) => {
    setProcessing(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: member } = await supabase
        .from("members")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (!member) throw new Error("Member not found");

      const table = item.type === "deposit" ? "saver_deposits" : "saver_withdrawals";

      // Update transaction status - different columns for deposits vs withdrawals
      const updateData = item.type === "deposit" 
        ? {
            status: "approved",
            approved_at: new Date().toISOString(),
            approved_by: member.id,
          }
        : {
            status: "completed",
            processed_by: member.id,
          };

      const { error: updateError } = await supabase
        .from(table)
        .update(updateData)
        .eq("id", item.id);

      if (updateError) throw updateError;

      // Update saver balance
      const newBalance = item.type === "deposit"
        ? item.saver.balance + item.amount
        : item.saver.balance - item.amount;

      const { error: balanceError } = await supabase
        .from("savers")
        .update({
          balance: newBalance,
          deposit_balance: newBalance,
        })
        .eq("id", item.saver.id);

      if (balanceError) throw balanceError;

      await logSystemEvent({
        category: "financial",
        action: item.type === "deposit" ? "Verifikasi Deposit Debitur" : "Verifikasi Penarikan Debitur",
        description: `Menyetujui ${item.type === "deposit" ? "deposit" : "penarikan"} ${formatRupiah(item.amount)} untuk ${item.saver.full_name}`,
        metadata: {
          transaction_id: item.id,
          saver_id: item.saver.id,
          amount: item.amount,
        },
      });

      toast.success(`${item.type === "deposit" ? "Deposit" : "Penarikan"} berhasil diverifikasi`);
      setActionDialog({ open: false, item: null, action: null });
      loadAllData();
    } catch (error: any) {
      console.error("Error approving transaction:", error);
      toast.error(`Gagal memverifikasi: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!actionDialog.item || !rejectionReason.trim()) {
      toast.error("Alasan penolakan wajib diisi");
      return;
    }
    setProcessing(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: member } = await supabase
        .from("members")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (!member) throw new Error("Member not found");

      const { item } = actionDialog;
      const table = item.type === "deposit" ? "saver_deposits" : "saver_withdrawals";
      
      // Update transaction status
      const { error: updateError } = await supabase
        .from(table)
        .update({
          status: "rejected",
          verified_at: new Date().toISOString(),
          verified_by: member.id,
          notes: `${item.notes || ""}\n[DITOLAK] ${rejectionReason}`.trim(),
        })
        .eq("id", item.id);

      if (updateError) throw updateError;

      await logSystemEvent({
        category: "financial",
        action: item.type === "deposit" ? "Tolak Deposit Debitur" : "Tolak Penarikan Debitur",
        description: `Menolak ${item.type === "deposit" ? "deposit" : "penarikan"} ${formatRupiah(item.amount)} untuk ${item.saver.full_name}. Alasan: ${rejectionReason}`,
        metadata: {
          transaction_id: item.id,
          saver_id: item.saver.id,
          amount: item.amount,
          reason: rejectionReason,
        },
      });

      toast.success(`${item.type === "deposit" ? "Deposit" : "Penarikan"} berhasil ditolak`);
      setActionDialog({ open: false, item: null, action: null });
      setRejectionReason("");
      loadAllData();
    } catch (error: any) {
      console.error("Error rejecting transaction:", error);
      toast.error(`Gagal menolak: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const getTypeLabel = (type: CombinedItem["type"]) => {
    switch (type) {
      case "deposit":
        return { label: "Deposit", variant: "default" as const, icon: ArrowUpCircle, color: "text-green-600" };
      case "withdrawal":
        return { label: "Penarikan", variant: "destructive" as const, icon: ArrowDownCircle, color: "text-red-600" };
      case "pending_withdrawal":
        return { label: "Menunggu PIN", variant: "secondary" as const, icon: Clock, color: "text-amber-600" };
    }
  };

  return (
    <>
      <Card className="w-full max-w-full overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base sm:text-lg flex items-center gap-2">
              <Wallet className="h-5 w-5 text-primary" />
              Verifikasi Transaksi Debitur
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-3 sm:p-6">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
              <CheckCircle className="h-8 w-8" />
              <p className="font-medium">Tidak ada transaksi pending</p>
              <p className="text-sm">Semua transaksi sudah diverifikasi</p>
            </div>
          ) : (
            <ScrollArea className="h-[500px]">
              <div className="space-y-3">
                {items.map((item) => {
                  const typeInfo = getTypeLabel(item.type);
                  const TypeIcon = typeInfo.icon;
                  
                  return (
                    <Card 
                      key={`${item.type}-${item.id}`} 
                      className={`overflow-hidden ${
                        item.type === "pending_withdrawal" 
                          ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800" 
                          : ""
                      }`}
                    >
                      <CardContent className="p-4">
                          <div className="flex items-center gap-3">
                          <div className="relative">
                            <Avatar className="h-12 w-12 border">
                              <AvatarImage src={item.saver.photo_url || undefined} />
                              <AvatarFallback className="bg-primary/10 text-primary">
                                {item.saver.full_name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div className={`absolute -bottom-1 -right-1 p-1 rounded-full ${
                              item.type === "deposit" ? "bg-green-500" : 
                              item.type === "withdrawal" ? "bg-red-500" : "bg-amber-500"
                            }`}>
                              <TypeIcon className="h-3 w-3 text-white" />
                            </div>
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-semibold">{item.saver.full_name}</p>
                              <Badge variant="outline" className="text-xs">
                                {item.saver.account_number || item.saver.saver_number}
                              </Badge>
                            </div>
                            {item.transaction_number && (
                              <p className="text-xs font-mono text-primary mt-0.5">
                                #{item.transaction_number}
                              </p>
                            )}
                            
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                              {/* Show transaction type label */}
                              {item.type === "deposit" && (
                                <Badge className="text-xs bg-green-600 hover:bg-green-700">
                                  Deposit
                                </Badge>
                              )}
                              {item.type === "withdrawal" && (
                                <Badge variant="destructive" className="text-xs">
                                  Penarikan
                                </Badge>
                              )}
                              {item.type === "pending_withdrawal" && (
                                <>
                                  <Badge variant="destructive" className="text-xs">
                                    Penarikan
                                  </Badge>
                                  <Badge variant="secondary" className="text-xs">
                                    {typeInfo.label}
                                  </Badge>
                                </>
                              )}
                              <span className={`font-bold ${typeInfo.color}`}>
                                {item.type === "deposit" ? "+" : "-"}{formatRupiah(item.amount)}
                              </span>
                              
                              {item.type === "pending_withdrawal" && item.expires_at && (
                                <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-300 text-xs">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {getTimeRemaining(item.expires_at)}
                                </Badge>
                              )}
                            </div>

                            {/* Payment method and staff info */}
                            {(item.type === "deposit" || item.type === "pending_withdrawal") && (
                              <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 flex-wrap">
                                {item.payment_method && (
                                  <>
                                    {item.payment_method === "transfer" ? (
                                      <>
                                        <Building2 className="h-3 w-3 text-blue-500" />
                                        <span>Transfer</span>
                                      </>
                                    ) : (
                                      <>
                                        <Banknote className="h-3 w-3 text-green-600" />
                                        <span>Tunai</span>
                                      </>
                                    )}
                                  </>
                                )}
                                {item.type === "deposit" && item.created_by_name && (
                                  <span className="text-muted-foreground">
                                    • Diajukan oleh <span className="font-medium text-foreground">{item.created_by_name}</span>
                                  </span>
                                )}
                                {item.type === "pending_withdrawal" && item.requested_by_name && (
                                  <span className="text-muted-foreground">
                                    • Diajukan oleh <span className="font-medium text-foreground">{item.requested_by_name}</span>
                                  </span>
                                )}
                              </div>
                            )}

                            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                              <Clock className="h-3 w-3" />
                              <span>{formatDateWIB(item.created_at)}</span>
                            </div>

                            {item.notes && (
                              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                                {item.notes}
                              </p>
                            )}

                            {item.type === "pending_withdrawal" && (
                              <div className="mt-2 p-2 bg-amber-100/50 dark:bg-amber-900/30 rounded text-xs text-amber-700 dark:text-amber-300">
                                ⏳ Menunggu konfirmasi PIN dari debitur
                              </div>
                            )}
                          </div>

                          {canManage && item.canVerify && (
                            <div className="flex flex-col gap-2">
                              <Button
                                size="sm"
                                onClick={() => setActionDialog({ 
                                  open: true, 
                                  item, 
                                  action: "approve" 
                                })}
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => setActionDialog({ 
                                  open: true, 
                                  item, 
                                  action: "reject" 
                                })}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Approval Dialog */}
      <AlertDialog 
        open={actionDialog.open && actionDialog.action === "approve"} 
        onOpenChange={(open) => !open && setActionDialog({ open: false, item: null, action: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Setujui {actionDialog.item?.type === "deposit" ? "Deposit" : "Penarikan"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menyetujui{" "}
              {actionDialog.item?.type === "deposit" ? "deposit" : "penarikan"} sebesar{" "}
              <strong>{formatRupiah(actionDialog.item?.amount || 0)}</strong> untuk{" "}
              <strong>{actionDialog.item?.saver.full_name}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (!actionDialog.item) return;
                setSupercodeItem(actionDialog.item);
                setSupercodeOpen(true);
                setActionDialog({ open: false, item: null, action: null });
              }}
              disabled={processing}
            >
              {processing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Setujui
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Rejection Dialog */}
      <AlertDialog 
        open={actionDialog.open && actionDialog.action === "reject"} 
        onOpenChange={(open) => {
          if (!open) {
            setActionDialog({ open: false, item: null, action: null });
            setRejectionReason("");
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Tolak {actionDialog.item?.type === "deposit" ? "Deposit" : "Penarikan"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menolak{" "}
              {actionDialog.item?.type === "deposit" ? "deposit" : "penarikan"} sebesar{" "}
              <strong>{formatRupiah(actionDialog.item?.amount || 0)}</strong> untuk{" "}
              <strong>{actionDialog.item?.saver.full_name}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-2">
            <Label htmlFor="rejection-reason">Alasan Penolakan *</Label>
            <Textarea
              id="rejection-reason"
              placeholder="Masukkan alasan penolakan..."
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
            />
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Batal</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleReject} 
              disabled={processing || !rejectionReason.trim()}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {processing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Tolak
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <SupercodeVerificationDialog
        open={supercodeOpen}
        onOpenChange={(open) => {
          setSupercodeOpen(open);
          if (!open) {
            // Clear after close; SupercodeVerificationDialog calls onOpenChange(false) before onSuccess()
            setTimeout(() => setSupercodeItem(null), 0);
          }
        }}
        title={
          supercodeItem?.type === "deposit"
            ? "Setujui Deposit Debitur"
            : "Setujui Penarikan Debitur"
        }
        description={
          supercodeItem
            ? `Masukkan supercode untuk menyetujui ${supercodeItem.type === "deposit" ? "deposit" : "penarikan"} ${formatRupiah(supercodeItem.amount)} atas nama ${supercodeItem.saver.full_name}.`
            : "Masukkan supercode untuk melanjutkan operasi ini"
        }
        onSuccess={() => {
          const item = supercodeItem;
          if (!item) return;
          void approveItem(item);
        }}
      />
    </>
  );
}
