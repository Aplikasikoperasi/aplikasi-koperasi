import { useState, useRef, useEffect } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { FileEdit, Upload, X } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { compressImage } from "@/lib/imageCompression";
import { DatePicker } from "@/components/ui/date-picker";
import { format, parse } from "date-fns";
import { sanitizeDateForDatabase, getTodayInWIB } from "@/lib/utils";

interface CustomerChangeRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer: any;
}

export function CustomerChangeRequestDialog({
  open,
  onOpenChange,
  customer,
}: CustomerChangeRequestDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [newPhotoFile, setNewPhotoFile] = useState<File | null>(null);
  const [newPhotoPreview, setNewPhotoPreview] = useState<string>("");
  const [dateOfBirth, setDateOfBirth] = useState<Date | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    full_name: customer?.full_name || "",
    nik: customer?.nik || "",
    phone: customer?.phone || "",
    address: customer?.address || "",
    occupation: customer?.occupation || "",
    notes: "",
  });

  // Update form when customer prop changes
  useEffect(() => {
    if (customer && open) {
      setFormData({
        full_name: customer.full_name || "",
        nik: customer.nik || "",
        phone: customer.phone || "",
        address: customer.address || "",
        occupation: customer.occupation || "",
        notes: "",
      });
      
      // Parse date_of_birth string to Date object
      if (customer.date_of_birth) {
        try {
          const parsedDate = parse(customer.date_of_birth, "yyyy-MM-dd", new Date());
          setDateOfBirth(parsedDate);
        } catch (error) {
          console.error('Error parsing date:', error);
          setDateOfBirth(undefined);
        }
      } else {
        setDateOfBirth(undefined);
      }
    }
  }, [customer, open]);

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "File harus berupa gambar",
        variant: "destructive",
      });
      return;
    }

    try {
      // Compress image
      const compressedFile = await compressImage(file);
      setNewPhotoFile(compressedFile);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(compressedFile);
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal memproses gambar",
        variant: "destructive",
      });
    }
  };

  const handleRemovePhoto = () => {
    setNewPhotoFile(null);
    setNewPhotoPreview("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let uploadedPhotoUrl = customer.photo_url;

      // Upload new photo if selected
      if (newPhotoFile) {
        const fileExt = newPhotoFile.name.split('.').pop();
        const fileName = `${customer.id}-change-request-${Date.now()}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('customer-photos')
          .upload(filePath, newPhotoFile, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('customer-photos')
          .getPublicUrl(filePath);

        uploadedPhotoUrl = publicUrl;
      }

      // Prepare old and new data for comparison
      // Convert empty strings to null for date fields to avoid PostgreSQL errors
      const oldData = {
        full_name: customer.full_name,
        nik: customer.nik,
        date_of_birth: customer.date_of_birth || null,
        phone: customer.phone,
        address: customer.address,
        occupation: customer.occupation,
        photo_url: customer.photo_url,
      };

      const newData = {
        full_name: formData.full_name,
        nik: formData.nik,
        date_of_birth: sanitizeDateForDatabase(dateOfBirth),
        phone: formData.phone,
        address: formData.address,
        occupation: formData.occupation,
        photo_url: uploadedPhotoUrl,
      };

      // Validate date_of_birth if provided
      if (dateOfBirth && !newData.date_of_birth) {
        toast({
          title: "Error",
          description: "Format tanggal lahir tidak valid",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      // Check if there are any changes
      const hasChanges = Object.keys(oldData).some(
        key => oldData[key as keyof typeof oldData] !== newData[key as keyof typeof newData]
      );

      if (!hasChanges) {
        toast({
          title: "Tidak ada perubahan",
          description: "Tidak ada data yang diubah",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const { error } = await supabase
        .from("customer_change_requests")
        .insert({
          customer_id: customer.id,
          requested_by: user.id,
          old_data: oldData,
          new_data: newData,
          notes: formData.notes,
        });

      if (error) throw error;

      await logSystemEvent({
        category: "customer_management",
        action: "Ajukan Perubahan Data",
        description: `Mengajukan perubahan data untuk nasabah: ${customer.full_name}`,
        metadata: {
          customer_id: customer.id,
          customer_name: customer.full_name,
        },
      });

      toast({
        title: "Berhasil",
        description: "Permintaan perubahan data telah diajukan dan menunggu persetujuan",
      });

      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Gagal",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-2xl w-full max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle className="flex items-center gap-2">
            <FileEdit className="h-5 w-5" />
            Ajukan Perubahan Data Nasabah
          </ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-3">
            {/* Photo Upload Section */}
            <div className="space-y-2">
              <Label>Foto Nasabah</Label>
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={newPhotoPreview || customer?.photo_url} alt="Preview" />
                    <AvatarFallback className="bg-primary/10 text-primary text-xl">
                      {customer?.full_name?.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="flex-1 space-y-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    className="hidden"
                    id="photo-upload"
                  />
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex-1"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      {newPhotoPreview ? "Ganti Foto" : "Upload Foto Baru"}
                    </Button>
                    {newPhotoPreview && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={handleRemovePhoto}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Format: JPG, PNG. Maks 5MB
                  </p>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="full_name">Nama Lengkap</Label>
              <Input
                id="full_name"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="nik">NIK</Label>
              <Input
                id="nik"
                value={formData.nik}
                onChange={(e) => setFormData({ ...formData, nik: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="date_of_birth">Tanggal Lahir</Label>
              <DatePicker
                value={dateOfBirth}
                onChange={setDateOfBirth}
                placeholder="dd/MM/yyyy"
                maxDate={getTodayInWIB()}
                minDate={new Date("1900-01-01")}
              />
            </div>

            <div>
              <Label htmlFor="phone">No. Telepon</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="occupation">Pekerjaan</Label>
              <Input
                id="occupation"
                value={formData.occupation}
                onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="address">Alamat</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                required
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="notes">Catatan (Opsional)</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Alasan perubahan data atau catatan tambahan..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex gap-2 justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Batal
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Mengirim..." : "Ajukan Perubahan"}
            </Button>
          </div>
        </form>
      </ResponsiveDialogContent>
    </ResponsiveDialog>
  );
}
