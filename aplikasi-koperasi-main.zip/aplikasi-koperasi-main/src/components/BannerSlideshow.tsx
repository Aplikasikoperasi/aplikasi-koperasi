import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Banner {
  id: string;
  image_url: string;
  display_order: number;
}

export function BannerSlideshow() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBanners = async () => {
      const { data, error } = await supabase
        .from('banners')
        .select('id, image_url, display_order')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (!error && data) {
        setBanners(data);
      }
      setIsLoading(false);
    };

    fetchBanners();

    // Subscribe to realtime updates
    const channel = supabase
      .channel('banners-changes')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'banners' 
      }, () => {
        fetchBanners();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Auto slide every 5 seconds
  useEffect(() => {
    if (banners.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [banners.length]);

  const goToPrevious = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
  }, [banners.length]);

  const goToNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % banners.length);
  }, [banners.length]);

  const goToSlide = useCallback((index: number) => {
    setCurrentIndex(index);
  }, []);

  if (isLoading) {
    return (
      <div className="w-full bg-muted animate-pulse rounded-lg" style={{ minHeight: '120px' }} />
    );
  }

  if (banners.length === 0) {
    return null;
  }

  return (
    <div className="relative w-full overflow-hidden rounded-lg group bg-muted/30">
      {/* Banner Images with Fade Animation */}
      <div className="relative w-full">
        {banners.map((banner, index) => (
          <div 
            key={banner.id} 
            className={cn(
              "w-full transition-opacity duration-700 ease-in-out overflow-hidden",
              index === currentIndex ? "opacity-100 relative" : "opacity-0 absolute inset-0"
            )}
          >
            <img
              src={banner.image_url}
              alt="Banner"
              className={cn(
                "w-full h-auto object-contain transition-transform duration-[5000ms] ease-out max-h-[200px] sm:max-h-[250px] md:max-h-[300px] lg:max-h-[350px]",
                index === currentIndex ? "scale-105" : "scale-100"
              )}
            />
          </div>
        ))}
      </div>

      {/* Navigation Arrows - only show if more than 1 banner */}
      {banners.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background text-foreground p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow-lg"
            aria-label="Previous banner"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background text-foreground p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow-lg"
            aria-label="Next banner"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

    </div>
  );
}
