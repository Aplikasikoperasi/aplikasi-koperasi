import { useState, useEffect } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDate, formatRupiah, roundToThousand, cn } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { MessageSquare, Banknote, Trash2, AlertCircle, Crown, Shield, Briefcase, Wallet } from "lucide-react";
import { generateInstallmentReminderMessage, openWhatsAppChat } from "@/lib/whatsappHelper";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { PenaltyPaymentDialog } from "./PenaltyPaymentDialog";
import { useInvalidateInstallments } from "@/hooks/useInstallmentsQuery";
import { useInvalidatePayments } from "@/hooks/usePaymentsQuery";

interface InstallmentDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  installment: any;
  onPay?: (installment: any) => void;
}

export function InstallmentDetailDialog({
  open,
  onOpenChange,
  installment,
  onPay,
}: InstallmentDetailDialogProps) {
  const { toast } = useToast();
  const { isOwner, isAdmin, isKasir } = useUserRole();
  const canManage = isOwner || isAdmin || isKasir;
  const invalidateInstallments = useInvalidateInstallments();
  const invalidatePayments = useInvalidatePayments();
  
  const [payments, setPayments] = useState<any[]>([]);
  const [loadingPayments, setLoadingPayments] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedPaymentId, setSelectedPaymentId] = useState<string | null>(null);
  const [superCode, setSuperCode] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [penaltyRate, setPenaltyRate] = useState<number>(() => {
    const snapshotRate =
      installment?.penalty_rate_per_day ??
      installment?.credit_applications?.penalty_rate_per_day;
    return snapshotRate ?? 2.0;
  });
  const [showPenaltyPaymentDialog, setShowPenaltyPaymentDialog] = useState(false);
  const [currentInst, setCurrentInst] = useState<any>(installment);
  
  useEffect(() => {
    if (open && installment?.id) {
      loadPayments();
      reloadInstallment();
    }
  }, [open, installment?.id]);

  useEffect(() => {
    // Gunakan rate denda yang tersimpan pada angsuran / aplikasi kredit (snapshot)
    const snapshotRate =
      currentInst?.penalty_rate_per_day ??
      installment?.penalty_rate_per_day ??
      installment?.credit_applications?.penalty_rate_per_day;

    if (snapshotRate != null) {
      setPenaltyRate(snapshotRate);
    } else if (open && installment?.id) {
      // Fallback hanya untuk data lama yang belum punya snapshot
      loadPenaltyRate();
    }
  }, [open, installment, currentInst?.penalty_rate_per_day]);

  const loadPenaltyRate = async () => {
    const { data } = await supabase.rpc('get_public_app_settings');
    if (data) {
      setPenaltyRate((data as any)?.penalty_rate_per_day || 2.0);
    }
  };

  const loadPayments = async () => {
    if (!installment?.id) return;
    setLoadingPayments(true);
    try {
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .eq('installment_id', installment.id)
        .order('payment_date', { ascending: false });
      if (error) throw error;
      setPayments(data || []);
    } catch (error) {
      console.error('Error loading payments:', error);
      toast({ title: "Error", description: "Gagal memuat data pembayaran", variant: "destructive" });
    } finally {
      setLoadingPayments(false);
    }
  };

  const reloadInstallment = async () => {
    if (!installment?.id) return;
    try {
      const { data } = await supabase
        .from('installments')
        .select(`
          id, 
          paid_amount, 
          total_amount, 
          frozen_penalty, 
          status, 
          paid_at, 
          principal_paid, 
          frozen_days_overdue,
          penalty_rate_per_day,
          credit_applications!inner(penalty_rate_per_day)
        `)
        .eq('id', installment.id)
        .maybeSingle();
      if (data) {
        setCurrentInst((prev: any) => ({ ...(prev || installment), ...data }));
      }
    } catch (e) {
      console.warn('Failed to reload installment', e);
    }
  };

  useEffect(() => { setCurrentInst(installment); }, [installment]);
  useEffect(() => {
    const onUpd = () => reloadInstallment();
    window.addEventListener('payments-updated', onUpd);
    window.addEventListener('installments-updated', onUpd);
    return () => {
      window.removeEventListener('payments-updated', onUpd);
      window.removeEventListener('installments-updated', onUpd);
    };
  }, [installment?.id]);
  // Calculate penalty and days overdue based on principal_paid status (using latest state)
  const calculatePenaltyAndDays = () => {
    const inst = currentInst || installment;
    if (!inst) return { daysOverdue: 0, penalty: 0 };
    if (inst.principal_paid) {
      return {
        daysOverdue: inst.frozen_days_overdue || 0,
        penalty: inst.frozen_penalty || 0,
      };
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(inst.due_date);
    due.setHours(0, 0, 0, 0);
    const diffTime = today.getTime() - due.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const daysOverdue = Math.max(0, diffDays);
    if (daysOverdue === 0) {
      return { daysOverdue: 0, penalty: 0 };
    }
    const baseTotal = Number((currentInst?.total_amount ?? installment.total_amount) || 0);
    const dailyPenalty = roundToThousand(baseTotal * (penaltyRate / 100));
    return { daysOverdue, penalty: daysOverdue * dailyPenalty };
  };

  if (!installment) return null;

  const { daysOverdue, penalty } = calculatePenaltyAndDays();
  
  // CRITICAL FIX: Calculate remaining penalty - NEVER reduce by extraPayment
  // Frozen penalty must be paid separately via "Bayar Denda" button
  const totalAmount = Number((currentInst?.total_amount ?? installment.total_amount) || 0);
  const paidAmount = Number((currentInst?.paid_amount ?? installment.paid_amount) || 0);
  const frozenPenalty = Number((currentInst?.frozen_penalty ?? installment.frozen_penalty) || 0);
  const remainingPenalty = frozenPenalty; // Direct value, no auto-reduction
  const remainingAmount = Math.max(0, totalAmount - paidAmount) + (currentInst?.principal_paid ? remainingPenalty : penalty);

  const handleDeletePayment = async () => {
    if (!selectedPaymentId || !superCode) return;
    
    setIsDeleting(true);
    try {
      // Verify SuperCode
      const { data: verifyData, error: verifyError } = await supabase.functions.invoke(
        'verify-supercode',
        {
          body: { superCodeInput: superCode }
        }
      );

      if (verifyError || !verifyData?.valid) {
        toast({
          title: "SuperCode Salah",
          description: verifyData?.error || "Kode yang Anda masukkan tidak valid",
          variant: "destructive",
        });
        setIsDeleting(false);
        return;
      }

      // Delete related incentive transactions (kasir and sales)
      // This ensures orphan incentives are cleaned up when payment is deleted
      const { error: incentiveDeleteError } = await supabase
        .from('member_balance_transactions')
        .delete()
        .eq('payment_id', selectedPaymentId);

      if (incentiveDeleteError) {
        console.error('Error deleting related incentives:', incentiveDeleteError);
        // Don't block payment deletion if incentive cleanup fails
      }

      // Delete payment
      const { error: deleteError } = await supabase
        .from('payments')
        .delete()
        .eq('id', selectedPaymentId);

      if (deleteError) throw deleteError;

      toast({
        title: "Berhasil",
        description: "Pembayaran dan insentif terkait berhasil dihapus",
      });

      // Invalidate queries to refresh data immediately
      invalidateInstallments();
      invalidatePayments();

      // Reload payments and trigger parent refresh
      await loadPayments();
      setShowDeleteDialog(false);
      setSuperCode("");
      setSelectedPaymentId(null);
      
      // Trigger page refresh event (legacy support)
      window.dispatchEvent(new Event('installments-updated'));
      
    } catch (error: any) {
      console.error('Error deleting payment:', error);
      toast({
        title: "Error",
        description: error.message || "Gagal menghapus pembayaran",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };
  
  if (!installment) return null;

  const getStatusBadge = () => {
    const status = currentInst?.status ?? installment.status;
    switch (status) {
      case 'paid':
        return <Badge variant="default">Lunas</Badge>;
      case 'unpaid':
        return <Badge variant="destructive">Belum Lunas</Badge>;
      case 'partial':
        return <Badge className="bg-yellow-600 text-white">Dibayar Sebagian</Badge>;
      case 'overdue':
        return <Badge variant="destructive">Menunggak</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-md w-full max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>Detail Angsuran</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="w-full max-w-full space-y-4 overflow-hidden">
          {/* Customer Info */}
          <div className="flex items-start gap-4">
            <ClickableAvatar
              src={installment.credit_applications?.customers?.photo_url}
              alt={installment.credit_applications?.customers?.full_name}
              fallback={installment.credit_applications?.customers?.full_name?.substring(0, 2).toUpperCase()}
              className="h-16 w-16 sm:h-20 sm:w-20 flex-shrink-0"
              fallbackClassName="bg-primary/10 text-primary text-lg sm:text-xl"
            />
            <div className="flex-1 min-w-0 space-y-1">
              <h3 className="font-bold text-base sm:text-lg truncate">{installment.credit_applications?.customers?.full_name}</h3>
              <p className="text-xs sm:text-sm text-muted-foreground truncate font-bold">{installment.credit_applications?.customers?.id_number}</p>
              <div className="flex flex-wrap items-center gap-2">{getStatusBadge()}</div>
            </div>
          </div>

          <Separator />

          {/* Installment Details */}
          <div className="space-y-2 text-xs sm:text-sm">
            <DetailRow label="No. Aplikasi" value={installment.credit_applications?.application_number || "-"} />
            {installment.is_silenced && (
              <div className="flex justify-between gap-2 sm:gap-4 bg-purple-50 dark:bg-purple-900/20 p-2 rounded-lg border border-purple-200 dark:border-purple-800">
                <span className="text-muted-foreground font-medium min-w-[100px] sm:min-w-[120px] text-xs sm:text-sm">Status Notifikasi:</span>
                <span className="text-right flex-1 break-words text-xs sm:text-sm font-semibold text-purple-700 dark:text-purple-300 flex items-center justify-end gap-1">
                  🔕 Silent Mode
                  <span className="text-[10px] font-normal text-muted-foreground">(Tidak ada reminder otomatis)</span>
                </span>
              </div>
            )}
            <div className="flex justify-between gap-2 sm:gap-4">
              <span className="text-muted-foreground font-medium min-w-[100px] sm:min-w-[120px] text-xs sm:text-sm">Penanggung Jawab:</span>
              <div className="text-right flex-1 break-words text-xs sm:text-sm font-semibold flex items-center justify-end gap-2 flex-wrap">
                <span>{installment.credit_applications?.members?.full_name || "-"}</span>
                {installment.credit_applications?.members?.position && (
                  <Badge 
                    className={cn(
                      "text-xs font-semibold shadow-sm w-fit capitalize inline-flex items-center gap-1",
                      installment.credit_applications.members.position.toLowerCase() === 'owner' && "bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 text-white border-purple-300 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]",
                      installment.credit_applications.members.position.toLowerCase() === 'admin' && "bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-600 text-white border-blue-300 shadow-md animate-shimmer animate-glow bg-[length:200%_100%]",
                      installment.credit_applications.members.position.toLowerCase() === 'sales' && "bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600 text-white border-orange-300 shadow-sm animate-shimmer bg-[length:200%_100%]",
                      installment.credit_applications.members.position.toLowerCase() === 'kasir' && "bg-gradient-to-r from-teal-500 via-cyan-400 to-teal-600 text-white border-teal-300 shadow-sm animate-shimmer bg-[length:200%_100%]"
                    )}
                  >
                    {installment.credit_applications.members.position.toLowerCase() === 'owner' && <Crown className="h-3 w-3" />}
                    {installment.credit_applications.members.position.toLowerCase() === 'admin' && <Shield className="h-3 w-3" />}
                    {installment.credit_applications.members.position.toLowerCase() === 'sales' && <Briefcase className="h-3 w-3" />}
                    {installment.credit_applications.members.position.toLowerCase() === 'kasir' && <Wallet className="h-3 w-3" />}
                    {installment.credit_applications.members.position}
                  </Badge>
                )}
              </div>
            </div>
            <DetailRow label="Angsuran Ke" value={`${installment.installment_number || "-"} / ${installment.credit_applications?.tenor_months || "-"}`} />
            <DetailRow label="Jatuh Tempo" value={formatDate(installment.due_date)} />
            <DetailRow label="Angsuran Bulanan" value={formatRupiah(installment.total_amount)} />
            <DetailRow label="Terbayar" value={formatRupiah(installment.paid_amount)} />
            
            {/* Penalty Breakdown - show if there's penalty or frozen penalty */}
            {daysOverdue > 0 && penalty > 0 && (
              <>
                <Separator className="my-3" />
                <div className="bg-orange-50 dark:bg-orange-950/20 p-3 rounded-lg space-y-2 border border-orange-200 dark:border-orange-900">
                  <div className="font-semibold text-orange-700 dark:text-orange-400 text-xs sm:text-sm mb-2">
                    Rincian Denda{installment.principal_paid ? ' (Dibekukan)' : ''}:
                  </div>
                  <DetailRow 
                    label="Hari Keterlambatan" 
                    value={`${daysOverdue} hari${installment.principal_paid ? ' (frozen)' : ''}`} 
                  />
                  <DetailRow 
                    label="Denda per Hari" 
                    value={formatRupiah(roundToThousand(installment.total_amount * (penaltyRate / 100)))} 
                  />
                  <DetailRow 
                    label="Perhitungan" 
                    value={`${daysOverdue} × ${formatRupiah(roundToThousand(installment.total_amount * (penaltyRate / 100)))}`}
                  />
                  <Separator className="my-2" />
                  <DetailRow 
                    label="Total Denda" 
                    value={formatRupiah(penalty)}
                  />
                  {installment.principal_paid && (
                    <div className="text-xs text-orange-600 dark:text-orange-400 mt-2 italic">
                      * Denda dibekukan saat angsuran pokok lunas
                    </div>
                  )}
                </div>
                <Separator className="my-3" />
              </>
            )}
            {daysOverdue > 0 && penalty === 0 && (
              <DetailRow label="Keterlambatan" value={`${daysOverdue} hari (data historis, tanpa denda)`} />
            )}
            
            <DetailRow 
              label="Sisa Tagihan" 
              value={formatRupiah(remainingAmount)} 
            />
            {currentInst?.paid_at && (
              <DetailRow label="Tgl Dibayar" value={formatDate(currentInst.paid_at)} />
            )}
            {currentInst?.principal_paid && (
              <DetailRow label="Status Pokok" value="Lunas" />
            )}
            {currentInst?.frozen_days_overdue > 0 && (
              <DetailRow label="Hari Dibekukan" value={`${currentInst.frozen_days_overdue} hari`} />
            )}
          </div>

          {/* Payment History */}
          {canManage && payments.length > 0 && (
            <>
              <Separator />
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Riwayat Pembayaran</h4>
                <ScrollArea className="max-h-[200px]">
                  <div className="space-y-2">
                    {payments.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-2 bg-muted/50 rounded text-xs">
                        <div className="flex-1">
                          <div className="font-medium">{formatRupiah(payment.amount)}</div>
                          <div className="text-muted-foreground">{formatDate(payment.payment_date)} • {payment.payment_method}</div>
                        </div>
                        {(isOwner || isAdmin) && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => {
                              setSelectedPaymentId(payment.id);
                              setShowDeleteDialog(true);
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </>
          )}

          {/* Action Buttons */}
          <div className="sticky bottom-0 left-0 right-0 bg-background border-t pt-4 -mx-4 px-4 pb-4">
            <div className="flex flex-col gap-2">
              {/* Tombol Bayar Angsuran: hanya muncul jika pokok belum lunas */}
              {canManage && onPay && !(currentInst?.principal_paid ?? installment.principal_paid) && (
                <Button 
                  className="w-full"
                  onClick={() => {
                    onPay(installment);
                    onOpenChange(false);
                  }}
                >
                  <Banknote className="h-4 w-4 mr-2" />
                  Bayar Angsuran
                </Button>
              )}
              {/* Tombol Bayar Denda: muncul jika ada sisa denda (frozen_penalty) */}
              {canManage && remainingPenalty > 0 && (
                <Button 
                  variant="outline"
                  className="w-full bg-orange-50 hover:bg-orange-100 text-orange-700 border-orange-200"
                  onClick={() => setShowPenaltyPaymentDialog(true)}
                >
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Bayar Denda ({formatRupiah(remainingPenalty)})
                </Button>
              )}
              <Button
                variant="outline"
                className="w-full bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                onClick={async () => {
                  let customerPhone = (installment.credit_applications?.customers?.phone || '').trim();
                  
                  if (!customerPhone) {
                    const customerId = installment.credit_applications?.customers?.id || installment.credit_applications?.customer_id;
                    if (customerId) {
                      const { data: fetched } = await supabase
                        .from('customers')
                        .select('phone')
                        .eq('id', customerId)
                        .maybeSingle();
                      customerPhone = (fetched as any)?.phone || '';
                    }
                  }
                  
                  if (!customerPhone) {
                    toast({
                      title: "Error",
                      description: "Nomor telepon nasabah tidak tersedia",
                      variant: "destructive",
                    });
                    return;
                  }

                  const message = generateInstallmentReminderMessage({
                    customerName: installment.credit_applications?.customers?.full_name || '',
                    customerPhone: customerPhone,
                    installmentNumber: installment.installment_number,
                    dueDate: installment.due_date,
                    totalAmount: remainingAmount,
                    daysOverdue: daysOverdue > 0 ? daysOverdue : undefined,
                    penalty: penalty > 0 ? penalty : undefined,
                    memberName: installment.credit_applications?.members?.full_name || '',
                    applicationNumber: installment.credit_applications?.application_number || '',
                    customerIdNumber: installment.credit_applications?.customers?.id_number,
                    dateOfBirth: installment.credit_applications?.customers?.date_of_birth,
                    bankName: undefined,
                    bankAccountNumber: undefined,
                    bankAccountHolder: undefined,
                  });

                  // Fetch bank info after generating message
                  const { data: bankDataRaw } = await supabase
                    .from("bank_accounts" as any)
                    .select("bank_name, account_number, account_holder")
                    .eq("is_primary", true)
                    .eq("is_active", true)
                    .maybeSingle();
                  
                  const bankData = bankDataRaw as any;
                  
                  const bankInfo = bankData?.bank_name ? {
                    bankName: bankData.bank_name,
                    bankAccountNumber: bankData.account_number,
                    bankAccountHolder: bankData.account_holder
                  } : undefined;

                  // Regenerate with bank info
                  const messageWithBank = generateInstallmentReminderMessage({
                    customerName: installment.credit_applications?.customers?.full_name || '',
                    customerPhone: customerPhone,
                    installmentNumber: installment.installment_number,
                    dueDate: installment.due_date,
                    totalAmount: remainingAmount,
                    daysOverdue: daysOverdue > 0 ? daysOverdue : undefined,
                    penalty: penalty > 0 ? penalty : undefined,
                    memberName: installment.credit_applications?.members?.full_name || '',
                    applicationNumber: installment.credit_applications?.application_number || '',
                    customerIdNumber: installment.credit_applications?.customers?.id_number,
                    dateOfBirth: installment.credit_applications?.customers?.date_of_birth,
                    bankName: bankInfo?.bankName,
                    bankAccountNumber: bankInfo?.bankAccountNumber,
                    bankAccountHolder: bankInfo?.bankAccountHolder,
                  });

                  const { usedClipboard } = openWhatsAppChat(customerPhone, messageWithBank);
                  
                  toast({
                    title: "Berhasil",
                    description: usedClipboard
                      ? "Pesan pengingat disalin ke clipboard — tempel (Paste) di WhatsApp untuk mengirim."
                      : "Membuka WhatsApp...",
                  });
                }}
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                Kirim Pesan WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </ResponsiveDialogContent>

      {/* Delete Confirmation Dialog with SuperCode */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pembayaran</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data pembayaran secara permanen. Masukkan SuperCode untuk melanjutkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="supercode">SuperCode</Label>
              <Input
                id="supercode"
                type="password"
                placeholder="Masukkan SuperCode"
                value={superCode}
                onChange={(e) => setSuperCode(e.target.value)}
                disabled={isDeleting}
              />
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel 
              onClick={() => {
                setSuperCode("");
                setSelectedPaymentId(null);
              }}
              disabled={isDeleting}
            >
              Batal
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeletePayment}
              disabled={!superCode || isDeleting}
              className="bg-destructive hover:bg-destructive/90"
            >
              {isDeleting ? "Menghapus..." : "Hapus"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Penalty Payment Dialog */}
      <PenaltyPaymentDialog
        open={showPenaltyPaymentDialog}
        onOpenChange={setShowPenaltyPaymentDialog}
        installment={installment}
        remainingPenalty={remainingPenalty}
        onSuccess={() => {
          setShowPenaltyPaymentDialog(false);
          loadPayments();
          onOpenChange(false);
        }}
      />
    </ResponsiveDialog>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2 sm:gap-4">
      <span className="text-muted-foreground font-medium min-w-[100px] sm:min-w-[120px] text-xs sm:text-sm">{label}:</span>
      <span className="text-right flex-1 break-words font-semibold text-xs sm:text-sm">{value}</span>
    </div>
  );
}
