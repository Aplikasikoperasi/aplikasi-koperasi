import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { formatRupiah, formatDateWIB } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { CheckCircle, XCircle, ArrowUpCircle, ArrowDownCircle, Loader2, Clock } from "lucide-react";
import { logSystemEvent } from "@/lib/systemLogger";

interface SaverInfo {
  id: string;
  full_name: string;
  saver_number: string;
  photo_url: string | null;
  balance: number;
}

interface PendingTransaction {
  id: string;
  type: "deposit" | "withdrawal";
  amount: number;
  date: string;
  notes: string | null;
  created_at: string;
  created_by_role: string | null;
  saver: SaverInfo;
}

interface SaverTransactionVerificationListProps {
  onCountChange?: (count: number) => void;
}

export default function SaverTransactionVerificationList({ 
  onCountChange 
}: SaverTransactionVerificationListProps) {
  const [transactions, setTransactions] = useState<PendingTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionDialog, setActionDialog] = useState<{
    open: boolean;
    transaction: PendingTransaction | null;
    action: "approve" | "reject" | null;
  }>({ open: false, transaction: null, action: null });
  const [rejectionReason, setRejectionReason] = useState("");
  const [processing, setProcessing] = useState(false);
  const { isOwner, isAdmin } = useUserRole();

  const canManage = isOwner || isAdmin;

  useEffect(() => {
    loadTransactions();

    // Subscribe to realtime changes
    const depositsChannel = supabase
      .channel("saver-deposits-verification")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "saver_deposits",
      }, () => loadTransactions())
      .subscribe();

    const withdrawalsChannel = supabase
      .channel("saver-withdrawals-verification")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "saver_withdrawals",
      }, () => loadTransactions())
      .subscribe();

    return () => {
      supabase.removeChannel(depositsChannel);
      supabase.removeChannel(withdrawalsChannel);
    };
  }, []);

  const loadTransactions = async () => {
    try {
      type DepositRow = { id: string; amount: number; deposit_date: string; notes: string | null; created_at: string; saver_id: string };
      type WithdrawalRow = { id: string; amount: number; withdrawal_date: string; notes: string | null; created_at: string; saver_id: string };
      type SaverRow = { id: string; full_name: string; saver_number: string; photo_url: string | null; balance: number | null };
      
      // Use explicit any to break the type chain
      const client = supabase as any;
      
      // Load pending deposits
      const { data: rawDeposits, error: depositsError } = await client
        .from("saver_deposits")
        .select("id, amount, deposit_date, notes, created_at, saver_id")
        .eq("status", "pending");
      
      if (depositsError) throw depositsError;
      const deposits: DepositRow[] = rawDeposits || [];

      // Load pending withdrawals
      const { data: rawWithdrawals, error: withdrawalsError } = await client
        .from("saver_withdrawals")
        .select("id, amount, withdrawal_date, notes, created_at, saver_id")
        .eq("status", "pending");
      
      if (withdrawalsError) throw withdrawalsError;
      const withdrawals: WithdrawalRow[] = rawWithdrawals || [];

      // Get all unique saver IDs
      const depositSaverIds = deposits.map((d) => d.saver_id);
      const withdrawalSaverIds = withdrawals.map((w) => w.saver_id);
      const allSaverIds = [...new Set([...depositSaverIds, ...withdrawalSaverIds])];

      // Get saver details
      let saversMap = new Map<string, SaverInfo>();
      if (allSaverIds.length > 0) {
        const { data: savers } = await client
          .from("savers")
          .select("id, full_name, saver_number, photo_url, balance")
          .in("id", allSaverIds);

        if (savers) {
          (savers as SaverRow[]).forEach((s) => {
            saversMap.set(s.id, {
              id: s.id,
              full_name: s.full_name,
              saver_number: s.saver_number,
              photo_url: s.photo_url,
              balance: s.balance || 0,
            });
          });
        }
      }

      // Combine and format transactions
      const formattedDeposits: PendingTransaction[] = deposits
        .filter((d) => saversMap.has(d.saver_id))
        .map((d) => ({
          id: d.id,
          type: "deposit" as const,
          amount: d.amount,
          date: d.deposit_date,
          notes: d.notes,
          created_at: d.created_at,
          created_by_role: null,
          saver: saversMap.get(d.saver_id)!,
        }));

      const formattedWithdrawals: PendingTransaction[] = withdrawals
        .filter((w) => saversMap.has(w.saver_id))
        .map((w) => ({
          id: w.id,
          type: "withdrawal" as const,
          amount: w.amount,
          date: w.withdrawal_date,
          notes: w.notes,
          created_at: w.created_at,
          created_by_role: null,
          saver: saversMap.get(w.saver_id)!,
        }));

      const allTransactions = [...formattedDeposits, ...formattedWithdrawals]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      setTransactions(allTransactions);
      onCountChange?.(allTransactions.length);
    } catch (error) {
      console.error("Error loading transactions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!actionDialog.transaction) return;
    setProcessing(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: member } = await supabase
        .from("members")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (!member) throw new Error("Member not found");

      const { transaction } = actionDialog;
      const table = transaction.type === "deposit" ? "saver_deposits" : "saver_withdrawals";
      
      // Update transaction status
      const { error: updateError } = await supabase
        .from(table)
        .update({
          status: transaction.type === "deposit" ? "approved" : "completed",
          verified_at: new Date().toISOString(),
          verified_by: member.id,
          ...(transaction.type === "withdrawal" ? { processed_by: member.id } : {}),
        })
        .eq("id", transaction.id);

      if (updateError) throw updateError;

      // Update saver balance
      const newBalance = transaction.type === "deposit"
        ? transaction.saver.balance + transaction.amount
        : transaction.saver.balance - transaction.amount;

      const { error: balanceError } = await supabase
        .from("savers")
        .update({
          balance: newBalance,
          deposit_balance: newBalance,
        })
        .eq("id", transaction.saver.id);

      if (balanceError) throw balanceError;

      await logSystemEvent({
        category: "financial",
        action: transaction.type === "deposit" ? "Verifikasi Deposit Debitur" : "Verifikasi Penarikan Debitur",
        description: `Menyetujui ${transaction.type === "deposit" ? "deposit" : "penarikan"} ${formatRupiah(transaction.amount)} untuk ${transaction.saver.full_name}`,
        metadata: {
          transaction_id: transaction.id,
          saver_id: transaction.saver.id,
          amount: transaction.amount,
        },
      });

      toast.success(`${transaction.type === "deposit" ? "Deposit" : "Penarikan"} berhasil diverifikasi`);
      setActionDialog({ open: false, transaction: null, action: null });
      loadTransactions();
    } catch (error: any) {
      console.error("Error approving transaction:", error);
      toast.error(`Gagal memverifikasi: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!actionDialog.transaction || !rejectionReason.trim()) {
      toast.error("Alasan penolakan wajib diisi");
      return;
    }
    setProcessing(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: member } = await supabase
        .from("members")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (!member) throw new Error("Member not found");

      const { transaction } = actionDialog;
      const table = transaction.type === "deposit" ? "saver_deposits" : "saver_withdrawals";
      
      // Update transaction status
      const { error: updateError } = await supabase
        .from(table)
        .update({
          status: "rejected",
          verified_at: new Date().toISOString(),
          verified_by: member.id,
          notes: `${transaction.notes || ""}\n[DITOLAK] ${rejectionReason}`.trim(),
        })
        .eq("id", transaction.id);

      if (updateError) throw updateError;

      await logSystemEvent({
        category: "financial",
        action: transaction.type === "deposit" ? "Tolak Deposit Debitur" : "Tolak Penarikan Debitur",
        description: `Menolak ${transaction.type === "deposit" ? "deposit" : "penarikan"} ${formatRupiah(transaction.amount)} untuk ${transaction.saver.full_name}. Alasan: ${rejectionReason}`,
        metadata: {
          transaction_id: transaction.id,
          saver_id: transaction.saver.id,
          amount: transaction.amount,
          reason: rejectionReason,
        },
      });

      toast.success(`${transaction.type === "deposit" ? "Deposit" : "Penarikan"} berhasil ditolak`);
      setActionDialog({ open: false, transaction: null, action: null });
      setRejectionReason("");
      loadTransactions();
    } catch (error: any) {
      console.error("Error rejecting transaction:", error);
      toast.error(`Gagal menolak: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 text-muted-foreground py-8">
        <CheckCircle className="h-8 w-8" />
        <p className="font-medium">Tidak ada transaksi pending</p>
        <p className="text-sm">Semua transaksi sudah diverifikasi</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {transactions.map((transaction) => (
          <Card key={`${transaction.type}-${transaction.id}`} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="relative">
                  <Avatar className="h-12 w-12 border">
                    <AvatarImage src={transaction.saver.photo_url || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {transaction.saver.full_name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`absolute -bottom-1 -right-1 p-1 rounded-full ${
                    transaction.type === "deposit" ? "bg-green-500" : "bg-red-500"
                  }`}>
                    {transaction.type === "deposit" ? (
                      <ArrowUpCircle className="h-3 w-3 text-white" />
                    ) : (
                      <ArrowDownCircle className="h-3 w-3 text-white" />
                    )}
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold">{transaction.saver.full_name}</p>
                    <Badge variant="outline" className="text-xs">
                      {transaction.saver.saver_number}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-2 mt-1">
                    <Badge 
                      variant={transaction.type === "deposit" ? "default" : "destructive"}
                      className="text-xs"
                    >
                      {transaction.type === "deposit" ? "Deposit" : "Penarikan"}
                    </Badge>
                    <span className={`font-bold ${
                      transaction.type === "deposit" ? "text-green-600" : "text-red-600"
                    }`}>
                      {transaction.type === "deposit" ? "+" : "-"}{formatRupiah(transaction.amount)}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                    <Clock className="h-3 w-3" />
                    <span>{formatDateWIB(transaction.created_at)}</span>
                    {transaction.created_by_role && (
                      <Badge variant="secondary" className="text-xs">
                        oleh {transaction.created_by_role}
                      </Badge>
                    )}
                  </div>

                  {transaction.notes && (
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {transaction.notes}
                    </p>
                  )}
                </div>

                {canManage && (
                  <div className="flex flex-col gap-2">
                    <Button
                      size="sm"
                      onClick={() => setActionDialog({ 
                        open: true, 
                        transaction, 
                        action: "approve" 
                      })}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => setActionDialog({ 
                        open: true, 
                        transaction, 
                        action: "reject" 
                      })}
                    >
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Approval Dialog */}
      <AlertDialog 
        open={actionDialog.open && actionDialog.action === "approve"} 
        onOpenChange={(open) => !open && setActionDialog({ open: false, transaction: null, action: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Setujui {actionDialog.transaction?.type === "deposit" ? "Deposit" : "Penarikan"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menyetujui{" "}
              {actionDialog.transaction?.type === "deposit" ? "deposit" : "penarikan"} sebesar{" "}
              <strong>{formatRupiah(actionDialog.transaction?.amount || 0)}</strong> untuk{" "}
              <strong>{actionDialog.transaction?.saver.full_name}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleApprove} disabled={processing}>
              {processing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Setujui
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Rejection Dialog */}
      <AlertDialog 
        open={actionDialog.open && actionDialog.action === "reject"} 
        onOpenChange={(open) => {
          if (!open) {
            setActionDialog({ open: false, transaction: null, action: null });
            setRejectionReason("");
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Tolak {actionDialog.transaction?.type === "deposit" ? "Deposit" : "Penarikan"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menolak{" "}
              {actionDialog.transaction?.type === "deposit" ? "deposit" : "penarikan"} sebesar{" "}
              <strong>{formatRupiah(actionDialog.transaction?.amount || 0)}</strong> untuk{" "}
              <strong>{actionDialog.transaction?.saver.full_name}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-2">
            <Label htmlFor="rejection-reason">Alasan Penolakan *</Label>
            <Textarea
              id="rejection-reason"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Masukkan alasan penolakan..."
              rows={3}
            />
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Batal</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleReject} 
              disabled={processing || !rejectionReason.trim()}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {processing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Tolak
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
