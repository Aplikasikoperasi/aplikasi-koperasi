import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CurrencyInput } from "@/components/ui/currency-input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowUpCircle, Loader2, Building2, AlertCircle, Copy, Check, KeyRound, ArrowLeft } from "lucide-react";
import { format } from "date-fns";
import { formatAccountNumber } from "@/lib/utils";

interface DepositAccount {
  id: string;
  bank_name: string;
  account_number: string;
  account_holder: string;
  is_primary: boolean;
}

interface SaverSelfDepositDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saverId: string;
  saverName: string;
  hasPin: boolean;
  onSuccess?: () => void;
}

export default function SaverSelfDepositDialog({
  open,
  onOpenChange,
  saverId,
  saverName,
  hasPin,
  onSuccess,
}: SaverSelfDepositDialogProps) {
  const [step, setStep] = useState<"form" | "pin">("form");
  const [amount, setAmount] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [depositAccounts, setDepositAccounts] = useState<DepositAccount[]>([]);
  const [copiedAccount, setCopiedAccount] = useState<string | null>(null);
  const [pin, setPin] = useState("");
  const [pinAttempts, setPinAttempts] = useState(0);
  const MAX_PIN_ATTEMPTS = 3;

  // Reset form when dialog opens/closes
  useEffect(() => {
    if (!open) {
      setStep("form");
      setAmount("");
      setNotes("");
      setPin("");
      setPinAttempts(0);
      setCopiedAccount(null);
    }
  }, [open]);

  // Fetch deposit accounts on dialog open
  useEffect(() => {
    const fetchDepositAccounts = async () => {
      const { data, error } = await supabase
        .from("deposit_accounts")
        .select("id, bank_name, account_number, account_holder, is_primary")
        .eq("is_active", true)
        .order("is_primary", { ascending: false })
        .order("bank_name");

      if (!error && data) {
        setDepositAccounts(data);
      }
    };

    if (open) {
      fetchDepositAccounts();
    }
  }, [open]);

  const numericAmount = parseInt(amount || "0", 10);

  const copyToClipboard = async (text: string, accountId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedAccount(accountId);
      toast.success("Nomor rekening disalin!");
      setTimeout(() => setCopiedAccount(null), 2000);
    } catch (error) {
      toast.error("Gagal menyalin");
    }
  };

  const handleFormSubmit = () => {
    if (numericAmount <= 0) {
      toast.error("Jumlah deposit harus lebih dari 0");
      return;
    }

    if (depositAccounts.length === 0) {
      toast.error("Tidak ada rekening deposit yang tersedia");
      return;
    }

    if (!hasPin) {
      toast.error("Anda belum mengatur PIN. Silakan atur PIN terlebih dahulu di halaman Profil.");
      return;
    }

    // Move to PIN verification step
    setStep("pin");
    setPin("");
  };

  const handlePinSubmit = async () => {
    if (pin.length !== 6) {
      toast.error("PIN harus 6 digit");
      return;
    }

    setIsSubmitting(true);
    try {
      // Verify PIN via edge function
      const { data: pinResult, error: pinError } = await supabase.functions.invoke(
        "verify-saver-pin",
        { body: { saver_id: saverId, pin } }
      );

      if (pinError || !pinResult?.success) {
        const newAttempts = pinAttempts + 1;
        setPinAttempts(newAttempts);
        setPin("");

        if (newAttempts >= MAX_PIN_ATTEMPTS) {
          toast.error("Terlalu banyak percobaan PIN salah. Silakan coba lagi nanti.");
          onOpenChange(false);
          return;
        }

        toast.error(`PIN salah. Sisa percobaan: ${MAX_PIN_ATTEMPTS - newAttempts}`);
        setIsSubmitting(false);
        return;
      }

      // PIN valid, proceed with deposit
      const primaryAccount = depositAccounts.find(acc => acc.is_primary) || depositAccounts[0];
      const paymentDetails = `${primaryAccount.bank_name} - ${primaryAccount.account_number} a.n. ${primaryAccount.account_holder}`;

      const { error: depositError } = await supabase
        .from("saver_deposits")
        .insert({
          saver_id: saverId,
          amount: numericAmount,
          deposit_date: format(new Date(), "yyyy-MM-dd"),
          remaining_balance: 0,
          is_eligible_for_interest: true,
          total_interest_earned: 0,
          transaction_type: "deposit",
          notes: notes || "Pengajuan deposit mandiri oleh debitur",
          payment_method: "transfer",
          payment_details: paymentDetails,
          status: "pending",
        });

      if (depositError) throw depositError;

      toast.success("Pengajuan deposit berhasil! Menunggu verifikasi admin.");
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error("Error adding deposit:", error);
      toast.error(`Gagal mengajukan deposit: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step === "pin" ? (
              <KeyRound className="h-5 w-5 text-primary" />
            ) : (
              <ArrowUpCircle className="h-5 w-5 text-green-600" />
            )}
            {step === "pin" ? "Verifikasi PIN" : "Pengajuan Deposit"}
          </DialogTitle>
        </DialogHeader>

        {step === "form" ? (
          <>
            <div className="space-y-4">
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">Debitur</p>
                <p className="font-semibold">{saverName}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Jumlah Deposit</Label>
                <CurrencyInput
                  id="amount"
                  value={amount}
                  onChange={(val) => setAmount(val)}
                  placeholder="Masukkan jumlah deposit"
                />
              </div>

              {/* Bank Account List */}
              <div className="space-y-2">
                <Label>Rekening Tujuan Transfer</Label>
                {depositAccounts.length === 0 ? (
                  <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                    <p className="text-sm text-destructive">
                      Belum ada rekening deposit yang dikonfigurasi. Hubungi admin.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {depositAccounts.map((account) => (
                      <div
                        key={account.id}
                        className={`p-3 rounded-lg border ${
                          account.is_primary
                            ? "bg-primary/5 border-primary/30"
                            : "bg-muted/50 border-border"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Building2 className="h-4 w-4 text-blue-500" />
                              <span className="font-medium">{account.bank_name}</span>
                              {account.is_primary && (
                                <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                                  Utama
                                </span>
                              )}
                            </div>
                            <p className="font-mono text-lg font-semibold mt-1">
                              {formatAccountNumber(account.account_number)}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              a.n. {account.account_holder}
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(account.account_number, account.id)}
                            className="min-h-[36px]"
                          >
                            {copiedAccount === account.id ? (
                              <Check className="h-4 w-4 text-green-600" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Catatan (Opsional)</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Catatan tambahan..."
                  rows={2}
                />
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <p className="text-sm text-amber-700 dark:text-amber-300">
                  ⚠️ Setelah transfer, deposit akan menunggu verifikasi terlebih dahulu. Chat admin untuk mengirimkan bukti transfer.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Batal
              </Button>
              <Button 
                onClick={handleFormSubmit} 
                disabled={isSubmitting || numericAmount <= 0 || depositAccounts.length === 0}
              >
                Lanjutkan
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <div className="space-y-6 py-4">
              <div className="text-center space-y-2">
                <p className="text-sm text-muted-foreground">
                  Konfirmasi deposit sebesar
                </p>
                <p className="text-2xl font-bold text-green-600">
                  Rp {numericAmount.toLocaleString("id-ID")}
                </p>
              </div>

              <div className="space-y-3">
                <Label className="text-center block">
                  Masukkan PIN Anda untuk konfirmasi
                </Label>
                <div className="flex justify-center">
                  <InputOTP
                    maxLength={6}
                    value={pin}
                    onChange={setPin}
                    disabled={isSubmitting}
                  >
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
                {pinAttempts > 0 && (
                  <p className="text-sm text-destructive text-center">
                    Sisa percobaan: {MAX_PIN_ATTEMPTS - pinAttempts}
                  </p>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => {
                  setStep("form");
                  setPin("");
                }}
                disabled={isSubmitting}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Button>
              <Button 
                onClick={handlePinSubmit} 
                disabled={isSubmitting || pin.length !== 6}
              >
                {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Ajukan Deposit
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
