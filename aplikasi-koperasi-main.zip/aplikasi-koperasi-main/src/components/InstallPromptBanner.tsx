import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { X, Download } from "lucide-react";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { toast } from "sonner";
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
  }>;
}
export const InstallPromptBanner = () => {
  const [showBanner, setShowBanner] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const {
    businessName
  } = useBusinessInfo();
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isEmbedded = (() => {
    try {
      return window.self !== window.top;
    } catch {
      return true;
    }
  })();
  useEffect(() => {
    // Check if app is already installed (running in standalone mode)
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone || // iOS Safari
      document.referrer.includes("android-app://"); // Android

    console.log("[InstallPromptBanner] Init check:", {
      isStandalone,
      displayMode: window.matchMedia("(display-mode: standalone)").matches,
      iosStandalone: (window.navigator as any).standalone,
      referrer: document.referrer,
    });

    // Always show banner when opened via browser (not standalone)
    setShowBanner(!isStandalone);

    // Listen for the beforeinstallprompt event (Chromium browsers)
    const handleBeforeInstallPrompt = (e: Event) => {
      console.log("[InstallPromptBanner] beforeinstallprompt event captured");
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);

      if (!isStandalone) setShowBanner(true);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    // Listen for successful app installation
    const handleAppInstalled = () => {
      setShowBanner(false);
      setDeferredPrompt(null);
    };
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);
  const handleInstallClick = async () => {
    console.log('[InstallPromptBanner] Install clicked, deferredPrompt:', !!deferredPrompt);

    // In Lovable Preview (embedded iframe), browsers won't fire beforeinstallprompt.
    if (isEmbedded) {
      toast.info("Install PWA harus dibuka di tab biasa (bukan Preview).", { duration: 5000 });
      // Open the same URL in a top-level tab using this user gesture
      window.open(window.location.href, "_blank", "noopener,noreferrer");
      return;
    }

    // iOS Safari does not support beforeinstallprompt → always show instructions
    if (!deferredPrompt) {
      if (isIOS) {
        showManualInstructions();
        return;
      }

      // Quick diagnostics (helps us know why desktop doesn't show the prompt)
      const hasSwController = !!navigator.serviceWorker?.controller;
      let hasSwRegistration = false;
      try {
        hasSwRegistration = !!(await navigator.serviceWorker?.getRegistration());
      } catch {
        hasSwRegistration = false;
      }

      let manifestOk = false;
      try {
        const res = await fetch("/manifest.webmanifest", { cache: "no-store" });
        manifestOk = res.ok;
      } catch {
        manifestOk = false;
      }

      console.log("[InstallPromptBanner] No beforeinstallprompt yet:", {
        isSecureContext: window.isSecureContext,
        hasSwController,
        hasSwRegistration,
        manifestOk,
        userAgent: navigator.userAgent,
      });

      if (!window.isSecureContext) {
        toast.error("Install PWA butuh HTTPS. Pastikan dibuka lewat https://mitradana.id", { duration: 7000 });
        return;
      }

      if (!manifestOk) {
        toast.error("Manifest PWA tidak terbaca. Coba refresh / bersihkan cache situs lalu ulangi.", {
          duration: 8000,
        });
        return;
      }

      if (!hasSwRegistration || !hasSwController) {
        toast.info(
          "PWA belum siap (service worker belum aktif). Coba refresh 1x, tunggu 5–10 detik, lalu klik Install lagi.",
          { duration: 9000 }
        );
        return;
      }

      toast.info(
        "Chrome belum menampilkan prompt install (sering karena pernah ditolak atau butuh sedikit interaksi). Tunggu 10–30 detik lalu klik Install lagi, atau pakai menu (⋮) → Install app.",
        { duration: 10000 }
      );
      return;
    }

    try {
      // Show the install prompt
      await deferredPrompt.prompt();

      // Wait for the user's response
      const { outcome } = await deferredPrompt.userChoice;
      console.log('[InstallPromptBanner] User choice:', outcome);

      if (outcome === 'accepted') {
        console.log('[InstallPromptBanner] User accepted the install prompt');
        setShowBanner(false);
      }
    } catch (error) {
      console.error('[InstallPromptBanner] Error showing install prompt:', error);
      toast.error("Gagal menampilkan prompt install. Coba refresh lalu ulangi.");
    }

    // Clear the deferred prompt
    setDeferredPrompt(null);
  };
  const showManualInstructions = () => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const message = isIOS
      ? 'Untuk install: Tap tombol Share (⬆️) lalu pilih "Add to Home Screen"'
      : 'Untuk install: Tap menu browser (⋮) lalu pilih "Install app" atau "Add to Home screen"';

    toast.info(message, { duration: 7000 });
  };
  const handleDismiss = () => {
    // Hide only for current view; on next browser load it will show again
    setShowBanner(false);
  };
  if (!showBanner) return null;
  return <div className="fixed bottom-4 right-4 z-50 animate-fade-in md:bottom-6 md:right-6">
      <div className="bg-gradient-to-br from-primary to-accent rounded-xl shadow-xl p-3 max-w-[280px] md:max-w-xs relative border border-primary/20">
        <Button onClick={handleDismiss} size="icon" variant="ghost" className="absolute -top-2 -right-2 h-5 w-5 text-primary-foreground bg-primary-foreground/20 hover:text-primary-foreground hover:bg-primary-foreground/30 rounded-full">
          <X className="h-2.5 w-2.5" />
        </Button>
        
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-background rounded-lg flex items-center justify-center flex-shrink-0 shadow-md">
            <Download className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0 pr-6">
            <p className="font-semibold text-primary-foreground text-xs mb-0.5 truncate">
              {businessName}
            </p>
            
            <Button
              onClick={handleInstallClick}
              size="sm"
              className="bg-background text-primary hover:bg-background/90 shadow-md font-semibold w-full text-xs h-8"
            >
              Install
            </Button>
          </div>
        </div>
      </div>
    </div>;
};