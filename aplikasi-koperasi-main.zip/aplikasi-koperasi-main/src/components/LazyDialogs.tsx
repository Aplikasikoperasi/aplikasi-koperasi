import { lazy, Suspense, ComponentType } from "react";
import { Skeleton } from "@/components/ui/skeleton";

// Lazy load dialog components with named exports wrapped as default
export const ApplicationDetailDialog = lazy(() => 
  import("@/components/ApplicationDetailDialog").then(module => ({ default: module.ApplicationDetailDialog }))
);

export const BlockedCustomerDetailDialog = lazy(() => 
  import("@/components/BlockedCustomerDetailDialog").then(module => ({ default: module.BlockedCustomerDetailDialog }))
);

export const ChangeRequestDetailDialog = lazy(() => 
  import("@/components/ChangeRequestDetailDialog").then(module => ({ default: module.ChangeRequestDetailDialog }))
);

export const CustomerChangeRequestDialog = lazy(() => 
  import("@/components/CustomerChangeRequestDialog").then(module => ({ default: module.CustomerChangeRequestDialog }))
);

export const CustomerDetailDialog = lazy(() => 
  import("@/components/CustomerDetailDialog").then(module => ({ default: module.CustomerDetailDialog }))
);

export const DisbursementReceiptDialog = lazy(() => 
  import("@/components/DisbursementReceiptDialog").then(module => ({ default: module.default }))
);

export const EditPaymentDialog = lazy(() => 
  import("@/components/EditPaymentDialog").then(module => ({ default: module.EditPaymentDialog }))
);

export const InstallmentDetailDialog = lazy(() => 
  import("@/components/InstallmentDetailDialog").then(module => ({ default: module.InstallmentDetailDialog }))
);

export const InstallmentPaymentDialog = lazy(() => 
  import("@/components/InstallmentPaymentDialog").then(module => ({ default: module.default }))
);

export const MemberDetailDialog = lazy(() => 
  import("@/components/MemberDetailDialog").then(module => ({ default: module.MemberDetailDialog }))
);

export const PaymentDetailDialog = lazy(() => 
  import("@/components/PaymentDetailDialog").then(module => ({ default: module.PaymentDetailDialog }))
);

export const SupercodeVerificationDialog = lazy(() => 
  import("@/components/SupercodeVerificationDialog").then(module => ({ default: module.SupercodeVerificationDialog }))
);

export const AgreementPreviewDialog = lazy(() => 
  import("@/components/AgreementPreviewDialog").then(module => ({ default: module.AgreementPreviewDialog }))
);

export const InstallmentHistoryDialog = lazy(() => 
  import("@/components/InstallmentHistoryDialog").then(module => ({ default: module.InstallmentHistoryDialog }))
);

// Loading fallback component
const DialogLoadingFallback = () => (
  <div className="p-6 space-y-4">
    <Skeleton className="h-8 w-3/4" />
    <Skeleton className="h-4 w-full" />
    <Skeleton className="h-4 w-full" />
    <Skeleton className="h-4 w-2/3" />
  </div>
);

// HOC to wrap lazy-loaded dialogs with Suspense
export function withSuspense<P extends object>(
  Component: ComponentType<P>
): ComponentType<P> {
  return function WrappedComponent(props: P) {
    return (
      <Suspense fallback={<DialogLoadingFallback />}>
        <Component {...props} />
      </Suspense>
    );
  };
}

// Export pre-wrapped components for easy use
export const LazyApplicationDetailDialog = withSuspense(ApplicationDetailDialog);
export const LazyBlockedCustomerDetailDialog = withSuspense(BlockedCustomerDetailDialog);
export const LazyChangeRequestDetailDialog = withSuspense(ChangeRequestDetailDialog);
export const LazyCustomerChangeRequestDialog = withSuspense(CustomerChangeRequestDialog);
export const LazyCustomerDetailDialog = withSuspense(CustomerDetailDialog);
export const LazyDisbursementReceiptDialog = withSuspense(DisbursementReceiptDialog);
export const LazyEditPaymentDialog = withSuspense(EditPaymentDialog);
export const LazyInstallmentDetailDialog = withSuspense(InstallmentDetailDialog);
export const LazyInstallmentPaymentDialog = withSuspense(InstallmentPaymentDialog);
export const LazyMemberDetailDialog = withSuspense(MemberDetailDialog);
export const LazyPaymentDetailDialog = withSuspense(PaymentDetailDialog);
export const LazySupercodeVerificationDialog = withSuspense(SupercodeVerificationDialog);
export const LazyAgreementPreviewDialog = withSuspense(AgreementPreviewDialog);
export const LazyInstallmentHistoryDialog = withSuspense(InstallmentHistoryDialog);
