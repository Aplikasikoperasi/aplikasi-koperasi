import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function MaintenanceBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [maintenanceTitle, setMaintenanceTitle] = useState("");
  const [maintenanceMessage, setMaintenanceMessage] = useState("");

  useEffect(() => {
    loadMaintenanceMode();

    // Subscribe to real-time changes
    const subscription = supabase
      .channel('maintenance-mode-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'app_settings'
        },
        () => {
          loadMaintenanceMode();
          setIsDismissed(false); // Show banner again when settings change
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadMaintenanceMode = async () => {
    const { data, error } = await supabase.rpc("get_public_app_settings");

    if (!error && data) {
      const settings = data as {
        maintenance_mode_enabled: boolean;
        maintenance_message: string;
        maintenance_title: string;
      };
      setIsVisible(settings.maintenance_mode_enabled || false);
      setMaintenanceMessage(settings.maintenance_message || "Sistem sedang dalam maintenance. Mohon maaf atas ketidaknyamanan ini.");
      setMaintenanceTitle(settings.maintenance_title || "Mode Maintenance");
    }
  };

  if (!isVisible || isDismissed) {
    return null;
  }

  return (
    <Alert variant="destructive" className="mb-4 animate-in fade-in slide-in-from-top-2 border-amber-500 bg-amber-50 dark:bg-amber-950">
      <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
      <AlertTitle className="text-amber-900 dark:text-amber-100 font-semibold">
        {maintenanceTitle}
      </AlertTitle>
      <AlertDescription className="text-amber-800 dark:text-amber-200">
        {maintenanceMessage}
      </AlertDescription>
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-2 right-2 h-6 w-6 hover:bg-amber-100 dark:hover:bg-amber-900"
        onClick={() => setIsDismissed(true)}
      >
        <X className="h-4 w-4" />
      </Button>
    </Alert>
  );
}
