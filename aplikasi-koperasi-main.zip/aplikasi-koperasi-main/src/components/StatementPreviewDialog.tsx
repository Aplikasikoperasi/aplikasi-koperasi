import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, Printer } from "lucide-react";
import { formatRupiah, formatDate } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StatementData } from "@/lib/generateStatementPDF";

export type { StatementData };

interface StatementPreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  statementData: StatementData;
  onDownload: () => void;
  onPrint: () => void;
}

const DAYS = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

function getDateComponents(date: Date) {
  return {
    dayName: DAYS[date.getDay()],
    day: date.getDate(),
    month: MONTHS[date.getMonth()],
    year: date.getFullYear(),
  };
}

export function StatementPreviewDialog({
  open,
  onOpenChange,
  statementData,
  onDownload,
  onPrint,
}: StatementPreviewDialogProps) {
  const appDate = getDateComponents(statementData.applicationDate);

  return (
    <>
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #statement-content, #statement-content * { visibility: visible; }
          #statement-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 0;
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            font-size: 11pt;
            line-height: 1.4;
            color: black;
            background: white;
          }
          @page { size: A4; margin: 1.5cm; }
        }
      `}</style>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Preview Surat Pernyataan</DialogTitle>
          </DialogHeader>
          
          <ScrollArea className="h-[65vh] pr-4">
            <div id="statement-content" className="space-y-3 text-sm p-4 bg-white text-black">
              {/* Title */}
              <div className="text-center space-y-1 mb-4">
                <h1 className="text-lg font-bold">SURAT PERNYATAAN</h1>
                <h2 className="text-base font-bold">PENANGGUNG JAWAB KREDIT</h2>
              </div>

              {/* Opening */}
              <p className="text-justify">
                Pada hari ini {appDate.dayName}, tanggal {appDate.day} {appDate.month} {appDate.year}, saya yang bertanda tangan di bawah ini:
              </p>

              {/* Two Column Layout - PJ on left, Customer on right */}
              <div className="grid grid-cols-2 gap-4 mt-4">
                {/* Penanggung Jawab Section */}
                <div className="border rounded-lg p-3 bg-amber-50/50">
                  <h3 className="font-bold text-center mb-2 text-amber-800 border-b pb-1">PENANGGUNG JAWAB</h3>
                  <div className="flex gap-3">
                    <Avatar className="h-16 w-20 rounded border flex-shrink-0">
                      <AvatarImage 
                        src={statementData.memberPhotoUrl} 
                        alt={statementData.memberName}
                        className="object-cover"
                      />
                      <AvatarFallback className="bg-amber-100 text-amber-800 text-xs rounded">
                        {statementData.memberName.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 text-xs space-y-0.5">
                      <p><span className="font-semibold">Nama:</span> {statementData.memberName}</p>
                      <p><span className="font-semibold">NIK:</span> {statementData.memberNik || "-"}</p>
                      <p><span className="font-semibold">Tgl Lahir:</span> {statementData.memberDateOfBirth ? formatDate(statementData.memberDateOfBirth) : "-"}</p>
                      <p><span className="font-semibold">Alamat:</span> {statementData.memberAddress || "-"}</p>
                    </div>
                  </div>
                </div>

                {/* Nasabah Section */}
                <div className="border rounded-lg p-3 bg-blue-50/50">
                  <h3 className="font-bold text-center mb-2 text-blue-800 border-b pb-1">NASABAH</h3>
                  <div className="flex gap-3">
                    <Avatar className="h-16 w-20 rounded border flex-shrink-0">
                      <AvatarImage 
                        src={statementData.customerPhotoUrl} 
                        alt={statementData.customerName}
                        className="object-cover"
                      />
                      <AvatarFallback className="bg-blue-100 text-blue-800 text-xs rounded">
                        {statementData.customerName.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 text-xs space-y-0.5">
                      <p><span className="font-semibold">Nama:</span> {statementData.customerName}</p>
                      <p><span className="font-semibold">NIK:</span> {statementData.customerNik || "-"}</p>
                      <p><span className="font-semibold">Tgl Lahir:</span> {statementData.customerDateOfBirth ? formatDate(statementData.customerDateOfBirth) : "-"}</p>
                      <p><span className="font-semibold">Alamat:</span> {statementData.customerAddress || "-"}</p>
                      <p><span className="font-semibold">Telepon:</span> {statementData.customerPhone || "-"}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Statement Text */}
              <p className="text-justify mt-3">
                Dengan ini menyatakan bahwa saya bersedia menjadi Penanggung Jawab dan Saksi untuk pengajuan kredit dengan rincian sebagai berikut:
              </p>

              {/* Credit Details - Compact Table */}
              <div className="border rounded-lg overflow-hidden mt-2">
                <table className="w-full text-xs">
                  <tbody>
                    <tr className="border-b bg-gray-50">
                      <td className="py-1.5 px-3 font-semibold w-1/4">No. Pengajuan</td>
                      <td className="py-1.5 px-3">{statementData.applicationNumber}</td>
                      <td className="py-1.5 px-3 font-semibold w-1/4">Tenor</td>
                      <td className="py-1.5 px-3">{statementData.tenor} Bulan</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-1.5 px-3 font-semibold">Jumlah Pinjaman</td>
                      <td className="py-1.5 px-3 font-bold text-green-700">{formatRupiah(statementData.amount)}</td>
                      <td className="py-1.5 px-3 font-semibold">Bunga</td>
                      <td className="py-1.5 px-3">{statementData.interestRate}% / bulan</td>
                    </tr>
                    <tr className={statementData.collateralDescription ? "border-b" : ""}>
                      <td className="py-1.5 px-3 font-semibold">Angsuran/Bulan</td>
                      <td className="py-1.5 px-3 font-bold text-primary" colSpan={3}>{formatRupiah(statementData.monthlyInstallment)}</td>
                    </tr>
                    {statementData.collateralDescription && (
                      <tr>
                        <td className="py-1.5 px-3 font-semibold">Jaminan</td>
                        <td className="py-1.5 px-3" colSpan={3}>{statementData.collateralDescription}</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Declaration Points */}
              <div className="mt-3">
                <p className="font-bold mb-1">PERNYATAAN:</p>
                <ol className="list-decimal list-inside space-y-1.5 text-justify text-xs">
                  <li>
                    Saya menyatakan bersedia menjadi Penanggung Jawab dan sebagai Saksi serta menjamin kelancaran pembayaran angsuran kredit sebesar <strong>{formatRupiah(statementData.monthlyInstallment)}</strong> per bulan selama <strong>{statementData.tenor} bulan</strong> sampai selesai.
                  </li>
                  <li>
                    Apabila nasabah <strong>{statementData.customerName}</strong> melarikan diri dan tidak membayar angsuran, maka saya yang akan menggantikan dan membayar seluruh sisa pinjaman yang belum dibayarkan.
                  </li>
                  <li>
                    Pernyataan ini saya buat dengan penuh kesadaran dan tanpa paksaan dari pihak manapun.
                  </li>
                </ol>
              </div>

              {/* Closing */}
              <p className="mt-3 text-justify">
                Demikian surat pernyataan ini saya buat untuk dipergunakan sebagaimana mestinya.
              </p>

              {/* Signature Section - Single column for PJ only */}
              <div className="flex justify-end mt-6">
                <div className="text-center w-56">
                  <p className="text-xs text-gray-500 mb-1">{appDate.day} {appDate.month} {appDate.year}</p>
                  <p className="font-semibold text-xs">Yang Menyatakan,</p>
                  <div className="h-16 mt-1 border-b border-dashed border-gray-300 mx-4"></div>
                  <p className="mt-1 font-bold text-sm">({statementData.memberName})</p>
                  <p className="text-xs text-muted-foreground">Penanggung Jawab Kredit</p>
                </div>
              </div>

              {/* Footer Note */}
              <p className="text-xs text-gray-500 italic mt-4 text-center">
                * Surat pernyataan ini merupakan bagian tidak terpisahkan dari perjanjian kredit.
              </p>
            </div>
          </ScrollArea>

          <DialogFooter className="flex-row gap-2 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Tutup
            </Button>
            <Button 
              variant="outline" 
              className="bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
              onClick={onPrint}
            >
              <Printer className="h-4 w-4 mr-2" />
              Cetak PDF
            </Button>
            <Button onClick={onDownload}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
