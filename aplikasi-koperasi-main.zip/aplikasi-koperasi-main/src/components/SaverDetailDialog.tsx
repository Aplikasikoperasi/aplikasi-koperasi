import { useState, useEffect } from "react";
import {
  ResponsiveDialog,
  ResponsiveDialogContent,
  ResponsiveDialogHeader,
  ResponsiveDialogTitle,
} from "@/components/ui/responsive-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDateWIB, formatRupiah, getNowInWIB } from "@/lib/utils";
import { User, Phone, Mail, MapPin, Calendar, CreditCard, Hash, Wallet, Briefcase, Pencil, Lock, ShieldCheck, Award, Medal, Trophy, ArrowUpCircle, ArrowDownCircle, Sparkles, History, TrendingUp, Plus, Minus, Filter, Banknote, Building2, ChevronLeft, ChevronRight, KeyRound, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRole } from "@/contexts/UserRoleContext";
import SaverDepositDialog from "./SaverDepositDialog";
import SaverWithdrawalDialog from "./SaverWithdrawalDialog";
import { SupercodeVerificationDialog } from "./SupercodeVerificationDialog";

interface Saver {
  id: string;
  saver_number: string;
  account_number: string;
  full_name: string;
  id_number: string;
  phone: string;
  address: string;
  date_of_birth: string | null;
  email: string | null;
  photo_url: string | null;
  status: string;
  created_at: string;
  balance: number | null;
  occupation: string | null;
  mother_maiden_name?: string | null;
  deposit_balance?: number | null;
  interest_balance?: number | null;
  tier_level?: string | null;
}

interface DepositTransaction {
  id: string;
  amount: number;
  deposit_date: string;
  transaction_type: string;
  remaining_balance: number;
  is_eligible_for_interest: boolean;
  total_interest_earned: number;
  payment_method: string | null;
  payment_details: string | null;
  notes: string | null;
  created_at: string;
  created_by: string | null;
  created_by_member?: { full_name: string } | null;
  approved_by: string | null;
  approved_by_member?: { full_name: string } | null;
  status: string | null;
  transaction_number: string | null;
}

interface InterestTransaction {
  id: string;
  amount: number;
  interest_rate: number;
  tier_level: string;
  principal_amount: number;
  period_month: string;
  payment_date: string;
  created_at: string;
}

interface WithdrawalTransaction {
  id: string;
  amount: number;
  withdrawal_date: string;
  status: string;
  notes: string | null;
  payment_method: string | null;
  payment_details: string | null;
  created_at: string;
  processed_by: string | null;
  processed_by_member?: { full_name: string } | null;
  transaction_number: string | null;
}

interface SaverDetailDialogProps {
  saver: Saver | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit?: (saver: Saver) => void;
}

// Tier badge component with shimmer/glow effects
export function TierBadge({ tier, size = "md" }: { tier: string; size?: "sm" | "md" }) {
  const sizeClasses = size === "sm" ? "text-xs px-2 py-0.5" : "text-sm px-3 py-1";
  const iconSize = size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5";
  
  if (tier === 'platinum') {
    return (
      <Badge className={`bg-gradient-to-r from-purple-400 via-pink-400 to-purple-500 text-white border-purple-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%] ${sizeClasses}`}>
        <Trophy className={`${iconSize} mr-1`} />
        Platinum
      </Badge>
    );
  }
  if (tier === 'gold') {
    return (
      <Badge className={`bg-gradient-to-r from-yellow-400 via-amber-300 to-amber-500 text-amber-900 border-yellow-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%] ${sizeClasses}`}>
        <Medal className={`${iconSize} mr-1`} />
        Gold
      </Badge>
    );
  }
  return (
    <Badge className={`bg-gradient-to-r from-slate-300 via-slate-200 to-slate-400 text-slate-800 border-slate-200 shadow-md animate-shimmer bg-[length:200%_100%] ${sizeClasses}`}>
      <Award className={`${iconSize} mr-1`} />
      Silver
    </Badge>
  );
}

export default function SaverDetailDialog({
  saver,
  open,
  onOpenChange,
  onEdit,
}: SaverDetailDialogProps) {
  const { isOwner, isAdmin } = useUserRole();
  const [isVerified, setIsVerified] = useState(false);
  const [dobAnswer, setDobAnswer] = useState("");
  const [motherNameAnswer, setMotherNameAnswer] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState("");
  const [verificationData, setVerificationData] = useState<{
    date_of_birth: string | null;
    mother_maiden_name: string | null;
  } | null>(null);
  const [deposits, setDeposits] = useState<DepositTransaction[]>([]);
  const [interests, setInterests] = useState<InterestTransaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalTransaction[]>([]);
  const [loadingTransactions, setLoadingTransactions] = useState(false);
  const [saverDetails, setSaverDetails] = useState<{
    balance: number;
    deposit_balance: number;
    interest_balance: number;
    tier_level: string;
  } | null>(null);
  const [showDepositDialog, setShowDepositDialog] = useState(false);
  const [showWithdrawalDialog, setShowWithdrawalDialog] = useState(false);
  
  // PIN Reset states
  const [showPinResetConfirm, setShowPinResetConfirm] = useState(false);
  const [isResettingPin, setIsResettingPin] = useState(false);
  const [saverHasPin, setSaverHasPin] = useState(false);
  
  // Pagination states
  const [depositsPage, setDepositsPage] = useState(1);
  const [withdrawalsPage, setWithdrawalsPage] = useState(1);
  const ITEMS_PER_PAGE = 10;
  
  // Filter states for transaction history
  const now = getNowInWIB();
  const [filterMonth, setFilterMonth] = useState<number>(now.getMonth() + 1);
  const [filterYear, setFilterYear] = useState<number>(now.getFullYear());
  
  // All months for filtering
  const allMonths = [
    { value: 1, label: "Januari" },
    { value: 2, label: "Februari" },
    { value: 3, label: "Maret" },
    { value: 4, label: "April" },
    { value: 5, label: "Mei" },
    { value: 6, label: "Juni" },
    { value: 7, label: "Juli" },
    { value: 8, label: "Agustus" },
    { value: 9, label: "September" },
    { value: 10, label: "Oktober" },
    { value: 11, label: "November" },
    { value: 12, label: "Desember" },
  ];

  // Get registration date from saver
  const registrationDate = saver ? new Date(saver.created_at) : now;
  const registrationYear = registrationDate.getFullYear();
  const registrationMonth = registrationDate.getMonth() + 1;

  // Filter months based on selected year and registration date
  const months = allMonths.filter((m) => {
    // If selected year is before registration year, no months available
    if (filterYear < registrationYear) return false;
    // If selected year is the registration year, only show months from registration onwards
    if (filterYear === registrationYear) return m.value >= registrationMonth;
    // If selected year is current year, only show months up to current month
    if (filterYear === now.getFullYear()) return m.value <= now.getMonth() + 1;
    // Otherwise show all months
    return true;
  });

  // Generate years from registration year to current year
  const years = Array.from(
    { length: now.getFullYear() - registrationYear + 1 },
    (_, i) => now.getFullYear() - i
  ).filter((year) => year >= registrationYear);

  // Auto-adjust month when year changes and selected month becomes invalid
  useEffect(() => {
    const validMonths = allMonths.filter((m) => {
      if (filterYear < registrationYear) return false;
      if (filterYear === registrationYear) return m.value >= registrationMonth;
      if (filterYear === now.getFullYear()) return m.value <= now.getMonth() + 1;
      return true;
    });
    
    if (validMonths.length > 0 && !validMonths.some((m) => m.value === filterMonth)) {
      // Set to the latest valid month
      setFilterMonth(validMonths[validMonths.length - 1].value);
    }
  }, [filterYear, registrationYear, registrationMonth]);

  // Reset verification state when dialog closes or saver changes
  useEffect(() => {
    if (!open) {
      setIsVerified(false);
      setDobAnswer("");
      setMotherNameAnswer("");
      setVerificationError("");
      setDeposits([]);
      setInterests([]);
      setWithdrawals([]);
      setSaverDetails(null);
      setVerificationData(null);
      setShowDepositDialog(false);
      setShowWithdrawalDialog(false);
      setShowPinResetConfirm(false);
      setSaverHasPin(false);
      // Reset pagination
      setDepositsPage(1);
      setWithdrawalsPage(1);
      // Reset filter to current month
      const currentNow = getNowInWIB();
      setFilterMonth(currentNow.getMonth() + 1);
      setFilterYear(currentNow.getFullYear());
    }
  }, [open]);

  // Reset pagination when filter changes
  useEffect(() => {
    setDepositsPage(1);
    setWithdrawalsPage(1);
  }, [filterMonth, filterYear]);

  // Fetch verification data and saver details when dialog opens
  useEffect(() => {
    const fetchVerificationData = async () => {
      if (open && saver) {
        const { data, error } = await supabase
          .from("savers")
          .select("date_of_birth, mother_maiden_name, deposit_balance, interest_balance, tier_level, balance, pin_hash")
          .eq("id", saver.id)
          .single();

        if (!error && data) {
          setVerificationData(data);
          setSaverDetails({
            balance: (data as any).balance || 0,
            deposit_balance: (data as any).deposit_balance || 0,
            interest_balance: (data as any).interest_balance || 0,
            tier_level: (data as any).tier_level || "silver",
          });
          setSaverHasPin(!!(data as any).pin_hash);
        }
      }
    };

    fetchVerificationData();
  }, [open, saver]);

  // Fetch transaction history when verified or filter changes
  useEffect(() => {
    const fetchTransactions = async () => {
      if (isVerified && saver) {
        setLoadingTransactions(true);
        try {
          // Calculate date range for the selected month/year
          const startDate = new Date(filterYear, filterMonth - 1, 1);
          const endDate = new Date(filterYear, filterMonth, 0, 23, 59, 59);
          const startDateStr = startDate.toISOString().split('T')[0];
          const endDateStr = endDate.toISOString().split('T')[0];
          
          const [depositsRes, interestsRes, withdrawalsRes] = await Promise.all([
            supabase
              .from("saver_deposits")
              .select("*, created_by_member:members!saver_deposits_created_by_fkey(full_name), approved_by_member:members!saver_deposits_approved_by_fkey(full_name)")
              .eq("saver_id", saver.id)
              .gte("deposit_date", startDateStr)
              .lte("deposit_date", endDateStr)
              .order("created_at", { ascending: false }),
            supabase
              .from("saver_interest_transactions")
              .select("*")
              .eq("saver_id", saver.id)
              .gte("payment_date", startDateStr)
              .lte("payment_date", endDateStr)
              .order("created_at", { ascending: false }),
            supabase
              .from("saver_withdrawals")
              .select("*, processed_by_member:members!saver_withdrawals_processed_by_fkey(full_name)")
              .eq("saver_id", saver.id)
              .gte("withdrawal_date", startDateStr)
              .lte("withdrawal_date", endDateStr)
              .order("created_at", { ascending: false }),
          ]);

          if (depositsRes.data) setDeposits(depositsRes.data as DepositTransaction[]);
          if (interestsRes.data) setInterests(interestsRes.data as InterestTransaction[]);
          if (withdrawalsRes.data) setWithdrawals(withdrawalsRes.data as WithdrawalTransaction[]);
        } catch (error) {
          console.error("Error fetching transactions:", error);
        } finally {
          setLoadingTransactions(false);
        }
      }
    };

    fetchTransactions();
  }, [isVerified, saver, filterMonth, filterYear]);

  const handleVerification = () => {
    if (!verificationData) {
      toast.error("Data verifikasi tidak tersedia");
      return;
    }

    setIsVerifying(true);

    // Format date input to match database format (DD/MM/YYYY -> YYYY-MM-DD)
    const dobParts = dobAnswer.split("/");
    let formattedDobAnswer = dobAnswer;
    if (dobParts.length === 3) {
      formattedDobAnswer = `${dobParts[2]}-${dobParts[1].padStart(2, "0")}-${dobParts[0].padStart(2, "0")}`;
    }

    const isDobCorrect = verificationData.date_of_birth === formattedDobAnswer;
    const isMotherNameCorrect = 
      verificationData.mother_maiden_name?.toUpperCase() === motherNameAnswer.toUpperCase();

    if (isDobCorrect && isMotherNameCorrect) {
      setIsVerified(true);
      setVerificationError("");
      toast.success("Verifikasi berhasil!");
    } else {
      setVerificationError("Tanggal lahir atau nama ibu kandung tidak sesuai dengan data yang terdaftar.");
    }

    setIsVerifying(false);
  };

  // Auto-format date input
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length > 8) value = value.slice(0, 8);
    if (value.length >= 4) {
      value = value.slice(0, 2) + "/" + value.slice(2, 4) + "/" + value.slice(4);
    } else if (value.length >= 2) {
      value = value.slice(0, 2) + "/" + value.slice(2);
    }
    setDobAnswer(value);
  };

  // Handle PIN reset after supercode verification
  const handlePinReset = async () => {
    if (!saver) return;
    
    setIsResettingPin(true);
    try {
      const { data, error } = await supabase.functions.invoke("reset-saver-pin", {
        body: { saver_id: saver.id },
      });

      if (error) throw error;

      if (data?.success) {
        toast.success(data.message || "PIN berhasil direset");
        setSaverHasPin(false);
      } else {
        toast.error(data?.message || "Gagal mereset PIN");
      }
    } catch (err: any) {
      console.error("Error resetting PIN:", err);
      toast.error(err.message || "Terjadi kesalahan saat mereset PIN");
    } finally {
      setIsResettingPin(false);
    }
  };

  if (!saver) return null;

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-2xl max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Detail Debitur
          </ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="space-y-4 overflow-hidden">
          {/* Header Info - Always visible */}
          <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <Avatar className="h-16 w-16 border-2">
              <AvatarImage src={saver.photo_url || undefined} alt={saver.full_name} />
              <AvatarFallback className="bg-primary/10 text-primary text-lg">
                {saver.full_name.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="text-lg font-semibold">{saver.full_name}</p>
                {saverDetails && <TierBadge tier={saverDetails.tier_level} />}
              </div>
              <p className="text-sm text-muted-foreground">{saver.saver_number}</p>
              {/* Account Number */}
              <p className="text-sm font-mono text-primary mt-0.5">
                <CreditCard className="h-3 w-3 inline mr-1" />
                {saver.account_number.replace(/(\d{4})(\d{3})(\d{3})/, "$1-$2-$3")}
              </p>
            </div>
            <Badge variant={saver.status === "active" ? "default" : "secondary"}>
              {saver.status === "active" ? "Aktif" : "Nonaktif"}
            </Badge>
          </div>

          {/* Verification Section */}
          {!isVerified ? (
            <div className="p-4 border rounded-lg bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
              <div className="flex items-center gap-2 mb-4">
                <Lock className="h-5 w-5 text-amber-600" />
                <h3 className="font-semibold text-amber-800 dark:text-amber-200">
                  Verifikasi Identitas
                </h3>
              </div>
              <p className="text-sm text-amber-700 dark:text-amber-300 mb-4">
                Untuk melihat data lengkap debitur, jawab pertanyaan keamanan berikut:
              </p>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="dob-verification" className="text-amber-800 dark:text-amber-200">
                    1. Tanggal Lahir Debitur (DD/MM/YYYY)
                  </Label>
                  <Input
                    id="dob-verification"
                    placeholder="contoh: 27/03/1990"
                    value={dobAnswer}
                    onChange={handleDateChange}
                    maxLength={10}
                    className="bg-white dark:bg-background"
                    autoComplete="off"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mother-verification" className="text-amber-800 dark:text-amber-200">
                    2. Nama Ibu Kandung Debitur
                  </Label>
                  <Input
                    id="mother-verification"
                    placeholder="Masukkan nama ibu kandung"
                    value={motherNameAnswer}
                    onChange={(e) => setMotherNameAnswer(e.target.value.toUpperCase())}
                    className="bg-white dark:bg-background"
                    autoComplete="off"
                  />
                </div>

                {verificationError && (
                  <div className="p-3 bg-destructive/10 border border-destructive/30 rounded-lg">
                    <p className="text-sm text-destructive font-medium">{verificationError}</p>
                  </div>
                )}

                <Button 
                  onClick={handleVerification} 
                  disabled={!dobAnswer || !motherNameAnswer || isVerifying}
                  className="w-full"
                >
                  <ShieldCheck className="h-4 w-4 mr-2" />
                  Verifikasi
                </Button>
              </div>
            </div>
          ) : (
            <>

              {/* Balance Section */}
              <div className="p-4 border rounded-lg bg-primary/5">
                {/* Total Balance - Large */}
                <div className="text-center mb-4">
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <Wallet className="h-5 w-5 text-primary" />
                    <span className="text-sm text-muted-foreground">Total Saldo</span>
                  </div>
                  <p className="text-3xl font-bold text-primary">
                    {formatRupiah(saverDetails?.balance ?? saver.balance ?? 0)}
                  </p>
                </div>
                
                {/* Balance Breakdown - Smaller */}
                <div className="grid grid-cols-2 gap-3 pt-3 border-t">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <ArrowUpCircle className="h-4 w-4 text-green-600" />
                      <span className="text-xs text-muted-foreground">Saldo Deposit</span>
                    </div>
                    <p className="text-base font-semibold text-green-600">
                      {formatRupiah(saverDetails?.deposit_balance ?? saver.deposit_balance ?? 0)}
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Sparkles className="h-4 w-4 text-amber-500" />
                      <span className="text-xs text-muted-foreground">Saldo Bunga</span>
                    </div>
                    <p className="text-base font-semibold text-amber-500">
                      {formatRupiah(saverDetails?.interest_balance ?? saver.interest_balance ?? 0)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Details Grid */}
              <div className="grid gap-3">
                <div className="flex items-start gap-3">
                  <Hash className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">NIK</p>
                    <p className="font-medium">{saver.id_number}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Telepon</p>
                    <p className="font-medium">{saver.phone}</p>
                  </div>
                </div>

                {saver.occupation && (
                  <div className="flex items-start gap-3">
                    <Briefcase className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Pekerjaan</p>
                      <p className="font-medium">{saver.occupation}</p>
                    </div>
                  </div>
                )}

                {saver.email && (
                  <div className="flex items-start gap-3">
                    <Mail className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-medium">{saver.email}</p>
                    </div>
                  </div>
                )}

                {saver.date_of_birth && (
                  <div className="flex items-start gap-3">
                    <Calendar className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Tanggal Lahir</p>
                      <p className="font-medium">{formatDateWIB(saver.date_of_birth)}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-3">
                  <MapPin className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Alamat</p>
                    <p className="font-medium">{saver.address}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Calendar className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Tanggal Daftar</p>
                    <p className="font-medium">{formatDateWIB(saver.created_at)}</p>
                  </div>
                </div>
              </div>


              {/* Transaction History Tabs */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <History className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Riwayat Transaksi</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4 text-muted-foreground" />
                    <Select
                      value={filterMonth.toString()}
                      onValueChange={(val) => setFilterMonth(parseInt(val))}
                    >
                      <SelectTrigger className="w-[110px] h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {months.map((month) => (
                          <SelectItem key={month.value} value={month.value.toString()}>
                            {month.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={filterYear.toString()}
                      onValueChange={(val) => setFilterYear(parseInt(val))}
                    >
                      <SelectTrigger className="w-[80px] h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((year) => (
                          <SelectItem key={year} value={year.toString()}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {/* Summary breakdown above tabs */}
                <div className="grid grid-cols-3 gap-2 p-3 bg-muted/50 rounded-lg text-center mb-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Total Deposit</p>
                    <p className="text-sm font-semibold text-green-600">
                      {formatRupiah(deposits.reduce((sum, d) => sum + d.amount, 0))}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Bunga</p>
                    <p className="text-sm font-semibold text-amber-600">
                      {formatRupiah(interests.reduce((sum, i) => sum + i.amount, 0))}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Tarik</p>
                    <p className="text-sm font-semibold text-red-600">
                      {formatRupiah(withdrawals.filter(w => w.status === 'completed').reduce((sum, w) => sum + w.amount, 0))}
                    </p>
                  </div>
                </div>
                
                <Tabs defaultValue="deposits" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="deposits" className="text-xs sm:text-sm">
                      <ArrowUpCircle className="h-3 w-3 mr-1" />
                      Deposit ({deposits.length})
                    </TabsTrigger>
                    <TabsTrigger value="interest" className="text-xs sm:text-sm">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Bunga ({interests.length})
                    </TabsTrigger>
                    <TabsTrigger value="withdrawals" className="text-xs sm:text-sm">
                      <ArrowDownCircle className="h-3 w-3 mr-1" />
                      Tarik ({withdrawals.length})
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="deposits" className="mt-4">
                    {loadingTransactions ? (
                      <p className="text-sm text-muted-foreground text-center py-4">Memuat...</p>
                    ) : deposits.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">Belum ada riwayat deposit</p>
                    ) : (
                      <>
                        <div className="space-y-2">
                          {deposits
                            .slice((depositsPage - 1) * ITEMS_PER_PAGE, depositsPage * ITEMS_PER_PAGE)
                            .map((deposit) => (
                            <div key={deposit.id} className={`p-3 rounded-lg border ${
                              deposit.status === "rejected" 
                                ? "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800" 
                                : deposit.status === "pending"
                                  ? "bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700"
                                  : "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800"
                            }`}>
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1 space-y-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <p className={`font-medium ${
                                      deposit.status === "rejected" 
                                        ? "text-red-700 dark:text-red-300 line-through" 
                                        : deposit.status === "pending"
                                          ? "text-amber-700 dark:text-amber-300"
                                          : "text-green-700 dark:text-green-300"
                                    }`}>+{formatRupiah(deposit.amount)}</p>
                                    <Badge variant="outline" className={`text-xs ${
                                      deposit.status === "rejected" 
                                        ? "bg-red-100 dark:bg-red-900/50 border-red-300" 
                                        : deposit.status === "pending"
                                          ? "bg-amber-100 dark:bg-amber-900/50 border-amber-300"
                                          : "bg-green-100 dark:bg-green-900/50 border-green-300"
                                    }`}>
                                      {deposit.transaction_type === "topup" ? "Top Up" : "Deposit"}
                                    </Badge>
                                  </div>
                                  {deposit.transaction_number && (
                                    <p className="text-xs font-mono text-primary">
                                      #{deposit.transaction_number}
                                    </p>
                                  )}
                                  <p className="text-xs text-muted-foreground">
                                    {formatDateWIB(deposit.deposit_date)}
                                  </p>
                                  <div className="flex items-center gap-3 flex-wrap text-xs text-muted-foreground">
                                    <span className="flex items-center gap-1">
                                      {deposit.payment_method === "transfer" ? (
                                        <Building2 className="h-3 w-3 text-blue-500" />
                                      ) : (
                                        <Banknote className="h-3 w-3 text-green-600" />
                                      )}
                                      {deposit.payment_method === "transfer" ? "Transfer" : "Tunai"}
                                    </span>
                                    {(deposit.approved_by_member?.full_name || deposit.created_by_member?.full_name) && (
                                      <span className="flex items-center gap-1">
                                        <User className="h-3 w-3" />
                                        {deposit.approved_by_member?.full_name || deposit.created_by_member?.full_name}
                                      </span>
                                    )}
                                  </div>
                                  {deposit.payment_details && (
                                    <p className="text-xs text-muted-foreground italic">
                                      Detail: {deposit.payment_details}
                                    </p>
                                  )}
                                  {deposit.notes && (
                                    <p className="text-xs text-muted-foreground italic">
                                      Ket: {deposit.notes}
                                    </p>
                                  )}
                                </div>
                                <Badge variant="outline" className={
                                  deposit.status === "rejected" 
                                    ? "text-xs border-red-500 text-red-600" 
                                    : deposit.status === "approved" || deposit.is_eligible_for_interest 
                                      ? "text-xs border-green-500 text-green-600" 
                                      : "text-xs border-yellow-500 text-yellow-600"
                                }>
                                  {deposit.status === "rejected" ? "Ditolak" : deposit.status === "approved" ? "Disetujui" : deposit.status === "pending" ? "Pending" : deposit.is_eligible_for_interest ? "Eligible" : "Pending"}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                        {/* Pagination for Deposits */}
                        {deposits.length > ITEMS_PER_PAGE && (
                          <div className="flex items-center justify-between mt-3 pt-3 border-t">
                            <span className="text-xs text-muted-foreground">
                              {(depositsPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(depositsPage * ITEMS_PER_PAGE, deposits.length)} dari {deposits.length}
                            </span>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                disabled={depositsPage === 1}
                                onClick={() => setDepositsPage(p => p - 1)}
                              >
                                <ChevronLeft className="h-4 w-4" />
                              </Button>
                              <span className="text-xs px-2">
                                {depositsPage}/{Math.ceil(deposits.length / ITEMS_PER_PAGE)}
                              </span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                disabled={depositsPage >= Math.ceil(deposits.length / ITEMS_PER_PAGE)}
                                onClick={() => setDepositsPage(p => p + 1)}
                              >
                                <ChevronRight className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="interest" className="mt-4">
                    {loadingTransactions ? (
                      <p className="text-sm text-muted-foreground text-center py-4">Memuat...</p>
                    ) : interests.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">Belum ada riwayat bunga</p>
                    ) : (
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {interests.map((interest) => (
                          <div key={interest.id} className="flex items-center justify-between p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                            <div>
                              <p className="font-medium text-amber-700 dark:text-amber-300">
                                +{formatRupiah(interest.amount)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatDateWIB(interest.payment_date)} • Periode {interest.period_month}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {interest.interest_rate}% dari {formatRupiah(interest.principal_amount)}
                              </p>
                            </div>
                            <TierBadge tier={interest.tier_level} />
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="withdrawals" className="mt-4">
                    {loadingTransactions ? (
                      <p className="text-sm text-muted-foreground text-center py-4">Memuat...</p>
                    ) : withdrawals.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">Belum ada riwayat penarikan</p>
                    ) : (
                      <>
                        <div className="space-y-2">
                          {withdrawals
                            .slice((withdrawalsPage - 1) * ITEMS_PER_PAGE, withdrawalsPage * ITEMS_PER_PAGE)
                            .map((withdrawal) => (
                            <div key={withdrawal.id} className={`p-3 rounded-lg border ${
                              withdrawal.status === "rejected"
                                ? "bg-gray-50 dark:bg-gray-950/20 border-gray-300 dark:border-gray-700"
                                : withdrawal.status === "pending"
                                  ? "bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700"
                                  : "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800"
                            }`}>
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1 space-y-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <p className={`font-medium ${
                                      withdrawal.status === "rejected" 
                                        ? "text-gray-500 line-through" 
                                        : withdrawal.status === "pending"
                                          ? "text-amber-700 dark:text-amber-300"
                                          : "text-red-700 dark:text-red-300"
                                    }`}>-{formatRupiah(withdrawal.amount)}</p>
                                    <Badge variant="outline" className={`text-xs ${
                                      withdrawal.status === "rejected" 
                                        ? "bg-gray-100 dark:bg-gray-900/50 border-gray-300" 
                                        : withdrawal.status === "pending"
                                          ? "bg-amber-100 dark:bg-amber-900/50 border-amber-300"
                                          : "bg-red-100 dark:bg-red-900/50 border-red-300"
                                    }`}>
                                      Penarikan
                                    </Badge>
                                  </div>
                                  {withdrawal.transaction_number && (
                                    <p className="text-xs font-mono text-primary">
                                      #{withdrawal.transaction_number}
                                    </p>
                                  )}
                                  <p className="text-xs text-muted-foreground">
                                    {formatDateWIB(withdrawal.withdrawal_date)}
                                  </p>
                                  <div className="flex items-center gap-3 flex-wrap text-xs text-muted-foreground">
                                    <span className="flex items-center gap-1">
                                      {withdrawal.payment_method === "transfer" ? (
                                        <Building2 className="h-3 w-3 text-blue-500" />
                                      ) : (
                                        <Banknote className="h-3 w-3 text-green-600" />
                                      )}
                                      {withdrawal.payment_method === "transfer" ? "Transfer" : "Tunai"}
                                    </span>
                                    {withdrawal.processed_by_member?.full_name && (
                                      <span className="flex items-center gap-1">
                                        <User className="h-3 w-3" />
                                        {withdrawal.processed_by_member.full_name}
                                      </span>
                                    )}
                                  </div>
                                  {withdrawal.payment_details && (
                                    <p className="text-xs text-muted-foreground italic">
                                      Detail: {withdrawal.payment_details}
                                    </p>
                                  )}
                                  {withdrawal.notes && (
                                    <p className="text-xs text-muted-foreground italic">
                                      Ket: {withdrawal.notes}
                                    </p>
                                  )}
                                </div>
                                <Badge
                                  variant="outline"
                                  className={
                                    withdrawal.status === "completed"
                                      ? "text-xs border-green-500 text-green-600"
                                      : withdrawal.status === "pending"
                                      ? "text-xs border-yellow-500 text-yellow-600"
                                      : withdrawal.status === "rejected"
                                      ? "text-xs border-red-500 text-red-600"
                                      : "text-xs border-gray-500 text-gray-600"
                                  }
                                >
                                  {withdrawal.status === "completed" ? "Selesai" : withdrawal.status === "pending" ? "Pending" : withdrawal.status === "rejected" ? "Ditolak" : withdrawal.status}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                        {/* Pagination for Withdrawals */}
                        {withdrawals.length > ITEMS_PER_PAGE && (
                          <div className="flex items-center justify-between mt-3 pt-3 border-t">
                            <span className="text-xs text-muted-foreground">
                              {(withdrawalsPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(withdrawalsPage * ITEMS_PER_PAGE, withdrawals.length)} dari {withdrawals.length}
                            </span>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                disabled={withdrawalsPage === 1}
                                onClick={() => setWithdrawalsPage(p => p - 1)}
                              >
                                <ChevronLeft className="h-4 w-4" />
                              </Button>
                              <span className="text-xs px-2">
                                {withdrawalsPage}/{Math.ceil(withdrawals.length / ITEMS_PER_PAGE)}
                              </span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                disabled={withdrawalsPage >= Math.ceil(withdrawals.length / ITEMS_PER_PAGE)}
                                onClick={() => setWithdrawalsPage(p => p + 1)}
                              >
                                <ChevronRight className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </TabsContent>
                </Tabs>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                {onEdit && (isOwner || isAdmin) && (
                  <Button 
                    className="w-full" 
                    variant="secondary"
                    onClick={() => {
                      onEdit(saver);
                      onOpenChange(false);
                    }}
                  >
                    <Pencil className="h-4 w-4 mr-2" />
                    Edit Data Debitur
                  </Button>
                )}
                {/* Reset PIN Button - Only for Admin/Owner when saver has PIN */}
                {(isOwner || isAdmin) && saverHasPin && (
                  <Button
                    variant="outline"
                    className="w-full border-amber-500 text-amber-600 hover:bg-amber-50 hover:text-amber-700"
                    onClick={() => setShowPinResetConfirm(true)}
                    disabled={isResettingPin}
                  >
                    {isResettingPin ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Mereset PIN...
                      </>
                    ) : (
                      <>
                        <KeyRound className="h-4 w-4 mr-2" />
                        Reset PIN Debitur
                      </>
                    )}
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </ResponsiveDialogContent>

      {/* Deposit Dialog */}
      {saver && (
        <SaverDepositDialog
          saverId={saver.id}
          saverName={saver.full_name}
          currentBalance={saverDetails?.balance ?? saver.balance ?? 0}
          open={showDepositDialog}
          onOpenChange={setShowDepositDialog}
          onSuccess={() => {
            // Refresh saver details and transactions
            setShowDepositDialog(false);
            // Trigger re-fetch
            supabase
              .from("savers")
              .select("deposit_balance, interest_balance, tier_level, balance")
              .eq("id", saver.id)
              .single()
              .then(({ data }) => {
                if (data) {
                  setSaverDetails({
                    balance: (data as any).balance || 0,
                    deposit_balance: (data as any).deposit_balance || 0,
                    interest_balance: (data as any).interest_balance || 0,
                    tier_level: (data as any).tier_level || "silver",
                  });
                }
              });
            // Refetch deposits
            supabase
              .from("saver_deposits")
              .select("*")
              .eq("saver_id", saver.id)
              .order("deposit_date", { ascending: false })
              .limit(50)
              .then(({ data }) => {
                if (data) setDeposits(data as any);
              });
          }}
        />
      )}

      {/* Withdrawal Dialog */}
      {saver && (
        <SaverWithdrawalDialog
          saverId={saver.id}
          saverName={saver.full_name}
          currentBalance={saverDetails?.balance ?? saver.balance ?? 0}
          open={showWithdrawalDialog}
          onOpenChange={setShowWithdrawalDialog}
          onSuccess={() => {
            setShowWithdrawalDialog(false);
            // Trigger re-fetch
            supabase
              .from("savers")
              .select("deposit_balance, interest_balance, tier_level, balance")
              .eq("id", saver.id)
              .single()
              .then(({ data }) => {
                if (data) {
                  setSaverDetails({
                    balance: (data as any).balance || 0,
                    deposit_balance: (data as any).deposit_balance || 0,
                    interest_balance: (data as any).interest_balance || 0,
                    tier_level: (data as any).tier_level || "silver",
                  });
                }
              });
            // Refetch withdrawals
            supabase
              .from("saver_withdrawals")
              .select("*")
              .eq("saver_id", saver.id)
              .order("withdrawal_date", { ascending: false })
              .limit(50)
              .then(({ data }) => {
                if (data) setWithdrawals(data as any);
              });
          }}
        />
      )}

      {/* Supercode Verification Dialog for PIN Reset */}
      <SupercodeVerificationDialog
        open={showPinResetConfirm}
        onOpenChange={setShowPinResetConfirm}
        onSuccess={handlePinReset}
        title="Reset PIN Debitur"
        description={`Masukkan supercode untuk mereset PIN debitur ${saver?.full_name}. Setelah direset, debitur harus membuat PIN baru.`}
      />
    </ResponsiveDialog>
  );
}