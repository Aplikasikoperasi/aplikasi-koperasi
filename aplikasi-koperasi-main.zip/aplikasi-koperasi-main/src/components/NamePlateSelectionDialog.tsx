import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Printer, Search, CheckSquare, Eye, X, Download, ChevronUp, ChevronDown } from "lucide-react";
import { formatRupiah } from "@/lib/utils";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface NamePlateItem {
  id: string;
  application_number: string;
  application_date?: string;
  amount_approved: number | null;
  amount_requested: number;
  tenor_months: number;
  customers: {
    full_name: string;
    id_number: string;
    photo_url?: string | null;
  };
  members: {
    full_name: string;
  };
}

interface NamePlateSelectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  applications: NamePlateItem[];
  isLoading: boolean;
  onPrint: (selectedIds: string[], action: 'print' | 'download') => void;
  isPrinting: boolean;
  businessName?: string;
  logoUrl?: string;
}

// Mini Name Plate Preview Component - Updated design
function NamePlatePreview({ 
  app, 
  businessName,
  logoUrl 
}: { 
  app: NamePlateItem; 
  businessName?: string;
  logoUrl?: string;
}) {
  // Format application date
  const formattedAppDate = app.application_date 
    ? new Date(app.application_date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
    : '-';

  return (
    <div className="bg-white border-2 border-blue-200 rounded-lg p-3 shadow-sm w-full max-w-[280px] mx-auto">
      {/* Header - Logo and Business Name (bigger) */}
      <div className="flex items-center justify-center gap-2 mb-2">
        {logoUrl && (
          <img 
            src={logoUrl} 
            alt="Logo" 
            className="w-6 h-6 object-contain"
            onError={(e) => e.currentTarget.style.display = 'none'}
          />
        )}
        <span className="font-bold text-sm text-blue-800 truncate">
          {businessName || 'Sistem Kredit'}
        </span>
      </div>
      
      {/* Blue line separator */}
      <div className="h-0.5 bg-blue-500 mb-2" />
      
      {/* Customer Photo + Name + ID section */}
      <div className="flex items-start gap-2 mb-2">
        {/* Customer Photo */}
        <div className="flex-shrink-0">
          {app.customers?.photo_url ? (
            <img 
              src={app.customers.photo_url} 
              alt="Foto" 
              className="w-10 h-10 object-cover rounded border border-gray-200"
              onError={(e) => e.currentTarget.style.display = 'none'}
            />
          ) : (
            <div className="w-10 h-10 bg-gray-100 rounded border border-gray-300 flex items-center justify-center">
              <span className="text-gray-400 text-xs">👤</span>
            </div>
          )}
        </div>
        
        {/* Name and ID */}
        <div className="flex-1 min-w-0">
          <div className="text-[9px] text-gray-500 uppercase tracking-wide">Nama Nasabah</div>
          <div className="font-bold text-xs text-gray-900 truncate">
            {app.customers?.full_name?.toUpperCase() || '-'}
          </div>
          <div className="text-[9px] text-gray-500 uppercase tracking-wide mt-0.5">No. ID</div>
          <div className="font-semibold text-[10px] text-gray-800">
            {app.customers?.id_number || '-'}
          </div>
        </div>
      </div>
      
      {/* Gray line */}
      <div className="h-px bg-gray-300 mb-2" />
      
      {/* Two columns: Loan Amount & Tenor */}
      <div className="grid grid-cols-2 gap-2 mb-1.5">
        <div className="text-center">
          <div className="text-[8px] text-gray-500 uppercase tracking-wide">Jumlah Pinjaman</div>
          <div className="font-bold text-[10px] text-green-600">
            {formatRupiah(app.amount_approved || app.amount_requested)}
          </div>
        </div>
        <div className="text-center">
          <div className="text-[8px] text-gray-500 uppercase tracking-wide">Tenor</div>
          <div className="font-bold text-[10px] text-purple-600">
            {app.tenor_months} Bulan
          </div>
        </div>
      </div>
      
      {/* Two columns: Application Date & Application Number */}
      <div className="grid grid-cols-2 gap-2 mb-1.5">
        <div className="text-center">
          <div className="text-[8px] text-gray-500 uppercase tracking-wide">Tgl Pengajuan</div>
          <div className="font-semibold text-[9px] text-gray-800">
            {formattedAppDate}
          </div>
        </div>
        <div className="text-center">
          <div className="text-[8px] text-gray-500 uppercase tracking-wide">No. Aplikasi</div>
          <div className="font-semibold text-[8px] text-gray-800 truncate">
            {app.application_number || '-'}
          </div>
        </div>
      </div>
      
      {/* PJ Kredit - centered */}
      <div className="text-center">
        <div className="text-[8px] text-gray-500 uppercase tracking-wide">PJ Kredit</div>
        <div className="font-semibold text-[10px] text-blue-600 truncate">
          {app.members?.full_name?.toUpperCase() || '-'}
        </div>
      </div>
    </div>
  );
}

export function NamePlateSelectionDialog({
  open,
  onOpenChange,
  applications,
  isLoading,
  onPrint,
  isPrinting,
  businessName,
  logoUrl,
}: NamePlateSelectionDialogProps) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [previewApp, setPreviewApp] = useState<NamePlateItem | null>(null);
  const [mobilePreviewOpen, setMobilePreviewOpen] = useState(false);

  // Reset selection when dialog opens - default to none selected
  useEffect(() => {
    if (open) {
      setSelectedIds(new Set());
      setSearchQuery("");
      setPreviewApp(null);
      setMobilePreviewOpen(false);
    }
  }, [open, applications]);

  // Auto open mobile preview when an app is selected for preview
  useEffect(() => {
    if (previewApp) {
      setMobilePreviewOpen(true);
    }
  }, [previewApp]);

  const filteredApplications = applications
    .filter(app => {
      const query = searchQuery.toLowerCase();
      return (
        app.customers?.full_name?.toLowerCase().includes(query) ||
        app.application_number?.toLowerCase().includes(query) ||
        app.customers?.id_number?.toLowerCase().includes(query) ||
        app.members?.full_name?.toLowerCase().includes(query)
      );
    })
    // Sort by application_number descending (newest first - APP-timestamp format)
    .sort((a, b) => b.application_number.localeCompare(a.application_number));

  const toggleSelection = (id: string) => {
    const newSelection = new Set(selectedIds);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedIds(newSelection);
  };

  const selectAll = () => {
    setSelectedIds(new Set(filteredApplications.map(app => app.id)));
  };

  const handlePrint = (action: 'print' | 'download') => {
    onPrint(Array.from(selectedIds), action);
  };

  const allSelected = filteredApplications.length > 0 && 
    filteredApplications.every(app => selectedIds.has(app.id));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Printer className="h-5 w-5" />
            Pilih Name Plate untuk Dicetak
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col md:flex-row gap-4 flex-1 min-h-0 overflow-hidden">
          {/* Left side: Selection list */}
          <div className="flex-1 flex flex-col space-y-3 min-w-0 min-h-0">
            {/* Search and Select All */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cari nama, nomor aplikasi..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Button
                variant={allSelected ? "default" : "outline"}
                size="sm"
                onClick={() => allSelected ? setSelectedIds(new Set()) : selectAll()}
                className="flex-1 sm:flex-none"
              >
                <CheckSquare className="h-4 w-4 mr-1" />
                <span className="sm:inline">{allSelected ? "Batal Pilih" : "Pilih Semua"}</span>
              </Button>
            </div>

            {/* Selection Count */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Badge variant="secondary">
                {selectedIds.size} dari {applications.length} dipilih
              </Badge>
            </div>

            {/* Mobile Preview - Collapsible */}
            <div className="md:hidden">
              <Collapsible open={mobilePreviewOpen} onOpenChange={setMobilePreviewOpen}>
                <CollapsibleTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Preview Name Plate
                      {previewApp && (
                        <Badge variant="secondary" className="text-xs">
                          {previewApp.customers?.full_name?.split(' ')[0]}
                        </Badge>
                      )}
                    </span>
                    {mobilePreviewOpen ? (
                      <ChevronUp className="h-4 w-4" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-2">
                  <div className="border rounded-lg bg-gray-50 dark:bg-gray-900 p-4">
                    {previewApp ? (
                      <div className="space-y-2">
                        <NamePlatePreview 
                          app={previewApp} 
                          businessName={businessName}
                          logoUrl={logoUrl}
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full"
                          onClick={() => {
                            setPreviewApp(null);
                            setMobilePreviewOpen(false);
                          }}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Tutup Preview
                        </Button>
                      </div>
                    ) : (
                      <div className="text-center text-muted-foreground text-sm py-4">
                        <Eye className="h-8 w-8 mx-auto mb-2 opacity-30" />
                        <p>Ketuk ikon mata pada item<br />untuk melihat preview</p>
                      </div>
                    )}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            </div>

            {/* Application List */}
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
                <span className="ml-2">Memuat data...</span>
              </div>
            ) : (
              <ScrollArea className="flex-1 min-h-0 h-[250px] md:h-[350px] border rounded-lg">
                <div className="p-2 space-y-1">
                  {filteredApplications.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      {searchQuery ? "Tidak ditemukan hasil pencarian" : "Tidak ada kredit aktif"}
                    </div>
                  ) : (
                    filteredApplications.map((app) => (
                      <div
                        key={app.id}
                        className={`flex items-center gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedIds.has(app.id)
                            ? "bg-primary/10 border border-primary/30"
                            : "hover:bg-muted/50 border border-transparent"
                        }`}
                        onClick={() => toggleSelection(app.id)}
                      >
                        <Checkbox
                          checked={selectedIds.has(app.id)}
                          onCheckedChange={() => toggleSelection(app.id)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
                            <span className="font-medium text-sm truncate max-w-[120px] sm:max-w-none">
                              {app.customers?.full_name}
                            </span>
                            <Badge variant="outline" className="text-[10px] sm:text-xs shrink-0">
                              {app.application_number}
                            </Badge>
                          </div>
                          <div className="text-xs sm:text-sm text-muted-foreground flex flex-wrap gap-x-2 sm:gap-x-3 gap-y-0.5 mt-0.5 sm:mt-1">
                            <span>{formatRupiah(app.amount_approved || app.amount_requested)}</span>
                            <span>{app.tenor_months} bln</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="shrink-0 h-8 w-8 p-0"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPreviewApp(app);
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            )}
          </div>

          {/* Right side: Preview panel - Desktop only */}
          <div className="hidden md:flex flex-col w-[300px] shrink-0">
            <div className="text-sm font-medium mb-2 flex items-center justify-between">
              <span>Preview Name Plate</span>
              {previewApp && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0"
                  onClick={() => setPreviewApp(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="flex-1 border rounded-lg bg-gray-50 dark:bg-gray-900 p-4 flex items-center justify-center min-h-[300px]">
              {previewApp ? (
                <NamePlatePreview 
                  app={previewApp} 
                  businessName={businessName}
                  logoUrl={logoUrl}
                />
              ) : (
                <div className="text-center text-muted-foreground text-sm">
                  <Eye className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p>Klik tombol mata pada<br />item untuk melihat preview</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">
            Batal
          </Button>
          <div className="flex gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              onClick={() => handlePrint('download')}
              disabled={selectedIds.size === 0 || isPrinting}
              className="flex-1 sm:flex-none"
            >
              {isPrinting ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 mr-2" />
              )}
              <span className="hidden sm:inline">Download PDF</span>
              <span className="sm:hidden">Download</span>
            </Button>
            <Button
              onClick={() => handlePrint('print')}
              disabled={selectedIds.size === 0 || isPrinting}
              className="flex-1 sm:flex-none"
            >
              {isPrinting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  <span className="hidden sm:inline">Memproses...</span>
                </>
              ) : (
                <>
                  <Printer className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Cetak Langsung</span>
                  <span className="sm:hidden">Cetak</span>
                </>
              )}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
