import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle, ResponsiveDialogDescription } from "@/components/ui/responsive-dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatRupiah, formatDate, roundToThousand, sanitizeDateForDatabase, getTodayInWIB, getTodayDateStringInWIB } from "@/lib/utils";
import { Search, AlertCircle, MessageSquare, CheckCircle2, Lock, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { SuccessCheckmark } from "@/components/ui/success-checkmark";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { DatePicker } from "@/components/ui/date-picker";
import { format } from "date-fns";
import { CurrencyInput } from "@/components/ui/currency-input";
import { openWhatsAppChat } from "@/lib/whatsappHelper";
import { useInvalidateInstallments } from "@/hooks/useInstallmentsQuery";
import { useInvalidatePayments } from "@/hooks/usePaymentsQuery";
import { useUserRole } from "@/hooks/useUserRole";
import { validatePaymentAmount, validatePaymentDate, kasirPinSchema } from "@/lib/paymentValidation";
interface InstallmentPaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  preSelectedInstallmentId?: string | null;
}
export default function InstallmentPaymentDialog({
  open,
  onOpenChange,
  onSuccess,
  preSelectedInstallmentId
}: InstallmentPaymentDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [installments, setInstallments] = useState<any[]>([]);
  const [selectedInstallment, setSelectedInstallment] = useState<any>(null);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [referenceNumber, setReferenceNumber] = useState("");
  const [paymentDate, setPaymentDate] = useState<Date | undefined>(undefined);
  const [penalty, setPenalty] = useState(0);
  const [penaltyRate, setPenaltyRate] = useState(2.0);
  const [daysOverdue, setDaysOverdue] = useState(0);
  const [isSearching, setIsSearching] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressMessage, setProgressMessage] = useState("");
  const [progressValue, setProgressValue] = useState(0);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [successPaymentData, setSuccessPaymentData] = useState<any>(null);
  const [kasirPin, setKasirPin] = useState("");
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  const {
    toast
  } = useToast();
  const { isKasir } = useUserRole();
  const invalidateInstallments = useInvalidateInstallments();
  const invalidatePayments = useInvalidatePayments();

  // Load current member ID for kasir
  useEffect(() => {
    const loadMemberId = async () => {
      if (isKasir) {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: memberData } = await supabase
            .from('members')
            .select('id')
            .eq('user_id', user.id)
            .maybeSingle();
          if (memberData) {
            setCurrentMemberId(memberData.id);
          }
        }
      }
    };
    loadMemberId();
  }, [isKasir]);

  // Reset form when dialog closes
  useEffect(() => {
    if (!open) {
      resetForm();
    }
  }, [open]);

  // Auto-load installment when preSelectedInstallmentId is provided
  useEffect(() => {
    if (preSelectedInstallmentId && open) {
      loadPreselectedInstallment(preSelectedInstallmentId);
    }
  }, [preSelectedInstallmentId, open]);
  useEffect(() => {
    if (selectedInstallment) {
      const updatePenalty = async () => {
        const p = await calculatePenalty(selectedInstallment);
        setPenalty(p);
      };
      updatePenalty();
    }
  }, [selectedInstallment, paymentDate]);

  // Auto-select first installment when installments list changes
  useEffect(() => {
    if (installments.length > 0) {
      const firstInstallment = installments[0];
      handleInstallmentSelect(firstInstallment);
    } else {
      setSelectedInstallment(null);
      setPaymentAmount("");
      setPenalty(0);
      setDaysOverdue(0);
    }
  }, [installments]);
  const resetForm = () => {
    setSearchQuery("");
    setSelectedCustomer(null);
    setSearchResults([]);
    setShowSearchResults(false);
    setInstallments([]);
    setSelectedInstallment(null);
    setPaymentAmount("");
    setPaymentMethod("cash");
    setReferenceNumber("");
    setPaymentDate(undefined);
    setPenalty(0);
    setKasirPin("");
    setPenaltyRate(2.0);
    setDaysOverdue(0);
    setPaymentSuccess(false);
    setSuccessPaymentData(null);
    setProgressMessage("");
    setProgressValue(0);
  };
  const calculatePenalty = async (installment: any) => {
    // Get penalty rate from settings
    const {
      data: settings
    } = await supabase.rpc('get_public_app_settings');
    const rate = (settings as any)?.penalty_rate_per_day || 2.0;
    setPenaltyRate(rate);

    // If principal already paid, use frozen values
    if (installment.principal_paid) {
      const frozenDays = installment.frozen_days_overdue || 0;
      setDaysOverdue(frozenDays);
      if (frozenDays === 0) return 0;
      const dailyPenalty = roundToThousand(installment.total_amount * (rate / 100));
      return frozenDays * dailyPenalty;
    }

    // Calculate penalty based on payment date vs due date
    const selectedPaymentDate = paymentDate || new Date();
    const paymentDateObj = new Date(selectedPaymentDate);
    paymentDateObj.setHours(0, 0, 0, 0);
    const dueDate = new Date(installment.due_date);
    dueDate.setHours(0, 0, 0, 0);

    // Calculate days overdue based on payment date, not today's date
    const diffTime = paymentDateObj.getTime() - dueDate.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const days = Math.max(0, diffDays);
    setDaysOverdue(days);

    // No penalty if payment date is on or before due date
    if (days === 0) return 0;
    const dailyPenalty = roundToThousand(installment.total_amount * (rate / 100));
    return days * dailyPenalty;
  };
  const searchCustomer = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Masukkan nama atau ID nasabah",
        variant: "destructive"
      });
      return;
    }

    // Reset all states before searching
    setSelectedCustomer(null);
    setSelectedInstallment(null);
    setInstallments([]);
    setPaymentAmount("");
    setPenalty(0);
    setDaysOverdue(0);
    setIsSearching(true);
    const {
      data,
      error
    } = await supabase.from("customers").select("*").eq("status", "approved").or(`full_name.ilike.%${searchQuery}%,id_number.ilike.%${searchQuery}%`);
    setIsSearching(false);
    if (error) {
      toast({
        title: "Gagal mencari nasabah",
        variant: "destructive"
      });
      return;
    }
    if (!data || data.length === 0) {
      toast({
        title: "Nasabah tidak ditemukan",
        variant: "destructive"
      });
      setSearchResults([]);
      setShowSearchResults(false);
      return;
    }

    // Sort results by relevance:
    // 1. Exact match on full_name or id_number
    // 2. Starts with search query
    // 3. Contains search query
    const searchLower = searchQuery.toLowerCase();
    const sortedResults = data.sort((a, b) => {
      const aNameLower = a.full_name.toLowerCase();
      const bNameLower = b.full_name.toLowerCase();
      const aIdLower = a.id_number.toLowerCase();
      const bIdLower = b.id_number.toLowerCase();

      // Exact match
      if (aNameLower === searchLower || aIdLower === searchLower) return -1;
      if (bNameLower === searchLower || bIdLower === searchLower) return 1;

      // Starts with (word boundary)
      const aNameStarts = aNameLower.split(' ').some(word => word.startsWith(searchLower));
      const bNameStarts = bNameLower.split(' ').some(word => word.startsWith(searchLower));
      if (aNameStarts && !bNameStarts) return -1;
      if (!aNameStarts && bNameStarts) return 1;

      // Starts with anywhere
      if (aNameLower.startsWith(searchLower) && !bNameLower.startsWith(searchLower)) return -1;
      if (!aNameLower.startsWith(searchLower) && bNameLower.startsWith(searchLower)) return 1;

      // Default: alphabetical
      return aNameLower.localeCompare(bNameLower);
    });
    if (sortedResults.length === 1) {
      // Only one result, select it automatically
      setSelectedCustomer(sortedResults[0]);
      setSearchResults([]);
      setShowSearchResults(false);
      await loadCustomerInstallments(sortedResults[0].id);
    } else {
      // Multiple results, show list for selection
      setSearchResults(sortedResults);
      setShowSearchResults(true);
    }
  };
  const selectCustomerFromResults = async (customer: any) => {
    setSelectedCustomer(customer);
    setSearchResults([]);
    setShowSearchResults(false);
    await loadCustomerInstallments(customer.id);
  };
  const loadCustomerInstallments = async (customerId: string) => {
    const {
      data: apps,
      error: appsError
    } = await supabase.from("credit_applications").select(`
        id,
        application_number,
        customer_id,
        amount_approved,
        tenor_months,
        status,
        customers (id, full_name, id_number)
      `).eq("customer_id", customerId).in("status", ["approved", "disbursed"]);
    if (appsError) {
      console.error("loadCustomerInstallments apps error:", appsError);
      toast({
        title: "Gagal memuat pengajuan kredit",
        description: appsError.message,
        variant: "destructive"
      });
      setInstallments([]);
      return;
    }
    if (!apps || apps.length === 0) {
      setInstallments([]);
      return;
    }
    const appIds = apps.map(a => a.id);
    const {
      data: installmentsData,
      error
    } = await supabase.from("installments").select("*").in("application_id", appIds).in("status", ["unpaid", "partial", "overdue"]).order("installment_number", {
      ascending: true
    });
    if (error) {
      console.error("loadCustomerInstallments error:", error);
      toast({
        title: "Gagal memuat angsuran",
        description: error.message,
        variant: "destructive"
      });
    } else {
      // Enrich with credit application and customer data
      const enrichedInstallments = await Promise.all((installmentsData || []).map(async inst => {
        const {
          data: appData
        } = await supabase.from("credit_applications").select(`
              id,
              application_number,
              customer_id,
              amount_approved,
              tenor_months,
              status,
              customers (id, full_name, id_number)
            `).eq("id", inst.application_id).single();
        return {
          ...inst,
          credit_applications: appData
        };
      }));

      // Filter logic: Prioritize overdue installments
      // If there are overdue installments, show only those
      // If no overdue, show only the next upcoming installment(s)
      const overdueInstallments = enrichedInstallments.filter(i => i.status === 'overdue');
      let filteredInstallments;
      if (overdueInstallments.length > 0) {
        // Show all overdue installments, sorted by installment number
        filteredInstallments = overdueInstallments.sort((a, b) => a.installment_number - b.installment_number);
      } else {
        // No overdue, show only the first unpaid/partial installment(s)
        const unpaidPartial = enrichedInstallments.filter(i => i.status === 'unpaid' || i.status === 'partial');
        if (unpaidPartial.length > 0) {
          // Find the minimum installment number
          const minInstallmentNumber = Math.min(...unpaidPartial.map(i => i.installment_number));
          // Show all installments with that number (in case of multiple applications)
          filteredInstallments = unpaidPartial.filter(i => i.installment_number === minInstallmentNumber).sort((a, b) => a.installment_number - b.installment_number);
        } else {
          filteredInstallments = [];
        }
      }
      setInstallments(filteredInstallments);
    }
  };
  const loadPreselectedInstallment = async (installmentId: string) => {
    const {
      data: installmentData,
      error: installmentError
    } = await supabase.from("installments").select("*").eq("id", installmentId).single();
    if (installmentError) {
      console.error("loadPreselectedInstallment error:", installmentError);
      toast({
        title: "Gagal memuat data angsuran",
        description: installmentError.message,
        variant: "destructive"
      });
      return;
    }
    if (!installmentData) return;

    // Load credit application and customer separately
    const {
      data: appData,
      error: appError
    } = await supabase.from("credit_applications").select(`
        id,
        application_number,
        customer_id,
        amount_approved,
        tenor_months,
        customers (id, full_name, id_number)
      `).eq("id", installmentData.application_id).single();
    if (appError) {
      console.error("loadPreselectedInstallment app error:", appError);
      toast({
        title: "Gagal memuat data aplikasi",
        description: appError.message,
        variant: "destructive"
      });
      return;
    }
    if (appData) {
      const customer = (appData as any).customers;
      setSelectedCustomer(customer);
      setSelectedInstallment(installmentData);
      const penalty = await calculatePenalty(installmentData);
      setPenalty(penalty);
      const remainingAmount = installmentData.total_amount - installmentData.paid_amount + penalty;
      setPaymentAmount(remainingAmount.toString());
    }
  };
  const handleInstallmentSelect = async (installment: any) => {
    setSelectedInstallment(installment);
    const penalty = await calculatePenalty(installment);
    setPenalty(penalty);
    const remainingAmount = installment.total_amount - installment.paid_amount + penalty;
    setPaymentAmount(remainingAmount.toString());
  };
  const handlePayment = async () => {
    if (!selectedInstallment || !selectedCustomer) return;
    
    // Comprehensive input validation using Zod
    const errors: string[] = [];
    
    // Validate payment amount
    const amountTotal = parseFloat(paymentAmount);
    const amountError = validatePaymentAmount(amountTotal);
    if (amountError) {
      errors.push(amountError);
    }
    
    // Validate payment date
    const dateError = validatePaymentDate(paymentDate);
    if (dateError) {
      errors.push(dateError);
    }
    
    // Validate payment method
    if (!paymentMethod) {
      errors.push("Metode pembayaran harus dipilih");
    }

    // Verifikasi PIN untuk kasir
    if (isKasir) {
      // Validate PIN using Zod schema
      try {
        kasirPinSchema.parse(kasirPin);
      } catch (error: any) {
        if (error.errors && error.errors[0]) {
          errors.push(error.errors[0].message);
        } else {
          errors.push("PIN kasir tidak valid");
        }
      }

      if (!currentMemberId) {
        errors.push("Data kasir tidak ditemukan");
      }
    }
    
    // Display validation errors
    if (errors.length > 0) {
      toast({
        title: "Data tidak valid",
        description: errors[0],
        variant: "destructive"
      });
      return;
    }

    // Verify PIN for kasir after validation passed
    if (isKasir) {
      const { data: pinValid, error: pinError } = await supabase
        .rpc('verify_kasir_pin', {
          p_member_id: currentMemberId,
          p_pin_input: kasirPin
        });

      if (pinError) {
        console.error('PIN verification error:', pinError);
        toast({
          title: "Error verifikasi PIN",
          description: "Gagal memverifikasi PIN kasir",
          variant: "destructive"
        });
        return;
      }

      if (!pinValid) {
        toast({
          title: "PIN salah",
          description: "PIN kasir yang Anda masukkan tidak valid",
          variant: "destructive"
        });
        return;
      }
    }

    setIsProcessing(true);
    setProgressMessage("Memvalidasi data pembayaran...");
    setProgressValue(20);
    try {
      // Validate payment date - use WIB timezone for default
      const sanitizedPaymentDate = paymentDate ? sanitizeDateForDatabase(paymentDate) : getTodayDateStringInWIB();
      if (paymentDate && !sanitizedPaymentDate) {
        toast({
          title: "Error",
          description: "Format tanggal pembayaran tidak valid (tahun harus antara 1900-2100)",
          variant: "destructive"
        });
        setIsProcessing(false);
        return;
      }
      const finalPaymentDate = sanitizedPaymentDate;

      // PERBAIKAN: Bayar HANYA angsuran yang dipilih
      // Denda tidak auto-terbayar dari angsuran berikutnya
      // Denda hanya bisa dibayar melalui tombol "Bayar Sisa Denda" di detail pembayaran
      let totalAllocated = 0;
      const paymentResults = [];

      // No special notes needed - penalty is calculated by RPC function based on payment date vs due date
      let paymentNotes = null;

      setProgressMessage("Memproses pembayaran...");
      setProgressValue(60);

      // Call atomic payment function with row lock - HANYA untuk angsuran yang dipilih
      const {
        data: result,
        error: rpcErr
      } = await supabase.rpc('apply_payment_to_installment', {
        p_installment_id: selectedInstallment.id,
        p_amount: amountTotal,
        p_payment_date: finalPaymentDate,
        p_payment_method: paymentMethod,
        p_reference: referenceNumber || '',
        p_notes: paymentNotes
      });
      if (rpcErr) throw rpcErr;
      
      const resultData = result as any;
      const allocated = Number(resultData.allocated_principal) + Number(resultData.allocated_penalty);
      if (allocated > 0) {
        paymentResults.push(resultData);
        totalAllocated += allocated;
      }
      if (totalAllocated <= 0) {
        throw new Error("Tidak ada angsuran yang diperbarui. Periksa status angsuran.");
      }

      // Data now auto-syncs via database triggers

      await logSystemEvent({
        category: "payment",
        action: isKasir ? "Catat Pembayaran (Kasir)" : "Catat Pembayaran",
        description: `Pembayaran ${selectedCustomer.full_name} sebesar ${formatRupiah(totalAllocated)} dialokasikan ke beberapa angsuran${isKasir ? ' - Diverifikasi dengan PIN kasir' : ''}`,
        metadata: {
          customer_id: selectedCustomer.id,
          application_id: selectedInstallment.application_id,
          total_allocated: totalAllocated,
          payment_date: finalPaymentDate,
          payment_method: paymentMethod,
          reference: referenceNumber || undefined,
          verified_by_kasir: isKasir,
          kasir_member_id: isKasir ? currentMemberId : undefined
        }
      });

      // Show success immediately - process incentives in background
      toast({
        title: "Pembayaran berhasil dialokasikan",
        description: `Total ${formatRupiah(totalAllocated)} telah diaplikasikan ke angsuran berjalan`
      });

      // Store success data for WhatsApp receipt
      setSuccessPaymentData({
        customer: selectedCustomer,
        totalAllocated,
        paymentDate: finalPaymentDate,
        paymentMethod,
        referenceNumber,
        paymentResults,
        installmentQueue: [selectedInstallment]
      });
      setPaymentSuccess(true);
      setIsProcessing(false);

      // Invalidate queries to refresh data immediately
      invalidateInstallments();
      invalidatePayments();

      // Process all background tasks without blocking UI
      const backgroundTasks = async () => {
        // Process incentives
        try {
          const { data: incentiveSettings } = await (supabase as any)
            .from('incentive_settings')
            .select('is_enabled, installment_payment_enabled, holiday_enabled')
            .maybeSingle();
          
          if (incentiveSettings?.is_enabled) {
            const incentivePromises = [];
            
            for (const result of paymentResults) {
              if (incentiveSettings.installment_payment_enabled) {
                incentivePromises.push(
                  supabase.functions.invoke('process-incentive', {
                    body: {
                      type: 'installment_payment',
                      application_id: selectedInstallment.application_id,
                      payment_id: result.payment_id,
                      installment_id: result.installment_id
                    }
                  })
                );
              }

              // THR accumulation (if enabled and before cutoff)
              if (incentiveSettings.holiday_enabled) {
                const paymentDateObj = new Date(finalPaymentDate);
                const paymentMonth = paymentDateObj.getMonth() + 1;
                const paymentDay = paymentDateObj.getDate();
                const isBeforeCutoff = paymentMonth < 12 || (paymentMonth === 12 && paymentDay <= 1);
                
                if (isBeforeCutoff) {
                  incentivePromises.push(
                    supabase.functions.invoke('process-incentive', {
                      body: {
                        type: 'holiday',
                        application_id: selectedInstallment.application_id,
                        payment_id: result.payment_id,
                        installment_id: result.installment_id
                      }
                    })
                  );
                }
              }
            }
            
            if (incentivePromises.length > 0) {
              await Promise.allSettled(incentivePromises);
            }
          }
        } catch (incentiveError) {
          console.error('Failed to process payment incentive:', incentiveError);
        }

        // Process kasir incentive if user is kasir
        if (isKasir && currentMemberId) {
          try {
            const { data: kasirIncentiveSettings } = await supabase
              .from('incentive_settings')
              .select('kasir_enabled, kasir_payment_enabled')
              .maybeSingle();
            
            if (kasirIncentiveSettings?.kasir_enabled && kasirIncentiveSettings?.kasir_payment_enabled) {
              for (const result of paymentResults) {
                await supabase.functions.invoke('process-kasir-incentive', {
                  body: {
                    type: 'kasir_payment',
                    payment_id: result.payment_id,
                    kasir_member_id: currentMemberId
                  }
                });
              }
            }
          } catch (kasirIncentiveError) {
            console.error('Failed to process kasir incentive:', kasirIncentiveError);
          }
        }

        // Send notification and WhatsApp
        try {
          await supabase.from("customer_messages").insert({
            customer_id: selectedCustomer.id,
            title: "Pembayaran Diterima",
            message: `Pembayaran sebesar ${formatRupiah(totalAllocated)} untuk angsuran telah diterima dan dicatat pada ${formatDate(finalPaymentDate)}. Terima kasih atas pembayaran Anda.`,
            type: "payment",
            is_read: false
          });

          const { data: whatsappSettings } = await supabase.from("whatsapp_settings").select("is_enabled").maybeSingle();
          if (whatsappSettings?.is_enabled && selectedCustomer.phone) {
            let receiptMessage = `✅ *BUKTI PEMBAYARAN ANGSURAN*\n\n`;
            receiptMessage += `Kepada Yth. ${selectedCustomer.full_name}\n`;
            receiptMessage += `ID: ${selectedCustomer.id_number}\n\n`;
            receiptMessage += `📋 *Detail Pembayaran:*\n`;
            receiptMessage += `• Tanggal: ${formatDate(finalPaymentDate)}\n`;
            receiptMessage += `• Total Dibayar: ${formatRupiah(totalAllocated)}\n`;
            receiptMessage += `• Metode: ${paymentMethod}\n`;
            if (referenceNumber) {
              receiptMessage += `• Ref: ${referenceNumber}\n`;
            }
            receiptMessage += `\n💰 *Alokasi Pembayaran:*\n`;
            for (const result of paymentResults) {
              receiptMessage += `\nAngsuran #${selectedInstallment.installment_number}:\n`;
              receiptMessage += `• Pokok: ${formatRupiah(result.allocated_principal)}\n`;
              if (result.allocated_penalty > 0) {
                receiptMessage += `• Denda: ${formatRupiah(result.allocated_penalty)}\n`;
              }
              receiptMessage += `• Status: ${result.new_status === 'paid' ? '✅ Lunas' : '⏳ Sebagian'}\n`;
              if (result.remaining_to_pay > 0) {
                receiptMessage += `• Sisa: ${formatRupiah(result.remaining_to_pay)}\n`;
              }
            }
            receiptMessage += `\n⭐ Skor Kredit Anda: ${selectedCustomer.credit_score?.toFixed(1) ?? '0.0'}/5\n\n`;
            receiptMessage += `Terima kasih atas pembayaran Anda! 🙏`;
            
            await supabase.functions.invoke('send-whatsapp-message', {
              body: {
                phone_number: selectedCustomer.phone,
                message: receiptMessage
              }
            });
          }
        } catch (notifError) {
          console.error("Notification error:", notifError);
        }

        // Reload installments for the same customer
        loadCustomerInstallments(selectedCustomer.id);
      };

      // Run background tasks without blocking
      backgroundTasks().catch(err => console.error("Background task error:", err));

      // Don't call onSuccess() here - let user continue paying if there are more installments
    } catch (error: any) {
      toast({
        title: "Gagal mencatat pembayaran",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
      setProgressMessage("");
      setProgressValue(0);
    }
  };
  const getDaysOverdue = (dueDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    const diffTime = today.getTime() - due.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };
  return <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>
            {paymentSuccess ? "Pembayaran Berhasil" : "Bayar Angsuran"}
          </ResponsiveDialogTitle>
          <ResponsiveDialogDescription>
            {paymentSuccess ? "Pembayaran telah berhasil dicatat. Anda dapat mengirim bukti bayar melalui WhatsApp." : "Silakan cari nasabah lalu pilih angsuran untuk mencatat pembayaran."}
          </ResponsiveDialogDescription>
        </ResponsiveDialogHeader>

        {paymentSuccess && successPaymentData ?
      // Success screen with WhatsApp button
      <div className="space-y-6 py-4">
            <div className="flex flex-col items-center gap-4 p-6 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-900">
              <SuccessCheckmark 
                show={true} 
                message=""
              />
              <div className="text-center space-y-2">
                <h3 className="font-bold text-lg text-success">Pembayaran Berhasil!</h3>
                <p className="text-muted-foreground">
                  Total {formatRupiah(successPaymentData.totalAllocated)} telah dicatat untuk {successPaymentData.customer.full_name}
                </p>
              </div>
            </div>

            {/* Payment Summary */}
            <div className="space-y-3 p-4 bg-muted/50 rounded-lg">
              <h4 className="font-semibold text-sm">Ringkasan Pembayaran</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Nama Nasabah:</span>
                  <span className="font-medium">{successPaymentData.customer.full_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ID Nasabah:</span>
                  <span className="font-medium">{successPaymentData.customer.id_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tanggal Bayar:</span>
                  <span className="font-medium">{formatDate(successPaymentData.paymentDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Metode:</span>
                  <span className="font-medium">{successPaymentData.paymentMethod}</span>
                </div>
                {successPaymentData.referenceNumber && <div className="flex justify-between">
                    <span className="text-muted-foreground">No. Referensi:</span>
                    <span className="font-medium">{successPaymentData.referenceNumber}</span>
                  </div>}
                <div className="flex justify-between border-t pt-2 mt-2">
                  <span className="font-semibold">Total Dibayar:</span>
                  <span className="font-bold text-lg">{formatRupiah(successPaymentData.totalAllocated)}</span>
                </div>
              </div>

              {/* Allocations */}
              {successPaymentData.paymentResults && successPaymentData.paymentResults.length > 0 && <div className="mt-4 pt-4 border-t space-y-2">
                  <h5 className="font-semibold text-sm">Alokasi Pembayaran:</h5>
                  {successPaymentData.paymentResults.map((result: any) => {
              const instNum = successPaymentData.installmentQueue?.find((q: any) => q.id === result.installment_id)?.installment_number;
              return <div key={result.installment_id} className="text-xs bg-background/50 p-2 rounded">
                        <div className="font-medium mb-1">Angsuran #{instNum}</div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Pokok:</span>
                          <span>{formatRupiah(result.allocated_principal)}</span>
                        </div>
                        {result.allocated_penalty > 0 && <div className="flex justify-between">
                            <span className="text-muted-foreground">Denda:</span>
                            <span>{formatRupiah(result.allocated_penalty)}</span>
                          </div>}
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Status:</span>
                          <span className={result.new_status === 'paid' ? 'text-green-600 font-medium' : 'text-yellow-600'}>
                            {result.new_status === 'paid' ? '✅ Lunas' : '⏳ Sebagian'}
                          </span>
                        </div>
                      </div>;
            })}
                </div>}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <Button className="w-full bg-green-600 hover:bg-green-700 text-white" onClick={async () => {
            let customerPhone = successPaymentData.customer.phone?.trim();

            // Fallback: fetch phone number from database if not available
            if (!customerPhone) {
              const customerId = successPaymentData.customer.id;
              if (customerId) {
                const {
                  data: fetched
                } = await supabase.from('customers').select('phone').eq('id', customerId).maybeSingle();
                customerPhone = (fetched as any)?.phone?.trim() || '';
              }
            }
            if (!customerPhone) {
              toast({
                title: "Error",
                description: "Nomor telepon nasabah tidak tersedia",
                variant: "destructive"
              });
              return;
            }

            // Validate phone number format
            const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
            if (!cleanPhone || cleanPhone.length < 8) {
              toast({
                title: "Error",
                description: "Format nomor telepon tidak sesuai. Minimal 8 digit.",
                variant: "destructive"
              });
              return;
            }

            // Build payment receipt message using consistent format from whatsappHelper
            let receiptMessage = `✅ *BUKTI PEMBAYARAN ANGSURAN*\n\n`;
            receiptMessage += `Kepada Yth,\n`;
            receiptMessage += `Bapak/Ibu *${successPaymentData.customer.full_name}*\n\n`;
            receiptMessage += `Pembayaran Anda telah kami terima dengan detail sebagai berikut:\n\n`;
            receiptMessage += `📋 *Detail Transaksi:*\n`;
            receiptMessage += `• No. ID: ${successPaymentData.customer.id_number}\n`;
            receiptMessage += `• Tanggal Bayar: ${formatDate(successPaymentData.paymentDate)}\n`;
            receiptMessage += `• Jumlah Dibayar: ${formatRupiah(successPaymentData.totalAllocated)}\n`;
            receiptMessage += `• Metode: ${successPaymentData.paymentMethod}\n`;
            if (successPaymentData.referenceNumber) {
              receiptMessage += `• No. Referensi: ${successPaymentData.referenceNumber}\n`;
            }
            receiptMessage += `\n💰 *Rincian Pembayaran Angsuran:*\n`;
            for (const result of successPaymentData.paymentResults || []) {
              const instNum = successPaymentData.installmentQueue?.find((q: any) => q.id === result.installment_id)?.installment_number;
              receiptMessage += `\n• Angsuran ke-${instNum}:\n`;
              receiptMessage += `  - Pokok: ${formatRupiah(result.allocated_principal)}\n`;
              if (result.allocated_penalty > 0) {
                receiptMessage += `  - Denda: ${formatRupiah(result.allocated_penalty)}\n`;
              }
              receiptMessage += `  - Status: ${result.new_status === 'paid' ? '✅ Lunas' : '⏳ Sebagian'}\n`;
              if (result.remaining_to_pay > 0) {
                receiptMessage += `  - Sisa: ${formatRupiah(result.remaining_to_pay)}\n`;
              }
            }

            // CRITICAL: Gunakan credit_score langsung dari database tanpa fallback
            const creditScore = successPaymentData.customer.credit_score ?? 0;
            const scoreEmoji = creditScore >= 4.5 ? '🌟' : creditScore >= 3.5 ? '⭐' : '⚠️';
            receiptMessage += `\n${scoreEmoji} *Skor Kredit Anda: ${creditScore.toFixed(1)}/5.0*\n`;
            receiptMessage += `_Skor kredit Anda ${creditScore >= 4.5 ? 'sangat baik' : creditScore >= 3.5 ? 'baik' : 'perlu ditingkatkan'}_\n`;
            receiptMessage += `\n✨ Terima kasih atas pembayaran Anda!\n\n`;

            // Add login info if available
            if (successPaymentData.customer.id_number && successPaymentData.customer.date_of_birth) {
              const dob = new Date(successPaymentData.customer.date_of_birth);
              const day = String(dob.getDate()).padStart(2, '0');
              const month = String(dob.getMonth() + 1).padStart(2, '0');
              const year = dob.getFullYear();
              const password = `${day}${month}${year}`;
              receiptMessage += `\n🔐 *Login:* ${successPaymentData.customer.id_number} / ${password}\n`;
              receiptMessage += `https://www.mitradana.id/\n`;
            }
            receiptMessage += `_Simpan pesan ini sebagai bukti pembayaran Anda._`;
            openWhatsAppChat(customerPhone, receiptMessage);
            toast({
              title: "Berhasil",
              description: "Membuka WhatsApp..."
            });
          }}>
                <MessageSquare className="h-4 w-4 mr-2" />
                Kirim Bukti Bayar via WhatsApp
              </Button>

              <Button variant="outline" onClick={() => {
            resetForm();
            onOpenChange(false);
          }}>
                Tutup
              </Button>
            </div>
          </div> :
      // Original payment form
      <div className="space-y-6">
          {/* Customer Search */}
          

          {/* Search Results - Multiple Customers */}
          {showSearchResults && searchResults.length > 0 && <div className="space-y-2">
              <Label>Pilih Nasabah ({searchResults.length} hasil ditemukan)</Label>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {searchResults.map(customer => <button key={customer.id} onClick={() => selectCustomerFromResults(customer)} className="w-full text-left p-3 rounded-lg border hover:bg-accent transition-colors">
                    <h3 className="font-semibold">{customer.full_name}</h3>
                    <p className="text-sm text-muted-foreground">
                      ID: {customer.id_number}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Telepon: {customer.phone}
                    </p>
                  </button>)}
              </div>
            </div>}


          {/* Installments List */}
          {installments.length > 0 && <div className="space-y-2">
              <Label>Pilih Angsuran</Label>
              <div className="space-y-2">
                {installments.map((inst, index) => {
              const daysOverdue = getDaysOverdue(inst.due_date);
              const remaining = Number(inst.total_amount) - Number(inst.paid_amount);
              const isOverdue = daysOverdue > 0;
              const isFirstInstallment = index === 0;
              const isDisabled = !isFirstInstallment;
              return <button key={inst.id} onClick={() => isFirstInstallment && handleInstallmentSelect(inst)} disabled={isDisabled} className={`w-full text-left p-3 rounded-lg border transition-colors ${selectedInstallment?.id === inst.id ? "border-primary bg-accent" : isDisabled ? "opacity-50 cursor-not-allowed bg-muted" : "hover:bg-accent cursor-pointer"}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">
                            Angsuran #{inst.installment_number} -{" "}
                            {inst.credit_applications?.customers?.id_number}
                            {isFirstInstallment && <span className="ml-2 text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded">
                                Prioritas
                              </span>}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Jatuh Tempo: {formatDate(inst.due_date)}
                          </p>
                          {isOverdue && <p className="text-sm text-destructive">
                              Terlambat {daysOverdue} hari
                            </p>}
                          {isDisabled && <p className="text-xs text-muted-foreground mt-1">
                              Bayar angsuran sebelumnya terlebih dahulu
                            </p>}
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">{formatRupiah(remaining)}</p>
                          <p className="text-sm text-muted-foreground">
                            dari {formatRupiah(Number(inst.total_amount))}
                          </p>
                        </div>
                      </div>
                    </button>;
            })}
              </div>
            </div>}

          {selectedInstallment && <div className="space-y-4 mt-6 p-4 bg-secondary/20 rounded-lg">
              <h4 className="font-semibold">Informasi Pembayaran</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Nama Nasabah</span>
                  <p className="font-medium">{selectedCustomer?.full_name}</p>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Angsuran ke-</span>
                  <p className="font-medium">{selectedInstallment.installment_number}</p>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tanggal Jatuh Tempo</span>
                  <p className="font-medium">{formatDate(selectedInstallment.due_date)}</p>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Angsuran Bulanan</span>
                  <p className="font-medium">{formatRupiah(selectedInstallment.total_amount)}</p>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Terbayar</span>
                  <p className="font-medium">{formatRupiah(selectedInstallment.paid_amount)}</p>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sisa Angsuran</span>
                  <p className="font-medium">{formatRupiah(selectedInstallment.total_amount - selectedInstallment.paid_amount)}</p>
                </div>
                
                {/* Penalty Details */}
                {penalty > 0 && daysOverdue > 0 && <div className="border-t pt-2 mt-2 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground font-semibold">Rincian Denda:</span>
                    </div>
                    <div className="flex justify-between pl-4">
                      <span className="text-muted-foreground text-xs">Lama Keterlambatan</span>
                      <p className="font-medium text-xs">{daysOverdue} hari</p>
                    </div>
                    <div className="flex justify-between pl-4">
                      <span className="text-muted-foreground text-xs">Persentase Denda</span>
                      <p className="font-medium text-xs">{penaltyRate}% per hari</p>
                    </div>
                    <div className="flex justify-between pl-4">
                      <span className="text-muted-foreground text-xs">Denda per Hari</span>
                      <p className="font-medium text-xs">{formatRupiah(roundToThousand(selectedInstallment.total_amount * (penaltyRate / 100)))}</p>
                    </div>
                    <div className="flex justify-between pl-4 border-t pt-1">
                      <span className="text-muted-foreground font-medium">Total Denda</span>
                      <p className="font-bold text-destructive">{formatRupiah(penalty)}</p>
                    </div>
                  </div>}
                
                {penalty === 0 && <div className="flex justify-between">
                    <span className="text-muted-foreground">Denda</span>
                    <p className="font-medium text-green-600">Rp. 0</p>
                  </div>}
                
                <div className="flex justify-between border-t pt-2 mt-2">
                  <span className="font-semibold">Total Tagihan</span>
                  <p className="font-bold">
                    {formatRupiah(selectedInstallment.total_amount - selectedInstallment.paid_amount + penalty)}
                  </p>
                </div>
              </div>
            </div>}

          {/* Payment Form */}
          {selectedInstallment && <div className="space-y-4 rounded-lg border p-4 bg-muted/50">
              <h3 className="font-semibold">Detail Pembayaran</h3>

              <div className="space-y-2">
                <Label>Jumlah Bayar</Label>
                <CurrencyInput value={paymentAmount} onChange={value => setPaymentAmount(value)} placeholder="0" />
              </div>

              <div className="space-y-2">
                <Label>Metode Pembayaran</Label>
                <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <option value="cash">Tunai</option>
                  <option value="transfer">Transfer Bank</option>
                  <option value="e-wallet">E-Wallet</option>
                </select>
              </div>

              {paymentMethod !== "cash" && <div className="space-y-2">
                  <Label>Nomor Referensi</Label>
                  <Input value={referenceNumber} onChange={e => setReferenceNumber(e.target.value)} placeholder="Nomor transaksi/referensi" />
                </div>}

              <div className="space-y-2">
                <Label>Tanggal Pembayaran (opsional)</Label>
                <DatePicker value={paymentDate} onChange={setPaymentDate} placeholder="dd/MM/yyyy" maxDate={getTodayInWIB()} />
                <p className="text-xs text-muted-foreground">
                  Kosongkan untuk menggunakan tanggal hari ini
                </p>
                
                {paymentDate && (() => {
              const today = new Date();
              today.setHours(0, 0, 0, 0);
              const selected = new Date(paymentDate);
              selected.setHours(0, 0, 0, 0);
              return selected < today;
            })() && <Alert className="mt-2">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      <strong>Input Data Historis:</strong> Tanggal pembayaran yang Anda pilih adalah tanggal di masa lalu. 
                      Pembayaran ini akan dicatat sebagai <strong>input data kredit lama</strong> dan <strong>tidak akan dikenakan denda</strong>, 
                      meskipun melewati tanggal jatuh tempo.
                    </AlertDescription>
                  </Alert>}
              </div>

              {/* PIN Kasir - Only for Kasir role */}
              {isKasir && (
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    PIN Kasir
                  </Label>
                  <Input 
                    type="password" 
                    value={kasirPin} 
                    onChange={(e) => setKasirPin(e.target.value)} 
                    placeholder="Masukkan PIN kasir"
                    maxLength={6}
                    className="text-center tracking-widest font-semibold"
                  />
                  <p className="text-xs text-muted-foreground">
                    Verifikasi PIN diperlukan untuk memproses pembayaran
                  </p>
                </div>
              )}

              {/* Inline Progress Indicator */}
              {isProcessing && progressMessage && (
                <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span className="text-sm font-medium">{progressMessage}</span>
                  </div>
                  <Progress value={progressValue} className="h-2" />
                  <p className="text-xs text-muted-foreground text-center">
                    Mohon tunggu, jangan tutup form ini...
                  </p>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button onClick={handlePayment} disabled={isProcessing || !paymentAmount || parseFloat(paymentAmount) <= 0 || (isKasir && !kasirPin)} className="flex-1" type="button">
                  {isProcessing ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Memproses...
                    </span>
                  ) : "Bayar"}
                </Button>
                <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isProcessing} type="button">
                  Batal
                </Button>
              </div>
            </div>}
        </div>}
      </ResponsiveDialogContent>
    </ResponsiveDialog>;
}