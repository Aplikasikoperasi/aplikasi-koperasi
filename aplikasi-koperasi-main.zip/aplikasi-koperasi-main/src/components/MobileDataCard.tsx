import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { ReactNode, ElementType } from "react";
import { CreditScoreStars } from "./CreditScoreStars";
import { AchievementBadge } from "./AchievementBadge";
import { PositionBadge } from "./PositionBadge";

interface MobileDataCardProps {
  id: string;
  photoUrl?: string | null;
  name: string;
  subtitle?: string;
  remainingAmount?: number;
  onClick: () => void;
  className?: string;
  statusIndicator?: ReactNode;
  progressValue?: number;
  progressLabel?: string;
  creditScore?: number;
  restorationStatus?: "never_restored" | "restored_once" | "permanently_blocked";
  applicationNumber?: string;
  installmentNumber?: number;
  paymentDate?: string;
  dueDate?: string;
  penaltyAmount?: number;
  registrationDate?: string;
  totalActiveLoanAmount?: number;
  totalCompletedLoanAmount?: number;
  disbursedAt?: string;
  firstInstallmentType?: string;
  isSilenced?: boolean;
  achievementBadge?: {
    badge_level: string;
    badge_name: string | null;
    badge_description: string | null;
    consecutive_on_time_payments: number;
    on_time_percentage: number;
  };
  creatorMember?: {
    full_name: string;
    position?: string;
  } | null;
  responsibleMember?: {
    full_name: string;
    position?: string;
  } | null;
  // Icon to display instead of avatar (for expenses, etc.)
  categoryIcon?: ElementType;
  categoryIconClassName?: string;
  // Badge/label to display for categorization
  badge?: ReactNode;
}

export function MobileDataCard({
  id,
  photoUrl,
  name,
  subtitle,
  remainingAmount,
  onClick,
  className,
  statusIndicator,
  progressValue,
  progressLabel,
  creditScore,
  restorationStatus,
  applicationNumber,
  installmentNumber,
  paymentDate,
  dueDate,
  penaltyAmount,
  registrationDate,
  totalActiveLoanAmount,
  totalCompletedLoanAmount,
  disbursedAt,
  firstInstallmentType,
  isSilenced,
  achievementBadge,
  creatorMember,
  responsibleMember,
  categoryIcon: CategoryIcon,
  categoryIconClassName,
  badge,
}: MobileDataCardProps) {
  return (
    <Card
      className={cn(
        "w-full max-w-full cursor-pointer hover:shadow-lg transition-shadow overflow-hidden",
        className
      )}
      onClick={onClick}
    >
      <div className="p-3">
        <div className="flex items-start gap-3">
          {/* Avatar or Category Icon */}
          <div className="relative flex-shrink-0 self-center" onClick={(e) => e.stopPropagation()}>
            {CategoryIcon ? (
              <div className={cn(
                "h-14 w-14 rounded-full flex items-center justify-center bg-primary/10",
                categoryIconClassName
              )}>
                <CategoryIcon className="h-7 w-7 text-primary" />
              </div>
            ) : (
              <ClickableAvatar
                src={photoUrl}
                alt={name}
                fallback={name.substring(0, 2).toUpperCase()}
                className="h-14 w-14"
                fallbackClassName="bg-primary/10 text-primary text-lg"
              />
            )}
            {statusIndicator}
          </div>

          {/* Customer Info */}
          <div className="flex-1 min-w-0 space-y-1.5">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm whitespace-pre-wrap break-words">{name}</h3>
                {subtitle && (
                  <p className="text-xs text-muted-foreground whitespace-pre-wrap break-words">{subtitle}</p>
                )}
                {remainingAmount !== undefined && remainingAmount > 0 && (
                  <p className="text-xs font-semibold text-red-600">
                    Sisa: Rp {remainingAmount.toLocaleString('id-ID')}
                  </p>
                )}
              </div>
              {creditScore !== undefined && restorationStatus && (
                <div className="flex-shrink-0">
                  <CreditScoreStars 
                    creditScore={creditScore} 
                    restorationStatus={restorationStatus}
                    className="scale-90"
                  />
                </div>
              )}
            </div>
            
            {/* Achievement Badge */}
            {achievementBadge && achievementBadge.badge_level !== 'none' && (
              <div className="mt-1">
                <AchievementBadge
                  badgeLevel={achievementBadge.badge_level}
                  badgeName={achievementBadge.badge_name}
                  badgeDescription={achievementBadge.badge_description}
                  consecutivePayments={achievementBadge.consecutive_on_time_payments}
                  onTimePercentage={achievementBadge.on_time_percentage}
                  size="sm"
                  showDetails={true}
                />
              </div>
            )}

            {/* Badge Label */}
            {badge && (
              <div className="mb-1">
                {badge}
              </div>
            )}

            {/* ID and Application Number */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-mono font-bold bg-primary/10 px-2 py-0.5 rounded border border-primary/20">
                {id}
              </span>
              {applicationNumber && (
                <span className="text-xs font-mono bg-muted px-2 py-0.5 rounded border border-border">
                  {applicationNumber}
                </span>
              )}
              {installmentNumber && (
                <span className="text-xs font-semibold bg-muted px-2 py-0.5 rounded border border-border">
                  Ang #{installmentNumber}
                </span>
              )}
              {isSilenced && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="text-xs font-semibold bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded border border-purple-300 dark:border-purple-700 flex items-center gap-1">
                        🔕 Silent
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">Tidak akan menerima reminder otomatis</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>

            {/* Responsible Member (Penanggung Jawab Kredit) */}
            {responsibleMember && (
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-muted-foreground">PJ Kredit: </span>
                <span className="font-semibold">{responsibleMember.full_name}</span>
                {responsibleMember.position && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div>
                          <PositionBadge 
                            position={responsibleMember.position}
                            size="sm"
                            className="cursor-help"
                          />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">Penanggung jawab aplikasi kredit</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
            )}

            {/* Creator Member */}
            {creatorMember && (
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-muted-foreground">Petugas: </span>
                <span className="font-semibold">{creatorMember.full_name}</span>
                {creatorMember.position && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div>
                          <PositionBadge 
                            position={creatorMember.position}
                            size="sm"
                            className="cursor-help"
                          />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">Diinput oleh {creatorMember.position}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
            )}

            {/* Registration Date */}
            {registrationDate && (
              <div className="text-xs text-muted-foreground">
                Terdaftar: {new Date(registrationDate).toLocaleDateString('id-ID', { 
                  day: '2-digit', 
                  month: 'short', 
                  year: 'numeric' 
                })}
              </div>
            )}

            {/* Disbursement Date and First Installment Type */}
            {disbursedAt && (
              <div className="flex flex-col gap-0.5 text-xs">
                <div className="flex items-center gap-1">
                  <span className="text-muted-foreground">Dicairkan:</span>
                  <span className="font-semibold">{new Date(disbursedAt).toLocaleDateString('id-ID', { 
                    day: '2-digit', 
                    month: 'short', 
                    year: 'numeric' 
                  })}</span>
                </div>
                {firstInstallmentType && (
                  <div className="flex items-center gap-1">
                    <span className="text-muted-foreground">Angsuran 1:</span>
                    <span className="font-semibold">
                      {firstInstallmentType === 'paid_upfront' ? 'Potong saat Pencairan' : 'Bulan Berikutnya'}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Loan Amount Summary */}
            {(totalActiveLoanAmount !== undefined && totalActiveLoanAmount > 0) || (totalCompletedLoanAmount !== undefined && totalCompletedLoanAmount > 0) ? (
              <div className="flex flex-col gap-0.5 text-xs">
                {totalActiveLoanAmount !== undefined && totalActiveLoanAmount > 0 && (
                  <div className="flex items-center gap-1">
                    <span className="text-muted-foreground">Pinjaman Aktif:</span>
                    <span className="font-semibold text-orange-600">Rp {totalActiveLoanAmount.toLocaleString('id-ID')}</span>
                  </div>
                )}
                {totalCompletedLoanAmount !== undefined && totalCompletedLoanAmount > 0 && (
                  <div className="flex items-center gap-1">
                    <span className="text-muted-foreground">Pinjaman Lunas:</span>
                    <span className="font-semibold text-green-600">Rp {totalCompletedLoanAmount.toLocaleString('id-ID')}</span>
                  </div>
                )}
              </div>
            ) : null}

            {/* Additional Info */}
            {(dueDate || paymentDate || penaltyAmount) && (
              <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
                {dueDate && (
                  <span>Jatuh Tempo: {new Date(dueDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                )}
                {paymentDate && (
                  <span>Dibayar: {new Date(paymentDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                )}
                {penaltyAmount !== undefined && penaltyAmount > 0 && (
                  <span className="font-semibold text-yellow-700">
                    ⚠️ Denda: Rp {penaltyAmount.toLocaleString('id-ID')}
                  </span>
                )}
              </div>
            )}

            {/* Progress Bar */}
            {progressValue !== undefined && (
              <div className="pt-2 w-full">
                <div className="flex justify-between items-center text-xs mb-1.5">
                  <span className="text-muted-foreground">{progressLabel}</span>
                  <span className="font-semibold">{progressValue?.toFixed(1)}%</span>
                </div>
                <Progress value={progressValue} className="h-2 w-full" />
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
