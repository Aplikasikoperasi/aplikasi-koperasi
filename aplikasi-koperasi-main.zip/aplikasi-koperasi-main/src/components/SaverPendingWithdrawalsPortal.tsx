import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { formatRupiah, formatDateWIB } from "@/lib/utils";
import {
  Clock,
  User,
  Banknote,
  Building2,
  AlertCircle,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface PendingWithdrawal {
  id: string;
  saver_id: string;
  amount: number;
  payment_method: string | null;
  payment_details: string | null;
  notes: string | null;
  requested_at: string;
  expires_at: string;
  status: string;
  transaction_number: string | null;
  savers: {
    full_name: string;
    account_number: string;
  } | null;
  members: {
    full_name: string;
  } | null;
}

export default function SaverPendingWithdrawalsPortal() {
  const [pendingWithdrawals, setPendingWithdrawals] = useState<PendingWithdrawal[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadPendingWithdrawals = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("saver_pending_withdrawals")
        .select(`
          *,
          savers:saver_id(full_name, account_number),
          members:requested_by(full_name)
        `)
        .eq("status", "pending")
        .order("requested_at", { ascending: false });

      if (error) throw error;
      setPendingWithdrawals(data || []);
    } catch (error) {
      console.error("Error loading pending withdrawals:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPendingWithdrawals();

    // Subscribe to real-time changes
    const channel = supabase
      .channel("pending-withdrawals-portal")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "saver_pending_withdrawals",
        },
        () => {
          loadPendingWithdrawals();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadPendingWithdrawals();
    setRefreshing(false);
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diff = expires.getTime() - now.getTime();

    if (diff <= 0) return "Kadaluarsa";

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}j ${minutes}m`;
  };

  // Update countdown every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setPendingWithdrawals((prev) => [...prev]);
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Daftar Tunggu Penarikan Debitur
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : pendingWithdrawals.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Tidak ada penarikan yang menunggu konfirmasi</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px]">
            <div className="space-y-3">
              {pendingWithdrawals.map((withdrawal) => (
                <div
                  key={withdrawal.id}
                  className="p-4 border rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800"
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-semibold">
                          {withdrawal.savers?.full_name || "Unknown"}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {withdrawal.savers?.account_number}
                      </p>
                      {withdrawal.transaction_number && (
                        <p className="text-xs font-mono text-primary mt-0.5">
                          #{withdrawal.transaction_number}
                        </p>
                      )}
                    </div>
                    <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-300">
                      <Clock className="h-3 w-3 mr-1" />
                      {getTimeRemaining(withdrawal.expires_at)}
                    </Badge>
                  </div>

                  {/* Amount */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Jumlah</span>
                    <span className="text-lg font-bold text-destructive">
                      {formatRupiah(withdrawal.amount)}
                    </span>
                  </div>

                  {/* Method */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Metode</span>
                    <div className="flex items-center gap-1 text-sm">
                      {withdrawal.payment_method === "transfer" ? (
                        <>
                          <Building2 className="h-3 w-3 text-blue-500" />
                          <span>Transfer</span>
                        </>
                      ) : (
                        <>
                          <Banknote className="h-3 w-3 text-green-600" />
                          <span>Tunai</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Requested by */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Diajukan oleh</span>
                    <span className="text-sm">{withdrawal.members?.full_name || "Admin"}</span>
                  </div>

                  {/* Requested at */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Waktu</span>
                    <span className="text-xs">{formatDateWIB(withdrawal.requested_at)}</span>
                  </div>

                  {/* Notes */}
                  {withdrawal.notes && (
                    <div className="mt-2 pt-2 border-t border-amber-200 dark:border-amber-800">
                      <p className="text-xs text-muted-foreground">
                        Catatan: {withdrawal.notes}
                      </p>
                    </div>
                  )}

                  {/* Info */}
                  <div className="mt-3 p-2 bg-amber-100/50 dark:bg-amber-900/30 rounded text-xs text-amber-700 dark:text-amber-300">
                    ⏳ Menunggu konfirmasi PIN dari debitur
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
