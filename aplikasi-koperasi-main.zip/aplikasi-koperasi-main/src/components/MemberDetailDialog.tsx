import { useState } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatDate, calculateAge, cn } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { Pencil, Trash2, ShieldOff, ShieldCheck, UserPlus, Crown, Shield, Briefcase, KeyRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface MemberDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: any;
  isOnline?: boolean;
  onEdit?: (member: any) => void;
  onDelete?: (member: any) => void;
  onToggleActive?: (member: any) => void;
  onActivateAccount?: (member: any) => void;
}

export function MemberDetailDialog({
  open,
  onOpenChange,
  member,
  isOnline = false,
  onEdit,
  onDelete,
  onToggleActive,
  onActivateAccount,
}: MemberDetailDialogProps) {
  // All hooks must be called unconditionally BEFORE any early returns
  const { isOwner, isAdmin, isSales } = useUserRole();
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();
  
  // PIN Edit States
  const [pinDialogOpen, setPinDialogOpen] = useState(false);
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [savingPin, setSavingPin] = useState(false);
  const [pinError, setPinError] = useState<string>("");
  
  // Early return AFTER all hooks
  if (!member) return null;
  
  const canManage = isOwner || isAdmin;
  const canViewDetails = isOwner || isAdmin; // Only owner and admin can see full details
  
  // Hierarki permission:
  // - Owner bisa edit/hapus: Owner, Admin, Sales, Kasir
  // - Admin bisa edit/hapus: Sales, Kasir (tidak bisa Owner dan sesama Admin)
  const targetPosition = member?.position?.toLowerCase();
  const isTargetOwner = targetPosition === 'owner';
  const isTargetAdmin = targetPosition === 'admin';
  const isTargetSalesOrKasir = targetPosition === 'sales' || targetPosition === 'kasir';
  
  // Tentukan apakah user yang login bisa edit member ini
  let canEditThisMember = false;
  if (isOwner) {
    // Owner bisa edit semua
    canEditThisMember = true;
  } else if (isAdmin) {
    // Admin hanya bisa edit Sales dan Kasir, tidak bisa edit Owner dan sesama Admin
    canEditThisMember = isTargetSalesOrKasir;
  }
  
  const isKasir = member?.position?.toLowerCase() === 'kasir';

  const handleEditPin = () => {
    setNewPin("");
    setConfirmPin("");
    setPinError("");
    setPinDialogOpen(true);
  };

  const handlePinSubmit = async () => {
    // Clear previous errors
    setPinError("");
    
    // Validate PIN format (only numbers)
    const pinRegex = /^\d+$/;
    if (!newPin || !pinRegex.test(newPin)) {
      const errorMsg = "PIN hanya boleh berisi angka";
      setPinError(errorMsg);
      toast({
        title: "❌ PIN tidak valid",
        description: errorMsg,
        variant: "destructive"
      });
      return;
    }

    // Validate PIN length (exactly 6 digits)
    if (newPin.length !== 6) {
      const errorMsg = "PIN harus tepat 6 digit angka";
      setPinError(errorMsg);
      toast({
        title: "❌ PIN tidak valid",
        description: errorMsg,
        variant: "destructive"
      });
      return;
    }

    if (newPin !== confirmPin) {
      const errorMsg = "PIN dan konfirmasi PIN harus sama";
      setPinError(errorMsg);
      toast({
        title: "❌ PIN tidak cocok",
        description: errorMsg,
        variant: "destructive"
      });
      return;
    }

    setSavingPin(true);
    try {
      // Request Supercode verification
      const isValid = await requireSuperCode('Ubah PIN Kasir');
      
      if (!isValid) {
        toast({
          title: "Verifikasi Gagal",
          description: "SuperCode salah atau dibatalkan",
          variant: "destructive"
        });
        setSavingPin(false);
        // Keep dialog open so user can try again
        return;
      }

      // Update PIN in database
      const { error } = await supabase
        .from('members')
        .update({ pin: newPin })
        .eq('id', member.id);

      if (error) {
        console.error('Error updating PIN:', error);
        toast({
          title: "Gagal Mengubah PIN",
          description: error.message || "Terjadi kesalahan saat mengubah PIN",
          variant: "destructive"
        });
        // Close dialog even on error
        setPinDialogOpen(false);
        setNewPin("");
        setConfirmPin("");
        setSavingPin(false);
        return;
      }

      // If member has auth account, sync PIN to auth system
      if (member.user_id && member.date_of_birth) {
        try {
          await supabase.functions.invoke('create-member-auth', {
            body: {
              memberId: member.id,
              fullName: member.full_name,
              dateOfBirth: member.date_of_birth,
              position: member.position,
              pin: newPin
            }
          });
        } catch (authError) {
          console.warn('Failed to sync PIN to auth:', authError);
          // Don't fail the whole operation if auth sync fails
        }
      }

      toast({
        title: "✅ PIN Berhasil Diubah",
        description: `PIN Kasir ${member.full_name} telah diperbarui`,
        variant: "default"
      });

      // Close dialog and reset form after a short delay so user can see the success message
      setTimeout(() => {
        setPinDialogOpen(false);
        setNewPin("");
        setConfirmPin("");
      }, 500);
    } catch (error: any) {
      console.error('Error updating PIN:', error);
      toast({
        title: "Gagal Mengubah PIN",
        description: error.message || "Terjadi kesalahan saat mengubah PIN",
        variant: "destructive"
      });
      // Always close dialog even on unexpected error
      setPinDialogOpen(false);
      setNewPin("");
      setConfirmPin("");
    } finally {
      setSavingPin(false);
    }
  };

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-md w-full">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>
            {canViewDetails ? "Detail Anggota" : "Informasi Anggota"}
          </ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="w-full max-w-full space-y-4 overflow-hidden">
          {/* Photo & Basic Info */}
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <ClickableAvatar
                src={member.photo_url}
                alt={member.full_name}
                fallback={member.full_name?.substring(0, 2).toUpperCase()}
                className="h-24 w-24"
                fallbackClassName="bg-primary/10 text-primary text-2xl"
              />
              {isOnline ? (
                <span 
                  className="absolute bottom-1 right-1 block h-5 w-5 rounded-full bg-green-500 ring-4 ring-background"
                  title="Online"
                />
              ) : (
                <span 
                  className="absolute bottom-1 right-1 block h-5 w-5 rounded-full bg-gray-400 ring-4 ring-background"
                  title="Offline"
                />
              )}
            </div>
            <div className="text-center space-y-2">
              <h3 className="font-bold text-lg">{member.full_name}</h3>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <Badge variant="outline" className="text-xs font-bold">
                  {member.member_number}
                </Badge>
                {!member.is_active && (
                  <Badge variant="destructive" className="text-xs">
                    Nonaktif
                  </Badge>
                )}
              </div>
              <Badge 
                className={cn(
                  "text-xs font-semibold shadow-sm w-fit capitalize inline-flex items-center gap-1",
                  member.position?.toLowerCase() === 'owner' && "bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 text-white border-purple-300 shadow-lg animate-shimmer bg-[length:200%_100%]",
                  member.position?.toLowerCase() === 'admin' && "bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-600 text-white border-blue-300 shadow-md animate-shimmer bg-[length:200%_100%]",
                  member.position?.toLowerCase() === 'sales' && "bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600 text-white border-emerald-300 shadow-sm animate-shimmer bg-[length:200%_100%]"
                )}
              >
                {member.position?.toLowerCase() === 'owner' && <Crown className="h-3 w-3" />}
                {member.position?.toLowerCase() === 'admin' && <Shield className="h-3 w-3" />}
                {member.position?.toLowerCase() === 'sales' && <Briefcase className="h-3 w-3" />}
                {member.position}
              </Badge>
              <Badge 
                variant={isOnline ? "default" : "secondary"}
                className={cn(
                  "text-xs",
                  isOnline && "animate-shimmer bg-gradient-to-r from-green-500 via-emerald-400 to-green-600 bg-[length:200%_100%] text-white border-green-300"
                )}
              >
                {isOnline ? "Online" : "Offline"}
              </Badge>
            </div>
          </div>

          {/* Full Details - Only for Owner and Admin */}
          {canViewDetails && (
            <>
              <Separator />
              <div className="space-y-3 text-sm">
                <DetailRow label="NIK" value={member.nik || "-"} />
                <DetailRow 
                  label="Tanggal Lahir" 
                  value={member.date_of_birth ? `${formatDate(member.date_of_birth)} (${calculateAge(member.date_of_birth)} tahun)` : "-"} 
                />
                <DetailRow label="No. Telepon" value={member.phone || "-"} />
                <DetailRow label="Pekerjaan" value={member.occupation || "-"} />
                <DetailRow label="Alamat" value={member.address || "-"} />
                <DetailRow 
                  label="Terdaftar" 
                  value={formatDate(member.effective_join_date || member.created_at)} 
                />
              </div>
            </>
          )}

          {/* Privacy Notice for Sales */}
          {isSales && !canViewDetails && (
            <>
              <Separator />
              <div className="text-center text-xs text-muted-foreground italic p-2">
                Detail lengkap anggota bersifat pribadi
              </div>
            </>
          )}

          {/* Action Buttons - Kontrol akses berdasarkan posisi target */}
          {canManage && (
            <>
              <Separator />
              <div className="flex flex-col gap-2 w-full">
                {/* Tombol Buat Akun - Hanya tampil jika user_id NULL dan memiliki hak edit */}
                {canEditThisMember && !member.user_id && member.date_of_birth && (
                  <Button
                    variant="default"
                    className="w-full justify-start"
                    onClick={() => {
                      onActivateAccount?.(member);
                      onOpenChange(false);
                    }}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Buat Akun Login
                  </Button>
                )}
                
                {/* Tombol Ubah PIN - Hanya tampil untuk Kasir dengan akun aktif dan memiliki hak edit */}
                {canEditThisMember && isKasir && member.user_id && (
                  <Button
                    variant="outline"
                    className="w-full justify-start text-orange-600 border-orange-200 hover:bg-orange-50 hover:text-orange-700"
                    onClick={handleEditPin}
                  >
                    <KeyRound className="h-4 w-4 mr-2" />
                    Ubah PIN Kasir
                  </Button>
                )}
                
                {/* Tombol Edit - Untuk Owner hanya Owner yang bisa edit, untuk lain-lain Owner & Admin bisa */}
                {canEditThisMember && (
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      onEdit?.(member);
                      onOpenChange(false);
                    }}
                  >
                    <Pencil className="h-4 w-4 mr-2" />
                    Edit Data Anggota
                  </Button>
                )}
                
                {/* Tombol Nonaktifkan/Aktifkan - Tidak untuk Owner dan Admin (kecuali user adalah Owner) */}
                {canEditThisMember && !isTargetOwner && (
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      onToggleActive?.(member);
                      onOpenChange(false);
                    }}
                  >
                    {member.is_active ? (
                      <>
                        <ShieldOff className="h-4 w-4 mr-2" />
                        Nonaktifkan Anggota
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="h-4 w-4 mr-2" />
                        Aktifkan Anggota
                      </>
                    )}
                  </Button>
                )}
                
                {/* Tombol Hapus - Tidak untuk Owner dan Admin (kecuali user adalah Owner) */}
                {canEditThisMember && !isTargetOwner && (
                  <Button
                    variant="destructive"
                    className="w-full justify-start"
                    onClick={() => {
                      onDelete?.(member);
                      onOpenChange(false);
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Hapus Anggota
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </ResponsiveDialogContent>

      {/* PIN Edit Dialog */}
      <Dialog open={pinDialogOpen} onOpenChange={setPinDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ubah PIN Kasir</DialogTitle>
            <DialogDescription>
              Masukkan PIN baru untuk {member.full_name}. PIN harus tepat 6 digit angka.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {pinError && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive px-4 py-3 rounded-md">
                <p className="text-sm font-medium">❌ {pinError}</p>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="new-pin">PIN Baru</Label>
              <Input
                id="new-pin"
                type="password"
                placeholder="6 digit angka"
                value={newPin}
                onChange={(e) => {
                  // Only allow numbers
                  const value = e.target.value.replace(/\D/g, '');
                  setNewPin(value);
                  setPinError(""); // Clear error when user types
                }}
                maxLength={6}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-pin">Konfirmasi PIN</Label>
              <Input
                id="confirm-pin"
                type="password"
                placeholder="Ulangi 6 digit angka"
                value={confirmPin}
                onChange={(e) => {
                  // Only allow numbers
                  const value = e.target.value.replace(/\D/g, '');
                  setConfirmPin(value);
                  setPinError(""); // Clear error when user types
                }}
                maxLength={6}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handlePinSubmit();
                  }
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setPinDialogOpen(false);
                setNewPin("");
                setConfirmPin("");
              }}
              disabled={savingPin}
            >
              Batal
            </Button>
            <Button onClick={handlePinSubmit} disabled={savingPin}>
              {savingPin ? "Memverifikasi..." : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ResponsiveDialog>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-muted-foreground font-medium min-w-[100px]">{label}:</span>
      <span className="text-right flex-1 break-words">{value}</span>
    </div>
  );
}
