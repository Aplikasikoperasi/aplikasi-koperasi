import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Crown, Shield, Briefcase, Wallet } from "lucide-react";

interface PositionBadgeProps {
  position: string;
  className?: string;
  size?: "sm" | "md";
}

export function PositionBadge({ position, className, size = "md" }: PositionBadgeProps) {
  const lowerPosition = position.toLowerCase();
  const iconSize = size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5";
  
  return (
    <Badge 
      className={cn(
        "font-semibold w-fit capitalize inline-flex items-center gap-1",
        size === "sm" ? "text-xs shadow-sm" : "text-xs shadow-sm",
        lowerPosition === 'owner' && "bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 text-white border-purple-300 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]",
        lowerPosition === 'admin' && "bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-600 text-white border-blue-300 shadow-md animate-shimmer animate-glow bg-[length:200%_100%]",
        lowerPosition === 'sales' && "bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600 text-white border-orange-300 shadow-sm animate-shimmer bg-[length:200%_100%]",
        lowerPosition === 'kasir' && "bg-gradient-to-r from-teal-500 via-cyan-400 to-teal-600 text-white border-teal-300 shadow-sm animate-shimmer bg-[length:200%_100%]",
        className
      )}
    >
      {lowerPosition === 'owner' && <Crown className={iconSize} />}
      {lowerPosition === 'admin' && <Shield className={iconSize} />}
      {lowerPosition === 'sales' && <Briefcase className={iconSize} />}
      {lowerPosition === 'kasir' && <Wallet className={iconSize} />}
      {position}
    </Badge>
  );
}
