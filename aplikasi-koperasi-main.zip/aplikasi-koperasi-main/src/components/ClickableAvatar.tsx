import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ImagePreviewDialog } from "@/components/ImagePreviewDialog";
import { cn } from "@/lib/utils";

interface ClickableAvatarProps {
  src?: string | null;
  alt?: string;
  fallback?: string;
  className?: string;
  fallbackClassName?: string;
  enablePreview?: boolean;
}

export function ClickableAvatar({ 
  src, 
  alt = "Avatar", 
  fallback, 
  className,
  fallbackClassName,
  enablePreview = true 
}: ClickableAvatarProps) {
  const [previewOpen, setPreviewOpen] = useState(false);

  const handleClick = () => {
    if (enablePreview && src) {
      setPreviewOpen(true);
    }
  };

  return (
    <>
      <Avatar 
        className={cn(
          src && enablePreview && "cursor-pointer hover:opacity-80 transition-opacity",
          className
        )}
        onClick={handleClick}
      >
        <AvatarImage src={src || undefined} alt={alt} />
        <AvatarFallback className={fallbackClassName}>
          {fallback || alt?.charAt(0)?.toUpperCase() || "?"}
        </AvatarFallback>
      </Avatar>

      <ImagePreviewDialog
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        imageUrl={src}
        alt={alt}
      />
    </>
  );
}
