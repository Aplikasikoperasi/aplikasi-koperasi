import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { CheckCircle, XCircle, Clock, Loader2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useUserRole } from "@/hooks/useUserRole";

interface WithdrawalRequest {
  id: string;
  member_id: string;
  amount: number;
  status: string;
  requested_at: string;
  withdrawal_method?: string;
  withdrawal_type?: string;
  bank_account_info: string;
  notes?: string;
  rejection_reason?: string;
  members: {
    full_name: string;
  };
}

interface WithdrawalRequestsListProps {
  statusFilter?: "pending" | "approved" | "rejected" | "all";
}

export function WithdrawalRequestsList({ statusFilter = "pending" }: WithdrawalRequestsListProps) {
  const { toast } = useToast();
  const { isOwner, isAdmin } = useUserRole();
  const canApproveWithdrawal = isOwner || isAdmin;
  const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<WithdrawalRequest | null>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [notes, setNotes] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");

  useEffect(() => {
    loadRequests();

    // Subscribe to changes
    const channel = supabase
      .channel("withdrawal-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "member_balance_withdrawals" }, loadRequests)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadRequests = async () => {
    try {
      let query = (supabase as any)
        .from("member_balance_withdrawals")
        .select(`
          *,
          members(full_name)
        `)
        .order("requested_at", { ascending: false });

      // Apply status filter
      if (statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }

      const { data, error } = await query;

      if (error) throw error;
      setRequests(data || []);
    } catch (error: any) {
      console.error("Error loading requests:", error);
      toast({
        title: "Gagal Memuat Data",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!selectedRequest) return;

    setActionLoading(true);
    try {
      // CRITICAL: Call edge function to properly process the withdrawal
      // This will validate balance, create negative transaction, and update status
      const { data: result, error: processError } = await supabase.functions.invoke(
        'process-balance-withdrawal',
        {
          body: {
            withdrawal_id: selectedRequest.id,
            action: 'approve'
          }
        }
      );

      if (processError) throw processError;
      if (result && !result.success) {
        throw new Error(result.error || 'Gagal memproses penarikan');
      }

      // Update notes if provided (edge function doesn't handle notes)
      if (notes) {
        await (supabase as any)
          .from("member_balance_withdrawals")
          .update({ notes })
          .eq("id", selectedRequest.id);
      }

      // Send notification to member
      await (supabase as any)
        .from("member_messages")
        .insert({
          member_id: selectedRequest.member_id,
          title: "Penarikan Saldo Disetujui ✓",
          message: `Pengajuan penarikan saldo sebesar ${formatCurrency(selectedRequest.amount)} telah DISETUJUI. ${notes ? `Catatan: ${notes}` : "Silakan hubungi admin untuk proses pencairan."}`,
          type: "announcement",
        });

      toast({
        title: "Berhasil",
        description: "Pengajuan penarikan telah disetujui",
      });

      setShowApproveDialog(false);
      setNotes("");
      setSelectedRequest(null);
      loadRequests();
    } catch (error: any) {
      console.error("Error approving request:", error);
      toast({
        title: "Gagal",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!selectedRequest) return;

    if (!rejectionReason.trim()) {
      toast({
        title: "Alasan Diperlukan",
        description: "Masukkan alasan penolakan",
        variant: "destructive",
      });
      return;
    }

    setActionLoading(true);
    try {
      // Call edge function to properly handle rejection
      const { data: result, error: processError } = await supabase.functions.invoke(
        'process-balance-withdrawal',
        {
          body: {
            withdrawal_id: selectedRequest.id,
            action: 'reject',
            rejection_reason: rejectionReason
          }
        }
      );

      if (processError) throw processError;
      if (result && !result.success) {
        throw new Error(result.error || 'Gagal menolak penarikan');
      }

      // Send notification to member
      await (supabase as any)
        .from("member_messages")
        .insert({
          member_id: selectedRequest.member_id,
          title: "Penarikan Saldo Ditolak",
          message: `Pengajuan penarikan saldo sebesar ${formatCurrency(selectedRequest.amount)} telah DITOLAK. Alasan: ${rejectionReason}. Saldo Anda akan kembali tersedia.`,
          type: "reminder",
        });

      toast({
        title: "Berhasil",
        description: "Pengajuan penarikan telah ditolak",
      });

      setShowRejectDialog(false);
      setRejectionReason("");
      setSelectedRequest(null);
      loadRequests();
    } catch (error: any) {
      console.error("Error rejecting request:", error);
      toast({
        title: "Gagal",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setActionLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" />Menunggu</Badge>;
      case "approved":
        return <Badge className="gap-1 bg-green-600"><CheckCircle className="h-3 w-3" />Disetujui</Badge>;
      case "rejected":
        return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" />Ditolak</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getWithdrawalTypeBadge = (type?: string) => {
    if (type === "year_end_bonus") {
      return <Badge className="bg-amber-500 hover:bg-amber-600 text-white">Bonus Akhir Tahun</Badge>;
    }
    return <Badge variant="secondary">Saldo Reguler</Badge>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-muted-foreground">
          Belum ada pengajuan penarikan saldo
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {requests.map((request) => (
          <Card key={request.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  {(request.members as any)?.full_name || "Unknown"}
                </CardTitle>
                {getStatusBadge(request.status)}
              </div>
              <CardDescription>
                {format(new Date(request.requested_at), "dd MMMM yyyy, HH:mm", { locale: id })}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 flex-wrap">
                {getWithdrawalTypeBadge(request.withdrawal_type)}
              </div>

              <div>
                <p className="text-2xl font-bold text-primary">
                  {formatCurrency(request.amount)}
                </p>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Metode Penarikan:</p>
                <Badge variant="outline" className="mt-1">
                  {request.withdrawal_method === "cash" ? "Cash" : "Transfer Bank"}
                </Badge>
              </div>

              {request.withdrawal_method === "transfer" && request.bank_account_info && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Informasi Rekening:</p>
                  <p className="text-sm whitespace-pre-wrap">{request.bank_account_info}</p>
                </div>
              )}

              {request.notes && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Catatan:</p>
                  <p className="text-sm">{request.notes}</p>
                </div>
              )}

              {request.rejection_reason && (
                <div>
                  <p className="text-sm font-medium text-destructive">Alasan Penolakan:</p>
                  <p className="text-sm">{request.rejection_reason}</p>
                </div>
              )}

              {request.status === "pending" && canApproveWithdrawal && (
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setSelectedRequest(request);
                      setShowRejectDialog(true);
                    }}
                  >
                    <XCircle className="mr-2 h-4 w-4" />
                    Tolak
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={() => {
                      setSelectedRequest(request);
                      setShowApproveDialog(true);
                    }}
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Setujui
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Approve Dialog */}
      <AlertDialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Setujui Penarikan Saldo</AlertDialogTitle>
            <AlertDialogDescription>
              Anda akan menyetujui penarikan saldo sebesar{" "}
              {selectedRequest && formatCurrency(selectedRequest.amount)} untuk{" "}
              {selectedRequest && (selectedRequest.members as any)?.full_name}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <Label>Catatan (Opsional)</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Tambahkan catatan jika diperlukan"
              rows={3}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleApprove} disabled={actionLoading}>
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Setujui
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reject Dialog */}
      <AlertDialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Tolak Penarikan Saldo</AlertDialogTitle>
            <AlertDialogDescription>
              Anda akan menolak penarikan saldo untuk{" "}
              {selectedRequest && (selectedRequest.members as any)?.full_name}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <Label>Alasan Penolakan *</Label>
            <Textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Masukkan alasan penolakan"
              rows={3}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleReject} disabled={actionLoading}>
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Tolak
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
