import { useSwipeSidebar } from "@/hooks/use-swipe-sidebar";

export function SwipeHandler() {
  useSwipeSidebar({
    threshold: 50,    // Jarak minimum swipe (lebih kecil = lebih responsif)
    edgeWidth: 80,    // Lebar area dari edge kiri untuk trigger (lebih besar = lebih mudah)
  });

  return null;
}
