import { useState } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/date-picker";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { formatDate, sanitizeDateForDatabase, getTodayInWIB } from "@/lib/utils";
import { Loader2, Shield, AlertCircle } from "lucide-react";
import { logSystemEvent } from "@/lib/systemLogger";
import { parse, format } from "date-fns";
import { CurrencyInput } from "@/components/ui/currency-input";
import { useInvalidateInstallments } from "@/hooks/useInstallmentsQuery";
import { useInvalidatePayments } from "@/hooks/usePaymentsQuery";
import { validatePaymentAmount, validatePaymentDate, validatePaymentForm } from "@/lib/paymentValidation";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface EditPaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  payment: any;
  onSuccess: () => void;
}

export function EditPaymentDialog({
  open,
  onOpenChange,
  payment,
  onSuccess,
}: EditPaymentDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [superCode, setSuperCode] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const invalidateInstallments = useInvalidateInstallments();
  const invalidatePayments = useInvalidatePayments();
  
  // Form state - convert payment_date from YYYY-MM-DD to Date object
  const [paymentDate, setPaymentDate] = useState<Date | undefined>(
    payment?.payment_date ? parse(payment.payment_date, "yyyy-MM-dd", new Date()) : undefined
  );
  const [amount, setAmount] = useState(payment?.amount?.toString() || "");
  const [paymentMethod, setPaymentMethod] = useState(payment?.payment_method || "");
  const [referenceNumber, setReferenceNumber] = useState(payment?.reference_number || "");
  const [notes, setNotes] = useState(payment?.notes || "");
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset validation errors
    setValidationErrors([]);
    
    // Comprehensive input validation using Zod
    const errors: string[] = [];
    
    // Validate payment date
    const dateError = validatePaymentDate(paymentDate);
    if (dateError) {
      errors.push(dateError);
    }
    
    // Validate payment amount
    const amountError = validatePaymentAmount(amount);
    if (amountError) {
      errors.push(amountError);
    }
    
    // Validate payment method
    if (!paymentMethod) {
      errors.push("Metode pembayaran harus dipilih");
    }
    
    // Validate reference number length
    if (referenceNumber && referenceNumber.length > 100) {
      errors.push("Nomor referensi maksimal 100 karakter");
    }
    
    // Validate notes length
    if (notes && notes.length > 500) {
      errors.push("Catatan maksimal 500 karakter");
    }
    
    // Validate SuperCode
    if (!superCode.trim()) {
      errors.push("SuperCode harus diisi untuk verifikasi");
    }
    
    // Display validation errors
    if (errors.length > 0) {
      setValidationErrors(errors);
      toast({
        title: "Data tidak valid",
        description: errors[0],
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Verify SuperCode
      const { data: verifyData, error: verifyError } = await supabase.functions.invoke(
        "verify-supercode",
        {
          body: { superCodeInput: superCode },
        }
      );

      if (verifyError || !verifyData?.valid) {
        toast({
          title: "SuperCode Salah",
          description: "SuperCode yang Anda masukkan tidak valid",
          variant: "destructive",
        });
        return;
      }

      // Get installment and application data
      const { data: installmentData } = await supabase
        .from("installments")
        .select("*, credit_applications(customers(full_name))")
        .eq("id", payment.installment_id)
        .single();

      if (!installmentData) {
        throw new Error("Data angsuran tidak ditemukan");
      }

      const dueDate = new Date(installmentData.due_date);
      const newPaymentDate = paymentDate;
      
      // Get penalty rate from settings
      const { data: settings } = await supabase
        .from("app_settings")
        .select("penalty_rate_per_day")
        .single();
      
      const penaltyRate = settings?.penalty_rate_per_day || 2.0;
      
      // Get all payments for this installment to recalculate
      const { data: allPayments } = await supabase
        .from("payments")
        .select("id, amount")
        .eq("installment_id", payment.installment_id);

      // Calculate total payment sum from all payments (including edited one)
      const otherPaymentsSum = allPayments
        ?.filter(p => p.id !== payment.id)
        .reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const totalPaymentSum = otherPaymentsSum + Number(amount);
      
      // Calculate penalty based on payment date
      const daysOverdue = Math.max(0, Math.floor((newPaymentDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
      const calculatedPenalty = daysOverdue > 0 
        ? Math.ceil((Number(installmentData.total_amount) * (penaltyRate / 100) * daysOverdue) / 1000) * 1000
        : 0;
      
      // CRITICAL FIX: Allocate payment ONLY to principal, never auto-reduce frozen penalty
      // Penalty must be paid manually via dedicated "Pay Penalty" button
      const totalAmount = Number(installmentData.total_amount);
      const newPaidAmount = Math.min(totalPaymentSum, totalAmount); // paid_amount never exceeds total_amount
      const principalFullyPaid = newPaidAmount >= totalAmount;
      
      // Frozen penalty = calculated penalty if principal is paid, 0 otherwise
      const newFrozenPenalty = principalFullyPaid ? calculatedPenalty : 0;

      console.log('💰 Edit Payment Debug:', {
        currentPaymentId: payment.id,
        allPaymentsCount: allPayments?.length || 0,
        otherPaymentsSum,
        newAmount: Number(amount),
        totalPaymentSum,
        totalAmount,
        calculatedPenalty,
        newPaidAmount,
        principalFullyPaid,
        newFrozenPenalty,
        daysOverdue,
        note: 'Penalty tidak auto-terbayar, harus bayar manual'
      });

      // Validate and convert Date to YYYY-MM-DD format for database
      const formattedPaymentDate = sanitizeDateForDatabase(paymentDate);
      
      if (!formattedPaymentDate) {
        toast({
          title: "Error",
          description: "Format tanggal pembayaran tidak valid",
          variant: "destructive",
        });
        return;
      }

      console.log('📝 Updating payment:', {
        paymentId: payment.id,
        oldDate: payment.payment_date,
        newDate: formattedPaymentDate,
        oldAmount: payment.amount,
        newAmount: Number(amount)
      });

      // Update payment record
      const { error: updateError } = await supabase
        .from("payments")
        .update({
          payment_date: formattedPaymentDate,
          amount: Number(amount),
          payment_method: paymentMethod,
          reference_number: referenceNumber,
          notes: notes,
        })
        .eq("id", payment.id);

      if (updateError) {
        console.error('❌ Update payment error:', updateError);
        throw updateError;
      }

      console.log('✅ Payment updated successfully');

      // CRITICAL: Status 'paid' ONLY if principal fully paid AND no frozen penalty
      // This is now enforced by database trigger as well
      const newStatus = principalFullyPaid && newFrozenPenalty === 0 ? "paid" : "partial";

      // Get earliest payment date from all payments for this installment
      // This ensures paid_at reflects the actual first payment date for credit score calculation
      const { data: allPaymentsForPaidAt } = await supabase
        .from("payments")
        .select("payment_date")
        .eq("installment_id", payment.installment_id)
        .order("payment_date", { ascending: true });
      
      // Use earliest payment date as paid_at if there are any payments
      const earliestPaymentDate = allPaymentsForPaidAt && allPaymentsForPaidAt.length > 0 
        ? allPaymentsForPaidAt[0].payment_date 
        : formattedPaymentDate;

      console.log('📊 Updating installment:', {
        installmentId: payment.installment_id,
        newFrozenPenalty,
        newPaidAmount,
        totalAmount,
        newStatus,
        earliestPaymentDate,
        allPaymentsCount: allPaymentsForPaidAt?.length || 0,
        principalFullyPaid
      });

      const { error: installmentError } = await supabase
        .from("installments")
        .update({
          frozen_penalty: newFrozenPenalty,
          paid_amount: newPaidAmount, // CRITICAL: Only principal amount, never exceeds total_amount
          principal_paid: principalFullyPaid,
          frozen_days_overdue: newFrozenPenalty > 0 ? daysOverdue : 0,
          status: newStatus,
          // CRITICAL FIX: Use earliest payment_date as paid_at for accurate late payment calculation
          // This affects credit score calculation based on paid_at vs due_date comparison
          paid_at: newPaidAmount > 0 ? earliestPaymentDate : null,
        })
        .eq("id", payment.installment_id);

      if (installmentError) {
        console.error('❌ Update installment error:', installmentError);
        throw installmentError;
      }

      console.log('✅ Installment updated successfully');

      // Log system event
      const creditApp: any = (installmentData as any).credit_applications;
      const customerName = Array.isArray(creditApp)
        ? creditApp[0]?.customers?.full_name
        : creditApp?.customers?.full_name;

      await logSystemEvent({
        category: "payment",
        action: "edit_payment",
        description: `Mengubah data pembayaran untuk ${customerName || "-"}`,
        metadata: {
          payment_id: payment.id,
          installment_id: payment.installment_id,
          old_date: payment.payment_date,
          new_date: formattedPaymentDate,
          old_amount: payment.amount,
          new_amount: amount,
          old_penalty: installmentData.frozen_penalty,
          new_penalty: newFrozenPenalty,
          paid_amount: newPaidAmount,
          principal_fully_paid: principalFullyPaid,
        },
      });

      toast({
        title: "Berhasil",
        description: "Data pembayaran berhasil diubah",
      });

      // Invalidate queries to refresh data immediately
      invalidateInstallments();
      invalidatePayments();

      onSuccess();
      onOpenChange(false);
      setSuperCode("");
      setShowVerification(false);
    } catch (error: any) {
      console.error("Error editing payment:", error);
      toast({
        title: "Error",
        description: error.message || "Gagal mengubah data pembayaran",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setSuperCode("");
      setShowVerification(false);
    }
    onOpenChange(open);
  };

  if (!payment) return null;

  return (
    <ResponsiveDialog open={open} onOpenChange={handleOpenChange}>
      <ResponsiveDialogContent className="max-w-md w-full max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>Edit Pembayaran</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto px-1">
          {validationErrors.length > 0 && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <ul className="list-disc list-inside space-y-1">
                  {validationErrors.map((error, index) => (
                    <li key={index} className="text-sm">{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="payment_date">Tanggal Pembayaran</Label>
            <DatePicker
              value={paymentDate}
              onChange={setPaymentDate}
              placeholder="dd/MM/yyyy"
              maxDate={getTodayInWIB()}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Jumlah Bayar (Rp)</Label>
            <CurrencyInput
              id="amount"
              value={amount}
              onChange={(value) => setAmount(value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="payment_method">Metode Pembayaran</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih metode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Cash">Cash</SelectItem>
                <SelectItem value="Transfer">Transfer</SelectItem>
                <SelectItem value="E-Wallet">E-Wallet</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reference_number">No. Referensi (Opsional)</Label>
            <Input
              id="reference_number"
              value={referenceNumber}
              onChange={(e) => setReferenceNumber(e.target.value)}
              placeholder="No. referensi transaksi"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan (Opsional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Catatan tambahan"
              rows={3}
            />
          </div>

          {!showVerification ? (
            <Button
              type="button"
              onClick={() => setShowVerification(true)}
              className="w-full"
            >
              Lanjutkan
            </Button>
          ) : (
            <>
              <div className="space-y-2 p-4 border rounded-lg bg-muted/30">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Shield className="h-4 w-4 text-primary" />
                  Verifikasi SuperCode
                </div>
                <Input
                  type="password"
                  placeholder="Masukkan SuperCode"
                  value={superCode}
                  onChange={(e) => setSuperCode(e.target.value)}
                  required
                />
              </div>

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowVerification(false)}
                  className="flex-1"
                  disabled={loading}
                >
                  Kembali
                </Button>
                <Button type="submit" disabled={loading} className="flex-1">
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Menyimpan...
                    </>
                  ) : (
                    "Simpan Perubahan"
                  )}
                </Button>
              </div>
            </>
          )}
        </form>
      </ResponsiveDialogContent>
    </ResponsiveDialog>
  );
}
