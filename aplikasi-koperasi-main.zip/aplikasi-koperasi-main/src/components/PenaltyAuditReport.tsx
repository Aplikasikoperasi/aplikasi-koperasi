import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertCircle, TrendingUp, Users } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface AuditResult {
  beforeFix: {
    affectedCustomers: string;
    incorrectInstallments: string;
    totalIncorrectPenalty: string;
  };
  afterFix: {
    affectedCustomers: string;
    incorrectInstallments: string;
    totalIncorrectPenalty: string;
  };
  summary: {
    totalPaid: number;
    onTime: number;
    late: number;
    errors: number;
  };
  verifiedCases: Array<{
    fullName: string;
    idNumber: string;
    applicationNumber: string;
    installmentNumber: number;
    dueDate: string;
    paymentDate: string;
    frozenPenalty: number;
    verificationStatus: string;
  }>;
}

interface PenaltyAuditReportProps {
  auditData: AuditResult;
}

export function PenaltyAuditReport({ auditData }: PenaltyAuditReportProps) {
  const onTimePercentage = auditData.summary.totalPaid > 0 
    ? ((auditData.summary.onTime / auditData.summary.totalPaid) * 100).toFixed(1)
    : "0";
  
  const latePercentage = auditData.summary.totalPaid > 0
    ? ((auditData.summary.late / auditData.summary.totalPaid) * 100).toFixed(1)
    : "0";

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">Laporan Audit Perhitungan Denda</CardTitle>
              <CardDescription className="mt-2">
                Verifikasi menyeluruh sistem perhitungan denda untuk memastikan akurasi data
              </CardDescription>
            </div>
            <Badge variant="default" className="h-8 px-4">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Audit Selesai
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Comparison: Before vs After */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Before Fix */}
        <Card className="border-destructive/50 bg-destructive/5">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              Sebelum Perbaikan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Customer Terpengaruh</p>
              <p className="text-2xl font-bold text-destructive">
                {auditData.beforeFix.affectedCustomers}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Angsuran Salah Hitung</p>
              <p className="text-2xl font-bold text-destructive">
                {auditData.beforeFix.incorrectInstallments}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Denda Salah</p>
              <p className="text-2xl font-bold text-destructive">
                {auditData.beforeFix.totalIncorrectPenalty}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* After Fix */}
        <Card className="border-green-500/50 bg-green-500/5">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Sesudah Perbaikan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Customer Terverifikasi</p>
              <p className="text-2xl font-bold text-green-600">
                {auditData.afterFix.affectedCustomers}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Angsuran Salah Hitung</p>
              <p className="text-2xl font-bold text-green-600">
                {auditData.afterFix.incorrectInstallments}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Denda Salah</p>
              <p className="text-2xl font-bold text-green-600">
                {auditData.afterFix.totalIncorrectPenalty}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Statistik Keseluruhan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Total Angsuran Lunas</p>
              <p className="text-3xl font-bold">{auditData.summary.totalPaid}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Tepat Waktu</p>
              <p className="text-3xl font-bold text-green-600">{auditData.summary.onTime}</p>
              <Badge variant="secondary" className="mt-2">{onTimePercentage}%</Badge>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Telat (Ada Denda)</p>
              <p className="text-3xl font-bold text-orange-600">{auditData.summary.late}</p>
              <Badge variant="secondary" className="mt-2">{latePercentage}%</Badge>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Kesalahan Ditemukan</p>
              <p className="text-3xl font-bold text-red-600">{auditData.summary.errors}</p>
              {auditData.summary.errors === 0 && (
                <Badge variant="default" className="mt-2">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  100% Akurat
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Verified Cases Detail */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Detail Verifikasi Customer
          </CardTitle>
          <CardDescription>
            Customer yang telah diverifikasi dan dipastikan perhitungan dendanya sudah benar
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Group by customer */}
            {Object.entries(
              auditData.verifiedCases.reduce((acc, item) => {
                if (!acc[item.fullName]) {
                  acc[item.fullName] = [];
                }
                acc[item.fullName].push(item);
                return acc;
              }, {} as Record<string, typeof auditData.verifiedCases>)
            ).map(([customerName, cases], idx) => (
              <div key={idx}>
                {idx > 0 && <Separator className="my-4" />}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-lg">{customerName}</h4>
                      <p className="text-sm text-muted-foreground">
                        {cases[0].idNumber} • {cases.length} angsuran terverifikasi
                      </p>
                    </div>
                    <Badge variant="default">
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      Verified
                    </Badge>
                  </div>
                  
                  <div className="ml-4 space-y-2">
                    {cases.map((item, caseIdx) => (
                      <div 
                        key={caseIdx}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/50 text-sm"
                      >
                        <div className="flex-1">
                          <p className="font-medium">
                            {item.applicationNumber} - Angsuran #{item.installmentNumber}
                          </p>
                          <p className="text-muted-foreground">
                            Jatuh Tempo: {new Date(item.dueDate).toLocaleDateString('id-ID')} • 
                            Dibayar: {new Date(item.paymentDate).toLocaleDateString('id-ID')}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge 
                            variant={item.verificationStatus.includes('TEPAT WAKTU') ? 'default' : 'secondary'}
                            className="whitespace-nowrap"
                          >
                            {item.verificationStatus}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Conclusion */}
      <Card className="border-green-500 bg-green-500/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="rounded-full bg-green-100 dark:bg-green-900/30 p-3">
              <CheckCircle2 className="h-6 w-6 text-green-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2">✅ Audit Selesai - Sistem Bersih 100%</h3>
              <p className="text-muted-foreground mb-4">
                Semua data telah diperbaiki dan diverifikasi. Sistem perhitungan denda sekarang:
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Denda hanya dihitung berdasarkan <strong>Tanggal Bayar vs Tanggal Jatuh Tempo</strong></span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Tanggal Dicatat (created_at) tidak digunakan untuk perhitungan</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Trigger otomatis mencegah kesalahan di masa depan</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Data historis telah disinkronkan dan diperbaiki</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
