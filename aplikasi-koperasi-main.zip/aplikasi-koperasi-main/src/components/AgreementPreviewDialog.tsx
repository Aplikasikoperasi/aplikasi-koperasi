import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, MessageSquare, Printer } from "lucide-react";
import { generateAgreementPDF } from "@/lib/generateAgreementPDF";
import { generateTemplateContent, AgreementData } from "@/lib/agreementTemplate";

interface AgreementPreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  agreementData: AgreementData;
  onDownload: () => void;
  onSendWhatsApp: () => void;
}

export function AgreementPreviewDialog({
  open,
  onOpenChange,
  agreementData,
  onDownload,
  onSendWhatsApp,
}: AgreementPreviewDialogProps) {
  // Use centralized template
  const template = generateTemplateContent(agreementData);

  return (
    <>
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #agreement-content, #agreement-content * { visibility: visible; }
          #agreement-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 0;
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            font-size: 12pt;
            line-height: 1.5;
            color: black;
            background: white;
          }
          @page { size: A4; margin: 2.54cm; }
        }
      `}</style>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Preview Surat Perjanjian Penitipan Modal</DialogTitle>
          </DialogHeader>
          
          <ScrollArea className="h-[60vh] pr-4">
            <div id="agreement-content" className="space-y-4 text-sm">
              {/* Title */}
              <h1 className="text-xl font-bold text-center mb-4">
                {template.title}
              </h1>

              {/* Opening */}
              <p className="mb-4">{template.opening}</p>

              {/* PIHAK PERTAMA */}
              <div className="mb-4">
                {template.customerPhotoUrl ? (
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <img 
                        src={template.customerPhotoUrl} 
                        alt="Foto Nasabah"
                        className="w-20 h-24 object-cover border"
                      />
                    </div>
                    <div className="flex-1 space-y-0">
                      {template.customerInfo.map((info, idx) => (
                        <p key={idx}>{info.label}: {info.value}</p>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-0">
                    {template.customerInfo.map((info, idx) => (
                      <p key={idx}>{info.label}: {info.value}</p>
                    ))}
                  </div>
                )}
                <p className="mt-2">{template.pihakPertamaClosing}</p>
              </div>

              {/* PIHAK KEDUA */}
              <div className="space-y-0 mb-4">
                {template.ownerInfo.map((info, idx) => (
                  <p key={idx}>{info.label}: {info.value}</p>
                ))}
                <p className="mt-2">{template.pihakKeduaClosing}</p>
              </div>

              {/* Agreement Points */}
              <div className="space-y-2">
                {template.agreementPoints.map((point, idx) => (
                  <p key={idx}>{point}</p>
                ))}
              </div>

              {/* Pasals - read keepTogether from template */}
              {template.pasals.map((pasal) => (
                <div 
                  key={pasal.number} 
                  className="space-y-1" 
                  style={pasal.keepTogether ? { pageBreakInside: 'avoid', breakInside: 'avoid' } : undefined}
                >
                  <h3 className="text-center font-bold">Pasal {pasal.number}</h3>
                  <h3 className="text-center font-bold">{pasal.title}</h3>
                  {pasal.intro && <p>{pasal.intro}</p>}
                  {pasal.points && pasal.points.map((point, idx) => (
                    <p key={idx}>{point}</p>
                  ))}
                  {pasal.content && <p className="text-justify">{pasal.content}</p>}
                </div>
              ))}

              {/* Agreement Date */}
              <p className="mt-4">{template.agreementDate}</p>

              {/* Signature Section */}
              <div className="pt-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  {template.signatures.map((sig, idx) => (
                    <div key={idx}>
                      <p className="font-semibold">{sig.role}</p>
                      <div className="h-20"></div>
                      <p className="text-xs text-muted-foreground mb-1">{sig.label}</p>
                      <p>({sig.name})</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollArea>

          <DialogFooter className="flex-row gap-2 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Tutup
            </Button>
            <Button 
              variant="outline" 
              className="bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
              onClick={async () => {
                await generateAgreementPDF(agreementData, 'print');
              }}
            >
              <Printer className="h-4 w-4 mr-2" />
              Cetak PDF
            </Button>
            <Button 
              onClick={onSendWhatsApp}
              className="bg-[#25D366] hover:bg-[#128C7E] text-white"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Kirim via WhatsApp
            </Button>
            <Button onClick={onDownload}>
              <Download className="h-4 w-4 mr-2" />
              Download Word
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
