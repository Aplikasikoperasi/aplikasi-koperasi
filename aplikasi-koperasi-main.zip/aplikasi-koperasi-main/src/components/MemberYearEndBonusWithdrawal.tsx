import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Gift, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
const yearEndBonusWithdrawalSchema = z.object({
  amount: z.number().positive({
    message: "Jumlah harus lebih dari 0"
  }).max(999999999, {
    message: "Jumlah terlalu besar"
  }),
  withdrawalMethod: z.enum(["cash", "transfer"], {
    errorMap: () => ({
      message: "Metode penarikan tidak valid"
    })
  }),
  bankInfo: z.string().max(500, {
    message: "Informasi bank terlalu panjang (maks 500 karakter)"
  }).optional()
});
interface MemberYearEndBonusWithdrawalProps {
  memberId: string;
  currentBalance: number;
  onSuccess: () => void;
}
export function MemberYearEndBonusWithdrawal({
  memberId,
  currentBalance,
  onSuccess
}: MemberYearEndBonusWithdrawalProps) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [withdrawalMethod, setWithdrawalMethod] = useState("cash");
  const [bankInfo, setBankInfo] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [yearEndBonusWithdrawalDate, setYearEndBonusWithdrawalDate] = useState<number>(7);
  const [hasWithdrawnThisYear, setHasWithdrawnThisYear] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const {
    toast
  } = useToast();
  const now = new Date();
  const currentMonth = now.getMonth() + 1; // JavaScript months are 0-indexed
  const currentYear = now.getFullYear();
  const currentDate = now.getDate();

  // Load year-end bonus withdrawal date from settings and check existing withdrawals
  useEffect(() => {
    const loadBonusSettings = async () => {
      setIsLoading(true);
      try {
        // Get member position to determine if kasir
        const {
          data: {
            user
          }
        } = await supabase.auth.getUser();
        if (!user) return;
        const {
          data: member
        } = await supabase.from("members").select("position").eq("user_id", user.id).single();
        const isKasir = member?.position?.toLowerCase() === 'kasir';
        const {
          data
        } = await (supabase as any).from("incentive_settings").select("year_end_bonus_withdrawal_date, kasir_year_end_bonus_withdrawal_date").single();
        if (data) {
          const withdrawalDate = isKasir ? data.kasir_year_end_bonus_withdrawal_date : data.year_end_bonus_withdrawal_date;
          if (withdrawalDate) {
            setYearEndBonusWithdrawalDate(withdrawalDate);
          }
        }

        // Check if member has already withdrawn this year (pending or approved)
        const { data: existingWithdrawals } = await (supabase as any)
          .from("member_balance_withdrawals")
          .select("id, status")
          .eq("member_id", memberId)
          .eq("withdrawal_type", "year_end_bonus")
          .eq("bonus_year", currentYear)
          .in("status", ["pending", "approved"]);

        setHasWithdrawnThisYear(existingWithdrawals && existingWithdrawals.length > 0);
      } finally {
        setIsLoading(false);
      }
    };
    loadBonusSettings();

    // Subscribe to realtime changes for settings
    const settingsChannel = supabase.channel("year-end-bonus-settings").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "incentive_settings"
    }, async (payload: any) => {
      // Re-check member position on settings change
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) return;
      const {
        data: member
      } = await supabase.from("members").select("position").eq("user_id", user.id).single();
      const isKasir = member?.position?.toLowerCase() === 'kasir';
      const withdrawalDate = isKasir ? payload.new?.kasir_year_end_bonus_withdrawal_date : payload.new?.year_end_bonus_withdrawal_date;
      if (withdrawalDate) {
        setYearEndBonusWithdrawalDate(withdrawalDate);
      }
    }).subscribe();

    // Subscribe to realtime changes for withdrawals
    const withdrawalsChannel = supabase.channel(`year-end-withdrawals-${memberId}`).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "member_balance_withdrawals",
      filter: `member_id=eq.${memberId}`
    }, async () => {
      // Re-check existing withdrawals
      const { data: existingWithdrawals } = await (supabase as any)
        .from("member_balance_withdrawals")
        .select("id, status")
        .eq("member_id", memberId)
        .eq("withdrawal_type", "year_end_bonus")
        .eq("bonus_year", currentYear)
        .in("status", ["pending", "approved"]);

      setHasWithdrawnThisYear(existingWithdrawals && existingWithdrawals.length > 0);
    }).subscribe();

    return () => {
      supabase.removeChannel(settingsChannel);
      supabase.removeChannel(withdrawalsChannel);
    };
  }, [memberId, currentYear]);

  // Only show in December on or after the configured date
  // Button will automatically reappear in December of next year even if previous year's bonus wasn't withdrawn
  // The balance accumulates year over year
  if (currentMonth !== 12 || currentDate < yearEndBonusWithdrawalDate) {
    return null;
  }

  // Show loading state
  if (isLoading) {
    return null;
  }

  // If already withdrawn this year, show disabled button with message
  if (hasWithdrawnThisYear) {
    return (
      <Button 
        disabled 
        size="sm" 
        className="rounded border shadow-sm text-xs font-medium h-6 px-2 text-center bg-gray-400 text-gray-200 cursor-not-allowed"
        title="Anda sudah melakukan penarikan tahun ini"
      >
        Sudah Ditarik
      </Button>
    );
  }

  // Only show withdrawal button if there's year-end bonus balance available
  if (currentBalance <= 0) {
    return null;
  }
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0
    }).format(value);
  };

  const formatNumber = (value: string) => {
    const numericValue = value.replace(/\D/g, '');
    if (!numericValue) return '';
    return new Intl.NumberFormat('id-ID').format(parseInt(numericValue));
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/\D/g, '');
    setAmount(rawValue);
  };
  const handleSubmit = async () => {
    const withdrawalAmount = parseFloat(amount);

    // Validate input with zod
    const validation = yearEndBonusWithdrawalSchema.safeParse({
      amount: withdrawalAmount,
      withdrawalMethod,
      bankInfo: bankInfo.trim()
    });
    if (!validation.success) {
      toast({
        title: "Validasi Gagal",
        description: validation.error.errors[0].message,
        variant: "destructive"
      });
      return;
    }
    if (withdrawalMethod === "transfer" && !bankInfo.trim()) {
      toast({
        title: "Error",
        description: "Mohon lengkapi informasi rekening bank",
        variant: "destructive"
      });
      return;
    }
    setIsSubmitting(true);
    try {
      // Use the currentBalance prop which is already validated and passed from parent
      const actualYearEndBonusBalance = currentBalance;

      // CRITICAL: Strict validation - cannot exceed actual year-end bonus balance
      if (withdrawalAmount > actualYearEndBonusBalance) {
        toast({
          title: "Saldo Bonus Akhir Tahun Tidak Mencukupi",
          description: `Jumlah melebihi saldo Bonus Akhir Tahun tersedia. Maksimal: ${formatCurrency(actualYearEndBonusBalance)}`,
          variant: "destructive"
        });
        setIsSubmitting(false);
        return;
      }

      // Additional check: ensure year-end bonus balance is positive
      if (actualYearEndBonusBalance <= 0) {
        toast({
          title: "Tidak Ada Saldo Bonus Akhir Tahun",
          description: "Saldo Bonus Akhir Tahun saat ini: Rp 0",
          variant: "destructive"
        });
        setIsSubmitting(false);
        return;
      }
      // Check if already withdrawn year-end bonus this year
      // This check is year-specific, allowing new withdrawals in subsequent years
      // If bonus from previous years wasn't withdrawn, it accumulates and can be withdrawn in current year
      const {
        data: existingWithdrawals,
        error: checkError
      } = await (supabase as any).from("member_balance_withdrawals").select("id").eq("member_id", memberId).eq("withdrawal_type", "year_end_bonus").eq("bonus_year", currentYear).in("status", ["pending", "approved"]);
      if (checkError) throw checkError;
      if (existingWithdrawals && existingWithdrawals.length > 0) {
        toast({
          title: "Tidak Dapat Mengajukan",
          description: "Anda sudah mengajukan penarikan Bonus Akhir Tahun untuk tahun ini",
          variant: "destructive"
        });
        setIsSubmitting(false);
        return;
      }
      const {
        error
      } = await (supabase as any).from("member_balance_withdrawals").insert({
        member_id: memberId,
        amount: withdrawalAmount,
        withdrawal_type: "year_end_bonus",
        withdrawal_method: withdrawalMethod,
        bonus_year: currentYear,
        bank_account_info: withdrawalMethod === "transfer" ? bankInfo : null,
        status: "pending"
      });
      if (error) throw error;
      toast({
        title: "Berhasil",
        description: "Permintaan penarikan Bonus Akhir Tahun berhasil diajukan"
      });
      setOpen(false);
      setAmount("");
      setWithdrawalMethod("cash");
      setBankInfo("");
      onSuccess();
    } catch (error: any) {
      console.error("Error submitting year-end bonus withdrawal:", error);
      toast({
        title: "Error",
        description: error.message || "Gagal mengajukan penarikan Bonus Akhir Tahun",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  return <>
      <Button onClick={() => setOpen(true)} size="sm" className="rounded border shadow-sm hover:shadow transition-all text-xs font-medium h-6 px-2 text-center text-white bg-blue-700 hover:bg-blue-800">
        Penarikan
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajukan Penarikan Bonus Akhir Tahun</DialogTitle>
            <DialogDescription>
              Saldo Bonus Akhir Tahun tersedia: {formatCurrency(currentBalance)}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah Penarikan (Rp)</Label>
              <Input id="amount" type="text" inputMode="numeric" value={formatNumber(amount)} onChange={handleAmountChange} placeholder="0" disabled={isSubmitting} />
            </div>

            <div className="space-y-2">
              <Label>Metode Penarikan</Label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input type="radio" name="withdrawalMethod" value="cash" checked={withdrawalMethod === "cash"} onChange={e => setWithdrawalMethod(e.target.value)} disabled={isSubmitting} />
                  <span>Tunai</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="withdrawalMethod" value="transfer" checked={withdrawalMethod === "transfer"} onChange={e => setWithdrawalMethod(e.target.value)} disabled={isSubmitting} />
                  <span>Transfer Bank</span>
                </label>
              </div>
            </div>

            {withdrawalMethod === "transfer" && <div className="space-y-2">
                <Label htmlFor="bankInfo">Informasi Rekening Bank</Label>
                <Textarea id="bankInfo" value={bankInfo} onChange={e => setBankInfo(e.target.value)} placeholder="Contoh: BCA 1234567890 a/n John Doe" disabled={isSubmitting} />
              </div>}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={isSubmitting}>
              Batal
            </Button>
            <Button onClick={handleSubmit} disabled={isSubmitting} className="bg-amber-600 hover:bg-amber-700">
              {isSubmitting ? <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </> : "Ajukan Penarikan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>;
}