import { useState, useEffect } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatRupiah, formatDate, sanitizeDateForDatabase, getTodayInWIB } from "@/lib/utils";
import { DatePicker } from "@/components/ui/date-picker";
import { CurrencyInput } from "@/components/ui/currency-input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { SuccessCheckmark } from "@/components/ui/success-checkmark";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useInvalidateInstallments } from "@/hooks/useInstallmentsQuery";
import { useInvalidatePayments } from "@/hooks/usePaymentsQuery";

interface PenaltyPaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  installment: any;
  remainingPenalty: number;
  onSuccess: () => void;
}

export function PenaltyPaymentDialog({
  open,
  onOpenChange,
  installment,
  remainingPenalty,
  onSuccess,
}: PenaltyPaymentDialogProps) {
  const { toast } = useToast();
  const invalidateInstallments = useInvalidateInstallments();
  const invalidatePayments = useInvalidatePayments();
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [referenceNumber, setReferenceNumber] = useState("");
  const [paymentDate, setPaymentDate] = useState<Date | undefined>(new Date());
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressMessage, setProgressMessage] = useState("");
  const [progressValue, setProgressValue] = useState(0);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [successData, setSuccessData] = useState<any>(null);

  useEffect(() => {
    if (open) {
      // Set default payment amount to remaining penalty
      setPaymentAmount(remainingPenalty.toString());
    } else {
      resetForm();
    }
  }, [open, remainingPenalty]);

  const resetForm = () => {
    setPaymentAmount("");
    setPaymentMethod("cash");
    setReferenceNumber("");
    setPaymentDate(new Date());
    setPaymentSuccess(false);
    setSuccessData(null);
    setProgressMessage("");
    setProgressValue(0);
  };

  const handleSubmit = async () => {
    if (!paymentDate || !paymentAmount) {
      toast({
        title: "Error",
        description: "Mohon lengkapi semua field yang diperlukan",
        variant: "destructive",
      });
      return;
    }

    const amount = parseFloat(paymentAmount);
    if (amount <= 0) {
      toast({
        title: "Error",
        description: "Jumlah pembayaran harus lebih dari 0",
        variant: "destructive",
      });
      return;
    }

    if (amount > remainingPenalty) {
      toast({
        title: "Peringatan",
        description: `Jumlah pembayaran melebihi sisa denda (${formatRupiah(remainingPenalty)}). Pembayaran akan disesuaikan.`,
      });
    }

    setIsProcessing(true);
    setProgressMessage("Memproses pembayaran denda...");
    setProgressValue(30);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Get member_id from members table
      const { data: memberData } = await supabase
        .from('members')
        .select('id, full_name')
        .eq('user_id', user.id)
        .maybeSingle();

      const memberId = memberData?.id;
      const memberName = memberData?.full_name || "Unknown";

      // Call apply_payment_to_installment function
      const { data: applyResult, error: applyError } = await supabase.rpc(
        'apply_payment_to_installment',
        {
          p_installment_id: installment.id,
          p_amount: amount,
          p_payment_date: sanitizeDateForDatabase(paymentDate),
          p_payment_method: paymentMethod,
          p_reference: referenceNumber || `PENALTY-${Date.now()}`,
          p_notes: 'Pembayaran denda terpisah'
        }
      );

      if (applyError) throw applyError;

      // Data now auto-syncs via database triggers

      // Log system event
      await logSystemEvent({
        action: "bayar_denda",
        category: "payment",
        description: `Pembayaran denda sebesar ${formatRupiah(amount)} untuk angsuran #${installment.installment_number}`,
        metadata: {
          installment_id: installment.id,
          application_id: installment.application_id,
          customer_id: installment.credit_applications?.customer_id,
          amount,
          payment_date: sanitizeDateForDatabase(paymentDate),
          payment_method: paymentMethod,
          reference_number: referenceNumber,
          member_id: memberId,
        },
      });

      setSuccessData({
        amount,
        paymentDate,
        paymentMethod,
        referenceNumber,
        customerName: installment.credit_applications?.customers?.full_name,
        installmentNumber: installment.installment_number,
        tenorMonths: installment.credit_applications?.tenor_months,
      });
      setPaymentSuccess(true);

      // Invalidate queries to refresh data immediately
      invalidateInstallments();
      invalidatePayments();

      // Dispatch event to refresh data (legacy support)
      window.dispatchEvent(new CustomEvent('payments-updated'));
      window.dispatchEvent(new CustomEvent('installments-updated'));

      toast({
        title: "Berhasil",
        description: "Pembayaran denda berhasil dicatat",
      });

      onSuccess();
    } catch (error: any) {
      console.error('Error processing penalty payment:', error);
      toast({
        title: "Error",
        description: error.message || "Gagal memproses pembayaran denda",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setProgressMessage("");
      setProgressValue(0);
    }
  };

  if (!installment) return null;

  if (paymentSuccess && successData) {
    return (
      <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
        <ResponsiveDialogContent className="max-w-md">
          <ResponsiveDialogHeader>
            <ResponsiveDialogTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="h-5 w-5" />
              Pembayaran Denda Berhasil
            </ResponsiveDialogTitle>
          </ResponsiveDialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex flex-col items-center p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-900">
              <SuccessCheckmark 
                show={true} 
                message="Pembayaran denda berhasil dicatat!"
              />
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Nasabah:</span>
                <span className="font-medium">{successData.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Angsuran Ke:</span>
                <span className="font-medium">{successData.installmentNumber} / {successData.tenorMonths || "-"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tanggal Bayar:</span>
                <span className="font-medium">{formatDate(successData.paymentDate)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Metode:</span>
                <span className="font-medium">{successData.paymentMethod}</span>
              </div>
              {successData.referenceNumber && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">No. Referensi:</span>
                  <span className="font-medium">{successData.referenceNumber}</span>
                </div>
              )}
              <div className="flex justify-between border-t pt-2 mt-2">
                <span className="font-semibold">Denda Dibayar:</span>
                <span className="font-bold text-lg text-green-600">{formatRupiah(successData.amount)}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={() => {
                onOpenChange(false);
                resetForm();
              }}
              className="w-full"
            >
              Tutup
            </Button>
          </div>
        </ResponsiveDialogContent>
      </ResponsiveDialog>
    );
  }

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-md">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>Bayar Denda Terpisah</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="space-y-4 py-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Form ini khusus untuk membayar sisa denda angsuran yang sudah dibayar lunas pokok dan bunganya.
            </AlertDescription>
          </Alert>

          <div className="space-y-3 text-sm bg-muted/30 p-3 rounded-lg">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Nasabah:</span>
              <span className="font-medium">{installment.credit_applications?.customers?.full_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Angsuran Ke:</span>
              <span className="font-medium">{installment.installment_number} / {installment.credit_applications?.tenor_months || "-"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Sisa Denda:</span>
              <span className="font-bold text-destructive">{formatRupiah(remainingPenalty)}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="penalty-amount">Jumlah Bayar Denda *</Label>
              <CurrencyInput
                id="penalty-amount"
                value={paymentAmount}
                onChange={setPaymentAmount}
                placeholder="Masukkan jumlah pembayaran"
                disabled={isProcessing}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment-date">Tanggal Bayar *</Label>
              <DatePicker
                value={paymentDate}
                onChange={setPaymentDate}
                disabled={isProcessing ? () => true : undefined}
                maxDate={getTodayInWIB()}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment-method">Metode Pembayaran *</Label>
              <Select
                value={paymentMethod}
                onValueChange={setPaymentMethod}
                disabled={isProcessing}
              >
                <SelectTrigger id="payment-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="transfer">Transfer</SelectItem>
                  <SelectItem value="e-wallet">E-Wallet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reference">No. Referensi (Opsional)</Label>
              <Input
                id="reference"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="Nomor referensi pembayaran"
                disabled={isProcessing}
              />
            </div>
          </div>
        </div>

        {/* Inline Progress Indicator */}
        {isProcessing && progressMessage && (
          <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <span className="text-sm font-medium">{progressMessage}</span>
            </div>
            <Progress value={progressValue} className="h-2" />
            <p className="text-xs text-muted-foreground text-center">
              Mohon tunggu, jangan tutup form ini...
            </p>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isProcessing}
            className="w-full"
          >
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isProcessing || !paymentAmount || !paymentDate}
            className="w-full"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Memproses...
              </span>
            ) : "Bayar Denda"}
          </Button>
        </div>
      </ResponsiveDialogContent>
    </ResponsiveDialog>
  );
}
