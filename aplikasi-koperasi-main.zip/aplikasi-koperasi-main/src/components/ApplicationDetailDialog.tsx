import { useState, useEffect } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { formatDate, formatRupiah, cn } from "@/lib/utils";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { Button } from "@/components/ui/button";
import { useUserRole } from "@/hooks/useUserRole";
import { CheckCircle, XCircle, Download, MessageSquare, Pencil, Trash2, Crown, Shield, Briefcase, Wallet, EyeOff, Eye, FileText, Printer, AlertTriangle, Users } from "lucide-react";
import { generateNamePlatePDF, NamePlateData } from "@/lib/generateNamePlatePDF";
import { generateStatementPDF, StatementData } from "@/lib/generateStatementPDF";
import { generateAgreementPDF } from "@/lib/generateAgreementPDF";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { supabase } from "@/integrations/supabase/client";
import { LazyInstallmentHistoryDialog as InstallmentHistoryDialog } from "@/components/LazyDialogs";
import { StatementPreviewDialog } from "@/components/StatementPreviewDialog";
import { NamePlatePreviewDialog } from "@/components/NamePlatePreviewDialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface ApplicationDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  application: any;
  installments?: any[];
  canApprove?: boolean;
  onApprove?: (applicationId: string, amountRequested: number) => void;
  onReject?: (applicationId: string) => void;
  onDownloadAgreement?: (application: any) => void;
  onSendWhatsApp?: (application: any) => void;
  onEdit?: (application: any) => void;
  onDelete?: (application: any) => void;
}

export function ApplicationDetailDialog({
  open,
  onOpenChange,
  application,
  installments = [],
  canApprove = false,
  onApprove,
  onReject,
  onDownloadAgreement,
  onSendWhatsApp,
  onEdit,
  onDelete,
}: ApplicationDetailDialogProps) {
  const { isOwner, isAdmin, isSales, isKasir } = useUserRole();
  const canManage = isOwner || isAdmin;
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  const [showInstallmentHistory, setShowInstallmentHistory] = useState(false);
  const [showStatementPreview, setShowStatementPreview] = useState(false);
  const [showNamePlatePreview, setShowNamePlatePreview] = useState(false);
  const [silencingInstallments, setSilencingInstallments] = useState(false);
  const [familyCreditCheck, setFamilyCreditCheck] = useState<{
    can_apply: boolean;
    reason: string;
    family_credits: Array<{
      customer_id: string;
      customer_name: string;
      application_number: string;
      amount_approved: number;
      remaining_amount: number;
      status: string;
    }>;
  } | null>(null);
  const [loadingFamilyCheck, setLoadingFamilyCheck] = useState(false);
  const { businessName, logoUrl } = useBusinessInfo();
  
  // Load current member ID for sales users
  useEffect(() => {
    if (!isSales || !open) return;
    
    const loadMemberId = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: memberData } = await supabase
          .from("members")
          .select("id")
          .eq("user_id", user.id)
          .maybeSingle();
        setCurrentMemberId(memberData?.id || null);
      }
    };
    
    loadMemberId();
  }, [isSales, open]);
  
  // Check family credit eligibility for pending applications
  useEffect(() => {
    if (!open || !application?.customer_id || application?.status !== 'pending') {
      setFamilyCreditCheck(null);
      return;
    }
    
    const checkFamilyCredit = async () => {
      setLoadingFamilyCheck(true);
      try {
        const { data, error } = await supabase.rpc('can_family_apply_credit', {
          p_customer_id: application.customer_id
        });
        
        if (error) {
          console.error('Error checking family credit:', error);
          return;
        }
        
        setFamilyCreditCheck(data as any);
      } catch (error) {
        console.error('Error checking family credit:', error);
      } finally {
        setLoadingFamilyCheck(false);
      }
    };
    
    checkFamilyCredit();
  }, [open, application?.customer_id, application?.status]);
  
  if (!application) return null;

  const isPending = application.status === 'pending';
  const isApproved = application.status === 'approved';
  const isDisbursed = application.status === 'disbursed';
  const showApprovalActions = isPending && canApprove && onApprove && onReject;
  const showDocumentActions = (isApproved || isDisbursed) && (onDownloadAgreement || onSendWhatsApp);
  const showManagementActions = canManage && (onEdit || onDelete);
  
  // Calculate progress
  const appInstallments = installments.filter(i => i.application_id === application.id);
  const totalInstallments = appInstallments.length;
  const paidInstallments = appInstallments.filter(i => i.status === 'paid').length;
  const progressValue = totalInstallments > 0 ? (paidInstallments / totalInstallments) * 100 : 0;
  const showProgress = (isApproved || isDisbursed) && totalInstallments > 0;

  // Check if any installments are silenced
  const hasSilencedInstallments = appInstallments.some((i: any) => i.is_silenced);
  
  // Handle toggle silent for all installments
  const handleToggleSilent = async () => {
    if (!application?.id) return;
    
    setSilencingInstallments(true);
    try {
      const targetSilenceState = !hasSilencedInstallments;
      
      // Update all installments for this application
      const { error } = await supabase
        .from("installments")
        .update({ is_silenced: targetSilenceState })
        .eq("application_id", application.id);
      
      if (error) throw error;
      
      // Refresh data if needed by parent
      const message = targetSilenceState 
        ? "Angsuran berhasil di-silent. Tidak akan muncul di tabel kecuali dicari."
        : "Angsuran berhasil ditampilkan kembali.";
      
      // Reload to reflect changes
      window.location.reload();
    } catch (error) {
      console.error("Error toggling silent status:", error);
    } finally {
      setSilencingInstallments(false);
    }
  };

  const getStatusBadge = () => {
    switch (application.status) {
      case 'approved':
        return <Badge variant="default">Disetujui</Badge>;
      case 'pending':
        return <Badge variant="secondary">Menunggu</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Ditolak</Badge>;
      case 'disbursed':
        return <Badge className="bg-green-600">Dicairkan</Badge>;
      default:
        return <Badge variant="secondary">{application.status}</Badge>;
    }
  };

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-md w-full max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>Detail Pengajuan Kredit</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="w-full max-w-full space-y-4 overflow-hidden">
          {/* Customer Info */}
          <div className="flex items-start gap-4">
            <ClickableAvatar
              src={application.customers?.photo_url}
              alt={application.customers?.full_name}
              fallback={application.customers?.full_name?.substring(0, 2).toUpperCase()}
              className="h-16 w-16 sm:h-20 sm:w-20 flex-shrink-0"
              fallbackClassName="bg-primary/10 text-primary text-lg sm:text-xl"
            />
            <div className="flex-1 min-w-0 space-y-1">
              <h3 className="font-bold text-base sm:text-lg truncate">{application.customers?.full_name}</h3>
              <p className="text-xs sm:text-sm text-muted-foreground truncate font-bold">{application.customers?.id_number}</p>
              <div className="flex flex-wrap items-center gap-2">
                {getStatusBadge()}
                {hasSilencedInstallments && (
                  <div className="text-[11px] px-2 py-0.5 rounded border bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border-purple-300 dark:border-purple-700 inline-flex items-center gap-1">
                    <span>🔕</span>
                    <span>Silent</span>
                  </div>
                )}
              </div>
              {application.customers?.credit_score !== undefined && (
                <CreditScoreStars 
                  creditScore={application.customers.credit_score} 
                  restorationStatus={application.customers.restoration_status || 'never_restored'} 
                />
              )}
            </div>
          </div>

          <Separator />

          {/* Family Credit Warning - For pending applications */}
          {isPending && familyCreditCheck && !familyCreditCheck.can_apply && (
            <Alert variant="destructive" className="border-red-300 bg-red-50 dark:bg-red-950/30">
              <Users className="h-4 w-4" />
              <AlertTitle className="text-sm font-semibold">Peringatan Kredit Keluarga</AlertTitle>
              <AlertDescription className="text-xs space-y-2">
                <p>{familyCreditCheck.reason}</p>
                {familyCreditCheck.family_credits.length > 0 && (
                  <div className="mt-2 space-y-1">
                    <p className="font-medium">Kredit aktif dalam keluarga (No. KK sama):</p>
                    {familyCreditCheck.family_credits.map((fc, idx) => (
                      <div key={idx} className="p-2 bg-white dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                        <div className="flex justify-between items-start">
                          <span className="font-medium">{fc.customer_name}</span>
                          <Badge variant="outline" className="text-[10px]">{fc.application_number}</Badge>
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-1">
                          Sisa: {formatRupiah(fc.remaining_amount)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}

          {/* Progress Bar - Only for approved/disbursed applications */}
          {showProgress && (
            <div 
              className="space-y-2 p-3 bg-muted/30 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => setShowInstallmentHistory(true)}
            >
              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm font-medium text-muted-foreground">
                  Progress Pembayaran
                </span>
                <span className="text-xs sm:text-sm font-bold">
                  {paidInstallments}/{totalInstallments} Angsuran
                </span>
              </div>
              <Progress value={progressValue} className="h-2 w-full" />
              <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>{progressValue.toFixed(1)}% Selesai</span>
                <span>{totalInstallments - paidInstallments} Tersisa</span>
              </div>
              <p className="text-xs text-center text-primary font-medium mt-1">
                Klik untuk lihat riwayat lengkap
              </p>
            </div>
          )}

          {showProgress && <Separator />}

          {/* Application Details */}
          <div className="space-y-2 text-xs sm:text-sm">
            <DetailRow label="No. Aplikasi" value={application.application_number} />
            <DetailRow label="Tanggal Pengajuan" value={formatDate(application.application_date || application.created_at)} />
            <div className="flex justify-between gap-2 sm:gap-4">
              <span className="text-muted-foreground font-medium min-w-[100px] sm:min-w-[120px] text-xs sm:text-sm">Penanggung Jawab:</span>
              <div className="text-right flex-1 break-words text-xs sm:text-sm font-semibold flex items-center justify-end gap-2 flex-wrap">
                <span>{application.members?.full_name || "-"}</span>
                {application.members?.position && (
                  <Badge 
                    className={cn(
                      "text-xs font-semibold shadow-sm w-fit capitalize inline-flex items-center gap-1",
                      application.members.position.toLowerCase() === 'owner' && "bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 text-white border-purple-300 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]",
                      application.members.position.toLowerCase() === 'admin' && "bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-600 text-white border-blue-300 shadow-md animate-shimmer animate-glow bg-[length:200%_100%]",
                      application.members.position.toLowerCase() === 'sales' && "bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600 text-white border-orange-300 shadow-sm animate-shimmer bg-[length:200%_100%]",
                      application.members.position.toLowerCase() === 'kasir' && "bg-gradient-to-r from-teal-500 via-cyan-400 to-teal-600 text-white border-teal-300 shadow-sm animate-shimmer bg-[length:200%_100%]"
                    )}
                  >
                    {application.members.position.toLowerCase() === 'owner' && <Crown className="h-3 w-3" />}
                    {application.members.position.toLowerCase() === 'admin' && <Shield className="h-3 w-3" />}
                    {application.members.position.toLowerCase() === 'sales' && <Briefcase className="h-3 w-3" />}
                    {application.members.position.toLowerCase() === 'kasir' && <Wallet className="h-3 w-3" />}
                    {application.members.position}
                  </Badge>
                )}
              </div>
            </div>
            <DetailRow label="Jumlah Pengajuan" value={formatRupiah(application.amount_requested)} />
            
            {/* Rincian Dana Diterima */}
            {(isApproved || isDisbursed) && (
              (() => {
                const amountApproved = application.amount_approved || application.amount_requested;
                const adminFee = application.admin_fee_amount || 0;
                const interestRate = application.interest_rate || 0;
                const tenor = application.tenor_months || 1;
                const monthlyInstallment = Math.ceil(
                  ((amountApproved / tenor) + (amountApproved * (interestRate / 100))) / 1000
                ) * 1000;
                // BUSINESS RULE: Tenor < 4 bulan TIDAK dipotong angsuran pertama, meskipun setting 'paid_upfront'
                const firstInstallmentDeducted = tenor >= 4 && application.first_installment_type === 'paid_upfront';
                
                let netDisbursement = amountApproved - adminFee;
                if (firstInstallmentDeducted) {
                  netDisbursement = netDisbursement - monthlyInstallment;
                }
                
                const hasDeductions = adminFee > 0 || firstInstallmentDeducted;
                
                return (
                  <div className="mt-2 p-2 bg-muted/30 rounded-lg space-y-1">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">Rincian Dana Diterima:</p>
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Jumlah Disetujui</span>
                      <span className="font-medium">{formatRupiah(amountApproved)}</span>
                    </div>
                    {adminFee > 0 && (
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Biaya Admin</span>
                        <span className="font-medium text-red-600">- {formatRupiah(adminFee)}</span>
                      </div>
                    )}
                    {firstInstallmentDeducted && (
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Angsuran Pertama (Dipotong)</span>
                        <span className="font-medium text-red-600">- {formatRupiah(monthlyInstallment)}</span>
                      </div>
                    )}
                    {hasDeductions && <Separator className="my-1" />}
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold">Dana Diterima</span>
                      <span className="font-bold text-green-600">
                        {formatRupiah(netDisbursement)}
                      </span>
                    </div>
                  </div>
                );
              })()
            )}
            <DetailRow label="Tenor" value={`${application.tenor_months} bulan`} />
            <DetailRow 
              label="Nilai Angsuran" 
              value={formatRupiah(
                Math.ceil(
                  ((application.amount_approved || application.amount_requested) / application.tenor_months + 
                  (application.amount_approved || application.amount_requested) * (application.interest_rate / 100)) / 1000
                ) * 1000
              )} 
            />
            <DetailRow label="Bunga" value={`${application.interest_rate}% per bulan`} />
            <DetailRow label="Tujuan" value={application.purpose || "-"} />
            <DetailRow label="Jaminan" value={application.collateral_description || "-"} />
            {application.approved_at && (
              <DetailRow label="Tgl Disetujui" value={formatDate(application.approved_at)} />
            )}
            {application.approver && (
              <DetailRow 
                label="Disetujui Oleh" 
                value={`${application.approver.full_name} (${application.approver.position})`} 
              />
            )}
            {application.disbursed_at && (
              <DetailRow label="Tgl Dicairkan" value={formatDate(application.disbursed_at)} />
            )}
          </div>

          {/* Document actions for approved applications */}
          {showDocumentActions && !isKasir && (
            <div className="space-y-2 pt-2">
              <Separator />
              <div className="grid grid-cols-2 gap-2">
                {onDownloadAgreement && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full"
                    onClick={() => onDownloadAgreement(application)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Perjanjian
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200"
                  onClick={() => setShowStatementPreview(true)}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Pernyataan
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                  onClick={() => setShowNamePlatePreview(true)}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Name Plate
                </Button>
                {onSendWhatsApp && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                    onClick={() => onSendWhatsApp(application)}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Struk WA
                  </Button>
                )}
              </div>
            </div>
          )}

          {/* Edit Button for Sales - Only on pending applications they created */}
          {isSales && !canManage && isPending && application.member_id === currentMemberId && onEdit && (
            <div className="pt-2">
              <Separator />
              <div className="mt-4">
                <Button
                  variant="outline"
                  className="w-full justify-center"
                  onClick={() => {
                    onEdit(application);
                    onOpenChange(false);
                  }}
                >
                  <Pencil className="h-4 w-4 mr-2" />
                  Edit Pengajuan Kredit
                </Button>
              </div>
            </div>
          )}

          {/* Action buttons section - Responsive for all devices */}
          {(showApprovalActions || showManagementActions) && (
            <div className="sticky bottom-0 left-0 right-0 bg-background border-t pt-4 -mx-4 px-4 pb-safe mt-6 space-y-3">
              
              {/* Approval Actions - Pending Applications for Owner/Admin */}
              {showApprovalActions && (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Aksi Persetujuan</p>
                  
                  {/* Family credit warning in approval section */}
                  {familyCreditCheck && !familyCreditCheck.can_apply && (
                    <div className="p-2 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg mb-2">
                      <p className="text-xs text-red-700 dark:text-red-300 font-medium flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        Tidak dapat disetujui: Kredit keluarga aktif
                      </p>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      className="w-full border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800"
                      onClick={() => {
                        onReject(application.id);
                        onOpenChange(false);
                      }}
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Tolak
                    </Button>
                    <Button
                      className={cn(
                        "w-full",
                        familyCreditCheck && !familyCreditCheck.can_apply 
                          ? "bg-gray-400 hover:bg-gray-400 cursor-not-allowed" 
                          : "bg-green-600 hover:bg-green-700"
                      )}
                      onClick={() => {
                        if (familyCreditCheck && !familyCreditCheck.can_apply) {
                          return; // Block approval if family has active credit
                        }
                        onApprove(application.id, application.amount_requested);
                        onOpenChange(false);
                      }}
                      disabled={familyCreditCheck && !familyCreditCheck.can_apply}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Setujui
                    </Button>
                  </div>
                </div>
              )}

              {/* Management Actions - Owner/Admin */}
              {showManagementActions && (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Kelola Pengajuan</p>
                  
                  {/* Silent Toggle Button - Only for disbursed/approved applications */}
                  {(isApproved || isDisbursed) && (
                    <Button
                      variant={hasSilencedInstallments ? "default" : "outline"}
                      className="w-full justify-start"
                      onClick={handleToggleSilent}
                      disabled={silencingInstallments}
                    >
                      {hasSilencedInstallments ? (
                        <>
                          <Eye className="h-4 w-4 mr-2" />
                          Tampilkan Angsuran
                        </>
                      ) : (
                        <>
                          <EyeOff className="h-4 w-4 mr-2" />
                          Silent Angsuran
                        </>
                      )}
                    </Button>
                  )}
                  
                  {onEdit && (
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => {
                        onEdit(application);
                        onOpenChange(false);
                      }}
                    >
                      <Pencil className="h-4 w-4 mr-2" />
                      Modifikasi Pengajuan
                    </Button>
                  )}
                  
                  {onDelete && (
                    <Button
                      variant="destructive"
                      className="w-full justify-start"
                      onClick={() => {
                        onDelete(application);
                        onOpenChange(false);
                      }}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Hapus Pengajuan
                    </Button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </ResponsiveDialogContent>

      {/* Installment History Dialog */}
      <InstallmentHistoryDialog
        open={showInstallmentHistory}
        onOpenChange={setShowInstallmentHistory}
        installments={appInstallments}
        applicationNumber={application.application_number}
        customerName={application.customers?.full_name || ""}
        loanAmount={application.amount_approved || application.amount_requested}
        tenor={application.tenor_months}
        status={application.status}
      />

      {/* Statement Preview Dialog */}
      {(() => {
        const amountApproved = application.amount_approved || application.amount_requested;
        const interestRate = application.interest_rate || 0;
        const tenor = application.tenor_months || 1;
        const monthlyInstallment = Math.ceil(
          ((amountApproved / tenor) + (amountApproved * (interestRate / 100))) / 1000
        ) * 1000;

        const statementData: StatementData = {
          memberName: application.members?.full_name || '-',
          memberNik: application.members?.nik,
          memberAddress: application.members?.address,
          memberDateOfBirth: application.members?.date_of_birth,
          memberPhotoUrl: application.members?.photo_url,
          customerName: application.customers?.full_name || '-',
          customerNik: application.customers?.nik,
          customerAddress: application.customers?.address,
          customerDateOfBirth: application.customers?.date_of_birth,
          customerPhotoUrl: application.customers?.photo_url,
          customerPhone: application.customers?.phone,
          applicationNumber: application.application_number || '-',
          amount: amountApproved,
          tenor: tenor,
          interestRate: interestRate,
          monthlyInstallment: monthlyInstallment,
          applicationDate: new Date(application.application_date || application.created_at),
          collateralDescription: application.collateral_description || undefined,
        };

        return (
          <StatementPreviewDialog
            open={showStatementPreview}
            onOpenChange={setShowStatementPreview}
            statementData={statementData}
            onDownload={() => generateStatementPDF(statementData, 'download')}
            onPrint={() => generateStatementPDF(statementData, 'print')}
          />
        );
      })()}

      {/* Name Plate Preview Dialog */}
      <NamePlatePreviewDialog
        open={showNamePlatePreview}
        onOpenChange={setShowNamePlatePreview}
        namePlateData={{
          businessName: businessName || 'Sistem Kredit',
          logoUrl: logoUrl || undefined,
          customerName: application.customers?.full_name || '',
          customerId: application.customers?.id_number || '',
          customerPhotoUrl: application.customers?.photo_url || undefined,
          applicationNumber: application.application_number || '',
          applicationDate: application.application_date || undefined,
          loanAmount: application.amount_approved || application.amount_requested,
          tenorMonths: application.tenor_months,
          memberName: application.members?.full_name || '',
        }}
      />
    </ResponsiveDialog>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2 sm:gap-4">
      <span className="text-muted-foreground font-medium min-w-[100px] sm:min-w-[120px] text-xs sm:text-sm">{label}:</span>
      <span className="text-right flex-1 break-words text-xs sm:text-sm font-semibold">{value}</span>
    </div>
  );
}
