import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { SupercodeVerificationDialog } from "@/components/SupercodeVerificationDialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Upload, X, Save } from "lucide-react";
import { compressImage } from "@/lib/imageCompression";

interface Saver {
  id: string;
  saver_number: string;
  account_number: string;
  full_name: string;
  id_number: string;
  phone: string;
  address: string;
  date_of_birth: string | null;
  email: string | null;
  photo_url: string | null;
  status: string;
  created_at: string;
  balance: number | null;
  occupation: string | null;
  mother_maiden_name?: string | null;
}

// Validate date format dd/mm/yyyy
const validateDateFormat = (value: string) => {
  if (!value || value === "") return true; // Optional for edit
  const regex = /^\d{2}\/\d{2}\/\d{4}$/;
  if (!regex.test(value)) return false;
  
  const [day, month, year] = value.split('/').map(Number);
  if (year < 1900 || year > new Date().getFullYear()) return false;
  if (month < 1 || month > 12) return false;
  if (day < 1 || day > 31) return false;
  
  const date = new Date(year, month - 1, day);
  return date.getDate() === day && date.getMonth() === month - 1 && date.getFullYear() === year;
};

// Validate phone number format
const validatePhone = (value: string) => {
  if (!value) return false;
  const cleanPhone = value.replace(/\s/g, '');
  return /^(\+62|08)\d{8,}$/.test(cleanPhone);
};

const formSchema = z.object({
  full_name: z.string()
    .min(1, "Nama lengkap wajib diisi")
    .min(3, "Nama minimal 3 karakter")
    .max(100, "Nama maksimal 100 karakter"),
  id_number: z.string()
    .min(1, "NIK wajib diisi")
    .length(16, "NIK harus tepat 16 digit")
    .regex(/^\d+$/, "NIK hanya boleh berisi angka"),
  phone: z.string()
    .min(1, "Nomor telepon wajib diisi")
    .refine(validatePhone, "Format: 08xxx atau +62xxx, minimal 10 digit"),
  address: z.string()
    .min(1, "Alamat wajib diisi")
    .min(10, "Alamat minimal 10 karakter")
    .max(500, "Alamat maksimal 500 karakter"),
  date_of_birth: z.string()
    .refine(validateDateFormat, "Format: dd/mm/yyyy (contoh: 15/08/1990)")
    .optional()
    .or(z.literal("")),
  email: z.string()
    .email("Format email tidak valid")
    .optional()
    .or(z.literal("")),
  occupation: z.string()
    .max(100, "Pekerjaan maksimal 100 karakter")
    .optional()
    .or(z.literal("")),
  mother_maiden_name: z.string()
    .max(100, "Nama ibu kandung maksimal 100 karakter")
    .optional()
    .or(z.literal("")),
  status: z.enum(["active", "inactive"]),
});

type FormValues = z.infer<typeof formSchema>;

interface SaverEditDialogProps {
  saver: Saver | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export default function SaverEditDialog({
  saver,
  open,
  onOpenChange,
  onSuccess,
}: SaverEditDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [showSupercodeDialog, setShowSupercodeDialog] = useState(false);
  const [pendingFormValues, setPendingFormValues] = useState<FormValues | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  // Convert ISO date to dd/mm/yyyy format
  const formatDateToDisplay = (isoDate: string | null): string => {
    if (!isoDate) return "";
    const date = new Date(isoDate);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      full_name: "",
      id_number: "",
      phone: "",
      address: "",
      date_of_birth: "",
      email: "",
      occupation: "",
      mother_maiden_name: "",
      status: "active",
    },
  });

  // Reset form when saver changes
  useEffect(() => {
    if (saver && open) {
      form.reset({
        full_name: saver.full_name,
        id_number: saver.id_number,
        phone: saver.phone,
        address: saver.address,
        date_of_birth: formatDateToDisplay(saver.date_of_birth),
        email: saver.email || "",
        occupation: saver.occupation || "",
        mother_maiden_name: saver.mother_maiden_name || "",
        status: saver.status as "active" | "inactive",
      });
      setPhotoPreview(saver.photo_url);
      setPhotoFile(null);
    }
  }, [saver, open, form]);

  // Auto-format date with separators
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>, onChange: (value: string) => void) => {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    if (value.length >= 5) {
      value = value.slice(0, 5) + '/' + value.slice(5);
    }
    
    if (value.length > 10) {
      value = value.slice(0, 10);
    }
    
    onChange(value);
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const compressedFile = await compressImage(file, 0.7, 800);
      setPhotoFile(compressedFile);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(compressedFile);
    } catch (error) {
      console.error("Error compressing image:", error);
      toast.error("Gagal memproses foto");
    } finally {
      setUploading(false);
    }
  };

  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(saver?.photo_url || null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const convertDateToISO = (dateStr: string): string | null => {
    if (!dateStr) return null;
    const [day, month, year] = dateStr.split('/');
    return `${year}-${month}-${day}`;
  };

  // Handle form submission - show supercode dialog first
  const handleFormSubmit = (values: FormValues) => {
    setPendingFormValues(values);
    setShowSupercodeDialog(true);
  };

  // Actual submit after supercode verification
  const onSubmit = async (values: FormValues) => {
    if (!saver) return;
    
    setPendingFormValues(null);
    setIsSubmitting(true);
    try {
      let photoUrl = saver.photo_url;

      // Upload new photo if changed
      if (photoFile) {
        const fileExt = photoFile.name.split('.').pop();
        const fileName = `saver_${Date.now()}.${fileExt}`;
        const filePath = fileName;

        const { error: uploadError } = await supabase.storage
          .from('customer-photos')
          .upload(filePath, photoFile, {
            cacheControl: '3600',
            upsert: false,
          });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('customer-photos')
          .getPublicUrl(filePath);

        photoUrl = publicUrl;
      }

      // Update saver
      const { error: updateError } = await supabase
        .from("savers")
        .update({
          full_name: values.full_name,
          id_number: values.id_number,
          phone: values.phone,
          address: values.address,
          date_of_birth: convertDateToISO(values.date_of_birth || ""),
          email: values.email || null,
          occupation: values.occupation || null,
          mother_maiden_name: values.mother_maiden_name || null,
          photo_url: photoUrl,
          status: values.status,
          updated_at: new Date().toISOString(),
        })
        .eq("id", saver.id);

      if (updateError) throw updateError;

      toast.success("Data debitur berhasil diperbarui!");
      queryClient.invalidateQueries({ queryKey: ["savers"] });
      onSuccess?.();
      onOpenChange(false);
    } catch (error: any) {
      console.error("Error updating saver:", error);
      toast.error("Gagal memperbarui data debitur", {
        description: error.message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!saver) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Data Debitur</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
            {/* Photo Upload */}
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-4">
                <div className="relative flex-shrink-0">
                  <Avatar className="h-16 w-16 border-2 border-dashed border-muted-foreground/50">
                    <AvatarImage src={photoPreview || undefined} />
                    <AvatarFallback className="bg-muted text-muted-foreground text-lg">
                      {form.watch("full_name")?.substring(0, 2).toUpperCase() || "?"}
                    </AvatarFallback>
                  </Avatar>
                  {photoFile && (
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute -top-1 -right-1 h-5 w-5 rounded-full"
                      onClick={removePhoto}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  )}
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-sm font-medium">Foto Debitur</span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                  >
                    {uploading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="mr-2 h-4 w-4" />
                    )}
                    Ganti Foto
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    className="hidden"
                  />
                </div>
              </div>
            </div>

            {/* Full Name */}
            <FormField
              control={form.control}
              name="full_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama Lengkap *</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Nama sesuai KTP" 
                      {...field}
                      onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* NIK */}
            <FormField
              control={form.control}
              name="id_number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>NIK *</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="16 digit NIK" 
                      maxLength={16}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Phone */}
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nomor Telepon *</FormLabel>
                  <FormControl>
                    <Input placeholder="08xxx atau +62xxx" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Date of Birth */}
            <FormField
              control={form.control}
              name="date_of_birth"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tanggal Lahir</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="dd/mm/yyyy"
                      value={field.value}
                      onChange={(e) => handleDateChange(e, field.onChange)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Occupation */}
            <FormField
              control={form.control}
              name="occupation"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pekerjaan</FormLabel>
                  <FormControl>
                    <Input placeholder="Pekerjaan" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Mother Maiden Name */}
            <FormField
              control={form.control}
              name="mother_maiden_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama Ibu Kandung</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Nama ibu kandung" 
                      {...field}
                      onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Email */}
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="email@contoh.com" type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Address */}
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Alamat *</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Alamat lengkap sesuai KTP"
                      rows={3}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Status */}
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="active">Aktif</SelectItem>
                      <SelectItem value="inactive">Nonaktif</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit Button */}
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Simpan Perubahan
            </Button>
          </form>
        </Form>
      </DialogContent>

      {/* Supercode Verification Dialog */}
      <SupercodeVerificationDialog
        open={showSupercodeDialog}
        onOpenChange={(open) => {
          setShowSupercodeDialog(open);
          if (!open) setPendingFormValues(null);
        }}
        onSuccess={() => {
          if (pendingFormValues) {
            onSubmit(pendingFormValues);
          }
        }}
        title="Verifikasi Edit Data Debitur"
        description="Masukkan supercode untuk menyimpan perubahan data debitur"
      />
    </Dialog>
  );
}
