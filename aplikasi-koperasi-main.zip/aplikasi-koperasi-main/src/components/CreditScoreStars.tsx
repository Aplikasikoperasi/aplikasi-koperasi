import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * CRITICAL: Credit Score Display Component
 * 
 * Komponen ini HANYA menampilkan credit_score dari database.
 * TIDAK ADA PERHITUNGAN atau MODIFIKASI skor di sini.
 * 
 * Sumber skor kredit: HANYA dari database function `calculate_credit_score()`
 * Range skor: 1.0 - 5.0 (tidak ada pembatasan hardcoded)
 * 
 * Formula skor kredit (di database):
 * 1 + ((total_angsuran - (telat + menunggak)) / total_angsuran) * 4
 * 
 * JANGAN UBAH tanpa persetujuan eksplisit!
 */
interface CreditScoreStarsProps {
  creditScore: number;
  restorationStatus: "never_restored" | "restored_once" | "permanently_blocked";
  className?: string;
}

export function CreditScoreStars({ 
  creditScore, 
  restorationStatus,
  className 
}: CreditScoreStarsProps) {
  // Determine color based on credit score and restoration status
  const getStarColor = () => {
    // For permanently blocked, always red regardless of score
    if (restorationStatus === "permanently_blocked") {
      return "fill-red-500 text-red-500";
    }
    
    // For restored once, use yellow
    if (restorationStatus === "restored_once") {
      return "fill-yellow-400 text-yellow-400";
    }
    
    // For never restored, determine by credit score
    if (creditScore >= 4) {
      return "fill-green-500 text-green-500"; // Green for good (4-5 stars)
    } else if (creditScore >= 3) {
      return "fill-yellow-400 text-yellow-400"; // Yellow for medium (3-3.9 stars)
    } else {
      return "fill-red-500 text-red-500"; // Red for poor (0-2.9 stars)
    }
  };

  const starColor = getStarColor();
  const emptyColor = "text-gray-300";

  // Get text color for numeric display
  const getTextColor = () => {
    if (restorationStatus === "permanently_blocked") return "text-red-500";
    if (restorationStatus === "restored_once") return "text-yellow-500";
    if (creditScore >= 4) return "text-green-500";
    if (creditScore >= 3) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((starNumber) => {
        const fillPercentage = Math.max(0, Math.min(100, (creditScore - (starNumber - 1)) * 100));
        const isPartialFill = fillPercentage > 0 && fillPercentage < 100;
        
        return (
          <div key={starNumber} className="relative h-4 w-4">
            {/* Background empty star */}
            <Star className={cn("h-4 w-4 absolute", emptyColor)} />
            
            {/* Filled star with clip-path for partial fill */}
            {fillPercentage > 0 && (
              <div 
                className="absolute inset-0 overflow-hidden"
                style={{ 
                  clipPath: isPartialFill 
                    ? `inset(0 ${100 - fillPercentage}% 0 0)` 
                    : undefined 
                }}
              >
                <Star 
                  className={cn("h-4 w-4", starColor)} 
                />
              </div>
            )}
          </div>
          );
        })}
      </div>
      <span className={cn("text-sm font-semibold", getTextColor())}>
        {creditScore.toFixed(1)}
      </span>
    </div>
  );
}
