import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CurrencyInput } from "@/components/ui/currency-input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import { ArrowDownCircle, Loader2, Wallet, Banknote, Building2, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { formatRupiah } from "@/lib/utils";
interface SaverWithdrawalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saverId: string;
  saverName: string;
  currentBalance: number;
  onSuccess?: () => void;
}
export default function SaverWithdrawalDialog({
  open,
  onOpenChange,
  saverId,
  saverName,
  currentBalance,
  onSuccess
}: SaverWithdrawalDialogProps) {
  const [amount, setAmount] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [paymentDetails, setPaymentDetails] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasPinSet, setHasPinSet] = useState<boolean | null>(null);
  const [isCheckingPin, setIsCheckingPin] = useState(false);
  const {
    isOwner,
    isAdmin,
    isKasir
  } = useUserRole();
  const numericAmount = parseInt(amount || "0", 10);

  // Check if saver has PIN set when dialog opens
  useEffect(() => {
    if (open && saverId) {
      setIsCheckingPin(true);
      supabase
        .from("savers")
        .select("pin_hash")
        .eq("id", saverId)
        .single()
        .then(({ data, error }) => {
          if (error) {
            console.error("Error checking PIN status:", error);
            setHasPinSet(false);
          } else {
            setHasPinSet(!!data?.pin_hash);
          }
          setIsCheckingPin(false);
        });
    } else if (!open) {
      // Reset when dialog closes
      setHasPinSet(null);
    }
  }, [open, saverId]);
  const handleSubmit = async () => {
    if (numericAmount <= 0) {
      toast.error("Jumlah penarikan harus lebih dari 0");
      return;
    }
    if (numericAmount > currentBalance) {
      toast.error("Saldo tidak mencukupi");
      return;
    }
    setIsSubmitting(true);
    try {
      // Get current member info
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");
      const {
        data: member
      } = await supabase.from("members").select("id, position").eq("user_id", user.id).single();
      if (!member) throw new Error("Member not found");

      // Fetch latest balance from database for validation
      const {
        data: latestSaver,
        error: fetchError
      } = await supabase.from("savers").select("balance, pin_hash").eq("id", saverId).single();
      if (fetchError) throw fetchError;
      const latestBalance = latestSaver?.balance || 0;

      // Re-validate with latest balance
      if (numericAmount > latestBalance) {
        toast.error("Saldo tidak mencukupi");
        setIsSubmitting(false);
        return;
      }

      // Check if saver has PIN set
      if (!latestSaver?.pin_hash) {
        toast.error("Debitur belum mengatur PIN. PIN harus diatur terlebih dahulu.");
        setIsSubmitting(false);
        return;
      }

      // Check if there's already a pending withdrawal
      const {
        data: existingPending
      } = await supabase.from("saver_pending_withdrawals").select("id").eq("saver_id", saverId).eq("status", "pending").limit(1);
      if (existingPending && existingPending.length > 0) {
        toast.error("Sudah ada penarikan yang menunggu konfirmasi untuk debitur ini");
        setIsSubmitting(false);
        return;
      }

      // Create pending withdrawal (requires saver PIN confirmation)
      const {
        error: pendingError
      } = await supabase.from("saver_pending_withdrawals").insert({
        saver_id: saverId,
        amount: numericAmount,
        payment_method: paymentMethod,
        payment_details: paymentMethod === 'transfer' ? paymentDetails : null,
        notes,
        requested_by: member.id,
        status: "pending"
      });
      if (pendingError) throw pendingError;
      toast.success("Permintaan penarikan berhasil dibuat. Menunggu konfirmasi PIN dari debitur.");

      // Reset form
      setAmount("");
      setNotes("");
      setPaymentMethod("cash");
      setPaymentDetails("");
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error("Error creating pending withdrawal:", error);
      toast.error(`Gagal membuat permintaan penarikan: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowDownCircle className="h-5 w-5 text-red-600" />
            Tarik Saldo
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-3 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">Debitur</p>
            <p className="font-semibold">{saverName}</p>
          </div>

          <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
            <div className="flex items-center gap-2">
              <Wallet className="h-4 w-4 text-primary" />
              <span className="text-sm">Saldo Tersedia</span>
            </div>
            <p className="text-xl font-bold text-primary">
              {formatRupiah(currentBalance)}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Jumlah Penarikan</Label>
            <CurrencyInput id="amount" value={amount} onChange={val => setAmount(val)} placeholder="Masukkan jumlah penarikan" />
            {numericAmount > currentBalance && <p className="text-sm text-destructive">Saldo tidak mencukupi</p>}
          </div>

          <div className="space-y-2">
            <Label>Metode Pencairan</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">
                  <div className="flex items-center gap-2">
                    <Banknote className="h-4 w-4 text-green-600" />
                    <span>Tunai (Cash)</span>
                  </div>
                </SelectItem>
                <SelectItem value="transfer">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-blue-500" />
                    <span>Transfer Bank</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {paymentMethod === 'transfer' && <div className="space-y-2">
              <Label htmlFor="payment-details">Rekening Tujuan</Label>
              <Input id="payment-details" value={paymentDetails} onChange={e => setPaymentDetails(e.target.value)} placeholder="Contoh: BCA - 1234567890 a.n. John Doe" />
            </div>}

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan (Opsional)</Label>
            <Textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Catatan tambahan..." rows={2} />
          </div>

          {/* PIN not set warning */}
          {hasPinSet === false && (
            <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-300 dark:border-red-800 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-700 dark:text-red-300">
                    Debitur belum mengatur PIN
                  </p>
                  <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                    Penarikan tidak dapat diproses karena debitur belum mengatur PIN. Minta debitur untuk login dan mengatur PIN terlebih dahulu.
                  </p>
                </div>
              </div>
            </div>
          )}

          {hasPinSet !== false && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-sm text-amber-700 dark:text-amber-300">⚠️ Penarikan akan menunggu konfirmasi PIN dari debitur</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Batal
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isSubmitting || numericAmount <= 0 || numericAmount > currentBalance || hasPinSet === false || isCheckingPin}
          >
            {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {isCheckingPin ? "Memeriksa..." : "Ajukan Penarikan"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>;
}