import { useEffect, useRef } from "react";
import { useDeviceDetection } from "@/hooks/use-device-detection";

interface DeviceAwareWrapperProps {
  children: React.ReactNode;
}

export function DeviceAwareWrapper({ children }: DeviceAwareWrapperProps) {
  const device = useDeviceDetection();
  const cleanupRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    // Add device-specific classes to body
    const body = document.body;
    
    // Remove all device classes first
    body.classList.remove("device-mobile", "device-tablet", "device-desktop", "touch-device", "device-ios", "device-android");
    
    // Add current device class
    body.classList.add(`device-${device.type}`);
    
    // Add touch device class if applicable
    if (device.isTouchDevice) {
      body.classList.add("touch-device");
    }

    // Detect iOS devices
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
                  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    
    if (isIOS) {
      body.classList.add("device-ios");
      // NOTE: We rely on CSS touch-action: manipulation instead of JS event interception
      // The CSS rule in index.css already handles double-tap zoom prevention
      // This avoids the problematic e.preventDefault() that was blocking all button clicks
    } else if (/Android/.test(navigator.userAgent)) {
      body.classList.add("device-android");
    }

    // Add orientation class
    body.setAttribute("data-orientation", device.orientation);

    // Log device info for debugging (only in development)
    if (import.meta.env.DEV) {
      console.log("Device detected:", {
        type: device.type,
        dimensions: `${device.screenWidth}x${device.screenHeight}`,
        orientation: device.orientation,
        touch: device.isTouchDevice,
        isIOS: isIOS,
      });
    }

    // Cleanup function - remove device classes on unmount
    return () => {
      if (cleanupRef.current) {
        cleanupRef.current();
        cleanupRef.current = null;
      }
    };
  }, [device]);

  return <>{children}</>;
}
