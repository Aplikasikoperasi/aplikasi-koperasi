import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Lock, Eye, EyeOff, Check, KeyRound } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface SaverPinSettingsProps {
  saverId: string;
  hasPin: boolean;
  onPinUpdated: () => void;
}

export default function SaverPinSettings({ saverId, hasPin, onPinUpdated }: SaverPinSettingsProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showCurrentPin, setShowCurrentPin] = useState(false);
  const [showNewPin, setShowNewPin] = useState(false);
  const [showConfirmPin, setShowConfirmPin] = useState(false);
  
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  
  // Inline error states
  const [currentPinError, setCurrentPinError] = useState("");
  const [newPinError, setNewPinError] = useState("");
  const [confirmPinError, setConfirmPinError] = useState("");

  const resetForm = () => {
    setCurrentPin("");
    setNewPin("");
    setConfirmPin("");
    setShowCurrentPin(false);
    setShowNewPin(false);
    setShowConfirmPin(false);
    setCurrentPinError("");
    setNewPinError("");
    setConfirmPinError("");
  };

  const handleClose = () => {
    setIsDialogOpen(false);
    resetForm();
  };

  const validatePin = (pin: string): boolean => {
    return /^\d{6}$/.test(pin);
  };

  const handleSubmit = async () => {
    // Reset errors
    setCurrentPinError("");
    setNewPinError("");
    setConfirmPinError("");

    let hasError = false;

    // Validate new PIN
    if (!validatePin(newPin)) {
      setNewPinError("PIN harus terdiri dari 6 digit angka");
      hasError = true;
    }

    if (newPin !== confirmPin) {
      setConfirmPinError("Konfirmasi PIN tidak cocok");
      hasError = true;
    }

    // If already has PIN, verify current PIN first
    if (hasPin && !validatePin(currentPin)) {
      setCurrentPinError("PIN harus terdiri dari 6 digit angka");
      hasError = true;
    }

    if (hasError) return;

    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("update-saver-pin", {
        body: {
          saver_id: saverId,
          current_pin: hasPin ? currentPin : null,
          new_pin: newPin,
        },
      });

      if (error) {
        toast.error("Gagal mengubah PIN");
        return;
      }

      if (data.success) {
        toast.success(hasPin ? "PIN berhasil diubah" : "PIN berhasil dibuat");
        onPinUpdated();
        handleClose();
        return;
      }

      // Tampilkan error di field yang relevan
      if (data.message === "PIN saat ini salah") {
        setCurrentPinError("PIN saat ini salah");
        return;
      }

      if (data.message) {
        toast.error(data.message);
      } else {
        toast.error("Gagal mengubah PIN");
      }
    } catch (error: any) {
      console.warn("Error updating PIN:", error);
      const errorMessage = error?.context?.message || error?.message || "Gagal mengubah PIN";
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Card className="animate-fade-in">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Pengaturan PIN
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            PIN digunakan untuk konfirmasi penarikan saldo. Hanya Anda yang mengetahui PIN ini.
          </p>
          
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${hasPin ? "bg-green-500" : "bg-orange-500"}`} />
            <span className="text-sm">
              {hasPin ? "PIN sudah diatur" : "PIN belum diatur"}
            </span>
          </div>

          <Button 
            onClick={() => setIsDialogOpen(true)}
            variant={hasPin ? "outline" : "default"}
            className="w-full"
          >
            <KeyRound className="h-4 w-4 mr-2" />
            {hasPin ? "Ubah PIN" : "Buat PIN"}
          </Button>
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              {hasPin ? "Ubah PIN" : "Buat PIN Baru"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {hasPin && (
              <div className="space-y-2">
                <Label htmlFor="currentPin">PIN Saat Ini</Label>
                <div className="relative">
                  <Input
                    id="currentPin"
                    type={showCurrentPin ? "text" : "password"}
                    inputMode="numeric"
                    maxLength={6}
                    value={currentPin}
                    onChange={(e) => {
                      setCurrentPin(e.target.value.replace(/\D/g, ""));
                      setCurrentPinError("");
                    }}
                    placeholder="Masukkan PIN saat ini"
                    className={`pr-10 ${currentPinError ? "border-destructive" : ""}`}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowCurrentPin(!showCurrentPin)}
                  >
                    {showCurrentPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                {currentPinError && (
                  <p className="text-xs text-destructive">{currentPinError}</p>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="newPin">PIN Baru (6 digit)</Label>
              <div className="relative">
                <Input
                  id="newPin"
                  type={showNewPin ? "text" : "password"}
                  inputMode="numeric"
                  maxLength={6}
                  value={newPin}
                  onChange={(e) => {
                    setNewPin(e.target.value.replace(/\D/g, ""));
                    setNewPinError("");
                  }}
                  placeholder="Masukkan PIN baru"
                  className={`pr-10 ${newPinError ? "border-destructive" : ""}`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowNewPin(!showNewPin)}
                >
                  {showNewPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              {newPinError ? (
                <p className="text-xs text-destructive">{newPinError}</p>
              ) : (
                <p className="text-xs text-muted-foreground">PIN harus terdiri dari 6 digit angka</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPin">Konfirmasi PIN Baru</Label>
              <div className="relative">
                <Input
                  id="confirmPin"
                  type={showConfirmPin ? "text" : "password"}
                  inputMode="numeric"
                  maxLength={6}
                  value={confirmPin}
                  onChange={(e) => {
                    setConfirmPin(e.target.value.replace(/\D/g, ""));
                    setConfirmPinError("");
                  }}
                  placeholder="Masukkan ulang PIN baru"
                  className={`pr-10 ${confirmPinError ? "border-destructive" : ""}`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowConfirmPin(!showConfirmPin)}
                >
                  {showConfirmPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              {confirmPinError ? (
                <p className="text-xs text-destructive">{confirmPinError}</p>
              ) : confirmPin && newPin === confirmPin ? (
                <p className="text-xs text-green-600 flex items-center gap-1">
                  <Check className="h-3 w-3" /> PIN cocok
                </p>
              ) : null}
            </div>

            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={handleClose} className="flex-1">
                Batal
              </Button>
              <Button 
                onClick={handleSubmit} 
                disabled={isLoading || !newPin || !confirmPin || (hasPin && !currentPin)}
                className="flex-1"
              >
                {isLoading ? "Menyimpan..." : "Simpan PIN"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
