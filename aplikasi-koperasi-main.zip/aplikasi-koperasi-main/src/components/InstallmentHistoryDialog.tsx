import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { Badge } from "@/components/ui/badge";
import { formatDate, formatRupiah } from "@/lib/utils";
import { usePenaltyRate } from "@/hooks/useInstallmentsQuery";
import { differenceInDays } from "date-fns";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";

interface InstallmentHistoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  installments: any[];
  applicationNumber: string;
  customerName: string;
  loanAmount?: number;
  tenor?: number;
  status?: string;
}

export function InstallmentHistoryDialog({
  open,
  onOpenChange,
  installments,
  applicationNumber,
  customerName,
  loanAmount = 0,
  tenor = 0,
  status = 'approved',
}: InstallmentHistoryDialogProps) {
  const { data: penaltyRate } = usePenaltyRate();

  // Calculate totals
  const totalPaid = installments.reduce((sum, inst) => sum + (inst.paid_amount || 0), 0);
  const totalAmount = installments.reduce((sum, inst) => sum + (inst.total_amount || 0), 0);
  const remainingBalance = totalAmount - totalPaid;
  const paidCount = installments.filter(i => i.status === 'paid').length;
  const progressPercent = installments.length > 0 ? (paidCount / installments.length) * 100 : 0;

  const calculatePenalty = (installment: any) => {
    const penaltyPct = (Number(penaltyRate) || 2) / 100;
    const total = Number(installment.total_amount || 0);
    const dueDate = installment.due_date ? new Date(installment.due_date) : null;

    // Jika sudah LUNAS/principal_paid, gunakan denda beku yang sudah dihitung sistem
    // CRITICAL: Jangan hitung ulang dengan paid_at karena paid_at bisa berbeda dengan payment_date
    if ((installment.principal_paid || installment.status === 'paid') && dueDate) {
      const frozenVal = Number(installment.frozen_penalty || 0);
      const frozenDays = Number(installment.frozen_days_overdue || 0);
      // Frozen penalty sudah dihitung berdasarkan payment_date vs due_date oleh sistem
      return { penalty: frozenVal, daysOverdue: frozenDays, isFrozen: true };
    }

  // Belum lunas: hitung denda berjalan (sama seperti di dashboard - gunakan total_amount dan round)
  if (dueDate) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    dueDate.setHours(0, 0, 0, 0);
    const daysOverdue = differenceInDays(today, dueDate);
    if (daysOverdue > 0) {
      const penalty = Math.ceil((daysOverdue * (total * penaltyPct)) / 1000) * 1000;
      return { penalty, daysOverdue, isFrozen: false };
    }
  }

    return { penalty: 0, daysOverdue: 0, isFrozen: false };
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge variant="default" className="text-xs">Lunas</Badge>;
      case 'overdue':
        return <Badge variant="destructive" className="text-xs">Menunggak</Badge>;
      case 'partial':
        return <Badge variant="secondary" className="text-xs">Sebagian</Badge>;
      default:
        return <Badge variant="outline" className="text-xs">Belum Bayar</Badge>;
    }
  };

  const sortedInstallments = [...installments].sort((a, b) => a.installment_number - b.installment_number);

  return (
    <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-2xl w-full max-h-[90vh]">
        <ResponsiveDialogHeader className="pr-14">
          <div className="flex items-center justify-between">
            <ResponsiveDialogTitle className="text-lg font-bold">{applicationNumber}</ResponsiveDialogTitle>
            <Badge className={status === 'disbursed' ? 'bg-blue-600' : 'bg-green-600'}>
              {status === 'disbursed' ? 'Dicairkan' : 'Disetujui'}
            </Badge>
          </div>
        </ResponsiveDialogHeader>

        <div className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Jumlah Pinjaman</p>
              <p className="font-bold text-base">{formatRupiah(loanAmount)}</p>
            </div>
            <div className="space-y-1 text-right">
              <p className="text-xs text-muted-foreground">Tenor</p>
              <p className="font-bold text-base">{tenor} Bulan</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Dibayar</p>
              <p className="font-bold text-base text-green-600">{formatRupiah(totalPaid)}</p>
            </div>
            <div className="space-y-1 text-right">
              <p className="text-xs text-muted-foreground">Sisa Utang</p>
              <p className="font-bold text-base text-orange-600">{formatRupiah(remainingBalance)}</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2 w-full">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Progress Pembayaran</span>
              <span className="text-sm font-bold">{progressPercent.toFixed(1)}%</span>
            </div>
            <Progress value={progressPercent} className="h-2 w-full" />
          </div>

          <Separator />

          {/* Installments Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-sm">Tabel Angsuran</h4>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Ke-</th>
                    <th className="text-left p-2">Jatuh Tempo</th>
                    <th className="text-right p-2">Jumlah</th>
                    <th className="text-right p-2">Denda</th>
                    <th className="text-center p-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedInstallments.map((installment) => {
                    const { penalty, daysOverdue, isFrozen } = calculatePenalty(installment);
                    
                    return (
                      <tr key={installment.id} className="border-b hover:bg-muted/50">
                        <td className="p-2">
                          <div className="flex items-center gap-1.5">
                            <span>{installment.installment_number}</span>
                            {installment.is_silenced && (
                              <span className="text-xs bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-1 py-0.5 rounded border border-purple-300 dark:border-purple-700 flex items-center gap-0.5" title="Silent Mode - Tidak ada reminder otomatis">
                                🔕
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-2">{formatDate(installment.due_date)}</td>
                        <td className="text-right p-2">{formatRupiah(installment.total_amount || 0)}</td>
                        <td className="text-right p-2">
                          {penalty > 0 ? (
                            isFrozen ? (
                              <div className="flex flex-col items-end">
                                <span className="text-orange-600 font-medium">{formatRupiah(penalty)}</span>
                                {daysOverdue > 0 && (
                                  <span className="text-xs text-muted-foreground">({daysOverdue} hari)</span>
                                )}
                              </div>
                            ) : (
                              <span className="text-red-600 font-semibold">{formatRupiah(penalty)}</span>
                            )
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="text-center p-2">
                          {getStatusBadge(installment.status)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {sortedInstallments.length === 0 && (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  Belum ada data angsuran
                </div>
              )}
            </div>
          </div>
        </div>
      </ResponsiveDialogContent>
    </ResponsiveDialog>
  );
}
