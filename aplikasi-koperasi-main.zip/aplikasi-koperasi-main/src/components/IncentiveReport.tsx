import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { formatRupiah } from "@/lib/utils";
import { Wallet, CheckCircle, ChevronLeft, ChevronRight, RefreshCw, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
interface MemberBalanceData {
  member_id: string;
  member_name: string;
  member_number: string;
  regular_balance: number;
  thr_balance: number;
  total_balance: number;
  available_balance: number;
  pending_withdrawals: number;
}
interface WithdrawalDetail {
  id: string;
  member_id: string;
  member_name: string;
  amount: number;
  status: string;
  requested_at: string;
  reviewed_at: string | null;
  withdrawal_type: string;
  withdrawal_method: string | null;
  bank_account_info: string | null;
  notes: string | null;
}
export function IncentiveReport() {
  const [loading, setLoading] = useState(true);
  const [memberBalances, setMemberBalances] = useState<MemberBalanceData[]>([]);
  const [approvedWithdrawals, setApprovedWithdrawals] = useState<WithdrawalDetail[]>([]);
  const [withdrawalPage, setWithdrawalPage] = useState(1);
  const [showOnlyWithBalance, setShowOnlyWithBalance] = useState(true);
  const [withdrawalSearch, setWithdrawalSearch] = useState("");
  const ITEMS_PER_PAGE = 20;

  // Filter members based on balance
  const filteredMemberBalances = useMemo(() => {
    if (!showOnlyWithBalance) return memberBalances;
    return memberBalances.filter(m => m.total_balance > 0);
  }, [memberBalances, showOnlyWithBalance]);
  const loadRealtimeBalances = async () => {
    try {
      setLoading(true);

      // Get all active members
      const {
        data: members,
        error: membersError
      } = await supabase.from("members").select("id, full_name, member_number, is_active").eq("is_active", true).order("member_number", {
        ascending: true
      });
      if (membersError) throw membersError;

      // Fetch balance for each member using the same RPC as member balance page
      const balancePromises = (members || []).map(async member => {
        // Get detailed balance using RPC
        const {
          data: balanceData,
          error: balanceError
        } = await supabase.rpc("get_member_balance_detailed", {
          p_member_id: member.id
        });
        if (balanceError) {
          console.error(`Error fetching balance for ${member.full_name}:`, balanceError);
          return null;
        }

        // Get available balance using RPC
        const {
          data: availableBalance,
          error: availableError
        } = await supabase.rpc("get_member_available_balance", {
          p_member_id: member.id
        });
        if (availableError) {
          console.error(`Error fetching available balance for ${member.full_name}:`, availableError);
        }

        // Get pending withdrawals
        const {
          data: pendingData,
          error: pendingError
        } = await supabase.from("member_balance_withdrawals").select("amount").eq("member_id", member.id).eq("status", "pending");
        const pendingTotal = pendingData?.reduce((sum, w) => sum + Number(w.amount), 0) || 0;
        const balance = balanceData?.[0] || {
          regular_balance: 0,
          thr_balance: 0,
          total_balance: 0
        };
        return {
          member_id: member.id,
          member_name: member.full_name,
          member_number: member.member_number || "-",
          regular_balance: Number(balance.regular_balance || 0),
          thr_balance: Number(balance.thr_balance || 0),
          total_balance: Number(balance.total_balance || 0),
          available_balance: Number(availableBalance || 0),
          pending_withdrawals: pendingTotal
        };
      });
      const results = await Promise.all(balancePromises);
      const validResults = results.filter((r): r is MemberBalanceData => r !== null);

      // Sort by total balance descending
      validResults.sort((a, b) => b.total_balance - a.total_balance);
      setMemberBalances(validResults);

      // Fetch approved withdrawals (all time, most recent first)
      const {
        data: withdrawalsData,
        error: withdrawalsError
      } = await supabase.from("member_balance_withdrawals").select(`
          id,
          member_id,
          amount,
          status,
          requested_at,
          reviewed_at,
          withdrawal_type,
          withdrawal_method,
          bank_account_info,
          notes,
          members:member_id (full_name)
        `).eq("status", "approved").order("reviewed_at", {
        ascending: false
      }).limit(500);
      if (withdrawalsError) throw withdrawalsError;
      const formattedWithdrawals: WithdrawalDetail[] = (withdrawalsData || []).map((w: any) => ({
        id: w.id,
        member_id: w.member_id,
        member_name: w.members?.full_name || "Unknown",
        amount: Number(w.amount),
        status: w.status,
        requested_at: w.requested_at,
        reviewed_at: w.reviewed_at,
        withdrawal_type: w.withdrawal_type || "regular",
        withdrawal_method: w.withdrawal_method,
        bank_account_info: w.bank_account_info,
        notes: w.notes
      }));
      setApprovedWithdrawals(formattedWithdrawals);
    } catch (error) {
      console.error("Error loading realtime balances:", error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    loadRealtimeBalances();

    // Debounce realtime updates
    let reloadTimeout: NodeJS.Timeout;
    const debouncedReload = () => {
      clearTimeout(reloadTimeout);
      reloadTimeout = setTimeout(() => {
        console.log("Reloading balances after changes...");
        loadRealtimeBalances();
      }, 1000);
    };

    // Setup realtime subscriptions
    const withdrawalsChannel = supabase.channel("incentive-withdrawals-realtime").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "member_balance_withdrawals"
    }, debouncedReload).subscribe();
    const transactionsChannel = supabase.channel("incentive-transactions-realtime").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "member_balance_transactions"
    }, debouncedReload).subscribe();
    return () => {
      clearTimeout(reloadTimeout);
      supabase.removeChannel(withdrawalsChannel);
      supabase.removeChannel(transactionsChannel);
    };
  }, []);

  // Filter withdrawals by search
  const filteredWithdrawals = useMemo(() => {
    if (!withdrawalSearch.trim()) return approvedWithdrawals;
    const search = withdrawalSearch.toLowerCase().trim();
    return approvedWithdrawals.filter(w => 
      w.member_name.toLowerCase().includes(search) ||
      (w.withdrawal_type === "year_end_bonus" ? "bonus akhir tahun" : "reguler").includes(search) ||
      format(new Date(w.reviewed_at || w.requested_at), "dd MMM yyyy", { locale: id }).toLowerCase().includes(search)
    );
  }, [approvedWithdrawals, withdrawalSearch]);

  // Reset page when search changes
  useEffect(() => {
    setWithdrawalPage(1);
  }, [withdrawalSearch]);

  // Pagination for withdrawals
  const totalWithdrawalPages = Math.ceil(filteredWithdrawals.length / ITEMS_PER_PAGE);
  const paginatedWithdrawals = useMemo(() => {
    const startIndex = (withdrawalPage - 1) * ITEMS_PER_PAGE;
    return filteredWithdrawals.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredWithdrawals, withdrawalPage]);

  // Calculate totals
  const totals = useMemo(() => {
    return filteredMemberBalances.reduce((acc, m) => ({
      regular: acc.regular + m.regular_balance,
      thr: acc.thr + m.thr_balance,
      total: acc.total + m.total_balance,
      available: acc.available + m.available_balance,
      pending: acc.pending + m.pending_withdrawals
    }), {
      regular: 0,
      thr: 0,
      total: 0,
      available: 0,
      pending: 0
    });
  }, [filteredMemberBalances]);
  const totalWithdrawn = useMemo(() => {
    return approvedWithdrawals.reduce((sum, w) => sum + w.amount, 0);
  }, [approvedWithdrawals]);
  if (loading) {
    return <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>;
  }
  return <div className="space-y-6">
      {/* Header with Filter and Refresh */}
      

      {/* Tabs */}
      <Tabs defaultValue="saldo" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="saldo" className="flex items-center gap-2">
            <Wallet className="h-4 w-4" />
            Saldo Insentif
          </TabsTrigger>
          <TabsTrigger value="penarikan" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            Penarikan
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Saldo Insentif */}
        <TabsContent value="saldo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">LAPORAN SALDO INSENTIF REALTIME</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Summary Cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg text-center border border-blue-200">
                    <div className="text-xs text-muted-foreground uppercase mb-1">Saldo Reguler</div>
                    <div className="text-xl font-bold text-blue-600">
                      {formatRupiah(totals.regular)}
                    </div>
                  </div>
                  <div className="p-4 bg-amber-50 rounded-lg text-center border border-amber-200">
                    <div className="text-xs text-muted-foreground uppercase mb-1">Bonus Akhir Tahun</div>
                    <div className="text-xl font-bold text-amber-600">
                      {formatRupiah(totals.thr)}
                    </div>
                  </div>
                  <div className="p-4 bg-primary/10 rounded-lg text-center border border-primary/20">
                    <div className="text-xs text-muted-foreground uppercase mb-1">Total Saldo</div>
                    <div className="text-xl font-bold text-primary">
                      {formatRupiah(totals.total)}
                    </div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg text-center border border-green-200">
                    <div className="text-xs text-muted-foreground uppercase mb-1">Dapat Ditarik</div>
                    <div className="text-xl font-bold text-green-700">
                      {formatRupiah(totals.available)}
                    </div>
                  </div>
                </div>

                {/* Table - Desktop */}
                <div className="hidden lg:block overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead className="text-center w-[60px]">ID</TableHead>
                        <TableHead>Nama Anggota</TableHead>
                        <TableHead className="text-right">Saldo Reguler</TableHead>
                        <TableHead className="text-right">Bonus Akhir Tahun</TableHead>
                        <TableHead className="text-right">Total Saldo</TableHead>
                        <TableHead className="text-right">Dapat Ditarik</TableHead>
                        <TableHead className="text-right">Pending</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredMemberBalances.length === 0 ? <TableRow>
                          <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                            {showOnlyWithBalance ? "Tidak ada anggota dengan saldo > 0" : "Tidak ada data saldo"}
                          </TableCell>
                        </TableRow> : <>
                          {filteredMemberBalances.map(member => <TableRow key={member.member_id}>
                              <TableCell className="text-center font-mono text-sm font-bold">
                                {member.member_number}
                              </TableCell>
                              <TableCell className="font-medium">{member.member_name}</TableCell>
                              <TableCell className="text-right font-semibold text-blue-600">
                                {formatRupiah(member.regular_balance)}
                              </TableCell>
                              <TableCell className="text-right font-semibold text-amber-600">
                                {formatRupiah(member.thr_balance)}
                              </TableCell>
                              <TableCell className="text-right font-semibold text-primary">
                                {formatRupiah(member.total_balance)}
                              </TableCell>
                              <TableCell className="text-right font-semibold text-green-600">
                                {formatRupiah(member.available_balance)}
                              </TableCell>
                              <TableCell className="text-right">
                                {member.pending_withdrawals > 0 ? <Badge variant="outline" className="text-orange-600 border-orange-300">
                                    {formatRupiah(member.pending_withdrawals)}
                                  </Badge> : <span className="text-muted-foreground">-</span>}
                              </TableCell>
                            </TableRow>)}
                          <TableRow className="bg-muted/50 font-bold border-t-2">
                            <TableCell colSpan={2} className="text-center">TOTAL</TableCell>
                            <TableCell className="text-right text-blue-600">
                              {formatRupiah(totals.regular)}
                            </TableCell>
                            <TableCell className="text-right text-amber-600">
                              {formatRupiah(totals.thr)}
                            </TableCell>
                            <TableCell className="text-right text-primary">
                              {formatRupiah(totals.total)}
                            </TableCell>
                            <TableCell className="text-right text-green-600">
                              {formatRupiah(totals.available)}
                            </TableCell>
                            <TableCell className="text-right">
                              {totals.pending > 0 && <Badge variant="outline" className="text-orange-600 border-orange-300">
                                  {formatRupiah(totals.pending)}
                                </Badge>}
                            </TableCell>
                          </TableRow>
                        </>}
                    </TableBody>
                  </Table>
                </div>

                {/* Card View - Mobile */}
                <div className="lg:hidden space-y-3">
                  {filteredMemberBalances.length === 0 ? <div className="text-center py-8 text-muted-foreground">
                      {showOnlyWithBalance ? "Tidak ada anggota dengan saldo > 0" : "Tidak ada data saldo"}
                    </div> : <>
                      {filteredMemberBalances.map(member => <Card key={member.member_id} className="border-l-4 border-l-primary">
                          <CardContent className="p-4">
                            <div className="mb-3">
                              <div className="font-mono text-xs text-muted-foreground mb-1">
                                {member.member_number}
                              </div>
                              <h3 className="font-semibold text-sm">{member.member_name}</h3>
                            </div>

                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div>
                                <p className="text-muted-foreground mb-1">Saldo Reguler</p>
                                <p className="font-semibold text-blue-600">
                                  {formatRupiah(member.regular_balance)}
                                </p>
                              </div>
                              <div>
                                <p className="text-muted-foreground mb-1">Bonus Akhir Tahun</p>
                                <p className="font-semibold text-amber-600">
                                  {formatRupiah(member.thr_balance)}
                                </p>
                              </div>
                              <div>
                                <p className="text-muted-foreground mb-1">Total Saldo</p>
                                <p className="font-semibold text-primary">
                                  {formatRupiah(member.total_balance)}
                                </p>
                              </div>
                              <div>
                                <p className="text-muted-foreground mb-1">Dapat Ditarik</p>
                                <p className="font-semibold text-green-600">
                                  {formatRupiah(member.available_balance)}
                                </p>
                              </div>
                              {member.pending_withdrawals > 0 && <div className="col-span-2">
                                  <p className="text-muted-foreground mb-1">Pending Penarikan</p>
                                  <Badge variant="outline" className="text-orange-600 border-orange-300">
                                    {formatRupiah(member.pending_withdrawals)}
                                  </Badge>
                                </div>}
                            </div>
                          </CardContent>
                        </Card>)}

                      {/* Total Card */}
                      <Card className="bg-muted/30 border border-primary">
                        <CardContent className="p-4">
                          <h3 className="font-bold text-sm mb-3">TOTAL SEMUA ANGGOTA</h3>
                          <div className="grid grid-cols-2 gap-3 text-xs">
                            <div>
                              <p className="text-muted-foreground mb-1">Saldo Reguler</p>
                              <p className="font-bold text-blue-600">{formatRupiah(totals.regular)}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground mb-1">Bonus Akhir Tahun</p>
                              <p className="font-bold text-amber-600">{formatRupiah(totals.thr)}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground mb-1">Total Saldo</p>
                              <p className="font-bold text-primary">{formatRupiah(totals.total)}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground mb-1">Dapat Ditarik</p>
                              <p className="font-bold text-green-600">{formatRupiah(totals.available)}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </>}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: Penarikan */}
        <TabsContent value="penarikan" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">RIWAYAT PENARIKAN DISETUJUI</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-green-50 rounded-lg text-center border border-green-200">
                    <div className="text-xs text-muted-foreground uppercase mb-1">
                      Total Penarikan Disetujui
                    </div>
                    <div className="text-2xl font-bold text-green-700">
                      {formatRupiah(totalWithdrawn)}
                    </div>
                  </div>
                  <div className="p-4 bg-muted rounded-lg text-center border">
                    <div className="text-xs text-muted-foreground uppercase mb-1">
                      Jumlah Transaksi
                    </div>
                    <div className="text-2xl font-bold">{approvedWithdrawals.length}</div>
                  </div>
                </div>

                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Cari nama anggota, tipe, atau tanggal..."
                    value={withdrawalSearch}
                    onChange={(e) => setWithdrawalSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>

                {/* Search Results Info */}
                {withdrawalSearch && (
                  <div className="text-sm text-muted-foreground">
                    Menampilkan {filteredWithdrawals.length} dari {approvedWithdrawals.length} transaksi
                  </div>
                )}

                {/* Table - Desktop */}
                <div className="hidden lg:block overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead>Tanggal</TableHead>
                        <TableHead>Nama Anggota</TableHead>
                        <TableHead>Tipe</TableHead>
                        <TableHead>Metode</TableHead>
                        <TableHead className="text-right">Jumlah</TableHead>
                        <TableHead>Catatan</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedWithdrawals.length === 0 ? <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                            {withdrawalSearch ? "Tidak ada hasil yang cocok" : "Belum ada penarikan yang disetujui"}
                          </TableCell>
                        </TableRow> : paginatedWithdrawals.map(withdrawal => <TableRow key={withdrawal.id}>
                            <TableCell className="text-sm">
                              {format(new Date(withdrawal.reviewed_at || withdrawal.requested_at), "dd MMM yyyy", {
                          locale: id
                        })}
                            </TableCell>
                            <TableCell className="font-medium">{withdrawal.member_name}</TableCell>
                            <TableCell>
                              <Badge variant={withdrawal.withdrawal_type === "year_end_bonus" ? "default" : "secondary"}>
                                {withdrawal.withdrawal_type === "year_end_bonus" ? "Bonus Akhir Tahun" : "Reguler"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <Badge variant={withdrawal.withdrawal_method === "transfer" ? "outline" : "secondary"} className="w-fit">
                                  {withdrawal.withdrawal_method === "transfer" ? "Transfer" : "Tunai"}
                                </Badge>
                                {withdrawal.withdrawal_method === "transfer" && withdrawal.bank_account_info && (
                                  <span className="text-xs text-muted-foreground mt-1 max-w-[150px] truncate">
                                    {withdrawal.bank_account_info}
                                  </span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-right font-semibold text-green-600">
                              {formatRupiah(withdrawal.amount)}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">
                              {withdrawal.notes || "-"}
                            </TableCell>
                          </TableRow>)}
                    </TableBody>
                  </Table>
                </div>

                {/* Card View - Mobile */}
                <div className="lg:hidden space-y-3">
                  {paginatedWithdrawals.length === 0 ? <div className="text-center py-8 text-muted-foreground">
                      {withdrawalSearch ? "Tidak ada hasil yang cocok" : "Belum ada penarikan yang disetujui"}
                    </div> : paginatedWithdrawals.map(withdrawal => <Card key={withdrawal.id} className="border-l-4 border-l-green-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-semibold text-sm">{withdrawal.member_name}</h3>
                              <p className="text-xs text-muted-foreground">
                                {format(new Date(withdrawal.reviewed_at || withdrawal.requested_at), "dd MMM yyyy", {
                            locale: id
                          })}
                              </p>
                            </div>
                            <Badge variant={withdrawal.withdrawal_type === "year_end_bonus" ? "default" : "secondary"} className="text-xs">
                              {withdrawal.withdrawal_type === "year_end_bonus" ? "Bonus" : "Reguler"}
                            </Badge>
                          </div>
                          <div className="text-lg font-bold text-green-600">
                            {formatRupiah(withdrawal.amount)}
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant={withdrawal.withdrawal_method === "transfer" ? "outline" : "secondary"} className="text-xs">
                              {withdrawal.withdrawal_method === "transfer" ? "Transfer" : "Tunai"}
                            </Badge>
                            {withdrawal.withdrawal_method === "transfer" && withdrawal.bank_account_info && (
                              <span className="text-xs text-muted-foreground truncate max-w-[150px]">
                                {withdrawal.bank_account_info}
                              </span>
                            )}
                          </div>
                          {withdrawal.notes && <p className="text-xs text-muted-foreground mt-1 truncate">
                              {withdrawal.notes}
                            </p>}
                        </CardContent>
                      </Card>)}
                </div>

                {/* Pagination */}
                {totalWithdrawalPages > 1 && <div className="flex items-center justify-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => setWithdrawalPage(p => Math.max(1, p - 1))} disabled={withdrawalPage === 1}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      Halaman {withdrawalPage} dari {totalWithdrawalPages}
                    </span>
                    <Button variant="outline" size="sm" onClick={() => setWithdrawalPage(p => Math.min(totalWithdrawalPages, p + 1))} disabled={withdrawalPage === totalWithdrawalPages}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>;
}