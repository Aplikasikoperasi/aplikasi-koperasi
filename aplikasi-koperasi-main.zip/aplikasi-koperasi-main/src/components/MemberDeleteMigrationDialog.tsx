import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useSuperCode } from "@/contexts/SuperCodeContext";
import { AlertTriangle, Database, Users } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface MemberDeleteMigrationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  memberToDelete: any;
  onConfirmDelete: () => void;
}

export function MemberDeleteMigrationDialog({
  open,
  onOpenChange,
  memberToDelete,
  onConfirmDelete,
}: MemberDeleteMigrationDialogProps) {
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();
  const [targetMemberId, setTargetMemberId] = useState<string>("");
  const [availableMembers, setAvailableMembers] = useState<any[]>([]);
  const [creditCount, setCreditCount] = useState(0);
  const [customerCount, setCustomerCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [migrating, setMigrating] = useState(false);

  // Fetch available members and affected data counts
  useEffect(() => {
    if (open && memberToDelete) {
      fetchData();
    }
  }, [open, memberToDelete]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch active members excluding the one being deleted
      const { data: members, error: membersError } = await supabase
        .from("members")
        .select("id, full_name, member_number, position")
        .neq("id", memberToDelete.id)
        .eq("is_active", true)
        .order("full_name");

      if (membersError) throw membersError;
      setAvailableMembers(members || []);

      // Count credit applications
      const { count: creditAppsCount, error: creditError } = await supabase
        .from("credit_applications")
        .select("*", { count: "exact", head: true })
        .eq("member_id", memberToDelete.id);

      if (creditError) throw creditError;
      setCreditCount(creditAppsCount || 0);

      // Count customers
      const { count: customersCount, error: customerError } = await supabase
        .from("customers")
        .select("*", { count: "exact", head: true })
        .eq("created_by", memberToDelete.id);

      if (customerError) throw customerError;
      setCustomerCount(customersCount || 0);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        title: "Gagal memuat data",
        description: "Terjadi kesalahan saat mengambil data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMigrationAndDelete = async () => {
    // Validate target member selection
    if (!targetMemberId) {
      toast({
        title: "Pilih Anggota Tujuan",
        description: "Anda harus memilih anggota untuk migrasi data",
        variant: "destructive",
      });
      return;
    }

    setMigrating(true);
    try {
      // Request SuperCode verification
      const isValid = await requireSuperCode("Hapus Anggota");

      if (!isValid) {
        toast({
          title: "Verifikasi Gagal",
          description: "SuperCode salah atau dibatalkan",
          variant: "destructive",
        });
        setMigrating(false);
        return;
      }

      // Get target member details
      const targetMember = availableMembers.find(m => m.id === targetMemberId);

      // Step 1: Migrate credit applications
      if (creditCount > 0) {
        const { error: creditMigrationError } = await supabase
          .from("credit_applications")
          .update({ member_id: targetMemberId })
          .eq("member_id", memberToDelete.id);

        if (creditMigrationError) throw creditMigrationError;
      }

      // Step 2: Migrate customers
      if (customerCount > 0) {
        const { error: customerMigrationError } = await supabase
          .from("customers")
          .update({ created_by: targetMemberId })
          .eq("created_by", memberToDelete.id);

        if (customerMigrationError) throw customerMigrationError;
      }

      // Step 3: Delete the member
      const { error: deleteError } = await supabase
        .from("members")
        .delete()
        .eq("id", memberToDelete.id);

      if (deleteError) throw deleteError;

      // Log success
      toast({
        title: "✅ Berhasil",
        description: `Anggota ${memberToDelete.full_name} berhasil dihapus. Data telah dimigrasikan ke ${targetMember?.full_name}.`,
      });

      // Close dialog and notify parent
      onOpenChange(false);
      onConfirmDelete();
    } catch (error: any) {
      console.error("Error during migration and deletion:", error);
      toast({
        title: "❌ Gagal Menghapus Anggota",
        description: error.message || "Terjadi kesalahan saat menghapus anggota",
        variant: "destructive",
      });
    } finally {
      setMigrating(false);
    }
  };

  const totalAffectedRecords = creditCount + customerCount;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Konfirmasi Hapus Anggota
          </DialogTitle>
          <DialogDescription>
            Sebelum menghapus anggota, data terkait harus dipindahkan ke anggota lain
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-8 text-center text-muted-foreground">
            Memuat data...
          </div>
        ) : (
          <div className="space-y-4">
            {/* Member Info */}
            <Alert>
              <AlertDescription>
                <div className="space-y-1">
                  <p className="font-semibold text-destructive">
                    Anggota yang akan dihapus:
                  </p>
                  <p className="font-medium">{memberToDelete?.full_name}</p>
                  <p className="text-sm text-muted-foreground">
                    {memberToDelete?.member_number} • {memberToDelete?.position}
                  </p>
                </div>
              </AlertDescription>
            </Alert>

            <Separator />

            {/* Data Summary */}
            <div className="space-y-2">
              <p className="font-medium text-sm">Data yang akan dimigrasikan:</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2 p-3 border rounded-lg bg-muted/50">
                  <Database className="h-4 w-4 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Kredit</p>
                    <p className="text-lg font-bold">{creditCount}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-3 border rounded-lg bg-muted/50">
                  <Users className="h-4 w-4 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Nasabah</p>
                    <p className="text-lg font-bold">{customerCount}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Target Member Selection */}
            {totalAffectedRecords > 0 ? (
              <div className="space-y-2">
                <Label htmlFor="target-member">
                  Pilih Anggota Tujuan Migrasi <span className="text-destructive">*</span>
                </Label>
                <Select value={targetMemberId} onValueChange={setTargetMemberId}>
                  <SelectTrigger id="target-member">
                    <SelectValue placeholder="Pilih anggota..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableMembers.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.full_name} ({member.member_number}) - {member.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Semua data kredit dan nasabah akan dipindahkan ke anggota yang dipilih
                </p>
              </div>
            ) : (
              <Alert>
                <AlertDescription>
                  ℹ️ Tidak ada data yang perlu dimigrasikan. Anggota dapat langsung dihapus.
                </AlertDescription>
              </Alert>
            )}

            {/* Warning */}
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <p className="font-semibold mb-1">Peringatan:</p>
                <ul className="text-sm list-disc list-inside space-y-1">
                  <li>Tindakan ini tidak dapat dibatalkan</li>
                  <li>Verifikasi SuperCode akan diminta</li>
                  {totalAffectedRecords > 0 && (
                    <li>Total {totalAffectedRecords} data akan dimigrasikan</li>
                  )}
                </ul>
              </AlertDescription>
            </Alert>
          </div>
        )}

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={migrating}
          >
            Batal
          </Button>
          <Button
            variant="destructive"
            onClick={handleMigrationAndDelete}
            disabled={loading || migrating || (totalAffectedRecords > 0 && !targetMemberId)}
          >
            {migrating ? "Memproses..." : "Hapus Anggota"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
