import { useEffect, useState, useRef, useCallback } from "react";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { RefreshCw, X } from "lucide-react";

// Check if we're in development mode
const isDev = import.meta.env.DEV;

export function PWAUpdatePrompt() {
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  const waitingWorkerRef = useRef<ServiceWorker | null>(null);
  const lastCheckRef = useRef<number>(0);
  const updateTriggeredRef = useRef(false);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const toastRef = useRef<{ dismiss: () => void; update: (props: any) => void } | null>(null);

  // Manual reload function - more reliable approach
  const handleUpdate = useCallback(async () => {
    console.log('🔄 Executing update...');
    
    // Clear countdown interval
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
    
    // Dismiss toast
    toastRef.current?.dismiss();
    
    // Tell waiting worker to activate
    if (waitingWorkerRef.current) {
      waitingWorkerRef.current.postMessage({ type: 'SKIP_WAITING' });
    }
    
    // Clear all caches before reload
    try {
      if ('caches' in window) {
        const names = await caches.keys();
        await Promise.all(names.map(name => caches.delete(name)));
        console.log('🗑️ All caches cleared');
      }
    } catch (err) {
      console.warn('⚠️ Failed to clear caches:', err);
    }
    
    // Force hard reload
    window.location.reload();
  }, []);

  // Cancel update and stop countdown
  const cancelUpdate = useCallback(() => {
    console.log('❌ Update cancelled by user');
    
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
    
    // Dismiss current toast
    toastRef.current?.dismiss();
    
    setCountdown(null);
    setUpdateAvailable(false);
    updateTriggeredRef.current = false;
    
    // Show cancellation toast
    toast({
      title: "⏸️ Update Ditunda",
      description: "Anda bisa update manual melalui tombol di sidebar.",
      duration: 5000,
    });
  }, []);

  // Start countdown and show notification
  const startUpdateCountdown = useCallback(() => {
    if (updateTriggeredRef.current) return; // Prevent duplicate triggers
    updateTriggeredRef.current = true;
    
    console.log('⏱️ Starting 10 second countdown for auto-update...');
    setUpdateAvailable(true);
    setCountdown(10);
    
    // We need to create the action buttons with the handlers
    const createActionButtons = (handleUpdateFn: () => void, cancelUpdateFn: () => void) => (
      <div className="flex gap-2">
        <Button 
          size="sm" 
          onClick={handleUpdateFn}
          className="gap-1"
        >
          <RefreshCw className="h-3 w-3" />
          Update
        </Button>
        <Button 
          size="sm" 
          variant="outline"
          onClick={cancelUpdateFn}
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    );
    
    // Show initial toast with Infinity duration
    const toastResult = toast({
      title: "🔄 Update Tersedia!",
      description: "Aplikasi akan diperbarui dalam 10 detik...",
      duration: 999999999, // Very long duration instead of Infinity
      action: createActionButtons(handleUpdate, cancelUpdate),
    });
    
    toastRef.current = toastResult;
    
    // Start countdown interval
    let timeLeft = 10;
    countdownIntervalRef.current = setInterval(() => {
      timeLeft -= 1;
      setCountdown(timeLeft);
      
      // Update toast description with countdown
      if (timeLeft > 0) {
        toastRef.current?.update({
          title: "🔄 Update Tersedia!",
          description: `Aplikasi akan diperbarui dalam ${timeLeft} detik...`,
          action: createActionButtons(handleUpdate, cancelUpdate),
        });
      } else {
        // Time's up - execute update
        console.log('⏱️ Countdown finished, executing auto-update...');
        
        if (countdownIntervalRef.current) {
          clearInterval(countdownIntervalRef.current);
          countdownIntervalRef.current = null;
        }
        
        // Update toast to show updating message
        toastRef.current?.update({
          title: "⬇️ Memperbarui Aplikasi...",
          description: "Mohon tunggu sebentar...",
          action: undefined,
        });
        
        // Execute update after short delay for user to see the message
        setTimeout(() => {
          handleUpdate();
        }, 500);
      }
    }, 1000);
  }, [handleUpdate, cancelUpdate]);

  useEffect(() => {
    // Cleanup on unmount
    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    // Skip service worker logic in development mode to prevent errors
    if (!('serviceWorker' in navigator)) {
      console.log('ℹ️ Service Worker not supported');
      return;
    }

    // In development, service worker might not work properly - just skip
    if (isDev) {
      console.log('ℹ️ Development mode - skipping PWA update checks');
      return;
    }

    // Throttled update check - 5 minutes minimum between checks
    const checkForUpdate = async (registration: ServiceWorkerRegistration) => {
      const now = Date.now();
      if (now - lastCheckRef.current < 5 * 60 * 1000) {
        return;
      }
      
      lastCheckRef.current = now;
      console.log('🔍 Checking for PWA updates...');
      
      try {
        await registration.update();
      } catch (err) {
        // Log but don't throw - update failures are non-critical
        console.warn('⚠️ Update check failed (non-critical):', err);
      }
    };

    // Setup service worker update detection
    navigator.serviceWorker.ready.then(registration => {
      console.log('✅ Service Worker ready');
      
      // Check if there's already a waiting worker
      if (registration.waiting) {
        console.log('⚠️ Update already waiting');
        waitingWorkerRef.current = registration.waiting;
        startUpdateCountdown();
      }

      // Listen for new service worker installing
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (!newWorker) return;

        console.log('🔄 New service worker found, installing...');

        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            console.log('✅ New service worker installed and waiting');
            waitingWorkerRef.current = newWorker;
            startUpdateCountdown();
          }
        });
      });

      // Periodic check every 5 minutes
      const periodicCheck = setInterval(() => {
        checkForUpdate(registration);
      }, 5 * 60 * 1000);

      // Only check on visibility change if been hidden for more than 5 minutes
      let lastHiddenTime = 0;
      const handleVisibilityChange = () => {
        if (document.visibilityState === 'hidden') {
          lastHiddenTime = Date.now();
        } else if (document.visibilityState === 'visible') {
          if (Date.now() - lastHiddenTime > 5 * 60 * 1000) {
            checkForUpdate(registration);
          }
        }
      };

      document.addEventListener('visibilitychange', handleVisibilityChange);

      return () => {
        clearInterval(periodicCheck);
        document.removeEventListener('visibilitychange', handleVisibilityChange);
      };
    }).catch(err => {
      console.warn('⚠️ Service Worker registration failed:', err);
    });

    // Listen for controller changes
    const handleControllerChange = () => {
      console.log('✅ New service worker activated');
    };

    navigator.serviceWorker.addEventListener('controllerchange', handleControllerChange);

    return () => {
      navigator.serviceWorker.removeEventListener('controllerchange', handleControllerChange);
    };
  }, [startUpdateCountdown]);

  // No UI rendered - toast handles everything
  return null;
}
