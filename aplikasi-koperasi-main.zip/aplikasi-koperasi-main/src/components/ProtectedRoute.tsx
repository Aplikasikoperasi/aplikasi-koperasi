import { useEffect, useState, useRef } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "@/hooks/useUserRole";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: Array<"owner" | "admin" | "sales" | "customer" | "kasir" | "saver">;
  requireAuth?: boolean;
}

export function ProtectedRoute({ 
  children, 
  allowedRoles = ["owner", "admin", "sales", "customer", "kasir", "saver"],
  requireAuth = true 
}: ProtectedRouteProps) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [isCustomerAccount, setIsCustomerAccount] = useState<boolean | null>(null);
  const [isMemberAccount, setIsMemberAccount] = useState<boolean | null>(null);
  const [isInitialCheckComplete, setIsInitialCheckComplete] = useState(false);
  const { role, loading: roleLoading } = useUserRole();
  const location = useLocation();
  const checkInProgress = useRef(false);

  // Helper function to fetch account type (runs outside of auth callback)
  const fetchAccountType = async (userId: string, isMounted: { current: boolean }) => {
    try {
      const [customerResult, memberResult] = await Promise.all([
        supabase.from("customers").select("id").eq("user_id", userId).maybeSingle(),
        supabase.from("members").select("id").eq("user_id", userId).maybeSingle(),
      ]);

      if (!isMounted.current) return;

      setIsCustomerAccount(!!customerResult.data);
      setIsMemberAccount(!!memberResult.data);
    } catch (err) {
      console.error("Account type fetch error:", err);
      if (!isMounted.current) return;
      setIsCustomerAccount(null);
      setIsMemberAccount(null);
    }
  };

  // Re-validate authentication and account type on every route change
  useEffect(() => {
    const isMounted = { current: true };

    const checkAuth = async () => {
      // Prevent multiple simultaneous checks
      if (checkInProgress.current) return;
      checkInProgress.current = true;

      try {
        const { data: { session }, error } = await supabase.auth.getSession();

        if (!isMounted.current) {
          checkInProgress.current = false;
          return;
        }

        if (error) {
          console.error("Auth check error:", error);
          setIsAuthenticated(false);
          setIsCustomerAccount(null);
          setIsMemberAccount(null);
          setIsInitialCheckComplete(true);
          checkInProgress.current = false;
          return;
        }

        setIsAuthenticated(!!session);

        if (session?.user) {
          await fetchAccountType(session.user.id, isMounted);
        } else {
          setIsCustomerAccount(null);
          setIsMemberAccount(null);
        }

        if (isMounted.current) {
          setIsInitialCheckComplete(true);
        }
      } catch (error) {
        console.error("Auth validation error:", error);
        if (isMounted.current) {
          setIsAuthenticated(false);
          setIsCustomerAccount(null);
          setIsMemberAccount(null);
          setIsInitialCheckComplete(true);
        }
      } finally {
        checkInProgress.current = false;
      }
    };

    checkAuth();

    return () => {
      isMounted.current = false;
    };
  }, [location.pathname]); // Re-check on every route change

  // Keep auth state in sync (handles sign-out / token expiry without route change)
  // CRITICAL: Follow Supabase best practices - NO async operations directly in callback
  useEffect(() => {
    const isMounted = { current: true };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted.current) return;

      // Only synchronous state updates inside callback
      setIsAuthenticated(!!session);

      // Defer Supabase calls with setTimeout to prevent deadlock
      if (session?.user) {
        setTimeout(() => {
          if (isMounted.current) {
            fetchAccountType(session.user.id, isMounted).then(() => {
              if (isMounted.current) {
                setIsInitialCheckComplete(true);
              }
            });
          }
        }, 0);
      } else {
        setIsCustomerAccount(null);
        setIsMemberAccount(null);
        setIsInitialCheckComplete(true);
      }
    });

    return () => {
      isMounted.current = false;
      subscription.unsubscribe();
    };
  }, []);

  // Show loading state while checking auth and role
  // CRITICAL: Don't redirect until ALL checks are complete to prevent redirect loops
  if (
    !isInitialCheckComplete ||
    isAuthenticated === null ||
    roleLoading ||
    (isAuthenticated && (isCustomerAccount === null || isMemberAccount === null))
  ) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Redirect to auth if not authenticated
  if (requireAuth && !isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }

  // SECURITY: Check account type restrictions
  // Customer accounts can ONLY access customer-allowed pages
  if (isCustomerAccount && !allowedRoles.includes("customer")) {
    console.warn("[ProtectedRoute] Customer account trying to access non-customer page");
    return <Navigate to="/customer-dashboard" replace />;
  }
  
  // Member/staff accounts cannot access customer-only pages
  if (isMemberAccount && !isCustomerAccount && allowedRoles.length === 1 && allowedRoles[0] === "customer") {
    console.warn("[ProtectedRoute] Member account trying to access customer-only page");
    // Redirect based on role
    switch (role) {
      case "kasir":
        return <Navigate to="/cashier-dashboard" replace />;
      case "sales":
        return <Navigate to="/sales-performance" replace />;
      default:
        return <Navigate to="/dashboard" replace />;
    }
  }

  // Check role authorization for non-customer accounts
  if (role && !isCustomerAccount && !allowedRoles.includes(role)) {
    // Redirect to appropriate dashboard based on role
    switch (role) {
      case "customer":
        return <Navigate to="/customer-dashboard" replace />;
      case "kasir":
        return <Navigate to="/cashier-dashboard" replace />;
      case "sales":
        return <Navigate to="/sales-performance" replace />;
      case "admin":
      case "owner":
        return <Navigate to="/dashboard" replace />;
      default:
        return <Navigate to="/auth" replace />;
    }
  }

  return <>{children}</>;
}
