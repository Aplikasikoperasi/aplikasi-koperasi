import { LayoutGrid, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

interface ViewToggleProps {
  viewMode: 'card' | 'table';
  onToggle: () => void;
}

export function ViewToggle({ viewMode, onToggle }: ViewToggleProps) {
  const isMobile = useIsMobile();
  
  // Only show on desktop
  if (isMobile) return null;

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={onToggle}
      className="gap-2"
    >
      {viewMode === 'table' ? (
        <>
          <LayoutGrid className="h-4 w-4" />
          <span>Card View</span>
        </>
      ) : (
        <>
          <Table className="h-4 w-4" />
          <span>Table View</span>
        </>
      )}
    </Button>
  );
}
