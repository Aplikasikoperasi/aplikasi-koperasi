import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logSystemEvent } from "@/lib/systemLogger";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface UpdateNoKKDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer: {
    id: string;
    full_name: string;
    id_number: string;
  } | null;
  onSuccess: () => void;
}

export function UpdateNoKKDialog({
  open,
  onOpenChange,
  customer,
  onSuccess,
}: UpdateNoKKDialogProps) {
  const [noKK, setNoKK] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!customer) return;
    
    // Validate No. KK
    if (!noKK || noKK.trim() === "") {
      setError("No. KK wajib diisi");
      return;
    }
    
    const noKKPattern = /^\d{16}$/;
    if (!noKKPattern.test(noKK)) {
      setError("No. KK harus tepat 16 digit angka");
      return;
    }
    
    setIsSubmitting(true);
    setError("");
    
    try {
      const { error: updateError } = await supabase
        .from("customers")
        .update({ no_kk: noKK })
        .eq("id", customer.id);
      
      if (updateError) throw updateError;
      
      await logSystemEvent({
        category: "customer_management",
        action: "Update No. KK",
        description: `Memperbarui No. KK nasabah: ${customer.full_name}`,
        metadata: {
          customer_id: customer.id,
          customer_name: customer.full_name,
          no_kk: noKK,
        },
      });
      
      toast.success("No. KK berhasil diperbarui");
      setNoKK("");
      onSuccess();
      onOpenChange(false);
    } catch (err: any) {
      console.error("Error updating No. KK:", err);
      toast.error("Gagal memperbarui No. KK: " + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setNoKK("");
    setError("");
    onOpenChange(false);
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2 text-amber-600">
            <AlertCircle className="h-5 w-5" />
            Data No. KK Diperlukan
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-3">
              <p>
                Nasabah <strong>{customer?.full_name}</strong> ({customer?.id_number}) 
                belum memiliki data No. Kartu Keluarga (KK) yang terdaftar.
              </p>
              <p className="text-amber-600 dark:text-amber-400 font-medium">
                Untuk melanjutkan pengajuan kredit, silakan lengkapi data No. KK terlebih dahulu.
              </p>
              <div className="pt-2">
                <Label htmlFor="no_kk_update">No. Kartu Keluarga (KK) *</Label>
                <Input
                  id="no_kk_update"
                  value={noKK}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value === "" || /^\d+$/.test(value)) {
                      setNoKK(value);
                      setError("");
                    }
                  }}
                  placeholder="Masukkan 16 digit No. KK"
                  maxLength={16}
                  className={error ? "border-destructive" : ""}
                  disabled={isSubmitting}
                />
                {error ? (
                  <p className="text-xs text-destructive mt-1 font-medium">{error}</p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">
                    No. KK digunakan untuk validasi kredit keluarga (16 digit)
                  </p>
                )}
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={handleClose} disabled={isSubmitting}>
            Batal
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleSubmit}
            disabled={isSubmitting || noKK.length !== 16}
            className="bg-primary"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Menyimpan...
              </>
            ) : (
              "Simpan & Lanjutkan"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
