import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Wallet } from "lucide-react";
import { z } from "zod";

const withdrawalSchema = z.object({
  amount: z.number()
    .positive({ message: "Jumlah harus lebih dari 0" })
    .max(999999999, { message: "Jumlah terlalu besar" }),
  withdrawalMethod: z.enum(["cash", "transfer"], { 
    errorMap: () => ({ message: "Metode penarikan tidak valid" }) 
  }),
  bankAccountInfo: z.string()
    .max(500, { message: "Informasi bank terlalu panjang (maks 500 karakter)" })
    .optional()
});

interface MemberBalanceWithdrawalProps {
  memberId: string;
  currentBalance: number;
  onSuccess: () => void;
}

export function MemberBalanceWithdrawal({ memberId, currentBalance, onSuccess }: MemberBalanceWithdrawalProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState("");
  const [withdrawalMethod, setWithdrawalMethod] = useState("cash");
  const [bankAccountInfo, setBankAccountInfo] = useState("");
  const [hasWithdrawnThisMonth, setHasWithdrawnThisMonth] = useState(false);
  const [checkingWithdrawal, setCheckingWithdrawal] = useState(true);

  // Check if already withdrawn this month on mount
  useEffect(() => {
    const checkExistingWithdrawal = async () => {
      try {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

        const { data, error } = await (supabase as any)
          .from("member_balance_withdrawals")
          .select("id")
          .eq("member_id", memberId)
          .eq("withdrawal_type", "regular")
          .gte("requested_at", startOfMonth.toISOString())
          .lte("requested_at", endOfMonth.toISOString())
          .in("status", ["pending", "approved"]);

        if (!error && data && data.length > 0) {
          setHasWithdrawnThisMonth(true);
        }
      } catch (err) {
        console.error("Error checking existing withdrawal:", err);
      } finally {
        setCheckingWithdrawal(false);
      }
    };
    checkExistingWithdrawal();
  }, [memberId]);

  const formatNumber = (value: string) => {
    const numericValue = value.replace(/\D/g, '');
    if (!numericValue) return '';
    return new Intl.NumberFormat('id-ID').format(parseInt(numericValue));
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/\D/g, '');
    setAmount(rawValue);
  };

  const handleSubmit = async () => {
    const withdrawAmount = Number(amount);

    // Validate input with zod
    const validation = withdrawalSchema.safeParse({
      amount: withdrawAmount,
      withdrawalMethod,
      bankAccountInfo: bankAccountInfo.trim()
    });

    if (!validation.success) {
      toast({
        title: "Validasi Gagal",
        description: validation.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Use currentBalance prop which is already validated and passed from parent
      const available = currentBalance;

      // CRITICAL: Strict validation - cannot exceed available balance
      if (withdrawAmount > available) {
        toast({
          title: "Saldo Tidak Mencukupi",
          description: `Jumlah melebihi saldo tersedia. Maksimal: ${formatCurrency(available)}`,
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      // Additional check: ensure available balance is positive
      if (available <= 0) {
        toast({
          title: "Tidak Ada Saldo Tersedia",
          description: "Saldo yang dapat ditarik saat ini: Rp 0",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      if (withdrawalMethod === "transfer" && !bankAccountInfo.trim()) {
        toast({
          title: "Informasi Bank Diperlukan",
          description: "Masukkan informasi rekening bank untuk transfer",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      // Check if already withdrawn this month
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

      const { data: existingWithdrawals, error: checkError } = await (supabase as any)
        .from("member_balance_withdrawals")
        .select("id")
        .eq("member_id", memberId)
        .eq("withdrawal_type", "regular")
        .gte("requested_at", startOfMonth.toISOString())
        .lte("requested_at", endOfMonth.toISOString())
        .in("status", ["pending", "approved"]);

      if (checkError) throw checkError;

      if (existingWithdrawals && existingWithdrawals.length > 0) {
        toast({
          title: "Tidak Dapat Mengajukan",
          description: "Anda sudah mengajukan penarikan saldo regular bulan ini. Maksimal 1x per bulan.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const { error } = await (supabase as any)
        .from("member_balance_withdrawals")
        .insert({
          member_id: memberId,
          amount: withdrawAmount,
          withdrawal_type: "regular",
          withdrawal_method: withdrawalMethod,
          bank_account_info: withdrawalMethod === "transfer" ? bankAccountInfo : null,
          status: "pending",
        });

      if (error) throw error;

      // Send notification to inbox
      await (supabase as any)
        .from("member_messages")
        .insert({
          member_id: memberId,
          title: "Pengajuan Penarikan Saldo",
          message: `Pengajuan penarikan saldo sebesar ${formatCurrency(withdrawAmount)} telah berhasil dikirim dan sedang menunggu persetujuan. Metode: ${withdrawalMethod === "cash" ? "Cash" : "Transfer Bank"}.`,
          type: "info",
        });

      toast({
        title: "Pengajuan Berhasil",
        description: "Pengajuan penarikan saldo telah dikirim dan menunggu persetujuan owner",
      });

      setOpen(false);
      setAmount("");
      setWithdrawalMethod("cash");
      setBankAccountInfo("");
      setHasWithdrawnThisMonth(true); // Disable button immediately after submission
      onSuccess();
    } catch (error: any) {
      console.error("Error submitting withdrawal:", error);
      toast({
        title: "Gagal Mengajukan",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(value);
  };

  // Only show withdrawal button if there's available balance
  if (currentBalance <= 0) {
    return null;
  }

  // Show disabled button if already withdrawn this month
  if (hasWithdrawnThisMonth) {
    return (
      <Button 
        disabled
        size="sm" 
        className="rounded border shadow-sm text-xs font-medium h-6 px-2 text-center opacity-50 cursor-not-allowed"
        title="Anda sudah mengajukan penarikan bulan ini"
      >
        Sudah Diajukan
      </Button>
    );
  }

  return (
    <>
      <Button 
        onClick={() => setOpen(true)} 
        disabled={checkingWithdrawal}
        size="sm" 
        className="rounded border shadow-sm hover:shadow transition-all text-xs font-medium h-6 px-2 text-center text-white bg-blue-700 hover:bg-blue-800"
      >
        {checkingWithdrawal ? "..." : "Penarikan"}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajukan Penarikan Saldo</DialogTitle>
            <DialogDescription>
              Saldo tersedia: {formatCurrency(currentBalance)}. Penarikan hanya bisa dilakukan untuk saldo yang tidak tertahan. Maksimal 1x penarikan per bulan.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah Penarikan (Rp)</Label>
              <Input
                id="amount"
                type="text"
                inputMode="numeric"
                value={formatNumber(amount)}
                onChange={handleAmountChange}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label>Metode Penarikan</Label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="withdrawal-method"
                    value="cash"
                    checked={withdrawalMethod === "cash"}
                    onChange={(e) => setWithdrawalMethod(e.target.value)}
                    className="w-4 h-4 text-primary"
                  />
                  <span className="text-sm">Cash</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="withdrawal-method"
                    value="transfer"
                    checked={withdrawalMethod === "transfer"}
                    onChange={(e) => setWithdrawalMethod(e.target.value)}
                    className="w-4 h-4 text-primary"
                  />
                  <span className="text-sm">Transfer Bank</span>
                </label>
              </div>
            </div>

            {withdrawalMethod === "transfer" && (
              <div className="space-y-2">
                <Label htmlFor="bank-info">Informasi Rekening Bank</Label>
                <Textarea
                  id="bank-info"
                  value={bankAccountInfo}
                  onChange={(e) => setBankAccountInfo(e.target.value)}
                  placeholder="Nama Bank, Nomor Rekening, Nama Pemilik Rekening"
                  rows={4}
                />
                <p className="text-xs text-muted-foreground">
                  Contoh: BCA - 1234567890 - Atas Nama John Doe
                </p>
              </div>
            )}

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setOpen(false)} className="flex-1">
                Batal
              </Button>
              <Button onClick={handleSubmit} disabled={loading} className="flex-1">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Ajukan
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
