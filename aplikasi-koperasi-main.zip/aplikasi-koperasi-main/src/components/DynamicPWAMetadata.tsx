import { useEffect } from "react";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";

/**
 * Update metadata (title/meta tags/icons) based on business information.
 * TIDAK mengubah manifest link agar PWA install tetap berfungsi.
 */
export const DynamicPWAMetadata = () => {
  const { businessName, businessDescription, logoUrl } = useBusinessInfo();

  useEffect(() => {
    if (!businessName) return;

    // Update document title
    document.title = businessName;

    // Helper: update or create <meta name="...">
    const updateMetaTag = (name: string, content: string) => {
      let element = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
      if (!element) {
        element = document.createElement("meta");
        element.name = name;
        document.head.appendChild(element);
      }
      element.content = content;
    };

    // Helper: update or create <meta property="...">
    const updatePropertyTag = (property: string, content: string) => {
      let element = document.querySelector(
        `meta[property="${property}"]`
      ) as HTMLMetaElement | null;
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute("property", property);
        document.head.appendChild(element);
      }
      element.content = content;
    };

    // Helper: update or create <link rel="..." sizes="..." href="...">
    const updateLinkTag = (rel: string, href: string, sizes?: string) => {
      const selector = sizes ? `link[rel="${rel}"][sizes="${sizes}"]` : `link[rel="${rel}"]`;
      let element = document.querySelector(selector) as HTMLLinkElement | null;
      if (!element) {
        element = document.createElement("link");
        element.rel = rel;
        if (sizes) element.setAttribute("sizes", sizes);
        document.head.appendChild(element);
      }
      element.href = href;
      return element;
    };

    // App name
    updateMetaTag("apple-mobile-web-app-title", businessName);
    updateMetaTag("application-name", businessName);

    // Description
    if (businessDescription) {
      updateMetaTag("description", businessDescription);
      updatePropertyTag("og:description", businessDescription);
      updateMetaTag("twitter:description", businessDescription);
    }

    // Open Graph / Twitter title
    updatePropertyTag("og:title", businessName);
    updateMetaTag("twitter:title", businessName);

    // Favicon + Apple touch icons (untuk browser, bukan PWA manifest)
    if (logoUrl) {
      updateLinkTag("icon", logoUrl);
      updateLinkTag("apple-touch-icon", logoUrl);
      updateLinkTag("apple-touch-icon-precomposed", logoUrl);

      const appleSizes = [
        "57x57",
        "60x60",
        "72x72",
        "76x76",
        "114x114",
        "120x120",
        "144x144",
        "152x152",
        "167x167",
        "180x180",
      ];
      appleSizes.forEach((size) => {
        updateLinkTag("apple-touch-icon", logoUrl, size);
      });

      updatePropertyTag("og:image", logoUrl);
      updateMetaTag("twitter:image", logoUrl);
    }

    console.log("[DynamicPWAMetadata] Updated metadata:", {
      businessName,
      hasLogo: !!logoUrl,
    });
  }, [businessName, businessDescription, logoUrl]);

  return null;
};
