import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Printer, User } from "lucide-react";
import { formatRupiah } from "@/lib/utils";
import { NamePlateData, generateNamePlatePDF } from "@/lib/generateNamePlatePDF";

interface NamePlatePreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  namePlateData: NamePlateData;
}

export function NamePlatePreviewDialog({
  open,
  onOpenChange,
  namePlateData,
}: NamePlatePreviewDialogProps) {
  const handlePrint = async () => {
    await generateNamePlatePDF(namePlateData, 'print');
  };

  const handleDownload = async () => {
    await generateNamePlatePDF(namePlateData, 'download');
  };

  // Format application date
  const formattedAppDate = namePlateData.applicationDate 
    ? new Date(namePlateData.applicationDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
    : '-';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Preview Name Plate</DialogTitle>
        </DialogHeader>
        
        <div className="p-4">
          {/* Name Plate Preview */}
          <div className="border-4 border-blue-500 rounded-lg p-3 bg-white">
            {/* Header - Logo and Business Name (bigger) */}
            <div className="flex items-center justify-center gap-3 mb-2">
              {namePlateData.logoUrl && (
                <img 
                  src={namePlateData.logoUrl} 
                  alt="Logo" 
                  className="h-10 w-10 object-contain"
                />
              )}
              <h2 className="text-xl font-bold text-blue-800">
                {namePlateData.businessName || 'Sistem Kredit'}
              </h2>
            </div>

            {/* Blue line */}
            <div className="h-0.5 bg-blue-500 mb-3"></div>

            {/* Customer Photo + Name + ID section */}
            <div className="flex items-start gap-3 mb-2">
              {/* Customer Photo */}
              <div className="flex-shrink-0">
                {namePlateData.customerPhotoUrl ? (
                  <img 
                    src={namePlateData.customerPhotoUrl} 
                    alt="Foto Nasabah" 
                    className="w-12 h-12 object-cover rounded border border-gray-200"
                  />
                ) : (
                  <div className="w-12 h-12 bg-gray-100 rounded border border-gray-300 flex items-center justify-center">
                    <User className="h-6 w-6 text-gray-400" />
                  </div>
                )}
              </div>
              
              {/* Name and ID */}
              <div className="flex-1">
                <p className="text-[9px] text-gray-500 font-semibold tracking-wider">NAMA NASABAH</p>
                <p className="text-sm font-bold text-gray-900 leading-tight">{namePlateData.customerName.toUpperCase()}</p>
                <p className="text-[9px] text-gray-500 font-semibold tracking-wider mt-1">NO. ID NASABAH</p>
                <p className="text-xs font-bold text-gray-700">{namePlateData.customerId}</p>
              </div>
            </div>

            {/* Dashed separator */}
            <div className="border-t border-dashed border-gray-400 mb-2"></div>

            {/* Details Grid - 2 columns with application date */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-center">
              <div>
                <p className="text-[8px] text-gray-500 font-semibold tracking-wider">JUMLAH PINJAMAN</p>
                <p className="text-sm font-bold text-green-600">{formatRupiah(namePlateData.loanAmount)}</p>
              </div>
              <div>
                <p className="text-[8px] text-gray-500 font-semibold tracking-wider">TENOR</p>
                <p className="text-sm font-bold text-purple-600">{namePlateData.tenorMonths} BULAN</p>
              </div>
              <div className="mt-1">
                <p className="text-[8px] text-gray-500 font-semibold tracking-wider">TGL PENGAJUAN</p>
                <p className="text-xs font-bold text-gray-700">{formattedAppDate}</p>
              </div>
              <div className="mt-1">
                <p className="text-[8px] text-gray-500 font-semibold tracking-wider">NO. APLIKASI</p>
                <p className="text-[10px] font-bold text-gray-700">{namePlateData.applicationNumber}</p>
              </div>
              <div className="col-span-2 mt-1">
                <p className="text-[8px] text-gray-500 font-semibold tracking-wider">PJ KREDIT</p>
                <p className="text-xs font-bold text-blue-600">{namePlateData.memberName?.toUpperCase() || '-'}</p>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="flex-row gap-2 justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Tutup
          </Button>
          <Button 
            variant="outline" 
            className="bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
            onClick={handlePrint}
          >
            <Printer className="h-4 w-4 mr-2" />
            Cetak
          </Button>
          <Button onClick={handleDownload}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
