import { useState, useEffect, useMemo } from "react";
import { ResponsiveDialog, ResponsiveDialogContent, ResponsiveDialogHeader, ResponsiveDialogTitle } from "@/components/ui/responsive-dialog";
import { ClickableAvatar } from "@/components/ClickableAvatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CreditScoreStars } from "@/components/CreditScoreStars";
import { formatDate, calculateAge, formatRupiah } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { Pencil, Trash2, ShieldAlert, CheckCircle, XCircle, FileText, FileEdit, UserPlus, AlertTriangle, Users } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { LazyCustomerChangeRequestDialog as CustomerChangeRequestDialog } from "@/components/LazyDialogs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LazyInstallmentHistoryDialog as InstallmentHistoryDialog } from "@/components/LazyDialogs";
import { AchievementBadge } from "@/components/AchievementBadge";
import { PrefetchedCustomerData } from "@/hooks/useCustomerDataPrefetch";

interface CustomerDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer: any;
  prefetchedData?: PrefetchedCustomerData | null;
  onEdit?: (customer: any) => void;
  onDelete?: (customer: any) => void;
  onBlock?: (customer: any) => void;
  onApprove?: (customer: any) => void;
  onReject?: (customer: any) => void;
  onApplyCredit?: (customer: any) => void;
}
export function CustomerDetailDialog({
  open,
  onOpenChange,
  customer,
  prefetchedData,
  onEdit,
  onDelete,
  onBlock,
  onApprove,
  onReject,
  onApplyCredit
}: CustomerDetailDialogProps) {
  const {
    isOwner,
    isAdmin,
    isSales
  } = useUserRole();
  const canManage = isOwner || isAdmin;
  const isPending = customer?.status === 'pending';
  const [showChangeRequestDialog, setShowChangeRequestDialog] = useState(false);
  const [creatingAuth, setCreatingAuth] = useState(false);
  // CRITICAL: Credit score berasal HANYA dari database, tidak ada fallback atau modifikasi
  const [currentCreditScore, setCurrentCreditScore] = useState(customer?.credit_score ?? 0);
  const [penaltyRate, setPenaltyRate] = useState(2.0);
  const {
    toast
  } = useToast();
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null);
  const [activeApplications, setActiveApplications] = useState<any[]>([]);
  const [loadingActiveApps, setLoadingActiveApps] = useState(false);
  const [selectedAppForHistory, setSelectedAppForHistory] = useState<any>(null);
  const [showInstallmentHistory, setShowInstallmentHistory] = useState(false);
  const [prefetchedInstallments, setPrefetchedInstallments] = useState<Record<string, any[]>>({});
  const [prefetchingInstallments, setPrefetchingInstallments] = useState(false);
  const [creditScoreBreakdown, setCreditScoreBreakdown] = useState<any>(null);
  const [loadingBreakdown, setLoadingBreakdown] = useState(false);
  const [achievementBadge, setAchievementBadge] = useState<any>(null);
  const [overdueDetails, setOverdueDetails] = useState<{
    totalOverdueAmount: number;
    totalPenaltyAmount: number;
    overdueInstallments: any[];
  } | null>(null);
  const [isBlocked, setIsBlocked] = useState(false);
  const [hasCreditHistory, setHasCreditHistory] = useState(true); // Default true to hide delete until checked
  const [familyMembers, setFamilyMembers] = useState<Array<{
    id: string;
    full_name: string;
    id_number: string;
    photo_url: string | null;
    has_active_credit: boolean;
    credit_status: string;
  }>>([]);
  const [loadingFamilyMembers, setLoadingFamilyMembers] = useState(false);
  
  // Check if customer has any credit applications (for delete button visibility)
  useEffect(() => {
    if (!open || !customer?.id) {
      setHasCreditHistory(true);
      return;
    }
    
    const checkCreditHistory = async () => {
      const { count, error } = await supabase
        .from("credit_applications")
        .select("id", { count: 'exact', head: true })
        .eq("customer_id", customer.id);
      
      if (!error) {
        setHasCreditHistory((count || 0) > 0);
      }
    };
    
    checkCreditHistory();
  }, [customer?.id, open]);

  useEffect(() => {
    if (open && customer?.id) {
      // If we have prefetched data, use it immediately for instant loading
      if (prefetchedData) {
        setPenaltyRate(prefetchedData.penaltyRate);
        setCreditScoreBreakdown(prefetchedData.creditScoreBreakdown);
        setAchievementBadge(prefetchedData.achievementBadge);
        setActiveApplications(prefetchedData.activeApplications);
        setOverdueDetails(prefetchedData.overdueDetails);
        setLoadingBreakdown(false);
        setLoadingActiveApps(false);
      } else {
        // Clear previous customer's data if no prefetch available
        setCreditScoreBreakdown(null);
        setAchievementBadge(null);
        setActiveApplications([]);
        setOverdueDetails(null);
      }
    }
  }, [customer?.id, open, prefetchedData]);

  // Check if customer is blocked
  useEffect(() => {
    if (!open || !customer?.id) {
      setIsBlocked(false);
      return;
    }
    
    const checkBlockedStatus = async () => {
      const { data, error } = await supabase
        .from("blocked_customers")
        .select("id")
        .eq("customer_id", customer.id)
        .maybeSingle();
      
      if (!error && data) {
        setIsBlocked(true);
      } else {
        setIsBlocked(false);
      }
    };
    
    checkBlockedStatus();

    // Listen for customer restoration event to re-check blocked status
    const handleCustomerRestored = () => {
      checkBlockedStatus();
    };
    
    window.addEventListener('customer-restored', handleCustomerRestored);
    return () => window.removeEventListener('customer-restored', handleCustomerRestored);
  }, [customer?.id, open]);

  // Load family members with the same No. KK
  useEffect(() => {
    if (!open || !customer?.id || !customer?.no_kk) {
      setFamilyMembers([]);
      return;
    }
    
    const loadFamilyMembers = async () => {
      setLoadingFamilyMembers(true);
      try {
        // Get all customers with the same no_kk (excluding current customer)
        const { data: familyData, error } = await supabase
          .from("customers")
          .select(`
            id,
            full_name,
            id_number,
            photo_url,
            status
          `)
          .eq("no_kk", customer.no_kk)
          .neq("id", customer.id)
          .eq("status", "approved");
        
        if (error) {
          console.error("Error loading family members:", error);
          return;
        }
        
        if (!familyData || familyData.length === 0) {
          setFamilyMembers([]);
          return;
        }
        
        // Check which family members have active credit
        const familyIds = familyData.map(f => f.id);
        const { data: activeCredits } = await supabase
          .from("credit_applications")
          .select("customer_id, status")
          .in("customer_id", familyIds)
          .in("status", ["approved", "disbursed", "active"]);
        
        const activeCreditsMap = new Map<string, string>();
        activeCredits?.forEach(c => {
          activeCreditsMap.set(c.customer_id, c.status);
        });
        
        const familyWithCreditStatus = familyData.map(f => ({
          ...f,
          has_active_credit: activeCreditsMap.has(f.id),
          credit_status: activeCreditsMap.get(f.id) || "none"
        }));
        
        setFamilyMembers(familyWithCreditStatus);
      } catch (error) {
        console.error("Error loading family members:", error);
      } finally {
        setLoadingFamilyMembers(false);
      }
    };
    
    loadFamilyMembers();
  }, [customer?.id, customer?.no_kk, open]);

  // Load current member ID for sales users
  useEffect(() => {
    if (!isSales || !open) return;
    const loadMemberId = async () => {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (user) {
        const {
          data: memberData
        } = await supabase.from("members").select("id").eq("user_id", user.id).maybeSingle();
        setCurrentMemberId(memberData?.id || null);
      }
    };
    loadMemberId();
  }, [isSales, open]);

  // Reset states when customer changes or dialog opens, but use prefetched data if available

  // Prefetch installments for all active applications to make opening history instant
  useEffect(() => {
    if (!open || activeApplications.length === 0) return;
    let cancelled = false;
    const run = async () => {
      try {
        setPrefetchingInstallments(true);
        const ids = activeApplications.map((a: any) => a.id);
        const { data, error } = await supabase
          .from('installments')
          .select('id, application_id, installment_number, due_date, total_amount, paid_amount, frozen_penalty, frozen_days_overdue, status, principal_paid, paid_at')
          .in('application_id', ids)
          .order('application_id', { ascending: true })
          .order('installment_number', { ascending: true });
        if (!cancelled && !error && data) {
          const map: Record<string, any[]> = {};
          for (const row of data) {
            if (!map[row.application_id]) map[row.application_id] = [];
            map[row.application_id].push(row);
          }
          setPrefetchedInstallments(map);
        }
      } finally {
        if (!cancelled) setPrefetchingInstallments(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [open, activeApplications]);

  // Derive counts for penalty installments (paid with penalty + current overdue) from prefetched data
  const penaltyCounters = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    let paidPenalty = 0;
    let currentOverdue = 0;
    for (const app of activeApplications) {
      const list = prefetchedInstallments[app.id] || [];
      for (const inst of list) {
        const due = new Date(inst.due_date);
        due.setHours(0, 0, 0, 0);
        // Count paid with penalty: ONLY check frozen_penalty (already calculated based on payment_date vs due_date)
        // CRITICAL: Do NOT use paid_at as it's just a timestamp, not the actual payment date
        if (inst.principal_paid) {
          const frozen = Number(inst.frozen_penalty || 0);
          if (frozen > 0) paidPenalty++;
        } else {
          // Running overdue: not paid principal and past due date
          if (today.getTime() > due.getTime()) currentOverdue++;
        }
      }
    }
    return { paidPenalty, currentOverdue };
  }, [activeApplications, prefetchedInstallments]);

  // running_penalty = angsuran dengan denda berjalan (partial dengan frozen_penalty > 0)
  // paid_with_penalty = angsuran yang sudah lunas tapi pernah terlambat
  const runningPenaltyCount = (creditScoreBreakdown?.running_penalty || 0);
  const historicalPenaltyCount = creditScoreBreakdown?.paid_with_penalty || 0;

  // Load all customer data using edge function so everything comes in one request
  useEffect(() => {
    if (!customer?.id || !open) return;
    
    const loadData = async () => {
      try {
        console.log('🔍 [CustomerDetail] Loading data for customer (edge fn):', customer.id);
        setLoadingBreakdown(true);
        setLoadingActiveApps(true);

        const { data, error } = await supabase.functions.invoke('customer-detail', {
          body: { customerId: customer.id },
        });

        console.log('📦 [CustomerDetail] Edge Response:', { data, error });

        if (error) throw error;

        if (data) {
          const result = data as any;
          console.log('✅ [CustomerDetail] Data loaded:', {
            hasCreditScoreBreakdown: !!result.creditScoreBreakdown,
            hasAchievementBadge: !!result.achievementBadge,
            activeAppsCount: result.activeApplications?.length || 0,
            hasOverdueDetails: !!result.overdueDetails,
            penaltyRate: result.penaltyRate,
          });
          
          setPenaltyRate(result.penaltyRate || 2.0);
          setCreditScoreBreakdown(result.creditScoreBreakdown);
          setAchievementBadge(result.achievementBadge);
          setActiveApplications(result.activeApplications || []);
          setOverdueDetails(result.overdueDetails);
        } else {
          console.warn('⚠️ [CustomerDetail] No data returned from edge function');
        }

        setLoadingBreakdown(false);
        setLoadingActiveApps(false);
      } catch (error) {
        console.error('❌ [CustomerDetail] Error loading customer data (edge):', error);
        setLoadingBreakdown(false);
        setLoadingActiveApps(false);
        toast({
          title: "Error",
          description: "Gagal memuat data detail nasabah",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [customer?.id, open, toast]);

  // Set up realtime subscription for credit score updates
  useEffect(() => {
    if (!customer?.id) return;
    // CRITICAL: Gunakan nilai credit_score langsung dari database tanpa fallback
    setCurrentCreditScore(customer.credit_score ?? 0);
    const channel = supabase.channel(`customer-detail-${customer.id}`).on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'customers',
      filter: `id=eq.${customer.id}`,
    }, (payload) => {
      console.log('🔄 Customer credit score updated:', payload);
      if (payload.new && 'credit_score' in payload.new) {
        // CRITICAL: Gunakan nilai credit_score langsung dari database tanpa fallback
        setCurrentCreditScore((payload.new as any).credit_score ?? 0);
      }
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [customer?.id, customer?.credit_score]);
  if (!customer) return null;
  const handleCreateAuthAccount = async () => {
    if (!customer.date_of_birth) {
      toast({
        title: "Data Tidak Lengkap",
        description: "Tanggal lahir nasabah harus diisi terlebih dahulu",
        variant: "destructive"
      });
      return;
    }
    setCreatingAuth(true);
    try {
      const {
        data,
        error
      } = await supabase.functions.invoke('create-customer-auth', {
        body: {
          customerId: customer.id,
          idNumber: customer.id_number,
          dateOfBirth: customer.date_of_birth,
          fullName: customer.full_name
        }
      });
      if (error) throw error;
      if (data.success) {
        toast({
          title: "Akun Login Berhasil Dibuat",
          description: `No. ID User: ${customer.id}\nPassword: ${formatPasswordFromDOB(customer.date_of_birth)}`
        });
        // Reload to show updated user_id
        window.location.reload();
      } else {
        throw new Error(data.error || 'Gagal membuat akun');
      }
    } catch (error: any) {
      console.error('Error creating auth account:', error);
      toast({
        title: "Gagal Membuat Akun Login",
        description: error.message || "Terjadi kesalahan saat membuat akun login",
        variant: "destructive"
      });
    } finally {
      setCreatingAuth(false);
    }
  };
  const formatPasswordFromDOB = (dob: string) => {
    const date = new Date(dob);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}${month}${year}`;
  };
  return <ResponsiveDialog open={open} onOpenChange={onOpenChange}>
      <ResponsiveDialogContent className="max-w-md w-full max-h-[90vh]">
        <ResponsiveDialogHeader>
          <ResponsiveDialogTitle>Detail Nasabah</ResponsiveDialogTitle>
        </ResponsiveDialogHeader>

        <div className="w-full max-w-full space-y-4 overflow-hidden">
          {/* Photo & Basic Info */}
          <div className="flex flex-col items-center gap-3">
            <ClickableAvatar
              src={customer.photo_url}
              alt={customer.full_name}
              fallback={customer.full_name?.substring(0, 2).toUpperCase()}
              className="h-20 w-20 sm:h-24 sm:w-24"
              fallbackClassName="bg-primary/10 text-primary text-xl sm:text-2xl"
            />
            <div className="text-center w-full px-2">
              <h3 className="font-bold text-base sm:text-lg truncate">{customer.full_name}</h3>
              <div className="flex gap-2 justify-center items-center mt-1 flex-wrap">
                <Badge variant={customer.status === 'approved' ? 'default' : customer.status === 'pending' ? 'secondary' : customer.status === 'rejected' ? 'destructive' : 'default'} className="text-xs">
                  {customer.status === 'approved' ? 'Disetujui' : customer.status === 'pending' ? 'Menunggu' : customer.status === 'rejected' ? 'Ditolak' : 'Aktif'}
                </Badge>
                {isBlocked && (
                  <Badge variant="destructive" className="text-xs gap-1">
                    <ShieldAlert className="h-3 w-3" />
                    Diblokir
                  </Badge>
                )}
              </div>
            </div>
            <CreditScoreStars creditScore={currentCreditScore} restorationStatus={customer.restoration_status || 'never_restored'} />
            
            {/* Achievement Badge */}
            {achievementBadge && achievementBadge.badge_level !== 'none' && <div className="mt-2">
                <AchievementBadge badgeLevel={achievementBadge.badge_level} badgeName={achievementBadge.badge_name} badgeDescription={achievementBadge.badge_description} consecutivePayments={achievementBadge.consecutive_on_time_payments} onTimePercentage={achievementBadge.on_time_percentage} size="md" showDetails={true} />
              </div>}
          </div>

          {/* Credit Score Breakdown */}
          {creditScoreBreakdown && <>
              <div className="bg-muted/30 rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-primary" />
                  <h4 className="font-semibold text-sm">Detail Skor Kredit</h4>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex justify-between p-2 bg-background rounded">
                    <span className="text-muted-foreground">Total Angsuran:</span>
                    <span className="font-semibold">{creditScoreBreakdown.total_installments}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-green-50 dark:bg-green-950/20 rounded">
                    <span className="text-muted-foreground">Tepat Waktu:</span>
                    <span className="font-semibold text-green-600 dark:text-green-400">{creditScoreBreakdown.on_time_no_penalty}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-yellow-50 dark:bg-yellow-950/20 rounded">
                    <span className="text-muted-foreground">Denda Berjalan:</span>
                    <span className="font-semibold text-yellow-600 dark:text-yellow-400">{runningPenaltyCount}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-amber-50 dark:bg-amber-950/20 rounded">
                    <span className="text-muted-foreground">Pernah Dibayar dgn Denda:</span>
                    <span className="font-semibold text-amber-600 dark:text-amber-400">{historicalPenaltyCount}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-red-50 dark:bg-red-950/20 rounded">
                    <span className="text-muted-foreground">Angsuran Jatuh Tempo    </span>
                    <span className="font-semibold text-red-600 dark:text-red-400">{creditScoreBreakdown.overdue_no_payment}</span>
                  </div>
                </div>
                
                {/* Pembayaran Partial */}
                {creditScoreBreakdown.partial_75_plus + creditScoreBreakdown.partial_50_74 + creditScoreBreakdown.partial_25_49 + creditScoreBreakdown.partial_1_24 > 0 && <div className="border-t border-border pt-2 mt-2">
                    <p className="text-xs font-medium mb-1.5">Pembayaran Partial:</p>
                    <div className="grid grid-cols-2 gap-1.5 text-xs">
                      {creditScoreBreakdown.partial_75_plus > 0 && <div className="flex justify-between p-1.5 bg-orange-50 dark:bg-orange-950/20 rounded">
                          <span className="text-muted-foreground">75-99%:</span>
                          <span className="font-semibold text-orange-600 dark:text-orange-400">{creditScoreBreakdown.partial_75_plus}</span>
                        </div>}
                      {creditScoreBreakdown.partial_50_74 > 0 && <div className="flex justify-between p-1.5 bg-orange-50 dark:bg-orange-950/20 rounded">
                          <span className="text-muted-foreground">50-74%:</span>
                          <span className="font-semibold text-orange-600 dark:text-orange-400">{creditScoreBreakdown.partial_50_74}</span>
                        </div>}
                      {creditScoreBreakdown.partial_25_49 > 0 && <div className="flex justify-between p-1.5 bg-orange-50 dark:bg-orange-950/20 rounded">
                          <span className="text-muted-foreground">25-49%:</span>
                          <span className="font-semibold text-orange-600 dark:text-orange-400">{creditScoreBreakdown.partial_25_49}</span>
                        </div>}
                      {creditScoreBreakdown.partial_1_24 > 0 && <div className="flex justify-between p-1.5 bg-orange-50 dark:bg-orange-950/20 rounded">
                          <span className="text-muted-foreground">1-24%:</span>
                          <span className="font-semibold text-orange-600 dark:text-orange-400">{creditScoreBreakdown.partial_1_24}</span>
                        </div>}
                    </div>
                  </div>}

                {/* Status Angsuran Mendatang */}
                {creditScoreBreakdown.upcoming_installments + creditScoreBreakdown.due_today > 0 && <div className="border-t border-border pt-2 mt-2">
                    <p className="text-xs font-medium mb-1.5">Status Mendatang:</p>
                    <div className="grid grid-cols-2 gap-1.5 text-xs">
                      {creditScoreBreakdown.upcoming_installments > 0 && <div className="flex justify-between p-1.5 bg-blue-50 dark:bg-blue-950/20 rounded">
                          <span className="text-muted-foreground">Belum Jatuh Tempo:</span>
                          <span className="font-semibold text-blue-600 dark:text-blue-400">{creditScoreBreakdown.upcoming_installments}</span>
                        </div>}
                      {creditScoreBreakdown.due_today > 0 && <div className="flex justify-between p-1.5 bg-amber-50 dark:bg-amber-950/20 rounded">
                          <span className="text-muted-foreground">Jatuh Tempo Hari Ini:</span>
                          <span className="font-semibold text-amber-600 dark:text-amber-400">{creditScoreBreakdown.due_today}</span>
                        </div>}
                    </div>
                  </div>}
              </div>
            </>}

          {/* Overdue Details for Nasabah Macet */}
          {achievementBadge?.badge_level === 'overdue' && overdueDetails && (
            <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg p-3 space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                <h4 className="font-semibold text-sm text-red-700 dark:text-red-300">Rincian Tunggakan</h4>
              </div>
              
              {/* Summary */}
              <div className="grid grid-cols-1 gap-2">
                <div className="flex justify-between items-center p-2.5 bg-white dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                  <span className="text-xs font-medium text-muted-foreground">Total Angsuran Tertunggak:</span>
                  <span className="text-sm font-bold text-red-600 dark:text-red-400">
                    {formatRupiah(overdueDetails.totalOverdueAmount)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2.5 bg-white dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                  <span className="text-xs font-medium text-muted-foreground">Total Denda:</span>
                  <span className="text-sm font-bold text-red-600 dark:text-red-400">
                    {formatRupiah(overdueDetails.totalPenaltyAmount)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2.5 bg-red-100 dark:bg-red-900/40 rounded border-2 border-red-300 dark:border-red-700">
                  <span className="text-xs font-bold text-red-700 dark:text-red-300">TOTAL KESELURUHAN:</span>
                  <span className="text-base font-bold text-red-700 dark:text-red-300">
                    {formatRupiah(overdueDetails.totalOverdueAmount + overdueDetails.totalPenaltyAmount)}
                  </span>
                </div>
              </div>

              {/* Overdue Installments List */}
              <div className="border-t border-red-200 dark:border-red-800 pt-2">
                <p className="text-xs font-semibold mb-2 text-red-700 dark:text-red-300">
                  Daftar Angsuran Menunggak ({overdueDetails.overdueInstallments.length}):
                </p>
                <div className="space-y-1.5 max-h-32 overflow-y-auto">
                  {overdueDetails.overdueInstallments.map((inst: any) => {
                    const unpaidAmount = (inst.total_amount || 0) - (inst.paid_amount || 0);
                    const daysOverdue = Math.max(0, Math.floor((new Date().getTime() - new Date(inst.due_date).getTime()) / (1000 * 60 * 60 * 24)));
                    
                    // Calculate current penalty dynamically
                    const currentPenalty = unpaidAmount * (penaltyRate / 100) * daysOverdue;
                    const roundedPenalty = Math.ceil(currentPenalty / 1000) * 1000;
                    
                    return (
                      <div key={inst.id} className="p-2 bg-white dark:bg-red-900/20 rounded text-xs border border-red-100 dark:border-red-800">
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-medium text-red-700 dark:text-red-300">
                            {inst.credit_applications?.application_number} - Angsuran #{inst.installment_number}
                          </span>
                          <span className="font-bold text-red-600 dark:text-red-400">
                            {formatRupiah(unpaidAmount)}
                          </span>
                        </div>
                        <div className="flex justify-between text-[10px] text-muted-foreground">
                          <span>Jatuh tempo: {formatDate(inst.due_date)}</span>
                          <span className="text-red-600 dark:text-red-400 font-medium">
                            {daysOverdue} hari terlambat
                          </span>
                        </div>
                        {roundedPenalty > 0 && (
                          <div className="mt-1 text-[10px] text-red-600 dark:text-red-400 font-medium">
                            Denda saat ini: {formatRupiah(roundedPenalty)}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          <Separator />

          {/* Details */}
          <div className="space-y-2 text-xs sm:text-sm">
            <DetailRow label="No. ID" value={customer.id_number || "-"} valueClassName="font-bold" />
            <DetailRow label="NIK" value={customer.nik || "-"} />
            <DetailRow label="No. KK" value={customer.no_kk || "-"} />
            <DetailRow label="Tanggal Lahir" value={customer.date_of_birth ? `${formatDate(customer.date_of_birth)} (${calculateAge(customer.date_of_birth)} tahun)` : "-"} />
            <DetailRow label="No. Telepon" value={customer.phone || "-"} />
            <DetailRow label="Pekerjaan" value={customer.occupation || "-"} />
            <DetailRow label="Alamat" value={customer.address || "-"} />
            <DetailRow label="Terdaftar" value={formatDate(customer.effective_registration_date || customer.created_at)} />
            {customer.creator && <DetailRow label="Didaftarkan Oleh" value={`${customer.creator.full_name}${customer.creator.position ? ` (${customer.creator.position})` : ''}`} />}
          </div>

          {/* Family Members Section */}
          {customer.no_kk && familyMembers.length > 0 && (
            <>
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-primary" />
                  <h4 className="font-semibold text-sm">Anggota Keluarga ({familyMembers.length})</h4>
                </div>
                <p className="text-xs text-muted-foreground">
                  Nasabah lain dengan No. KK yang sama: {customer.no_kk}
                </p>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {familyMembers.map(member => (
                    <div 
                      key={member.id} 
                      className="flex items-center gap-3 p-2 bg-muted/30 rounded-lg border border-border/50"
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={member.photo_url || undefined} alt={member.full_name} />
                        <AvatarFallback className="text-xs bg-primary/10 text-primary">
                          {member.full_name?.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium truncate">{member.full_name}</p>
                        <p className="text-[10px] text-muted-foreground">{member.id_number}</p>
                      </div>
                      {member.has_active_credit ? (
                        <Badge variant="destructive" className="text-[10px] px-1.5 py-0.5">
                          Kredit Aktif
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0.5 text-muted-foreground">
                          Tidak Ada Kredit
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Active Credit Applications */}
          {activeApplications.length > 0 && <>
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-primary" />
                  <h4 className="font-semibold text-sm">Kredit Aktif ({activeApplications.length})</h4>
                </div>
                <div className="space-y-2">
                  {activeApplications.map(app => {
                const totalInstallments = (app.installment_progress?.total ?? (app.installments?.length || 0));
                const paidInstallments = (app.installment_progress?.paid ?? (app.installments?.filter((i: any) => i.status === 'paid').length || 0));
                const progressPercent = totalInstallments > 0 ? (paidInstallments / totalInstallments) * 100 : 0;
                const unpaidPenalty = app.installments ? app.installments.reduce((sum: number, i: any) => sum + (i.frozen_penalty || 0), 0) : 0;
                return <div key={app.id} className="p-3 bg-muted/30 rounded-lg border border-border/50 space-y-2 cursor-pointer hover:bg-muted/50 active:bg-muted/70 transition-all touch-manipulation" onClick={() => {
                  const pref = prefetchedInstallments[app.id];
                  setSelectedAppForHistory({ ...app, installments: pref || [] });
                  setShowInstallmentHistory(true);
                  if (!pref) {
                    (async () => {
                      try {
                        const { data, error } = await supabase
                          .from('installments')
                          .select('id, application_id, installment_number, due_date, total_amount, paid_amount, frozen_penalty, frozen_days_overdue, status, principal_paid, paid_at')
                          .eq('application_id', app.id)
                          .order('installment_number');
                        if (error) throw error;
                        setPrefetchedInstallments(prev => ({ ...prev, [app.id]: data || [] }));
                        setSelectedAppForHistory(prev => prev && prev.id === app.id ? { ...prev, installments: data || [] } : prev);
                      } catch (e) {
                        toast({ title: 'Gagal memuat riwayat', description: 'Tidak bisa mengambil data angsuran', variant: 'destructive' });
                      }
                    })();
                  }
                }}>
                        <div className="flex justify-between items-start gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-sm truncate">{app.application_number}</p>
                            <p className="text-xs text-muted-foreground">
                              {app.member?.full_name} • {app.tenor_months} bulan
                            </p>
                          </div>
                          <Badge className={app.status === 'disbursed' ? 'bg-green-600' : ''}>
                            {app.status === 'disbursed' ? 'Dicairkan' : 'Disetujui'}
                          </Badge>
                        </div>
                        
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">Pinjaman:</span>
                            <span className="font-semibold">{formatRupiah(app.amount_approved || app.amount_requested)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">Progress:</span>
                            <span className="font-semibold">{paidInstallments}/{totalInstallments} ({progressPercent.toFixed(1)}%)</span>
                          </div>
                          {unpaidPenalty > 0 && <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Denda:</span>
                              <span className="font-semibold text-orange-600">{formatRupiah(unpaidPenalty)}</span>
                            </div>}
                        </div>

                        {/* Progress Bar */}
                        <Progress value={progressPercent} className="h-2 w-full" />
                        
                        <p className="text-xs text-center text-primary font-medium select-none">
                          Ketuk untuk lihat riwayat lengkap
                        </p>
                      </div>;
              })}
                </div>
              </div>
            </>}

          {/* Create Auth Account Button - Only for Owner/Admin when no user_id */}
          {canManage && !isPending && !customer.user_id && <>
              <Separator />
              <div className="w-full">
                <Button size="lg" variant="secondary" className="w-full justify-center text-base font-semibold h-12" onClick={handleCreateAuthAccount} disabled={creatingAuth}>
                  <UserPlus className="h-5 w-5 mr-2" />
                  {creatingAuth ? "Membuat Akun..." : "Buat Akun Login"}
                </Button>
              </div>
            </>}

          {/* Blocked Customer Warning - Show when customer is blocked */}
          {!isPending && isBlocked && (
            <>
              <Separator />
              <div className="w-full bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <ShieldAlert className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h4 className="font-semibold text-sm text-destructive">Nasabah Diblokir</h4>
                    <p className="text-xs text-muted-foreground">
                      Nasabah ini tidak dapat mengajukan kredit baru karena telah diblokir. 
                      Silakan hubungi Owner untuk informasi lebih lanjut atau pemulihan akses.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Apply Credit Button - Available for ALL roles (Owner, Admin, Sales) */}
          {/* Only show if customer has NO active credits (no unpaid installments) */}
          {!isPending && !isBlocked && onApplyCredit && (() => {
          // Hide button if customer has ANY active credits with unpaid installments
          // activeApplications already filtered by edge function to only include apps with unpaid installments
          const canApply = activeApplications.length === 0;
          console.log("🔍 [ApplyCreditButton]", {
            customerName: customer.full_name,
            activeApplicationsCount: activeApplications.length,
            canApply,
            activeApps: activeApplications.map(app => ({
              number: app.application_number,
              progress: app.installment_progress
            }))
          });
          return canApply;
        })() && <>
              <Separator />
              <div className="w-full">
                <Button size="lg" variant="default" className="w-full justify-center text-base font-semibold h-12 bg-primary hover:bg-primary/90" onClick={() => {
              onApplyCredit(customer);
              onOpenChange(false);
            }}>
                  <FileText className="h-5 w-5 mr-2" />
                  Ajukan Kredit
                </Button>
              </div>
            </>}

          {/* Request Change Button - Only for Sales on approved customers */}
          {isSales && !canManage && !isPending && <>
              <Separator />
              <div className="w-full">
                <Button size="lg" variant="outline" className="w-full justify-center text-base font-semibold h-12" onClick={() => setShowChangeRequestDialog(true)}>
                  <FileEdit className="h-5 w-5 mr-2" />
                  Ajukan Perubahan Data
                </Button>
              </div>
            </>}

          {/* Edit Button for Sales - Only on pending customers they created */}
          {isSales && !canManage && isPending && customer.created_by === currentMemberId && onEdit && <>
              <Separator />
              <div className="w-full">
                <Button size="lg" variant="outline" className="w-full justify-center text-base font-semibold h-12" onClick={() => {
              onEdit(customer);
              onOpenChange(false);
            }}>
                  <Pencil className="h-5 w-5 mr-2" />
                  Edit Data Nasabah
                </Button>
              </div>
            </>}

          {/* Action Buttons - Only for Owner and Admin */}
          {canManage && <>
              <Separator />
              <div className="flex flex-col gap-2 w-full">
                {isPending ? (/* Pending Customer Actions */
            <>
                    <Button variant="default" className="w-full justify-start" onClick={() => {
                onApprove?.(customer);
                onOpenChange(false);
              }}>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Setujui Nasabah
                    </Button>
                    
                    <Button variant="destructive" className="w-full justify-start" onClick={() => {
                onReject?.(customer);
                onOpenChange(false);
              }}>
                      <XCircle className="h-4 w-4 mr-2" />
                      Tolak Nasabah
                    </Button>
                  </>) : (/* Active Customer Actions */
            <>
                    <Button variant="outline" className="w-full justify-start" onClick={() => {
                onEdit?.(customer);
                onOpenChange(false);
              }}>
                      <Pencil className="h-4 w-4 mr-2" />
                      Edit Data Nasabah
                    </Button>
                    
                    <Button variant="outline" className="w-full justify-start text-orange-600 hover:text-orange-700" onClick={() => {
                onBlock?.(customer);
                onOpenChange(false);
              }}>
                      <ShieldAlert className="h-4 w-4 mr-2" />
                      Blokir Nasabah
                    </Button>
                    
                    {!hasCreditHistory && (
                    <Button variant="destructive" className="w-full justify-start" onClick={() => {
                onDelete?.(customer);
                onOpenChange(false);
              }}>
                      <Trash2 className="h-4 w-4 mr-2" />
                      Hapus Nasabah
                    </Button>
                    )}
                  </>)}
              </div>
            </>}
        </div>
      </ResponsiveDialogContent>

      <CustomerChangeRequestDialog open={showChangeRequestDialog} onOpenChange={setShowChangeRequestDialog} customer={customer} />

      {/* Installment History Dialog */}
      {selectedAppForHistory && <InstallmentHistoryDialog open={showInstallmentHistory} onOpenChange={setShowInstallmentHistory} installments={selectedAppForHistory.installments || []} applicationNumber={selectedAppForHistory.application_number} customerName={customer.full_name} loanAmount={selectedAppForHistory.amount_approved || selectedAppForHistory.amount_requested} tenor={selectedAppForHistory.tenor_months} status={selectedAppForHistory.status} />}
    </ResponsiveDialog>;
}
function DetailRow({
  label,
  value,
  valueClassName
}: {
  label: string;
  value: string;
  valueClassName?: string;
}) {
  return <div className="flex justify-between gap-2 sm:gap-4">
      <span className="text-muted-foreground font-medium min-w-[90px] sm:min-w-[100px] text-xs sm:text-sm">{label}:</span>
      <span className={`text-right flex-1 break-words text-xs sm:text-sm font-semibold ${valueClassName || ''}`}>{value}</span>
    </div>;
}