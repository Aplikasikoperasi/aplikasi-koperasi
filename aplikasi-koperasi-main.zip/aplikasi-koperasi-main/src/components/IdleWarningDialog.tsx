import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Clock } from "lucide-react";

interface IdleWarningDialogProps {
  open: boolean;
  remainingTime: number;
  onExtend: () => void;
}

export function IdleWarningDialog({ open, remainingTime, onExtend }: IdleWarningDialogProps) {
  const minutes = Math.floor(remainingTime / 60);
  const seconds = remainingTime % 60;

  return (
    <AlertDialog open={open}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="h-12 w-12 rounded-full bg-warning/10 flex items-center justify-center">
              <Clock className="h-6 w-6 text-warning" />
            </div>
            <AlertDialogTitle className="text-xl">Peringatan Sesi</AlertDialogTitle>
          </div>
          <AlertDialogDescription className="text-base">
            Sesi Anda akan berakhir dalam{" "}
            <span className="font-bold text-warning">
              {minutes > 0 && `${minutes} menit `}
              {seconds} detik
            </span>
            {" "}karena tidak ada aktivitas.
            <br />
            <br />
            Klik tombol di bawah untuk melanjutkan sesi Anda.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogAction onClick={onExtend} className="w-full">
            Perpanjang Sesi
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
