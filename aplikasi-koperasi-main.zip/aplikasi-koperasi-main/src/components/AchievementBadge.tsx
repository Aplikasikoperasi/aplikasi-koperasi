import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { Sparkles, Award, Trophy, Star, Shield, AlertCircle, Eye } from "lucide-react";

interface AchievementBadgeProps {
  badgeLevel: string;
  badgeName: string | null;
  badgeDescription: string | null;
  consecutivePayments: number;
  onTimePercentage: number;
  size?: "sm" | "md" | "lg";
  showDetails?: boolean;
}

export function AchievementBadge({
  badgeLevel,
  badgeName,
  badgeDescription,
  consecutivePayments,
  onTimePercentage,
  size = "md",
  showDetails = true,
}: AchievementBadgeProps) {
  if (!badgeName) {
    return null;
  }

  const getBadgeColor = () => {
    switch (badgeLevel) {
      case 'diamond':
        return 'bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-500 text-white border-cyan-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]';
      case 'platinum':
        return 'bg-gradient-to-r from-purple-400 via-pink-400 to-purple-500 text-white border-purple-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]';
      case 'gold':
        return 'bg-gradient-to-r from-yellow-400 via-amber-300 to-amber-500 text-amber-900 border-yellow-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]';
      case 'silver':
        return 'bg-gradient-to-r from-slate-300 via-slate-200 to-slate-400 text-slate-800 border-slate-200 shadow-md animate-shimmer bg-[length:200%_100%]';
      case 'bronze':
        return 'bg-gradient-to-r from-orange-400 to-orange-600 text-orange-900 border-orange-200 shadow-md animate-shimmer bg-[length:200%_100%]';
      case 'new':
        return 'bg-gradient-to-r from-blue-400 to-indigo-500 text-white border-blue-200 shadow-md animate-shimmer bg-[length:200%_100%]';
      case 'overdue':
        return 'bg-gradient-to-r from-red-500 to-red-600 text-white border-red-300 shadow-lg animate-shimmer bg-[length:200%_100%]';
      case 'monitored':
        return 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-yellow-300 shadow-md animate-shimmer bg-[length:200%_100%]';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'text-xs px-2 py-1 gap-1';
      case 'lg':
        return 'text-base px-4 py-2 gap-2';
      default:
        return 'text-sm px-3 py-1.5 gap-1.5';
    }
  };

  const getBadgeIcon = () => {
    const iconSize = size === 'sm' ? 12 : size === 'lg' ? 18 : 14;
    
    switch (badgeLevel) {
      case 'diamond':
        return <Trophy size={iconSize} className="shrink-0" />;
      case 'platinum':
        return <Star size={iconSize} className="shrink-0" />;
      case 'gold':
        return <Award size={iconSize} className="shrink-0" />;
      case 'silver':
        return <Shield size={iconSize} className="shrink-0" />;
      case 'bronze':
        return <Shield size={iconSize} className="shrink-0" />;
      case 'new':
        return <Sparkles size={iconSize} className="shrink-0" />;
      case 'overdue':
        return <AlertCircle size={iconSize} className="shrink-0" />;
      case 'monitored':
        return <Eye size={iconSize} className="shrink-0" />;
      default:
        return null;
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            className={cn(
              "font-semibold shadow-md cursor-help inline-flex items-center justify-center gap-1 whitespace-nowrap",
              getBadgeColor(),
              getSizeClasses()
            )}
          >
            {getBadgeIcon()}
            <span>{badgeName}</span>
          </Badge>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs">
          <div className="space-y-2">
            <p className="font-semibold text-sm">{badgeDescription}</p>
            {showDetails && (
              <div className="text-xs text-muted-foreground space-y-1">
                <p>Pembayaran berturut: <span className="font-semibold text-foreground">{consecutivePayments} bulan</span></p>
                <p>Tingkat ketepatan: <span className="font-semibold text-foreground">{onTimePercentage}%</span></p>
              </div>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
