import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Shield, AlertCircle } from "lucide-react";

interface SupercodeVerificationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  title?: string;
  description?: string;
}

export const SupercodeVerificationDialog = ({
  open,
  onOpenChange,
  onSuccess,
  title = "Verifikasi Supercode",
  description = "Masukkan supercode untuk melanjutkan operasi ini"
}: SupercodeVerificationDialogProps) => {
  const [supercode, setSupercode] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState("");

  const handleVerify = async () => {
    if (!supercode.trim()) {
      setError("Supercode tidak boleh kosong");
      return;
    }

    setVerifying(true);
    setError("");

    try {
      const { data, error: verifyError } = await supabase.functions.invoke('verify-supercode', {
        body: {
          superCodeInput: supercode.trim(),
          operation: title
        }
      });

      if (verifyError) throw verifyError;

      if (data?.valid) {
        // Reset state
        setSupercode("");
        setError("");
        onOpenChange(false);
        
        // Call success callback
        onSuccess();
      } else {
        setError(data?.error || "SuperCode salah");
      }
    } catch (err: any) {
      console.error("Supercode verification error:", err);
      setError(err.message || "Gagal memverifikasi supercode");
    } finally {
      setVerifying(false);
    }
  };

  const handleClose = () => {
    setSupercode("");
    setError("");
    onOpenChange(false);
  };

  return (
    <AlertDialog open={open} onOpenChange={handleClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-amber-600" />
            {title}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {description}
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="supercode">Supercode</Label>
            <Input
              id="supercode"
              type="password"
              value={supercode}
              onChange={(e) => {
                setSupercode(e.target.value);
                setError("");
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !verifying) {
                  handleVerify();
                }
              }}
              placeholder="Masukkan supercode"
              disabled={verifying}
              autoFocus
            />
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </div>

        <AlertDialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={verifying}
          >
            Batal
          </Button>
          <Button
            onClick={handleVerify}
            disabled={verifying || !supercode.trim()}
          >
            {verifying ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Memverifikasi...
              </>
            ) : (
              'Verifikasi'
            )}
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
