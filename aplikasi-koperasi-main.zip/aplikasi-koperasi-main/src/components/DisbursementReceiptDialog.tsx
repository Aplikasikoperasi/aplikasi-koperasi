import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { formatRupiah, formatDate } from "@/lib/utils";
import { MessageSquare } from "lucide-react";
import { generateDisbursementReceiptMessage, openWhatsAppChat } from "@/lib/whatsappHelper";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface DisbursementReceiptDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: {
    customerName: string;
    memberName: string;
    disbursementDate: string;
    amountRequested: number;
    firstInstallmentAmount?: number;
    adminFee?: number;
    netAmount: number;
    customerPhone?: string;
    applicationNumber?: string;
  };
}

export default function DisbursementReceiptDialog({ 
  open, 
  onOpenChange, 
  data 
}: DisbursementReceiptDialogProps) {
  const { toast } = useToast();
  
  const handleSendWhatsApp = async () => {
    try {
      // Try provided phone first, then fallback to DB by application number
      let customerPhone = (data.customerPhone || '').trim();
      let customerIdNumber: string | undefined;
      let dateOfBirth: string | undefined;

      if (!customerPhone && data.applicationNumber) {
        const { data: app } = await supabase
          .from('credit_applications')
          .select(`customers!inner(phone, id_number, date_of_birth)`) 
          .eq('application_number', data.applicationNumber)
          .maybeSingle();
        customerPhone = (app as any)?.customers?.phone || '';
        customerIdNumber = (app as any)?.customers?.id_number;
        dateOfBirth = (app as any)?.customers?.date_of_birth;
      }

      if (!customerPhone) {
        toast({
          title: "Error",
          description: "Nomor telepon nasabah tidak tersedia",
          variant: "destructive",
        });
        return;
      }

      // Generate message using helper
      const { data: bankDataRaw } = await supabase
        .from("bank_accounts" as any)
        .select("bank_name, account_number, account_holder")
        .eq("is_primary", true)
        .eq("is_active", true)
        .maybeSingle();
      
      const bankData = bankDataRaw as any;
      
      const bankInfo = bankData?.bank_name ? {
        bankName: bankData.bank_name,
        bankAccountNumber: bankData.account_number,
        bankAccountHolder: bankData.account_holder
      } : undefined;

      const message = generateDisbursementReceiptMessage({
        customerName: data.customerName,
        memberName: data.memberName,
        disbursementDate: data.disbursementDate,
        amountRequested: data.amountRequested,
        firstInstallmentAmount: data.firstInstallmentAmount,
        adminFee: data.adminFee,
        netAmount: data.netAmount,
        applicationNumber: data.applicationNumber || 'N/A',
        customerIdNumber,
        dateOfBirth,
        bankName: bankInfo?.bankName,
        bankAccountNumber: bankInfo?.bankAccountNumber,
        bankAccountHolder: bankInfo?.bankAccountHolder,
      });

      // Check if WhatsApp integration is enabled
      const { data: whatsappSettings } = await supabase
        .from("whatsapp_settings")
        .select("is_enabled")
        .maybeSingle();

      if (whatsappSettings?.is_enabled) {
        // Send via WhatsApp API
        const { error: sendError } = await supabase.functions.invoke('send-whatsapp-message', {
          body: {
            phone_number: customerPhone,
            message: message
          }
        });

        if (sendError) {
          console.error("Error sending via WhatsApp API:", sendError);
          // Fallback to opening WhatsApp
          openWhatsAppChat(customerPhone, message);
          toast({
            title: "Berhasil",
            description: "Membuka WhatsApp...",
          });
        } else {
          toast({
            title: "Berhasil",
            description: "Bukti pencairan berhasil dikirim via WhatsApp",
          });
        }
      } else {
        // Fallback to opening WhatsApp
        openWhatsAppChat(customerPhone, message);
        toast({
          title: "Berhasil",
          description: "Membuka WhatsApp...",
        });
      }
    } catch (error) {
      console.error("Error sending WhatsApp message:", error);
      toast({
        title: "Error",
        description: "Gagal mengirim pesan WhatsApp",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Rincian Pencairan Dana</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Nama Nasabah</p>
              <p className="font-semibold">{data.customerName}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Penanggung Jawab</p>
              <p className="font-semibold">{data.memberName}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Tanggal Pencairan</p>
              <p className="font-semibold">{formatDate(data.disbursementDate)}</p>
            </div>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-3 font-semibold">Keterangan</th>
                  <th className="text-right p-3 font-semibold">Jumlah</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                <tr>
                  <td className="p-3">Jumlah Pengajuan</td>
                  <td className="p-3 text-right">{formatRupiah(data.amountRequested)}</td>
                </tr>
                {data.firstInstallmentAmount && (
                  <tr>
                    <td className="p-3">Pembayaran Angsuran Pertama</td>
                    <td className="p-3 text-right text-destructive">- {formatRupiah(data.firstInstallmentAmount)}</td>
                  </tr>
                )}
                {data.adminFee && (
                  <tr>
                    <td className="p-3">Biaya Admin</td>
                    <td className="p-3 text-right text-destructive">- {formatRupiah(data.adminFee)}</td>
                  </tr>
                )}
                <tr className="bg-muted font-semibold">
                  <td className="p-3">Dana Diterima Nasabah</td>
                  <td className="p-3 text-right">{formatRupiah(data.netAmount)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Tutup
            </Button>
            <Button 
              onClick={handleSendWhatsApp}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Kirim Bukti via WhatsApp
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}