import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { CurrencyInput } from "@/components/ui/currency-input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  ArrowLeftRight, 
  Loader2, 
  Wallet, 
  AlertTriangle, 
  KeyRound,
  Search,
  User,
  CheckCircle2,
  XCircle
} from "lucide-react";
import { formatRupiah } from "@/lib/utils";

interface SaverTransferDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saverId: string;
  saverName: string;
  saverAccountNumber: string;
  currentBalance: number;
  hasPin: boolean;
  onSuccess?: () => void;
}

interface RecipientInfo {
  id: string;
  full_name: string;
  account_number: string;
  photo_url: string | null;
}

export default function SaverTransferDialog({
  open,
  onOpenChange,
  saverId,
  saverName,
  saverAccountNumber,
  currentBalance,
  hasPin,
  onSuccess,
}: SaverTransferDialogProps) {
  const [step, setStep] = useState<"form" | "confirm" | "pin">("form");
  const [amount, setAmount] = useState<string>("");
  const [recipientAccountNumber, setRecipientAccountNumber] = useState("");
  const [displayAccountNumber, setDisplayAccountNumber] = useState("");
  const [recipientInfo, setRecipientInfo] = useState<RecipientInfo | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [pin, setPin] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [pinAttempts, setPinAttempts] = useState(0);

  const numericAmount = parseInt(amount || "0", 10);

  // Format account number with separators (xxxx xxx xxx)
  const formatAccountNumber = (value: string) => {
    const digits = value.replace(/\D/g, "");
    const parts = [];
    if (digits.length > 0) parts.push(digits.slice(0, 4));
    if (digits.length > 4) parts.push(digits.slice(4, 7));
    if (digits.length > 7) parts.push(digits.slice(7, 10));
    return parts.join(" ");
  };

  const handleAccountNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/\D/g, "").slice(0, 10);
    setRecipientAccountNumber(rawValue);
    setDisplayAccountNumber(formatAccountNumber(rawValue));
  };

  // Reset form when dialog opens/closes
  useEffect(() => {
    if (!open) {
      setStep("form");
      setAmount("");
      setRecipientAccountNumber("");
      setDisplayAccountNumber("");
      setRecipientInfo(null);
      setSearchError(null);
      setPin("");
      setPinAttempts(0);
    }
  }, [open]);

  // Search for recipient when account number changes
  useEffect(() => {
    const searchRecipient = async () => {
      // Use raw digits for comparison
      const rawAccountNumber = recipientAccountNumber.replace(/\D/g, "");
      const rawSaverAccountNumber = saverAccountNumber.replace(/\D/g, "");
      
      if (rawAccountNumber.length < 5) {
        setRecipientInfo(null);
        setSearchError(null);
        return;
      }

      // Don't allow transfer to self
      if (rawAccountNumber === rawSaverAccountNumber) {
        setRecipientInfo(null);
        setSearchError("Tidak dapat transfer ke rekening sendiri");
        return;
      }

      setIsSearching(true);
      setSearchError(null);

      try {
        const { data, error } = await supabase
          .from("savers")
          .select("id, full_name, account_number, photo_url")
          .eq("account_number", rawAccountNumber)
          .eq("status", "active")
          .single();

        if (error || !data) {
          setRecipientInfo(null);
          setSearchError("Rekening tidak ditemukan");
        } else {
          setRecipientInfo(data);
          setSearchError(null);
        }
      } catch {
        setRecipientInfo(null);
        setSearchError("Gagal mencari rekening");
      } finally {
        setIsSearching(false);
      }
    };

    const debounceTimeout = setTimeout(searchRecipient, 500);
    return () => clearTimeout(debounceTimeout);
  }, [recipientAccountNumber, saverAccountNumber]);

  const handleFormSubmit = () => {
    if (numericAmount <= 0) {
      toast.error("Jumlah transfer harus lebih dari 0");
      return;
    }

    if (numericAmount > currentBalance) {
      toast.error("Saldo tidak mencukupi");
      return;
    }

    if (!hasPin) {
      toast.error("Anda belum mengatur PIN. Silakan atur PIN terlebih dahulu di halaman Profil.");
      return;
    }

    if (!recipientInfo) {
      toast.error("Pilih rekening tujuan yang valid");
      return;
    }

    setStep("confirm");
  };

  const handleConfirmContinue = () => {
    setStep("pin");
  };

  const handlePinConfirm = async () => {
    if (pin.length !== 6) {
      toast.error("Masukkan PIN 6 digit");
      return;
    }

    if (!recipientInfo) {
      toast.error("Rekening tujuan tidak valid");
      return;
    }

    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke("transfer-saver-balance", {
        body: {
          sender_id: saverId,
          recipient_id: recipientInfo.id,
          amount: numericAmount,
          pin: pin,
        },
      });

      if (error) {
        // Try to parse error
        let errorBody: any = null;
        const ctx = (error as any)?.context;
        if (ctx && typeof ctx.json === "function") {
          try {
            const res = typeof ctx.clone === "function" ? ctx.clone() : ctx;
            errorBody = await res.json();
          } catch {}
        }

        if (!errorBody) {
          const msg = String((error as any)?.message ?? "");
          const start = msg.indexOf("{");
          const end = msg.lastIndexOf("}");
          if (start !== -1 && end !== -1 && end > start) {
            try {
              errorBody = JSON.parse(msg.slice(start, end + 1));
            } catch {}
          }
        }

        if (errorBody) {
          if (errorBody.blocked) {
            toast.error(errorBody.error || "Transfer dibatalkan karena PIN salah 3x");
            onOpenChange(false);
            return;
          }

          if (errorBody.attempts !== undefined) {
            setPinAttempts(errorBody.attempts);
            toast.error(`PIN salah. Percobaan: ${errorBody.attempts}/3`);
            setPin("");
            return;
          }

          toast.error(errorBody.error || "Gagal melakukan transfer");
          setPin("");
          return;
        }

        toast.error("Gagal melakukan transfer");
        setPin("");
        return;
      }

      if (data?.error) {
        if (data.blocked) {
          toast.error(data.error);
          onOpenChange(false);
          return;
        }

        if (data.attempts !== undefined) {
          setPinAttempts(data.attempts);
          toast.error(`PIN salah. Percobaan: ${data.attempts}/3`);
          setPin("");
          return;
        }

        toast.error(data.error);
        setPin("");
        return;
      }

      toast.success(`Transfer berhasil ke ${recipientInfo.full_name}!`);
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error("Error processing transfer:", error);
      toast.error("Gagal melakukan transfer");
      setPin("");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    onOpenChange(false);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Dialog open={open} onOpenChange={(val) => !val && handleCancel()}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowLeftRight className="h-5 w-5 text-blue-600" />
            Transfer Saldo
          </DialogTitle>
        </DialogHeader>

        {step === "form" ? (
          <div className="space-y-4">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Pengirim</p>
              <p className="font-semibold">{saverName}</p>
              <p className="text-xs text-muted-foreground">{saverAccountNumber}</p>
            </div>

            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4 text-primary" />
                <span className="text-sm">Saldo Tersedia</span>
              </div>
              <p className="text-xl font-bold text-primary">
                {formatRupiah(currentBalance)}
              </p>
            </div>

            {!hasPin && (
              <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-300 dark:border-red-800 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-700 dark:text-red-300">
                      PIN Belum Diatur
                    </p>
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                      Anda harus mengatur PIN terlebih dahulu di halaman Profil untuk dapat melakukan transfer.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Recipient Account Input */}
            <div className="space-y-2">
              <Label htmlFor="recipient-account">Nomor Rekening Tujuan</Label>
              <div className="relative">
                <Input
                  id="recipient-account"
                  value={displayAccountNumber}
                  onChange={handleAccountNumberChange}
                  placeholder="xxxx xxx xxx"
                  className="pr-10"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  {isSearching ? (
                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                  ) : recipientInfo ? (
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                  ) : searchError ? (
                    <XCircle className="h-4 w-4 text-destructive" />
                  ) : (
                    <Search className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              </div>
              {searchError && (
                <p className="text-sm text-destructive">{searchError}</p>
              )}
            </div>

            {/* Recipient Info Preview */}
            {recipientInfo && (
              <div className="p-4 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12 border-2 border-green-300">
                    {recipientInfo.photo_url ? (
                      <AvatarImage src={recipientInfo.photo_url} alt={recipientInfo.full_name} />
                    ) : null}
                    <AvatarFallback className="bg-green-200 text-green-700">
                      {getInitials(recipientInfo.full_name)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-green-800 dark:text-green-200">
                      {recipientInfo.full_name}
                    </p>
                    <p className="text-sm text-green-600 dark:text-green-400">
                      {recipientInfo.account_number}
                    </p>
                  </div>
                  <CheckCircle2 className="h-5 w-5 text-green-600 ml-auto" />
                </div>
              </div>
            )}

            {/* Amount Input */}
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah Transfer</Label>
              <CurrencyInput
                id="amount"
                value={amount}
                onChange={(val) => setAmount(val)}
                placeholder="Masukkan jumlah transfer"
              />
              {numericAmount > currentBalance && (
                <p className="text-sm text-destructive">Saldo tidak mencukupi</p>
              )}
            </div>

            <div className="p-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                💡 Transfer akan langsung diproses setelah input PIN
              </p>
            </div>
          </div>
        ) : step === "confirm" ? (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg space-y-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Jumlah Transfer</p>
                <p className="text-2xl font-bold text-blue-600">
                  {formatRupiah(numericAmount)}
                </p>
              </div>

              <div className="flex items-center justify-center gap-4">
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Dari</p>
                  <p className="font-medium text-sm">{saverName}</p>
                </div>
                <ArrowLeftRight className="h-5 w-5 text-muted-foreground" />
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Ke</p>
                  <p className="font-medium text-sm">{recipientInfo?.full_name}</p>
                </div>
              </div>

              {recipientInfo && (
                <div className="flex items-center justify-center gap-3 pt-2 border-t">
                  <Avatar className="h-10 w-10">
                    {recipientInfo.photo_url ? (
                      <AvatarImage src={recipientInfo.photo_url} alt={recipientInfo.full_name} />
                    ) : null}
                    <AvatarFallback className="bg-blue-200 text-blue-700">
                      {getInitials(recipientInfo.full_name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left">
                    <p className="font-semibold">{recipientInfo.full_name}</p>
                    <p className="text-xs text-muted-foreground">{recipientInfo.account_number}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-sm text-amber-700 dark:text-amber-300">
                ⚠️ Pastikan data penerima sudah benar. Transfer tidak dapat dibatalkan setelah dikonfirmasi.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Transfer ke</span>
                <span className="font-medium">{recipientInfo?.full_name}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Jumlah</span>
                <span className="text-xl font-bold text-blue-600">
                  {formatRupiah(numericAmount)}
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-center block flex items-center justify-center gap-2">
                <KeyRound className="h-4 w-4" />
                Masukkan PIN untuk konfirmasi
              </Label>
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={pin}
                  onChange={setPin}
                  disabled={isSubmitting}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
              {pinAttempts > 0 && (
                <p className="text-center text-sm text-destructive">
                  Percobaan PIN salah: {pinAttempts}/3
                </p>
              )}
            </div>
          </div>
        )}

        <DialogFooter className="flex-col sm:flex-row gap-2">
          {step === "form" ? (
            <>
              <Button variant="outline" onClick={handleCancel} disabled={isSubmitting}>
                Batal
              </Button>
              <Button
                onClick={handleFormSubmit}
                disabled={isSubmitting || numericAmount <= 0 || numericAmount > currentBalance || !hasPin || !recipientInfo}
              >
                Lanjutkan
              </Button>
            </>
          ) : step === "confirm" ? (
            <>
              <Button variant="outline" onClick={() => setStep("form")} disabled={isSubmitting}>
                Kembali
              </Button>
              <Button onClick={handleConfirmContinue}>
                Konfirmasi & Masukkan PIN
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setStep("confirm")} disabled={isSubmitting}>
                Kembali
              </Button>
              <Button
                onClick={handlePinConfirm}
                disabled={isSubmitting || pin.length !== 6}
              >
                {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Transfer Sekarang
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
