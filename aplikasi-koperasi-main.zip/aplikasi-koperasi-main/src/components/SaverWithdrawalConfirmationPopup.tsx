import { useState, useEffect, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatRupiah, formatDateWIB } from "@/lib/utils";
import {
  AlertTriangle,
  Clock,
  Wallet,
  Banknote,
  Building2,
  Loader2,
  X,
  CheckCircle2,
} from "lucide-react";

interface PendingWithdrawal {
  id: string;
  saver_id: string;
  amount: number;
  payment_method: string | null;
  payment_details: string | null;
  notes: string | null;
  requested_at: string;
  expires_at: string;
  status: string;
  requested_by: string | null;
  failed_pin_attempts?: number;
  members?: {
    full_name: string;
  } | null;
}

interface SaverWithdrawalConfirmationPopupProps {
  saverId: string;
  onConfirm?: () => void;
}

export default function SaverWithdrawalConfirmationPopup({
  saverId,
  onConfirm,
}: SaverWithdrawalConfirmationPopupProps) {
  const [pendingWithdrawal, setPendingWithdrawal] = useState<PendingWithdrawal | null>(null);
  const [open, setOpen] = useState(false);
  const [pin, setPin] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<string>("");
  const [failedAttempts, setFailedAttempts] = useState(0);
  const MAX_ATTEMPTS = 3;

  // Load pending withdrawals for this saver
  const loadPendingWithdrawal = useCallback(async () => {
    if (!saverId) return;

    const { data, error } = await supabase
      .from("saver_pending_withdrawals")
      .select("*, members:requested_by(full_name)")
      .eq("saver_id", saverId)
      .eq("status", "pending")
      .order("requested_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Error loading pending withdrawal:", error);
      return;
    }

    if (data) {
      // Check if expired
      const expiresAt = new Date(data.expires_at);
      if (new Date() > expiresAt) {
        // Auto-expire
        await supabase
          .from("saver_pending_withdrawals")
          .update({ status: "expired" })
          .eq("id", data.id);
        setPendingWithdrawal(null);
        setOpen(false);
      } else {
        setPendingWithdrawal(data);
        setFailedAttempts(data.failed_pin_attempts || 0);
        setOpen(true);
      }
    } else {
      setPendingWithdrawal(null);
      setOpen(false);
    }
  }, [saverId]);

  // Initial load and real-time subscription
  useEffect(() => {
    loadPendingWithdrawal();

    // Subscribe to real-time changes
    const channel = supabase
      .channel(`pending-withdrawals-${saverId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "saver_pending_withdrawals",
          filter: `saver_id=eq.${saverId}`,
        },
        (payload) => {
          console.log("Pending withdrawal change:", payload);
          loadPendingWithdrawal();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [saverId, loadPendingWithdrawal]);

  // Countdown timer
  useEffect(() => {
    if (!pendingWithdrawal) return;

    const updateTimer = () => {
      const now = new Date();
      const expiresAt = new Date(pendingWithdrawal.expires_at);
      const diff = expiresAt.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeRemaining("Kadaluarsa");
        loadPendingWithdrawal(); // Refresh to update status
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeRemaining(
        `${hours.toString().padStart(2, "0")}:${minutes
          .toString()
          .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
      );
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [pendingWithdrawal, loadPendingWithdrawal]);

  const handleConfirm = async () => {
    if (!pendingWithdrawal || pin.length !== 6) {
      toast.error("Masukkan PIN 6 digit");
      return;
    }

    setIsSubmitting(true);

    const parseInvokeErrorBody = async (err: any) => {
      const ctx = err?.context;
      if (ctx && typeof ctx.json === "function") {
        try {
          const res = typeof ctx.clone === "function" ? ctx.clone() : ctx;
          return await res.json();
        } catch {
          // ignore (body might be consumed)
        }
      }

      const msg = String(err?.message ?? "");
      const start = msg.indexOf("{");
      const end = msg.lastIndexOf("}");
      if (start !== -1 && end !== -1 && end > start) {
        try {
          return JSON.parse(msg.slice(start, end + 1));
        } catch {
          // ignore
        }
      }

      return null;
    };

    try {
      const { data, error } = await supabase.functions.invoke("confirm-saver-withdrawal", {
        body: {
          withdrawal_id: pendingWithdrawal.id,
          pin: pin,
          action: "confirm",
        },
      });

      // Treat 401 (wrong PIN) as a normal flow: update UI, don't crash, don't toast.
      if (error) {
        const errorBody = await parseInvokeErrorBody(error);

        if (errorBody) {
          if (errorBody.attempts !== undefined) {
            setFailedAttempts(errorBody.attempts);
          }

          if (errorBody.cancelled) {
            toast.error(errorBody.error || "Transaksi dibatalkan karena PIN salah 3x");
            setOpen(false);
            setPendingWithdrawal(null);
            setPin("");
            setFailedAttempts(0);
            onConfirm?.();
            return;
          }

          // Wrong PIN: no toast (form already shows failed attempts)
          setPin("");
          return;
        }

        toast.error("Gagal mengkonfirmasi penarikan");
        setPin("");
        return;
      }

      if (data?.error) {
        if (data.cancelled) {
          toast.error(data.error);
          setOpen(false);
          setPendingWithdrawal(null);
          setPin("");
          setFailedAttempts(0);
          onConfirm?.();
          return;
        }

        // No toast for PIN errors (UI already shows it)
        if (data.attempts !== undefined) {
          setFailedAttempts(data.attempts);
        }

        setPin("");
        return;
      }

      toast.success("Penarikan berhasil dikonfirmasi!");
      setOpen(false);
      setPendingWithdrawal(null);
      setPin("");
      setFailedAttempts(0);
      onConfirm?.();
    } catch (error: any) {
      console.error("Error confirming withdrawal:", error);
      toast.error("Gagal mengkonfirmasi penarikan");
      setPin("");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = async () => {
    if (!pendingWithdrawal) return;

    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke("confirm-saver-withdrawal", {
        body: {
          withdrawal_id: pendingWithdrawal.id,
          action: "cancel",
        },
      });

      if (error) throw error;

      if (data?.error) {
        toast.error(data.error);
        return;
      }

      toast.success("Penarikan berhasil dibatalkan");
      setOpen(false);
      setPendingWithdrawal(null);
      setPin("");
      onConfirm?.();
    } catch (error: any) {
      console.error("Error cancelling withdrawal:", error);
      toast.error(error.message || "Gagal membatalkan penarikan");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!pendingWithdrawal) return null;

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="h-5 w-5" />
            Konfirmasi Penarikan
          </DialogTitle>
          <DialogDescription>
            Ada permintaan penarikan yang memerlukan konfirmasi Anda
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Countdown Timer */}
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-amber-600" />
                <span className="text-sm text-amber-700 dark:text-amber-300">
                  Waktu tersisa:
                </span>
              </div>
              <span className="font-mono font-bold text-lg text-amber-600 dark:text-amber-400">
                {timeRemaining}
              </span>
            </div>
          </div>

          {/* Withdrawal Details */}
          <div className="p-4 bg-muted rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Jumlah Penarikan</span>
              <span className="text-xl font-bold text-destructive">
                {formatRupiah(pendingWithdrawal.amount)}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Metode</span>
              <div className="flex items-center gap-1">
                {pendingWithdrawal.payment_method === "transfer" ? (
                  <>
                    <Building2 className="h-4 w-4 text-blue-500" />
                    <span>Transfer Bank</span>
                  </>
                ) : (
                  <>
                    <Banknote className="h-4 w-4 text-green-600" />
                    <span>Tunai</span>
                  </>
                )}
              </div>
            </div>

            {pendingWithdrawal.payment_details && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Rekening Tujuan</span>
                <span className="text-sm">{pendingWithdrawal.payment_details}</span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Diajukan oleh</span>
              <span className="text-sm font-medium">
                {pendingWithdrawal.members?.full_name || "Admin"}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Waktu Pengajuan</span>
              <span className="text-sm">
                {formatDateWIB(pendingWithdrawal.requested_at)}
              </span>
            </div>

            {pendingWithdrawal.notes && (
              <div className="pt-2 border-t">
                <span className="text-xs text-muted-foreground">Catatan:</span>
                <p className="text-sm">{pendingWithdrawal.notes}</p>
              </div>
            )}
          </div>

          {/* PIN Input */}
          <div className="space-y-2">
            <Label className="text-center block">Masukkan PIN Anda untuk konfirmasi</Label>
            <div className="flex justify-center">
              <InputOTP
                maxLength={6}
                value={pin}
                onChange={setPin}
                disabled={isSubmitting}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>
            
            {/* Failed attempts warning */}
            {failedAttempts > 0 && (
              <div className="p-2 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg text-center">
                <p className="text-sm text-red-600 dark:text-red-400 font-medium">
                  ⚠️ Percobaan gagal: {failedAttempts}/{MAX_ATTEMPTS}
                </p>
                <p className="text-xs text-red-500 dark:text-red-400 mt-1">
                  {MAX_ATTEMPTS - failedAttempts === 1 
                    ? "Sisa 1 percobaan! Transaksi akan dibatalkan jika PIN salah lagi."
                    : `Sisa ${MAX_ATTEMPTS - failedAttempts} percobaan sebelum transaksi dibatalkan.`
                  }
                </p>
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleCancel}
            disabled={isSubmitting}
            className="flex-1"
          >
            {isSubmitting ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <X className="h-4 w-4 mr-2" />
            )}
            Batalkan
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={isSubmitting || pin.length !== 6}
            className="flex-1"
          >
            {isSubmitting ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <CheckCircle2 className="h-4 w-4 mr-2" />
            )}
            Konfirmasi
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
