import { useEffect, useState } from "react";
import { useNavigate, Outlet, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { LogOut, Inbox, ClipboardCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { RealtimeClock } from "@/components/RealtimeClock";
import { useUserRole } from "@/hooks/useUserRole";
import { useIsMobile } from "@/hooks/use-mobile";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { useIdleTimeout } from "@/hooks/useIdleTimeout";
import { IdleWarningDialog } from "@/components/IdleWarningDialog";
import { useAutoBackup } from "@/hooks/useAutoBackup";
import { SwipeHandler } from "@/components/SwipeHandler";
import { useQueryClient } from "@tanstack/react-query";
import { MaintenanceBanner } from "@/components/MaintenanceBanner";
import { useAppVisibility } from "@/hooks/useAppVisibility";

export function AppLayout() {
  const [user, setUser] = useState<any>(null);
  const [fullName, setFullName] = useState<string | null>(null);
  const [position, setPosition] = useState<string | null>(null);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [presenceChannel, setPresenceChannel] = useState<any>(null);
  const [unreadMessageCount, setUnreadMessageCount] = useState(0);
  const [verificationCount, setVerificationCount] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { role, loading: roleLoading, isOwner, isAdmin, isSales } = useUserRole();
  const isMobile = useIsMobile();
  const { businessName, logoUrl } = useBusinessInfo();
  const queryClient = useQueryClient();
  
  // Auto backup to Google Drive when scheduled
  useAutoBackup();
  
  // Auto reconnect Supabase and refresh data when app becomes visible after idle
  useAppVisibility({
    onBecomeVisible: () => {
      console.log('👁️ App became visible, checking connection...');
    },
    refreshOnVisible: true,
  });
  
  // Auto logout on idle with role-based timeout
  const { showWarning, remainingTime, extendSession, handleLogout: idleLogout } = useIdleTimeout({
    role: role as "owner" | "admin" | "sales" | "customer" | "kasir",
    onWarning: () => {
      console.log('⚠️ Idle warning triggered');
    },
    onLogout: () => {
      console.log('🚪 Auto logout due to inactivity');
    },
  });

  useEffect(() => {
    let isMounted = true;

    const syncUserFromSession = (session: any) => {
      if (!isMounted) return;

      if (!session) {
        // NOTE: Jangan redirect di sini — biarkan ProtectedRoute yang menangani.
        // Redirect ganda antara AppLayout + ProtectedRoute bisa memicu loop di mobile.
        setUser(null);
        setFullName(null);
        setPosition(null);
        setPhotoUrl(null);
        return;
      }

      console.log('👤 User logged in:', session.user.email);
      setUser(session.user);
      loadMemberProfile(session.user.id);
    };

    supabase.auth.getSession().then(({ data: { session } }) => {
      syncUserFromSession(session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      syncUserFromSession(session);
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const loadMemberProfile = async (userId: string) => {
    try {
      // Get member data for position, name and photo (from current user)
      const { data: memberData } = await supabase
        .from("members")
        .select("full_name, position, photo_url")
        .eq("user_id", userId)
        .maybeSingle();
      
      if (memberData) {
        setFullName(memberData.full_name);
        setPosition(memberData.position);
        setPhotoUrl(memberData.photo_url);
      }
    } catch (error) {
      console.error("Error loading member profile:", error);
    }
  };

  // Listen for member profile updates
  useEffect(() => {
    if (!user) return;

    const handleProfileUpdate = () => {
      loadMemberProfile(user.id);
    };

    window.addEventListener('businessProfileUpdated', handleProfileUpdate);
    return () => window.removeEventListener('businessProfileUpdated', handleProfileUpdate);
  }, [user]);

  // Load unread message count for inbox
  useEffect(() => {
    if (!user) return;

    const loadUnreadCount = async () => {
      try {
        // Get member_id from user_id
        const { data: memberData } = await supabase
          .from("members")
          .select("id")
          .eq("user_id", user.id)
          .maybeSingle();

        if (!memberData) return;

        // Count unread messages
        const { count } = await supabase
          .from("member_messages")
          .select("*", { count: "exact", head: true })
          .eq("member_id", memberData.id)
          .eq("is_read", false);

        setUnreadMessageCount(count || 0);
      } catch (error) {
        console.error("Error loading unread message count:", error);
      }
    };

    loadUnreadCount();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('header-inbox-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'member_messages'
        },
        () => {
          loadUnreadCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  // Load verification count for header badge
  useEffect(() => {
    const loadVerificationCount = async () => {
      try {
        // Get pending restoration requests (only those where customer is still blocked)
        const { data: pendingRestoration } = await supabase
          .from("customer_restoration_requests")
          .select("customer_id")
          .eq("status", "pending");

        let validRestorationCount = 0;
        if (pendingRestoration && pendingRestoration.length > 0) {
          const customerIds = pendingRestoration.map(r => r.customer_id);
          const { data: blockedCustomers } = await supabase
            .from("blocked_customers")
            .select("customer_id")
            .in("customer_id", customerIds);
          const blockedSet = new Set((blockedCustomers || []).map(b => b.customer_id));
          validRestorationCount = pendingRestoration.filter(r => blockedSet.has(r.customer_id)).length;
        }

        // Get pending saver transactions count
        const { count: pendingSaverDeposits } = await supabase
          .from("saver_deposits")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending");

        const { count: pendingSaverWithdrawals } = await supabase
          .from("saver_withdrawals")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending");

        // Also count pending withdrawals waiting for PIN confirmation
        const { count: pendingPinWithdrawals } = await supabase
          .from("saver_pending_withdrawals")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending");

        const pendingSaverTransactions = (pendingSaverDeposits || 0) + (pendingSaverWithdrawals || 0) + (pendingPinWithdrawals || 0);

        const [
          { count: customersCount },
          { count: applicationsCount },
          { count: changeCount },
          { count: withdrawalCount },
          { count: expensesCount }
        ] = await Promise.all([
          supabase.from("customers").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("credit_applications").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("customer_change_requests").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("member_balance_withdrawals").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("expenses").select("*", { count: "exact", head: true }).eq("status", "pending")
        ]);

        const total = (customersCount || 0) + (applicationsCount || 0) + validRestorationCount + (changeCount || 0) + (withdrawalCount || 0) + (expensesCount || 0) + pendingSaverTransactions;
        setVerificationCount(total);
      } catch (err) {
        console.error("Failed to load verification counts", err);
      }
    };

    loadVerificationCount();

    // Subscribe to changes
    const channel = supabase
      .channel('header-verification-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customers' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'credit_applications' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customer_restoration_requests' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blocked_customers' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customer_change_requests' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'member_balance_withdrawals' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expenses' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'saver_deposits' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'saver_withdrawals' }, loadVerificationCount)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'saver_pending_withdrawals' }, loadVerificationCount)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Setup presence tracking for online status
  useEffect(() => {
    if (!user) return;

    const channel = supabase.channel('online-members', {
      config: {
        presence: {
          key: user.id,
        },
      },
    });

    channel
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState();
        const onlineIds = new Set<string>();
        
        // Extract all user_id from presence state
        Object.values(state).forEach((presences: any) => {
          presences.forEach((presence: any) => {
            if (presence.user_id) {
              onlineIds.add(presence.user_id);
            }
          });
        });
        
        console.log('👥 Online users:', Array.from(onlineIds));
        
        // Broadcast online users to all components
        window.dispatchEvent(new CustomEvent('online-users-updated', {
          detail: { onlineUserIds: Array.from(onlineIds) }
        }));
      })
      .on('presence', { event: 'join' }, ({ key, newPresences }) => {
        console.log('🟢 User joined:', key, newPresences);
      })
      .on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
        console.log('🔴 User left:', key, leftPresences);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({
            user_id: user.id,
            online_at: new Date().toISOString(),
          });
          console.log('✅ Tracking presence for user:', user.id);
        }
      });

    setPresenceChannel(channel);

    return () => {
      channel.untrack();
      channel.unsubscribe();
    };
  }, [user]);

  // Route protection for sales role (only after role is loaded)
  useEffect(() => {
    if (roleLoading) return; // wait until role resolved

    const restrictedPaths = ["/dashboard", "/reports", "/settings"]; // base restricted paths

    // Only restrict if user is strictly sales (not owner/admin)
    if (isSales && !isOwner && !isAdmin) {
      const path = location.pathname;
      const params = new URLSearchParams(location.search);
      const allowReportsDetailed = (path === "/reports" && params.get("tab") === "detailed") || path === "/reports/detailed";
      if (restrictedPaths.includes(path) && !allowReportsDetailed) {
        // Silently redirect without showing error toast during login/initial load
        navigate("/sales-performance", { replace: true });
      }
    }
  }, [roleLoading, isSales, isOwner, isAdmin, location.pathname, location.search, navigate]);

  const handleLogout = async () => {
    try {
      // Untrack presence before logout
      if (presenceChannel) {
        await presenceChannel.untrack();
      }
      
      // CRITICAL SECURITY: Clear React Query cache first to prevent data leaks
      queryClient.clear();
      
      // Clear all session data
      await supabase.auth.signOut();
      
      // CRITICAL: Clear ALL localStorage to prevent role confusion and cache issues
      localStorage.clear();
      
      // CRITICAL: Clear ALL sessionStorage 
      sessionStorage.clear();
      
      // Reset all state
      setUser(null);
      setFullName(null);
      setPosition(null);
      setPhotoUrl(null);
      
      toast({ title: "Berhasil keluar" });
      
      // CRITICAL: Hard redirect to auth page to ensure all cache is cleared
      // This prevents any cached data or role information from persisting
      window.location.href = '/auth';
    } catch (error) {
      console.error("Logout error:", error);
      toast({ 
        title: "Terjadi kesalahan saat keluar",
        variant: "destructive" 
      });
    }
  };

  const handleRefresh = async () => {
    // Dispatch custom event that pages can listen to
    window.dispatchEvent(new CustomEvent('page-refresh'));
    
    // Small delay to show the refresh animation
    await new Promise(resolve => setTimeout(resolve, 500));
    
    toast({ 
      title: "Halaman diperbarui",
      duration: 2000 
    });
  };

  if (!user) return null;

  return (
    <>
      <SidebarProvider defaultOpen={!isMobile}>
        <SwipeHandler />
        <div className="min-h-screen flex w-full">
          <AppSidebar />
          <div className="flex-1 flex flex-col">
            <header className="fixed top-0 left-0 right-0 z-[100] min-h-[56px] sm:h-14 border-b-2 border-primary/30 bg-card flex items-center px-3 sm:px-4 justify-between gap-2 shadow-lg pt-safe-top">
              <SidebarTrigger className="min-h-[44px] min-w-[44px]" />
              
              {/* Verification Badge - Only visible when there are pending verifications */}
              {verificationCount > 0 && (
                <Button 
                  onClick={() => navigate("/verifications")} 
                  variant="ghost" 
                  size="sm" 
                  className="relative min-h-[44px] min-w-[44px]"
                >
                  <ClipboardCheck className="h-4 w-4 sm:h-5 sm:w-5" />
                  <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs animate-pulse">
                    {verificationCount}
                  </Badge>
                </Button>
              )}
              
              {/* Inbox Button */}
              <Button 
                onClick={() => navigate("/inbox")} 
                variant="ghost" 
                size="sm" 
                className="relative min-h-[44px] min-w-[44px]"
              >
                <Inbox className="h-4 w-4 sm:h-5 sm:w-5" />
                {unreadMessageCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {unreadMessageCount}
                  </Badge>
                )}
              </Button>
              
              {/* Center - Business Logo & Name (Responsive) */}
              <div className="flex items-center gap-2 sm:gap-3 sm:absolute sm:left-1/2 sm:transform sm:-translate-x-1/2">
              {logoUrl && (
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-md overflow-hidden flex-shrink-0 animate-logo-container">
                    <img 
                      key={logoUrl}
                      src={logoUrl} 
                      alt="Logo" 
                      className="w-full h-full object-cover animate-logo"
                    />
                  </div>
                )}
                <span className="text-base sm:text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent truncate max-w-[120px] sm:max-w-none font-mono">
                  {businessName || "Sistem Kredit"}
                </span>
              </div>

              {/* Right - User Info & Logout */}
              <div className="flex items-center gap-2 sm:gap-4 ml-auto">
                {fullName && position && (
                  <div className="flex items-center gap-2 sm:gap-3">
                    {photoUrl && (
                      <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full overflow-hidden flex-shrink-0">
                        <img 
                          src={photoUrl} 
                          alt={fullName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div className="hidden lg:flex items-center gap-2">
                      <span className="text-sm font-semibold text-foreground">{fullName}</span>
                      <span className="text-sm text-muted-foreground">-</span>
                      <span className="text-sm text-muted-foreground capitalize">{position}</span>
                    </div>
                  </div>
                )}
                <Button onClick={handleLogout} variant="ghost" size="sm" className="min-h-[44px] min-w-[44px]">
                  <LogOut className="h-4 w-4 sm:mr-2" />
                  <span className="hidden sm:inline">Keluar</span>
                </Button>
              </div>
            </header>
            <main className="flex-1 overflow-hidden relative pt-[calc(56px+env(safe-area-inset-top))] sm:pt-[calc(3.5rem+env(safe-area-inset-top))]">
              <div className="h-[calc(100vh-56px)] sm:h-[calc(100vh-3.5rem)] w-full p-3 sm:p-6 overflow-auto bg-gradient-to-br from-background via-primary/5 to-accent/10">
                <div className="w-full max-w-full overflow-x-auto">
                  <MaintenanceBanner />
                  <Outlet />
                </div>
              </div>
              <RealtimeClock />
            </main>
          </div>
        </div>
      </SidebarProvider>
      
      <IdleWarningDialog
        open={showWarning} 
        remainingTime={remainingTime}
        onExtend={extendSession}
      />
    </>
  );
}
