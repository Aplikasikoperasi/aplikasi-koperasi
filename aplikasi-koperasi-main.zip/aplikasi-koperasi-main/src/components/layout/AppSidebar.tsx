import { useEffect, useState, useRef, useCallback } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, Users, UserCheck, UserX, FileText, Calendar, DollarSign, BarChart3, Settings, Building2, ScrollText, MessageCircle, Database, Clock, TrendingUp, RefreshCw, Wallet, Receipt } from "lucide-react";
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar } from "@/components/ui/sidebar";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "@/hooks/useUserRole";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatRupiah, formatDate } from "@/lib/utils";
import { useBusinessInfo } from "@/hooks/useBusinessInfo";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { APP_VERSION, checkForUpdates } from "@/lib/version";
const items = [{
  title: "Dasbor",
  url: "/dashboard",
  icon: LayoutDashboard,
  hideForKasir: true
}, {
  title: "Dashboard Kasir",
  url: "/cashier-dashboard",
  icon: LayoutDashboard,
  kasirOnly: true
}, {
  title: "Anggota Nasabah Debitur",
  url: "/members-customers",
  icon: Users
}, {
  title: "Kredit & Pembayaran",
  url: "/installments-payments",
  icon: FileText
}, {
  title: "Portal Verifikasi",
  url: "/verifications",
  icon: Clock
}, {
  title: "Biaya Operasional",
  url: "/expenses",
  icon: Receipt,
  kasirAdminOwnerOnly: true
}, {
  title: "Pinjaman Aktif",
  url: "/reports/detailed",
  icon: TrendingUp,
  salesOnly: true
}, {
  title: "WhatsApp",
  url: "/whatsapp",
  icon: MessageCircle
}, {
  title: "Broadcast Pesan",
  url: "/broadcast-messages",
  icon: MessageCircle,
  ownerAdminOnly: true
}, {
  title: "Laporan",
  url: "/reports",
  icon: BarChart3,
  ownerAdminOnly: true
}, {
  title: "Pengaturan",
  url: "/settings",
  icon: Settings,
  ownerOnly: true
}];

// Saldo menu item - separated to always be at the bottom
const saldoMenuItem = {
  title: "Saldo",
  url: "/member-balance",
  icon: Wallet,
  memberBalanceOnly: true
};
export function AppSidebar() {
  const {
    state,
    open,
    setOpen,
    openMobile,
    setOpenMobile
  } = useSidebar();
  const location = useLocation();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const isCollapsed = state === "collapsed";
  const {
    businessName,
    logoUrl
  } = useBusinessInfo();
  const {
    role,
    isOwner,
    isAdmin,
    isSales,
    isKasir
  } = useUserRole();
  const [activeLoans, setActiveLoans] = useState<any[]>([]);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateProgress, setUpdateProgress] = useState(0);
  const [updateStatus, setUpdateStatus] = useState<string>("");
  const [incentiveEnabled, setIncentiveEnabled] = useState(false);
  const [memberBalance, setMemberBalance] = useState<number>(0);
  const [bonusBalance, setBonusBalance] = useState<number>(0);
  const [hasMemberBalance, setHasMemberBalance] = useState<boolean>(false);
  const {
    toast
  } = useToast();

  // Auto-close timer ref
  const autoCloseTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Function to close sidebar
  const closeSidebar = useCallback(() => {
    setOpen(false);
    setOpenMobile(false);
  }, [setOpen, setOpenMobile]);

  // Function to reset auto-close timer (5 seconds)
  const resetAutoCloseTimer = useCallback(() => {
    if (autoCloseTimerRef.current) {
      clearTimeout(autoCloseTimerRef.current);
    }
    autoCloseTimerRef.current = setTimeout(() => {
      closeSidebar();
    }, 5000);
  }, [closeSidebar]);

  // Start/stop timer when sidebar opens/closes
  useEffect(() => {
    const isOpen = open || openMobile;
    if (isOpen) {
      resetAutoCloseTimer();
    } else {
      if (autoCloseTimerRef.current) {
        clearTimeout(autoCloseTimerRef.current);
        autoCloseTimerRef.current = null;
      }
    }
    return () => {
      if (autoCloseTimerRef.current) {
        clearTimeout(autoCloseTimerRef.current);
      }
    };
  }, [open, openMobile, resetAutoCloseTimer]);

  // Additional verification counts
  const [pendingCustomersCount, setPendingCustomersCount] = useState(0);
  const [pendingApplicationsCount, setPendingApplicationsCount] = useState(0);
  const [restorationRequestsCount, setRestorationRequestsCount] = useState(0);
  const [changeRequestsCount, setChangeRequestsCount] = useState(0);
  const [withdrawalRequestsCount, setWithdrawalRequestsCount] = useState(0);
  const [pendingExpensesCount, setPendingExpensesCount] = useState(0);
  const [pendingSaverTransactionsCount, setPendingSaverTransactionsCount] = useState(0);

  // Load verification counts with real-time updates - visible for all roles
  useEffect(() => {
    const loadVerificationCounts = async () => {
      try {
        // ✅ Filter restoration requests: hanya count yang customernya MASIH diblokir
        const {
          data: pendingRestoration
        } = await supabase.from("customer_restoration_requests").select("customer_id").eq("status", "pending");
        let validRestorationCount = 0;
        if (pendingRestoration && pendingRestoration.length > 0) {
          const customerIds = pendingRestoration.map(r => r.customer_id);
          const {
            data: blockedCustomers
          } = await supabase.from("blocked_customers").select("customer_id").in("customer_id", customerIds);
          const blockedSet = new Set((blockedCustomers || []).map(b => b.customer_id));
          validRestorationCount = pendingRestoration.filter(r => blockedSet.has(r.customer_id)).length;
        }

        // Get pending saver transactions count
        const { count: pendingSaverDeposits } = await supabase
          .from("saver_deposits")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending");

        const { count: pendingSaverWithdrawals } = await supabase
          .from("saver_withdrawals")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending");

        // Also count pending withdrawals waiting for PIN confirmation
        const { count: pendingPinWithdrawals } = await supabase
          .from("saver_pending_withdrawals")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending");

        const pendingSaverTransactions = (pendingSaverDeposits || 0) + (pendingSaverWithdrawals || 0) + (pendingPinWithdrawals || 0);

        const [{
          count: customersCount
        }, {
          count: applicationsCount
        }, {
          count: changeCount
        }, {
          count: withdrawalCount
        }, {
          count: expensesCount
        }] = await Promise.all([supabase.from("customers").select("*", {
          count: "exact",
          head: true
        }).eq("status", "pending"), supabase.from("credit_applications").select("*", {
          count: "exact",
          head: true
        }).eq("status", "pending"), supabase.from("customer_change_requests").select("*", {
          count: "exact",
          head: true
        }).eq("status", "pending"), supabase.from("member_balance_withdrawals").select("*", {
          count: "exact",
          head: true
        }).eq("status", "pending"), supabase.from("expenses").select("*", {
          count: "exact",
          head: true
        }).eq("status", "pending")]);
        setPendingCustomersCount(customersCount || 0);
        setPendingApplicationsCount(applicationsCount || 0);
        setRestorationRequestsCount(validRestorationCount);
        setChangeRequestsCount(changeCount || 0);
        setWithdrawalRequestsCount(withdrawalCount || 0);
        setPendingExpensesCount(expensesCount || 0);
        setPendingSaverTransactionsCount(pendingSaverTransactions);
      } catch (err) {
        console.error("Failed to load verification counts", err);
      }
    };
    loadVerificationCounts();
    const channel = supabase.channel('verification-updates').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customers'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'credit_applications'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customer_restoration_requests'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'blocked_customers'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'customer_change_requests'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'member_balance_withdrawals'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'expenses'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'saver_deposits'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'saver_withdrawals'
    }, loadVerificationCounts).on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'saver_pending_withdrawals'
    }, loadVerificationCounts).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Total verification count for all roles
  const verificationCount = pendingCustomersCount + pendingApplicationsCount + restorationRequestsCount + changeRequestsCount + withdrawalRequestsCount + pendingExpensesCount + pendingSaverTransactionsCount;
  const handleMouseEnter = () => {
    setOpen(true);
    resetAutoCloseTimer();
  };
  const handleMouseLeave = () => {
    // On mouse leave, close immediately instead of waiting for timer
    closeSidebar();
  };

  // Load incentive settings to show/hide Saldo menu
  useEffect(() => {
    const loadIncentiveSettings = async () => {
      const {
        data
      } = await (supabase as any).from("incentive_settings").select("is_enabled").single();
      setIncentiveEnabled(data?.is_enabled || false);
    };
    loadIncentiveSettings();

    // Subscribe to changes
    const channel = supabase.channel("incentive-settings-changes").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "incentive_settings"
    }, loadIncentiveSettings).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Load member balance for staff users (sales, admin, owner, kasir if enabled)
  useEffect(() => {
    // Skip if incentive not enabled at all
    if (!incentiveEnabled) {
      setHasMemberBalance(false);
      return;
    }

    // Skip for kasir if kasir incentive is not enabled (will be checked via separate query)
    // For owner/admin/sales - always check their balance
    const loadMemberBalance = async () => {
      // Get current member ID
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) return;
      const {
        data: member
      } = await supabase.from("members").select("id").eq("user_id", user.id).single();
      if (!member) return;

      // Get balance details using same RPC as MemberBalance page
      const {
        data: balanceData,
        error: balanceError
      } = await supabase.rpc("get_member_balance_detailed", {
        p_member_id: member.id
      });
      if (balanceError) {
        console.error('[AppSidebar] Error getting balance:', balanceError);
      }

      // Handle both array and single object responses
      const balanceObj = Array.isArray(balanceData) ? balanceData[0] : balanceData;
      const totalBalance = Number(balanceObj?.total_balance) || 0;

      // Get available balance (subtracts pending withdrawals)
      const {
        data: availableBalance
      } = await supabase.rpc("get_member_available_balance", {
        p_member_id: member.id
      });
      const regularAvailableBalance = Number(availableBalance) || 0;

      // Get held balance (saldo tertahan) from monthly summary
      const {
        data: heldRows,
        error: heldError
      } = await supabase.from("member_monthly_balance_summary").select("available_balance").eq("member_id", member.id).eq("is_held", true);
      if (heldError) {
        console.error('[AppSidebar] Error getting held balance:', heldError);
      }
      const heldBalance = (heldRows || []).reduce((sum, r: any) => sum + Number(r.available_balance || 0), 0);

      // Use thr_balance directly from RPC for consistency with MemberBalance page
      // The RPC already calculates: sum of all year_end_bonus transactions minus pending withdrawals
      const thrBalance = Number(balanceObj?.thr_balance) || 0;

      // Get incentive settings to check if holiday bonus is enabled
      const {
        data: incentiveSettings
      } = await supabase.from("incentive_settings").select("holiday_enabled, kasir_holiday_enabled").maybeSingle();

      // Determine bonus balance based on incentive settings
      const bonusBalance = incentiveSettings?.holiday_enabled || incentiveSettings?.kasir_holiday_enabled ? thrBalance : 0;
      console.log('[AppSidebar] Regular available balance:', regularAvailableBalance);
      console.log('[AppSidebar] Held balance:', heldBalance);
      console.log('[AppSidebar] Bonus balance:', bonusBalance);

      // Show menu if there's any balance: available, held, total, or year-end bonus
      const hasAnyBalance = totalBalance > 0 || regularAvailableBalance > 0 || heldBalance > 0 || bonusBalance > 0;
      setHasMemberBalance(hasAnyBalance);

      // Set regular and bonus balances separately
      setMemberBalance(regularAvailableBalance);
      setBonusBalance(bonusBalance);
    };
    loadMemberBalance();

    // Subscribe to balance changes
    const channel = supabase.channel("sidebar-balance").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "member_monthly_balance_summary"
    }, loadMemberBalance).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "member_balance_transactions"
    }, loadMemberBalance).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "member_balance_withdrawals"
    }, loadMemberBalance).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "payments"
    }, loadMemberBalance).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "credit_applications"
    }, loadMemberBalance).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "incentive_settings"
    }, loadMemberBalance).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [isSales, isKasir, isAdmin, isOwner, incentiveEnabled, role]);

  // Load active loans for sales users on mobile
  useEffect(() => {
    if (!isMobile || !isSales) return;
    const loadActiveLoans = async () => {
      const {
        data: applications
      } = await supabase.from("credit_applications").select(`
          id,
          application_number,
          amount_approved,
          approved_at,
          customers(full_name),
          members(full_name)
        `).in("status", ["approved", "disbursed"]).order("approved_at", {
        ascending: false
      }).limit(10);
      if (!applications) return;
      const loansWithDetails = await Promise.all(applications.map(async app => {
        const {
          data: installments
        } = await supabase.from("installments").select("total_amount, paid_amount, status, frozen_penalty").eq("application_id", app.id);
        const totalPaid = installments?.reduce((sum, i) => sum + Number(i.paid_amount), 0) || 0;
        const totalOutstanding = installments?.reduce((sum, i) => sum + (Number(i.total_amount) - Number(i.paid_amount)), 0) || 0;
        return {
          id: app.id,
          application_number: app.application_number,
          customer_name: (app.customers as any)?.full_name || "N/A",
          member_name: (app.members as any)?.full_name || "N/A",
          amount_approved: app.amount_approved || 0,
          approved_at: app.approved_at,
          total_paid: totalPaid,
          total_outstanding: totalOutstanding
        };
      }));
      setActiveLoans(loansWithDetails);
    };
    loadActiveLoans();

    // Realtime subscription
    const channel = supabase.channel("sidebar-loans").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "credit_applications"
    }, loadActiveLoans).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "installments"
    }, loadActiveLoans).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "payments"
    }, loadActiveLoans).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [isMobile, isSales]);

  // Auto-close sidebar on route change in mobile view
  useEffect(() => {
    if (isMobile) {
      setOpen(false);
      setOpenMobile(false);
    }
  }, [location.pathname, isMobile, setOpen, setOpenMobile]);

  // Ensure sidebar closes on orientation change (mobile)
  useEffect(() => {
    const handleOrientation = () => setOpenMobile(false);
    window.addEventListener('orientationchange', handleOrientation);
    return () => window.removeEventListener('orientationchange', handleOrientation);
  }, [setOpenMobile]);
  const handleMenuItemClick = () => {
    // Auto-close sidebar on all devices when menu item is clicked
    closeSidebar();
    // Clear the auto-close timer since we're closing immediately
    if (autoCloseTimerRef.current) {
      clearTimeout(autoCloseTimerRef.current);
      autoCloseTimerRef.current = null;
    }
  };
  const handleCheckForUpdates = async () => {
    if (!('serviceWorker' in navigator)) {
      toast({
        title: "Update Tidak Didukung",
        description: "Browser Anda tidak mendukung fitur update otomatis",
        variant: "destructive"
      });
      return;
    }
    
    setCheckingUpdate(true);
    setUpdateProgress(0);
    setUpdateStatus("Memeriksa update...");
    
    try {
      console.log('🔍 Checking for updates...');
      
      // Step 1: Check if there's actually an update available
      setUpdateProgress(25);
      const { hasUpdate, currentVersion } = await checkForUpdates();
      
      if (!hasUpdate) {
        // No update available - show message and don't reload
        setUpdateProgress(100);
        setUpdateStatus("Sudah versi terbaru!");
        
        toast({
          title: "✅ Sudah Versi Terbaru",
          description: `Versi ${currentVersion} - Tidak ada update baru`,
          duration: 3000
        });
        
        // Reset state after showing message
        setTimeout(() => {
          setCheckingUpdate(false);
          setUpdateProgress(0);
          setUpdateStatus("");
        }, 2000);
        
        return;
      }
      
      // Update available - proceed with update
      console.log('🔄 Update found, proceeding...');
      
      toast({
        title: "🔄 Update Ditemukan!",
        description: "Mengunduh versi baru...",
        duration: 3000
      });

      // Step 2: Clear ALL caches
      setUpdateProgress(50);
      setUpdateStatus("Menghapus cache lama...");
      
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        console.log('🗑️ Found caches:', cacheNames);
        for (const cacheName of cacheNames) {
          console.log('🗑️ Clearing cache:', cacheName);
          await caches.delete(cacheName);
        }
        console.log('✅ All caches cleared');
      }

      // Step 3: Activate new service worker
      setUpdateProgress(75);
      setUpdateStatus("Mengaktifkan versi baru...");
      
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration?.waiting) {
          // Tell the waiting service worker to activate
          registration.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
      }

      // Step 4: Complete and reload
      setUpdateProgress(100);
      setUpdateStatus("Reload halaman...");
      
      toast({
        title: "🔄 Mengunduh Versi Baru...",
        description: "Aplikasi akan reload dalam 1 detik...",
        duration: 2000
      });

      // Reload to activate the new version
      setTimeout(() => {
        console.log('🔄 Reloading to activate new version...');
        window.location.reload();
      }, 1000);
      
    } catch (error) {
      console.error('❌ Update check failed:', error);
      setCheckingUpdate(false);
      setUpdateProgress(0);
      setUpdateStatus("");
      toast({
        title: "❌ Gagal Memeriksa Update",
        description: "Terjadi kesalahan saat memeriksa update",
        variant: "destructive"
      });
    }
  };

  // Filter menu items based on role
  console.log('🔐 Current user role in sidebar:', role);
  console.log('🎁 Incentive enabled:', incentiveEnabled);
  const filteredItems = items.filter(item => {
    // Owner-only items
    if ('ownerOnly' in item && item.ownerOnly && !isOwner) {
      return false;
    }

    // Filter owner/admin only items for sales
    if ('ownerAdminOnly' in item && item.ownerAdminOnly && !isOwner && !isAdmin) {
      return false;
    }

    // Kasir/Admin/Owner only items (like Pengeluaran)
    if ('kasirAdminOwnerOnly' in item && item.kasirAdminOwnerOnly) {
      return isKasir || isAdmin || isOwner;
    }

    // Sales-only items (Pinjaman Aktif, Laporan Kinerja) ONLY for pure sales role
    // Owner and Admin use the full "Laporan" menu instead
    if (item.salesOnly) {
      return isSales && !isOwner && !isAdmin;
    }

    // Sales role (non-owner, non-admin) - restricted menu
    if (isSales && !isOwner && !isAdmin) {
      // Sales can see: Dashboard (which now shows SalesPerformance), Anggota Nasabah Debitur, Portal Verifikasi, Kredit & Pembayaran, Pinjaman Aktif, WhatsApp
      const salesMenus = ["Dasbor", "Anggota Nasabah Debitur", "Portal Verifikasi", "Kredit & Pembayaran", "Pinjaman Aktif", "WhatsApp"];
      return salesMenus.includes(item.title);
    }

    // Admin role (non-owner) - sees everything except Settings
    if (isAdmin && !isOwner) {
      return item.title !== "Pengaturan";
    }

    // Owner sees all items
    if (isOwner) {
      return true;
    }

    // Default - allow
    return true;
  });

  // Check if Saldo menu should be shown and add it at the end
  // Show for any staff member who has balance and incentive is enabled
  const shouldShowSaldo = incentiveEnabled && hasMemberBalance && (isSales || isAdmin || isOwner || isKasir);
  const finalMenuItems = shouldShowSaldo ? [...filteredItems, saldoMenuItem] : filteredItems;
  console.log('📋 Filtered menu items:', finalMenuItems.map(i => i.title));
  return <Sidebar className="bg-gradient-to-b from-card via-card/95 to-primary/5 border-r-2 border-primary/20 shadow-lg backdrop-blur-sm h-dvh" collapsible="icon" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
      <SidebarContent className="bg-transparent text-foreground h-full flex flex-col overflow-hidden">
        {/* Logo Section - Dynamic sizing */}
        <SidebarGroup className="flex-shrink-0">
          <div className="flex flex-col items-center gap-1 sm:gap-2 border-b-2 border-primary/30 backdrop-blur-sm relative overflow-hidden px-2 sm:px-4 py-2 sm:py-4 mt-12 sm:mt-14">
            {/* Shimmer overlay effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" style={{
            backgroundSize: '200% 100%'
          }}></div>
            
            <div className="relative z-10 flex flex-col items-center w-full rounded-none">
            {logoUrl ? <div className={`overflow-hidden transition-all duration-200 animate-logo-container ${isCollapsed && !isMobile ? 'w-12 h-12' : 'w-full max-w-[min(120px,15vh)] h-auto'}`}>
                <img key={logoUrl} src={logoUrl} alt="Logo" className="w-full h-full object-contain animate-logo" />
              </div> : <div className={`bg-primary flex items-center justify-center transition-all duration-200 ${isCollapsed && !isMobile ? 'w-12 h-12 rounded-xl' : 'w-full max-w-[min(120px,15vh)] aspect-square'}`}>
                <Building2 className={`text-primary-foreground ${isCollapsed && !isMobile ? 'w-6 h-6' : 'w-16 h-16 sm:w-20 sm:h-20'}`} />
              </div>}
            </div>
          </div>
        </SidebarGroup>

        {/* Member Balance Section - For Staff with Incentive Enabled - Clickable */}
        {incentiveEnabled && hasMemberBalance && (isSales || isAdmin || isOwner || isKasir) && <SidebarGroup className="flex-shrink-0">
            {/* Expanded state - show full details */}
            {(isMobile || !isCollapsed) && <div onClick={() => navigate('/member-balance')} className="px-2 sm:px-4 py-1.5 sm:py-2 border-b border-sidebar-border cursor-pointer hover:bg-sidebar-accent transition-colors relative">
                {/* Pulse indicator for available balance */}
                {(memberBalance > 0 || bonusBalance > 0) && <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />}
                <div className="space-y-0.5 sm:space-y-1 pr-3">
                  {memberBalance > 0 && <p className="text-xs sm:text-sm font-bold text-foreground">
                      Insentif: <span className="text-blue-700">{formatRupiah(memberBalance)}</span>
                    </p>}
                  {bonusBalance > 0 && <p className="text-xs sm:text-sm font-bold text-foreground">
                      Bonus: <span className="text-emerald-600">{formatRupiah(bonusBalance)}</span>
                    </p>}
                  <p className="text-[10px] sm:text-xs text-muted-foreground">Klik untuk detail →</p>
                </div>
              </div>}
            {/* Collapsed state - show icon with hover card */}
            {!isMobile && isCollapsed && <HoverCard openDelay={100} closeDelay={100}>
                <HoverCardTrigger asChild>
                  <div onClick={() => navigate('/member-balance')} className="px-2 py-2 border-b border-sidebar-border cursor-pointer hover:bg-sidebar-accent transition-colors flex justify-center relative">
                    <div className="relative">
                      <Wallet className="h-4 w-4 text-primary" />
                      {(memberBalance > 0 || bonusBalance > 0) && <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />}
                    </div>
                  </div>
                </HoverCardTrigger>
                <HoverCardContent side="right" align="start" className="w-56 p-3">
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-foreground flex items-center gap-2">
                      <Wallet className="h-4 w-4 text-primary" />
                      Saldo Anda
                    </p>
                    <Separator />
                    <div className="space-y-1.5">
                      {memberBalance > 0 && <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">Insentif Reguler</span>
                          <span className="text-sm font-bold text-blue-600">{formatRupiah(memberBalance)}</span>
                        </div>}
                      {bonusBalance > 0 && <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">Bonus Akhir Tahun</span>
                          <span className="text-sm font-bold text-emerald-600">{formatRupiah(bonusBalance)}</span>
                        </div>}
                      {memberBalance > 0 && bonusBalance > 0 && <>
                          <Separator className="my-1" />
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-medium text-foreground">Total</span>
                            <span className="text-sm font-bold text-primary">{formatRupiah(memberBalance + bonusBalance)}</span>
                          </div>
                        </>}
                    </div>
                    <p className="text-xs text-muted-foreground pt-1">Klik untuk detail →</p>
                  </div>
                </HoverCardContent>
              </HoverCard>}
          </SidebarGroup>}

        {/* Menu Section - Flex grow to fill available space */}
        <SidebarGroup className="flex-1 min-h-0 overflow-y-auto">
          <SidebarGroupLabel className="text-[10px] sm:text-xs font-bold text-foreground uppercase tracking-wider px-2 sm:px-3 py-1 sm:py-1.5">
            Menu Utama
          </SidebarGroupLabel>
          <SidebarGroupContent className="flex-1">
            <SidebarMenu className="gap-0.5 sm:gap-1 px-1.5 sm:px-3 py-1 text-foreground">
              {items.filter((item: any) => {
              // Filter based on role
              if (item.kasirOnly) return isKasir;
              if (item.hideForKasir && isKasir) return false;
              if (item.ownerOnly) return isOwner; // Only owner can access
              if (item.ownerAdminOnly) return isOwner || isAdmin;
              if (item.kasirAdminOwnerOnly) return isKasir || isAdmin || isOwner;
              if (item.salesOnly) return isSales && !isOwner && !isAdmin;
              return true;
            }).map((item: any) => {
              const hasQueryParams = item.url.includes('?');
              const toProp = hasQueryParams ? {
                pathname: item.url.split('?')[0],
                search: `?${item.url.split('?')[1]}`
              } : item.url;
              const showBadge = item.url === "/verifications" && verificationCount > 0;
              return <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink to={toProp as any} onClick={handleMenuItemClick} aria-disabled={false} className={({
                    isActive
                  }) => `group relative flex items-center gap-2 sm:gap-3 rounded-lg px-2 sm:px-3 py-1.5 sm:py-2 opacity-100 ${isActive ? 'bg-primary text-primary-foreground shadow-sm font-semibold' : 'text-foreground hover:bg-sidebar-accent hover:text-foreground'}`}>
                        <item.icon className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0 text-foreground" />
                        <span className="text-xs sm:text-sm font-medium text-foreground truncate" title={item.title}>{item.title}</span>
                        {showBadge && <Badge variant="destructive" className="ml-auto text-[10px] px-1.5 py-0.5">
                            {verificationCount}
                          </Badge>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>;
            })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Update Check Section - Fixed at bottom */}
        <div className="flex-shrink-0 border-t border-sidebar-border">
          <SidebarGroup>
            <SidebarGroupContent className="px-1.5 sm:px-3 py-2 sm:py-3">
              <Button onClick={handleCheckForUpdates} disabled={checkingUpdate} variant="outline" size="sm" className="w-full justify-start gap-2 sm:gap-3 hover:bg-sidebar-accent h-8 sm:h-9">
                <RefreshCw className={`h-3.5 w-3.5 sm:h-4 sm:w-4 ${checkingUpdate ? 'animate-spin' : ''}`} />
                <span className="text-xs sm:text-sm font-medium">
                  {checkingUpdate ? 'Memperbarui...' : 'Periksa & Update'}
                </span>
              </Button>
              
              {checkingUpdate && <div className="mt-2 space-y-1">
                  <div className="w-full bg-secondary rounded-full h-1.5 overflow-hidden">
                    <div className="bg-primary h-full transition-all duration-500 ease-out" style={{
                  width: `${updateProgress}%`
                }} />
                  </div>
                  <p className="text-[10px] text-muted-foreground px-1">
                    {updateStatus} ({updateProgress.toFixed(1)}%)
                  </p>
                </div>}
              
              {/* App Version */}
              <div className="mt-2 text-center">
                <span className="text-[10px] text-muted-foreground/70">
                  Versi {APP_VERSION}
                </span>
              </div>
            </SidebarGroupContent>
          </SidebarGroup>
        </div>

      </SidebarContent>
    </Sidebar>;
}