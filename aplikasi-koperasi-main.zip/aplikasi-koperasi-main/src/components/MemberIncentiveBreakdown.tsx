import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { Award, TrendingUp, FileText, DollarSign, ChevronLeft, ChevronRight } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, subMonths } from "date-fns";
import { id } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

const ITEMS_PER_PAGE = 15;

interface IncentiveDetail {
  id: string;
  description: string;
  amount: number;
  created_at: string;
  reference_number?: string;
  customer_name?: string;
  payment_id?: string;
  type: "credit_application" | "installment_payment";
}
interface IncentiveBreakdown {
  credit_application: {
    total: number;
    count: number;
    details: IncentiveDetail[];
  };
  installment_payment: {
    total: number;
    count: number;
    details: IncentiveDetail[];
  };
  total: number;
}
interface MemberIncentiveBreakdownProps {
  memberId: string;
}
export function MemberIncentiveBreakdown({
  memberId
}: MemberIncentiveBreakdownProps) {
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), "yyyy-MM"));
  const [creditAppPage, setCreditAppPage] = useState(1);
  const [installmentPage, setInstallmentPage] = useState(1);
  const [breakdown, setBreakdown] = useState<IncentiveBreakdown>({
    credit_application: {
      total: 0,
      count: 0,
      details: []
    },
    installment_payment: {
      total: 0,
      count: 0,
      details: []
    },
    total: 0
  });

  // Generate last 12 months for dropdown
  const monthOptions = Array.from({
    length: 12
  }, (_, i) => {
    const date = subMonths(new Date(), i);
    return {
      value: format(date, "yyyy-MM"),
      label: format(date, "MMMM yyyy", {
        locale: id
      })
    };
  });
  // Reset pages when month changes
  useEffect(() => {
    setCreditAppPage(1);
    setInstallmentPage(1);
  }, [selectedMonth]);

  useEffect(() => {
    if (memberId) {
      loadIncentiveBreakdown();
    }
  }, [memberId, selectedMonth]);

  // Pagination helpers
  const getCreditAppPaginatedData = () => {
    const start = (creditAppPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    return breakdown.credit_application.details.slice(start, end);
  };

  const getInstallmentPaginatedData = () => {
    const start = (installmentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    return breakdown.installment_payment.details.slice(start, end);
  };

  const creditAppTotalPages = Math.ceil(breakdown.credit_application.details.length / ITEMS_PER_PAGE);
  const installmentTotalPages = Math.ceil(breakdown.installment_payment.details.length / ITEMS_PER_PAGE);

  const PaginationControls = ({ 
    currentPage, 
    totalPages, 
    onPageChange,
    totalItems 
  }: { 
    currentPage: number; 
    totalPages: number; 
    onPageChange: (page: number) => void;
    totalItems: number;
  }) => {
    if (totalPages <= 1) return null;
    
    const startItem = (currentPage - 1) * ITEMS_PER_PAGE + 1;
    const endItem = Math.min(currentPage * ITEMS_PER_PAGE, totalItems);
    
    return (
      <div className="flex items-center justify-between px-2 py-3 border-t">
        <div className="text-xs text-muted-foreground">
          Menampilkan {startItem}-{endItem} dari {totalItems}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="h-8 w-8 p-0"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-1 px-2">
            <span className="text-sm font-medium">{currentPage}</span>
            <span className="text-xs text-muted-foreground">/ {totalPages}</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="h-8 w-8 p-0"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };
  const loadIncentiveBreakdown = async () => {
    try {
      setLoading(true);
      
      // Use period_month for filtering (format: YYYY-MM)
      // This matches how incentives are recorded based on payment_date, not created_at
      const {
        data: transactions,
        error
      } = await supabase.from("member_balance_transactions").select("*").eq("member_id", memberId).eq("period_month", selectedMonth).in("type", ["credit_application", "installment_payment"]).order("created_at", {
        ascending: false
      });
      if (error) throw error;

      // Fetch related data separately if transactions exist
      let applicationMap: Record<string, {
        application_number: string;
        customer_name: string;
      }> = {};
      let paymentMap: Record<string, {
        reference_number: string;
        customer_name: string;
      }> = {};
      if (transactions && transactions.length > 0) {
        // Get unique application IDs
        const applicationIds = [...new Set(transactions.filter(t => t.application_id).map(t => t.application_id))];
        const paymentIds = [...new Set(transactions.filter(t => t.payment_id).map(t => t.payment_id))];

        // Fetch applications
        if (applicationIds.length > 0) {
          const {
            data: applications
          } = await supabase.from("credit_applications").select("id, application_number, customers:customer_id(full_name)").in("id", applicationIds);
          applications?.forEach((app: any) => {
            applicationMap[app.id] = {
              application_number: app.application_number,
              customer_name: app.customers?.full_name || ""
            };
          });
        }

        // Fetch payments with related data
        if (paymentIds.length > 0) {
          const {
            data: payments
          } = await supabase.from("payments").select(`
              id, 
              reference_number,
              installments:installment_id(
                credit_applications:application_id(
                  customers:customer_id(full_name)
                )
              )
            `).in("id", paymentIds);
          payments?.forEach((payment: any) => {
            paymentMap[payment.id] = {
              reference_number: payment.reference_number || "",
              customer_name: payment.installments?.credit_applications?.customers?.full_name || ""
            };
          });
        }
      }

      // Calculate breakdown
      const newBreakdown: IncentiveBreakdown = {
        credit_application: {
          total: 0,
          count: 0,
          details: []
        },
        installment_payment: {
          total: 0,
          count: 0,
          details: []
        },
        total: 0
      };
      transactions?.forEach((tx: any) => {
        const amount = Number(tx.amount);
        const type = tx.type as "credit_application" | "installment_payment";
        let reference_number = "";
        let customer_name = "";
        if (type === "credit_application" && tx.application_id) {
          const appData = applicationMap[tx.application_id];
          reference_number = appData?.application_number || "";
          customer_name = appData?.customer_name || "";
        } else if (type === "installment_payment" && tx.payment_id) {
          const paymentData = paymentMap[tx.payment_id];
          reference_number = paymentData?.reference_number || "";
          customer_name = paymentData?.customer_name || "";
        }
        newBreakdown[type].total += amount;
        newBreakdown[type].count += 1;
        newBreakdown[type].details.push({
          id: tx.id,
          description: tx.description,
          amount: amount,
          created_at: tx.created_at,
          reference_number,
          customer_name,
          payment_id: tx.payment_id || undefined,
          type
        });
        newBreakdown.total += amount;
      });
      setBreakdown(newBreakdown);
    } catch (error: any) {
      console.error("Error loading incentive breakdown:", error);
    } finally {
      setLoading(false);
    }
  };
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0
    }).format(amount);
  };
  if (loading) {
    return <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            Laporan Insentif
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-32 w-full" />
        </CardContent>
      </Card>;
  }
  return <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="h-5 w-5" />
          Laporan Insentif
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Month Selector */}
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium">Periode:</label>
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {monthOptions.map(option => <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Detailed Breakdown Table */}
        {(breakdown.credit_application.details.length > 0 || breakdown.installment_payment.details.length > 0) && <div className="space-y-4">
            {/* Credit Application Details */}
            {breakdown.credit_application.details.length > 0 && <div>
                <h3 className="text-sm font-semibold mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    <span className="hidden sm:inline">Detail Insentif Pengajuan Kredit</span>
                    <span className="sm:hidden">Insentif Kredit</span>
                  </span>
                  <span className="text-xs text-muted-foreground font-normal">
                    {breakdown.credit_application.details.length} transaksi
                  </span>
                </h3>
                <div className="border rounded-lg overflow-hidden">
                  {/* Desktop Table */}
                  <div className="hidden md:block">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tanggal</TableHead>
                          <TableHead>No. Aplikasi</TableHead>
                          <TableHead>Nasabah</TableHead>
                          <TableHead>Deskripsi</TableHead>
                          <TableHead className="text-right">Jumlah</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getCreditAppPaginatedData().map(detail => <TableRow key={detail.id}>
                            <TableCell className="text-sm">
                              {format(new Date(detail.created_at), "dd MMM yyyy, HH:mm", { locale: id })}
                            </TableCell>
                            <TableCell className="font-medium text-sm">
                              {detail.reference_number || "-"}
                            </TableCell>
                            <TableCell className="text-sm">
                              {detail.customer_name || "-"}
                            </TableCell>
                            <TableCell className="text-sm">{detail.description}</TableCell>
                            <TableCell className="text-right text-sm font-medium">
                              {formatCurrency(detail.amount)}
                            </TableCell>
                          </TableRow>)}
                        <TableRow className="bg-muted/50 font-semibold">
                          <TableCell colSpan={4}>Subtotal</TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(breakdown.credit_application.total)}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                  
                  {/* Mobile Cards */}
                  <div className="md:hidden divide-y">
                    {getCreditAppPaginatedData().map(detail => (
                      <div key={detail.id} className="p-3 space-y-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{detail.customer_name || "-"}</p>
                            <p className="text-xs text-muted-foreground">{detail.reference_number || "-"}</p>
                          </div>
                          <p className="font-semibold text-sm text-green-600 whitespace-nowrap">
                            {formatCurrency(detail.amount)}
                          </p>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{detail.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(detail.created_at), "dd MMM yyyy, HH:mm", { locale: id })}
                        </p>
                      </div>
                    ))}
                    <div className="p-3 bg-muted/50 flex items-center justify-between">
                      <span className="font-semibold text-sm">Subtotal</span>
                      <span className="font-bold text-sm">{formatCurrency(breakdown.credit_application.total)}</span>
                    </div>
                  </div>
                  
                  <PaginationControls
                    currentPage={creditAppPage}
                    totalPages={creditAppTotalPages}
                    onPageChange={setCreditAppPage}
                    totalItems={breakdown.credit_application.details.length}
                  />
                </div>
              </div>}

            {/* Installment Payment Details */}
            {breakdown.installment_payment.details.length > 0 && <div>
                <h3 className="text-sm font-semibold mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    <span className="hidden sm:inline">Detail Insentif Kredit dan Pembayaran</span>
                    <span className="sm:hidden">Insentif Pembayaran</span>
                  </span>
                  <span className="text-xs text-muted-foreground font-normal">
                    {breakdown.installment_payment.details.length} transaksi
                  </span>
                </h3>
                <div className="border rounded-lg overflow-hidden">
                  {/* Desktop Table */}
                  <div className="hidden md:block">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tanggal</TableHead>
                          <TableHead>Nasabah</TableHead>
                          <TableHead>Deskripsi</TableHead>
                          <TableHead className="text-right">Jumlah</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getInstallmentPaginatedData().map(detail => <TableRow key={detail.id}>
                            <TableCell className="text-sm">
                              {format(new Date(detail.created_at), "dd MMM yyyy, HH:mm", { locale: id })}
                            </TableCell>
                            <TableCell className="text-sm">
                              {detail.customer_name || "-"}
                            </TableCell>
                            <TableCell className="text-sm">{detail.description}</TableCell>
                            <TableCell className="text-right text-sm font-medium">
                              {formatCurrency(detail.amount)}
                            </TableCell>
                          </TableRow>)}
                        <TableRow className="bg-muted/50 font-semibold">
                          <TableCell colSpan={3}>Subtotal</TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(breakdown.installment_payment.total)}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                  
                  {/* Mobile Cards */}
                  <div className="md:hidden divide-y">
                    {getInstallmentPaginatedData().map(detail => (
                      <div key={detail.id} className="p-3 space-y-1">
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-medium text-sm flex-1 min-w-0 truncate">{detail.customer_name || "-"}</p>
                          <p className="font-semibold text-sm text-green-600 whitespace-nowrap">
                            {formatCurrency(detail.amount)}
                          </p>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{detail.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(detail.created_at), "dd MMM yyyy, HH:mm", { locale: id })}
                        </p>
                      </div>
                    ))}
                    <div className="p-3 bg-muted/50 flex items-center justify-between">
                      <span className="font-semibold text-sm">Subtotal</span>
                      <span className="font-bold text-sm">{formatCurrency(breakdown.installment_payment.total)}</span>
                    </div>
                  </div>
                  
                  <PaginationControls
                    currentPage={installmentPage}
                    totalPages={installmentTotalPages}
                    onPageChange={setInstallmentPage}
                    totalItems={breakdown.installment_payment.details.length}
                  />
                </div>
              </div>}
          </div>}

        {breakdown.total === 0 && <div className="text-center py-8 text-muted-foreground">
            <Award className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Tidak ada insentif pada periode ini</p>
          </div>}
      </CardContent>
    </Card>;
}