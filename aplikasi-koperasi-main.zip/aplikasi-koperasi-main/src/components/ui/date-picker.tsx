import * as React from "react";
import { parse, format } from "date-fns";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

export type DatePickerProps = {
  value?: Date | null;
  onChange?: (date: Date | undefined) => void;
  placeholder?: string;
  disabled?: (date: Date) => boolean;
  className?: string;
  dateFormat?: string; // default: dd/MM/yyyy
  maxDate?: Date; // Tanggal maksimal yang diperbolehkan
  minDate?: Date; // Tanggal minimal yang diperbolehkan
};

export function DatePicker({
  value,
  onChange,
  placeholder = "dd/MM/yyyy",
  disabled,
  className,
  dateFormat = "dd/MM/yyyy",
  maxDate,
  minDate,
}: DatePickerProps) {
  const [text, setText] = React.useState<string>(value ? format(value, dateFormat) : "");
  const [error, setError] = React.useState<string>("");

  React.useEffect(() => {
    setText(value ? format(value, dateFormat) : "");
    setError("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, dateFormat]);

  const validateDate = (dateStr: string): { valid: boolean; error?: string; date?: Date } => {
    if (dateStr.length !== 10) {
      return { valid: false, error: "Format tanggal harus lengkap (dd/MM/yyyy)" };
    }

    const parsed = parse(dateStr, dateFormat, new Date());
    
    // Check if date is valid
    if (isNaN(parsed.getTime())) {
      return { valid: false, error: "Tanggal tidak valid" };
    }

    const year = parsed.getFullYear();
    const month = parsed.getMonth();
    const day = parsed.getDate();

    // Validate year range (1900-2100)
    if (year < 1900 || year > 2100) {
      return { valid: false, error: "Tahun harus antara 1900-2100" };
    }

    // Validate month (0-11 in JS Date)
    if (month < 0 || month > 11) {
      return { valid: false, error: "Bulan tidak valid (01-12)" };
    }

    // Validate day
    if (day < 1 || day > 31) {
      return { valid: false, error: "Tanggal tidak valid" };
    }

    // Check if the date is a real calendar date (e.g., not 31 Feb)
    const testDate = new Date(year, month, day);
    if (testDate.getDate() !== day || testDate.getMonth() !== month || testDate.getFullYear() !== year) {
      return { valid: false, error: "Tanggal tidak valid untuk bulan tersebut" };
    }

    // Check maxDate constraint (tanggal tidak boleh melebihi batas maksimal)
    if (maxDate) {
      const maxDateOnly = new Date(maxDate.getFullYear(), maxDate.getMonth(), maxDate.getDate());
      const parsedDateOnly = new Date(year, month, day);
      if (parsedDateOnly > maxDateOnly) {
        return { valid: false, error: "Tanggal tidak boleh lebih dari hari ini" };
      }
    }

    // Check minDate constraint (tanggal tidak boleh kurang dari batas minimal)
    if (minDate) {
      const minDateOnly = new Date(minDate.getFullYear(), minDate.getMonth(), minDate.getDate());
      const parsedDateOnly = new Date(year, month, day);
      if (parsedDateOnly < minDateOnly) {
        return { valid: false, error: `Tanggal tidak boleh sebelum ${format(minDate, dateFormat)}` };
      }
    }

    return { valid: true, date: parsed };
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let input = e.target.value;
    
    // Remove all non-digit characters
    const digitsOnly = input.replace(/\D/g, '');
    
    // Auto-format with slashes
    let formatted = '';
    
    if (digitsOnly.length > 0) {
      // Add day (first 2 digits)
      formatted = digitsOnly.slice(0, 2);
      
      if (digitsOnly.length > 2) {
        // Add slash and month (next 2 digits)
        formatted += '/' + digitsOnly.slice(2, 4);
      }
      
      if (digitsOnly.length > 4) {
        // Add slash and year (next 4 digits)
        formatted += '/' + digitsOnly.slice(4, 8);
      }
    }
    
    setText(formatted);
    setError("");
    
    // Auto-commit when date is complete (10 characters: dd/MM/yyyy)
    if (formatted.length === 10) {
      const validation = validateDate(formatted);
      if (validation.valid && validation.date) {
        if (!disabled || !disabled(validation.date)) {
          onChange?.(validation.date);
        }
      } else {
        setError(validation.error || "");
      }
    }
  };

  const commitText = React.useCallback(() => {
    const trimmed = text.trim();
    
    // Check if date is complete (dd/MM/yyyy format)
    if (!trimmed || trimmed.length < 10) {
      setError("");
      return;
    }

    const validation = validateDate(trimmed);
    if (validation.valid && validation.date) {
      if (disabled && disabled(validation.date)) {
        setError("Tanggal ini tidak diperbolehkan");
        return;
      }
      onChange?.(validation.date);
      setError("");
    } else {
      setError(validation.error || "");
    }
  }, [text, onChange, dateFormat, disabled, maxDate, minDate]);

  return (
    <div className="space-y-1">
      <Input
        value={text}
        onChange={handleInputChange}
        onBlur={commitText}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            commitText();
          }
        }}
        placeholder={placeholder}
        maxLength={10}
        className={cn("w-full font-mono", error && "border-destructive", className)}
      />
      {error && (
        <p className="text-xs text-destructive">{error}</p>
      )}
    </div>
  );
}

export default DatePicker;
