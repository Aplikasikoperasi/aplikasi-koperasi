import * as React from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { formatNumberWithSeparator, parseNumberFromSeparator } from "@/lib/utils";

export interface CurrencyInputProps extends Omit<React.ComponentProps<"input">, "type" | "onChange" | "value"> {
  value?: string;
  onChange?: (value: string) => void;
}

const CurrencyInput = React.forwardRef<HTMLInputElement, CurrencyInputProps>(
  ({ className, value = "", onChange, ...props }, ref) => {
    const [displayValue, setDisplayValue] = React.useState(() => 
      value ? formatNumberWithSeparator(value) : ""
    );

    React.useEffect(() => {
      setDisplayValue(value ? formatNumberWithSeparator(value) : "");
    }, [value]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const inputValue = e.target.value;
      const numericValue = parseNumberFromSeparator(inputValue);
      
      if (numericValue === "" || /^\d+$/.test(numericValue)) {
        const formatted = formatNumberWithSeparator(numericValue);
        setDisplayValue(formatted);
        onChange?.(numericValue);
      }
    };

    return (
      <Input
        type="text"
        inputMode="numeric"
        className={cn(className)}
        value={displayValue}
        onChange={handleChange}
        ref={ref}
        {...props}
      />
    );
  }
);

CurrencyInput.displayName = "CurrencyInput";

export { CurrencyInput };
