import { cn } from "@/lib/utils";
import { useEffect, useState, useRef } from "react";
import { useSuccessFeedback } from "@/hooks/use-success-feedback";

interface SuccessCheckmarkProps {
  show: boolean;
  message?: string;
  className?: string;
  onComplete?: () => void;
  enableSound?: boolean;
  enableHaptic?: boolean;
}

export function SuccessCheckmark({ 
  show, 
  message = "Berhasil!", 
  className, 
  onComplete,
  enableSound = true,
  enableHaptic = true,
}: SuccessCheckmarkProps) {
  const [key, setKey] = useState(0);
  const { playSuccessSound, triggerHaptic } = useSuccessFeedback();
  const hasTriggeredRef = useRef(false);

  useEffect(() => {
    if (show && !hasTriggeredRef.current) {
      setKey(prev => prev + 1);
      hasTriggeredRef.current = true;
      
      // Trigger feedback after a short delay to sync with animation
      const feedbackTimer = setTimeout(() => {
        if (enableSound) playSuccessSound();
        if (enableHaptic) triggerHaptic();
      }, 500); // Sync with circle animation completion
      
      if (onComplete) {
        const completeTimer = setTimeout(onComplete, 2000);
        return () => {
          clearTimeout(feedbackTimer);
          clearTimeout(completeTimer);
        };
      }
      
      return () => clearTimeout(feedbackTimer);
    }
    
    if (!show) {
      hasTriggeredRef.current = false;
    }
  }, [show, onComplete, enableSound, enableHaptic, playSuccessSound, triggerHaptic]);

  if (!show) return null;

  return (
    <div key={key} className={cn("flex flex-col items-center justify-center py-4 animate-fade-in", className)}>
      <div className="relative w-16 h-16">
        {/* Circle */}
        <svg 
          className="w-16 h-16 transform rotate-[-90deg]"
          viewBox="0 0 64 64"
        >
          <circle
            cx="32"
            cy="32"
            r="28"
            fill="none"
            stroke="hsl(var(--success))"
            strokeWidth="4"
            strokeLinecap="round"
            className="animate-draw-circle"
            style={{
              strokeDasharray: "176",
              strokeDashoffset: "176",
            }}
          />
        </svg>
        
        {/* Checkmark */}
        <svg
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8"
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M5 13l4 4L19 7"
            stroke="hsl(var(--success))"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="animate-draw-check"
            style={{
              strokeDasharray: "24",
              strokeDashoffset: "24",
            }}
          />
        </svg>
      </div>
      
      <p className="mt-3 text-sm font-medium text-success animate-[fade-in_0.3s_ease-out_0.7s_both]">
        {message}
      </p>
    </div>
  );
}
