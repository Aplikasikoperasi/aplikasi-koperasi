import * as React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";

type ResponsiveDialogCtx = { mode: 'drawer' | 'dialog'; setOpen?: (open: boolean) => void; open?: boolean };
const ResponsiveDialogModeContext = React.createContext<ResponsiveDialogCtx>({ mode: 'dialog' });

interface ResponsiveDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
  trigger?: React.ReactNode;
}

export function ResponsiveDialog({
  open,
  onOpenChange,
  children,
  trigger,
}: ResponsiveDialogProps) {
  const isMobile = useIsMobile();

  if (isMobile) {
    return (
      <ResponsiveDialogModeContext.Provider value={{ mode: "drawer", setOpen: onOpenChange, open }}>
        <Dialog open={open} onOpenChange={onOpenChange}>
          {trigger && <DialogTrigger asChild>{trigger}</DialogTrigger>}
          {children}
        </Dialog>
      </ResponsiveDialogModeContext.Provider>
    );
  }

  return (
    <ResponsiveDialogModeContext.Provider value={{ mode: "dialog", setOpen: onOpenChange, open }}>
      <Dialog open={open} onOpenChange={onOpenChange}>
        {trigger && <DialogTrigger asChild>{trigger}</DialogTrigger>}
        {children}
      </Dialog>
    </ResponsiveDialogModeContext.Provider>
  );
}

interface ResponsiveDialogContentProps {
  children: React.ReactNode;
  className?: string;
}

export function ResponsiveDialogContent({
  children,
  className,
}: ResponsiveDialogContentProps) {
  const ctx = React.useContext(ResponsiveDialogModeContext);
  const isMobile = ctx.mode === 'drawer';

  if (isMobile) {
    // Remove any conflicting height/overflow classes from className for mobile
    const mobileClassName = className
      ?.split(' ')
      .filter(cls => !cls.includes('max-h-') && !cls.includes('overflow-') && !cls.includes('max-w-'))
      .join(' ');
    
    return (
      <DialogContent 
        className={cn(
          mobileClassName,
          "fixed inset-0 z-[10000] w-screen max-w-none rounded-none border-none bg-background p-0 m-0 translate-x-0 translate-y-0"
        )}
        style={{ height: '100dvh', maxHeight: '100dvh' }}
      >
        <div className="flex h-[100dvh] w-full max-w-full flex-col overflow-hidden">
          <div className="flex-1 min-h-0 w-full max-w-full overflow-y-auto overflow-x-hidden overscroll-contain px-4 pt-16 pb-safe">
            {children}
          </div>
        </div>
      </DialogContent>
    );
  }

  return (
    <DialogContent className={cn("w-full max-w-full", className)}>
      {children}
    </DialogContent>
  );
}

interface ResponsiveDialogHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export function ResponsiveDialogHeader({
  children,
  className,
}: ResponsiveDialogHeaderProps) {
  // Always use Dialog variants for consistent behavior across breakpoints
  return <DialogHeader className={className}>{children}</DialogHeader>;
}

interface ResponsiveDialogTitleProps {
  children: React.ReactNode;
  className?: string;
}

export function ResponsiveDialogTitle({
  children,
  className,
}: ResponsiveDialogTitleProps) {
  // Always use Dialog variants for consistency
  return <DialogTitle className={className}>{children}</DialogTitle>;
}

interface ResponsiveDialogDescriptionProps {
  children: React.ReactNode;
  className?: string;
}

export function ResponsiveDialogDescription({
  children,
  className,
}: ResponsiveDialogDescriptionProps) {
  return <DialogDescription className={className}>{children}</DialogDescription>;
}

export function ResponsiveDialogTrigger({ asChild, children }: { asChild?: boolean; children: React.ReactNode }) {
  const ctx = React.useContext(ResponsiveDialogModeContext);
  const Comp = DialogTrigger;

  let enhanced = children;
  if (React.isValidElement(children)) {
    const originalOnClick = (children.props as any)?.onClick;
    enhanced = React.cloneElement(children as any, {
      onClick: (e: any) => {
        originalOnClick?.(e);
        ctx.setOpen?.(true);
      },
    });
  }

  return <Comp asChild={asChild}>{enhanced}</Comp>;
}
