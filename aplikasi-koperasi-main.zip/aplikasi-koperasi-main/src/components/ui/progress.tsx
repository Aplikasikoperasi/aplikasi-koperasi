import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";

import { cn } from "@/lib/utils";

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => {
  const currentValue = value || 0;
  
  // Check if we're at a milestone
  const isMilestone = currentValue === 25 || currentValue === 50 || currentValue === 75 || currentValue === 100;
  
  // Determine glow color based on milestone
  const getGlowColor = () => {
    if (currentValue === 25) return "shadow-[0_0_20px_rgba(59,130,246,0.6)]"; // Blue
    if (currentValue === 50) return "shadow-[0_0_20px_rgba(234,179,8,0.6)]"; // Yellow
    if (currentValue === 75) return "shadow-[0_0_20px_rgba(249,115,22,0.6)]"; // Orange
    if (currentValue === 100) return "shadow-[0_0_20px_rgba(34,197,94,0.6)]"; // Green
    return "";
  };

  return (
    <ProgressPrimitive.Root
      ref={ref}
      className={cn("relative h-2 w-full overflow-hidden rounded-full bg-secondary", className)}
      {...props}
    >
      <ProgressPrimitive.Indicator
        className="h-full w-full flex-1 bg-primary transition-all relative overflow-hidden rounded-full animate-[pulse-subtle_2s_ease-in-out_infinite]"
        style={{ transform: `translateX(-${100 - currentValue}%)` }}
      >
        {/* Premium download-style sweeping highlight with glow effect */}
        <div 
          className="absolute inset-y-0 w-[40%] animate-[sweep_2.5s_ease-in-out_infinite]"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.8) 50%, transparent 100%)',
            transform: 'skewX(-20deg)',
            filter: 'blur(1px)',
            boxShadow: '0 0 20px rgba(255,255,255,0.5), 0 0 40px rgba(255,255,255,0.3)'
          }}
        />
        
        {/* Glow effect at the end of progress bar when milestone is reached */}
        {isMilestone && (
          <div 
            className={cn(
              "absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white animate-glow transition-all duration-500",
              getGlowColor()
            )}
          >
            {/* Pulsing ring effect */}
            <div className={cn(
              "absolute inset-0 rounded-full bg-white/50 animate-ping",
              getGlowColor()
            )} />
          </div>
        )}
      </ProgressPrimitive.Indicator>
    </ProgressPrimitive.Root>
  );
});
Progress.displayName = ProgressPrimitive.Root.displayName;

export { Progress };
