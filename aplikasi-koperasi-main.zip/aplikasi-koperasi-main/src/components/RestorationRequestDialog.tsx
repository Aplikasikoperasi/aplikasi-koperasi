import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { AlertCircle, CheckCircle } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDateWIB } from "@/lib/utils";

interface RestorationRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  request: any;
  onUpdate: () => void;
}

export function RestorationRequestDialog({
  open,
  onOpenChange,
  request,
  onUpdate,
}: RestorationRequestDialogProps) {
  const queryClient = useQueryClient();
  const [isApproving, setIsApproving] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [showRejectForm, setShowRejectForm] = useState(false);

  const handleApprove = async () => {
    setIsApproving(true);
    try {
      // Update request status
      const { error: updateError } = await supabase
        .from("customer_restoration_requests")
        .update({
          status: "approved",
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq("id", request.id);

      if (updateError) throw updateError;

      // Restore customer by removing block
      const { error: restoreError } = await supabase.rpc("restore_blocked_customer", {
        p_customer_id: request.customer_id,
      });

      if (restoreError) throw restoreError;

      // Invalidate customers query so restored customer appears in active list
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      
      toast.success("Permohonan pemulihan disetujui");
      onUpdate();
      onOpenChange(false);
    } catch (error: any) {
      console.error("Error approving restoration:", error);
      toast.error(error.message || "Gagal menyetujui permohonan");
    } finally {
      setIsApproving(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      toast.error("Alasan penolakan harus diisi");
      return;
    }

    setIsRejecting(true);
    try {
      const { error } = await supabase
        .from("customer_restoration_requests")
        .update({
          status: "rejected",
          rejection_reason: rejectionReason,
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq("id", request.id);

      if (error) throw error;

      toast.success("Permohonan pemulihan ditolak");
      onUpdate();
      onOpenChange(false);
    } catch (error: any) {
      console.error("Error rejecting restoration:", error);
      toast.error(error.message || "Gagal menolak permohonan");
    } finally {
      setIsRejecting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Detail Permohonan Pemulihan Akun</DialogTitle>
        </DialogHeader>

        {!request ? (
          <div className="py-8 text-center text-muted-foreground">
            Memuat data...
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Nama Nasabah</Label>
                <p className="font-medium">{request.customers?.full_name || '-'}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">No. Telepon</Label>
                <p className="font-medium">{request.customers?.phone || '-'}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Skor Kredit</Label>
                <p className="font-medium text-red-500">
                  {request.customers?.credit_score?.toFixed(1) || '-'}
                </p>
              </div>
              <div>
                <Label className="text-muted-foreground">Tanggal Permohonan</Label>
                <p className="font-medium">
                  {formatDateWIB(request.requested_at, 'long')}
                </p>
              </div>
            </div>

            {request.notes && (
              <div>
                <Label className="text-muted-foreground">Catatan Nasabah</Label>
                <p className="text-sm bg-muted p-3 rounded-md">{request.notes}</p>
              </div>
            )}

            {!showRejectForm ? (
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleApprove}
                  disabled={isApproving || isRejecting}
                  className="flex-1"
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  {isApproving ? "Menyetujui..." : "Setujui Permohonan"}
                </Button>
                <Button
                  onClick={() => setShowRejectForm(true)}
                  variant="destructive"
                  disabled={isApproving || isRejecting}
                  className="flex-1"
                >
                  <AlertCircle className="mr-2 h-4 w-4" />
                  Tolak Permohonan
                </Button>
              </div>
            ) : (
              <div className="space-y-3 pt-4">
                <div>
                  <Label htmlFor="rejection-reason">
                    Alasan Penolakan <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="rejection-reason"
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="Jelaskan alasan penolakan..."
                    className="mt-1"
                    rows={4}
                  />
                </div>
                <div className="flex gap-3">
                  <Button
                    onClick={handleReject}
                    disabled={isRejecting || !rejectionReason.trim()}
                    variant="destructive"
                    className="flex-1"
                  >
                    {isRejecting ? "Menolak..." : "Konfirmasi Penolakan"}
                  </Button>
                  <Button
                    onClick={() => {
                      setShowRejectForm(false);
                      setRejectionReason("");
                    }}
                    variant="outline"
                    disabled={isRejecting}
                    className="flex-1"
                  >
                    Batal
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
