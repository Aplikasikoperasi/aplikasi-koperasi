import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, XCircle, MessageCircle, Key, Phone, Link, AlertCircle, Eye, EyeOff, Trash2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { SupercodeVerificationDialog } from "@/components/SupercodeVerificationDialog";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface WhatsAppSettings {
  id?: string;
  api_provider: string;
  api_url: string;
  phone_number: string;
  phone_number_id: string;
  business_account_id: string;
  webhook_verify_token: string;
  is_enabled: boolean;
  last_tested_at?: string;
  test_status?: string;
  test_message?: string;
  api_key?: string;
  broadcast_delay_seconds?: number;
}

export function WhatsAppSettings() {
  const [settings, setSettings] = useState<WhatsAppSettings>({
    api_provider: 'whatsapp_business',
    api_url: '',
    phone_number: '',
    phone_number_id: '',
    business_account_id: '',
    webhook_verify_token: '',
    is_enabled: false,
    api_key: '',
    broadcast_delay_seconds: 1,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [showWebhookToken, setShowWebhookToken] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [isApiKeySet, setIsApiKeySet] = useState(false);
  const [supercodeAction, setSupercodeAction] = useState<'view' | 'edit' | 'delete' | null>(null);
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('whatsapp_settings' as any)
        .select('*')
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        const typedData = data as any;
        setSettings(typedData);
        // Check if API key is set (masked value indicates it exists)
        setIsApiKeySet(!!typedData.api_key && typedData.api_key.length > 0);
      }
    } catch (error: any) {
      console.error('Error loading WhatsApp settings:', error);
      toast({
        title: "Gagal memuat pengaturan",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    const verified = await requireSuperCode("menyimpan pengaturan WhatsApp API");
    if (!verified) return;
    
    try {
      setSaving(true);

      // Prepare update data
      const updateData: any = {
        api_provider: settings.api_provider,
        api_url: settings.api_url,
        phone_number: settings.phone_number,
        phone_number_id: settings.phone_number_id,
        business_account_id: settings.business_account_id,
        webhook_verify_token: settings.webhook_verify_token,
        is_enabled: settings.is_enabled,
        broadcast_delay_seconds: settings.broadcast_delay_seconds || 1,
      };

      // Only include api_key if it's been changed (not the masked value)
      if (settings.api_key && !settings.api_key.includes('•')) {
        updateData.api_key = settings.api_key;
      }

      if (settings.id) {
        // Update existing
        const { error } = await supabase
          .from('whatsapp_settings' as any)
          .update(updateData)
          .eq('id', settings.id);

        if (error) throw error;
      } else {
        // Insert new
        const { data, error } = await supabase
          .from('whatsapp_settings' as any)
          .insert(updateData)
          .select()
          .single();

        if (error) throw error;
        if (data) {
          setSettings({ ...settings, id: (data as any).id });
        }
      }

      // Update isApiKeySet flag
      if (settings.api_key && !settings.api_key.includes('•')) {
        setIsApiKeySet(true);
      }

      toast({
        title: "Pengaturan berhasil disimpan",
        description: "Konfigurasi WhatsApp API telah diperbarui",
      });

      await loadSettings();
    } catch (error: any) {
      console.error('Error saving settings:', error);
      toast({
        title: "Gagal menyimpan pengaturan",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleSupercodeVerified = async () => {
    if (!supercodeAction) return;

    try {
      if (supercodeAction === 'view') {
        // Fetch real API key from database
        const { data, error } = await supabase
          .from('whatsapp_settings' as any)
          .select('api_key')
          .eq('id', settings.id)
          .maybeSingle();

        if (error) throw error;
        
        const typedData = data as any;
        setSettings({ ...settings, api_key: typedData?.api_key || '' });
        setShowApiKey(true);
        
        toast({
          title: "API Key Ditampilkan",
          description: "Anda dapat melihat API Key sekarang",
        });
      } else if (supercodeAction === 'edit') {
        setShowApiKey(true);
        
        toast({
          title: "Mode Edit Aktif",
          description: "Anda dapat mengubah API Key sekarang",
        });
      } else if (supercodeAction === 'delete') {
        // Delete API key
        const { error } = await supabase
          .from('whatsapp_settings' as any)
          .update({ api_key: null })
          .eq('id', settings.id);

        if (error) throw error;

        setSettings({ ...settings, api_key: '' });
        setIsApiKeySet(false);
        setShowApiKey(false);
        
        toast({
          title: "API Key Dihapus",
          description: "WhatsApp API Key telah dihapus",
        });
      }
    } catch (error: any) {
      toast({
        title: "Gagal",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSupercodeAction(null);
    }
  };

  const handleTest = async () => {
    try {
      setTesting(true);

      // Get API key for testing
      let apiKeyForTest = settings.api_key;
      
      // If API key is masked, fetch the real one
      if (!apiKeyForTest || apiKeyForTest.includes('•')) {
        const { data: settingsData, error: fetchError } = await supabase
          .from('whatsapp_settings' as any)
          .select('api_key')
          .eq('id', settings.id)
          .maybeSingle();

        if (fetchError) throw fetchError;
        apiKeyForTest = (settingsData as any)?.api_key;
      }

      // Test connection via edge function
      const { data, error } = await supabase.functions.invoke('test-whatsapp-connection', {
        body: {
          api_provider: settings.api_provider,
          api_url: settings.api_url,
          phone_number: settings.phone_number,
          phone_number_id: settings.phone_number_id,
          business_account_id: settings.business_account_id,
          api_key: apiKeyForTest,
        }
      });

      if (error) throw error;

      const testResult = data as any;
      
      // Update settings with test result
      if (settings.id) {
        await supabase
          .from('whatsapp_settings' as any)
          .update({
            last_tested_at: new Date().toISOString(),
            test_status: testResult.success ? 'success' : 'failed',
            test_message: testResult.message || '',
          })
          .eq('id', settings.id);
      }

      if (testResult.success) {
        toast({
          title: "Koneksi Berhasil",
          description: "WhatsApp API terhubung dengan baik",
        });
      } else {
        toast({
          title: "Koneksi Gagal",
          description: testResult.message || "Tidak dapat terhubung ke WhatsApp API",
          variant: "destructive",
        });
      }

      await loadSettings();
    } catch (error: any) {
      console.error('Error testing connection:', error);
      toast({
        title: "Gagal menguji koneksi",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                WhatsApp API Configuration
              </CardTitle>
              <CardDescription className="mt-2">
                Konfigurasi WhatsApp Business API untuk mengirim pesan otomatis
              </CardDescription>
            </div>
            {settings.test_status && (
              <Badge variant={settings.test_status === 'success' ? 'default' : 'destructive'}>
                {settings.test_status === 'success' ? (
                  <><CheckCircle2 className="h-3 w-3 mr-1" /> Connected</>
                ) : (
                  <><XCircle className="h-3 w-3 mr-1" /> Disconnected</>
                )}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Enable/Disable Switch */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="space-y-0.5">
              <Label htmlFor="enabled" className="text-base">Status API</Label>
              <p className="text-sm text-muted-foreground">
                Aktifkan untuk menggunakan WhatsApp API
              </p>
            </div>
            <Switch
              id="enabled"
              checked={settings.is_enabled}
              onCheckedChange={(checked) => setSettings({ ...settings, is_enabled: checked })}
            />
          </div>

          <Separator />

          {/* API Provider Selection */}
          <div className="space-y-2">
            <Label htmlFor="provider">Provider API</Label>
            <Select
              value={settings.api_provider}
              onValueChange={(value) => setSettings({ ...settings, api_provider: value })}
            >
              <SelectTrigger id="provider">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="whatsapp_business">Meta WhatsApp Business API</SelectItem>
                <SelectItem value="wappin">Wappin.id</SelectItem>
                <SelectItem value="fonnte">Fonnte</SelectItem>
                <SelectItem value="custom">Custom API</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Pilih provider WhatsApp API yang akan digunakan
            </p>
          </div>

          {/* Phone Number */}
          <div className="space-y-2">
            <Label htmlFor="phone" className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Nomor Telepon WhatsApp
            </Label>
            <Input
              id="phone"
              type="text"
              placeholder="628123456789"
              value={settings.phone_number}
              onChange={(e) => setSettings({ ...settings, phone_number: e.target.value })}
            />
            <p className="text-sm text-muted-foreground">
              Format: 628xxx (tanpa tanda + atau spasi)
            </p>
          </div>

          <Separator />

          {/* API Key Configuration */}
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Key className="h-4 w-4" />
                WhatsApp API Key
              </CardTitle>
              <CardDescription>
                API Key disimpan terenkripsi di database. Perlu verifikasi supercode untuk melihat/mengubah/menghapus
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <Label htmlFor="api_key">API Key</Label>
                <div className="flex gap-2">
                  <Input
                    id="api_key"
                    type={showApiKey ? "text" : "password"}
                    placeholder={isApiKeySet ? "••••••••••••••••" : "Masukkan API Key"}
                    value={isApiKeySet && !showApiKey ? "••••••••••••••••" : settings.api_key}
                    onChange={(e) => setSettings({ ...settings, api_key: e.target.value })}
                    disabled={!showApiKey && isApiKeySet}
                    className="flex-1"
                  />
                  {isApiKeySet && (
                    <>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => setSupercodeAction('view')}
                        title="Lihat API Key"
                      >
                        {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => setSupercodeAction('edit')}
                        title="Edit API Key"
                      >
                        <Key className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => setSupercodeAction('delete')}
                        title="Hapus API Key"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {isApiKeySet 
                    ? "API Key sudah diatur. Klik ikon mata, edit, atau hapus untuk melakukan perubahan (perlu verifikasi supercode)"
                    : "Masukkan API Key dari provider WhatsApp Anda"}
                </p>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* API URL */}
          <div className="space-y-2">
            <Label htmlFor="api_url" className="flex items-center gap-2">
              <Link className="h-4 w-4" />
              API URL
            </Label>
            <Input
              id="api_url"
              type="url"
              placeholder="https://api.whatsapp.com/v1"
              value={settings.api_url}
              onChange={(e) => setSettings({ ...settings, api_url: e.target.value })}
            />
            <p className="text-sm text-muted-foreground">
              URL endpoint untuk WhatsApp API
            </p>
          </div>

          {/* API URL */}
          <div className="space-y-2">
            <Label htmlFor="api_url" className="flex items-center gap-2">
              <Link className="h-4 w-4" />
              API URL
            </Label>
            <Input
              id="api_url"
              type="url"
              placeholder="https://api.whatsapp.com/v1"
              value={settings.api_url}
              onChange={(e) => setSettings({ ...settings, api_url: e.target.value })}
            />
            <p className="text-sm text-muted-foreground">
              URL endpoint untuk WhatsApp API
            </p>
          </div>

          {/* Meta WhatsApp Business API specific fields */}
          {settings.api_provider === 'whatsapp_business' && (
            <>
              <div className="space-y-2">
                <Label htmlFor="phone_number_id">Phone Number ID</Label>
                <Input
                  id="phone_number_id"
                  type="text"
                  placeholder="123456789"
                  value={settings.phone_number_id}
                  onChange={(e) => setSettings({ ...settings, phone_number_id: e.target.value })}
                />
                <p className="text-sm text-muted-foreground">
                  Phone Number ID dari WhatsApp Business Account
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="business_account_id">Business Account ID</Label>
                <Input
                  id="business_account_id"
                  type="text"
                  placeholder="123456789"
                  value={settings.business_account_id}
                  onChange={(e) => setSettings({ ...settings, business_account_id: e.target.value })}
                />
                <p className="text-sm text-muted-foreground">
                  WhatsApp Business Account ID
                </p>
              </div>
            </>
          )}

          {/* Webhook Verify Token */}
          <div className="space-y-2">
            <Label htmlFor="webhook_token" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Webhook Verify Token
            </Label>
            <div className="flex gap-2">
              <Input
                id="webhook_token"
                type={showWebhookToken ? "text" : "password"}
                placeholder="your_webhook_token"
                value={settings.webhook_verify_token}
                onChange={(e) => setSettings({ ...settings, webhook_verify_token: e.target.value })}
                className="flex-1"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowWebhookToken(!showWebhookToken)}
              >
                {showWebhookToken ? "Hide" : "Show"}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Token untuk verifikasi webhook (optional)
            </p>
          </div>

          <Separator />

          {/* Broadcast Delay */}
          <div className="space-y-2">
            <Label htmlFor="broadcast_delay" className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Delay Broadcast (detik)
            </Label>
            <Input
              id="broadcast_delay"
              type="number"
              min="0"
              max="10"
              placeholder="1"
              value={settings.broadcast_delay_seconds || 1}
              onChange={(e) => {
                const value = parseInt(e.target.value) || 1;
                setSettings({ ...settings, broadcast_delay_seconds: Math.max(0, Math.min(10, value)) });
              }}
            />
            <p className="text-sm text-muted-foreground">
              Jeda waktu antar pengiriman pesan broadcast (0-10 detik). Default: 1 detik. Naikkan jika sering terkena rate limiting.
            </p>
          </div>

          {/* Test Status */}
          {settings.last_tested_at && (
            <div className="p-4 bg-muted rounded-lg space-y-2">
              <p className="text-sm font-medium">Status Terakhir:</p>
              <p className="text-xs text-muted-foreground">
                Diuji pada: {new Date(settings.last_tested_at).toLocaleString('id-ID')}
              </p>
              {settings.test_message && (
                <p className="text-xs text-muted-foreground">
                  {settings.test_message}
                </p>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button onClick={handleSave} disabled={saving || testing} className="flex-1">
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                "Simpan Pengaturan"
              )}
            </Button>
            <Button 
              onClick={handleTest} 
              disabled={testing || saving || !settings.api_url || !settings.phone_number}
              variant="outline"
            >
              {testing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : (
                "Test Connection"
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Information Card */}
      <Card>
        <CardHeader>
          <CardTitle>Informasi Penting</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <div className="space-y-1">
            <p className="font-medium text-foreground">WhatsApp Business API Key:</p>
            <p>
              API Key disimpan terenkripsi di database. Untuk melihat, mengubah, atau menghapus API Key yang sudah tersimpan, 
              diperlukan verifikasi supercode untuk keamanan maksimal.
            </p>
          </div>
          <div className="space-y-1">
            <p className="font-medium text-foreground">Provider API:</p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li><strong>Meta WhatsApp Business API:</strong> API resmi dari Meta (memerlukan Business Account)</li>
              <li><strong>Wappin.id:</strong> Provider lokal Indonesia dengan harga terjangkau</li>
              <li><strong>Fonnte:</strong> Provider Indonesia dengan fitur lengkap</li>
              <li><strong>Custom API:</strong> Untuk provider lainnya dengan custom endpoint</li>
            </ul>
          </div>
          <div className="space-y-1">
            <p className="font-medium text-foreground">Webhook:</p>
            <p>
              Jika menggunakan webhook untuk menerima pesan masuk, atur verify token dan endpoint webhook di dashboard provider Anda.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Supercode Verification Dialog */}
      <SupercodeVerificationDialog
        open={supercodeAction !== null}
        onOpenChange={(open) => !open && setSupercodeAction(null)}
        onSuccess={handleSupercodeVerified}
        title="Verifikasi Supercode"
        description={
          supercodeAction === 'view' ? 'Masukkan supercode untuk melihat WhatsApp API Key' :
          supercodeAction === 'edit' ? 'Masukkan supercode untuk mengubah WhatsApp API Key' :
          supercodeAction === 'delete' ? 'Masukkan supercode untuk menghapus WhatsApp API Key' :
          'Masukkan supercode untuk melanjutkan'
        }
      />
    </div>
  );
}