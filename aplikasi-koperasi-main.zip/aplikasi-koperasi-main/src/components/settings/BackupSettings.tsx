import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Download, Database, FileSpreadsheet, HardDrive, Trash2, Upload, AlertCircle, CheckCircle2, Loader2, Cloud, FileText, Users, UserCheck, DollarSign, CheckCircle, XCircle, Clock } from "lucide-react";
import * as XLSX from "xlsx";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { toast as sonnerToast } from "sonner";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { GoogleDriveSettings } from "./GoogleDriveSettings";
import { useSuperCode } from "@/contexts/SuperCodeContext";
import { RestoreProgressMonitor } from "./RestoreProgressMonitor";
import { getTodayDateStringInWIB } from "@/lib/utils";
interface BackupFile {
  name: string;
  created_at: string;
  size: number;
}
interface RestoreResult {
  success: boolean;
  message: string;
  version?: string;
  totals?: {
    inserted: number;
    updated: number;
    failed: number;
  };
  stats: {
    [tableName: string]: {
      inserted: number;
      updated?: number;
      skipped: number;
      failed: number;
    };
  };
}
interface BackupAnalysis {
  version?: string;
  totalSize: number;
  tables: {
    [tableName: string]: number;
  };
  coreTables: {
    members: number;
    customers: number;
    applications: number;
    installments: number;
    payments: number;
  };
}
const mapIncrementalReportsToStats = (data: any): RestoreResult["stats"] => {
  const reports = data?.reports || [];
  const getStats = (tableName: string) => {
    const report = reports.find((r: any) => r.table === tableName);
    return {
      inserted: report?.inserted || 0,
      skipped: report?.alreadyExists || 0,
      failed: report?.failed || 0
    };
  };
  return {
    members: getStats("members"),
    customers: getStats("customers"),
    applications: getStats("credit_applications"),
    installments: getStats("installments"),
    payments: getStats("payments")
  };
};
const buildIncrementalRestoreResult = (data: any): RestoreResult => {
  const stats = mapIncrementalReportsToStats(data);
  const summary = data?.summary || {};
  const messageParts: string[] = [];
  if (typeof summary.totalInserted === "number") {
    messageParts.push(`Ditambahkan ${summary.totalInserted} data baru`);
  }
  if (typeof summary.totalSkipped === "number") {
    messageParts.push(`Dilewati ${summary.totalSkipped} data yang sudah ada`);
  }
  if (typeof summary.totalFailed === "number") {
    messageParts.push(`Gagal ${summary.totalFailed} data`);
  }
  return {
    success: data?.success ?? summary.totalFailed === 0,
    message: messageParts.length > 0 ? `Restore selesai: ${messageParts.join(" • ")}` : "Restore selesai",
    stats
  };
};
const normalizeRestoreErrorMessage = (error: any): string => {
  const rawMessage = (typeof error === "string" ? error : error?.message) || error?.value && (error.value as any).message || "Terjadi kesalahan saat restore data";
  if (rawMessage.includes("Failed to send a request to the Edge Function") || rawMessage.includes("Failed to fetch")) {
    return "Koneksi ke server terputus (timeout) saat menunggu hasil restore. Proses restore dengan data besar biasanya tetap berjalan di server, namun laporan detail tidak bisa dikirim kembali ke aplikasi.";
  }
  return rawMessage;
};
export const BackupSettings = () => {
  const {
    toast
  } = useToast();
  const {
    requireSuperCode
  } = useSuperCode();
  const [isExporting, setIsExporting] = useState(false);
  const [autoBackupEnabled, setAutoBackupEnabled] = useState(false);
  const [backupFiles, setBackupFiles] = useState<BackupFile[]>([]);
  const [lastBackup, setLastBackup] = useState<string | null>(null);
  const [nextBackup, setNextBackup] = useState<string | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restoreProgress, setRestoreProgress] = useState("");
  const [restoreResult, setRestoreResult] = useState<RestoreResult | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);
  const [storageUsed, setStorageUsed] = useState(0);
  const [storageTotal] = useState(1024); // 1GB in MB
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);
  const [selectedRestoreFile, setSelectedRestoreFile] = useState<string>("");
  const [backupAnalysis, setBackupAnalysis] = useState<BackupAnalysis | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [restoreReports, setRestoreReports] = useState<any[]>([]);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [activeRestoreProgressId, setActiveRestoreProgressId] = useState<string | null>(null);

  // Load backup settings and files
  useEffect(() => {
    loadBackupSettings();
    loadBackupFiles();
  }, []);
  const loadBackupSettings = async () => {
    const {
      data
    } = await supabase.from('auto_backup_settings').select('*').maybeSingle();
    if (data) {
      setAutoBackupEnabled(data.enabled);
      setLastBackup(data.last_backup_at);

      // Auto-fix: If next backup is more than 2 days away, recalculate it
      if (data.enabled && data.next_backup_at) {
        const nextBackupTime = new Date(data.next_backup_at).getTime();
        const now = Date.now();
        const daysUntilBackup = (nextBackupTime - now) / (1000 * 60 * 60 * 24);

        // If scheduled more than 2.5 days away, reset to 2 days at midnight
        if (daysUntilBackup > 2.5) {
          const correctedDate = new Date(now + 2 * 24 * 60 * 60 * 1000);
          correctedDate.setHours(0, 0, 0, 0);
          await supabase.from('auto_backup_settings').update({
            next_backup_at: correctedDate.toISOString()
          }).eq('enabled', true);
          setNextBackup(correctedDate.toISOString());
          sonnerToast.info('Jadwal backup diperbaiki ke interval 2 hari');
        } else {
          setNextBackup(data.next_backup_at);
        }
      } else {
        setNextBackup(data.next_backup_at);
      }
    }
  };
  const loadBackupFiles = async () => {
    const {
      data,
      error
    } = await supabase.storage.from('backups').list('', {
      sortBy: {
        column: 'created_at',
        order: 'desc'
      }
    });
    if (error) {
      console.error('Error loading backups:', error);
      return;
    }
    if (data) {
      const backupFilesList = data.map(file => ({
        name: file.name,
        created_at: file.created_at || new Date().toISOString(),
        size: file.metadata?.size || 0
      }));
      setBackupFiles(backupFilesList);

      // Calculate total storage used
      const totalBytes = backupFilesList.reduce((sum, file) => sum + file.size, 0);
      const totalMB = totalBytes / (1024 * 1024);
      setStorageUsed(Number(totalMB.toFixed(2)));
    }
  };
  const handleAutoBackupToggle = async (enabled: boolean) => {
    const previousState = autoBackupEnabled;
    setAutoBackupEnabled(enabled);

    // Set next backup to besok jam 00:00 WIB
    let nextBackupDate = null;
    if (enabled) {
      nextBackupDate = new Date();
      nextBackupDate.setDate(nextBackupDate.getDate() + 1);
      nextBackupDate.setHours(0, 0, 0, 0); // Set to midnight WIB
    }
    const {
      error
    } = await supabase.from('auto_backup_settings').update({
      enabled,
      next_backup_at: nextBackupDate ? nextBackupDate.toISOString() : null
    }).eq('enabled', previousState);
    if (error) {
      sonnerToast.error("Gagal mengubah pengaturan auto backup");
      setAutoBackupEnabled(!enabled);
      return;
    }
    sonnerToast.success(enabled ? "Auto backup harian (jam 00:00 WIB) diaktifkan" : "Auto backup dinonaktifkan");
    loadBackupSettings();
  };

  const handleBackupNow = async () => {
    const verified = await requireSuperCode("backup manual sekarang");
    if (!verified) return;
    
    setIsExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke('weekly-backup');
      if (error) throw error;
      
      if (data?.status === 'processing') {
        sonnerToast.success("Backup sedang diproses di background", {
          description: "Anda akan menerima notifikasi di Inbox ketika backup selesai. Proses ini bisa memakan waktu beberapa menit untuk data yang besar.",
          duration: 6000
        });
        // Reload immediately to show "processing" state
        loadBackupSettings();
      } else if (data?.success) {
        sonnerToast.success("Backup berhasil dibuat", {
          description: `File: ${data.filename || 'backup file'}`
        });
        loadBackupSettings();
        loadBackupFiles();
      } else {
        throw new Error(data?.error || 'Gagal membuat backup');
      }
    } catch (error: any) {
      console.error('Error creating backup:', error);
      sonnerToast.error("Gagal memulai backup", {
        description: error.message
      });
    } finally {
      setIsExporting(false);
    }
  };
  const downloadBackupFile = async (fileName: string) => {
    const verified = await requireSuperCode("download file backup");
    if (!verified) return;
    const {
      data,
      error
    } = await supabase.storage.from('backups').download(fileName);
    if (error) {
      sonnerToast.error("Gagal mengunduh file backup");
      return;
    }
    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
    sonnerToast.success("File backup berhasil diunduh");
  };
  const deleteBackupFile = async (fileName: string) => {
    const verified = await requireSuperCode("menghapus file backup");
    if (!verified) return;
    const {
      error
    } = await supabase.storage.from('backups').remove([fileName]);
    if (error) {
      sonnerToast.error("Gagal menghapus file backup");
      return;
    }
    sonnerToast.success("File backup berhasil dihapus");
    loadBackupFiles();
  };
  const regenerateMissingInstallments = async () => {
    const verified = await requireSuperCode("regenerasi angsuran yang hilang");
    if (!verified) return;
    setIsRegenerating(true);
    try {
      const {
        data,
        error
      } = await supabase.functions.invoke('regenerate-missing-installments');
      if (error) throw error;
      if (data?.success) {
        toast({
          title: "Regenerasi Berhasil",
          description: `${data.total_installments_regenerated} angsuran berhasil dibuat untuk ${data.applications_processed} aplikasi`
        });
        sonnerToast.success(`${data.total_installments_regenerated} angsuran yang hilang berhasil dibuat ulang`);
      } else {
        throw new Error(data?.error || 'Gagal regenerasi angsuran');
      }
    } catch (error: any) {
      console.error('Error regenerating installments:', error);
      toast({
        title: "Gagal Regenerasi",
        description: error.message || "Terjadi kesalahan saat regenerasi angsuran",
        variant: "destructive"
      });
    } finally {
      setIsRegenerating(false);
    }
  };
  const restoreFromStorage = async (fileName: string) => {
    const verified = await requireSuperCode("restore backup dari storage");
    if (!verified) return;
    setSelectedRestoreFile(fileName);
    setShowRestoreDialog(true);
  };
  const confirmRestore = async () => {
    const verified = await requireSuperCode("restore backup dari storage");
    if (!verified) {
      setShowRestoreDialog(false);
      return;
    }
    setShowRestoreDialog(false);
    setIsRestoring(true);
    setProgressPercent(10);
    setRestoreProgress("Mengambil file backup dari storage...");
    setRestoreResult(null);
    setRestoreReports([]);
    try {
      // Download file from storage
      const {
        data: fileData,
        error: downloadError
      } = await supabase.storage.from('backups').download(selectedRestoreFile);
      if (downloadError) {
        throw new Error(`Gagal mengambil file: ${downloadError.message}`);
      }
      setRestoreProgress("Membaca file backup...");
      setProgressPercent(30);
      const text = await fileData.text();
      const backupData = JSON.parse(text);

      // Validate backup format
      if (!backupData.data) {
        throw new Error('Format backup tidak valid');
      }
      setRestoreProgress("Memulai proses restore di background...");
      setProgressPercent(40);
      console.log("Starting background restore via restore-backup-data edge function...");

      // Call restore-backup-data edge function (returns immediately with progress ID)
      const {
        data,
        error
      } = await supabase.functions.invoke('restore-backup-data', {
        body: {
          backupData
        }
      });
      if (error) {
        console.error("Restore edge function error:", error);
        throw new Error(error.message || 'Restore gagal');
      }
      if (!data || !data.progressId) {
        throw new Error('Failed to start restore process');
      }
      const progressId = data.progressId;
      console.log("Restore started with progress ID:", progressId);

      // Set active restore progress ID untuk monitoring UI
      setActiveRestoreProgressId(progressId);

      // Subscribe to realtime progress updates
      setRestoreProgress("Memantau progress restore...");
      setProgressPercent(50);
      const channel = supabase.channel(`restore-progress-${progressId}`).on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'restore_progress',
        filter: `id=eq.${progressId}`
      }, payload => {
        const progress = payload.new;
        console.log("Progress update:", progress);
        setRestoreProgress(progress.status || 'Processing...');

        // Calculate progress based on status
        const statusText = progress.status || '';
        let percent = 50;
        
        if (statusText.includes('profiles')) percent = 52;
        else if (statusText.includes('members')) percent = 55;
        else if (statusText.includes('Nasabah') || statusText.includes('customers')) percent = 60;
        else if (statusText.includes('Kredit') || statusText.includes('applications')) percent = 65;
        else if (statusText.includes('installments')) percent = 70;
        else if (statusText.includes('payments')) percent = 75;
        else if (statusText.includes('blocked')) percent = 78;
        else if (statusText.includes('bank')) percent = 80;
        else if (statusText.includes('balance')) percent = 82;
        else if (statusText.includes('messages')) percent = 85;
        else if (statusText.includes('requests')) percent = 88;
        else if (statusText.includes('whatsapp')) percent = 90;
        else if (statusText.includes('logs')) percent = 93;
        else if (statusText.includes('Post-processing')) percent = 95;
        else if (statusText.includes('completed')) percent = 100;
        
        setProgressPercent(percent);
      }).subscribe();

      // Poll for completion
      let attempts = 0;
      const maxAttempts = 120; // 2 minutes max wait (120 * 1000ms)

      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        const {
          data: progressData,
          error: progressError
        } = await supabase.from('restore_progress').select('*').eq('id', progressId).single();
        if (progressError) {
          console.error("Error fetching progress:", progressError);
          break;
        }
        if (progressData.status === 'completed' || progressData.status === 'completed_with_errors' || progressData.status === 'failed') {
          console.log("Restore completed:", progressData);
          supabase.removeChannel(channel);
          if (progressData.status === 'failed') {
            const errorLog = progressData.error_log as any;
            throw new Error(errorLog?.error || 'Restore failed');
          }

          // Build result from progress data
          const errorLog = progressData.error_log as any;
          const summary = errorLog?.summary || {};
          const totals = errorLog?.totals || {};
          
          // Build stats object dynamically from summary
          const stats: RestoreResult['stats'] = {};
          Object.keys(summary).forEach(tableName => {
            const tableStats = summary[tableName];
            stats[tableName] = {
              inserted: tableStats.inserted || 0,
              updated: tableStats.updated || 0,
              skipped: tableStats.skipped || 0,
              failed: tableStats.failed || 0
            };
          });
          
          const result: RestoreResult = {
            success: progressData.status === 'completed',
            message: progressData.status === 'completed' 
              ? '✅ Restore berhasil - ALL data restored!' 
              : `⚠️ Restore selesai dengan ${totals.failed || 0} errors`,
            version: '2.0',
            totals: {
              inserted: totals.inserted || 0,
              updated: totals.updated || 0,
              failed: totals.failed || 0
            },
            stats
          };
          
          setProgressPercent(100);
          setRestoreProgress("Restore selesai!");
          setRestoreResult(result);
          
          // Keep progress monitor visible for final review
          setTimeout(() => {
            setActiveRestoreProgressId(null);
          }, 30000); // Hide after 30 seconds
          
          return result;
        }
        attempts++;
      }

      // Timeout - but restore might still complete in background
      supabase.removeChannel(channel);
      throw new Error('Monitoring timeout - restore mungkin masih berjalan di background. Cek progress di table restore_progress.');
    } catch (error: any) {
      console.error("Error restoring from storage:", error);
      const userMessage = normalizeRestoreErrorMessage(error);
      sonnerToast.error("Gagal restore dari cloud", {
        description: userMessage
      });
      setRestoreResult({
        success: false,
        message: userMessage,
        stats: {
          members: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          customers: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          applications: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          installments: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          payments: {
            inserted: 0,
            skipped: 0,
            failed: 0
          }
        }
      });
    } finally {
      setIsRestoring(false);
      setProgressPercent(0);
    }
  };
  const exportToJSON = async () => {
    const verified = await requireSuperCode("export data ke JSON");
    if (!verified) return;
    setIsExporting(true);
    try {
      // Fetch ALL data INCLUDING installments - TRUE UNLIMITED with explicit high limits
      const [customers, applications, payments, members, installments] = await Promise.all([supabase.from("customers").select("*").limit(999999), supabase.from("credit_applications").select("*").limit(999999), supabase.from("payments").select("*").limit(999999), supabase.from("members").select("*").limit(999999), supabase.from("installments").select("*").limit(999999)]);

      // Calculate data date range
      const dates: Date[] = [];

      // Get dates from customers (created_at)
      customers.data?.forEach(c => {
        if (c.created_at) dates.push(new Date(c.created_at));
      });

      // Get dates from applications (application_date)
      applications.data?.forEach(a => {
        if (a.application_date) dates.push(new Date(a.application_date));
      });

      // Get dates from payments (payment_date)
      payments.data?.forEach(p => {
        if (p.payment_date) dates.push(new Date(p.payment_date));
      });

      // Get dates from members (created_at)
      members.data?.forEach(m => {
        if (m.created_at) dates.push(new Date(m.created_at));
      });
      const oldestDate = dates.length > 0 ? new Date(Math.min(...dates.map(d => d.getTime()))) : null;
      const newestDate = dates.length > 0 ? new Date(Math.max(...dates.map(d => d.getTime()))) : null;
      const backupData = {
        exportDate: new Date().toISOString(),
        version: "1.0",
        dataRange: {
          oldestDate: oldestDate ? oldestDate.toISOString() : null,
          newestDate: newestDate ? newestDate.toISOString() : null,
          totalDays: oldestDate && newestDate ? Math.ceil((newestDate.getTime() - oldestDate.getTime()) / (1000 * 60 * 60 * 24)) : 0
        },
        data: {
          customers: customers.data || [],
          credit_applications: applications.data || [],
          payments: payments.data || [],
          members: members.data || [],
          installments: installments.data || []
        },
        stats: {
          totalCustomers: customers.data?.length || 0,
          totalApplications: applications.data?.length || 0,
          totalPayments: payments.data?.length || 0,
          totalMembers: members.data?.length || 0,
          totalInstallments: installments.data?.length || 0
        }
      };
      const blob = new Blob([JSON.stringify(backupData, null, 2)], {
        type: "application/json"
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `backup-koperasi-${getTodayDateStringInWIB()}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({
        title: "Backup JSON Berhasil",
        description: "Database telah dibackup ke file JSON"
      });
    } catch (error) {
      console.error("Error exporting JSON:", error);
      toast({
        title: "Error",
        description: "Gagal membuat backup JSON",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };
  const exportToExcel = async () => {
    const verified = await requireSuperCode("export data ke Excel");
    if (!verified) return;
    setIsExporting(true);
    try {
      // SKIP installments - will be auto-generated from triggers
      const [customers, applications, payments, members] = await Promise.all([supabase.from("customers").select("*"), supabase.from("credit_applications").select("*"), supabase.from("payments").select("*"), supabase.from("members").select("*")]);
      const wb = XLSX.utils.book_new();
      const wsCustomers = XLSX.utils.json_to_sheet(customers.data || []);
      XLSX.utils.book_append_sheet(wb, wsCustomers, "Nasabah");
      const wsApplications = XLSX.utils.json_to_sheet(applications.data || []);
      XLSX.utils.book_append_sheet(wb, wsApplications, "Pengajuan Kredit");
      const wsPayments = XLSX.utils.json_to_sheet(payments.data || []);
      XLSX.utils.book_append_sheet(wb, wsPayments, "Pembayaran");
      const wsMembers = XLSX.utils.json_to_sheet(members.data || []);
      XLSX.utils.book_append_sheet(wb, wsMembers, "Anggota");
      XLSX.writeFile(wb, `data-koperasi-${getTodayDateStringInWIB()}.xlsx`);
      toast({
        title: "Export Excel Berhasil",
        description: "Semua data telah diexport ke Excel"
      });
    } catch (error) {
      console.error("Error exporting Excel:", error);
      toast({
        title: "Error",
        description: "Gagal export ke Excel",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };
  const analyzeBackupFile = async (file: File) => {
    try {
      const text = await file.text();
      const backupData = JSON.parse(text);
      if (!backupData.data) {
        throw new Error('Format backup tidak valid');
      }
      
      // Calculate table counts
      const tables: { [key: string]: number } = {};
      Object.keys(backupData.data).forEach(tableName => {
        const data = backupData.data[tableName];
        tables[tableName] = Array.isArray(data) ? data.length : 0;
      });
      
      const analysis: BackupAnalysis = {
        version: backupData.version || '1.0',
        totalSize: file.size,
        tables,
        coreTables: {
          members: backupData.data.members?.length || 0,
          customers: backupData.data.customers?.length || 0,
          applications: backupData.data.credit_applications?.length || 0,
          installments: backupData.data.installments?.length || 0,
          payments: backupData.data.payments?.length || 0,
        }
      };
      
      setBackupAnalysis(analysis);
      
      const totalRecords = Object.values(tables).reduce((sum, count) => sum + count, 0);
      const tableCount = Object.keys(tables).length;
      
      sonnerToast.success("File backup berhasil dianalisis", {
        description: `Version ${analysis.version} • ${tableCount} tables • ${totalRecords} total records`
      });
    } catch (error: any) {
      console.error("Error analyzing backup:", error);
      sonnerToast.error("Gagal menganalisis file backup", {
        description: error.message
      });
      setBackupAnalysis(null);
    }
  };
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const validExcelTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
      const isExcel = validExcelTypes.includes(file.type);
      const isJson = file.type === 'application/json' || file.name.endsWith('.json');
      if (!isExcel && !isJson) {
        toast({
          title: "Format File Tidak Valid",
          description: "Silakan upload file Excel (.xlsx) atau JSON (.json)",
          variant: "destructive"
        });
        return;
      }
      setUploadedFile(file);
      setRestoreFile(file);
      setRestoreResult(null);
      setRestoreProgress("");
      setProgressPercent(0);
      setBackupAnalysis(null);
      setRestoreReports([]);

      // Analyze JSON file
      if (isJson) {
        await analyzeBackupFile(file);
      }
    }
  };
  const restoreFromJSON = async () => {
    if (!uploadedFile) {
      toast({
        title: "File Tidak Ditemukan",
        description: "Silakan pilih file backup JSON terlebih dahulu",
        variant: "destructive"
      });
      return;
    }
    const verified = await requireSuperCode("restore data dari JSON");
    if (!verified) return;
    const isConfirmed = window.confirm(
      "⚠️ PERINGATAN: RESTORE KOMPREHENSIF\n\n" +
      "🧹 CLEANING STEP (Langkah Pembersihan):\n" +
      "• Installments & Payments untuk aplikasi di backup akan DIHAPUS DULU\n" +
      "• Mencegah duplikasi data angsuran & pembayaran\n" +
      "• Data baru dari backup akan dimasukkan setelah pembersihan\n\n" +
      "📝 UPSERT METHOD:\n" +
      "1. ✅ Batch processing: 100 records per batch\n" +
      "2. 🔄 UPDATE: Data dengan ID sama akan DITIMPA\n" +
      "3. ➕ INSERT: ID baru akan DITAMBAHKAN\n" +
      "4. ✅ Progress tracking real-time per tabel\n" +
      "5. ✅ Urutan: profiles → members → customers → applications → installments → payments\n\n" +
      "Kelebihan metode ini:\n" +
      "- Cepat: Batch processing efisien\n" +
      "- Aman: Cleaning step mencegah duplikasi\n" +
      "- Reliable: UPSERT otomatis, urutan respect foreign keys\n\n" +
      "⚠️ PENTING: Pastikan Anda sudah membackup data sebelum melanjutkan!\n\n" +
      "Apakah Anda yakin ingin melanjutkan?"
    );
    if (!isConfirmed) {
      return;
    }
    executeRestoreFromJSON();
  };
  const executeRestoreFromJSON = async () => {
    if (!uploadedFile) return;
    setIsRestoring(true);
    setProgressPercent(10);
    setRestoreProgress("Membaca file backup...");
    setRestoreResult(null);
    setRestoreReports([]);
    try {
      setRestoreProgress("Membaca file backup...");
      setProgressPercent(30);
      const text = await uploadedFile.text();
      const backupData = JSON.parse(text);

      // Validate backup format
      if (!backupData.data) {
        throw new Error('Format backup tidak valid');
      }
      setRestoreProgress("Memulai proses restore di background...");
      setProgressPercent(40);
      console.log("Starting background restore via restore-backup-data edge function (file upload)...");

      // Call restore-backup-data edge function (returns immediately with progress ID)
      const {
        data,
        error
      } = await supabase.functions.invoke('restore-backup-data', {
        body: {
          backupData
        }
      });
      if (error) {
        console.error("Restore edge function error:", error);
        throw new Error(error.message || 'Restore gagal');
      }
      if (!data || !data.progressId) {
        throw new Error('Failed to start restore process');
      }
      const progressId = data.progressId;
      console.log("Restore started with progress ID:", progressId);

      // Set active restore progress ID untuk monitoring UI
      setActiveRestoreProgressId(progressId);

      // Subscribe to realtime progress updates
      setRestoreProgress("Memantau progress restore...");
      setProgressPercent(50);
      const channel = supabase.channel(`restore-progress-file-${progressId}`).on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'restore_progress',
        filter: `id=eq.${progressId}`
      }, payload => {
        const progress = payload.new;
        console.log("Progress update:", progress);
        setRestoreProgress(progress.status || 'Processing...');

        // Calculate progress based on status
        const statusText = progress.status || '';
        let percent = 50;
        
        if (statusText.includes('profiles')) percent = 52;
        else if (statusText.includes('members')) percent = 55;
        else if (statusText.includes('Nasabah') || statusText.includes('customers')) percent = 60;
        else if (statusText.includes('Kredit') || statusText.includes('applications')) percent = 65;
        else if (statusText.includes('installments')) percent = 70;
        else if (statusText.includes('payments')) percent = 75;
        else if (statusText.includes('blocked')) percent = 78;
        else if (statusText.includes('bank')) percent = 80;
        else if (statusText.includes('balance')) percent = 82;
        else if (statusText.includes('messages')) percent = 85;
        else if (statusText.includes('requests')) percent = 88;
        else if (statusText.includes('whatsapp')) percent = 90;
        else if (statusText.includes('logs')) percent = 93;
        else if (statusText.includes('Post-processing')) percent = 95;
        else if (statusText.includes('completed')) percent = 100;
        
        setProgressPercent(percent);
      }).subscribe();

      // Poll for completion
      let attempts = 0;
      const maxAttempts = 120; // 2 minutes max wait

      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        const {
          data: progressData,
          error: progressError
        } = await supabase.from('restore_progress').select('*').eq('id', progressId).single();
        if (progressError) {
          console.error("Error fetching progress:", progressError);
          break;
        }
        if (progressData.status === 'completed' || progressData.status === 'completed_with_errors' || progressData.status === 'failed') {
          console.log("Restore completed:", progressData);
          supabase.removeChannel(channel);
          if (progressData.status === 'failed') {
            const errorLog = progressData.error_log as any;
            throw new Error(errorLog?.error || 'Restore failed');
          }

          // Build result from progress data
          const errorLog = progressData.error_log as any;
          const summary = errorLog?.summary || {};
          const totals = errorLog?.totals || {};
          
          // Build stats object dynamically from summary
          const stats: RestoreResult['stats'] = {};
          Object.keys(summary).forEach(tableName => {
            const tableStats = summary[tableName];
            stats[tableName] = {
              inserted: tableStats.inserted || 0,
              updated: tableStats.updated || 0,
              skipped: tableStats.skipped || 0,
              failed: tableStats.failed || 0
            };
          });
          
          const result: RestoreResult = {
            success: progressData.status === 'completed',
            message: progressData.status === 'completed' 
              ? '✅ Restore berhasil - ALL data restored!' 
              : `⚠️ Restore selesai dengan ${totals.failed || 0} errors`,
            version: '2.0',
            totals: {
              inserted: totals.inserted || 0,
              updated: totals.updated || 0,
              failed: totals.failed || 0
            },
            stats
          };
          
          setProgressPercent(100);
          setRestoreProgress("Restore selesai!");
          setRestoreResult(result);
          toast({
            title: result.success ? "Restore Berhasil" : "Restore Completed with Errors",
            description: result.message,
            variant: result.success ? "default" : "destructive"
          });

          // Keep progress monitor visible for final review
          setTimeout(() => {
            setActiveRestoreProgressId(null);
          }, 30000); // Hide after 30 seconds

          // Refresh data
          await loadBackupFiles();
          return;
        }
        attempts++;
      }

      // Timeout - but restore might still complete in background
      supabase.removeChannel(channel);
      throw new Error('Monitoring timeout - restore mungkin masih berjalan di background. Cek progress di table restore_progress.');
    } catch (error: any) {
      console.error("Error during restore:", error);
      const userMessage = normalizeRestoreErrorMessage(error);
      toast({
        title: "Restore Gagal",
        description: userMessage,
        variant: "destructive"
      });
      setRestoreResult({
        success: false,
        message: userMessage,
        stats: {
          members: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          customers: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          applications: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          installments: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          payments: {
            inserted: 0,
            skipped: 0,
            failed: 0
          }
        }
      });
    } finally {
      setIsRestoring(false);
      setProgressPercent(0);
    }
  };
  const restoreFromExcel = async () => {
    if (!restoreFile) {
      toast({
        title: "File Tidak Ditemukan",
        description: "Silakan pilih file backup Excel terlebih dahulu",
        variant: "destructive"
      });
      return;
    }
    const verified = await requireSuperCode("restore data dari Excel");
    if (!verified) return;
    executeRestoreFromExcel();
  };
  const executeRestoreFromExcel = async () => {
    setIsRestoring(true);
    setRestoreProgress("Membaca file Excel dan mengkonversi ke format backup...");
    setProgressPercent(10);
    try {
      const data = await restoreFile.arrayBuffer();
      const workbook = XLSX.read(data);

      // SKIP installments sheet - will be auto-generated dari trigger
      const requiredSheets = ['Anggota', 'Nasabah', 'Pengajuan Kredit', 'Pembayaran'];
      const missingSheets = requiredSheets.filter(sheet => !workbook.SheetNames.includes(sheet));
      if (missingSheets.length > 0) {
        throw new Error(`Sheet tidak lengkap: ${missingSheets.join(', ')}`);
      }
      const membersData = XLSX.utils.sheet_to_json(workbook.Sheets['Anggota']);
      const customersData = XLSX.utils.sheet_to_json(workbook.Sheets['Nasabah']);
      const applicationsData = XLSX.utils.sheet_to_json(workbook.Sheets['Pengajuan Kredit']);
      const paymentsData = XLSX.utils.sheet_to_json(workbook.Sheets['Pembayaran']);

      // Convert Excel data to backup format
      const backupData = {
        timestamp: new Date().toISOString(),
        data: {
          members: membersData,
          customers: customersData,
          credit_applications: applicationsData,
          payments: paymentsData
        }
      };
      setRestoreProgress("Mengirim data ke server untuk restore incremental per tabel...");
      setProgressPercent(30);

      // Call incremental-restore edge function
      const {
        data: restoreData,
        error
      } = await supabase.functions.invoke('incremental-restore', {
        body: {
          backupData
        }
      });
      if (error) {
        console.error("Restore edge function error:", error);
        throw new Error(error.message || 'Restore gagal');
      }
      if (!restoreData || restoreData.success === false) {
        throw new Error(restoreData?.error || 'Restore gagal');
      }
      console.log("Incremental restore from Excel completed:", restoreData);
      setProgressPercent(100);
      setRestoreProgress("Restore incremental selesai!");
      const result = buildIncrementalRestoreResult(restoreData);
      setRestoreResult(result);
      toast({
        title: "Restore Excel Berhasil",
        description: result.message
      });
    } catch (error: any) {
      console.error("Error restoring data:", error);
      const userMessage = normalizeRestoreErrorMessage(error);
      toast({
        title: "Gagal Restore Data",
        description: userMessage,
        variant: "destructive"
      });
      setRestoreResult({
        success: false,
        message: userMessage,
        stats: {
          members: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          customers: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          applications: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          installments: {
            inserted: 0,
            skipped: 0,
            failed: 0
          },
          // Not restored
          payments: {
            inserted: 0,
            skipped: 0,
            failed: 0
          }
        }
      });
    } finally {
      setIsRestoring(false);
    }
  };
  return <Tabs defaultValue="local" className="space-y-6">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="local" className="flex items-center gap-2">
          <HardDrive className="h-4 w-4" />
          Backup Lokal
        </TabsTrigger>
        <TabsTrigger value="google-drive" className="flex items-center gap-2">
          <Cloud className="h-4 w-4" />
          Google Drive
        </TabsTrigger>
      </TabsList>

      <TabsContent value="local" className="space-y-6">
      {/* Storage Indicator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Monitoring Storage
          </CardTitle>
          <CardDescription>
            Penggunaan storage untuk file backup
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Storage Terpakai</span>
              <span className="font-medium">
                {storageUsed} MB / {storageTotal} MB
              </span>
            </div>
            <Progress value={storageUsed / storageTotal * 100} className="h-2 w-full" />
            <p className="text-xs text-muted-foreground">
              {(storageUsed / storageTotal * 100).toFixed(1)}% terpakai
            </p>
          </div>

          {storageUsed / storageTotal > 0.8 && <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Storage Hampir Penuh</AlertTitle>
              <AlertDescription>
                Storage backup sudah mencapai {(storageUsed / storageTotal * 100).toFixed(0)}%. 
                Sistem akan otomatis menghapus backup lama (&gt;7 hari) saat backup baru dibuat.
              </AlertDescription>
            </Alert>}

          <div className="text-xs text-muted-foreground space-y-1">
            <p>✓ Auto-delete backup lebih dari 7 hari: Aktif</p>
            <p>✓ Backup disimpan: {backupFiles.length} file</p>
            <p>✓ Total file backup: {backupFiles.length} file</p>
          </div>
        </CardContent>
      </Card>

      {/* Auto Backup Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="h-5 w-5" />
            Auto Backup Harian
          </CardTitle>
          <CardDescription>
            Backup otomatis setiap hari jam 00:00 WIB, menyimpan backup 7 hari terakhir
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="auto-backup">Aktifkan Auto Backup</Label>
            <Switch id="auto-backup" checked={autoBackupEnabled} onCheckedChange={handleAutoBackupToggle} />
          </div>
          
          {autoBackupEnabled && <div className="space-y-3">
              <div className="space-y-2 text-sm">
                <div className="p-3 bg-primary/5 rounded-md border border-primary/20">
                  <p className="font-medium text-primary mb-1">📅 Jadwal Auto Backup</p>
                  <p className="text-muted-foreground text-xs">
                    Backup otomatis berjalan setiap hari pada jam 00:00 WIB (tengah malam)
                  </p>
                  <p className="text-muted-foreground text-xs mt-1">
                    Sistem akan memeriksa riwayat backup dan hanya melakukan backup jika belum ada backup hari ini
                  </p>
                </div>
                {lastBackup && <p className="text-muted-foreground">
                    <span className="font-medium">Backup terakhir:</span> {format(new Date(lastBackup), 'dd MMMM yyyy HH:mm', {
                  locale: id
                })}
                  </p>}
                {nextBackup && <p className="text-muted-foreground">
                    <span className="font-medium">Backup berikutnya:</span> {format(new Date(nextBackup), 'dd MMMM yyyy HH:mm', {
                  locale: id
                })}
                  </p>}
              </div>
              
              {/* Tombol Backup Sekarang */}
              <Button
                onClick={handleBackupNow}
                disabled={isExporting}
                variant="outline"
                className="w-full"
              >
                {isExporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Membuat Backup...
                  </>
                ) : (
                  <>
                    <Cloud className="mr-2 h-4 w-4" />
                    Backup Sekarang
                  </>
                )}
              </Button>
              
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Kebijakan Retensi</AlertTitle>
                <AlertDescription>
                  Backup lebih dari 7 hari akan otomatis dihapus untuk menghemat storage
                </AlertDescription>
              </Alert>
            </div>}
        </CardContent>
      </Card>

      {/* Manual Backup */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Backup Manual
          </CardTitle>
          <CardDescription>
            Download backup database dalam format JSON atau Excel
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button onClick={exportToJSON} disabled={isExporting} variant="outline" className="w-full">
              <Database className="mr-2 h-4 w-4" />
              Backup Database (JSON)
            </Button>
            <Button onClick={exportToExcel} disabled={isExporting} variant="outline" className="w-full">
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Export ke Excel
            </Button>
          </div>
          
          {/* Regenerate Missing Installments */}
          
        </CardContent>
      </Card>

      {/* Restore Data */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Restore Data dari Backup
          </CardTitle>
          <CardDescription>
            Upload file backup Excel (.xlsx) atau JSON (.json) untuk mengembalikan data ke sistem
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div>
              <Label htmlFor="restore-file">Pilih File Backup (Excel atau JSON)</Label>
              <Input id="restore-file" type="file" accept=".xlsx,.xls,.json" onChange={handleFileUpload} disabled={isRestoring} className="mt-2" />
              {restoreFile && <p className="text-sm text-muted-foreground mt-2">
                  File dipilih: {restoreFile.name} ({restoreFile.name.endsWith('.json') ? 'JSON Backup' : 'Excel Backup'})
                </p>}
            </div>

            {/* Backup Analysis */}
            {backupAnalysis && <Alert>
                <CheckCircle2 className="h-4 w-4" />
                <AlertTitle>Analisis File Backup</AlertTitle>
                <AlertDescription className="space-y-2">
                  <p className="text-sm font-medium">Isi file backup yang akan di-restore:</p>
                  {backupAnalysis.version && (
                    <div className="inline-flex items-center gap-2 mb-2 px-2 py-1 bg-primary/10 text-primary rounded-md text-xs font-semibold">
                      <CheckCircle2 className="h-3 w-3" />
                      Backup Version {backupAnalysis.version}
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-2 text-xs mt-2">
                    <div className="space-y-1">
                      <p>👥 Anggota: <span className="font-semibold">{backupAnalysis.coreTables.members}</span></p>
                      <p>👤 Nasabah: <span className="font-semibold">{backupAnalysis.coreTables.customers}</span></p>
                    </div>
                    <div className="space-y-1">
                      <p>📋 Pengajuan Kredit: <span className="font-semibold">{backupAnalysis.coreTables.applications}</span></p>
                      <p>💳 Angsuran: <span className="font-semibold">{backupAnalysis.coreTables.installments || 0}</span></p>
                      <p>💰 Pembayaran: <span className="font-semibold">{backupAnalysis.coreTables.payments}</span></p>
                    </div>
                  </div>
                  {backupAnalysis.version === '2.0' && Object.keys(backupAnalysis.tables).length > 5 && (
                    <div className="mt-2 p-2 bg-muted rounded text-xs">
                      <p className="font-semibold mb-1">+ {Object.keys(backupAnalysis.tables).length - 5} tables tambahan:</p>
                      <p className="text-muted-foreground">
                        {Object.keys(backupAnalysis.tables)
                          .filter(t => !['members', 'customers', 'credit_applications', 'installments', 'payments'].includes(t))
                          .slice(0, 5)
                          .join(', ')}
                        {Object.keys(backupAnalysis.tables).length > 10 && ', ...'}
                      </p>
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-2">
                    Ukuran file: {(backupAnalysis.totalSize / 1024 / 1024).toFixed(2)} MB
                  </p>
                  {backupAnalysis.coreTables.installments && backupAnalysis.coreTables.installments > 0 && <p className="text-xs font-medium text-primary mt-2">
                      ✅ File ini memiliki data angsuran lengkap ({backupAnalysis.coreTables.installments} records)
                    </p>}
                  {(!backupAnalysis.coreTables.installments || backupAnalysis.coreTables.installments === 0) && <p className="text-xs font-medium text-amber-600 mt-2">
                      ⚠️ File ini TIDAK memiliki data angsuran - gunakan tombol Regenerasi setelah restore
                    </p>}
                </AlertDescription>
              </Alert>}

            {/* Info about Restore Method */}
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertTitle>✨ Metode Restore: 2 Langkah (Cleaning + UPSERT)</AlertTitle>
              <AlertDescription className="space-y-3 text-xs">
                <div>
                  <p className="font-semibold mb-2">1️⃣ CLEANING STEP (Pembersihan):</p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>🧹 <strong>Installments & Payments</strong> untuk aplikasi di backup akan <strong>DIHAPUS DULU</strong></li>
                    <li>🔒 Mencegah duplikasi data angsuran dan pembayaran</li>
                    <li>✅ Data baru dari backup kemudian dimasukkan</li>
                  </ul>
                </div>
                
                <div>
                  <p className="font-semibold mb-2">2️⃣ UPSERT (Update/Insert):</p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>🔄 Jika ID sudah ada → Data lama <strong>DITIMPA/UPDATE</strong> dengan data dari backup</li>
                    <li>➕ Jika ID belum ada → Data <strong>DITAMBAHKAN/INSERT</strong> sebagai baru</li>
                    <li>📦 Batch processing: 100-1000 record per batch untuk performa optimal</li>
                    <li>📊 Progress tracking real-time per tabel</li>
                    <li>📋 Urutan: profiles → members → customers → applications → installments → payments</li>
                  </ul>
                </div>
                
                <p className="font-medium text-amber-600 dark:text-amber-400 mt-2">
                  ⚠️ Perhatian: Installments/Payments lama akan dihapus, data lainnya akan ditimpa!
                </p>
              </AlertDescription>
            </Alert>

            <Button onClick={() => {
              if (restoreFile?.name.endsWith('.json')) {
                restoreFromJSON();
              } else {
                restoreFromExcel();
              }
            }} disabled={!restoreFile || isRestoring} className="w-full" size="lg">
              {isRestoring ? <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memulihkan Data...
                </> : <>
                  <Upload className="mr-2 h-4 w-4" />
                  Restore Data dari {restoreFile?.name.endsWith('.json') ? 'JSON' : 'Excel'}
                </>}
            </Button>

            {isRestoring && <div className="space-y-2 w-full">
                <Progress value={progressPercent} className="h-2 w-full" />
                <p className="text-sm text-center text-muted-foreground">{restoreProgress}</p>
              </div>}

            {/* Real-time Restore Progress Monitor */}
            {activeRestoreProgressId && (
              <div className="mt-4">
                <RestoreProgressMonitor 
                  progressId={activeRestoreProgressId}
                  onComplete={(success) => {
                    console.log("Restore completed:", success);
                    setIsRestoring(false);
                  }}
                />
              </div>
            )}

            {restoreResult && <Alert variant={restoreResult.success ? "default" : "destructive"}>
                {restoreResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                <AlertTitle>
                  {restoreResult.success ? "Restore Berhasil" : "Restore Gagal"}
                </AlertTitle>
                <AlertDescription className="space-y-3">
                  <p className="font-medium">{restoreResult.message}</p>
                  
                  {restoreResult.version && (
                    <div className="inline-flex items-center gap-2 px-2 py-1 bg-primary/10 text-primary rounded-md text-xs font-semibold">
                      Backup Version {restoreResult.version}
                    </div>
                  )}
                  
                  {restoreResult.totals && (
                    <div className="p-3 bg-primary/5 rounded-lg space-y-1">
                      <p className="font-semibold text-sm">Total Summary:</p>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div className="text-green-600 dark:text-green-400">
                          ✓ Inserted: {restoreResult.totals.inserted}
                        </div>
                        <div className="text-blue-600 dark:text-blue-400">
                          ↻ Updated: {restoreResult.totals.updated}
                        </div>
                        <div className="text-red-600 dark:text-red-400">
                          ✗ Failed: {restoreResult.totals.failed}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="text-xs space-y-2 mt-3 p-3 bg-muted/50 rounded-lg max-h-80 overflow-y-auto">
                    <p className="font-semibold text-sm mb-2 sticky top-0 bg-muted/50 pb-1">📊 Detail per Table:</p>
                    
                    <div className="space-y-1.5">
                      {Object.entries(restoreResult.stats).map(([tableName, stats]) => {
                        const total = stats.inserted + (stats.updated || 0) + stats.skipped + stats.failed;
                        if (total === 0) return null;
                        
                        return (
                          <div key={tableName} className="flex justify-between items-center py-1 border-b border-border/50">
                            <span className="font-medium">{tableName}:</span>
                            <span className="font-mono text-xs">
                              {stats.inserted > 0 && (
                                <span className="text-green-600 dark:text-green-400">{stats.inserted} ✓</span>
                              )}
                              {stats.updated && stats.updated > 0 && (
                                <span className="text-blue-600 dark:text-blue-400 ml-2">{stats.updated} ↻</span>
                              )}
                              {stats.skipped > 0 && (
                                <span className="text-yellow-600 dark:text-yellow-400 ml-2">{stats.skipped} ⊘</span>
                              )}
                              {stats.failed > 0 && (
                                <span className="text-red-600 dark:text-red-400 ml-2">{stats.failed} ✗</span>
                              )}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div className="pt-2 mt-2 border-t border-border text-[10px] text-muted-foreground">
                    <p>✓ = Inserted • ↻ = Updated • ⊘ = Skipped • ✗ = Failed</p>
                  </div>
                </AlertDescription>
              </Alert>}
          </div>
        </CardContent>
      </Card>

      {/* Backup Files List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            File Backup Tersimpan di Cloud
          </CardTitle>
          <CardDescription>
            Restore langsung dari backup yang tersimpan di cloud storage (Table-by-Table)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Info about Restore Method */}
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertTitle>✨ Metode Restore: 2 Langkah (Cleaning + UPSERT)</AlertTitle>
            <AlertDescription className="space-y-3 text-xs">
              <div>
                <p className="font-semibold mb-1">1️⃣ CLEANING STEP:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>🧹 <strong>Installments & Payments</strong> lama <strong>DIHAPUS DULU</strong></li>
                  <li>🔒 Mencegah duplikasi</li>
                </ul>
              </div>
              
              <div>
                <p className="font-semibold mb-1">2️⃣ UPSERT:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>🔄 ID sama → <strong>DITIMPA/UPDATE</strong></li>
                  <li>➕ ID baru → <strong>DITAMBAHKAN/INSERT</strong></li>
                  <li>📦 Batch 100-1000 records</li>
                </ul>
              </div>
              
              <p className="font-medium text-amber-600 dark:text-amber-400 mt-1">
                ⚠️ Installments/Payments dihapus, data lain ditimpa!
              </p>
            </AlertDescription>
          </Alert>

          {backupFiles.length === 0 ? <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Belum Ada Backup</AlertTitle>
              <AlertDescription>
                Belum ada file backup yang tersimpan di cloud storage. 
                {autoBackupEnabled ? <span className="block mt-2">
                    Auto backup berkala sudah aktif. Backup pertama akan dilakukan pada: <strong>{nextBackup ? format(new Date(nextBackup), 'dd MMMM yyyy HH:mm', {
                    locale: id
                  }) : 'segera'}</strong>
                  </span> : <span className="block mt-2">
                    Aktifkan <strong>Auto Backup Harian</strong> di atas untuk backup otomatis setiap hari jam 00:00 WIB.
                  </span>}
              </AlertDescription>
            </Alert> : <div className="space-y-2">
              {backupFiles.map(file => <div key={file.name} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(file.created_at), 'dd MMM yyyy HH:mm', {
                    locale: id
                  })} • 
                      {(file.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="default" onClick={() => restoreFromStorage(file.name)} disabled={isRestoring} title="Restore langsung dari cloud">
                      <Upload className="h-4 w-4 mr-1" />
                      Restore
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => downloadBackupFile(file.name)} disabled={isRestoring} title="Download file backup">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => deleteBackupFile(file.name)} disabled={isRestoring} title="Hapus file backup">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>)}
            </div>}

          {/* Real-time Restore Progress Monitor untuk Cloud Restore */}
          {activeRestoreProgressId && (
            <div className="mt-4">
              <RestoreProgressMonitor 
                progressId={activeRestoreProgressId}
                onComplete={(success) => {
                  console.log("Cloud restore completed:", success);
                  setIsRestoring(false);
                }}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Restore Confirmation Dialog */}
      <AlertDialog open={showRestoreDialog} onOpenChange={setShowRestoreDialog}>
        <AlertDialogContent className="max-w-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-amber-600">
              <AlertCircle className="h-5 w-5" />
              Peringatan: Restore Database
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4 text-left">
                <p className="font-semibold text-foreground">
                  File Backup: <span className="text-primary">{selectedRestoreFile}</span>
                </p>
                
                <Alert variant="destructive" className="border-amber-500 bg-amber-50 dark:bg-amber-950/30">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <AlertTitle className="text-amber-800 dark:text-amber-300">Penting! Pahami Metode Restore (2 Langkah)</AlertTitle>
                  <AlertDescription className="text-amber-700 dark:text-amber-400 space-y-3 text-sm">
                    <div>
                      <p className="font-semibold mb-1">1️⃣ CLEANING STEP (Pembersihan):</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Installments & Payments</strong> untuk aplikasi di backup akan <strong>DIHAPUS DULU</strong></li>
                        <li>Mencegah duplikasi data angsuran dan pembayaran</li>
                        <li>Data baru dari backup kemudian dimasukkan</li>
                      </ul>
                    </div>
                    
                    <div>
                      <p className="font-semibold mb-1">2️⃣ UPSERT (Update/Insert):</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Jika ID sudah ada:</strong> Data lama DITIMPA dengan versi dari backup</li>
                        <li><strong>Jika ID belum ada:</strong> Data baru DITAMBAHKAN ke database</li>
                        <li><strong>TIDAK ada skip:</strong> Semua data dari backup diproses</li>
                      </ul>
                    </div>
                  </AlertDescription>
                </Alert>

                <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 space-y-2">
                  <p className="font-semibold text-destructive">⚠️ Risiko yang Mungkin Terjadi:</p>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>❌ Pembayaran yang dilakukan setelah tanggal backup akan HILANG</li>
                    <li>❌ Perubahan data nasabah/kredit terbaru akan KEMBALI ke versi lama</li>
                    <li>❌ Status kredit yang sudah berubah akan KEMBALI ke status sebelumnya</li>
                    <li>❌ Angsuran yang sudah dibayar bisa kembali ke status belum bayar</li>
                  </ul>
                </div>

                <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                  <p className="font-semibold text-sm">✅ Rekomendasi Penggunaan:</p>
                  <ul className="text-xs space-y-1 text-muted-foreground">
                    <li>• Restore hanya untuk recovery data yang hilang atau rusak</li>
                    <li>• JANGAN gunakan restore untuk "membatalkan" transaksi</li>
                    <li>• Pastikan backup sudah benar sebelum melanjutkan</li>
                    <li>• Pertimbangkan membuat backup database saat ini terlebih dahulu</li>
                  </ul>
                </div>

                <p className="text-sm font-semibold text-center text-destructive">
                  Apakah Anda yakin ingin melanjutkan restore?
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isRestoring}>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={confirmRestore} disabled={isRestoring} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {isRestoring ? <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restoring...
                </> : 'Ya, Saya Mengerti Risikonya - Restore Sekarang'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      </TabsContent>

      <TabsContent value="google-drive">
        <GoogleDriveSettings />
      </TabsContent>
    </Tabs>;
};