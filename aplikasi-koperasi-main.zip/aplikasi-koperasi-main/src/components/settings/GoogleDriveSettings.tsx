import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Cloud, CheckCircle2, XCircle, Copy, Eye, EyeOff, Download, Upload, Trash2, RefreshCw, Shield, Clock, Calendar, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SupercodeVerificationDialog } from "@/components/SupercodeVerificationDialog";
import { CleanupHistoryLog } from "./CleanupHistoryLog";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface GoogleDriveSettings {
  id?: string;
  auth_mode?: 'service_account' | 'oauth';
  client_email: string;
  private_key: string;
  folder_id: string;
  is_enabled: boolean;
  backup_schedule?: 'daily' | 'weekly' | 'monthly';
  backup_time?: string;
  backup_day?: number;
  backup_date?: number;
  last_backup_at?: string;
  next_backup_at?: string;
  oauth_client_id?: string;
  oauth_client_secret?: string;
  oauth_user_email?: string;
  oauth_access_token?: string;
  oauth_refresh_token?: string;
  oauth_token_expiry?: string;
  retention_days?: number;
}

interface GoogleDriveFile {
  id: string;
  name: string;
  created_at: string;
  size: number;
  mimeType: string;
}

export const GoogleDriveSettings = () => {
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'unknown' | 'connected' | 'error'>('unknown');
  const [showPrivateKey, setShowPrivateKey] = useState(false);
  const [driveFiles, setDriveFiles] = useState<GoogleDriveFile[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);
  const [selectedFile, setSelectedFile] = useState<GoogleDriveFile | null>(null);
  const [restoreProgress, setRestoreProgress] = useState("");
  const [restorePercent, setRestorePercent] = useState(0);
  const [superCode, setSuperCode] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const [showSupercodeDialog, setShowSupercodeDialog] = useState(false);
  const [uploadingJson, setUploadingJson] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [lastBackupStatus, setLastBackupStatus] = useState<string>('');
  const [isTokenExpired, setIsTokenExpired] = useState(false);
  const [selectedFilesForCleanup, setSelectedFilesForCleanup] = useState<Set<string>>(new Set());
  const [isDeletingFiles, setIsDeletingFiles] = useState(false);
  
  // Ref to track last token refresh time (prevent infinite loop)
  const lastRefreshAttempt = useRef<number>(0);
  
  const [settings, setSettings] = useState<GoogleDriveSettings>({
    auth_mode: 'oauth',
    client_email: '',
    private_key: '',
    folder_id: '',
    is_enabled: false,
    backup_schedule: 'daily',
    backup_time: '02:00',
    backup_day: 1,
    backup_date: 1,
    oauth_client_id: '',
    oauth_client_secret: '',
    retention_days: 7,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  useEffect(() => {
    if (connectionStatus === 'connected' && settings.is_enabled) {
      loadDriveFiles();
    }
  }, [connectionStatus, settings.is_enabled]);

  // Check if OAuth authentication needs re-auth (refresh token invalid)
  useEffect(() => {
    if (settings.auth_mode === 'oauth') {
      // Only set expired if refresh token is missing or invalid
      // Access token expiry is handled by auto-refresh every 30 minutes
      const hasRefreshToken = !!settings.oauth_refresh_token;
      const hasOAuthCredentials = !!settings.oauth_client_id && !!settings.oauth_client_secret;
      
      // Only show warning if critical OAuth components are missing
      setIsTokenExpired(!hasRefreshToken || !hasOAuthCredentials);
    } else {
      setIsTokenExpired(false);
    }
  }, [settings.auth_mode, settings.oauth_refresh_token, settings.oauth_client_id, settings.oauth_client_secret]);

  // Auto-refresh token mechanism: check every hour, refresh 1 day before expiry
  useEffect(() => {
    if (settings.auth_mode !== 'oauth' || !settings.oauth_token_expiry || !settings.is_enabled) {
      return;
    }

    const checkAndRefreshToken = async () => {
      const now = Date.now();
      const oneHourInMs = 60 * 60 * 1000;
      
      // Prevent refresh if we already tried within the last hour
      if (now - lastRefreshAttempt.current < oneHourInMs) {
        return;
      }

      const expiryDate = new Date(settings.oauth_token_expiry);
      const currentDate = new Date(now);
      const oneDayBeforeExpiry = new Date(expiryDate.getTime() - 24 * 60 * 60 * 1000);

      // If token expires within 24 hours and not yet expired, auto-refresh
      if (currentDate >= oneDayBeforeExpiry && currentDate < expiryDate) {
        console.log('Auto-refreshing OAuth token (expires soon)...');
        lastRefreshAttempt.current = now; // Mark refresh attempt
        
        try {
          const { data, error } = await supabase.functions.invoke('google-drive-refresh-token');
          
          if (error) throw error;
          
          if (data?.success) {
            toast({
              title: "Token Diperpanjang",
              description: "Token Google Drive berhasil diperpanjang otomatis",
            });
            // Manually update settings instead of reloading to prevent loop
            setSettings(prev => ({
              ...prev,
              oauth_token_expiry: data.expiresAt,
            }));
          } else {
            throw new Error(data?.error || 'Gagal memperpanjang token');
          }
        } catch (error: any) {
          console.error('Auto-refresh token failed:', error);
          toast({
            title: "Gagal Memperpanjang Token",
            description: "Token tidak dapat diperpanjang otomatis. Silakan re-auth manual.",
            variant: "destructive",
          });
        }
      }
    };

    // Check immediately on mount (but respects cooldown)
    checkAndRefreshToken();

    // Then check every hour
    const intervalId = setInterval(checkAndRefreshToken, 60 * 60 * 1000);

    return () => clearInterval(intervalId);
  }, [settings.auth_mode, settings.oauth_token_expiry, settings.is_enabled, toast]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('google_drive_settings')
        .select('*')
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSettings({
          id: data.id,
          auth_mode: (data.auth_mode as 'service_account' | 'oauth') || 'oauth',
          client_email: data.client_email || '',
          private_key: data.private_key || '',
          folder_id: data.folder_id || '',
          is_enabled: data.is_enabled || false,
          backup_schedule: (data.backup_schedule as 'daily' | 'weekly' | 'monthly') || 'daily',
          backup_time: data.backup_time || '02:00:00',
          backup_day: data.backup_day || 1,
          backup_date: data.backup_date || 1,
          last_backup_at: data.last_backup_at,
          next_backup_at: data.next_backup_at,
          oauth_client_id: data.oauth_client_id || '',
          oauth_client_secret: data.oauth_client_secret || '',
          oauth_user_email: data.oauth_user_email,
          oauth_access_token: data.oauth_access_token,
          oauth_refresh_token: data.oauth_refresh_token,
          oauth_token_expiry: data.oauth_token_expiry,
          retention_days: data.retention_days || 7,
        });
        
        // Set connection status based on auth mode
        if (data.auth_mode === 'oauth') {
          // Check token expiry
          if (data.oauth_token_expiry) {
            const expiryDate = new Date(data.oauth_token_expiry);
            const now = new Date();
            if (now >= expiryDate) {
              setConnectionStatus('error');
            } else if (data.oauth_access_token && data.folder_id) {
              setConnectionStatus('connected');
            }
          } else if (data.oauth_access_token && data.folder_id) {
            setConnectionStatus('connected');
          }
        } else {
          if (data.client_email && data.private_key && data.folder_id) {
            setConnectionStatus('connected');
          }
        }
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: "Error",
        description: "Gagal memuat pengaturan Google Drive",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    const verified = await requireSuperCode("menyimpan pengaturan Google Drive");
    if (!verified) return;
    
    try {
      setLoading(true);

      // Validate inputs
      if (!settings.client_email || !settings.private_key || !settings.folder_id) {
        toast({
          title: "Validasi Gagal",
          description: "Semua field harus diisi",
          variant: "destructive",
        });
        return;
      }

      // Check if settings exist and are connected (require SuperCode for updates)
      const { data: existing } = await supabase
        .from('google_drive_settings')
        .select('id')
        .maybeSingle();

      // If settings exist and connected, require SuperCode verification
      if (existing && settings.id && connectionStatus === 'connected') {
        if (!superCode.trim()) {
          toast({
            title: "Error",
            description: "Harap masukkan SuperCode untuk verifikasi perubahan konfigurasi",
            variant: "destructive",
          });
          return;
        }

        // Verify SuperCode
        const { data: verifyData, error: verifyError } = await supabase.functions.invoke(
          "verify-supercode",
          {
            body: { superCodeInput: superCode },
          }
        );

        if (verifyError || !verifyData?.valid) {
          toast({
            title: "SuperCode Salah",
            description: "SuperCode yang Anda masukkan tidak valid",
            variant: "destructive",
          });
          return;
        }
      }

      if (existing) {
        // Update existing
        const { error } = await supabase
          .from('google_drive_settings')
          .update({
            auth_mode: settings.auth_mode,
            client_email: settings.client_email,
            private_key: settings.private_key,
            folder_id: settings.folder_id,
            is_enabled: settings.is_enabled,
            backup_schedule: settings.backup_schedule,
            backup_time: settings.backup_time,
            backup_day: settings.backup_day,
            backup_date: settings.backup_date,
            oauth_client_id: settings.oauth_client_id,
            oauth_client_secret: settings.oauth_client_secret,
          })
          .eq('id', existing.id);

        if (error) throw error;
      } else {
        // Insert new
        const { error } = await supabase
          .from('google_drive_settings')
          .insert({
            auth_mode: settings.auth_mode,
            client_email: settings.client_email,
            private_key: settings.private_key,
            folder_id: settings.folder_id,
            is_enabled: settings.is_enabled,
            backup_schedule: settings.backup_schedule,
            backup_time: settings.backup_time,
            backup_day: settings.backup_day,
            backup_date: settings.backup_date,
            oauth_client_id: settings.oauth_client_id,
            oauth_client_secret: settings.oauth_client_secret,
          });

        if (error) throw error;
      }

      toast({
        title: "✓ Berhasil",
        description: "Pengaturan Google Drive berhasil disimpan",
      });

      // Reset verification state
      setSuperCode("");
      setShowVerification(false);

      // Test connection after save
      await testConnection();
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Error",
        description: "Gagal menyimpan pengaturan",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const testConnection = async () => {
    try {
      setTesting(true);
      setConnectionStatus('unknown');

      // Check credentials based on auth mode
      if (settings.auth_mode === 'oauth') {
        if (!settings.oauth_access_token && !settings.folder_id) {
          toast({
            title: "Kredensial Tidak Lengkap",
            description: "Silakan login dengan Google dan isi Folder ID terlebih dahulu",
            variant: "destructive",
          });
          setConnectionStatus('error');
          return;
        } else if (!settings.oauth_access_token) {
          toast({
            title: "Belum Login Google",
            description: "Silakan klik tombol 'Login dengan Google' terlebih dahulu",
            variant: "destructive",
          });
          setConnectionStatus('error');
          return;
        } else if (!settings.folder_id) {
          toast({
            title: "Folder ID Belum Diisi",
            description: "Silakan isi Google Drive Folder ID terlebih dahulu",
            variant: "destructive",
          });
          setConnectionStatus('error');
          return;
        }
      } else {
        if (!settings.client_email || !settings.private_key || !settings.folder_id) {
          toast({
            title: "Kredensial Tidak Lengkap",
            description: "Silakan isi semua field kredensial",
            variant: "destructive",
          });
          setConnectionStatus('error');
          return;
        }
      }

      const testData = {
        timestamp: new Date().toISOString(),
        test: true,
        message: 'Test connection from Lovable Cloud',
      };

      const filename = `test-connection-${Date.now()}.json`;

      const { data, error } = await supabase.functions.invoke('upload-to-google-drive', {
        body: { 
          backupData: testData,
          filename 
        }
      });

      if (error) {
        console.error('Connection test failed:', error);
        setConnectionStatus('error');
        toast({
          title: "✗ Koneksi Gagal",
          description: "Tidak dapat terhubung ke Google Drive. Periksa kredensial Anda.",
          variant: "destructive",
        });
      } else {
        setConnectionStatus('connected');
        toast({
          title: "✓ Koneksi Berhasil",
          description: "Google Drive terhubung dengan baik",
        });
      }
    } catch (error) {
      console.error('Connection test error:', error);
      setConnectionStatus('error');
      toast({
        title: "Error",
        description: "Gagal menguji koneksi",
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  const handleJsonUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      toast({
        title: "Error",
        description: "Harap upload file JSON yang valid",
        variant: "destructive",
      });
      return;
    }

    try {
      setUploadingJson(true);
      const fileContent = await file.text();
      const jsonData = JSON.parse(fileContent);

      // Validate JSON structure
      if (!jsonData.client_email || !jsonData.private_key) {
        toast({
          title: "Error",
          description: "File JSON tidak valid. Pastikan file berisi client_email dan private_key",
          variant: "destructive",
        });
        return;
      }

      // CRITICAL FIX: Extract ONLY the private_key string, not entire JSON
      let privateKeyString = jsonData.private_key;
      
      // If private_key is somehow a JSON object (shouldn't happen but handle it)
      if (typeof privateKeyString === 'object') {
        privateKeyString = privateKeyString.private_key || JSON.stringify(privateKeyString);
      }
      
      // Validate private key format
      if (!privateKeyString.includes('BEGIN PRIVATE KEY')) {
        toast({
          title: "Error",
          description: "Private key tidak valid. Pastikan format private key benar",
          variant: "destructive",
        });
        return;
      }

      // Update settings with JSON data - ONLY the private key string
      setSettings({
        ...settings,
        client_email: jsonData.client_email,
        private_key: privateKeyString, // Store ONLY the private key string
      });

      toast({
        title: "✓ Berhasil",
        description: "Kredensial berhasil dimuat dari file JSON. Jangan lupa SIMPAN PERUBAHAN.",
      });
    } catch (error) {
      console.error('Error parsing JSON:', error);
      toast({
        title: "Error",
        description: "Gagal membaca file JSON. Pastikan format file benar",
        variant: "destructive",
      });
    } finally {
      setUploadingJson(false);
      // Reset input
      event.target.value = '';
    }
  };

  const handleOAuthLogin = async () => {
    try {
      setLoading(true);
      
      if (!settings.oauth_client_id || !settings.oauth_client_secret) {
        toast({
          title: "Kredensial Tidak Lengkap",
          description: "Harap isi OAuth Client ID dan Secret terlebih dahulu",
          variant: "destructive",
        });
        return;
      }

      // Save settings first to store oauth credentials
      await handleSave();
      
      // Generate OAuth URL
      const redirectUrl = `${window.location.origin}/oauth/callback`;
      const { data, error } = await supabase.functions.invoke('google-drive-oauth-url', {
        body: { 
          redirectUrl,
          clientId: settings.oauth_client_id
        }
      });

      if (error) throw error;
      if (!data?.authUrl) throw new Error('No auth URL returned');

      // Store redirect URL in sessionStorage for callback
      sessionStorage.setItem('oauth_redirect', window.location.pathname);

      // Open Google OAuth in new tab to avoid iframe X-Frame-Options issues
      window.open(data.authUrl, '_blank', 'noopener,noreferrer');
    } catch (error) {
      console.error('OAuth login error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Gagal melakukan OAuth login",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManualBackup = async () => {
    if (!settings.id) {
      toast({
        title: "Error",
        description: "Konfigurasi Google Drive harus disimpan terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsBackingUp(true);
      setLastBackupStatus('Memulai backup manual...');

      const { data, error } = await supabase.functions.invoke('scheduled-google-drive-backup', {
        body: { force: true }
      });

      if (error) throw error;

      if (data?.success) {
        setLastBackupStatus(`✓ Backup berhasil: ${data.filename}`);
        toast({
          title: "✓ Backup Berhasil",
          description: `File: ${data.filename}`,
        });
        
        // Auto-cleanup old backups after successful backup
        await handleAutoCleanupOldBackups();
        
        // Reload settings and files
        await loadSettings();
        if (settings.is_enabled) {
          await loadDriveFiles();
        }
      } else {
        setLastBackupStatus(`⚠ ${data?.message || 'Backup tidak dijalankan'}`);
        toast({
          title: "Info",
          description: data?.message || "Backup tidak dijalankan",
        });
      }
    } catch (error) {
      console.error('Manual backup error:', error);
      setLastBackupStatus('✗ Backup gagal');
      toast({
        title: "Error",
        description: "Gagal melakukan backup manual",
        variant: "destructive",
      });
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleSaveSchedule = async () => {
    if (!settings.id) {
      toast({
        title: "Error",
        description: "Konfigurasi Google Drive harus disimpan terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    const verified = await requireSuperCode("menyimpan jadwal backup");
    if (!verified) return;

    try {
      setLoading(true);

      const { error } = await supabase
        .from('google_drive_settings')
        .update({
          backup_schedule: settings.backup_schedule,
          backup_time: settings.backup_time,
          backup_day: settings.backup_day,
          backup_date: settings.backup_date,
          retention_days: settings.retention_days,
        })
        .eq('id', settings.id);

      if (error) throw error;

      toast({
        title: "✓ Berhasil",
        description: "Jadwal backup berhasil disimpan",
      });
    } catch (error) {
      console.error('Error saving schedule:', error);
      toast({
        title: "Error",
        description: "Gagal menyimpan jadwal backup",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleToggleEnabled = async (enabled: boolean) => {
    setSettings({ ...settings, is_enabled: enabled });
    
    if (settings.id) {
      try {
        const { error } = await supabase
          .from('google_drive_settings')
          .update({ is_enabled: enabled })
          .eq('id', settings.id);

        if (error) throw error;

        toast({
          title: enabled ? "✓ Diaktifkan" : "✓ Dinonaktifkan",
          description: enabled 
            ? "Backup ke Google Drive diaktifkan" 
            : "Backup ke Google Drive dinonaktifkan",
        });
      } catch (error) {
        console.error('Error toggling:', error);
        setSettings({ ...settings, is_enabled: !enabled });
      }
    }
  };

  const loadDriveFiles = async () => {
    try {
      setLoadingFiles(true);
      
      const { data, error } = await supabase.functions.invoke('list-google-drive-backups');
      
      if (error) {
        console.error('Failed to load files:', error);
        return;
      }

      if (data?.files) {
        setDriveFiles(data.files);
      }
    } catch (error) {
      console.error('Error loading files:', error);
    } finally {
      setLoadingFiles(false);
    }
  };

  const downloadFile = async (file: GoogleDriveFile) => {
    try {
      const { data, error } = await supabase.functions.invoke('download-from-google-drive', {
        body: { fileId: file.id }
      });

      if (error) throw error;

      if (data?.data) {
        const blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        toast({
          title: "✓ Berhasil",
          description: "File backup berhasil diunduh",
        });
      }
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Error",
        description: "Gagal mengunduh file",
        variant: "destructive",
      });
    }
  };

  const handleBatchDeleteFiles = async () => {
    if (selectedFilesForCleanup.size === 0) {
      toast({
        title: "Pilih File",
        description: "Pilih minimal 1 file untuk dihapus",
        variant: "destructive",
      });
      return;
    }

    setIsDeletingFiles(true);
    try {
      const fileIds = Array.from(selectedFilesForCleanup);
      const { data, error } = await supabase.functions.invoke('delete-google-drive-files', {
        body: { fileIds }
      });

      if (error) throw error;

      toast({
        title: "Batch Delete Berhasil",
        description: `${data?.deletedFiles?.length || 0} file berhasil dihapus`,
      });

      setSelectedFilesForCleanup(new Set());
      await loadDriveFiles();
    } catch (error: any) {
      console.error('Batch delete error:', error);
      toast({
        title: "Gagal Menghapus File",
        description: error.message || "Terjadi kesalahan",
        variant: "destructive",
      });
    } finally {
      setIsDeletingFiles(false);
    }
  };

  const handleAutoCleanupOldBackups = async () => {
    try {
      console.log('Running auto-cleanup for old backups...');
      
      // Get current user ID
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data, error } = await supabase.functions.invoke('cleanup-old-google-drive-backups', {
        body: {
          cleanup_type: 'auto',
          executed_by: user?.id || null
        }
      });

      if (error) {
        console.error('Auto-cleanup error:', error);
        return;
      }

      if (data?.deletedFiles?.length > 0) {
        // Format deleted files information
        const filesList = data.deletedFiles
          .map((file: any) => {
            const createdDate = new Date(file.createdTime).toLocaleDateString('id-ID', {
              day: '2-digit',
              month: 'short',
              year: 'numeric'
            });
            return `• ${file.name} (${createdDate})`;
          })
          .join('\n');

        toast({
          title: "🗑️ Auto-Cleanup Berhasil",
          description: (
            <div className="space-y-2">
              <p className="font-semibold">
                {data.deletedFiles.length} backup lama dihapus (lebih dari {data.retentionDays} hari)
              </p>
              <div className="text-sm text-muted-foreground max-h-32 overflow-y-auto">
                <p className="font-medium mb-1">File yang dihapus:</p>
                <pre className="whitespace-pre-wrap font-mono text-xs">
                  {filesList}
                </pre>
              </div>
            </div>
          ),
          duration: 8000,
        });
        await loadDriveFiles();
      } else {
        console.log('No old backups to delete');
        toast({
          title: "✓ Cleanup Selesai",
          description: `Tidak ada backup lama yang perlu dihapus (masa simpan: ${data?.retentionDays || settings.retention_days || 7} hari)`,
        });
      }
    } catch (error) {
      console.error('Auto-cleanup error:', error);
    }
  };

  const handleManualCleanup = async () => {
    if (!confirm('Apakah Anda yakin ingin menjalankan cleanup manual? File backup yang lebih lama dari masa simpan akan dihapus.')) {
      return;
    }

    setLoadingFiles(true);
    try {
      console.log('Running manual cleanup for old backups...');
      
      // Get current user ID
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data, error } = await supabase.functions.invoke('cleanup-old-google-drive-backups', {
        body: {
          cleanup_type: 'manual',
          executed_by: user?.id || null
        }
      });

      if (error) throw error;

      if (data?.deletedFiles?.length > 0) {
        // Format deleted files information
        const filesList = data.deletedFiles
          .map((file: any) => {
            const createdDate = new Date(file.createdTime).toLocaleDateString('id-ID', {
              day: '2-digit',
              month: 'short',
              year: 'numeric'
            });
            return `• ${file.name} (${createdDate})`;
          })
          .join('\n');

        toast({
          title: "🗑️ Cleanup Manual Berhasil",
          description: (
            <div className="space-y-2">
              <p className="font-semibold">
                {data.deletedFiles.length} backup lama dihapus (lebih dari {data.retentionDays} hari)
              </p>
              <div className="text-sm text-muted-foreground max-h-32 overflow-y-auto">
                <p className="font-medium mb-1">File yang dihapus:</p>
                <pre className="whitespace-pre-wrap font-mono text-xs">
                  {filesList}
                </pre>
              </div>
            </div>
          ),
          duration: 8000,
        });
        await loadDriveFiles();
      } else {
        toast({
          title: "✓ Cleanup Selesai",
          description: `Tidak ada backup lama yang perlu dihapus (masa simpan: ${data?.retentionDays || settings.retention_days || 7} hari)`,
        });
      }
    } catch (error) {
      console.error('Manual cleanup error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Gagal menjalankan cleanup",
        variant: "destructive",
      });
    } finally {
      setLoadingFiles(false);
    }
  };

  const initiateRestore = (file: GoogleDriveFile) => {
    setSelectedFile(file);
    setShowSupercodeDialog(true);
  };

  const handleSupercodeSuccess = () => {
    setShowRestoreDialog(true);
  };

  const confirmRestore = async () => {
    if (!selectedFile) return;

    setShowRestoreDialog(false);
    setRestoring(true);
    setRestoreProgress("Mengunduh backup dari Google Drive...");
    setRestorePercent(10);

    try {
      // Download file
      const { data: downloadData, error: downloadError } = await supabase.functions.invoke(
        'download-from-google-drive',
        { body: { fileId: selectedFile.id } }
      );

      if (downloadError) throw downloadError;

      const backupData = downloadData.data;
      if (!backupData || !backupData.data) {
        throw new Error('Invalid backup data');
      }

      const { members, customers, credit_applications, installments, payments } = backupData.data;

      // Restore members
      setRestoreProgress("Memulihkan data anggota...");
      setRestorePercent(20);
      for (const member of members || []) {
        await supabase.from('members').upsert(member, { onConflict: 'id' });
      }

      // Restore customers
      setRestoreProgress("Memulihkan data nasabah...");
      setRestorePercent(40);
      for (const customer of customers || []) {
        await supabase.from('customers').upsert(customer, { onConflict: 'id' });
      }

      // Restore applications
      setRestoreProgress("Memulihkan data pengajuan...");
      setRestorePercent(60);
      for (const app of credit_applications || []) {
        await supabase.from('credit_applications').upsert(app, { onConflict: 'id' });
      }

      // Restore installments
      setRestoreProgress("Memulihkan data angsuran...");
      setRestorePercent(80);
      for (const inst of installments || []) {
        await supabase.from('installments').upsert(inst, { onConflict: 'id' });
      }

      // Restore payments
      setRestoreProgress("Memulihkan data pembayaran...");
      setRestorePercent(95);
      for (const payment of payments || []) {
        await supabase.from('payments').upsert(payment, { onConflict: 'id' });
      }

      setRestorePercent(100);
      setRestoreProgress("Restore selesai!");

      toast({
        title: "✓ Restore Berhasil",
        description: "Database berhasil dipulihkan dari Google Drive",
      });

      setTimeout(() => {
        window.location.reload();
      }, 2000);

    } catch (error) {
      console.error('Restore error:', error);
      toast({
        title: "Error",
        description: "Gagal restore dari Google Drive",
        variant: "destructive",
      });
    } finally {
      setRestoring(false);
      setRestoreProgress("");
      setRestorePercent(0);
    }
  };

  return (
    <div className="space-y-6">
      {/* OAuth Token Expired Warning Banner */}
      {settings.auth_mode === 'oauth' && isTokenExpired && (
        <Alert variant="destructive" className="border-amber-500 bg-amber-50 dark:bg-amber-950/30">
          <XCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          <AlertDescription className="flex items-center justify-between">
            <div className="flex-1">
              <p className="font-semibold text-amber-800 dark:text-amber-300">Google Drive Memerlukan Autentikasi Ulang</p>
              <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                Refresh token tidak valid atau hilang. Silakan login ulang dengan Google untuk melanjutkan backup otomatis.
              </p>
              <p className="text-xs text-amber-600 dark:text-amber-500 mt-2">
                ℹ️ Access token akan di-refresh otomatis setiap 30 menit. Anda hanya perlu login ulang jika refresh token benar-benar invalid.
              </p>
            </div>
            <Button
              onClick={handleOAuthLogin}
              disabled={loading || !settings.oauth_client_id || !settings.oauth_client_secret}
              variant="outline"
              size="sm"
              className="ml-4 border-amber-600 hover:bg-amber-100 dark:hover:bg-amber-900 whitespace-nowrap"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Membuka...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Login Ulang
                </>
              )}
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Status Koneksi Google Drive
          </CardTitle>
          <CardDescription>
            Status koneksi dan konfigurasi backup ke Google Drive
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {connectionStatus === 'connected' && (
                <>
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                  <span className="text-sm font-medium">Terhubung</span>
                </>
              )}
              {connectionStatus === 'error' && (
                <>
                  <XCircle className="h-5 w-5 text-destructive" />
                  <span className="text-sm font-medium">Tidak Terhubung</span>
                </>
              )}
              {connectionStatus === 'unknown' && (
                <>
                  <Cloud className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm font-medium">Belum Ditest</span>
                </>
              )}
            </div>
            <Button
              onClick={testConnection}
              disabled={testing || loading || !settings.client_email}
              variant="outline"
              size="sm"
            >
              {testing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : (
                'Test Koneksi'
              )}
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div>
              <p className="text-sm font-medium">Backup Otomatis ke Google Drive</p>
              <p className="text-xs text-muted-foreground">
                Aktifkan untuk menyimpan backup otomatis ke Google Drive
              </p>
            </div>
            <Switch
              checked={settings.is_enabled}
              onCheckedChange={handleToggleEnabled}
              disabled={loading || !settings.client_email}
            />
          </div>

          {/* Backup Schedule Settings */}
          {settings.is_enabled && connectionStatus === 'connected' && (
            <div className="space-y-4 p-4 border rounded-lg bg-accent/30">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Clock className="h-4 w-4" />
                Jadwal Backup Otomatis
              </div>

              <div className="grid gap-4">
                {/* Frequency Selection */}
                <div className="space-y-2">
                  <Label htmlFor="backup_schedule">Frekuensi Backup</Label>
                  <Select 
                    value={settings.backup_schedule} 
                    onValueChange={(value: 'daily' | 'weekly' | 'monthly') => 
                      setSettings({ ...settings, backup_schedule: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih frekuensi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Harian</SelectItem>
                      <SelectItem value="weekly">Mingguan</SelectItem>
                      <SelectItem value="monthly">Bulanan</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Time Selection */}
                <div className="space-y-2">
                  <Label htmlFor="backup_time">Jam Backup</Label>
                  <div className="flex gap-2 items-center">
                    <Select 
                      value={settings.backup_time?.substring(0, 2) || '02'}
                      onValueChange={(hour) => {
                        const minute = settings.backup_time?.substring(3, 5) || '00';
                        setSettings({ ...settings, backup_time: `${hour}:${minute}` });
                      }}
                    >
                      <SelectTrigger className="w-[100px] font-mono">
                        <SelectValue placeholder="Jam" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px]">
                        {Array.from({ length: 24 }, (_, i) => {
                          const hour = i.toString().padStart(2, '0');
                          return (
                            <SelectItem key={hour} value={hour} className="font-mono">
                              {hour}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                    <span className="text-lg font-bold">:</span>
                    <Select 
                      value={settings.backup_time?.substring(3, 5) || '00'}
                      onValueChange={(minute) => {
                        const hour = settings.backup_time?.substring(0, 2) || '02';
                        setSettings({ ...settings, backup_time: `${hour}:${minute}` });
                      }}
                    >
                      <SelectTrigger className="w-[100px] font-mono">
                        <SelectValue placeholder="Menit" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px]">
                        {Array.from({ length: 60 }, (_, i) => {
                          const minute = i.toString().padStart(2, '0');
                          return (
                            <SelectItem key={minute} value={minute} className="font-mono">
                              {minute}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Format 24 jam (00:00 - 23:59) • Waktu sistem server (WIB)
                  </p>
                </div>

                {/* Weekly: Day Selection */}
                {settings.backup_schedule === 'weekly' && (
                  <div className="space-y-2">
                    <Label htmlFor="backup_day">Hari dalam Seminggu</Label>
                    <Select 
                      value={settings.backup_day?.toString()} 
                      onValueChange={(value) => 
                        setSettings({ ...settings, backup_day: parseInt(value) })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih hari" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">Minggu</SelectItem>
                        <SelectItem value="1">Senin</SelectItem>
                        <SelectItem value="2">Selasa</SelectItem>
                        <SelectItem value="3">Rabu</SelectItem>
                        <SelectItem value="4">Kamis</SelectItem>
                        <SelectItem value="5">Jumat</SelectItem>
                        <SelectItem value="6">Sabtu</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Monthly: Date Selection */}
                {settings.backup_schedule === 'monthly' && (
                  <div className="space-y-2">
                    <Label htmlFor="backup_date">Tanggal dalam Bulan</Label>
                    <Input
                      id="backup_date"
                      type="number"
                      min="1"
                      max="31"
                      value={settings.backup_date || 1}
                      onChange={(e) => setSettings({ ...settings, backup_date: parseInt(e.target.value) })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Masukkan tanggal 1-31. Jika bulan tidak memiliki tanggal tersebut, backup akan dilakukan di akhir bulan.
                    </p>
                  </div>
                )}

                {/* Retention Policy Setting */}
                <div className="space-y-2">
                  <Label htmlFor="retention_days">Retensi Backup (Hapus Otomatis)</Label>
                  <Select 
                    value={settings.retention_days?.toString() || '7'}
                    onValueChange={(value) => 
                      setSettings({ ...settings, retention_days: parseInt(value) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih retensi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 Hari (1 Minggu)</SelectItem>
                      <SelectItem value="14">14 Hari (2 Minggu)</SelectItem>
                      <SelectItem value="30">30 Hari (1 Bulan)</SelectItem>
                      <SelectItem value="60">60 Hari (2 Bulan)</SelectItem>
                      <SelectItem value="90">90 Hari (3 Bulan)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Backup lebih dari {settings.retention_days || 7} hari akan otomatis dihapus saat backup baru dibuat
                  </p>
                </div>

                {/* Last Backup Info */}
                {settings.last_backup_at && (
                  <div className="flex items-start gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3 mt-0.5" />
                    <div>
                      <p>Backup terakhir: {format(new Date(settings.last_backup_at), 'dd MMM yyyy HH:mm', { locale: id })}</p>
                      {settings.next_backup_at && (
                        <p>Backup berikutnya: {format(new Date(settings.next_backup_at), 'dd MMM yyyy HH:mm', { locale: id })}</p>
                      )}
                    </div>
                  </div>
                )}

                {/* Backup Status & Actions */}
                <div className="space-y-3">
                  {lastBackupStatus && (
                    <div className="p-3 rounded-lg bg-muted text-sm">
                      {lastBackupStatus}
                    </div>
                  )}
                  
                  {settings.last_backup_at && (
                    <div className="text-sm text-muted-foreground">
                      Backup terakhir: {new Date(settings.last_backup_at).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB
                    </div>
                  )}

                  <div className="grid grid-cols-3 gap-3">
                    <Button
                      onClick={handleManualBackup}
                      disabled={isBackingUp || loading || !settings.id}
                      variant="default"
                      className="col-span-3"
                    >
                      {isBackingUp ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Backup...
                        </>
                      ) : (
                        <>
                          <Cloud className="mr-2 h-4 w-4" />
                          Backup Sekarang
                        </>
                      )}
                    </Button>

                    <Button
                      onClick={handleManualCleanup}
                      disabled={loadingFiles || loading || !settings.id}
                      variant="outline"
                    >
                      {loadingFiles ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Cleanup...
                        </>
                      ) : (
                        <>
                          <Trash2 className="mr-2 h-4 w-4" />
                          Cleanup Manual
                        </>
                      )}
                    </Button>

                    <Button
                      onClick={handleSaveSchedule}
                      disabled={loading || !settings.id}
                    >
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Menyimpan...
                        </>
                      ) : (
                        'Simpan Jadwal'
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Configuration Card */}
      <Card>
        <CardHeader>
          <CardTitle>Konfigurasi Google Drive</CardTitle>
          <CardDescription>
            Pilih metode autentikasi yang Anda inginkan
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Auth Mode Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Metode Autentikasi</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                type="button"
                variant={settings.auth_mode === 'oauth' ? 'default' : 'outline'}
                onClick={() => setSettings({ ...settings, auth_mode: 'oauth' })}
                className="h-auto p-4 flex-col items-start gap-2"
              >
                <div className="font-semibold">OAuth (Disarankan)</div>
                <div className="text-xs opacity-80 text-left">
                  Login dengan akun Google Anda. Cocok untuk Gmail personal.
                </div>
              </Button>
              <Button
                type="button"
                variant={settings.auth_mode === 'service_account' ? 'default' : 'outline'}
                onClick={() => setSettings({ ...settings, auth_mode: 'service_account' })}
                className="h-auto p-4 flex-col items-start gap-2"
              >
                <div className="font-semibold">Service Account</div>
                <div className="text-xs opacity-80 text-left">
                  Menggunakan kredensial JSON. Hanya untuk Workspace.
                </div>
              </Button>
            </div>
          </div>

          {/* OAuth Configuration */}
          {settings.auth_mode === 'oauth' && (
            <div className="space-y-4">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Mode OAuth lebih mudah dan aman. Cukup login sekali dengan akun Google Anda.
                </AlertDescription>
              </Alert>

              {/* Auto-Refresh Info */}
              <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
                <RefreshCw className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <AlertTitle className="text-blue-900 dark:text-blue-100">
                  🔄 Auto-Refresh Token Aktif
                </AlertTitle>
                <AlertDescription className="text-blue-800 dark:text-blue-200 space-y-2 text-sm">
                  <p>
                    Sistem akan otomatis me-refresh access token Google setiap <strong>30 menit</strong> di background.
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-xs ml-2 mt-2">
                    <li>✅ Token selalu fresh tanpa perlu login ulang</li>
                    <li>✅ Backup otomatis tidak akan pernah gagal karena token expired</li>
                    <li>✅ Anda hanya perlu login ulang jika refresh token benar-benar invalid</li>
                  </ul>
                  <p className="text-xs text-blue-700 dark:text-blue-300 mt-3 pt-2 border-t border-blue-200 dark:border-blue-800">
                    💡 <strong>Tip:</strong> Selama Anda melihat status "Terhubung" di bawah, backup akan berjalan otomatis tanpa masalah.
                  </p>
                </AlertDescription>
              </Alert>

              {/* OAuth Client Credentials */}
              <div className="space-y-4 p-4 border rounded-lg bg-muted/30">
                <div className="space-y-2">
                  <Label htmlFor="oauth-client-id">OAuth Client ID</Label>
                  <Input
                    id="oauth-client-id"
                    type="text"
                    placeholder="Masukkan Google OAuth Client ID"
                    value={settings.oauth_client_id || ''}
                    onChange={(e) => setSettings({ ...settings, oauth_client_id: e.target.value })}
                    disabled={loading}
                  />
                  <p className="text-xs text-muted-foreground">
                    Dapatkan dari Google Cloud Console - APIs & Services - Credentials
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="oauth-client-secret">OAuth Client Secret</Label>
                  <Input
                    id="oauth-client-secret"
                    type="password"
                    placeholder="Masukkan Google OAuth Client Secret"
                    value={settings.oauth_client_secret || ''}
                    onChange={(e) => setSettings({ ...settings, oauth_client_secret: e.target.value })}
                    disabled={loading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="authorized-origins">Authorized JavaScript origins</Label>
                  <div className="flex gap-2">
                    <Input
                      id="authorized-origins"
                      value={window.location.origin}
                      readOnly
                      disabled
                      className="font-mono text-xs"
                    />
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.origin);
                        toast({ title: "✓ Disalin", description: "Authorized JavaScript origins disalin ke clipboard" });
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Salin URL ini dan tambahkan ke <strong>Authorized JavaScript origins</strong> di Google Cloud Console
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="redirect-uri">Authorized redirect URIs</Label>
                  <div className="flex gap-2">
                    <Input
                      id="redirect-uri"
                      value={`${window.location.origin}/oauth/callback`}
                      readOnly
                      disabled
                      className="font-mono text-xs"
                    />
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => {
                        navigator.clipboard.writeText(`${window.location.origin}/oauth/callback`);
                        toast({ title: "✓ Disalin", description: "Redirect URI disalin ke clipboard" });
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Salin URL ini dan tambahkan ke <strong>Authorized redirect URIs</strong> di Google Cloud Console
                  </p>
                </div>
              </div>

              {settings.oauth_user_email ? (
                <div className="p-4 border rounded-lg bg-green-50 dark:bg-green-950/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-900 dark:text-green-100">
                        ✓ Terhubung
                      </p>
                      <p className="text-sm text-green-700 dark:text-green-300">
                        {settings.oauth_user_email}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleOAuthLogin}
                      disabled={loading || !settings.oauth_client_id || !settings.oauth_client_secret}
                    >
                      Login Ulang
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  onClick={handleOAuthLogin}
                  disabled={loading || !settings.oauth_client_id || !settings.oauth_client_secret}
                  className="w-full"
                  size="lg"
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Membuka Google...
                    </>
                  ) : (
                    <>
                      <Cloud className="mr-2 h-4 w-4" />
                      Login dengan Google
                    </>
                  )}
                </Button>
              )}

              {/* Folder ID for OAuth */}
              <div className="space-y-2">
                <Label htmlFor="folder_id_oauth">Google Drive Folder ID</Label>
                <div className="flex gap-2">
                  <Input
                    id="folder_id_oauth"
                    placeholder="1AbC2DeF3GhI4JkL5MnO6PqR7StU8VwX"
                    value={settings.folder_id}
                    onChange={(e) => setSettings({ ...settings, folder_id: e.target.value })}
                    disabled={loading}
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => {
                      navigator.clipboard.writeText(settings.folder_id);
                      toast({ title: "✓ Disalin", description: "Folder ID disalin" });
                    }}
                    disabled={!settings.folder_id}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  ID folder dari URL: https://drive.google.com/drive/folders/<strong>FOLDER_ID</strong>
                </p>
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  Gunakan folder di My Drive Anda. Tidak perlu Shared Drive.
                </p>
              </div>
            </div>
          )}

          {/* Service Account Configuration */}
          {settings.auth_mode === 'service_account' && (
            <div className="space-y-4">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Service Account hanya untuk Google Workspace. Memerlukan Shared Drive.
                </AlertDescription>
              </Alert>

              {/* JSON Upload Section */}
              <div className="p-4 border-2 border-dashed rounded-lg bg-muted/30">
                <div className="space-y-2">
                  <Label htmlFor="json_upload" className="text-sm font-semibold">
                    Upload Service Account JSON (Opsional)
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Upload file JSON dari Google Cloud untuk mengisi kredensial secara otomatis
                  </p>
                  <div className="flex items-center gap-2">
                    <Input
                      id="json_upload"
                      type="file"
                      accept=".json"
                      onChange={handleJsonUpload}
                      disabled={loading || uploadingJson}
                      className="cursor-pointer"
                    />
                    {uploadingJson && (
                      <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                    )}
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">
                    Atau masukkan manual
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="client_email">Client Email</Label>
                <div className="flex gap-2">
                  <Input
                    id="client_email"
                    type="email"
                    placeholder="service-account@project-id.iam.gserviceaccount.com"
                    value={settings.client_email}
                    onChange={(e) => setSettings({ ...settings, client_email: e.target.value })}
                    disabled={loading}
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => {
                      navigator.clipboard.writeText(settings.client_email);
                      toast({ title: "✓ Disalin", description: "Email disalin ke clipboard" });
                    }}
                    disabled={!settings.client_email}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Dari field "client_email" di JSON key
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="private_key">Private Key</Label>
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <Textarea
                      id="private_key"
                      placeholder="-----BEGIN PRIVATE KEY-----&#10;...&#10;-----END PRIVATE KEY-----"
                      value={settings.private_key}
                      onChange={(e) => setSettings({ ...settings, private_key: e.target.value })}
                      disabled={loading}
                      rows={showPrivateKey ? 8 : 3}
                      className="font-mono text-xs"
                    />
                    <div className="flex flex-col gap-2">
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => setShowPrivateKey(!showPrivateKey)}
                      >
                        {showPrivateKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => {
                          navigator.clipboard.writeText(settings.private_key);
                          toast({ title: "✓ Disalin", description: "Private key disalin" });
                        }}
                        disabled={!settings.private_key}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Dari field "private_key" di JSON key (termasuk BEGIN dan END marker)
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="folder_id">Google Drive Folder ID (Shared Drive)</Label>
                <div className="flex gap-2">
                  <Input
                    id="folder_id"
                    placeholder="1AbC2DeF3GhI4JkL5MnO6PqR7StU8VwX"
                    value={settings.folder_id}
                    onChange={(e) => setSettings({ ...settings, folder_id: e.target.value })}
                    disabled={loading}
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => {
                      navigator.clipboard.writeText(settings.folder_id);
                      toast({ title: "✓ Disalin", description: "Folder ID disalin" });
                    }}
                    disabled={!settings.folder_id}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  ID folder dari URL: https://drive.google.com/drive/folders/<strong>FOLDER_ID</strong>
                </p>
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  ⚠️ PENTING: Harus folder di Shared Drive, bukan My Drive!
                </p>
              </div>
            </div>
          )}

          <div className="pt-4 space-y-4">
            {!showVerification ? (
              <Button
                type="button"
                onClick={() => {
                  // If settings exist and connected, show verification
                  if (settings.id && connectionStatus === 'connected') {
                    setShowVerification(true);
                  } else {
                    // Otherwise, save directly
                    handleSave();
                  }
                }}
                disabled={loading || !settings.client_email || !settings.private_key || !settings.folder_id}
                className="w-full"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Menyimpan...
                  </>
                ) : (
                  'Simpan Konfigurasi'
                )}
              </Button>
            ) : (
              <>
                <div className="space-y-2 p-4 border rounded-lg bg-muted/30">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Shield className="h-4 w-4 text-primary" />
                    Verifikasi SuperCode
                  </div>
                  <Input
                    type="password"
                    placeholder="Masukkan SuperCode"
                    value={superCode}
                    onChange={(e) => setSuperCode(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Perubahan konfigurasi Google Drive memerlukan verifikasi SuperCode
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowVerification(false);
                      setSuperCode("");
                    }}
                    className="flex-1"
                    disabled={loading}
                  >
                    Kembali
                  </Button>
                  <Button 
                    onClick={handleSave} 
                    disabled={loading || !superCode.trim()}
                    className="flex-1"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Menyimpan...
                      </>
                    ) : (
                      "Simpan Perubahan"
                    )}
                  </Button>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Instructions Card */}
      <Card>
        <CardHeader>
          <CardTitle>Petunjuk Setup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">1. Buat Service Account di Google Cloud</h4>
            <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
              <li>Buka Google Cloud Console</li>
              <li>Pilih atau buat project</li>
              <li>Aktifkan Google Drive API</li>
              <li>Buat Service Account dengan role "Editor" atau "Owner"</li>
              <li>Download JSON credentials file</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-semibold">2. Setup Google Drive Folder</h4>
            <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
              <li>Buat folder baru di Google Drive untuk backup</li>
              <li>Share folder dengan email service account (dari JSON)</li>
              <li>Berikan akses "Editor"</li>
              <li>Copy Folder ID dari URL folder</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-semibold">3. Konfigurasi di Aplikasi</h4>
            <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
              <li>Copy-paste Client Email dari JSON file</li>
              <li>Copy-paste Private Key dari JSON file (lengkap dengan BEGIN/END)</li>
              <li>Paste Folder ID dari Google Drive</li>
              <li>Simpan dan test koneksi</li>
              <li>Aktifkan backup otomatis jika sudah terhubung</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Backup Files List */}
      {connectionStatus === 'connected' && settings.is_enabled && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Backup Files di Google Drive</CardTitle>
                <CardDescription>
                  Daftar file backup yang tersimpan di Google Drive
                </CardDescription>
              </div>
              <Button
                onClick={loadDriveFiles}
                disabled={loadingFiles}
                variant="outline"
                size="sm"
              >
                {loadingFiles ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loadingFiles ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : driveFiles.length === 0 ? (
              <Alert>
                <Cloud className="h-4 w-4" />
                <AlertDescription>
                  Belum ada file backup di Google Drive
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-3">
                {driveFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-sm">{file.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(file.created_at), 'dd MMM yyyy HH:mm', { locale: id })} •{' '}
                        {(file.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="default"
                        onClick={() => initiateRestore(file)}
                        disabled={restoring}
                        title="Restore database dari file ini"
                      >
                        <Upload className="h-4 w-4 mr-1" />
                        Restore
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => downloadFile(file)}
                        disabled={restoring}
                        title="Download file backup"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Restore Progress */}
      {restoring && (
        <Card>
          <CardHeader>
            <CardTitle>Restore Database</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={restorePercent} className="h-2 w-full" />
            <p className="text-sm text-muted-foreground text-center">
              {restoreProgress} ({restorePercent.toFixed(1)}%)
            </p>
          </CardContent>
        </Card>
      )}

      {/* Supercode Verification Dialog */}
      <SupercodeVerificationDialog
        open={showSupercodeDialog}
        onOpenChange={setShowSupercodeDialog}
        onSuccess={handleSupercodeSuccess}
        title="Verifikasi Supercode untuk Restore"
        description="Operasi restore dari Google Drive memerlukan verifikasi supercode. Masukkan supercode untuk melanjutkan."
      />

      {/* Restore Confirmation Dialog */}
      <AlertDialog open={showRestoreDialog} onOpenChange={setShowRestoreDialog}>
        <AlertDialogContent className="max-w-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-amber-600">
              <AlertCircle className="h-5 w-5" />
              Peringatan: Restore dari Google Drive
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4 text-left">
                <p className="font-semibold text-foreground">
                  File Backup: <span className="text-primary">{selectedFile?.name}</span>
                </p>
                
                <Alert variant="destructive" className="border-amber-500 bg-amber-50 dark:bg-amber-950/30">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <AlertTitle className="text-amber-800 dark:text-amber-300">Penting! Pahami Risiko Restore</AlertTitle>
                  <AlertDescription className="text-amber-700 dark:text-amber-400 space-y-2 text-sm">
                    <p className="font-semibold">Restore menggunakan metode MERGE, bukan penggantian total:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li><strong>Data yang ID-nya SAMA:</strong> Akan DITIMPA dengan versi dari backup (perubahan terbaru HILANG)</li>
                      <li><strong>Data yang ID-nya BERBEDA:</strong> Akan TETAP ADA (tidak terhapus)</li>
                      <li><strong>Data baru di backup:</strong> Akan DITAMBAHKAN ke database</li>
                    </ul>
                  </AlertDescription>
                </Alert>

                <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 space-y-2">
                  <p className="font-semibold text-destructive">⚠️ Risiko yang Mungkin Terjadi:</p>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>❌ Pembayaran yang dilakukan setelah tanggal backup akan HILANG</li>
                    <li>❌ Perubahan data nasabah/kredit terbaru akan KEMBALI ke versi lama</li>
                    <li>❌ Status kredit yang sudah berubah akan KEMBALI ke status sebelumnya</li>
                    <li>❌ Angsuran yang sudah dibayar bisa kembali ke status belum bayar</li>
                  </ul>
                </div>

                <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                  <p className="font-semibold text-sm">✅ Rekomendasi Penggunaan:</p>
                  <ul className="text-xs space-y-1 text-muted-foreground">
                    <li>• Restore hanya untuk recovery data yang hilang atau rusak</li>
                    <li>• JANGAN gunakan restore untuk "membatalkan" transaksi</li>
                    <li>• Pastikan backup sudah benar sebelum melanjutkan</li>
                    <li>• Pertimbangkan membuat backup database saat ini terlebih dahulu</li>
                  </ul>
                </div>

                <p className="text-sm font-semibold text-center text-destructive">
                  Apakah Anda yakin ingin melanjutkan restore?
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={restoring}>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmRestore}
              disabled={restoring}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {restoring ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restoring...
                </>
              ) : (
                'Ya, Saya Mengerti Risikonya - Restore Sekarang'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Cleanup History Log */}
      {settings.is_enabled && <CleanupHistoryLog />}
    </div>
  );
};
