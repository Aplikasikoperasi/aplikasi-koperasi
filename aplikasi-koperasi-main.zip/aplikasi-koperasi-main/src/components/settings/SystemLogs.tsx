import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { Search, Filter, ChevronLeft, ChevronRight } from "lucide-react";

interface SystemLog {
  id: string;
  user_name: string;
  category: string;
  action: string;
  description: string;
  metadata: any;
  created_at: string;
}

const categoryLabels: Record<string, string> = {
  member_management: "Manajemen Anggota",
  customer_management: "Manajemen Nasabah",
  credit_application: "Aplikasi Kredit",
  payment: "Pembayaran",
  blocking: "Pemblokiran",
  security: "Keamanan",
  system_error: "Error Sistem"
};

const categoryColors: Record<string, string> = {
  member_management: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  customer_management: "bg-green-500/10 text-green-500 border-green-500/20",
  credit_application: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  payment: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  blocking: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  security: "bg-red-500/10 text-red-500 border-red-500/20",
  system_error: "bg-destructive/10 text-destructive border-destructive/20"
};

export function SystemLogs() {
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<SystemLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const itemsPerPage = 50;

  useEffect(() => {
    loadLogs();
  }, [currentPage, categoryFilter]);

  useEffect(() => {
    filterLogs();
  }, [searchQuery, logs]);

  const loadLogs = async () => {
    try {
      setLoading(true);
      
      // Build query based on category filter
      let query = supabase
        .from("system_logs")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false });
      
      if (categoryFilter !== "all") {
        query = query.eq("category", categoryFilter as any);
      }
      
      // Apply pagination
      const from = (currentPage - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;

      if (error) throw error;
      setLogs(data || []);
      setTotalCount(count || 0);
    } catch (error) {
      console.error("Error loading logs:", error);
    } finally {
      setLoading(false);
    }
  };

  const filterLogs = () => {
    let filtered = [...logs];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(log => 
        log.user_name.toLowerCase().includes(query) ||
        log.action.toLowerCase().includes(query) ||
        log.description.toLowerCase().includes(query)
      );
    }

    setFilteredLogs(filtered);
  };

  const totalPages = Math.ceil(totalCount / itemsPerPage);
  
  const handleCategoryChange = (value: string) => {
    setCategoryFilter(value);
    setCurrentPage(1); // Reset to first page when filter changes
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari log..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="w-full sm:w-[200px]">
          <Select value={categoryFilter} onValueChange={handleCategoryChange}>
            <SelectTrigger>
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Semua Kategori" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Kategori</SelectItem>
              {Object.entries(categoryLabels).map(([key, label]) => (
                <SelectItem key={key} value={key}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <ScrollArea className="h-[600px]">
          {loading ? (
            <div className="p-8 text-center text-muted-foreground">
              Memuat log sistem...
            </div>
          ) : filteredLogs.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              Tidak ada log yang ditemukan
            </div>
          ) : (
            <div className="divide-y">
              {filteredLogs.map((log) => (
                <div key={log.id} className="p-4 hover:bg-accent/50 transition-colors">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className={categoryColors[log.category]}>
                          {categoryLabels[log.category]}
                        </Badge>
                        <span className="text-sm font-medium truncate">
                          {log.action}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {log.description}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="font-medium">{log.user_name}</span>
                        <span>•</span>
                        <span>
                          {format(new Date(log.created_at), "dd MMMM yyyy 'pukul' HH:mm:ss", { 
                            locale: localeId 
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                  {log.metadata && Object.keys(log.metadata).length > 0 && (
                    <details className="mt-2">
                      <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
                        Detail Tambahan
                      </summary>
                      <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-x-auto">
                        {JSON.stringify(log.metadata, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </Card>

      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Log sistem otomatis terhapus setelah 30 hari
        </p>
        
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground">
            Halaman {currentPage} dari {totalPages} ({totalCount} total log)
          </p>
          <div className="flex gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1 || loading}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages || loading}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
