import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { Upload, Trash2, GripVertical, Image, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
interface Banner {
  id: string;
  image_url: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
}
export function BannerSettings() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const fetchBanners = async () => {
    const {
      data,
      error
    } = await supabase.from('banners').select('*').order('display_order', {
      ascending: true
    });
    if (error) {
      toast.error('Gagal memuat banner');
      return;
    }
    setBanners(data || []);
    setIsLoading(false);
  };
  useEffect(() => {
    fetchBanners();
  }, []);
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('File harus berupa gambar');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Ukuran file maksimal 5MB');
      return;
    }
    setIsUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

      // Upload to storage
      const {
        error: uploadError
      } = await supabase.storage.from('banners').upload(fileName, file);
      if (uploadError) throw uploadError;

      // Get public URL
      const {
        data: {
          publicUrl
        }
      } = supabase.storage.from('banners').getPublicUrl(fileName);

      // Get max display_order
      const maxOrder = banners.length > 0 ? Math.max(...banners.map(b => b.display_order)) : 0;

      // Save to database
      const {
        error: dbError
      } = await supabase.from('banners').insert({
        image_url: publicUrl,
        display_order: maxOrder + 1,
        is_active: true
      });
      if (dbError) throw dbError;
      toast.success('Banner berhasil diupload');
      fetchBanners();
    } catch (error: any) {
      toast.error(error.message || 'Gagal mengupload banner');
    } finally {
      setIsUploading(false);
      // Reset input
      e.target.value = '';
    }
  };
  const handleToggleActive = async (id: string, currentValue: boolean) => {
    const {
      error
    } = await supabase.from('banners').update({
      is_active: !currentValue
    }).eq('id', id);
    if (error) {
      toast.error('Gagal mengubah status banner');
      return;
    }
    setBanners(prev => prev.map(b => b.id === id ? {
      ...b,
      is_active: !currentValue
    } : b));
    toast.success(`Banner ${!currentValue ? 'diaktifkan' : 'dinonaktifkan'}`);
  };
  const handleDelete = async (banner: Banner) => {
    if (!confirm('Hapus banner ini?')) return;
    try {
      // Extract filename from URL
      const url = new URL(banner.image_url);
      const pathParts = url.pathname.split('/');
      const fileName = pathParts[pathParts.length - 1];

      // Delete from storage
      await supabase.storage.from('banners').remove([fileName]);

      // Delete from database
      const {
        error
      } = await supabase.from('banners').delete().eq('id', banner.id);
      if (error) throw error;
      setBanners(prev => prev.filter(b => b.id !== banner.id));
      toast.success('Banner berhasil dihapus');
    } catch (error: any) {
      toast.error('Gagal menghapus banner');
    }
  };
  const handleReorder = async (bannerId: string, direction: 'up' | 'down') => {
    const currentIndex = banners.findIndex(b => b.id === bannerId);
    if (currentIndex === -1) return;
    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (newIndex < 0 || newIndex >= banners.length) return;
    const newBanners = [...banners];
    const [movedBanner] = newBanners.splice(currentIndex, 1);
    newBanners.splice(newIndex, 0, movedBanner);

    // Update display_order for all banners
    const updates = newBanners.map((banner, index) => ({
      id: banner.id,
      display_order: index + 1
    }));

    // Update in database
    for (const update of updates) {
      await supabase.from('banners').update({
        display_order: update.display_order
      }).eq('id', update.id);
    }
    setBanners(newBanners.map((b, i) => ({
      ...b,
      display_order: i + 1
    })));
    toast.success('Urutan banner diperbarui');
  };
  if (isLoading) {
    return <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="w-5 h-5" />
            Banner Homepage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        </CardContent>
      </Card>;
  }
  return <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Image className="w-5 h-5" />
          Banner Homepage
        </CardTitle>
        <CardDescription>
          Kelola banner slideshow yang tampil di halaman utama. Banner akan berganti otomatis setiap 5 detik.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Upload Section */}
        <div className="space-y-2">
          <Label>Upload Banner Baru</Label>
          <div className="flex items-center gap-3">
            <Input type="file" accept="image/*" onChange={handleFileUpload} disabled={isUploading} className="flex-1" />
            {isUploading && <Loader2 className="w-5 h-5 animate-spin text-primary" />}
          </div>
          <p className="text-xs text-muted-foreground">
            Format: JPG, PNG, WebP. Maksimal 5MB. Rekomendasi rasio 3:1 atau 21:9.
          </p>
        </div>

        {/* Banner List */}
        <div className="space-y-3">
          <Label>Daftar Banner ({banners.length})</Label>
          
          {banners.length === 0 ? <div className="text-center py-8 text-muted-foreground border border-dashed rounded-lg">
              <Image className="w-10 h-10 mx-auto mb-2 opacity-50" />
              <p>Belum ada banner</p>
              <p className="text-sm">Upload banner pertama Anda</p>
            </div> : <div className="space-y-3">
              {banners.map((banner, index) => (
                <div 
                  key={banner.id} 
                  className={cn(
                    "flex flex-col sm:flex-row sm:items-center gap-3 p-3 border rounded-lg transition-all",
                    !banner.is_active && "opacity-50 bg-muted/30"
                  )}
                >
                  {/* Left: Reorder + Thumbnail + Order Number */}
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {/* Reorder Buttons */}
                    <div className="flex flex-col gap-0.5 shrink-0">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-7 w-7 hover:bg-primary/10" 
                        onClick={() => handleReorder(banner.id, 'up')} 
                        disabled={index === 0}
                      >
                        <GripVertical className="w-4 h-4 rotate-90" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-7 w-7 hover:bg-primary/10" 
                        onClick={() => handleReorder(banner.id, 'down')} 
                        disabled={index === banners.length - 1}
                      >
                        <GripVertical className="w-4 h-4 -rotate-90" />
                      </Button>
                    </div>

                    {/* Thumbnail */}
                    <img 
                      src={banner.image_url} 
                      alt={`Banner ${index + 1}`} 
                      className="max-w-32 sm:max-w-48 h-auto max-h-20 sm:max-h-28 object-contain rounded-md border bg-muted/30 shrink-0" 
                    />

                    {/* Order Number Badge */}
                    <span className="text-sm font-medium text-muted-foreground hidden sm:inline">
                      #{index + 1}
                    </span>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 pl-10 sm:pl-0">
                    {/* Active Toggle */}
                    <div className="flex items-center gap-2">
                      <Switch 
                        checked={banner.is_active} 
                        onCheckedChange={() => handleToggleActive(banner.id, banner.is_active)} 
                      />
                      <Label className="text-xs text-muted-foreground cursor-pointer select-none">
                        {banner.is_active ? 'Aktif' : 'Nonaktif'}
                      </Label>
                    </div>

                    {/* Delete Button */}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0" 
                      onClick={() => handleDelete(banner)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>}
        </div>
      </CardContent>
    </Card>;
}