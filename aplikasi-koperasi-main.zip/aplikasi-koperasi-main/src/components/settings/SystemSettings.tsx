import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2 } from "lucide-react";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface CustomRate {
  tenor: number;
  rate: number;
}

export const SystemSettings = ({ userId }: { userId: string }) => {
  const [interestType, setInterestType] = useState<"flat" | "tiered" | "custom">("flat");
  const [flatRate, setFlatRate] = useState(4.0);
  const [maxTenor, setMaxTenor] = useState(24);
  const [penaltyRate, setPenaltyRate] = useState(2.0);
  const [customRates, setCustomRates] = useState<CustomRate[]>([]);
  const [firstInstallmentType, setFirstInstallmentType] = useState<"paid_upfront" | "next_month">("next_month");
  const [adminFeeEnabled, setAdminFeeEnabled] = useState(false);
  const [adminFeeAmount, setAdminFeeAmount] = useState(0);
  const [adminFeeMinimum, setAdminFeeMinimum] = useState(0);
  
  const [badgeDiscountEnabled, setBadgeDiscountEnabled] = useState(false);
  const [platinumDiscount, setPlatinumDiscount] = useState(0);
  const [diamondDiscount, setDiamondDiscount] = useState(0);
  const [goldDiscount, setGoldDiscount] = useState(0);
  const [autoBlockThreshold, setAutoBlockThreshold] = useState(3.7);
  
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();

  useEffect(() => {
    loadSettings();
  }, [userId]);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from("app_settings")
        .select("*")
        .eq("user_id", userId)
        .single();

      if (error && error.code !== "PGRST116") throw error;

      if (data) {
        const settings = data as any;
        setInterestType(settings.interest_type || "flat");
        setFlatRate(settings.flat_interest_rate || 4.0);
        setMaxTenor(settings.max_tenor_months || 24);
        setPenaltyRate(settings.penalty_rate_per_day || 2.0);
        setCustomRates(settings.custom_rates || []);
        setFirstInstallmentType(settings.first_installment_type || "next_month");
        setAdminFeeEnabled(settings.admin_fee_enabled || false);
        setAdminFeeAmount(settings.admin_fee_amount || 0);
        setAdminFeeMinimum(settings.admin_fee_minimum || 0);
        
        setBadgeDiscountEnabled(settings.badge_discount_enabled || false);
        setPlatinumDiscount(settings.platinum_discount || 0);
        setDiamondDiscount(settings.diamond_discount || 0);
        setGoldDiscount(settings.gold_discount || 0);
        setAutoBlockThreshold(settings.auto_block_threshold || 3.7);
        
      }
    } catch (error: any) {
      toast({
        title: "Gagal memuat pengaturan",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    const verified = await requireSuperCode("menyimpan pengaturan sistem");
    if (!verified) return;
    
    setLoading(true);
    try {
      const { data: existing } = await supabase
        .from("app_settings")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      const settingsData = {
        user_id: userId,
        interest_type: interestType,
        flat_interest_rate: flatRate,
        max_tenor_months: maxTenor,
        penalty_rate_per_day: penaltyRate,
        custom_rates: customRates as any,
        first_installment_type: firstInstallmentType,
        admin_fee_enabled: adminFeeEnabled,
        admin_fee_amount: adminFeeAmount,
        admin_fee_minimum: adminFeeMinimum,
        
        badge_discount_enabled: badgeDiscountEnabled,
        platinum_discount: platinumDiscount,
        diamond_discount: diamondDiscount,
        gold_discount: goldDiscount,
        auto_block_threshold: autoBlockThreshold,
        
      };

      if (existing) {
        const { error } = await supabase
          .from("app_settings")
          .update(settingsData)
          .eq("user_id", userId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("app_settings")
          .insert(settingsData);
        if (error) throw error;
      }

      toast({
        title: "Pengaturan berhasil disimpan",
        description: "Pengaturan sistem telah diperbarui"
      });
    } catch (error: any) {
      toast({
        title: "Gagal menyimpan pengaturan",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addCustomRate = () => {
    setCustomRates([...customRates, { tenor: 1, rate: 4.0 }]);
  };

  const removeCustomRate = (index: number) => {
    setCustomRates(customRates.filter((_, i) => i !== index));
  };

  const updateCustomRate = (index: number, field: "tenor" | "rate", value: number) => {
    const updated = [...customRates];
    updated[index][field] = value;
    setCustomRates(updated);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Pengaturan Sistem Bunga</CardTitle>
          <CardDescription>
            Atur tipe bunga dan persentase yang akan digunakan untuk perhitungan kredit
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>Tipe Sistem Bunga</Label>
            <RadioGroup value={interestType} onValueChange={(v: any) => setInterestType(v)}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="flat" id="flat" />
                <Label htmlFor="flat" className="font-normal cursor-pointer">
                  Flat - Bunga tetap untuk semua tenor
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="tiered" id="tiered" />
                <Label htmlFor="tiered" className="font-normal cursor-pointer">
                  Berjenjang - Bunga berdasarkan tenor (1 bln: 10%, 2 bln: 7%, 3 bln: 6%, 4-5 bln: 5%, &gt;6 bln: 4%)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="custom" id="custom" />
                <Label htmlFor="custom" className="font-normal cursor-pointer">
                  Custom - Atur bunga per tenor secara manual
                </Label>
              </div>
            </RadioGroup>
          </div>

          {interestType === "flat" && (
            <div className="space-y-2">
              <Label htmlFor="flatRate">Persentase Bunga Flat (%)</Label>
              <Input
                id="flatRate"
                type="number"
                step="0.1"
                value={flatRate}
                onChange={(e) => setFlatRate(parseFloat(e.target.value) || 0)}
              />
            </div>
          )}

          {interestType === "custom" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Bunga Custom per Tenor</Label>
                <Button type="button" size="sm" onClick={addCustomRate}>
                  <Plus className="h-4 w-4 mr-2" />
                  Tambah
                </Button>
              </div>
              {customRates.map((rate, index) => (
                <div key={index} className="flex gap-4 items-center">
                  <div className="flex-1">
                    <Label>Tenor (Bulan)</Label>
                    <Input
                      type="number"
                      value={rate.tenor}
                      onChange={(e) => updateCustomRate(index, "tenor", parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div className="flex-1">
                    <Label>Bunga (%)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={rate.rate}
                      onChange={(e) => updateCustomRate(index, "rate", parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    onClick={() => removeCustomRate(index)}
                    className="mt-6"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pengaturan Tenor & Denda</CardTitle>
          <CardDescription>
            Atur batas maksimal tenor dan persentase denda keterlambatan
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="maxTenor">Tenor Maksimal (Bulan)</Label>
            <Input
              id="maxTenor"
              type="number"
              value={maxTenor}
              onChange={(e) => setMaxTenor(parseInt(e.target.value) || 0)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="penaltyRate">Denda Keterlambatan per Hari (%)</Label>
            <Input
              id="penaltyRate"
              type="number"
              step="0.1"
              value={penaltyRate}
              onChange={(e) => setPenaltyRate(parseFloat(e.target.value) || 0)}
            />
            <p className="text-sm text-muted-foreground">
              Rumus: Total Angsuran × Persentase Denda × Hari Keterlambatan
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pengaturan Auto-Blocking</CardTitle>
          <CardDescription>
            Atur ambang batas skor kredit untuk pemblokiran otomatis nasabah
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="autoBlockThreshold">Batas Skor Kredit Minimum</Label>
            <Input
              id="autoBlockThreshold"
              type="number"
              step="0.1"
              min="1"
              max="5"
              value={autoBlockThreshold}
              onChange={(e) => setAutoBlockThreshold(parseFloat(e.target.value) || 3.7)}
            />
            <p className="text-sm text-muted-foreground">
              Nasabah dengan skor kredit ≤ nilai ini akan diblokir otomatis oleh sistem (rentang: 1.0 - 5.0)
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pengaturan Angsuran Pertama</CardTitle>
          <CardDescription>
            Atur kapan angsuran pertama harus dibayar
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <RadioGroup value={firstInstallmentType} onValueChange={(v: any) => setFirstInstallmentType(v)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="paid_upfront" id="paid_upfront" />
              <Label htmlFor="paid_upfront" className="font-normal cursor-pointer">
                Angsuran Pertama di Awal - Angsuran pertama dibayar saat pencairan dan tercatat otomatis
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="next_month" id="next_month" />
              <Label htmlFor="next_month" className="font-normal cursor-pointer">
                Angsuran Pertama di Bulan Berikutnya - Angsuran pertama jatuh tempo 1 bulan setelah disetujui
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pengaturan Biaya Admin</CardTitle>
          <CardDescription>
            Atur biaya administrasi yang dipotong saat pencairan dana
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <RadioGroup 
            value={adminFeeEnabled ? "enabled" : "disabled"} 
            onValueChange={(v) => setAdminFeeEnabled(v === "enabled")}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="disabled" id="admin_disabled" />
              <Label htmlFor="admin_disabled" className="font-normal cursor-pointer">
                None Admin - Tidak ada biaya admin
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="enabled" id="admin_enabled" />
              <Label htmlFor="admin_enabled" className="font-normal cursor-pointer">
                Admin Aktif - Dana pencairan akan dipotong biaya admin
              </Label>
            </div>
          </RadioGroup>

          {adminFeeEnabled && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="adminFee">Biaya Admin (%)</Label>
                <Input
                  id="adminFee"
                  type="number"
                  value={adminFeeAmount}
                  onChange={(e) => setAdminFeeAmount(parseFloat(e.target.value) || 0)}
                  placeholder="Contoh: 2.5"
                  min="0"
                  max="100"
                  step="0.1"
                />
                <p className="text-sm text-muted-foreground">
                  Biaya admin dalam persentase (%). Rumus: Dana Diterima = Dana Diajukan - (Dana Diajukan × %)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="adminFeeMin">Biaya Admin Minimum (Rp)</Label>
                <Input
                  id="adminFeeMin"
                  type="text"
                  value={adminFeeMinimum ? adminFeeMinimum.toLocaleString('id-ID') : ''}
                  onChange={(e) => {
                    const numericValue = parseInt(e.target.value.replace(/\D/g, '')) || 0;
                    setAdminFeeMinimum(numericValue);
                  }}
                  placeholder="Contoh: 50.000"
                />
                <p className="text-sm text-muted-foreground">
                  Jika hasil perhitungan persentase lebih kecil dari nilai ini, maka biaya admin akan menggunakan nilai minimum.
                </p>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-md">
                <p className="text-sm text-amber-900 dark:text-amber-100">
                  <strong>Contoh:</strong> Pinjaman Rp 2.000.000 dengan biaya admin 1% = Rp 20.000. 
                  Jika minimum Rp 50.000, maka biaya admin yang ditagih adalah Rp 50.000.
                </p>
              </div>
            </div>
          )}
        </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Diskon Bunga Badge Premium</CardTitle>
              <CardDescription>
                Berikan diskon bunga khusus untuk nasabah dengan badge Gold, Diamond, dan Platinum
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Aktifkan Diskon Badge</Label>
                  <p className="text-sm text-muted-foreground">
                    Diskon otomatis diterapkan saat nasabah premium mengajukan kredit
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Button
                    type="button"
                    variant={badgeDiscountEnabled ? "default" : "outline"}
                    size="sm"
                    onClick={() => setBadgeDiscountEnabled(!badgeDiscountEnabled)}
                  >
                    {badgeDiscountEnabled ? "Aktif" : "Nonaktif"}
                  </Button>
                </div>
              </div>

              {badgeDiscountEnabled && (
                <div className="space-y-4 pt-4 border-t">
                  <div className="space-y-2">
                    <Label htmlFor="platinum-discount" className="flex items-center gap-2">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-gradient-to-r from-purple-500 to-purple-700 text-white">
                        💎 Platinum Elite
                      </span>
                      Diskon Bunga (%)
                    </Label>
                    <Input
                      id="platinum-discount"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={platinumDiscount}
                      onChange={(e) => setPlatinumDiscount(parseFloat(e.target.value) || 0)}
                      placeholder="Contoh: 0.5"
                    />
                    <p className="text-xs text-muted-foreground">
                      Bunga dikurangi {platinumDiscount}% untuk nasabah Platinum Elite
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="diamond-discount" className="flex items-center gap-2">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
                        💠 Diamond Premier
                      </span>
                      Diskon Bunga (%)
                    </Label>
                    <Input
                      id="diamond-discount"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={diamondDiscount}
                      onChange={(e) => setDiamondDiscount(parseFloat(e.target.value) || 0)}
                      placeholder="Contoh: 0.3"
                    />
                    <p className="text-xs text-muted-foreground">
                      Bunga dikurangi {diamondDiscount}% untuk nasabah Diamond Premier
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gold-discount" className="flex items-center gap-2">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-gradient-to-r from-yellow-500 to-amber-600 text-white">
                        ⭐ Gold Member
                      </span>
                      Diskon Bunga (%)
                    </Label>
                    <Input
                      id="gold-discount"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={goldDiscount}
                      onChange={(e) => setGoldDiscount(parseFloat(e.target.value) || 0)}
                      placeholder="Contoh: 0.2"
                    />
                    <p className="text-xs text-muted-foreground">
                      Bunga dikurangi {goldDiscount}% untuk nasabah Gold Member
                    </p>
                  </div>

                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 rounded-md">
                    <p className="text-sm text-blue-900 dark:text-blue-100">
                      <strong>Contoh:</strong> Bunga normal 4% dengan diskon Gold 0.2% → Bunga final 3.8%
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>


      <Button onClick={handleSave} disabled={loading} className="w-full">
        {loading ? "Menyimpan..." : "Simpan Pengaturan"}
      </Button>
    </div>
  );
};
