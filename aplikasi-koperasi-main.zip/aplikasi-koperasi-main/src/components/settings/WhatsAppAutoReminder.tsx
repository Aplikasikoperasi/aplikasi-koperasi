import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Clock, AlertCircle, CheckCircle, Loader2, Send } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useSuperCode } from "@/contexts/SuperCodeContext";

export function WhatsAppAutoReminder() {
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [settings, setSettings] = useState({
    is_enabled: false,
    overdue_reminder_enabled: true,
    due_date_reminder_enabled: true,
    reminder_time: "08:00",
    last_run_at: null as string | null,
    next_run_at: null as string | null,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from("whatsapp_auto_reminder_settings")
        .select("*")
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSettings({
          is_enabled: data.is_enabled,
          overdue_reminder_enabled: data.overdue_reminder_enabled,
          due_date_reminder_enabled: data.due_date_reminder_enabled,
          reminder_time: data.reminder_time?.substring(0, 5) || "08:00",
          last_run_at: data.last_run_at,
          next_run_at: data.next_run_at,
        });
      }
    } catch (error: any) {
      console.error("Error loading settings:", error);
      toast({
        title: "Error",
        description: "Gagal memuat pengaturan",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    const verified = await requireSuperCode("menyimpan pengaturan auto reminder");
    if (!verified) return;
    
    setSaving(true);
    try {
      const { data: existingData } = await supabase
        .from("whatsapp_auto_reminder_settings")
        .select("id")
        .maybeSingle();

      if (existingData) {
        const { error } = await supabase
          .from("whatsapp_auto_reminder_settings")
          .update({
            is_enabled: settings.is_enabled,
            overdue_reminder_enabled: settings.overdue_reminder_enabled,
            due_date_reminder_enabled: settings.due_date_reminder_enabled,
            reminder_time: settings.reminder_time + ":00",
          })
          .eq("id", existingData.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("whatsapp_auto_reminder_settings")
          .insert({
            is_enabled: settings.is_enabled,
            overdue_reminder_enabled: settings.overdue_reminder_enabled,
            due_date_reminder_enabled: settings.due_date_reminder_enabled,
            reminder_time: settings.reminder_time + ":00",
          });

        if (error) throw error;
      }

      toast({
        title: "Berhasil",
        description: "Pengaturan auto-reminder berhasil disimpan. Cron job akan aktif dalam beberapa menit.",
      });

      await loadSettings();
    } catch (error: any) {
      console.error("Error saving settings:", error);
      toast({
        title: "Error",
        description: error.message || "Gagal menyimpan pengaturan",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const testReminders = async () => {
    setTesting(true);
    try {
      const { data, error } = await supabase.functions.invoke('run-auto-reminders');

      if (error) throw error;

      toast({
        title: "Test Berhasil",
        description: `Reminder telah dikirim. Overdue: ${data?.results?.overdue?.sent || 0}, Jatuh Tempo: ${data?.results?.dueDate?.sent || 0}`,
      });

      await loadSettings();
    } catch (error: any) {
      console.error("Error testing reminders:", error);
      toast({
        title: "Error",
        description: error.message || "Gagal mengirim test reminder",
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Auto-Reminder WhatsApp
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Auto-Reminder WhatsApp Terjadwal
        </CardTitle>
        <CardDescription>
          Kirim pengingat otomatis setiap hari untuk tunggakan dan jatuh tempo
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Status Alert */}
        <Alert>
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-sm">
            <strong className="text-green-600">Cron Job Aktif!</strong> Sistem akan mengirim pengingat otomatis setiap hari pukul {settings.reminder_time} WIB.
          </AlertDescription>
        </Alert>

        {/* Enable/Disable */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="enable-auto-reminder">Aktifkan Auto-Reminder</Label>
            <p className="text-sm text-muted-foreground">
              Kirim pengingat WhatsApp secara otomatis
            </p>
          </div>
          <Switch
            id="enable-auto-reminder"
            checked={settings.is_enabled}
            onCheckedChange={(checked) =>
              setSettings({ ...settings, is_enabled: checked })
            }
          />
        </div>

        {/* Reminder Time */}
        <div className="space-y-2">
          <Label htmlFor="reminder-time">Waktu Pengiriman</Label>
          <Input
            id="reminder-time"
            type="time"
            value={settings.reminder_time}
            onChange={(e) =>
              setSettings({ ...settings, reminder_time: e.target.value })
            }
            disabled={!settings.is_enabled}
          />
          <p className="text-xs text-muted-foreground">
            Pengingat akan dikirim setiap hari pada waktu yang ditentukan
          </p>
        </div>

        {/* Reminder Types */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="overdue-reminder">Pengingat Tunggakan</Label>
              <p className="text-sm text-muted-foreground">
                Kirim untuk angsuran yang sudah lewat jatuh tempo
              </p>
            </div>
            <Switch
              id="overdue-reminder"
              checked={settings.overdue_reminder_enabled}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, overdue_reminder_enabled: checked })
              }
              disabled={!settings.is_enabled}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="due-date-reminder">Pengingat Jatuh Tempo</Label>
              <p className="text-sm text-muted-foreground">
                Kirim H-3 dan hari H jatuh tempo
              </p>
            </div>
            <Switch
              id="due-date-reminder"
              checked={settings.due_date_reminder_enabled}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, due_date_reminder_enabled: checked })
              }
              disabled={!settings.is_enabled}
            />
          </div>
        </div>

        {/* Status */}
        {settings.last_run_at && (
          <div className="space-y-2 p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Terakhir Dijalankan:</span>
              <Badge variant="outline">
                {new Date(settings.last_run_at).toLocaleString("id-ID")}
              </Badge>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={saveSettings}
            disabled={saving || testing}
            className="w-full"
          >
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Menyimpan...
              </>
            ) : (
              "Simpan Pengaturan"
            )}
          </Button>

          <Button
            onClick={testReminders}
            disabled={saving || testing || !settings.is_enabled}
            variant="outline"
            className="w-full"
          >
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Mengirim...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Test Kirim
              </>
            )}
          </Button>
        </div>

        {/* Warning Alert */}
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-xs">
            <strong>Catatan:</strong> Auto-reminder akan mengirim pesan WhatsApp secara otomatis sesuai jadwal. 
            Pastikan WhatsApp API sudah dikonfigurasi dengan benar di pengaturan WhatsApp.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
