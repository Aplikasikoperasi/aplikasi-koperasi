import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, DollarSign, TrendingUp, Gift, Users, Calculator } from "lucide-react";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface IncentiveSettings {
  id: string;
  // Sales settings
  is_enabled: boolean;
  credit_application_enabled: boolean;
  credit_application_amount: number;
  credit_application_type: "fixed" | "percentage";
  installment_payment_enabled: boolean;
  installment_payment_amount: number;
  installment_payment_type: "fixed" | "percentage";
  holiday_enabled: boolean;
  holiday_amount: number;
  holiday_type: "fixed" | "percentage";
  year_end_bonus_withdrawal_date: number;
  // Kasir settings
  kasir_enabled: boolean;
  kasir_payment_enabled: boolean;
  kasir_payment_amount: number;
  kasir_payment_type: "fixed" | "percentage";
  kasir_holiday_enabled: boolean;
  kasir_holiday_amount: number;
  kasir_holiday_type: "fixed" | "percentage";
  kasir_year_end_bonus_withdrawal_date: number;
}

export function IncentiveSettings() {
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [settings, setSettings] = useState<IncentiveSettings>({
    id: "",
    // Sales settings
    is_enabled: false,
    credit_application_enabled: false,
    credit_application_amount: 0,
    credit_application_type: "fixed",
    installment_payment_enabled: false,
    installment_payment_amount: 0,
    installment_payment_type: "fixed",
    holiday_enabled: false,
    holiday_amount: 0,
    holiday_type: "fixed",
    year_end_bonus_withdrawal_date: 7,
    // Kasir settings
    kasir_enabled: false,
    kasir_payment_enabled: false,
    kasir_payment_amount: 0,
    kasir_payment_type: "fixed",
    kasir_holiday_enabled: false,
    kasir_holiday_amount: 0,
    kasir_holiday_type: "fixed",
    kasir_year_end_bonus_withdrawal_date: 7,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await (supabase as any)
        .from("incentive_settings")
        .select("*")
        .single();

      if (error && error.code !== "PGRST116") {
        throw error;
      }

      if (data) {
        setSettings({
          id: data.id,
          // Sales settings
          is_enabled: data.is_enabled,
          credit_application_enabled: data.credit_application_enabled,
          credit_application_amount: Number(data.credit_application_amount || 0),
          credit_application_type: data.credit_application_type || "fixed",
          installment_payment_enabled: data.installment_payment_enabled,
          installment_payment_amount: Number(data.installment_payment_amount || 0),
          installment_payment_type: data.installment_payment_type || "fixed",
          holiday_enabled: data.holiday_enabled,
          holiday_amount: Number(data.holiday_amount || 0),
          holiday_type: data.holiday_type || "fixed",
          year_end_bonus_withdrawal_date: data.year_end_bonus_withdrawal_date || 7,
          // Kasir settings
          kasir_enabled: data.kasir_enabled || false,
          kasir_payment_enabled: data.kasir_payment_enabled || false,
          kasir_payment_amount: Number(data.kasir_payment_amount || 0),
          kasir_payment_type: data.kasir_payment_type || "fixed",
          kasir_holiday_enabled: data.kasir_holiday_enabled || false,
          kasir_holiday_amount: Number(data.kasir_holiday_amount || 0),
          kasir_holiday_type: data.kasir_holiday_type || "fixed",
          kasir_year_end_bonus_withdrawal_date: data.kasir_year_end_bonus_withdrawal_date || 7,
        });
      }
    } catch (error: any) {
      console.error("Error loading incentive settings:", error);
      toast({
        title: "Gagal Memuat Pengaturan",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    const verified = await requireSuperCode("menyimpan pengaturan insentif");
    if (!verified) return;

    setSaving(true);
    try {
      const dataToSave = {
        // Sales settings
        is_enabled: settings.is_enabled,
        credit_application_enabled: settings.credit_application_enabled,
        credit_application_amount: settings.credit_application_amount,
        credit_application_type: settings.credit_application_type,
        installment_payment_enabled: settings.installment_payment_enabled,
        installment_payment_amount: settings.installment_payment_amount,
        installment_payment_type: settings.installment_payment_type,
        holiday_enabled: settings.holiday_enabled,
        holiday_amount: settings.holiday_amount,
        holiday_type: settings.holiday_type,
        year_end_bonus_withdrawal_date: settings.year_end_bonus_withdrawal_date,
        // Kasir settings
        kasir_enabled: settings.kasir_enabled,
        kasir_payment_enabled: settings.kasir_payment_enabled,
        kasir_payment_amount: settings.kasir_payment_amount,
        kasir_payment_type: settings.kasir_payment_type,
        kasir_holiday_enabled: settings.kasir_holiday_enabled,
        kasir_holiday_amount: settings.kasir_holiday_amount,
        kasir_holiday_type: settings.kasir_holiday_type,
        kasir_year_end_bonus_withdrawal_date: settings.kasir_year_end_bonus_withdrawal_date,
      };

      if (settings.id) {
        const { error } = await (supabase as any)
          .from("incentive_settings")
          .update(dataToSave)
          .eq("id", settings.id);

        if (error) throw error;
      } else {
        const { data, error } = await (supabase as any)
          .from("incentive_settings")
          .insert([dataToSave])
          .select()
          .single();

        if (error) throw error;
        if (data) {
          setSettings((prev) => ({ ...prev, id: data.id }));
        }
      }

      toast({
        title: "Berhasil",
        description: "Pengaturan insentif berhasil disimpan",
      });
    } catch (error: any) {
      console.error("Error saving incentive settings:", error);
      toast({
        title: "Gagal Menyimpan",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="sales" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="sales" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Insentif Sales
          </TabsTrigger>
          <TabsTrigger value="kasir" className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            Insentif Kasir
          </TabsTrigger>
        </TabsList>

        {/* Sales Tab */}
        <TabsContent value="sales" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Status Insentif Sales</CardTitle>
              <CardDescription>
                Aktifkan atau nonaktifkan sistem insentif untuk anggota sales
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Switch
                  id="incentive-enabled"
                  checked={settings.is_enabled}
                  onCheckedChange={(checked) =>
                    setSettings((prev) => ({ ...prev, is_enabled: checked }))
                  }
                />
                <Label htmlFor="incentive-enabled">
                  {settings.is_enabled ? "Aktif" : "Nonaktif"}
                </Label>
              </div>
            </CardContent>
          </Card>

          {settings.is_enabled && (
            <>
              {/* Insentif Pengajuan Kredit */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    <CardTitle>Insentif Pengajuan Kredit</CardTitle>
                  </div>
                  <CardDescription>
                    Berikan insentif kepada sales setiap kali pengajuan kredit disetujui
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="credit-app-enabled"
                      checked={settings.credit_application_enabled}
                      onCheckedChange={(checked) =>
                        setSettings((prev) => ({
                          ...prev,
                          credit_application_enabled: checked,
                        }))
                      }
                    />
                    <Label htmlFor="credit-app-enabled">
                      {settings.credit_application_enabled ? "Aktif" : "Nonaktif"}
                    </Label>
                  </div>
                  {settings.credit_application_enabled && (
                    <>
                      <div className="space-y-3">
                        <Label>Tipe Insentif</Label>
                        <RadioGroup
                          value={settings.credit_application_type}
                          onValueChange={(value: "fixed" | "percentage") =>
                            setSettings((prev) => ({
                              ...prev,
                              credit_application_type: value,
                            }))
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="fixed" id="credit-fixed" />
                            <Label htmlFor="credit-fixed" className="font-normal cursor-pointer">
                              Nilai Tetap (Rupiah)
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="percentage" id="credit-percentage" />
                            <Label htmlFor="credit-percentage" className="font-normal cursor-pointer">
                              Persentase dari Nilai Kredit Disetujui
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="credit-app-amount">
                          {settings.credit_application_type === "percentage"
                            ? "Persentase Insentif (%)"
                            : "Jumlah Insentif (Rp)"}
                        </Label>
                        <Input
                          id="credit-app-amount"
                          type="number"
                          value={settings.credit_application_amount || ""}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              credit_application_amount: e.target.value === "" ? 0 : Number(e.target.value),
                            }))
                          }
                          placeholder="0"
                          min="0"
                          max={settings.credit_application_type === "percentage" ? "100" : undefined}
                          step={settings.credit_application_type === "percentage" ? "0.1" : "1000"}
                        />
                        {settings.credit_application_type === "percentage" && (
                          <p className="text-xs text-muted-foreground">
                            Contoh: 2% dari kredit Rp 10.000.000 = Rp 200.000
                          </p>
                        )}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Insentif Pembayaran Angsuran */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <CardTitle>Insentif Pembayaran Angsuran</CardTitle>
                  </div>
                  <CardDescription>
                    Berikan insentif kepada sales setiap kali pembayaran angsuran diterima
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="payment-enabled"
                      checked={settings.installment_payment_enabled}
                      onCheckedChange={(checked) =>
                        setSettings((prev) => ({
                          ...prev,
                          installment_payment_enabled: checked,
                        }))
                      }
                    />
                    <Label htmlFor="payment-enabled">
                      {settings.installment_payment_enabled ? "Aktif" : "Nonaktif"}
                    </Label>
                  </div>
                  {settings.installment_payment_enabled && (
                    <>
                      <div className="space-y-3">
                        <Label>Tipe Insentif</Label>
                        <RadioGroup
                          value={settings.installment_payment_type}
                          onValueChange={(value: "fixed" | "percentage") =>
                            setSettings((prev) => ({
                              ...prev,
                              installment_payment_type: value,
                            }))
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="fixed" id="payment-fixed" />
                            <Label htmlFor="payment-fixed" className="font-normal cursor-pointer">
                              Nilai Tetap (Rupiah)
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="percentage" id="payment-percentage" />
                            <Label htmlFor="payment-percentage" className="font-normal cursor-pointer">
                              Persentase dari Nilai Angsuran Dibayar
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="payment-amount">
                          {settings.installment_payment_type === "percentage"
                            ? "Persentase Insentif (%)"
                            : "Jumlah Insentif (Rp)"}
                        </Label>
                        <Input
                          id="payment-amount"
                          type="number"
                          value={settings.installment_payment_amount || ""}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              installment_payment_amount: e.target.value === "" ? 0 : Number(e.target.value),
                            }))
                          }
                          placeholder="0"
                          min="0"
                          max={settings.installment_payment_type === "percentage" ? "100" : undefined}
                          step={settings.installment_payment_type === "percentage" ? "0.1" : "1000"}
                        />
                        {settings.installment_payment_type === "percentage" && (
                          <p className="text-xs text-muted-foreground">
                            Contoh: 1% dari angsuran Rp 1.000.000 = Rp 10.000
                          </p>
                        )}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Insentif Bonus Akhir Tahun Sales */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Gift className="h-5 w-5 text-primary" />
                    <CardTitle>Insentif Bonus Akhir Tahun</CardTitle>
                  </div>
                  <CardDescription>
                    Insentif khusus akhir tahun yang dapat ditarik setiap bulan Desember
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="holiday-enabled"
                      checked={settings.holiday_enabled}
                      onCheckedChange={(checked) =>
                        setSettings((prev) => ({
                          ...prev,
                          holiday_enabled: checked,
                        }))
                      }
                    />
                    <Label htmlFor="holiday-enabled">
                      {settings.holiday_enabled ? "Aktif" : "Nonaktif"}
                    </Label>
                  </div>
                  {settings.holiday_enabled && (
                    <>
                      <div className="space-y-3">
                        <Label>Tipe Insentif</Label>
                        <RadioGroup
                          value={settings.holiday_type}
                          onValueChange={(value: "fixed" | "percentage") =>
                            setSettings((prev) => ({
                              ...prev,
                              holiday_type: value,
                            }))
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="fixed" id="holiday-fixed" />
                            <Label htmlFor="holiday-fixed" className="font-normal cursor-pointer">
                              Nilai Tetap (Rupiah)
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="percentage" id="holiday-percentage" />
                            <Label htmlFor="holiday-percentage" className="font-normal cursor-pointer">
                              Persentase dari Total Angsuran Nasabah (1 Tahun Berjalan)
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="holiday-amount">
                          {settings.holiday_type === "percentage"
                            ? "Persentase Insentif (%)"
                            : "Jumlah Insentif (Rp)"}
                        </Label>
                        <Input
                          id="holiday-amount"
                          type="number"
                          value={settings.holiday_amount || ""}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              holiday_amount: e.target.value === "" ? 0 : Number(e.target.value),
                            }))
                          }
                          placeholder="0"
                          min="0"
                          max={settings.holiday_type === "percentage" ? "100" : undefined}
                          step={settings.holiday_type === "percentage" ? "0.1" : "1000"}
                        />
                        {settings.holiday_type === "percentage" && (
                          <p className="text-xs text-muted-foreground">
                            Contoh: 5% dari total pembayaran nasabah Rp 100.000.000 = Rp 5.000.000. 
                            Perhitungan direset setiap tahun (1 Jan - 31 Des)
                          </p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="year-end-bonus-withdrawal-date">
                          Tanggal Mulai Penarikan Bonus (Desember)
                        </Label>
                        <Input
                          id="year-end-bonus-withdrawal-date"
                          type="number"
                          value={settings.year_end_bonus_withdrawal_date}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              year_end_bonus_withdrawal_date: Math.min(31, Math.max(1, Number(e.target.value))),
                            }))
                          }
                          placeholder="7"
                          min="1"
                          max="31"
                        />
                        <p className="text-xs text-muted-foreground">
                          Tombol penarikan bonus akhir tahun akan muncul mulai tanggal ini di bulan Desember
                        </p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Kasir Tab */}
        <TabsContent value="kasir" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Status Insentif Kasir</CardTitle>
              <CardDescription>
                Aktifkan atau nonaktifkan sistem insentif untuk kasir
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Switch
                  id="kasir-incentive-enabled"
                  checked={settings.kasir_enabled}
                  onCheckedChange={(checked) =>
                    setSettings((prev) => ({ ...prev, kasir_enabled: checked }))
                  }
                />
                <Label htmlFor="kasir-incentive-enabled">
                  {settings.kasir_enabled ? "Aktif" : "Nonaktif"}
                </Label>
              </div>
            </CardContent>
          </Card>

          {settings.kasir_enabled && (
            <>
              {/* Insentif Pembayaran Kasir */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <CardTitle>Insentif Pembayaran</CardTitle>
                  </div>
                  <CardDescription>
                    Insentif untuk kasir berdasarkan total pembayaran yang diinput. 
                    Jika mode persentase: dihitung dari total pembayaran yang diinput kasir pada bulan tersebut.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="kasir-payment-enabled"
                      checked={settings.kasir_payment_enabled}
                      onCheckedChange={(checked) =>
                        setSettings((prev) => ({
                          ...prev,
                          kasir_payment_enabled: checked,
                        }))
                      }
                    />
                    <Label htmlFor="kasir-payment-enabled">
                      {settings.kasir_payment_enabled ? "Aktif" : "Nonaktif"}
                    </Label>
                  </div>
                  {settings.kasir_payment_enabled && (
                    <>
                      <div className="space-y-3">
                        <Label>Tipe Insentif</Label>
                        <RadioGroup
                          value={settings.kasir_payment_type}
                          onValueChange={(value: "fixed" | "percentage") =>
                            setSettings((prev) => ({
                              ...prev,
                              kasir_payment_type: value,
                            }))
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="fixed" id="kasir-payment-fixed" />
                            <Label htmlFor="kasir-payment-fixed" className="font-normal cursor-pointer">
                              Nilai Tetap per Transaksi (Rupiah)
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="percentage" id="kasir-payment-percentage" />
                            <Label htmlFor="kasir-payment-percentage" className="font-normal cursor-pointer">
                              Persentase dari Nilai Pembayaran
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="kasir-payment-amount">
                          {settings.kasir_payment_type === "percentage"
                            ? "Persentase Insentif (%)"
                            : "Jumlah Insentif per Transaksi (Rp)"}
                        </Label>
                        <Input
                          id="kasir-payment-amount"
                          type="number"
                          value={settings.kasir_payment_amount || ""}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              kasir_payment_amount: e.target.value === "" ? 0 : Number(e.target.value),
                            }))
                          }
                          placeholder="0"
                          min="0"
                          max={settings.kasir_payment_type === "percentage" ? "100" : undefined}
                          step={settings.kasir_payment_type === "percentage" ? "0.1" : "1000"}
                        />
                        {settings.kasir_payment_type === "percentage" ? (
                          <p className="text-xs text-muted-foreground">
                            Contoh: 0.5% dari pembayaran Rp 1.000.000 = Rp 5.000
                          </p>
                        ) : (
                          <p className="text-xs text-muted-foreground">
                            Contoh: Rp 5.000 per transaksi pembayaran yang diinput
                          </p>
                        )}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Insentif Bonus Akhir Tahun Kasir */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Gift className="h-5 w-5 text-primary" />
                    <CardTitle>Insentif Bonus Akhir Tahun Kasir</CardTitle>
                  </div>
                  <CardDescription>
                    Insentif akhir tahun untuk kasir. Jika mode persentase: dihitung dari total semua pembayaran 
                    yang diinput kasir dari 1 Januari sampai 1 Desember tahun berjalan.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="kasir-holiday-enabled"
                      checked={settings.kasir_holiday_enabled}
                      onCheckedChange={(checked) =>
                        setSettings((prev) => ({
                          ...prev,
                          kasir_holiday_enabled: checked,
                        }))
                      }
                    />
                    <Label htmlFor="kasir-holiday-enabled">
                      {settings.kasir_holiday_enabled ? "Aktif" : "Nonaktif"}
                    </Label>
                  </div>
                  {settings.kasir_holiday_enabled && (
                    <>
                      <div className="space-y-3">
                        <Label>Tipe Insentif</Label>
                        <RadioGroup
                          value={settings.kasir_holiday_type}
                          onValueChange={(value: "fixed" | "percentage") =>
                            setSettings((prev) => ({
                              ...prev,
                              kasir_holiday_type: value,
                            }))
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="fixed" id="kasir-holiday-fixed" />
                            <Label htmlFor="kasir-holiday-fixed" className="font-normal cursor-pointer">
                              Nilai Tetap (Rupiah)
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="percentage" id="kasir-holiday-percentage" />
                            <Label htmlFor="kasir-holiday-percentage" className="font-normal cursor-pointer">
                              Persentase dari Total Pembayaran (1 Jan - 1 Des)
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="kasir-holiday-amount">
                          {settings.kasir_holiday_type === "percentage"
                            ? "Persentase Insentif (%)"
                            : "Jumlah Insentif (Rp)"}
                        </Label>
                        <Input
                          id="kasir-holiday-amount"
                          type="number"
                          value={settings.kasir_holiday_amount || ""}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              kasir_holiday_amount: e.target.value === "" ? 0 : Number(e.target.value),
                            }))
                          }
                          placeholder="0"
                          min="0"
                          max={settings.kasir_holiday_type === "percentage" ? "100" : undefined}
                          step={settings.kasir_holiday_type === "percentage" ? "0.1" : "1000"}
                        />
                        {settings.kasir_holiday_type === "percentage" && (
                          <p className="text-xs text-muted-foreground">
                            Contoh: 1% dari total pembayaran Rp 500.000.000 = Rp 5.000.000
                          </p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="kasir-year-end-bonus-withdrawal-date">
                          Tanggal Mulai Penarikan Bonus (Desember)
                        </Label>
                        <Input
                          id="kasir-year-end-bonus-withdrawal-date"
                          type="number"
                          value={settings.kasir_year_end_bonus_withdrawal_date}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              kasir_year_end_bonus_withdrawal_date: Math.min(31, Math.max(1, Number(e.target.value))),
                            }))
                          }
                          placeholder="7"
                          min="1"
                          max="31"
                        />
                        <p className="text-xs text-muted-foreground">
                          Tombol penarikan bonus akhir tahun akan muncul mulai tanggal ini di bulan Desember
                        </p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>

      <Button onClick={handleSave} disabled={saving} className="w-full">
        {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Simpan Pengaturan
      </Button>
    </div>
  );
}
