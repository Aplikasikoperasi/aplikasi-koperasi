import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Loader2, Clock, Trash2, CheckCircle, XCircle } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";

interface CleanupHistory {
  id: string;
  cleanup_type: 'auto' | 'manual';
  retention_days: number;
  total_files_checked: number;
  files_deleted: number;
  files_failed: number;
  deleted_files: any[];
  failed_files: any[];
  cutoff_date: string;
  created_at: string;
}

export const CleanupHistoryLog = () => {
  const [history, setHistory] = useState<CleanupHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('google_drive_cleanup_history')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setHistory((data || []) as CleanupHistory[]);
    } catch (error) {
      console.error('Failed to load cleanup history:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Riwayat Cleanup
          </CardTitle>
          <CardDescription>
            Log operasi cleanup backup otomatis dan manual
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Riwayat Cleanup
        </CardTitle>
        <CardDescription>
          Log operasi cleanup backup otomatis dan manual (20 terakhir)
        </CardDescription>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Trash2 className="w-12 h-12 mx-auto mb-2 opacity-20" />
            <p>Belum ada riwayat cleanup</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-4">
              {history.map((entry) => (
                <div
                  key={entry.id}
                  className="border rounded-lg p-4 space-y-3 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge variant={entry.cleanup_type === 'auto' ? 'secondary' : 'default'}>
                          {entry.cleanup_type === 'auto' ? '🤖 Otomatis' : '👤 Manual'}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {format(new Date(entry.created_at), 'dd MMM yyyy, HH:mm', { locale: id })}
                        </span>
                      </div>
                      <p className="text-sm font-medium">
                        Masa simpan: {entry.retention_days} hari
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2 text-sm">
                        {entry.files_deleted > 0 && (
                          <span className="flex items-center gap-1 text-green-600">
                            <CheckCircle className="w-4 h-4" />
                            {entry.files_deleted} dihapus
                          </span>
                        )}
                        {entry.files_failed > 0 && (
                          <span className="flex items-center gap-1 text-red-600">
                            <XCircle className="w-4 h-4" />
                            {entry.files_failed} gagal
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {entry.total_files_checked} file diperiksa
                      </p>
                    </div>
                  </div>

                  {entry.deleted_files.length > 0 && (
                    <div className="text-xs space-y-1">
                      <p className="font-medium text-muted-foreground">File yang dihapus:</p>
                      <div className="bg-muted/50 rounded p-2 max-h-32 overflow-y-auto">
                        {entry.deleted_files.map((file: any, idx: number) => (
                          <div key={idx} className="flex justify-between py-1">
                            <span className="font-mono">{file.name}</span>
                            <span className="text-muted-foreground">
                              {format(new Date(file.createdTime), 'dd/MM/yy')}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {entry.failed_files.length > 0 && (
                    <div className="text-xs space-y-1">
                      <p className="font-medium text-red-600">Gagal dihapus:</p>
                      <div className="bg-red-50 dark:bg-red-950/20 rounded p-2 max-h-32 overflow-y-auto">
                        {entry.failed_files.map((file: any, idx: number) => (
                          <div key={idx} className="py-1">
                            <span className="font-mono">{file.name}</span>
                            <p className="text-red-600 text-xs">{file.error}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};
