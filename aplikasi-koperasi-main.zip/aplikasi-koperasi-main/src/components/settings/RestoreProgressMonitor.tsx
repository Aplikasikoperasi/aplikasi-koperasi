import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Clock, CheckCircle2, XCircle, Loader2, Database } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";

interface RestoreProgressData {
  id: string;
  status: string;
  backup_timestamp: string;
  total_customers: number;
  completed_customers: number;
  current_customer_name: string | null;
  total_applications: number;
  completed_applications: number;
  started_at: string;
  completed_at: string | null;
  last_updated: string;
  error_log: any;
}

interface TableProgress {
  name: string;
  displayName: string;
  inserted: number;
  updated: number;
  failed: number;
  total: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

interface RestoreProgressMonitorProps {
  progressId: string;
  onComplete?: (success: boolean) => void;
}

export const RestoreProgressMonitor = ({ progressId, onComplete }: RestoreProgressMonitorProps) => {
  const [progress, setProgress] = useState<RestoreProgressData | null>(null);
  const [tableProgress, setTableProgress] = useState<TableProgress[]>([]);
  const [overallProgress, setOverallProgress] = useState(0);
  const [eta, setEta] = useState<string>("");
  const [elapsedTime, setElapsedTime] = useState<string>("");

  // Table mappings dengan urutan restore
  const tableMappings: { name: string; displayName: string }[] = [
    { name: 'profiles', displayName: '👤 Profil' },
    { name: 'members', displayName: '👥 Anggota' },
    { name: 'customers', displayName: '🏪 Nasabah' },
    { name: 'credit_applications', displayName: '📝 Aplikasi Kredit' },
    { name: 'installments', displayName: '💳 Angsuran' },
    { name: 'payments', displayName: '💰 Pembayaran' },
    { name: 'blocked_customers', displayName: '🚫 Nasabah Diblokir' },
    { name: 'block_history', displayName: '📋 Riwayat Blokir' },
    { name: 'bank_accounts', displayName: '🏦 Rekening Bank' },
    { name: 'member_balance_transactions', displayName: '💵 Transaksi Saldo' },
    { name: 'member_balance_withdrawals', displayName: '💸 Penarikan Saldo' },
    { name: 'member_monthly_balance_summary', displayName: '📊 Ringkasan Saldo' },
    { name: 'customer_messages', displayName: '✉️ Pesan Nasabah' },
    { name: 'member_messages', displayName: '📨 Pesan Anggota' },
    { name: 'customer_change_requests', displayName: '🔄 Permintaan Ubah Data' },
    { name: 'customer_restoration_requests', displayName: '♻️ Permintaan Pemulihan' },
    { name: 'whatsapp_message_logs', displayName: '📱 Log WhatsApp' },
    { name: 'system_logs', displayName: '🗂️ Log Sistem' }
  ];

  // Fetch progress data
  const fetchProgress = async () => {
    const { data, error } = await supabase
      .from('restore_progress')
      .select('*')
      .eq('id', progressId)
      .single();

    if (error) {
      console.error('Error fetching progress:', error);
      return;
    }

    if (data) {
      setProgress(data as RestoreProgressData);
      
      // Parse table progress from error_log
      if (data.error_log) {
        const errorLog = data.error_log as any;
        const summary = errorLog.summary || {};
        
        const tables: TableProgress[] = tableMappings.map(mapping => {
          const tableStats = summary[mapping.name] || {
            inserted: 0,
            updated: 0,
            failed: 0,
            total: 0
          };

          let status: TableProgress['status'] = 'pending';
          
          if (tableStats.total > 0) {
            const processed = tableStats.inserted + tableStats.updated + tableStats.failed;
            if (processed >= tableStats.total) {
              status = tableStats.failed > 0 ? 'failed' : 'completed';
            } else if (processed > 0) {
              status = 'processing';
            }
          }

          return {
            name: mapping.name,
            displayName: mapping.displayName,
            inserted: tableStats.inserted || 0,
            updated: tableStats.updated || 0,
            failed: tableStats.failed || 0,
            total: tableStats.total || 0,
            status
          };
        });

        setTableProgress(tables);

        // Calculate overall progress
        const totalRecords = tables.reduce((sum, t) => sum + t.total, 0);
        const processedRecords = tables.reduce((sum, t) => sum + t.inserted + t.updated + t.failed, 0);
        const percent = totalRecords > 0 ? Math.round((processedRecords / totalRecords) * 100) : 0;
        setOverallProgress(percent);

        // Calculate ETA
        if (data.started_at && percent > 0 && percent < 100) {
          const startTime = new Date(data.started_at).getTime();
          const currentTime = Date.now();
          const elapsed = currentTime - startTime;
          const totalEstimated = (elapsed / percent) * 100;
          const remaining = totalEstimated - elapsed;
          
          const minutes = Math.floor(remaining / 60000);
          const seconds = Math.floor((remaining % 60000) / 1000);
          setEta(`~${minutes}m ${seconds}s`);
        } else if (percent >= 100) {
          setEta('Selesai');
        }
      }

      // Calculate elapsed time
      if (data.started_at) {
        const startTime = new Date(data.started_at).getTime();
        const endTime = data.completed_at ? new Date(data.completed_at).getTime() : Date.now();
        const elapsed = endTime - startTime;
        
        const minutes = Math.floor(elapsed / 60000);
        const seconds = Math.floor((elapsed % 60000) / 1000);
        setElapsedTime(`${minutes}m ${seconds}s`);
      }

      // Check if completed
      if (data.status === 'completed' || data.status === 'completed_with_errors' || data.status === 'failed') {
        if (onComplete) {
          onComplete(data.status === 'completed');
        }
      }
    }
  };

  // Initial fetch and polling
  useEffect(() => {
    fetchProgress();
    
    // Poll every 2 seconds
    const interval = setInterval(fetchProgress, 2000);
    
    return () => clearInterval(interval);
  }, [progressId]);

  // Subscribe to realtime updates
  useEffect(() => {
    const channel = supabase
      .channel(`restore-progress-${progressId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'restore_progress',
          filter: `id=eq.${progressId}`
        },
        () => {
          fetchProgress();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [progressId]);

  if (!progress) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="text-sm text-muted-foreground">Memuat progress...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusBadge = () => {
    switch (progress.status) {
      case 'processing':
        return <Badge variant="default" className="gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Sedang Berjalan</Badge>;
      case 'completed':
        return <Badge variant="default" className="gap-1 bg-green-500"><CheckCircle2 className="h-3 w-3" /> Selesai</Badge>;
      case 'completed_with_errors':
        return <Badge variant="destructive" className="gap-1">⚠️ Selesai dengan Error</Badge>;
      case 'failed':
        return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" /> Gagal</Badge>;
      default:
        return <Badge variant="outline">Menunggu</Badge>;
    }
  };

  const isRunning = progress.status === 'processing';

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Progress Restore Real-Time
            </CardTitle>
            <CardDescription>
              Monitoring proses restore data backup
            </CardDescription>
          </div>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">Progress Keseluruhan</span>
            <span className="text-muted-foreground">{overallProgress}%</span>
          </div>
          <Progress value={overallProgress} className="h-3" />
        </div>

        {/* Time Info */}
        <div className="grid grid-cols-2 gap-4">
          <Alert>
            <Clock className="h-4 w-4" />
            <AlertDescription>
              <div className="text-xs text-muted-foreground">Waktu Berjalan</div>
              <div className="font-semibold">{elapsedTime}</div>
            </AlertDescription>
          </Alert>
          <Alert>
            <Clock className="h-4 w-4" />
            <AlertDescription>
              <div className="text-xs text-muted-foreground">Estimasi Sisa Waktu</div>
              <div className="font-semibold">{eta || '-'}</div>
            </AlertDescription>
          </Alert>
        </div>

        {/* Current Status */}
        {isRunning && (
          <Alert>
            <Loader2 className="h-4 w-4 animate-spin" />
            <AlertDescription>
              <div className="text-xs text-muted-foreground">Status Saat Ini</div>
              <div className="font-medium">{progress.status}</div>
              {progress.current_customer_name && (
                <div className="text-xs mt-1">Processing: {progress.current_customer_name}</div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Table Progress */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Detail Progress Per Tabel</h4>
          <ScrollArea className="h-[400px] rounded-md border p-4">
            <div className="space-y-4">
              {tableProgress.map((table) => {
                const progressPercent = table.total > 0 
                  ? Math.round(((table.inserted + table.updated + table.failed) / table.total) * 100) 
                  : 0;

                return (
                  <div key={table.name} className="space-y-2 pb-4 border-b last:border-0">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{table.displayName}</span>
                      <div className="flex items-center gap-2">
                        {table.status === 'processing' && <Loader2 className="h-3 w-3 animate-spin text-blue-500" />}
                        {table.status === 'completed' && <CheckCircle2 className="h-3 w-3 text-green-500" />}
                        {table.status === 'failed' && <XCircle className="h-3 w-3 text-red-500" />}
                        <span className="text-xs text-muted-foreground">{progressPercent}%</span>
                      </div>
                    </div>
                    
                    {table.total > 0 && (
                      <>
                        <Progress value={progressPercent} className="h-2" />
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>
                            {table.inserted + table.updated + table.failed} / {table.total} records
                          </span>
                          <span className="flex gap-3">
                            <span className="text-green-600">✓ {table.inserted}</span>
                            <span className="text-blue-600">↻ {table.updated}</span>
                            {table.failed > 0 && <span className="text-red-600">✗ {table.failed}</span>}
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Summary Stats */}
        {progress.error_log?.totals && (
          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {progress.error_log.totals.inserted || 0}
              </div>
              <div className="text-xs text-muted-foreground">Data Baru</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {progress.error_log.totals.updated || 0}
              </div>
              <div className="text-xs text-muted-foreground">Data Update</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {progress.error_log.totals.failed || 0}
              </div>
              <div className="text-xs text-muted-foreground">Gagal</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
