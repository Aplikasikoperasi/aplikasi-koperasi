import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Upload } from "lucide-react";
import { useSuperCode } from "@/contexts/SuperCodeContext";

const profileSchema = z.object({
  business_name: z.string().max(100, "Nama usaha maksimal 100 karakter").optional(),
  business_address: z.string().max(500, "Alamat maksimal 500 karakter").optional(),
  business_description: z.string().max(200, "Deskripsi maksimal 200 karakter").optional(),
  business_phone: z.string().max(20, "Nomor telepon maksimal 20 karakter").optional(),
  business_email: z.string().email("Email tidak valid").optional().or(z.literal("")),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

interface ProfileSettingsProps {
  userId: string;
}

export const ProfileSettings = ({ userId }: ProfileSettingsProps) => {
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [superCode, setSuperCode] = useState("");
  const [savingSuperCode, setSavingSuperCode] = useState(false);
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      business_name: "",
      business_address: "",
      business_description: "",
      business_phone: "",
      business_email: "",
    },
  });

  useEffect(() => {
    loadProfile();
  }, [userId]);

  const loadProfile = async () => {
    try {
      // Load profile data
      const { data, error } = await supabase
        .from("profiles")
        .select("business_name, business_address, business_description, business_phone, business_email, logo_url")
        .eq("id", userId)
        .single();

      if (error) throw error;

      if (data) {
        form.reset({
          business_name: data.business_name || "",
          business_address: data.business_address || "",
          business_description: data.business_description || "",
          business_phone: data.business_phone || "",
          business_email: data.business_email || "",
        });
        setLogoUrl(data.logo_url);
      }

      // Load supercode from app_settings
      const { data: settingsData } = await supabase
        .from("app_settings")
        .select("super_code")
        .eq("user_id", userId)
        .single();

      if (settingsData) {
        setSuperCode(settingsData.super_code || "");
      }
    } catch (error: any) {
      toast({
        title: "Gagal memuat profil",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleSaveSuperCode = async () => {
    const verified = await requireSuperCode("mengubah SuperCode");
    if (!verified) return;

    setSavingSuperCode(true);
    try {
      const { data: existing } = await supabase
        .from("app_settings")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from("app_settings")
          .update({ super_code: superCode })
          .eq("user_id", userId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("app_settings")
          .insert({ user_id: userId, super_code: superCode });
        if (error) throw error;
      }

      toast({
        title: "Berhasil",
        description: "SuperCode berhasil diperbarui",
      });
    } catch (error: any) {
      toast({
        title: "Gagal menyimpan SuperCode",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSavingSuperCode(false);
    }
  };

  const onSubmit = async (values: ProfileFormValues) => {
    const verified = await requireSuperCode("menyimpan perubahan profil");
    if (!verified) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          business_name: values.business_name || null,
          business_address: values.business_address || null,
          business_description: values.business_description || null,
          business_phone: values.business_phone || null,
          business_email: values.business_email || null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId);

      if (error) throw error;

      toast({
        title: "Berhasil",
        description: "Profil berhasil diperbarui",
      });

      // Trigger event to update header and sidebar
      window.dispatchEvent(new Event('businessProfileUpdated'));
    } catch (error: any) {
      toast({
        title: "Gagal memperbarui profil",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const verified = await requireSuperCode("mengunggah logo");
    if (!verified) {
      event.target.value = '';
      return;
    }

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Tipe file tidak valid",
        description: "Harap unggah file gambar",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "File terlalu besar",
        description: "Harap unggah gambar kurang dari 2MB",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${userId}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from("business-logos")
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("business-logos")
        .getPublicUrl(fileName);

      const { error: updateError } = await supabase
        .from("profiles")
        .update({ logo_url: publicUrl })
        .eq("id", userId);

      if (updateError) throw updateError;

      setLogoUrl(publicUrl);
      toast({
        title: "Berhasil",
        description: "Logo berhasil diunggah",
      });

      // Trigger event to update header and sidebar
      window.dispatchEvent(new Event('businessProfileUpdated'));
    } catch (error: any) {
      toast({
        title: "Gagal mengunggah logo",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Informasi Usaha</CardTitle>
          <CardDescription>Perbarui detail dan logo usaha Anda</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-24 h-24 rounded-lg border-2 border-dashed border-muted-foreground/25 flex items-center justify-center overflow-hidden bg-muted">
                {logoUrl ? (
                  <img key={logoUrl} src={logoUrl} alt="Business logo" className="w-full h-full object-cover animate-logo" />
                ) : (
                  <Upload className="w-8 h-8 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <label htmlFor="logo-upload">
                  <Button type="button" variant="outline" disabled={uploading} asChild>
                    <span>
                      {uploading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Mengunggah...
                        </>
                      ) : (
                        "Unggah Logo"
                      )}
                    </span>
                  </Button>
                </label>
                <input
                  id="logo-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
                <p className="text-sm text-muted-foreground mt-2">
                  Rekomendasi: Gambar persegi, maksimal 2MB
                </p>
              </div>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="business_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Usaha</FormLabel>
                    <FormControl>
                      <Input placeholder="Masukkan nama usaha Anda" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="business_description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deskripsi Usaha</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Masukkan deskripsi singkat tentang usaha Anda" 
                        rows={2}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="business_address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Alamat Usaha</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Masukkan alamat usaha Anda" 
                        rows={3}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="business_phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nomor Telepon</FormLabel>
                      <FormControl>
                        <Input placeholder="Contoh: 0812-3456-7890" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="business_email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="Contoh: info@bisnis.com" type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Menyimpan...
                  </>
                ) : (
                  "Simpan Perubahan"
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* SuperCode Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Pengaturan SuperCode</CardTitle>
          <CardDescription>
            SuperCode adalah kode keamanan rahasia untuk verifikasi aksi penting
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="superCode" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">SuperCode</label>
            <Input
              id="superCode"
              type="password"
              value={superCode}
              onChange={(e) => setSuperCode(e.target.value.replace(/\D/g, ''))}
              placeholder="Masukkan kode angka"
              maxLength={10}
            />
            <p className="text-sm text-muted-foreground">
              SuperCode hanya boleh berisi angka (maksimal 10 digit)
            </p>
          </div>
          <Button onClick={handleSaveSuperCode} disabled={savingSuperCode}>
            {savingSuperCode ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Menyimpan...
              </>
            ) : (
              "Simpan SuperCode"
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
