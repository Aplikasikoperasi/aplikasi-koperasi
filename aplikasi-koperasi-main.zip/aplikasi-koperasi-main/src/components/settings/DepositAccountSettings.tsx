import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Trash2, Star, Percent, CalendarDays, Award, Medal, Trophy } from "lucide-react";
import { formatNumberWithSeparator, parseNumberFromSeparator } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface DepositAccount {
  id: string;
  bank_name: string;
  account_number: string;
  account_holder: string;
  is_primary: boolean;
  is_active: boolean;
}

export function DepositAccountSettings() {
  const { toast } = useToast();
  const { requireSuperCode } = useSuperCode();
  const [accounts, setAccounts] = useState<DepositAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    bank_name: "",
    account_number: "",
    account_holder: "",
    is_active: true,
  });
  
  // Interest settings state
  const [interestRate, setInterestRate] = useState<number>(0);
  const [interestPaymentDay, setInterestPaymentDay] = useState<number>(1);
  const [savingInterestSettings, setSavingInterestSettings] = useState(false);
  
  // Tier settings state
  const [silverMinBalance, setSilverMinBalance] = useState<number>(0);
  const [silverInterestRate, setSilverInterestRate] = useState<number>(0.5);
  const [silverInterestRateText, setSilverInterestRateText] = useState<string>("0.5");
  const [goldMinBalance, setGoldMinBalance] = useState<number>(5000000);
  const [goldInterestRate, setGoldInterestRate] = useState<number>(0.75);
  const [goldInterestRateText, setGoldInterestRateText] = useState<string>("0.75");
  const [platinumMinBalance, setPlatinumMinBalance] = useState<number>(10000000);
  const [platinumInterestRate, setPlatinumInterestRate] = useState<number>(1.0);
  const [platinumInterestRateText, setPlatinumInterestRateText] = useState<string>("1");
  const [minDaysForInterest, setMinDaysForInterest] = useState<number>(21);

  useEffect(() => {
    loadAccounts();
    loadInterestSettings();
  }, []);

  const loadInterestSettings = async () => {
    try {
      const { data, error } = await supabase
        .from("app_settings")
        .select("deposit_interest_rate, deposit_interest_payment_day, deposit_tier_silver_min_balance, deposit_tier_silver_interest_rate, deposit_tier_gold_min_balance, deposit_tier_gold_interest_rate, deposit_tier_platinum_min_balance, deposit_tier_platinum_interest_rate, deposit_min_days_for_interest")
        .limit(1)
        .single();
      
      if (error && error.code !== "PGRST116") throw error;
      if (data) {
        const settings = data as any;

        const silverRate = settings.deposit_tier_silver_interest_rate ?? 0.5;
        const goldRate = settings.deposit_tier_gold_interest_rate ?? 0.75;
        const platinumRate = settings.deposit_tier_platinum_interest_rate ?? 1.0;

        setInterestRate(settings.deposit_interest_rate ?? 0);
        setInterestPaymentDay(settings.deposit_interest_payment_day ?? 1);

        setSilverMinBalance(settings.deposit_tier_silver_min_balance ?? 0);
        setSilverInterestRate(silverRate);
        setSilverInterestRateText(silverRate === 0 ? "" : String(silverRate));

        setGoldMinBalance(settings.deposit_tier_gold_min_balance ?? 5000000);
        setGoldInterestRate(goldRate);
        setGoldInterestRateText(goldRate === 0 ? "" : String(goldRate));

        setPlatinumMinBalance(settings.deposit_tier_platinum_min_balance ?? 10000000);
        setPlatinumInterestRate(platinumRate);
        setPlatinumInterestRateText(platinumRate === 0 ? "" : String(platinumRate));

        setMinDaysForInterest(settings.deposit_min_days_for_interest ?? 21);
      }
    } catch (error: any) {
      console.log("Could not load interest settings:", error.message);
    }
  };

  const handleSaveInterestSettings = async () => {
    const verified = await requireSuperCode("mengubah pengaturan bunga simpanan");
    if (!verified) return;

    setSavingInterestSettings(true);
    try {
      const { data: existing } = await supabase
        .from("app_settings")
        .select("id")
        .limit(1)
        .single();

      if (existing) {
        const { error } = await supabase
          .from("app_settings")
          .update({
            deposit_interest_rate: interestRate,
            deposit_interest_payment_day: interestPaymentDay,
            deposit_tier_silver_min_balance: silverMinBalance,
            deposit_tier_silver_interest_rate: silverInterestRate,
            deposit_tier_gold_min_balance: goldMinBalance,
            deposit_tier_gold_interest_rate: goldInterestRate,
            deposit_tier_platinum_min_balance: platinumMinBalance,
            deposit_tier_platinum_interest_rate: platinumInterestRate,
            deposit_min_days_for_interest: minDaysForInterest,
          } as any)
          .eq("id", existing.id);
        if (error) throw error;
      } else {
        toast({
          title: "Error",
          description: "Pengaturan aplikasi belum diinisialisasi",
          variant: "destructive",
        });
        return;
      }

      toast({ title: "Sukses", description: "Pengaturan bunga simpanan berhasil disimpan" });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSavingInterestSettings(false);
    }
  };

  const loadAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from("deposit_accounts" as any)
        .select("*")
        .order("is_primary", { ascending: false })
        .order("created_at", { ascending: true });

      if (error) throw error;
      setAccounts((data || []) as any);
    } catch (error: any) {
      // Table might not exist yet, that's ok
      console.log("Deposit accounts table may not exist yet");
      setAccounts([]);
    }
  };

  const validateAccountNumber = (value: string): boolean => {
    return /^\d+$/.test(value);
  };

  const formatAccountNumber = (value: string): string => {
    return value.replace(/(.{4})/g, '$1 ').trim();
  };

  const handleAccountNumberChange = (value: string) => {
    // Remove spaces first to get raw digits
    const rawValue = value.replace(/\s/g, '');
    if (rawValue === "" || validateAccountNumber(rawValue)) {
      setFormData({ ...formData, account_number: rawValue });
    }
  };

  const handleSave = async () => {
    if (!formData.bank_name || !formData.account_number || !formData.account_holder) {
      toast({
        title: "Error",
        description: "Semua field harus diisi",
        variant: "destructive",
      });
      return;
    }

    if (!validateAccountNumber(formData.account_number)) {
      toast({
        title: "Error",
        description: "Nomor rekening hanya boleh berisi angka",
        variant: "destructive",
      });
      return;
    }

    const verified = await requireSuperCode(editingId ? "memperbarui rekening deposit" : "menambahkan rekening deposit");
    if (!verified) return;

    setLoading(true);
    try {
      if (editingId) {
        const { error } = await supabase
          .from("deposit_accounts" as any)
          .update({
            bank_name: formData.bank_name,
            account_number: formData.account_number,
            account_holder: formData.account_holder,
            is_active: formData.is_active,
          })
          .eq("id", editingId);

        if (error) throw error;
        toast({ title: "Sukses", description: "Rekening deposit berhasil diperbarui" });
      } else {
        const { error } = await supabase
          .from("deposit_accounts" as any)
          .insert({
            bank_name: formData.bank_name,
            account_number: formData.account_number,
            account_holder: formData.account_holder,
            is_primary: accounts.length === 0,
            is_active: formData.is_active,
          });

        if (error) throw error;
        toast({ title: "Sukses", description: "Rekening deposit berhasil ditambahkan" });
      }

      setFormData({ bank_name: "", account_number: "", account_holder: "", is_active: true });
      setEditingId(null);
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (account: DepositAccount) => {
    setEditingId(account.id);
    setFormData({
      bank_name: account.bank_name,
      account_number: account.account_number,
      account_holder: account.account_holder,
      is_active: account.is_active,
    });
  };

  const handleDelete = async () => {
    if (!deleteId) return;

    const verified = await requireSuperCode("menghapus rekening deposit");
    if (!verified) {
      setDeleteId(null);
      return;
    }

    try {
      const { error } = await supabase
        .from("deposit_accounts" as any)
        .delete()
        .eq("id", deleteId);

      if (error) throw error;
      toast({ title: "Sukses", description: "Rekening deposit berhasil dihapus" });
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeleteId(null);
    }
  };

  const handleSetPrimary = async (id: string) => {
    const verified = await requireSuperCode("mengubah rekening deposit utama");
    if (!verified) return;
    
    try {
      const { error } = await supabase
        .from("deposit_accounts" as any)
        .update({ is_primary: true })
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Sukses", description: "Rekening deposit utama berhasil diubah" });
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleToggleActive = async (id: string, currentStatus: boolean) => {
    const verified = await requireSuperCode(currentStatus ? "menonaktifkan rekening deposit" : "mengaktifkan rekening deposit");
    if (!verified) return;
    
    try {
      const { error } = await supabase
        .from("deposit_accounts" as any)
        .update({ is_active: !currentStatus })
        .eq("id", id);

      if (error) throw error;
      toast({ 
        title: "Sukses", 
        description: `Rekening deposit ${!currentStatus ? "diaktifkan" : "dinonaktifkan"}` 
      });
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setFormData({ bank_name: "", account_number: "", account_holder: "", is_active: true });
  };

  return (
    <div className="space-y-6">
      {/* Interest Settings Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Percent className="h-5 w-5" />
            Pengaturan Bunga Simpanan
          </CardTitle>
          <CardDescription>
            Atur besar bunga dan tanggal pemberian bunga untuk saldo simpanan nasabah
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Basic Settings */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="interest_payment_day" className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4" />
                Tanggal Pemberian Bunga
              </Label>
              <Select
                value={interestPaymentDay.toString()}
                onValueChange={(value) => setInterestPaymentDay(parseInt(value))}
              >
                <SelectTrigger id="interest_payment_day">
                  <SelectValue placeholder="Pilih tanggal" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 28 }, (_, i) => i + 1).map((day) => (
                    <SelectItem key={day} value={day.toString()}>
                      {day}
                    </SelectItem>
                  ))}
                  <SelectItem value="0">Akhir Bulan</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                Tanggal bunga akan diberikan setiap bulan
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="min_days_for_interest">Minimal Hari Deposit</Label>
              <div className="relative">
                <Input
                  id="min_days_for_interest"
                  type="number"
                  min="1"
                  max="31"
                  value={minDaysForInterest}
                  onChange={(e) => setMinDaysForInterest(parseInt(e.target.value) || 21)}
                  className="pr-12"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">hari</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Minimal waktu deposit sebelum mendapatkan bunga
              </p>
            </div>
          </div>

          {/* Tier Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">Pengaturan Level Nasabah</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Atur saldo minimum dan bunga berbeda untuk setiap level nasabah
            </p>

            {/* Silver Tier */}
            <div className="border rounded-lg p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Badge className="bg-gradient-to-r from-slate-300 via-slate-200 to-slate-400 text-slate-800 border-slate-200 shadow-md animate-shimmer bg-[length:200%_100%]">
                  <Award className="h-3 w-3 mr-1" />
                  Silver
                </Badge>
                <span className="text-sm text-muted-foreground">(Level Dasar)</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Saldo Minimum</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">Rp</span>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={silverMinBalance === 0 ? "" : formatNumberWithSeparator(silverMinBalance)}
                      onChange={(e) => {
                        const raw = parseNumberFromSeparator(e.target.value);
                        setSilverMinBalance(raw === "" ? 0 : parseFloat(raw));
                      }}
                      className="pl-10"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Bunga per Bulan</Label>
                  <div className="relative">
                    <Input
                      type="text"
                      inputMode="decimal"
                      value={silverInterestRateText}
                      onChange={(e) => {
                        const next = e.target.value.replace(",", ".");
                        if (next === "") {
                          setSilverInterestRateText("");
                          setSilverInterestRate(0);
                          return;
                        }
                        if (!/^\d*\.?\d*$/.test(next)) return;

                        setSilverInterestRateText(next);
                        setSilverInterestRate(parseFloat(next) || 0);
                      }}
                      className="pr-8"
                      placeholder="0"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Gold Tier */}
            <div className="border rounded-lg p-4 space-y-3 border-yellow-300 bg-yellow-50/50 dark:bg-yellow-950/20">
              <div className="flex items-center gap-2">
                <Badge className="bg-gradient-to-r from-yellow-400 via-amber-300 to-amber-500 text-amber-900 border-yellow-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]">
                  <Medal className="h-3 w-3 mr-1" />
                  Gold
                </Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Saldo Minimum</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">Rp</span>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={goldMinBalance === 0 ? "" : formatNumberWithSeparator(goldMinBalance)}
                      onChange={(e) => {
                        const raw = parseNumberFromSeparator(e.target.value);
                        setGoldMinBalance(raw === "" ? 0 : parseFloat(raw));
                      }}
                      className="pl-10"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Bunga per Bulan</Label>
                  <div className="relative">
                    <Input
                      type="text"
                      inputMode="decimal"
                      value={goldInterestRateText}
                      onChange={(e) => {
                        const next = e.target.value.replace(",", ".");
                        if (next === "") {
                          setGoldInterestRateText("");
                          setGoldInterestRate(0);
                          return;
                        }
                        if (!/^\d*\.?\d*$/.test(next)) return;

                        setGoldInterestRateText(next);
                        setGoldInterestRate(parseFloat(next) || 0);
                      }}
                      className="pr-8"
                      placeholder="0"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Platinum Tier */}
            <div className="border rounded-lg p-4 space-y-3 border-purple-300 bg-purple-50/50 dark:bg-purple-950/20">
              <div className="flex items-center gap-2">
                <Badge className="bg-gradient-to-r from-purple-400 via-pink-400 to-purple-500 text-white border-purple-200 shadow-lg animate-shimmer animate-glow bg-[length:200%_100%]">
                  <Trophy className="h-3 w-3 mr-1" />
                  Platinum
                </Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Saldo Minimum</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">Rp</span>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={platinumMinBalance === 0 ? "" : formatNumberWithSeparator(platinumMinBalance)}
                      onChange={(e) => {
                        const raw = parseNumberFromSeparator(e.target.value);
                        setPlatinumMinBalance(raw === "" ? 0 : parseFloat(raw));
                      }}
                      className="pl-10"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Bunga per Bulan</Label>
                  <div className="relative">
                    <Input
                      type="text"
                      inputMode="decimal"
                      value={platinumInterestRateText}
                      onChange={(e) => {
                        const next = e.target.value.replace(",", ".");
                        if (next === "") {
                          setPlatinumInterestRateText("");
                          setPlatinumInterestRate(0);
                          return;
                        }
                        if (!/^\d*\.?\d*$/.test(next)) return;

                        setPlatinumInterestRateText(next);
                        setPlatinumInterestRate(parseFloat(next) || 0);
                      }}
                      className="pr-8"
                      placeholder="0"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Button onClick={handleSaveInterestSettings} disabled={savingInterestSettings}>
            {savingInterestSettings ? "Menyimpan..." : "Simpan Pengaturan Bunga"}
          </Button>
        </CardContent>
      </Card>

      {/* Deposit Accounts Card */}
      <Card>
        <CardHeader>
          <CardTitle>Rekening Deposit Simpanan</CardTitle>
          <CardDescription>
            Kelola rekening bank untuk deposit simpanan nasabah. Tandai satu sebagai rekening utama.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="deposit_bank_name">Nama Bank</Label>
              <Input
                id="deposit_bank_name"
                placeholder="Contoh: BCA"
                value={formData.bank_name}
                onChange={(e) => setFormData({ ...formData, bank_name: e.target.value.toUpperCase() })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="deposit_account_number">Nomor Rekening</Label>
              <Input
                id="deposit_account_number"
                placeholder="Hanya angka"
                value={formatAccountNumber(formData.account_number)}
                onChange={(e) => handleAccountNumberChange(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Hanya boleh berisi angka
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="deposit_account_holder">Nama Pemegang Rekening</Label>
              <Input
                id="deposit_account_holder"
                placeholder="Nama sesuai rekening"
                value={formData.account_holder}
                onChange={(e) => setFormData({ ...formData, account_holder: e.target.value.toUpperCase() })}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="deposit_is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label htmlFor="deposit_is_active">Aktif</Label>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={loading}>
                {editingId ? "Perbarui" : "Tambah"} Rekening
              </Button>
              {editingId && (
                <Button variant="outline" onClick={cancelEdit}>
                  Batal
                </Button>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium">Daftar Rekening Deposit</h3>
            {accounts.length === 0 ? (
              <p className="text-sm text-muted-foreground">Belum ada rekening deposit yang ditambahkan</p>
            ) : (
              <div className="space-y-3">
                {accounts.map((account) => (
                  <Card key={account.id} className={!account.is_active ? "opacity-60" : ""}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{account.bank_name}</p>
                            {account.is_primary && (
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            )}
                            {!account.is_active && (
                              <span className="text-xs text-muted-foreground">(Nonaktif)</span>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {formatAccountNumber(account.account_number)}
                          </p>
                          <p className="text-sm">{account.account_holder}</p>
                        </div>
                        <div className="flex gap-2">
                          {!account.is_primary && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleSetPrimary(account.id)}
                              title="Jadikan rekening utama"
                            >
                              <Star className="h-4 w-4" />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleToggleActive(account.id, account.is_active)}
                          >
                            {account.is_active ? "Nonaktifkan" : "Aktifkan"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(account)}
                          >
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => setDeleteId(account.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Rekening Deposit?</AlertDialogTitle>
            <AlertDialogDescription>
              Aksi ini tidak dapat dibatalkan. Rekening akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
