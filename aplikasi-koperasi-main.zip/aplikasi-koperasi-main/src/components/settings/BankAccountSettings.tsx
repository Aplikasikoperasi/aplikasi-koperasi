import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Trash2, Plus, Star } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useSuperCode } from "@/contexts/SuperCodeContext";
interface BankAccount {
  id: string;
  bank_name: string;
  account_number: string;
  account_holder: string;
  is_primary: boolean;
  is_active: boolean;
}
export function BankAccountSettings() {
  const {
    toast
  } = useToast();
  const {
    requireSuperCode
  } = useSuperCode();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    bank_name: "",
    account_number: "",
    account_holder: "",
    is_active: true
  });
  useEffect(() => {
    loadAccounts();
  }, []);
  const loadAccounts = async () => {
    try {
      const {
        data,
        error
      } = await supabase.from("bank_accounts" as any).select("*").order("is_primary", {
        ascending: false
      }).order("created_at", {
        ascending: true
      });
      if (error) throw error;
      setAccounts((data || []) as any);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };
  const validateAccountNumber = (value: string): boolean => {
    return /^\d+$/.test(value);
  };

  const formatAccountNumber = (value: string): string => {
    return value.replace(/(.{4})/g, '$1 ').trim();
  };

  const handleAccountNumberChange = (value: string) => {
    // Remove spaces first to get raw digits
    const rawValue = value.replace(/\s/g, '');
    if (rawValue === "" || validateAccountNumber(rawValue)) {
      setFormData({
        ...formData,
        account_number: rawValue
      });
    }
  };
  const handleSave = async () => {
    if (!formData.bank_name || !formData.account_number || !formData.account_holder) {
      toast({
        title: "Error",
        description: "Semua field harus diisi",
        variant: "destructive"
      });
      return;
    }
    if (!validateAccountNumber(formData.account_number)) {
      toast({
        title: "Error",
        description: "Nomor rekening hanya boleh berisi angka",
        variant: "destructive"
      });
      return;
    }
    const verified = await requireSuperCode(editingId ? "memperbarui rekening" : "menambahkan rekening");
    if (!verified) return;
    setLoading(true);
    try {
      if (editingId) {
        const {
          error
        } = await supabase.from("bank_accounts" as any).update({
          bank_name: formData.bank_name,
          account_number: formData.account_number,
          account_holder: formData.account_holder,
          is_active: formData.is_active
        }).eq("id", editingId);
        if (error) throw error;
        toast({
          title: "Sukses",
          description: "Rekening berhasil diperbarui"
        });
      } else {
        const {
          error
        } = await supabase.from("bank_accounts" as any).insert({
          bank_name: formData.bank_name,
          account_number: formData.account_number,
          account_holder: formData.account_holder,
          is_primary: accounts.length === 0,
          is_active: formData.is_active
        });
        if (error) throw error;
        toast({
          title: "Sukses",
          description: "Rekening berhasil ditambahkan"
        });
      }
      setFormData({
        bank_name: "",
        account_number: "",
        account_holder: "",
        is_active: true
      });
      setEditingId(null);
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleEdit = (account: BankAccount) => {
    setEditingId(account.id);
    setFormData({
      bank_name: account.bank_name,
      account_number: account.account_number,
      account_holder: account.account_holder,
      is_active: account.is_active
    });
  };
  const handleDelete = async () => {
    if (!deleteId) return;
    const verified = await requireSuperCode("menghapus rekening");
    if (!verified) {
      setDeleteId(null);
      return;
    }
    try {
      const {
        error
      } = await supabase.from("bank_accounts" as any).delete().eq("id", deleteId);
      if (error) throw error;
      toast({
        title: "Sukses",
        description: "Rekening berhasil dihapus"
      });
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setDeleteId(null);
    }
  };
  const handleSetPrimary = async (id: string) => {
    const verified = await requireSuperCode("mengubah rekening utama");
    if (!verified) return;
    try {
      const {
        error
      } = await supabase.from("bank_accounts" as any).update({
        is_primary: true
      }).eq("id", id);
      if (error) throw error;
      toast({
        title: "Sukses",
        description: "Rekening utama berhasil diubah"
      });
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };
  const handleToggleActive = async (id: string, currentStatus: boolean) => {
    const verified = await requireSuperCode(currentStatus ? "menonaktifkan rekening" : "mengaktifkan rekening");
    if (!verified) return;
    try {
      const {
        error
      } = await supabase.from("bank_accounts" as any).update({
        is_active: !currentStatus
      }).eq("id", id);
      if (error) throw error;
      toast({
        title: "Sukses",
        description: `Rekening ${!currentStatus ? "diaktifkan" : "dinonaktifkan"}`
      });
      loadAccounts();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };
  const cancelEdit = () => {
    setEditingId(null);
    setFormData({
      bank_name: "",
      account_number: "",
      account_holder: "",
      is_active: true
    });
  };
  return <>
      <Card>
        <CardHeader>
          <CardTitle>Rekening Pembayaran Kredit</CardTitle>
          <CardDescription>
            Kelola rekening bank untuk pembayaran. Tandai satu sebagai rekening utama.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bank_name">Nama Bank</Label>
              <Input id="bank_name" placeholder="Contoh: BCA" value={formData.bank_name} onChange={e => setFormData({
              ...formData,
              bank_name: e.target.value.toUpperCase()
            })} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="account_number">Nomor Rekening</Label>
              <Input id="account_number" placeholder="Hanya angka" value={formatAccountNumber(formData.account_number)} onChange={e => handleAccountNumberChange(e.target.value)} />
              <p className="text-sm text-muted-foreground">
                Hanya boleh berisi angka
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="account_holder">Nama Pemegang Rekening</Label>
              <Input id="account_holder" placeholder="Nama sesuai rekening" value={formData.account_holder} onChange={e => setFormData({
              ...formData,
              account_holder: e.target.value.toUpperCase()
            })} />
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="is_active" checked={formData.is_active} onCheckedChange={checked => setFormData({
              ...formData,
              is_active: checked
            })} />
              <Label htmlFor="is_active">Aktif</Label>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={loading}>
                {editingId ? "Perbarui" : "Tambah"} Rekening
              </Button>
              {editingId && <Button variant="outline" onClick={cancelEdit}>
                  Batal
                </Button>}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium">Daftar Rekening</h3>
            {accounts.length === 0 ? <p className="text-sm text-muted-foreground">Belum ada rekening yang ditambahkan</p> : <div className="space-y-3">
                {accounts.map(account => <Card key={account.id} className={!account.is_active ? "opacity-60" : ""}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{account.bank_name}</p>
                            {account.is_primary && <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />}
                            {!account.is_active && <span className="text-xs text-muted-foreground">(Nonaktif)</span>}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {formatAccountNumber(account.account_number)}
                          </p>
                          <p className="text-sm">{account.account_holder}</p>
                        </div>
                        <div className="flex gap-2">
                          {!account.is_primary && <Button size="sm" variant="outline" onClick={() => handleSetPrimary(account.id)} title="Jadikan rekening utama">
                              <Star className="h-4 w-4" />
                            </Button>}
                          <Button size="sm" variant="outline" onClick={() => handleToggleActive(account.id, account.is_active)}>
                            {account.is_active ? "Nonaktifkan" : "Aktifkan"}
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleEdit(account)}>
                            Edit
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => setDeleteId(account.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>)}
              </div>}
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Rekening Bank?</AlertDialogTitle>
            <AlertDialogDescription>
              Aksi ini tidak dapat dibatalkan. Rekening akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>;
}