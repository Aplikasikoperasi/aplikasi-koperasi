import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Plus, Edit, Trash2, Copy, FileText } from "lucide-react";
import { useSuperCode } from "@/contexts/SuperCodeContext";

interface Template {
  id: string;
  name: string;
  category: string;
  title: string;
  content: string;
  variables: string[];
  is_active: boolean;
  created_at: string;
}

export default function WhatsAppTemplates() {
  const { requireSuperCode } = useSuperCode();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    name: "",
    category: "other" as string,
    title: "",
    content: "",
    variables: [] as string[],
    is_active: true
  });

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("whatsapp_message_templates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      const templatesData = (data || []).map(t => ({
        ...t,
        variables: Array.isArray(t.variables) ? t.variables as string[] : []
      }));
      setTemplates(templatesData);
    } catch (error) {
      console.error("Error loading templates:", error);
      toast.error("Gagal memuat template");
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (template?: Template) => {
    if (template) {
      setEditingTemplate(template);
      setFormData({
        name: template.name,
        category: template.category,
        title: template.title,
        content: template.content,
        variables: template.variables,
        is_active: template.is_active
      });
    } else {
      setEditingTemplate(null);
      setFormData({
        name: "",
        category: "other",
        title: "",
        content: "",
        variables: [],
        is_active: true
      });
    }
    setDialogOpen(true);
  };

  const extractVariables = (content: string): string[] => {
    const regex = /\{\{([^}]+)\}\}/g;
    const matches = content.match(regex) || [];
    return Array.from(new Set(matches.map(m => m.replace(/\{\{|\}\}/g, ""))));
  };

  const handleSave = async () => {
    if (!formData.name || !formData.title || !formData.content) {
      toast.error("Nama, judul, dan konten harus diisi");
      return;
    }

    const verified = await requireSuperCode(editingTemplate ? "memperbarui template" : "menyimpan template");
    if (!verified) return;

    try {
      const variables = extractVariables(formData.content);
      
      if (editingTemplate) {
        const { error } = await supabase
          .from("whatsapp_message_templates")
          .update({
            name: formData.name,
            category: formData.category,
            title: formData.title,
            content: formData.content,
            variables: variables,
            is_active: formData.is_active
          })
          .eq("id", editingTemplate.id);

        if (error) throw error;
        toast.success("Template berhasil diperbarui");
      } else {
        const { error } = await supabase
          .from("whatsapp_message_templates")
          .insert({
            name: formData.name,
            category: formData.category,
            title: formData.title,
            content: formData.content,
            variables: variables,
            is_active: formData.is_active
          });

        if (error) throw error;
        toast.success("Template berhasil ditambahkan");
      }

      setDialogOpen(false);
      loadTemplates();
    } catch (error: any) {
      console.error("Error saving template:", error);
      toast.error(error.message || "Gagal menyimpan template");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Yakin ingin menghapus template ini?")) return;

    const verified = await requireSuperCode("menghapus template");
    if (!verified) return;

    try {
      const { error } = await supabase
        .from("whatsapp_message_templates")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("Template berhasil dihapus");
      loadTemplates();
    } catch (error: any) {
      console.error("Error deleting template:", error);
      toast.error("Gagal menghapus template");
    }
  };

  const handleDuplicate = async (template: Template) => {
    try {
      const { error } = await supabase
        .from("whatsapp_message_templates")
        .insert({
          name: `${template.name}_copy`,
          category: template.category,
          title: `${template.title} (Copy)`,
          content: template.content,
          variables: template.variables,
          is_active: false
        });

      if (error) throw error;
      toast.success("Template berhasil diduplikasi");
      loadTemplates();
    } catch (error: any) {
      console.error("Error duplicating template:", error);
      toast.error("Gagal menduplikasi template");
    }
  };

  const getCategoryBadge = (category: string) => {
    const colors: Record<string, string> = {
      greeting: "bg-blue-500",
      promo: "bg-purple-500",
      announcement: "bg-orange-500",
      reminder: "bg-yellow-500",
      receipt: "bg-green-500",
      other: "bg-gray-500"
    };
    return <Badge className={colors[category] || colors.other}>{category}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold mb-2">Template Pesan WhatsApp</h2>
          <p className="text-muted-foreground">
            Kelola template pesan untuk berbagai keperluan
          </p>
        </div>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="h-4 w-4 mr-2" />
          Tambah Template
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        </div>
      ) : templates.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">Belum ada template</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">{template.title}</CardTitle>
                    <div className="flex items-center gap-2">
                      {getCategoryBadge(template.category)}
                      <Badge variant={template.is_active ? "default" : "secondary"}>
                        {template.is_active ? "Aktif" : "Nonaktif"}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleOpenDialog(template)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDuplicate(template)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(template.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-4">
                    {template.content}
                  </p>
                  {template.variables.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-2">
                      {template.variables.map((variable) => (
                        <Badge key={variable} variant="outline" className="text-xs">
                          {`{{${variable}}}`}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingTemplate ? "Edit Template" : "Tambah Template"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Nama Template *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="nama_template_tanpa_spasi"
              />
              <p className="text-xs text-muted-foreground">
                Gunakan huruf kecil dan underscore, contoh: promo_ramadan_2024
              </p>
            </div>

            <div className="space-y-2">
              <Label>Kategori *</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="greeting">Greeting</SelectItem>
                  <SelectItem value="promo">Promo</SelectItem>
                  <SelectItem value="announcement">Announcement</SelectItem>
                  <SelectItem value="reminder">Reminder</SelectItem>
                  <SelectItem value="receipt">Receipt</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Judul *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Judul template untuk ditampilkan"
              />
            </div>

            <div className="space-y-2">
              <Label>Konten Pesan *</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                placeholder="Tulis konten pesan di sini...&#10;&#10;Gunakan {{variable_name}} untuk variabel yang bisa diganti.&#10;Contoh: Halo {{customer_name}}, terima kasih!"
                rows={8}
              />
              <p className="text-xs text-muted-foreground">
                Variabel terdeteksi: {extractVariables(formData.content).join(", ") || "Tidak ada"}
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label>Template Aktif</Label>
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Batal
              </Button>
              <Button onClick={handleSave}>
                Simpan
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
