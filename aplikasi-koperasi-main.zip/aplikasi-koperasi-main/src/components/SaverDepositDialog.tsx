import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CurrencyInput } from "@/components/ui/currency-input";
import { DatePicker } from "@/components/ui/date-picker";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import { ArrowUpCircle, Loader2, Banknote, Building2, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { formatAccountNumber } from "@/lib/utils";

interface DepositAccount {
  id: string;
  bank_name: string;
  account_number: string;
  account_holder: string;
  is_primary: boolean;
}

interface SaverDepositDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saverId: string;
  saverName: string;
  currentBalance: number;
  onSuccess?: () => void;
}

export default function SaverDepositDialog({
  open,
  onOpenChange,
  saverId,
  saverName,
  currentBalance,
  onSuccess,
}: SaverDepositDialogProps) {
  const [amount, setAmount] = useState<string>("");
  const [depositDate, setDepositDate] = useState<Date>(new Date());
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [selectedAccountId, setSelectedAccountId] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [depositAccounts, setDepositAccounts] = useState<DepositAccount[]>([]);
  const { isOwner, isAdmin, isKasir } = useUserRole();

  // Fetch deposit accounts on dialog open
  useEffect(() => {
    const fetchDepositAccounts = async () => {
      const { data, error } = await supabase
        .from("deposit_accounts")
        .select("id, bank_name, account_number, account_holder, is_primary")
        .eq("is_active", true)
        .order("is_primary", { ascending: false })
        .order("bank_name");

      if (!error && data) {
        setDepositAccounts(data);
        // Auto-select primary account if exists
        const primaryAccount = data.find(acc => acc.is_primary);
        if (primaryAccount) {
          setSelectedAccountId(primaryAccount.id);
        }
      }
    };

    if (open) {
      fetchDepositAccounts();
    }
  }, [open]);

  const numericAmount = parseInt(amount || "0", 10);

  const handleSubmit = async () => {
    if (numericAmount <= 0) {
      toast.error("Jumlah deposit harus lebih dari 0");
      return;
    }

    setIsSubmitting(true);
    try {
      // Get current member info
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: member } = await supabase
        .from("members")
        .select("id, position")
        .eq("user_id", user.id)
        .single();

      if (!member) throw new Error("Member not found");

      const role = member.position?.toLowerCase();
      const isAutoApproved = role === 'owner' || role === 'admin';

      // Determine deposit status based on role
      // Owner/Admin deposits are auto-approved, others are pending verification
      const depositStatus = isAutoApproved ? 'approved' : 'pending';

      // Insert deposit transaction
      // If auto-approved, trigger will update saver balance automatically
      // If pending, balance will be updated when approved
      const { error: depositError } = await supabase
        .from("saver_deposits")
        .insert({
          saver_id: saverId,
          amount: numericAmount,
          deposit_date: format(depositDate, "yyyy-MM-dd"),
          remaining_balance: 0, // Will be recalculated when approved
          is_eligible_for_interest: true,
          total_interest_earned: 0,
          transaction_type: "deposit",
          notes,
          created_by: member.id,
          payment_method: paymentMethod,
          payment_details: paymentMethod === 'transfer' && selectedAccountId 
            ? (() => {
                const account = depositAccounts.find(a => a.id === selectedAccountId);
                return account ? `${account.bank_name} - ${account.account_number} a.n. ${account.account_holder}` : null;
              })()
            : null,
          status: depositStatus,
          approved_by: isAutoApproved ? member.id : null,
          approved_at: isAutoApproved ? new Date().toISOString() : null,
        });

      // If auto-approved, update saver balance immediately
      if (!depositError && isAutoApproved) {
        const { data: saverData } = await supabase
          .from("savers")
          .select("balance, deposit_balance")
          .eq("id", saverId)
          .single();
        
        if (saverData) {
          await supabase
            .from("savers")
            .update({
              balance: (saverData.balance || 0) + numericAmount,
              deposit_balance: (saverData.deposit_balance || 0) + numericAmount,
            })
            .eq("id", saverId);
        }
      }

      if (depositError) throw depositError;

      const successMessage = isAutoApproved 
        ? "Deposit berhasil ditambahkan" 
        : "Deposit berhasil diajukan, menunggu verifikasi Owner/Admin";
      toast.success(successMessage);
      
      // Reset form
      setAmount("");
      setNotes("");
      setDepositDate(new Date());
      setPaymentMethod("cash");
      setSelectedAccountId("");
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error("Error adding deposit:", error);
      toast.error(`Gagal menambahkan deposit: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowUpCircle className="h-5 w-5 text-green-600" />
            Tambah Deposit
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-3 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">Debitur</p>
            <p className="font-semibold">{saverName}</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Jumlah Deposit</Label>
            <CurrencyInput
              id="amount"
              value={amount}
              onChange={(val) => setAmount(val)}
              placeholder="Masukkan jumlah deposit"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="deposit-date">Tanggal Deposit</Label>
            <DatePicker
              value={depositDate}
              onChange={(date) => date && setDepositDate(date)}
              maxDate={new Date()}
            />
          </div>

          <div className="space-y-2">
            <Label>Metode Pembayaran</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">
                  <div className="flex items-center gap-2">
                    <Banknote className="h-4 w-4 text-green-600" />
                    <span>Tunai (Cash)</span>
                  </div>
                </SelectItem>
                <SelectItem value="transfer">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-blue-500" />
                    <span>Transfer Bank</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {paymentMethod === 'transfer' && (
            <div className="space-y-2">
              <Label>Rekening Tujuan Transfer</Label>
              {depositAccounts.length === 0 ? (
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-destructive" />
                  <p className="text-sm text-destructive">
                    Belum ada rekening simpanan yang dikonfigurasi. Hubungi Owner untuk menambahkan rekening.
                  </p>
                </div>
              ) : (
                <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih rekening tujuan" />
                  </SelectTrigger>
                  <SelectContent>
                    {depositAccounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        <div className="flex flex-col">
                          <span className="font-medium font-mono">
                            {account.bank_name} - {formatAccountNumber(account.account_number)}
                            {account.is_primary && " ⭐"}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            a.n. {account.account_holder}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan (Opsional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Catatan tambahan..."
              rows={2}
            />
          </div>

          {isKasir && !isOwner && !isAdmin && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-sm text-amber-700 dark:text-amber-300">
                ⚠️ Deposit akan menunggu verifikasi dari Owner/Admin
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Batal
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || numericAmount <= 0}>
            {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {isKasir && !isOwner && !isAdmin ? "Ajukan Deposit" : "Simpan Deposit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
