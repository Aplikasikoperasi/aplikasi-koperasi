import { formatRupiah } from "@/lib/utils";

// Lazy load pdfmake to avoid bundle size issues
let pdfMakeInstance: any = null;

async function loadPdfMake() {
  if (pdfMakeInstance) return pdfMakeInstance;
  
  const pdfMake = await import('pdfmake/build/pdfmake');
  const pdfFonts = await import('pdfmake/build/vfs_fonts');
  
  const vfs = pdfFonts.default?.pdfMake?.vfs || pdfFonts.default?.vfs || pdfFonts.pdfMake?.vfs;
  
  if (pdfMake.default) {
    pdfMake.default.vfs = vfs;
    pdfMakeInstance = pdfMake.default;
  } else if (pdfMake) {
    (pdfMake as any).vfs = vfs;
    pdfMakeInstance = pdfMake;
  }
  
  return pdfMakeInstance;
}

// Helper function to convert image URL to base64
async function getBase64FromUrl(url: string): Promise<string | null> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('Error loading image:', error);
    return null;
  }
}

export interface NamePlateData {
  businessName: string;
  logoUrl?: string;
  customerName: string;
  customerId: string;
  customerPhotoUrl?: string;
  applicationNumber: string;
  applicationDate?: string;
  loanAmount: number;
  tenorMonths: number;
  memberName?: string; // PJ Kredit
}

export async function generateNamePlatePDF(data: NamePlateData, action: 'print' | 'download') {
  const pdfMake = await loadPdfMake();
  
  const {
    businessName,
    logoUrl,
    customerName,
    customerId,
    customerPhotoUrl,
    applicationNumber,
    applicationDate,
    loanAmount,
    tenorMonths,
    memberName
  } = data;

  // Try to load logo if URL provided
  let logoBase64: string | null = null;
  if (logoUrl) {
    logoBase64 = await getBase64FromUrl(logoUrl);
  }

  // Try to load customer photo if URL provided
  let customerPhotoBase64: string | null = null;
  if (customerPhotoUrl) {
    customerPhotoBase64 = await getBase64FromUrl(customerPhotoUrl);
  }

  // Format application date
  const formattedAppDate = applicationDate 
    ? new Date(applicationDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
    : '-';

  // Page inner width for lines (page width 400 - margins 30 - border 6 = ~364)
  const lineWidth = 340;

  // Build content - single layer layout
  const content: any[] = [
    // Single table with all content
    {
      table: {
        widths: ['*'],
        body: [
          // Header row with logo and business name - centered, bigger business name
          [
            {
              stack: logoBase64 ? [
                {
                  columns: [
                    { width: '*', text: '' },
                    {
                      image: logoBase64,
                      width: 36,
                      height: 36,
                    },
                    {
                      text: businessName || 'Sistem Kredit',
                      style: 'businessNameLarge',
                      margin: [8, 4, 0, 0],
                      width: 'auto'
                    },
                    { width: '*', text: '' }
                  ],
                  columnGap: 0
                }
              ] : [
                {
                  text: businessName || 'Sistem Kredit',
                  style: 'businessNameLarge',
                  alignment: 'center'
                }
              ],
              alignment: 'center',
              margin: [8, 8, 8, 6]
            }
          ],
          // Full width decorative line
          [
            {
              canvas: [
                {
                  type: 'line',
                  x1: 10,
                  y1: 0,
                  x2: lineWidth,
                  y2: 0,
                  lineWidth: 2,
                  lineColor: '#3b82f6'
                }
              ],
              margin: [0, 0, 0, 8]
            }
          ],
          // Customer photo + name + ID section - fixed widths
          [
            {
              columns: [
                // Customer photo on left - fixed width
                {
                  width: 60,
                  stack: [
                    customerPhotoBase64 ? {
                      image: customerPhotoBase64,
                      width: 45,
                      height: 45,
                      fit: [45, 45]
                    } : {
                      canvas: [
                        { type: 'rect', x: 0, y: 0, w: 45, h: 45, r: 3, lineWidth: 1, lineColor: '#cbd5e1' }
                      ],
                      width: 45
                    }
                  ],
                  margin: [10, 0, 0, 0]
                },
                // Name and ID on right - takes remaining space
                {
                  width: '*',
                  stack: [
                    { text: 'NAMA NASABAH', style: 'label' },
                    { text: customerName.toUpperCase(), style: 'customerName', margin: [0, 2, 0, 4] },
                    { text: 'NO. ID NASABAH', style: 'label' },
                    { text: customerId, style: 'value', margin: [0, 2, 0, 0] }
                  ],
                  margin: [0, 0, 10, 0]
                }
              ],
              columnGap: 5,
              margin: [0, 0, 0, 6]
            }
          ],
          // Separator line
          [
            {
              canvas: [
                {
                  type: 'line',
                  x1: 10,
                  y1: 0,
                  x2: lineWidth,
                  y2: 0,
                  lineWidth: 1,
                  lineColor: '#94a3b8',
                  dash: { length: 5, space: 3 }
                }
              ],
              margin: [0, 0, 0, 6]
            }
          ],
          // Details in 2 columns - now with application date
          [
            {
              columns: [
                {
                  stack: [
                    { text: 'JUMLAH PINJAMAN', style: 'label', alignment: 'center' },
                    { text: formatRupiah(loanAmount), style: 'amountValue', alignment: 'center', margin: [0, 2, 0, 6] },
                    { text: 'TGL PENGAJUAN', style: 'label', alignment: 'center' },
                    { text: formattedAppDate, style: 'value', alignment: 'center', margin: [0, 2, 0, 6] },
                    { text: 'PJ KREDIT', style: 'label', alignment: 'center' },
                    { text: memberName?.toUpperCase() || '-', style: 'memberValue', alignment: 'center', margin: [0, 2, 0, 0] }
                  ],
                  width: '50%'
                },
                {
                  stack: [
                    { text: 'TENOR', style: 'label', alignment: 'center' },
                    { text: `${tenorMonths} BULAN`, style: 'tenorValue', alignment: 'center', margin: [0, 2, 0, 6] },
                    { text: 'NO. APLIKASI', style: 'label', alignment: 'center' },
                    { text: applicationNumber, style: 'appNumberValue', alignment: 'center', margin: [0, 2, 0, 0] }
                  ],
                  width: '50%'
                }
              ],
              margin: [0, 0, 0, 8]
            }
          ]
        ]
      },
      layout: {
        hLineWidth: (i: number, node: any) => (i === 0 || i === node.table.body.length) ? 3 : 0,
        vLineWidth: () => 3,
        hLineColor: () => '#3b82f6',
        vLineColor: () => '#3b82f6',
      }
    }
  ];

  const docDefinition = {
    pageSize: { width: 400, height: 300 }, // Single layer with enough space
    pageMargins: [15, 15, 15, 15],
    content,
    styles: {
      businessNameLarge: { 
        fontSize: 22, 
        bold: true,
        color: '#1e40af',
        font: 'Roboto'
      },
      label: {
        fontSize: 7,
        color: '#64748b',
        bold: true,
        letterSpacing: 1
      },
      customerName: {
        fontSize: 13,
        bold: true,
        color: '#0f172a',
      },
      value: {
        fontSize: 9,
        bold: true,
        color: '#334155',
      },
      amountValue: {
        fontSize: 11,
        bold: true,
        color: '#059669',
      },
      tenorValue: {
        fontSize: 11,
        bold: true,
        color: '#7c3aed',
      },
      memberValue: {
        fontSize: 9,
        bold: true,
        color: '#0369a1',
      },
      appNumberValue: {
        fontSize: 8,
        bold: true,
        color: '#334155',
      }
    },
    defaultStyle: {
      font: 'Roboto',
      fontSize: 10,
    }
  } as any;

  const pdfDoc = pdfMake.createPdf(docDefinition);
  
  if (action === 'print') {
    // Open PDF in new tab where user can print it
    pdfDoc.open();
  } else {
    const fileName = `NamePlate_${applicationNumber}_${customerName.replace(/\s+/g, '_')}.pdf`;
    pdfDoc.download(fileName);
  }
}

// Helper function to create a single name plate content block for grid layout
async function createNamePlateBlockAsync(data: NamePlateData, logoBase64: string | null, customerPhotosCache: Map<string, string | null>) {
  // Line width for grid layout (each card is ~370pt wide)
  const lineWidth = 340;
  
  // Get customer photo from cache or load it
  let customerPhotoBase64: string | null = null;
  if (data.customerPhotoUrl) {
    if (customerPhotosCache.has(data.customerPhotoUrl)) {
      customerPhotoBase64 = customerPhotosCache.get(data.customerPhotoUrl) || null;
    } else {
      customerPhotoBase64 = await getBase64FromUrl(data.customerPhotoUrl);
      customerPhotosCache.set(data.customerPhotoUrl, customerPhotoBase64);
    }
  }

  // Format application date
  const formattedAppDate = data.applicationDate 
    ? new Date(data.applicationDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
    : '-';
  
  return {
    table: {
      widths: ['*'],
      body: [
        // Header row with logo and business name
        [
          {
            stack: logoBase64 ? [
              {
                columns: [
                  { width: '*', text: '' },
                  {
                    image: logoBase64,
                    width: 28,
                    height: 28,
                  },
                  {
                    text: data.businessName || 'Sistem Kredit',
                    style: 'businessNameSmall',
                    margin: [6, 3, 0, 0],
                    width: 'auto'
                  },
                  { width: '*', text: '' }
                ],
                columnGap: 0
              }
            ] : [
              {
                text: data.businessName || 'Sistem Kredit',
                style: 'businessNameSmall',
                alignment: 'center'
              }
            ],
            alignment: 'center',
            margin: [6, 6, 6, 4]
          }
        ],
        // Decorative line
        [
          {
            canvas: [
              {
                type: 'line',
                x1: 8,
                y1: 0,
                x2: lineWidth,
                y2: 0,
                lineWidth: 2,
                lineColor: '#3b82f6'
              }
            ],
            margin: [0, 0, 0, 6]
          }
        ],
        // Customer photo + name + ID section - fixed widths
        [
          {
            columns: [
              // Customer photo on left - fixed width
              {
                width: 50,
                stack: [
                  customerPhotoBase64 ? {
                    image: customerPhotoBase64,
                    width: 38,
                    height: 38,
                    fit: [38, 38]
                  } : {
                    canvas: [
                      { type: 'rect', x: 0, y: 0, w: 38, h: 38, r: 3, lineWidth: 1, lineColor: '#cbd5e1' }
                    ],
                    width: 38
                  }
                ],
                margin: [8, 0, 0, 0]
              },
              // Name and ID on right - takes remaining space
              {
                width: '*',
                stack: [
                  { text: 'NAMA NASABAH', style: 'labelSmall' },
                  { text: data.customerName.toUpperCase(), style: 'customerNameSmall', margin: [0, 2, 0, 3] },
                  { text: 'NO. ID NASABAH', style: 'labelSmall' },
                  { text: data.customerId, style: 'valueSmall', margin: [0, 2, 0, 0] }
                ],
                margin: [0, 0, 8, 0]
              }
            ],
            columnGap: 4,
            margin: [0, 0, 0, 4]
          }
        ],
        // Separator line
        [
          {
            canvas: [
              {
                type: 'line',
                x1: 8,
                y1: 0,
                x2: lineWidth,
                y2: 0,
                lineWidth: 1,
                lineColor: '#94a3b8',
                dash: { length: 4, space: 3 }
              }
            ],
            margin: [0, 0, 0, 4]
          }
        ],
        // Details in 2 columns - with application date
        [
          {
            columns: [
              {
                stack: [
                  { text: 'JUMLAH PINJAMAN', style: 'labelSmall', alignment: 'center' },
                  { text: formatRupiah(data.loanAmount), style: 'amountValueSmall', alignment: 'center', margin: [0, 2, 0, 4] },
                  { text: 'TGL PENGAJUAN', style: 'labelSmall', alignment: 'center' },
                  { text: formattedAppDate, style: 'valueSmall', alignment: 'center', margin: [0, 2, 0, 4] },
                  { text: 'PJ KREDIT', style: 'labelSmall', alignment: 'center' },
                  { text: data.memberName?.toUpperCase() || '-', style: 'memberValueSmall', alignment: 'center', margin: [0, 2, 0, 0] }
                ],
                width: '50%'
              },
              {
                stack: [
                  { text: 'TENOR', style: 'labelSmall', alignment: 'center' },
                  { text: `${data.tenorMonths} BULAN`, style: 'tenorValueSmall', alignment: 'center', margin: [0, 2, 0, 4] },
                  { text: 'NO. APLIKASI', style: 'labelSmall', alignment: 'center' },
                  { text: data.applicationNumber, style: 'appNumberSmall', alignment: 'center', margin: [0, 2, 0, 0] }
                ],
                width: '50%'
              }
            ],
            margin: [0, 0, 0, 6]
          }
        ]
      ]
    },
    layout: {
      hLineWidth: (i: number, node: any) => (i === 0 || i === node.table.body.length) ? 2.5 : 0,
      vLineWidth: () => 2,
      hLineColor: () => '#3b82f6',
      vLineColor: () => '#3b82f6',
    }
  };
}

// Generate multiple name plates in a single PDF (4 per page - 2x2 grid)
export async function generateBulkNamePlatePDF(
  dataArray: NamePlateData[], 
  action: 'print' | 'download',
  onProgress?: (current: number, total: number) => void
) {
  if (dataArray.length === 0) {
    throw new Error('Tidak ada data untuk dicetak');
  }

  const pdfMake = await loadPdfMake();
  
  // Load logo once for all pages
  const firstData = dataArray[0];
  let logoBase64: string | null = null;
  if (firstData.logoUrl) {
    logoBase64 = await getBase64FromUrl(firstData.logoUrl);
  }

  const allContent: any[] = [];
  const ITEMS_PER_PAGE = 4; // 2x2 grid
  const customerPhotosCache = new Map<string, string | null>();

  // Process data in chunks of 4
  for (let pageIndex = 0; pageIndex < Math.ceil(dataArray.length / ITEMS_PER_PAGE); pageIndex++) {
    const startIdx = pageIndex * ITEMS_PER_PAGE;
    const pageItems = dataArray.slice(startIdx, startIdx + ITEMS_PER_PAGE);
    
    onProgress?.(Math.min(startIdx + ITEMS_PER_PAGE, dataArray.length), dataArray.length);

    // Add page break before each page except the first
    if (pageIndex > 0) {
      allContent.push({ text: '', pageBreak: 'before' });
    }

    // Create 2x2 grid layout
    // Row 1 (items 0 and 1)
    const row1Items = pageItems.slice(0, 2);
    if (row1Items.length > 0) {
      const row1Blocks = await Promise.all(
        row1Items.map(item => createNamePlateBlockAsync(item, logoBase64, customerPhotosCache))
      );
      allContent.push({
        columns: row1Blocks.map(block => ({
          width: '50%',
          stack: [block],
          margin: [8, 8, 8, 8]
        })),
        columnGap: 15
      });
    }

    // Row 2 (items 2 and 3)
    const row2Items = pageItems.slice(2, 4);
    if (row2Items.length > 0) {
      const row2Blocks = await Promise.all(
        row2Items.map(item => createNamePlateBlockAsync(item, logoBase64, customerPhotosCache))
      );
      allContent.push({
        columns: row2Blocks.map(block => ({
          width: '50%',
          stack: [block],
          margin: [8, 8, 8, 8]
        })),
        columnGap: 15,
        margin: [0, 15, 0, 0]
      });
    }
  }

  const docDefinition = {
    pageSize: 'A4',
    pageOrientation: 'landscape',
    pageMargins: [15, 15, 15, 15],
    content: allContent,
    styles: {
      businessNameSmall: { 
        fontSize: 18, 
        bold: true,
        color: '#1e40af',
        font: 'Roboto'
      },
      labelSmall: {
        fontSize: 7,
        color: '#64748b',
        bold: true,
        letterSpacing: 0.5
      },
      customerNameSmall: {
        fontSize: 11,
        bold: true,
        color: '#0f172a',
      },
      valueSmall: {
        fontSize: 9,
        bold: true,
        color: '#334155',
      },
      amountValueSmall: {
        fontSize: 10,
        bold: true,
        color: '#059669',
      },
      tenorValueSmall: {
        fontSize: 10,
        bold: true,
        color: '#7c3aed',
      },
      memberValueSmall: {
        fontSize: 8,
        bold: true,
        color: '#0369a1',
      },
      appNumberSmall: {
        fontSize: 7,
        bold: true,
        color: '#334155',
      }
    },
    defaultStyle: {
      font: 'Roboto',
      fontSize: 9,
    }
  } as any;

  const pdfDoc = pdfMake.createPdf(docDefinition);
  
  if (action === 'print') {
    // Open PDF in new tab where user can print it
    pdfDoc.open();
    return dataArray.length;
  } else {
    const fileName = `NamePlate_Bulk_${dataArray.length}_Kredit_${new Date().toISOString().split('T')[0]}.pdf`;
    pdfDoc.download(fileName);
    return dataArray.length;
  }
}
