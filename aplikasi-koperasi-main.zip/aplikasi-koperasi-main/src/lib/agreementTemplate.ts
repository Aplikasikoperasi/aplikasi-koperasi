import { formatRupiah, formatDate } from "@/lib/utils";

export interface AgreementData {
  customer: {
    full_name: string;
    date_of_birth?: string;
    nik?: string;
    address: string;
    occupation?: string;
    phone: string;
    photo_url?: string;
  };
  ownerMember: {
    full_name: string;
    date_of_birth?: string;
    nik?: string;
    address?: string;
    occupation?: string;
    phone?: string;
  };
  witnessName: string;
  applicationDate: Date;
  amount: number;
  tenor: number;
  interestRate: number;
  monthlyInstallment: number;
  isShortTenor: boolean;
  firstInstallmentDeducted: boolean;
  adminFee: number;
  adminFeePercentage: number;
  netDisbursement: number;
  firstInstallmentDate: Date;
  collateralDescription?: string;
  penaltyRate: number;
}

// Indonesian days and months
const DAYS = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

// Helper to format date components
export function getDateComponents(date: Date) {
  return {
    dayName: DAYS[date.getDay()],
    day: date.getDate(),
    month: MONTHS[date.getMonth()],
    year: date.getFullYear(),
  };
}

// Generate all template content from agreement data
export function generateTemplateContent(data: AgreementData) {
  const appDate = getDateComponents(data.applicationDate);
  const firstInstDate = getDateComponents(data.firstInstallmentDate);
  
  const rupiah = (v: number) => formatRupiah(v);

  // Customer info fields
  const customerInfo = [
    { label: "Nama", value: data.customer.full_name },
    { label: "T.Tgl Lahir", value: data.customer.date_of_birth ? formatDate(data.customer.date_of_birth) : "-" },
    { label: "NIK", value: data.customer.nik || "-" },
    { label: "Alamat", value: data.customer.address },
    { label: "Pekerjaan", value: data.customer.occupation || "-" },
    { label: "Telepon", value: data.customer.phone },
  ];

  // Owner info fields
  const ownerInfo = [
    { label: "Nama", value: data.ownerMember.full_name },
    { label: "T.Tgl Lahir", value: data.ownerMember.date_of_birth ? formatDate(data.ownerMember.date_of_birth) : "-" },
    { label: "NIK", value: data.ownerMember.nik || "-" },
    { label: "Alamat", value: data.ownerMember.address || "-" },
    { label: "Pekerjaan", value: data.ownerMember.occupation || "Wiraswasta" },
    { label: "Telepon", value: data.ownerMember.phone || "-" },
  ];

  // Agreement points
  const pointA = `a. Dengan ini menyatakan, bahwa PIHAK PERTAMA telah dengan sah dan benar menerima titipan modal kerja kepada PIHAK KEDUA, sebesar ${rupiah(data.amount)}.`;

  const agreementPoints = data.collateralDescription
    ? [
        pointA,
        `b. PIHAK PERTAMA memberikan ${data.collateralDescription} sebagai jaminan atas Pinjaman ini dan akan dikembalikan apabila PIHAK PERTAMA melunasi segala tagihan nya baik pokok, bunga maupun dendanya (apabila ada).`,
        `c. PIHAK PERTAMA mengakui telah menerima sejumlah uang tersebut secara lengkap dari PIHAK KEDUA dan memberikan Jaminan tersebut secara sadar dan tanpa ada unsur paksaan, sebelum penandatanganan Surat Perjanjian ini, sehingga Surat Perjanjian ini diakui oleh kedua belah pihak dan berlaku sebagai tanda penerimaan yang sah secara hukum yang berlaku.`,
        `d. Kedua belah pihak telah bersepakat untuk mengadakan serta mengikatkan diri terhadap syarat-syarat serta ketetapan-ketetapan dalam perjanjian ini yang diatur dalam 7 (Tujuh) pasal sebagai berikut:`,
      ]
    : [
        pointA,
        `b. PIHAK PERTAMA mengakui telah menerima sejumlah uang tersebut secara lengkap dari PIHAK KEDUA secara sadar dan tanpa ada unsur paksaan, sebelum penandatanganan Surat Perjanjian ini, sehingga Surat Perjanjian ini diakui oleh kedua belah pihak dan berlaku sebagai tanda penerimaan yang sah secara hukum yang berlaku.`,
        `c. Kedua belah pihak telah bersepakat untuk mengadakan serta mengikatkan diri terhadap syarat-syarat serta ketetapan-ketetapan dalam perjanjian ini yang diatur dalam 7 (Tujuh) pasal sebagai berikut:`,
      ];

  // Pasal 1 - PEMBAYARAN
  const pasal1Content = `PIHAK PERTAMA berjanji akan membayar titipan sebesar ${rupiah(data.amount)} tersebut dengan cara menyicil selama ${data.tenor} Bulan. ${
    data.firstInstallmentDeducted
      ? `Angsuran pertama telah dipotong saat pencairan, sehingga pembayaran dilakukan untuk sisa ${data.tenor - 1} angsuran dimulai dari tanggal ${firstInstDate.day} Bulan ${firstInstDate.month} Tahun ${firstInstDate.year}.`
      : `Pembayaran dilakukan setiap bulannya dimulai dari tanggal ${firstInstDate.day} Bulan ${firstInstDate.month} Tahun ${firstInstDate.year}.`
  } Dikenakan bunga sebesar ${data.interestRate}% sehingga jumlah angsuran setiap bulan yang harus dibayarkan adalah sebesar ${rupiah(data.monthlyInstallment)}.${
    data.isShortTenor ? " Untuk tenor 1-3 bulan, angsuran pertama otomatis dimulai di bulan berikutnya setelah pencairan." : ""
  } Apabila PIHAK PERTAMA tidak membayarkan cicilan tersebut tepat waktu, maka akan dikenakan denda administrasi sebesar ${data.penaltyRate}% perhari dari nilai total angsuran yang sedang jatuh tempo.`;

  // Pasal 2 - PELANGGARAN
  const pasal2Content = "Jika PIHAK PERTAMA lalai atau tidak dapat memenuhi seluruh kewajibannya sebagaimana ditetapkan dalam Surat Perjanjian ini dan atau apabila terjadi pelanggaran oleh PIHAK PERTAMA atas salah satu atau beberapa kewajibannya sebagaimana yang disebutkan dalam Surat Perjanjian ini, maka PIHAK KEDUA berhak menagih segera secara sekaligus jumlah hutang pinjaman tersebut meskipun jatuh tempo perjanjian ini belum dicapai, dan berhak melaporkan PIHAK PERTAMA kepada Pihak Berwajib dalam hal Ini Kepolisian Republik Indonesia.";

  // Pasal 3 - HAL-HAL YANG TIDAK DIINGINKAN
  const pasal3Intro = "PIHAK KEDUA berhak menagih kembali seluruh uang hutang PIHAK PERTAMA secara sekaligus, apabila:";
  const pasal3Points = [
    "1. PIHAK PERTAMA dinyatakan bangkrut atau pailit oleh Pengadilan sebelum tanggal jatuh tempo perjanjian ini dicapai.",
    "2. PIHAK PERTAMA meninggal dunia sebelum tanggal jatuh tempo perjanjian ini, kecuali jika ahli waris PIHAK PERTAMA sanggup dan bersedia memenuhi kewajiban-kewajiban yang berkaitan dengan isi Surat Perjanjian ini.",
  ];

  // Pasal 4 - BIAYA PENAGIHAN
  const pasal4Content = "Semua biaya penagihan hutang tersebut di atas, termasuk biaya juru sita dan biaya-biaya kuasa PIHAK KEDUA untuk menagih hutang tersebut, menjadi tanggungan dan wajib dibayarkan oleh PIHAK PERTAMA.";

  // Pasal 5 - BIAYA-BIAYA LAINNYA
  const pasal5Content = "Biaya pembuatan Surat Perjanjian ini dan segala biaya yang berhubungan dengan hutang pinjaman tersebut di atas menjadi tanggungan dan wajib dibayarkan oleh PIHAK PERTAMA kepada PIHAK KEDUA.";

  // Pasal 6 - PENYELESAIAN PERSELISIHAN
  const pasal6Content = "Jika terjadi perselisihan dalam pelaksanaan perjanjian ini, para pihak sepakat untuk menyelesaikannya secara musyawarah untuk mufakat. Dalam hal musyawarah tidak tercapai, para pihak sepakat menyelesaikan perselisihan tersebut melalui Pengadilan Negeri setempat.";

  // Pasal 7 - PENUTUP
  const pasal7Content = "Demikianlah Surat Perjanjian ini dibuat dan ditandatangani oleh kedua belah pihak dalam keadaan sadar dan tanpa ada paksaan dari pihak manapun.";

  return {
    // Header
    title: "SURAT PERJANJIAN PENITIPAN MODAL",
    
    // Opening
    opening: `Pada hari ini ${appDate.dayName}, ${appDate.day} ${appDate.month} ${appDate.year}, kami yang bertanda tangan di bawah ini:`,
    
    // Party info
    customerInfo,
    ownerInfo,
    customerPhotoUrl: data.customer.photo_url,
    pihakPertamaClosing: "Bertindak untuk dan atas nama diri sendiri dan untuk selanjutnya disebut PIHAK PERTAMA.",
    pihakKeduaClosing: "Bertindak untuk dan atas nama diri sendiri dan untuk selanjutnya disebut PIHAK KEDUA.",
    
    // Agreement points
    agreementPoints,
    
    // Pasal content - keepTogether: true means title should stay with content (no page break between)
    pasals: [
      { number: 1, title: "PEMBAYARAN", content: pasal1Content, keepTogether: true },
      { number: 2, title: "PELANGGARAN", content: pasal2Content, keepTogether: true },
      { number: 3, title: "HAL-HAL YANG TIDAK DIINGINKAN", intro: pasal3Intro, points: pasal3Points, keepTogether: true },
      { number: 4, title: "BIAYA PENAGIHAN", content: pasal4Content, keepTogether: true },
      { number: 5, title: "BIAYA-BIAYA LAINNYA", content: pasal5Content, keepTogether: true },
      { number: 6, title: "PENYELESAIAN PERSELISIHAN", content: pasal6Content, keepTogether: true },
      { number: 7, title: "PENUTUP", content: pasal7Content, keepTogether: true },
    ],
    
    // Signature section settings
    signatureKeepTogether: true, // Keep all signatures on same page
    
    // Agreement date
    agreementDate: `Tanggal Perjanjian: ${appDate.day} ${appDate.month} ${appDate.year}`,
    
    // Signatures
    signatures: [
      { role: "PIHAK PERTAMA,", name: data.customer.full_name, label: "Tanda Tangan & Materai" },
      { role: "PIHAK KEDUA,", name: data.ownerMember.full_name, label: "Tanda Tangan" },
      { role: "SAKSI,", name: data.witnessName, label: "Tanda Tangan" },
    ],
  };
}

export type TemplateContent = ReturnType<typeof generateTemplateContent>;

// Generate WhatsApp message from agreement data
export function generateAgreementWhatsAppMessage(data: AgreementData, applicationNumber: string): string {
  const rupiah = (v: number) => formatRupiah(v);
  const appDate = getDateComponents(data.applicationDate);
  const firstInstDate = getDateComponents(data.firstInstallmentDate);
  
  let message = `*SURAT PERJANJIAN PENITIPAN MODAL*\n\n`;
  message += `Pada hari ${appDate.dayName}, ${appDate.day} ${appDate.month} ${appDate.year}\n\n`;
  
  message += `Kepada Yth.\n*${data.customer.full_name}*\n`;
  if (data.customer.nik) {
    message += `NIK: ${data.customer.nik}\n`;
  }
  message += `Alamat: ${data.customer.address}\n\n`;
  
  message += `-----------------------------------\n`;
  message += `*RINCIAN PERJANJIAN KREDIT*\n`;
  message += `-----------------------------------\n`;
  message += `📋 No. Aplikasi: ${applicationNumber}\n`;
  message += `💰 Jumlah Pinjaman: ${rupiah(data.amount)}\n`;
  message += `📊 Bunga: ${data.interestRate}%\n`;
  message += `📅 Tenor: ${data.tenor} Bulan\n`;
  message += `💳 Angsuran/Bulan: ${rupiah(data.monthlyInstallment)}\n\n`;
  
  // Rincian potongan
  if (data.adminFee > 0 || data.firstInstallmentDeducted) {
    message += `*Rincian Potongan:*\n`;
    if (data.adminFee > 0) {
      message += `📝 Biaya Admin (${data.adminFeePercentage}%): ${rupiah(data.adminFee)}\n`;
    }
    if (data.firstInstallmentDeducted) {
      message += `📝 Angsuran Pertama: ${rupiah(data.monthlyInstallment)}\n`;
    }
    message += `\n`;
  }
  
  message += `💵 *Dana Diterima: ${rupiah(data.netDisbursement)}*\n\n`;
  
  message += `-----------------------------------\n`;
  message += `*JADWAL PEMBAYARAN*\n`;
  message += `-----------------------------------\n`;
  
  if (data.isShortTenor) {
    message += `ℹ️ *Khusus Tenor 1-3 Bulan:*\n`;
    message += `Angsuran pertama dimulai di bulan berikutnya\n\n`;
  }
  
  if (data.firstInstallmentDeducted) {
    message += `✅ Angsuran pertama telah dipotong saat pencairan\n`;
    message += `📆 Sisa ${data.tenor - 1} angsuran dimulai: ${firstInstDate.day} ${firstInstDate.month} ${firstInstDate.year}\n\n`;
  } else {
    message += `📆 Angsuran pertama: ${firstInstDate.day} ${firstInstDate.month} ${firstInstDate.year}\n`;
    message += `📆 Total: ${data.tenor} angsuran\n\n`;
  }
  
  // Jaminan jika ada
  if (data.collateralDescription) {
    message += `🔒 *Jaminan:* ${data.collateralDescription}\n\n`;
  }
  
  message += `-----------------------------------\n`;
  message += `⚠️ *KETENTUAN PENTING*\n`;
  message += `-----------------------------------\n`;
  message += `• Denda ${data.penaltyRate}% per hari jika terlambat\n`;
  message += `• Bayar tepat waktu setiap tanggal ${firstInstDate.day}\n`;
  message += `• Kegagalan pembayaran dapat dilaporkan ke pihak berwajib\n`;
  message += `• Simpan dokumen perjanjian dengan baik\n\n`;
  
  message += `-----------------------------------\n`;
  message += `Perjanjian ini dibuat oleh:\n`;
  message += `*PIHAK PERTAMA:* ${data.customer.full_name}\n`;
  message += `*PIHAK KEDUA:* ${data.ownerMember.full_name}\n`;
  message += `*SAKSI:* ${data.witnessName}\n\n`;
  
  message += `Terima kasih atas kepercayaan Anda! 🙏`;
  
  return message;
}
