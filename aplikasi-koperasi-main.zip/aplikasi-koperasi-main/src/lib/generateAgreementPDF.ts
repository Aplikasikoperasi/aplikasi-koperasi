import { generateTemplateContent, AgreementData } from "@/lib/agreementTemplate";

// Lazy load pdfmake
let pdfMakeInstance: any = null;

async function loadPdfMake() {
  if (pdfMakeInstance) return pdfMakeInstance;
  
  const pdfMake = await import('pdfmake/build/pdfmake');
  const pdfFonts = await import('pdfmake/build/vfs_fonts');
  
  const vfs = pdfFonts.default?.pdfMake?.vfs || pdfFonts.default?.vfs || pdfFonts.pdfMake?.vfs;
  
  if (pdfMake.default) {
    pdfMake.default.vfs = vfs;
    pdfMakeInstance = pdfMake.default;
  } else if (pdfMake) {
    (pdfMake as any).vfs = vfs;
    pdfMakeInstance = pdfMake;
  }
  
  return pdfMakeInstance;
}

async function getImageBase64(url: string): Promise<string | null> {
  try {
    if (!url) return null;
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('Error loading image for PDF:', error);
    return null;
  }
}

export async function generateAgreementPDF(agreementData: AgreementData, action: 'print' | 'download') {
  const pdfMake = await loadPdfMake();
  const template = generateTemplateContent(agreementData);
  
  // Load customer photo if available
  const customerPhotoBase64 = template.customerPhotoUrl ? await getImageBase64(template.customerPhotoUrl) : null;

  // Customer info rows for table
  const customerInfoRows = template.customerInfo.map(info => [info.label + ":", info.value]);
  const ownerInfoRows = template.ownerInfo.map(info => [info.label + ":", info.value]);

  // PIHAK PERTAMA section
  const pihakPertamaSection: any = customerPhotoBase64 ? {
    table: {
      widths: [80, '*'],
      body: [[
        { image: customerPhotoBase64, width: 70, height: 90 },
        { table: { widths: [60, '*'], body: customerInfoRows }, layout: 'noBorders' }
      ]]
    },
    layout: 'noBorders',
    margin: [0, 0, 0, 4]
  } : {
    table: { widths: [60, '*'], body: customerInfoRows },
    layout: 'noBorders',
    margin: [0, 0, 0, 4]
  };

  // Build content array
  const content: any[] = [
    // Title
    { text: template.title, style: "header", alignment: "center", margin: [0, 0, 0, 15] },
    
    // Opening
    { text: template.opening, margin: [0, 0, 0, 12] },

    // PIHAK PERTAMA
    pihakPertamaSection,
    { text: template.pihakPertamaClosing, margin: [0, 0, 0, 12] },

    // PIHAK KEDUA
    { table: { widths: [60, '*'], body: ownerInfoRows }, layout: 'noBorders', margin: [0, 0, 0, 4] },
    { text: template.pihakKeduaClosing, margin: [0, 0, 0, 12] },

    // Agreement points
    ...template.agreementPoints.map((point, idx) => ({
      text: point,
      margin: [0, 0, 0, idx === template.agreementPoints.length - 1 ? 12 : 8]
    })),
  ];

  // Add pasals - read keepTogether from template
  template.pasals.forEach((pasal) => {
    const pasalContent: any[] = [
      { text: `Pasal ${pasal.number}`, alignment: 'center', bold: true, margin: [0, 0, 0, 0] },
      { text: pasal.title, alignment: 'center', bold: true, margin: [0, 0, 0, 8] },
    ];
    
    if (pasal.intro) {
      pasalContent.push({ text: pasal.intro, margin: [0, 0, 0, 4] });
    }
    if (pasal.points) {
      pasal.points.forEach((point) => {
        pasalContent.push({ text: point, margin: [0, 0, 0, 4] });
      });
    }
    if (pasal.content) {
      pasalContent.push({ text: pasal.content, margin: [0, 0, 0, 10], alignment: 'justify' });
    }

    // Use unbreakable if keepTogether is true in template
    if (pasal.keepTogether) {
      content.push({
        unbreakable: true,
        stack: pasalContent
      });
    } else {
      content.push(...pasalContent);
    }
  });

  // Agreement date
  content.push({ text: template.agreementDate, margin: [0, 0, 0, 20] });

  // Signatures
  content.push({
    unbreakable: true,
    stack: [{
      columns: template.signatures.map((sig) => ({
        width: '*',
        stack: [
          { text: sig.role, alignment: 'center', bold: true },
          { text: '\n\n\n\n', fontSize: 11 },
          { text: sig.label, alignment: 'center', fontSize: 8, color: '#666666' },
          { text: '\n', fontSize: 6 },
          { text: `(${sig.name})`, alignment: 'center' }
        ]
      }))
    }]
  });

  const docDefinition = {
    pageSize: 'A4',
    pageMargins: [40, 40, 40, 40],
    content,
    styles: {
      header: { fontSize: 14, bold: true, font: 'Roboto' }
    },
    defaultStyle: { font: 'Roboto', fontSize: 10, lineHeight: 1.25 }
  } as any;

  const pdfDoc = pdfMake.createPdf(docDefinition);
  
  if (action === 'print') {
    pdfDoc.print();
  } else {
    const fileName = `Perjanjian_${(agreementData as any).app?.id || 'document'}_${agreementData.customer.full_name.replace(/\s+/g, '_')}.pdf`;
    pdfDoc.download(fileName);
  }
}
