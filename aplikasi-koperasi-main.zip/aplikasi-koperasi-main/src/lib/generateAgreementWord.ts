import { Document, Packer, Paragraph, TextRun, AlignmentType, Table as DocxTable, TableRow as DocxTableRow, TableCell as DocxTableCell, WidthType, BorderStyle, ImageRun } from "docx";
import { saveAs } from "file-saver";
import { generateTemplateContent, AgreementData } from "@/lib/agreementTemplate";

// Helper to create no-border cell
function createNoBorderCell(children: Paragraph[], width: number) {
  return new DocxTableCell({
    children,
    borders: {
      top: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.NONE },
      left: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE }
    },
    width: { size: width, type: WidthType.PERCENTAGE }
  });
}

// Load image as ArrayBuffer
async function loadImageBuffer(url: string): Promise<ArrayBuffer | null> {
  try {
    const response = await fetch(url);
    return await response.arrayBuffer();
  } catch (error) {
    console.error('Error loading image:', error);
    return null;
  }
}

export async function generateAgreementWord(agreementData: AgreementData & { app?: any }) {
  const template = generateTemplateContent(agreementData);
  
  // Load customer photo if available
  let customerPhotoBuffer: ArrayBuffer | null = null;
  if (template.customerPhotoUrl) {
    customerPhotoBuffer = await loadImageBuffer(template.customerPhotoUrl);
  }

  // Build customer info paragraphs
  const customerInfoParagraphs = template.customerInfo.map(info => 
    new Paragraph({
      children: [
        new TextRun({ text: `${info.label}: `, bold: false }),
        new TextRun(info.value)
      ],
      spacing: { after: 0 }
    })
  );

  // Build owner info paragraphs
  const ownerInfoParagraphs = template.ownerInfo.map(info => 
    new Paragraph({
      children: [
        new TextRun({ text: `${info.label}: `, bold: false }),
        new TextRun(info.value)
      ],
      spacing: { after: 0 }
    })
  );

  // PIHAK PERTAMA section
  const pihakPertamaSection = customerPhotoBuffer ? [
    new DocxTable({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
        insideHorizontal: { style: BorderStyle.NONE },
        insideVertical: { style: BorderStyle.NONE }
      },
      rows: [
        new DocxTableRow({
          children: [
            new DocxTableCell({
              width: { size: 20, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({
                  children: [
                    new ImageRun({
                      data: customerPhotoBuffer,
                      transformation: { width: 80, height: 100 },
                      type: 'png',
                    }),
                  ],
                })
              ]
            }),
            new DocxTableCell({
              width: { size: 80, type: WidthType.PERCENTAGE },
              children: customerInfoParagraphs
            })
          ]
        })
      ]
    }),
    new Paragraph({
      text: template.pihakPertamaClosing,
      spacing: { after: 400 }
    }),
  ] : [
    ...customerInfoParagraphs,
    new Paragraph({
      text: template.pihakPertamaClosing,
      spacing: { after: 400 }
    }),
  ];

  // Build pasals - read keepTogether from template
  const pasalParagraphs: Paragraph[] = [];
  template.pasals.forEach(pasal => {
    const keepTogether = pasal.keepTogether ?? true;
    
    // Pasal number
    pasalParagraphs.push(new Paragraph({
      text: `Pasal ${pasal.number}`,
      alignment: AlignmentType.CENTER,
      spacing: { after: 0 },
      style: "Heading2",
      keepNext: keepTogether,
      keepLines: keepTogether
    }));
    // Pasal title
    pasalParagraphs.push(new Paragraph({
      text: pasal.title,
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      style: "Heading2",
      keepNext: keepTogether,
      keepLines: keepTogether
    }));
    // Pasal intro if exists
    if (pasal.intro) {
      pasalParagraphs.push(new Paragraph({
        text: pasal.intro,
        spacing: { after: 200 },
        keepNext: keepTogether
      }));
    }
    // Pasal points if exists
    if (pasal.points) {
      pasal.points.forEach((point, idx) => {
        pasalParagraphs.push(new Paragraph({
          text: point,
          spacing: { after: 100 },
          keepNext: keepTogether && idx < pasal.points!.length - 1
        }));
      });
    }
    // Pasal content if exists
    if (pasal.content) {
      pasalParagraphs.push(new Paragraph({
        text: pasal.content,
        spacing: { after: 300 }
      }));
    }
  });

  // Signature table
  const signatureTable = new DocxTable({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.NONE },
      left: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE },
      insideHorizontal: { style: BorderStyle.NONE },
      insideVertical: { style: BorderStyle.NONE }
    },
    rows: [
      // Role row
      new DocxTableRow({
        children: template.signatures.map(sig => 
          createNoBorderCell([
            new Paragraph({ text: sig.role, alignment: AlignmentType.CENTER })
          ], 33)
        )
      }),
      // Empty row for signature space
      new DocxTableRow({
        children: template.signatures.map((sig, idx) => 
          createNoBorderCell([
            new Paragraph({ text: "", spacing: { after: 600 } }),
            new Paragraph({ text: "", spacing: { after: 600 } }),
            new Paragraph({ text: "", spacing: { after: 600 } }),
            new Paragraph({ 
              text: idx === 0 ? "Materai" : "", 
              alignment: AlignmentType.CENTER,
              spacing: { after: 300 }
            })
          ], 33)
        )
      }),
      // Names row
      new DocxTableRow({
        children: template.signatures.map(sig => 
          createNoBorderCell([
            new Paragraph({ text: `( ${sig.name} )`, alignment: AlignmentType.CENTER })
          ], 33)
        )
      })
    ]
  });

  // Create document
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        // Title
        new Paragraph({
          text: template.title,
          alignment: AlignmentType.CENTER,
          spacing: { after: 400 },
          style: "Heading1"
        }),
        // Opening
        new Paragraph({
          text: template.opening,
          spacing: { after: 400 }
        }),
        // PIHAK PERTAMA
        ...pihakPertamaSection,
        // PIHAK KEDUA
        ...ownerInfoParagraphs,
        new Paragraph({
          text: template.pihakKeduaClosing,
          spacing: { after: 400 }
        }),
        // Agreement points
        ...template.agreementPoints.map((point, idx) => 
          new Paragraph({
            text: point,
            spacing: { after: idx === template.agreementPoints.length - 1 ? 400 : 200 }
          })
        ),
        // Pasals
        ...pasalParagraphs,
        // Agreement date
        new Paragraph({
          text: template.agreementDate,
          spacing: { after: 200 }
        }),
        // Space before signatures
        new Paragraph({ text: "", spacing: { after: 120 } }),
        // Signature table
        signatureTable
      ]
    }]
  });

  // Generate and download
  const blob = await Packer.toBlob(doc);
  const fileName = `Perjanjian_${agreementData.app?.id || 'document'}_${agreementData.customer.full_name.replace(/\s+/g, '_')}.docx`;
  saveAs(blob, fileName);
  
  return fileName;
}
