// Build version - automatically generated at build time by Vite
// This creates a unique version for each build without manual updates

// Build ID based on build timestamp (generated once at build time)
// Format: YYYYMMDD.HHMM (e.g., 20260117.1430)
const buildDate = new Date();
const year = buildDate.getFullYear();
const month = String(buildDate.getMonth() + 1).padStart(2, '0');
const day = String(buildDate.getDate()).padStart(2, '0');
const hours = String(buildDate.getHours()).padStart(2, '0');
const minutes = String(buildDate.getMinutes()).padStart(2, '0');

export const APP_VERSION = `${year}${month}${day}.${hours}${minutes}`;

// Full build timestamp for debugging
export const BUILD_TIME = buildDate.toISOString();

// Function to check if there's a newer version available
export const checkForUpdates = async (): Promise<{ hasUpdate: boolean; currentVersion: string }> => {
  try {
    // Check if service worker has an update waiting
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.getRegistration();
      
      if (registration) {
        // Force check for updates
        await registration.update();
        
        // Check if there's a waiting worker (meaning update is available)
        if (registration.waiting) {
          console.log('✅ Update found: New service worker waiting');
          return { hasUpdate: true, currentVersion: APP_VERSION };
        }
        
        // Check if there's an installing worker
        if (registration.installing) {
          console.log('✅ Update found: New service worker installing');
          return { hasUpdate: true, currentVersion: APP_VERSION };
        }
      }
    }
    
    // No update available
    console.log('ℹ️ No update available, current version:', APP_VERSION);
    return { hasUpdate: false, currentVersion: APP_VERSION };
  } catch (error) {
    console.error('Error checking for updates:', error);
    return { hasUpdate: false, currentVersion: APP_VERSION };
  }
};
