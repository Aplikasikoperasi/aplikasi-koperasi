import { supabase } from "@/integrations/supabase/client";

export type LogCategory = 
  | "member_management"
  | "customer_management"
  | "credit_application"
  | "payment"
  | "blocking"
  | "security"
  | "system_error"
  | "data_deletion"
  | "sensitive_update"
  | "authentication"
  | "financial";

interface LogEventParams {
  category: LogCategory;
  action: string;
  description: string;
  metadata?: Record<string, any>;
}

export async function logSystemEvent({
  category,
  action,
  description,
  metadata = {}
}: LogEventParams): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    // Get user name from members table if available
    let userName = user?.email || "System";
    if (user?.id) {
      const { data: member } = await supabase
        .from("members")
        .select("full_name")
        .eq("user_id", user.id)
        .single();
      
      if (member?.full_name) {
        userName = member.full_name;
      }
    }

    // Enhanced metadata with timestamp and IP info
    const enhancedMetadata = {
      ...metadata,
      timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
    };

    await supabase.rpc("log_system_event", {
      p_user_id: user?.id || null,
      p_user_name: userName,
      p_category: category as any,
      p_action: action,
      p_description: description,
      p_metadata: enhancedMetadata
    });
  } catch (error) {
    console.error("Failed to log system event:", error);
  }
}

// Helper functions for critical operations logging
export async function logDeletion(
  entityType: string,
  entityId: string,
  entityName: string,
  additionalData?: Record<string, any>
) {
  await logSystemEvent({
    category: "data_deletion",
    action: `delete_${entityType}`,
    description: `Menghapus ${entityType}: ${entityName}`,
    metadata: {
      entity_type: entityType,
      entity_id: entityId,
      entity_name: entityName,
      ...additionalData
    }
  });
}

export async function logSensitiveUpdate(
  entityType: string,
  entityId: string,
  oldValue: any,
  newValue: any,
  fieldName: string
) {
  await logSystemEvent({
    category: "sensitive_update",
    action: `update_${entityType}_${fieldName}`,
    description: `Update ${fieldName} pada ${entityType}`,
    metadata: {
      entity_type: entityType,
      entity_id: entityId,
      field_name: fieldName,
      old_value: oldValue,
      new_value: newValue
    }
  });
}

export async function logFailedLogin(email: string, reason: string) {
  await logSystemEvent({
    category: "authentication",
    action: "failed_login",
    description: `Login gagal: ${reason}`,
    metadata: {
      email,
      reason,
      ip_address: "client-side" // In production, get from server
    }
  });
}

export async function logSuccessfulLogin(userId: string, userName: string) {
  await logSystemEvent({
    category: "authentication",
    action: "successful_login",
    description: `Login berhasil: ${userName}`,
    metadata: {
      user_id: userId,
      user_name: userName
    }
  });
}
