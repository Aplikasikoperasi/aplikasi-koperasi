// Maximum time to wait for image operations (30 seconds)
const COMPRESSION_TIMEOUT = 30000;

export const compressImage = async (file: File, maxSizeMB = 0.5, maxWidthOrHeight = 800): Promise<File> => {
  return new Promise((resolve, reject) => {
    // Set timeout to prevent infinite waiting
    const timeout = setTimeout(() => {
      reject(new Error('Kompresi gambar timeout. Coba gunakan gambar yang lebih kecil.'));
    }, COMPRESSION_TIMEOUT);

    const cleanup = () => clearTimeout(timeout);

    const reader = new FileReader();
    
    reader.onload = (e) => {
      const img = new Image();
      
      img.onload = () => {
        try {
          // Calculate new dimensions
          let width = img.width;
          let height = img.height;
          
          // Limit very large images more aggressively
          const effectiveMax = Math.min(maxWidthOrHeight, 1024);
          
          if (width > height) {
            if (width > effectiveMax) {
              height = Math.round((height * effectiveMax) / width);
              width = effectiveMax;
            }
          } else {
            if (height > effectiveMax) {
              width = Math.round((width * effectiveMax) / height);
              height = effectiveMax;
            }
          }
          
          // Create canvas
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            cleanup();
            reject(new Error('Could not get canvas context'));
            return;
          }
          
          // Draw image
          ctx.drawImage(img, 0, 0, width, height);
          
          // Always convert to JPEG for better compatibility and smaller size
          // This handles HEIC, PNG, WEBP, etc.
          canvas.toBlob(
            (blob) => {
              cleanup();
              
              if (!blob) {
                reject(new Error('Could not compress image'));
                return;
              }
              
              // Generate new filename with .jpg extension
              const baseName = file.name.replace(/\.[^/.]+$/, '') || 'photo';
              const newFileName = `${baseName}.jpg`;
              
              // Create new file from blob - always as JPEG
              const compressedFile = new File([blob], newFileName, {
                type: 'image/jpeg',
                lastModified: Date.now(),
              });
              
              console.log(`Image compressed: ${(file.size / 1024).toFixed(1)}KB -> ${(compressedFile.size / 1024).toFixed(1)}KB`);
              resolve(compressedFile);
            },
            'image/jpeg', // Always output as JPEG
            0.75 // Quality 75% for faster upload
          );
        } catch (error) {
          cleanup();
          reject(error);
        }
      };
      
      img.onerror = () => {
        cleanup();
        reject(new Error('Gagal memuat gambar. Pastikan file adalah gambar yang valid.'));
      };
      
      img.src = e.target?.result as string;
    };
    
    reader.onerror = () => {
      cleanup();
      reject(new Error('Gagal membaca file. Coba upload ulang.'));
    };
    
    reader.readAsDataURL(file);
  });
};

// Helper function to check if file needs compression
export const needsCompression = (file: File): boolean => {
  // Compress if larger than 500KB or not JPEG
  return file.size > 500 * 1024 || !file.type.includes('jpeg');
};

// Get file size in human readable format
export const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};
