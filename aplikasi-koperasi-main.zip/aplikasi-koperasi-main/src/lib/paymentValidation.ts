import { z } from 'zod';

/**
 * Payment validation schemas using Zod
 * Provides comprehensive client-side validation for payment inputs
 * Server-side validation should also be implemented in database functions
 */

// Payment amount validation
// - Must be positive
// - Max 1 billion to prevent overflow attacks
// - Must be multiple of 1000 (Rupiah rounding)
export const paymentAmountSchema = z
  .number({
    required_error: "Jumlah pembayaran harus diisi",
    invalid_type_error: "Jumlah pembayaran harus berupa angka",
  })
  .positive("Jumlah pembayaran harus lebih dari 0")
  .max(1_000_000_000, "Jumlah pembayaran maksimal Rp 1.000.000.000")
  .multipleOf(1000, "Jumlah pembayaran harus kelipatan Rp 1.000");

// Payment date validation
// - Must be a valid date
// - Cannot be in the future
export const paymentDateSchema = z
  .date({
    required_error: "Tanggal pembayaran harus diisi",
    invalid_type_error: "Tanggal pembayaran tidak valid",
  })
  .max(new Date(), "Tanggal pembayaran tidak boleh di masa depan");

// Payment method validation
export const paymentMethodSchema = z.enum(["Cash", "Transfer", "E-Wallet", "Potong Pencairan"], {
  required_error: "Metode pembayaran harus dipilih",
  invalid_type_error: "Metode pembayaran tidak valid",
});

// Reference number validation (optional)
export const referenceNumberSchema = z
  .string()
  .max(100, "Nomor referensi maksimal 100 karakter")
  .optional()
  .nullable()
  .transform(val => val || null);

// Notes validation (optional)
export const notesSchema = z
  .string()
  .max(500, "Catatan maksimal 500 karakter")
  .optional()
  .nullable()
  .transform(val => val || null);

// PIN validation for kasir
export const kasirPinSchema = z
  .string({
    required_error: "PIN kasir harus diisi",
  })
  .min(4, "PIN minimal 4 karakter")
  .max(6, "PIN maksimal 6 karakter");

// SuperCode validation
export const superCodeSchema = z
  .string({
    required_error: "SuperCode harus diisi",
  })
  .min(1, "SuperCode harus diisi");

/**
 * Complete payment form validation schema
 * Use this for form-level validation
 */
export const paymentFormSchema = z.object({
  amount: paymentAmountSchema,
  payment_date: paymentDateSchema,
  payment_method: paymentMethodSchema,
  reference_number: referenceNumberSchema,
  notes: notesSchema,
});

/**
 * Payment form with PIN validation (for kasir)
 */
export const paymentFormWithPinSchema = paymentFormSchema.extend({
  kasir_pin: kasirPinSchema,
});

/**
 * Payment form with SuperCode validation (for edit/delete)
 */
export const paymentFormWithSuperCodeSchema = paymentFormSchema.extend({
  super_code: superCodeSchema,
});

// Type exports for TypeScript
export type PaymentFormData = z.infer<typeof paymentFormSchema>;
export type PaymentFormWithPinData = z.infer<typeof paymentFormWithPinSchema>;
export type PaymentFormWithSuperCodeData = z.infer<typeof paymentFormWithSuperCodeSchema>;

/**
 * Helper function to validate payment amount
 * Returns error message if invalid, null if valid
 */
export function validatePaymentAmount(amount: number | string): string | null {
  try {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    paymentAmountSchema.parse(numAmount);
    return null;
  } catch (error) {
    if (error instanceof z.ZodError) {
      return error.errors[0].message;
    }
    return "Jumlah pembayaran tidak valid";
  }
}

/**
 * Helper function to validate payment date
 * Returns error message if invalid, null if valid
 * Note: undefined/null dates are allowed - will default to today in payment processing
 */
export function validatePaymentDate(date: Date | undefined | null): string | null {
  // Allow empty date - will default to today in payment processing
  if (!date) {
    return null;
  }
  try {
    paymentDateSchema.parse(date);
    return null;
  } catch (error) {
    if (error instanceof z.ZodError) {
      return error.errors[0].message;
    }
    return "Tanggal pembayaran tidak valid";
  }
}

/**
 * Helper function to validate complete payment form
 * Returns array of error messages if invalid, empty array if valid
 */
export function validatePaymentForm(formData: Partial<PaymentFormData>): string[] {
  try {
    paymentFormSchema.parse(formData);
    return [];
  } catch (error) {
    if (error instanceof z.ZodError) {
      return error.errors.map(err => err.message);
    }
    return ["Data pembayaran tidak valid"];
  }
}
