// Login Rate Limiter - Device-based login attempt tracking
// Max 3 failed attempts per device, progressive lockout (30 min → 1 jam → 2 jam → dst)

const STORAGE_KEY = 'login_attempts';
const MAX_ATTEMPTS = 3;
const BASE_LOCKOUT_MINUTES = 30; // Base lockout: 30 minutes

interface LoginAttemptData {
  attempts: number;
  lastAttemptTime: number;
  lockedUntil: number | null;
  lockoutCount: number; // Track how many times user has been locked out
}

function getDeviceId(): string {
  // Use a combination of browser fingerprint-like data as device identifier
  let deviceId = localStorage.getItem('device_id');
  if (!deviceId) {
    deviceId = `device_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    localStorage.setItem('device_id', deviceId);
  }
  return deviceId;
}

function getAttemptData(): LoginAttemptData {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch {
    // If parsing fails, return default
  }
  return {
    attempts: 0,
    lastAttemptTime: 0,
    lockedUntil: null,
    lockoutCount: 0
  };
}

function saveAttemptData(data: LoginAttemptData): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function isLoginBlocked(): { blocked: boolean; remainingMinutes: number } {
  const data = getAttemptData();
  
  if (data.lockedUntil && data.lockedUntil > Date.now()) {
    const remainingMs = data.lockedUntil - Date.now();
    const remainingMinutes = Math.ceil(remainingMs / 60000);
    return { blocked: true, remainingMinutes };
  }
  
  // If lockout has expired, reset attempts but keep lockoutCount for progressive lockout
  if (data.lockedUntil && data.lockedUntil <= Date.now()) {
    const newData: LoginAttemptData = {
      attempts: 0,
      lastAttemptTime: 0,
      lockedUntil: null,
      lockoutCount: data.lockoutCount // Keep lockout count for progressive increase
    };
    saveAttemptData(newData);
  }
  
  return { blocked: false, remainingMinutes: 0 };
}

export function recordFailedAttempt(): { 
  blocked: boolean; 
  attemptsRemaining: number;
  lockoutMinutes: number;
} {
  const data = getAttemptData();
  
  // If already locked, don't increment
  if (data.lockedUntil && data.lockedUntil > Date.now()) {
    const remainingMs = data.lockedUntil - Date.now();
    return { 
      blocked: true, 
      attemptsRemaining: 0,
      lockoutMinutes: Math.ceil(remainingMs / 60000)
    };
  }
  
  // Increment attempts
  data.attempts += 1;
  data.lastAttemptTime = Date.now();
  
  // Check if max attempts reached
  if (data.attempts >= MAX_ATTEMPTS) {
    // Calculate progressive lockout: 30min, 60min, 120min, etc. (x2 each time)
    const multiplier = Math.pow(2, data.lockoutCount);
    const lockoutMinutes = BASE_LOCKOUT_MINUTES * multiplier;
    const lockoutMs = lockoutMinutes * 60 * 1000;
    
    data.lockedUntil = Date.now() + lockoutMs;
    data.lockoutCount += 1; // Increment lockout count for next time
    saveAttemptData(data);
    return { 
      blocked: true, 
      attemptsRemaining: 0,
      lockoutMinutes: lockoutMinutes
    };
  }
  
  saveAttemptData(data);
  return { 
    blocked: false, 
    attemptsRemaining: MAX_ATTEMPTS - data.attempts,
    lockoutMinutes: 0
  };
}

export function resetLoginAttempts(): void {
  const data: LoginAttemptData = {
    attempts: 0,
    lastAttemptTime: 0,
    lockedUntil: null,
    lockoutCount: 0 // Full reset on successful login
  };
  saveAttemptData(data);
}

export function getLoginAttemptsRemaining(): number {
  const data = getAttemptData();
  
  // If locked, no attempts remaining
  if (data.lockedUntil && data.lockedUntil > Date.now()) {
    return 0;
  }
  
  // If lock expired, user can try again
  if (data.lockedUntil && data.lockedUntil <= Date.now()) {
    return MAX_ATTEMPTS;
  }
  
  return MAX_ATTEMPTS - data.attempts;
}

export function getLockoutEndTime(): Date | null {
  const data = getAttemptData();
  if (data.lockedUntil && data.lockedUntil > Date.now()) {
    return new Date(data.lockedUntil);
  }
  return null;
}
