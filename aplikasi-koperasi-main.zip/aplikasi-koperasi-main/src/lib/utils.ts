import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ============================================================
// WIB (GMT+7) TIMEZONE UTILITIES
// All date operations should use these functions for consistency
// ============================================================

const WIB_OFFSET_MINUTES = 7 * 60; // WIB is UTC+7

// Convert any date to WIB timezone
export function toWIB(date: Date | string | null | undefined): Date | null {
  if (!date) return null;
  const dateObj = typeof date === 'string' ? new Date(date) : new Date(date.getTime());
  if (isNaN(dateObj.getTime())) return null;
  
  const utcTime = dateObj.getTime() + (dateObj.getTimezoneOffset() * 60000);
  return new Date(utcTime + (WIB_OFFSET_MINUTES * 60000));
}

// Get current date/time in WIB
export function getNowInWIB(): Date {
  return toWIB(new Date())!;
}

// Helper to get current date in WIB (GMT+7) - end of day for date comparisons
export function getTodayInWIB(): Date {
  const wibTime = getNowInWIB();
  wibTime.setHours(23, 59, 59, 999);
  return wibTime;
}

// Helper to get today's date string in WIB (GMT+7) as YYYY-MM-DD
export function getTodayDateStringInWIB(): string {
  return getDateStringInWIB(0);
}

// Helper to get date string X days from today in WIB (GMT+7) as YYYY-MM-DD
// daysOffset: positive for future dates, negative for past dates
export function getDateStringInWIB(daysOffset: number = 0): string {
  const wibTime = getNowInWIB();
  wibTime.setDate(wibTime.getDate() + daysOffset);
  
  const year = wibTime.getFullYear();
  const month = String(wibTime.getMonth() + 1).padStart(2, '0');
  const day = String(wibTime.getDate()).padStart(2, '0');
  
  return `${year}-${month}-${day}`;
}

// Get current ISO timestamp in WIB context (for database storage)
export function getCurrentTimestampWIB(): string {
  return new Date().toISOString();
}

// ============================================================
// DATE FORMATTING UTILITIES (DD/MM/YYYY default format)
// ============================================================

// Indonesian month names
const MONTH_NAMES_ID = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

const MONTH_NAMES_SHORT_ID = [
  'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
  'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
];

const DAY_NAMES_ID = [
  'Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'
];

type DateFormatStyle = 'short' | 'medium' | 'long' | 'full' | 'iso' | 'input';

/**
 * Format date to Indonesian format with WIB timezone
 * @param date - Date string, Date object, or null/undefined
 * @param style - Format style:
 *   - 'short': DD/MM/YYYY (default)
 *   - 'medium': DD MMM YYYY (e.g., 15 Jan 2024)
 *   - 'long': DD MMMM YYYY (e.g., 15 Januari 2024)
 *   - 'full': Senin, DD MMMM YYYY (e.g., Senin, 15 Januari 2024)
 *   - 'iso': YYYY-MM-DD (for database/API)
 *   - 'input': DD/MM/YYYY (same as short, for form inputs)
 */
export function formatDateWIB(
  date: Date | string | null | undefined, 
  style: DateFormatStyle = 'short'
): string {
  if (!date) return "-";
  
  const wibDate = toWIB(date);
  if (!wibDate) return "-";
  
  const day = wibDate.getDate();
  const month = wibDate.getMonth();
  const year = wibDate.getFullYear();
  const dayOfWeek = wibDate.getDay();
  
  const dayStr = String(day).padStart(2, '0');
  const monthStr = String(month + 1).padStart(2, '0');
  
  switch (style) {
    case 'iso':
      return `${year}-${monthStr}-${dayStr}`;
    case 'medium':
      return `${dayStr} ${MONTH_NAMES_SHORT_ID[month]} ${year}`;
    case 'long':
      return `${dayStr} ${MONTH_NAMES_ID[month]} ${year}`;
    case 'full':
      return `${DAY_NAMES_ID[dayOfWeek]}, ${dayStr} ${MONTH_NAMES_ID[month]} ${year}`;
    case 'short':
    case 'input':
    default:
      return `${dayStr}/${monthStr}/${year}`;
  }
}

/**
 * Format datetime to Indonesian format with WIB timezone
 * @param date - Date string, Date object, or null/undefined
 * @param includeSeconds - Whether to include seconds in time
 */
export function formatDateTimeWIB(
  date: Date | string | null | undefined,
  includeSeconds: boolean = false
): string {
  if (!date) return "-";
  
  const wibDate = toWIB(date);
  if (!wibDate) return "-";
  
  const dateStr = formatDateWIB(wibDate, 'short');
  const hours = String(wibDate.getHours()).padStart(2, '0');
  const minutes = String(wibDate.getMinutes()).padStart(2, '0');
  const seconds = String(wibDate.getSeconds()).padStart(2, '0');
  
  const timeStr = includeSeconds 
    ? `${hours}:${minutes}:${seconds}` 
    : `${hours}:${minutes}`;
  
  return `${dateStr} ${timeStr} WIB`;
}

/**
 * Format datetime with long date format
 */
export function formatDateTimeLongWIB(
  date: Date | string | null | undefined
): string {
  if (!date) return "-";
  
  const wibDate = toWIB(date);
  if (!wibDate) return "-";
  
  const dateStr = formatDateWIB(wibDate, 'long');
  const hours = String(wibDate.getHours()).padStart(2, '0');
  const minutes = String(wibDate.getMinutes()).padStart(2, '0');
  
  return `${dateStr} pukul ${hours}:${minutes} WIB`;
}

/**
 * Format relative time (e.g., "2 hari lalu", "dalam 3 jam")
 */
export function formatRelativeTimeWIB(date: Date | string | null | undefined): string {
  if (!date) return "-";
  
  const wibDate = toWIB(date);
  const now = getNowInWIB();
  if (!wibDate) return "-";
  
  const diffMs = now.getTime() - wibDate.getTime();
  const diffMinutes = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  const isPast = diffMs > 0;
  const absMinutes = Math.abs(diffMinutes);
  const absHours = Math.abs(diffHours);
  const absDays = Math.abs(diffDays);
  
  if (absMinutes < 1) return "baru saja";
  if (absMinutes < 60) {
    return isPast ? `${absMinutes} menit lalu` : `dalam ${absMinutes} menit`;
  }
  if (absHours < 24) {
    return isPast ? `${absHours} jam lalu` : `dalam ${absHours} jam`;
  }
  if (absDays < 7) {
    return isPast ? `${absDays} hari lalu` : `dalam ${absDays} hari`;
  }
  
  return formatDateWIB(date, 'medium');
}

// ============================================================
// LEGACY COMPATIBILITY - Keep existing function signatures
// ============================================================

export function formatRupiah(amount: number): string {
  return `Rp ${amount.toLocaleString("id-ID")}`;
}

// Legacy formatDate - now uses WIB timezone
export function formatDate(dateString: string | null | undefined): string {
  return formatDateWIB(dateString, 'short');
}

export function calculateAge(dateOfBirth: string | null | undefined): number | null {
  if (!dateOfBirth) return null;
  
  const today = getNowInWIB();
  const birthDate = toWIB(dateOfBirth);
  if (!birthDate) return null;
  
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
}

export function roundToThousand(amount: number): number {
  return Math.ceil(amount / 1000) * 1000;
}

export function formatNumberWithSeparator(value: string | number): string {
  const stringValue = String(value).replace(/\D/g, '');
  if (!stringValue) return '';
  return stringValue.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

export function parseNumberFromSeparator(value: string): string {
  return value.replace(/\./g, '');
}

export function formatAccountNumber(value: string): string {
  if (!value) return '';
  return value.replace(/(.{4})/g, '$1 ').trim();
}

export function validateDateString(dateString: string): boolean {
  if (!dateString) return false;
  
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return false;
    
    const year = date.getFullYear();
    if (year < 1900 || year > 2100) return false;
    
    return true;
  } catch {
    return false;
  }
}

export function sanitizeDateForDatabase(date: Date | string | null | undefined): string | null {
  if (!date) return null;
  
  try {
    // Convert to WIB first to ensure consistent date across timezones
    const wibDate = toWIB(date);
    if (!wibDate) return null;
    
    const year = wibDate.getFullYear();
    
    // Validate year range
    if (year < 1900 || year > 2100) return null;
    
    // Return in YYYY-MM-DD format using WIB date
    const month = String(wibDate.getMonth() + 1).padStart(2, '0');
    const day = String(wibDate.getDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
  } catch {
    return null;
  }
}

/**
 * Get current timestamp in WIB timezone formatted for database
 * Returns ISO string with WIB offset (+07:00)
 */
export function getCurrentTimestampForDB(): string {
  const now = new Date();
  const wibDate = toWIB(now);
  if (!wibDate) return now.toISOString();
  
  // Format as ISO string with WIB timezone indicator
  const year = wibDate.getFullYear();
  const month = String(wibDate.getMonth() + 1).padStart(2, '0');
  const day = String(wibDate.getDate()).padStart(2, '0');
  const hours = String(wibDate.getHours()).padStart(2, '0');
  const minutes = String(wibDate.getMinutes()).padStart(2, '0');
  const seconds = String(wibDate.getSeconds()).padStart(2, '0');
  
  // Return with +07:00 offset to indicate WIB
  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}+07:00`;
}

/**
 * Get today's date in WIB as YYYY-MM-DD string
 * Use this for setting application dates, disbursement dates, etc.
 */
export function getTodayDateForDB(): string {
  const now = new Date();
  const wibDate = toWIB(now);
  if (!wibDate) {
    // Fallback: manual calculation
    const utcTime = now.getTime() + (now.getTimezoneOffset() * 60000);
    const wibTime = new Date(utcTime + (WIB_OFFSET_MINUTES * 60000));
    const year = wibTime.getFullYear();
    const month = String(wibTime.getMonth() + 1).padStart(2, '0');
    const day = String(wibTime.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  const year = wibDate.getFullYear();
  const month = String(wibDate.getMonth() + 1).padStart(2, '0');
  const day = String(wibDate.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
