import { formatRupiah, formatDate } from "./utils";

/**
 * Sanitizes text for WhatsApp messages by removing markdown characters
 * and limiting length to prevent message manipulation
 */
function sanitizeForWhatsApp(text: string, maxLength: number = 100): string {
  if (!text) return '';
  
  return text
    .replace(/[*_~`]/g, '') // Remove WhatsApp markdown characters
    .replace(/[\n\r]/g, ' ') // Replace newlines with spaces
    .trim()
    .substring(0, maxLength);
}

/**
 * Sanitizes numeric values and application numbers
 */
function sanitizeApplicationNumber(appNumber: string): string {
  if (!appNumber) return 'N/A';
  // Only allow alphanumeric and basic separators
  return appNumber.replace(/[^a-zA-Z0-9\-\/]/g, '').substring(0, 30);
}

interface InstallmentReminderData {
  customerName: string;
  customerPhone: string;
  installmentNumber: number;
  dueDate: string;
  totalAmount: number;
  daysOverdue?: number;
  penalty?: number;
  memberName: string;
  applicationNumber: string;
  creditScore?: number;
  customerIdNumber?: string;
  dateOfBirth?: string;
  bankName?: string;
  bankAccountNumber?: string;
  bankAccountHolder?: string;
}

interface PaymentReceiptData {
  customerName: string;
  paymentDate: string;
  amount: number;
  installmentNumber: number;
  paymentMethod: string;
  referenceNumber?: string;
  applicationNumber: string;
  creditScore?: number;
  customerIdNumber?: string;
  dateOfBirth?: string;
  remainingPenalty?: number;
  totalAmount?: number;
  paidAmount?: number;
  bankName?: string;
  bankAccountNumber?: string;
  bankAccountHolder?: string;
}

export function generateInstallmentReminderMessage(data: InstallmentReminderData): string {
  // Sanitize all user inputs
  const customerName = sanitizeForWhatsApp(data.customerName, 50);
  const memberName = sanitizeForWhatsApp(data.memberName, 50);
  const applicationNumber = sanitizeApplicationNumber(data.applicationNumber);
  
  const isOverdue = data.daysOverdue && data.daysOverdue > 0;
  
  let message = `🔔 *PENGINGAT ANGSURAN*\n\n`;
  message += `Yth. *${customerName}*\n\n`;
  
  if (isOverdue) {
    message += `⚠️ *TUNGGAKAN*\n`;
    message += `Angsuran ke-${data.installmentNumber} lewat ${data.daysOverdue} hari\n`;
    message += `Jatuh Tempo: ${formatDate(data.dueDate)}\n\n`;
    message += `💰 *Pembayaran:*\n`;
    message += `Pokok: ${formatRupiah(data.totalAmount)}\n`;
    if (data.penalty && data.penalty > 0) {
      message += `Denda: ${formatRupiah(data.penalty)}\n`;
      message += `*Total: ${formatRupiah(data.totalAmount + data.penalty)}*\n`;
    }
  } else {
    message += `📅 Angsuran ke-${data.installmentNumber}\n`;
    message += `Jatuh Tempo: ${formatDate(data.dueDate)}\n`;
    message += `💰 *${formatRupiah(data.totalAmount)}*\n`;
  }
  
  message += `\n📋 No: ${applicationNumber}\n`;
  
  // Credit score (compact)
  if (data.creditScore !== undefined) {
    const emoji = data.creditScore >= 4.5 ? '🌟' : data.creditScore >= 3.5 ? '⭐' : '⚠️';
    message += `${emoji} Skor: ${data.creditScore.toFixed(1)}/5\n`;
  }
  
  message += `\n⏰ Segera bayar untuk hindari denda.\n`;
  
  // Bank info (compact, no separator lines)
  if (data.bankName && data.bankAccountNumber && data.bankAccountHolder) {
    message += `\n🏦 *Transfer ke:*\n`;
    message += `${data.bankName} - ${data.bankAccountNumber}\n`;
    message += `a.n. ${data.bankAccountHolder}\n`;
  }
  
  message += `\n👤 PJ: ${memberName}\n`;
  
  // Login info (clear and detailed)
  if (data.customerIdNumber && data.dateOfBirth) {
    const dob = new Date(data.dateOfBirth);
    const password = `${String(dob.getDate()).padStart(2, '0')}${String(dob.getMonth() + 1).padStart(2, '0')}${dob.getFullYear()}`;
    message += `\n🔐 *Login Akun Anda:*\n`;
    message += `👤 Username: ${data.customerIdNumber}\n`;
    message += `🔑 Password: ${password}\n`;
    message += `🌐 Link: https://www.mitradana.id/\n`;
  }
  
  message += `\n_Terima kasih._`;
  
  return message;
}

export function generatePaymentReceiptMessage(data: PaymentReceiptData): string {
  // Sanitize all user inputs
  const customerName = sanitizeForWhatsApp(data.customerName, 50);
  const applicationNumber = sanitizeApplicationNumber(data.applicationNumber);
  const paymentMethod = sanitizeForWhatsApp(data.paymentMethod, 30);
  const referenceNumber = data.referenceNumber ? sanitizeApplicationNumber(data.referenceNumber) : '';
  
  let message = `✅ *BUKTI BAYAR*\n\n`;
  message += `Yth. *${customerName}*\n\n`;
  message += `📋 *Transaksi:*\n`;
  message += `No: ${applicationNumber}\n`;
  message += `Angsuran ke-${data.installmentNumber}\n`;
  message += `Tgl: ${formatDate(data.paymentDate)}\n`;
  message += `Dibayar: ${formatRupiah(data.amount)}\n`;
  message += `Metode: ${paymentMethod}\n`;
  if (referenceNumber) {
    message += `Ref: ${referenceNumber}\n`;
  }
  
  // Payment breakdown (compact)
  if (data.totalAmount !== undefined && data.paidAmount !== undefined) {
    message += `\n💰 *Rincian:*\n`;
    if (data.remainingPenalty !== undefined && data.remainingPenalty > 0) {
      message += `Total: ${formatRupiah(data.totalAmount)} + Denda ${formatRupiah(data.remainingPenalty)}\n`;
    } else {
      message += `Total: ${formatRupiah(data.totalAmount)}\n`;
    }
    message += `Terbayar: ${formatRupiah(data.paidAmount)}\n`;
    
    const remainingPrincipal = Math.max(0, data.totalAmount - data.paidAmount);
    if (remainingPrincipal > 0) {
      message += `Sisa: ${formatRupiah(remainingPrincipal)}\n`;
    }
  }
  
  // Penalty info (compact)
  if (data.remainingPenalty !== undefined && data.remainingPenalty > 0) {
    message += `\n⚠️ *Sisa Denda: ${formatRupiah(data.remainingPenalty)}*\n`;
  } else if (data.remainingPenalty !== undefined && data.remainingPenalty === 0 && data.paidAmount !== undefined && data.totalAmount !== undefined && data.paidAmount >= data.totalAmount) {
    message += `\n✅ *LUNAS*\n`;
  }
  
  // Credit score (compact)
  if (data.creditScore !== undefined) {
    const emoji = data.creditScore >= 4.5 ? '🌟' : data.creditScore >= 3.5 ? '⭐' : '⚠️';
    message += `\n${emoji} Skor: ${data.creditScore.toFixed(1)}/5\n`;
  }
  
  message += `\n✨ Terima kasih!\n`;
  
  // Login info (clear and detailed)
  if (data.customerIdNumber && data.dateOfBirth) {
    const dob = new Date(data.dateOfBirth);
    const password = `${String(dob.getDate()).padStart(2, '0')}${String(dob.getMonth() + 1).padStart(2, '0')}${dob.getFullYear()}`;
    message += `\n🔐 *Login Akun Anda:*\n`;
    message += `👤 Username: ${data.customerIdNumber}\n`;
    message += `🔑 Password: ${password}\n`;
    message += `🌐 Link: https://www.mitradana.id/\n`;
  }
  
  message += `\n_Simpan sebagai bukti bayar._`;
  
  return message;
}

export type WhatsAppLinkMode = 'auto' | 'web' | 'api' | 'app';

export function generateWhatsAppLink(phoneNumber: string, message: string, mode: WhatsAppLinkMode = 'auto'): string {
  // Clean phone number (remove all non-numeric characters)
  const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
  
  // Validate phone number
  if (!cleanPhone || cleanPhone.length < 8) {
    console.error('Invalid phone number:', phoneNumber);
    return '#'; // Return invalid link if phone is invalid
  }
  
  // Add country code if not present (assuming Indonesia +62)
  let formattedPhone = cleanPhone;
  if (cleanPhone.startsWith('0')) {
    formattedPhone = '62' + cleanPhone.substring(1);
  } else if (!cleanPhone.startsWith('62')) {
    formattedPhone = '62' + cleanPhone;
  }
  
  // CRITICAL: Use proper encoding for WhatsApp
  // encodeURIComponent can cause issues with very long messages
  // Use a more reliable encoding that WhatsApp accepts better
  const encodedMessage = encodeURIComponent(message)
    .replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());

  // Decide link mode based on device
  const isMobile = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent);
  
  let finalMode: WhatsAppLinkMode = mode;
  if (mode === 'auto') {
    finalMode = isMobile ? 'api' : 'api';
  }
  
  // Generate link based on mode
  // IMPORTANT: Use wa.me format which is more reliable for long messages
  if (finalMode === 'app') {
    // Deep link format - tries to open native app
    return `whatsapp://send?phone=${formattedPhone}&text=${encodedMessage}`;
  }
  
  if (finalMode === 'web') {
    // Web WhatsApp - for desktop browsers
    return `https://web.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`;
  }
  
  // CRITICAL FIX: Use wa.me instead of api.whatsapp.com
  // wa.me is more reliable for desktop and handles longer URLs better
  return `https://wa.me/${formattedPhone}?text=${encodedMessage}`;
}

export function generateDisbursementNotification(data: {
  customerName: string;
  amountApproved: number;
  tenor: number;
  interestRate: number;
  monthlyInstallment: number;
  firstInstallmentDate: string;
  applicationNumber: string;
  creditScore?: number;
  customerIdNumber?: string;
  dateOfBirth?: string;
}): string {
  const customerName = sanitizeForWhatsApp(data.customerName, 50);
  const applicationNumber = sanitizeApplicationNumber(data.applicationNumber);
  
  let message = `🎉 *KREDIT DISETUJUI*\n\n`;
  message += `Yth. *${customerName}*\n\n`;
  message += `Pengajuan kredit Anda disetujui!\n\n`;
  message += `💰 *Detail:*\n`;
  message += `Jumlah: ${formatRupiah(data.amountApproved)}\n`;
  message += `Tenor: ${data.tenor} bln @ ${data.interestRate}%\n`;
  message += `Angsuran: ${formatRupiah(data.monthlyInstallment)}/bln\n`;
  message += `Mulai: ${formatDate(data.firstInstallmentDate)}\n`;
  message += `No: ${applicationNumber}\n`;
  
  if (data.creditScore !== undefined) {
    const emoji = data.creditScore >= 4.5 ? '🌟' : data.creditScore >= 3.5 ? '⭐' : '⚠️';
    message += `\n${emoji} Skor: ${data.creditScore.toFixed(1)}/5\n`;
  }
  
  message += `\n📌 Bayar tepat waktu!\n`;
  
  // Login info (clear and detailed)
  if (data.customerIdNumber && data.dateOfBirth) {
    const dob = new Date(data.dateOfBirth);
    const password = `${String(dob.getDate()).padStart(2, '0')}${String(dob.getMonth() + 1).padStart(2, '0')}${dob.getFullYear()}`;
    message += `\n🔐 *Login Akun Anda:*\n`;
    message += `👤 Username: ${data.customerIdNumber}\n`;
    message += `🔑 Password: ${password}\n`;
    message += `🌐 Link: https://www.mitradana.id/\n`;
  }
  
  message += `\n_Terima kasih!_`;
  
  return message;
}

export function generateDisbursementReceiptMessage(data: {
  customerName: string;
  memberName: string;
  disbursementDate: string;
  amountRequested: number;
  firstInstallmentAmount?: number;
  adminFee?: number;
  netAmount: number;
  applicationNumber: string;
  creditScore?: number;
  customerIdNumber?: string;
  dateOfBirth?: string;
  bankName?: string;
  bankAccountNumber?: string;
  bankAccountHolder?: string;
}): string {
  const customerName = sanitizeForWhatsApp(data.customerName, 50);
  const memberName = sanitizeForWhatsApp(data.memberName, 50);
  const applicationNumber = sanitizeApplicationNumber(data.applicationNumber);
  
  let message = `🧾 *STRUK PENCAIRAN*\n\n`;
  message += `Yth. *${customerName}*\n\n`;
  message += `📋 *Pencairan:*\n`;
  message += `No: ${applicationNumber}\n`;
  message += `Tgl: ${formatDate(data.disbursementDate)}\n`;
  message += `PJ: ${memberName}\n\n`;
  message += `💰 *Dana:*\n`;
  message += `Pengajuan: ${formatRupiah(data.amountRequested)}\n`;
  
  if (data.firstInstallmentAmount) {
    message += `Pot. Angsuran 1: ${formatRupiah(data.firstInstallmentAmount)}\n`;
  }
  if (data.adminFee) {
    message += `Admin: ${formatRupiah(data.adminFee)}\n`;
  }
  message += `*Diterima: ${formatRupiah(data.netAmount)}*\n`;
  
  if (data.creditScore !== undefined) {
    const emoji = data.creditScore >= 4.5 ? '🌟' : data.creditScore >= 3.5 ? '⭐' : '⚠️';
    message += `\n${emoji} Skor: ${data.creditScore.toFixed(1)}/5\n`;
  }
  
  // Bank info (compact)
  if (data.bankName && data.bankAccountNumber && data.bankAccountHolder) {
    message += `\n🏦 *Transfer ke:*\n`;
    message += `${data.bankName} - ${data.bankAccountNumber}\n`;
    message += `a.n. ${data.bankAccountHolder}\n`;
  }
  
  // Login info (clear and detailed)
  if (data.customerIdNumber && data.dateOfBirth) {
    const dob = new Date(data.dateOfBirth);
    const password = `${String(dob.getDate()).padStart(2, '0')}${String(dob.getMonth() + 1).padStart(2, '0')}${dob.getFullYear()}`;
    message += `\n🔐 *Login Akun Anda:*\n`;
    message += `👤 Username: ${data.customerIdNumber}\n`;
    message += `🔑 Password: ${password}\n`;
    message += `🌐 Link: https://www.mitradana.id/\n`;
  }
  
  message += `\n_Simpan struk ini._`;
  
  return message;
}

export function openWhatsAppChat(phone: string, message: string): { usedClipboard: boolean } {
  const isMobile =
    typeof navigator !== "undefined" &&
    /Android|iPhone|iPad|iPod|Windows Phone|Opera Mini|IEMobile/i.test(navigator.userAgent);

  // Clean phone number
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  if (!cleanPhone || cleanPhone.length < 8) {
    console.error('[WA] Invalid phone number:', phone);
    return { usedClipboard: false };
  }

  // Format phone number with country code
  let formattedPhone = cleanPhone;
  if (cleanPhone.startsWith('0')) {
    formattedPhone = '62' + cleanPhone.substring(1);
  } else if (!cleanPhone.startsWith('62')) {
    formattedPhone = '62' + cleanPhone;
  }

  // Encode message
  const encodedMessage = encodeURIComponent(message)
    .replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());

  // Deep link - opens WhatsApp app directly without browser redirect
  const deepLink = `whatsapp://send?phone=${formattedPhone}&text=${encodedMessage}`;
  
  // Fallback wa.me link
  const waLink = `https://wa.me/${formattedPhone}?text=${encodedMessage}`;

  // Backup clipboard for very long messages
  const LONG_THRESHOLD = 1800;
  let usedClipboard = false;
  
  if (encodedMessage.length > LONG_THRESHOLD) {
    try {
      void navigator.clipboard?.writeText(message);
      usedClipboard = true;
      console.info("[WA] message too long → copied to clipboard as backup");
    } catch {
      // ignore
    }
  }

  console.info("[WA] openWhatsAppChat", { isMobile, phone: formattedPhone, messageLen: message.length });

  // Try deep link first (opens WhatsApp app directly)
  // This works on both mobile and desktop if WhatsApp is installed
  const tryDeepLink = () => {
    return new Promise<boolean>((resolve) => {
      const timeout = setTimeout(() => {
        resolve(false);
      }, 1500);

      // Try to open deep link
      window.location.href = deepLink;
      
      // If page doesn't navigate away, deep link failed
      const checkFocus = () => {
        if (document.hidden) {
          clearTimeout(timeout);
          resolve(true);
        }
      };
      
      document.addEventListener('visibilitychange', checkFocus, { once: true });
      
      setTimeout(() => {
        document.removeEventListener('visibilitychange', checkFocus);
      }, 2000);
    });
  };

  // For mobile: use deep link directly (most reliable)
  if (isMobile) {
    console.info("[WA] Mobile - using whatsapp:// deep link");
    window.location.href = deepLink;
    return { usedClipboard };
  }

  // For desktop: try deep link first, fallback to wa.me
  console.info("[WA] Desktop - using whatsapp:// deep link");
  
  // Use the deep link directly - it opens WhatsApp Desktop if installed
  window.location.href = deepLink;
  
  return { usedClipboard };
}




