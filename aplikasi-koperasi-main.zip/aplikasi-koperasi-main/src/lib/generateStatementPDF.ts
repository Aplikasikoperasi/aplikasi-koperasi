import { formatRupiah, formatDate } from "@/lib/utils";

// Lazy load pdfmake to avoid bundle size issues
let pdfMakeInstance: any = null;

async function loadPdfMake() {
  if (pdfMakeInstance) return pdfMakeInstance;
  
  const pdfMake = await import('pdfmake/build/pdfmake');
  const pdfFonts = await import('pdfmake/build/vfs_fonts');
  
  // Fix the vfs fonts import structure
  const vfs = pdfFonts.default?.pdfMake?.vfs || pdfFonts.default?.vfs || pdfFonts.pdfMake?.vfs;
  
  if (pdfMake.default) {
    pdfMake.default.vfs = vfs;
    pdfMakeInstance = pdfMake.default;
  } else if (pdfMake) {
    (pdfMake as any).vfs = vfs;
    pdfMakeInstance = pdfMake;
  }
  
  return pdfMakeInstance;
}

export interface StatementData {
  memberName: string;
  memberNik?: string;
  memberAddress?: string;
  memberDateOfBirth?: string;
  memberPhotoUrl?: string;
  customerName: string;
  customerNik?: string;
  customerAddress?: string;
  customerDateOfBirth?: string;
  customerPhotoUrl?: string;
  customerPhone?: string;
  applicationNumber: string;
  amount: number;
  tenor: number;
  interestRate: number;
  monthlyInstallment: number;
  applicationDate: Date;
  collateralDescription?: string;
}

// Helper to convert image URL to base64
async function getImageAsBase64(url: string): Promise<string | null> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}

export async function generateStatementPDF(data: StatementData, action: 'print' | 'download') {
  const pdfMake = await loadPdfMake();
  
  const {
    memberName,
    memberNik,
    memberAddress,
    memberDateOfBirth,
    memberPhotoUrl,
    customerName,
    customerNik,
    customerAddress,
    customerDateOfBirth,
    customerPhotoUrl,
    customerPhone,
    applicationNumber,
    amount,
    tenor,
    interestRate,
    monthlyInstallment,
    applicationDate,
    collateralDescription,
  } = data;

  const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

  const dayName = days[applicationDate.getDay()];
  const day = applicationDate.getDate();
  const month = months[applicationDate.getMonth()];
  const year = applicationDate.getFullYear();

  const rupiah = (v: number) => formatRupiah(v);

  // Fetch images as base64
  const [memberImageBase64, customerImageBase64] = await Promise.all([
    memberPhotoUrl ? getImageAsBase64(memberPhotoUrl) : null,
    customerPhotoUrl ? getImageAsBase64(customerPhotoUrl) : null,
  ]);

  // Helper function to create person info section with photo
  const createPersonSection = (
    title: string,
    name: string,
    nik: string | undefined,
    dob: string | undefined,
    address: string | undefined,
    phone: string | undefined,
    imageBase64: string | null,
    bgColor: string,
    textColor: string
  ) => {
    const infoContent = [
      { text: `Nama: ${name}`, fontSize: 8, margin: [0, 0, 0, 1] },
      { text: `NIK: ${nik || '-'}`, fontSize: 8, margin: [0, 0, 0, 1] },
      { text: `Tgl Lahir: ${dob ? formatDate(dob) : '-'}`, fontSize: 8, margin: [0, 0, 0, 1] },
      { text: `Alamat: ${address || '-'}`, fontSize: 8, margin: [0, 0, 0, 1] },
      ...(phone ? [{ text: `Telepon: ${phone}`, fontSize: 8, margin: [0, 0, 0, 1] }] : []),
    ];

    const photoColumn = imageBase64
      ? { image: imageBase64, width: 50, height: 60, margin: [0, 0, 5, 0] }
      : { 
          text: name.substring(0, 2).toUpperCase(),
          width: 50,
          alignment: 'center' as const,
          margin: [0, 20, 5, 0],
          fontSize: 14,
          bold: true,
          color: textColor,
        };

    return {
      table: {
        widths: ['*'],
        body: [
          [
            {
              stack: [
                { text: title, bold: true, alignment: 'center', fontSize: 9, color: textColor, margin: [0, 0, 0, 5] },
                {
                  columns: [
                    photoColumn,
                    { stack: infoContent, width: '*' }
                  ]
                }
              ],
              fillColor: bgColor,
              margin: [5, 5, 5, 5]
            }
          ]
        ]
      },
      layout: {
        hLineWidth: () => 0.5,
        vLineWidth: () => 0.5,
        hLineColor: () => '#cccccc',
        vLineColor: () => '#cccccc',
      }
    };
  };

  const content: any[] = [
    // Title
    { 
      text: "SURAT PERNYATAAN", 
      style: "header", 
      alignment: "center", 
      margin: [0, 0, 0, 3] 
    },
    { 
      text: "PENANGGUNG JAWAB KREDIT", 
      style: "subheader", 
      alignment: "center", 
      margin: [0, 0, 0, 15] 
    },
    
    // Opening
    { 
      text: `Pada hari ini ${dayName}, tanggal ${day} ${month} ${year}, saya yang bertanda tangan di bawah ini:`, 
      margin: [0, 0, 0, 10],
      fontSize: 10,
    },
    
    // Two column layout for PJ and Customer info with photos
    {
      columns: [
        {
          width: '49%',
          ...createPersonSection(
            'PENANGGUNG JAWAB',
            memberName,
            memberNik,
            memberDateOfBirth,
            memberAddress,
            undefined,
            memberImageBase64,
            '#FEF3C7',
            '#92400E'
          )
        },
        { width: '2%', text: '' },
        {
          width: '49%',
          ...createPersonSection(
            'NASABAH',
            customerName,
            customerNik,
            customerDateOfBirth,
            customerAddress,
            customerPhone,
            customerImageBase64,
            '#DBEAFE',
            '#1E40AF'
          )
        }
      ],
      margin: [0, 0, 0, 10]
    },
    
    { 
      text: 'Dengan ini menyatakan bahwa saya bersedia menjadi Penanggung Jawab dan Saksi untuk pengajuan kredit dengan rincian sebagai berikut:', 
      margin: [0, 0, 0, 8],
      fontSize: 10,
    },
    
    // Credit details table - compact
    {
      table: {
        widths: ['25%', '25%', '25%', '25%'],
        body: [
          [
            { text: 'No. Pengajuan', bold: true, fontSize: 8, fillColor: '#f3f4f6' },
            { text: applicationNumber, fontSize: 8, fillColor: '#f3f4f6' },
            { text: 'Tenor', bold: true, fontSize: 8, fillColor: '#f3f4f6' },
            { text: `${tenor} Bulan`, fontSize: 8, fillColor: '#f3f4f6' }
          ],
          [
            { text: 'Jumlah Pinjaman', bold: true, fontSize: 8 },
            { text: rupiah(amount), fontSize: 8, bold: true, color: '#15803D' },
            { text: 'Bunga', bold: true, fontSize: 8 },
            { text: `${interestRate}% / bulan`, fontSize: 8 }
          ],
          [
            { text: 'Angsuran/Bulan', bold: true, fontSize: 8 },
            { text: rupiah(monthlyInstallment), fontSize: 8, bold: true, color: '#1D4ED8', colSpan: 3 },
            {}, {}
          ],
          ...(collateralDescription ? [[
            { text: 'Jaminan', bold: true, fontSize: 8 },
            { text: collateralDescription, fontSize: 8, colSpan: 3 },
            {}, {}
          ]] : []),
        ]
      },
      layout: {
        hLineWidth: () => 0.5,
        vLineWidth: () => 0.5,
        hLineColor: () => '#d1d5db',
        vLineColor: () => '#d1d5db',
        paddingLeft: () => 4,
        paddingRight: () => 4,
        paddingTop: () => 3,
        paddingBottom: () => 3,
      },
      margin: [0, 0, 0, 10]
    },
    
    // Statement content
    { 
      text: 'PERNYATAAN:', 
      bold: true,
      fontSize: 10,
      margin: [0, 0, 0, 5] 
    },
    
    {
      ol: [
        { 
          text: [
            'Saya menyatakan bersedia menjadi Penanggung Jawab dan sebagai Saksi serta menjamin kelancaran pembayaran angsuran kredit sebesar ',
            { text: rupiah(monthlyInstallment), bold: true },
            ' per bulan selama ',
            { text: `${tenor} bulan`, bold: true },
            ' sampai selesai.'
          ],
          fontSize: 9,
          margin: [0, 0, 0, 4]
        },
        { 
          text: [
            'Apabila nasabah ',
            { text: customerName, bold: true },
            ' melarikan diri dan tidak membayar angsuran, maka saya yang akan menggantikan dan membayar seluruh sisa pinjaman yang belum dibayarkan.'
          ],
          fontSize: 9,
          margin: [0, 0, 0, 4]
        },
        { 
          text: 'Pernyataan ini saya buat dengan penuh kesadaran dan tanpa paksaan dari pihak manapun.',
          fontSize: 9,
          margin: [0, 0, 0, 4]
        },
      ],
      margin: [15, 0, 0, 10]
    },
    
    { 
      text: 'Demikian surat pernyataan ini saya buat untuk dipergunakan sebagaimana mestinya.', 
      fontSize: 10,
      margin: [0, 0, 0, 20] 
    },
    
    // Signature section - single column aligned right (PJ only)
    {
      columns: [
        { width: '*', text: '' },
        {
          width: 'auto',
          stack: [
            { text: `${day} ${month} ${year}`, alignment: 'center', fontSize: 8, color: '#666666' },
            { text: 'Yang Menyatakan,', alignment: 'center', fontSize: 9, margin: [0, 2, 0, 0] },
            { text: ' ', margin: [0, 50, 0, 0] },
            { text: `(${memberName})`, alignment: 'center', bold: true, fontSize: 10 },
            { text: 'Penanggung Jawab Kredit', alignment: 'center', fontSize: 8, color: '#666666' }
          ],
          margin: [0, 0, 30, 0]
        }
      ],
      margin: [0, 0, 0, 15]
    },
    
    // Footer note
    {
      text: '* Surat pernyataan ini merupakan bagian tidak terpisahkan dari perjanjian kredit.',
      fontSize: 8,
      italics: true,
      alignment: 'center',
      color: '#666666'
    }
  ];

  const docDefinition = {
    pageSize: 'A4',
    pageMargins: [40, 40, 40, 40],
    content,
    styles: {
      header: { 
        fontSize: 14, 
        bold: true,
        font: 'Roboto'
      },
      subheader: { 
        fontSize: 12, 
        bold: true,
        font: 'Roboto'
      },
    },
    defaultStyle: {
      font: 'Roboto',
      fontSize: 10,
      lineHeight: 1.3
    }
  } as any;

  const pdfDoc = pdfMake.createPdf(docDefinition);
  
  if (action === 'print') {
    pdfDoc.print();
  } else {
    const fileName = `Surat_Pernyataan_${applicationNumber}_${memberName.replace(/\s+/g, '_')}.pdf`;
    pdfDoc.download(fileName);
  }
}
